import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10, 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (short) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-1), (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(4, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) -1, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getEnd();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(100, serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(8, serialDate4);
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) '#', serialDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = null;
        try {
            timeSeries4.add(timeSeriesDataItem5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries4.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) -1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) '#');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        try {
            java.lang.Number number6 = timeSeries4.getValue((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        try {
            org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getFollowingDayOfWeek((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        long long5 = timeSeries4.getMaximumItemAge();
//        timeSeries4.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond7.peg(calendar8);
//        long long10 = fixedMillisecond7.getMiddleMillisecond();
//        long long11 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
//        try {
//            timeSeries4.add(timeSeriesDataItem13, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560193147462L + "'", long10 == 1560193147462L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560193147462L + "'", long11 == 1560193147462L);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        long long5 = timeSeries4.getMaximumItemAge();
//        timeSeries4.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond7.peg(calendar8);
//        long long10 = fixedMillisecond7.getMiddleMillisecond();
//        long long11 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
//        java.lang.Number number14 = timeSeriesDataItem13.getValue();
//        try {
//            timeSeries4.add(timeSeriesDataItem13, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560193147756L + "'", long10 == 1560193147756L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560193147756L + "'", long11 == 1560193147756L);
//        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0d + "'", number14.equals(0.0d));
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone5);
        try {
            int int7 = spreadsheetDate1.compareTo((java.lang.Object) timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: sun.util.calendar.ZoneInfo cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        serialDate11.setDescription("ERROR : Relative To String");
        java.lang.String str14 = serialDate11.getDescription();
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        try {
            org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(7, (int) (short) 1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        try {
            timeSeries4.update(1, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond9.peg(calendar10);
//        long long12 = fixedMillisecond9.getMiddleMillisecond();
//        long long13 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        int int16 = month8.compareTo((java.lang.Object) timeSeriesDataItem15);
//        java.util.Calendar calendar17 = null;
//        try {
//            long long18 = month8.getLastMillisecond(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560193150729L + "'", long12 == 1560193150729L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560193150729L + "'", long13 == 1560193150729L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("6-January-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2019, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day11.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNull(class8);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        try {
            org.jfree.data.time.SerialDate serialDate35 = spreadsheetDate1.getNearestDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.previous();
//        long long5 = regularTimePeriod4.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193151232L + "'", long2 == 1560193151232L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193151232L + "'", long3 == 1560193151232L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560193151231L + "'", long5 == 1560193151231L);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        serialDate11.setDescription("ERROR : Relative To String");
        java.lang.String str14 = serialDate11.getDescription();
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
        try {
            org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        long long5 = timeSeries4.getMaximumItemAge();
//        timeSeries4.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond7.getLastMillisecond(calendar9);
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 100.0d);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560193152424L + "'", long10 == 1560193152424L);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        int int4 = day3.getMonth();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        java.util.Calendar calendar6 = null;
        try {
            day3.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "November" + "'", str1.equals("November"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        timeSeries4.setDescription("6-January-1900");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.removeChangeListener(seriesChangeListener7);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(3, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        try {
            timeSeries7.delete(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(1, 2958465, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        try {
            timeSeries4.delete((int) (short) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        java.lang.Number number1 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, number1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        try {
            org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate1.getFollowingDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        int int5 = timeSeries4.getItemCount();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.getDataItem((-43619));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener7);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        timeSeries4.setDescription("6-January-1900");
        try {
            timeSeries4.delete((int) (byte) 0, (-43619));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 100, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(4, 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(4, year17);
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond19.peg(calendar20);
//        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries18.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date30 = fixedMillisecond29.getEnd();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond29.getLastMillisecond(calendar31);
//        try {
//            timeSeries28.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) (-43619));
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560193154871L + "'", long32 == 1560193154871L);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(8, serialDate4);
        org.jfree.data.time.SerialDate serialDate8 = serialDate4.getFollowingDayOfWeek(1);
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-43619), serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        try {
            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 11);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("6-January-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.Object obj34 = null;
        boolean boolean35 = spreadsheetDate16.equals(obj34);
        java.lang.String str36 = spreadsheetDate16.toString();
        org.jfree.data.time.SerialDate serialDate37 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date39 = fixedMillisecond38.getEnd();
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date39);
        serialDate40.setDescription("ERROR : Relative To String");
        try {
            boolean boolean44 = spreadsheetDate16.isInRange(serialDate37, serialDate40, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "6-January-1900" + "'", str36.equals("6-January-1900"));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(serialDate40);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        timeSeries4.setDescription("6-January-1900");
        int int7 = timeSeries4.getItemCount();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class16);
        java.lang.String str18 = timeSeries17.getDescription();
        boolean boolean19 = month12.equals((java.lang.Object) str18);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = month12.getLastMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class13);
        timeSeries14.setDescription("6-January-1900");
        java.lang.Class<?> wildcardClass17 = timeSeries14.getClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond9, (java.lang.Class) wildcardClass17);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 1560193154730L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.util.Date date9 = fixedMillisecond5.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month11.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        int int6 = day5.getMonth();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        java.lang.String str9 = regularTimePeriod8.toString();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "11-June-2019" + "'", str9.equals("11-June-2019"));
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setMaximumItemCount(1900);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) "");
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Mon Jun 10 11:59:08 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(2, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 6-January-1900" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: 6-January-1900"));
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond9.peg(calendar10);
//        long long12 = fixedMillisecond9.getMiddleMillisecond();
//        long long13 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        int int16 = month8.compareTo((java.lang.Object) timeSeriesDataItem15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month8.next();
//        long long18 = month8.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560193161533L + "'", long12 == 1560193161533L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560193161533L + "'", long13 == 1560193161533L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        boolean boolean8 = timeSeriesDataItem6.equals((java.lang.Object) 1560193151218L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193161668L + "'", long3 == 1560193161668L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193161668L + "'", long4 == 1560193161668L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) strArray0);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        serialDate11.setDescription("ERROR : Relative To String");
        java.lang.String str14 = serialDate11.getDescription();
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date22 = fixedMillisecond21.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        int int25 = day24.getMonth();
        boolean boolean26 = spreadsheetDate20.equals((java.lang.Object) day24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getEnd();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        serialDate29.setDescription("ERROR : Relative To String");
        java.lang.String str32 = serialDate29.getDescription();
        boolean boolean33 = spreadsheetDate20.isOnOrBefore(serialDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date37 = fixedMillisecond36.getEnd();
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(serialDate38);
        int int40 = day39.getMonth();
        boolean boolean41 = spreadsheetDate35.equals((java.lang.Object) day39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date43 = fixedMillisecond42.getEnd();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(date43);
        serialDate44.setDescription("ERROR : Relative To String");
        java.lang.String str47 = serialDate44.getDescription();
        boolean boolean48 = spreadsheetDate35.isOnOrBefore(serialDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean51 = spreadsheetDate35.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean52 = spreadsheetDate20.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean53 = spreadsheetDate17.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        try {
            org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ERROR : Relative To String" + "'", str32.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ERROR : Relative To String" + "'", str47.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date35 = fixedMillisecond34.getEnd();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
        boolean boolean38 = spreadsheetDate16.isAfter(serialDate36);
        try {
            org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate16.getNearestDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar20 = null;
        fixedMillisecond19.peg(calendar20);
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries18.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
        timeSeries4.fireSeriesChanged();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date33 = fixedMillisecond32.getEnd();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate34);
        int int36 = day35.getMonth();
        boolean boolean37 = spreadsheetDate31.equals((java.lang.Object) day35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day35.next();
        try {
            timeSeries4.add(regularTimePeriod38, (java.lang.Number) 1560193147514L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(6, (int) (short) 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar20 = null;
        fixedMillisecond19.peg(calendar20);
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries18.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date34 = fixedMillisecond33.getEnd();
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        int int37 = day36.getMonth();
        boolean boolean38 = spreadsheetDate32.equals((java.lang.Object) day36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day36.next();
        try {
            timeSeries18.add(regularTimePeriod39, (java.lang.Number) (byte) 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
        java.util.Calendar calendar13 = null;
        try {
            year9.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries15.createCopy(4, 100);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries15.createCopy((int) 'a', (int) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.addAndOrUpdate(timeSeries21);
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class26);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries27.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date31 = fixedMillisecond30.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date31, timeZone33);
        boolean boolean35 = timeSeries27.equals((java.lang.Object) day34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day34.next();
        try {
            timeSeries22.add((org.jfree.data.time.RegularTimePeriod) day34, (java.lang.Number) 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        long long3 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560193162514L + "'", long2 == 1560193162514L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193162514L + "'", long3 == 1560193162514L);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.lang.Class class9 = timeSeries4.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries4.removeChangeListener(seriesChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        long long14 = fixedMillisecond13.getSerialIndex();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond9.peg(calendar10);
//        long long12 = fixedMillisecond9.getMiddleMillisecond();
//        long long13 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        int int16 = month8.compareTo((java.lang.Object) timeSeriesDataItem15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month8.next();
//        java.util.Calendar calendar18 = null;
//        try {
//            month8.peg(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560193163936L + "'", long12 == 1560193163936L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560193163936L + "'", long13 == 1560193163936L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.Object obj34 = null;
        boolean boolean35 = spreadsheetDate16.equals(obj34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        try {
            org.jfree.data.time.SerialDate serialDate38 = spreadsheetDate16.getFollowingDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        long long5 = timeSeries4.getMaximumItemAge();
//        timeSeries4.clear();
//        timeSeries4.setMaximumItemCount((int) (short) 10);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class12);
//        int int14 = timeSeries13.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries4.addAndOrUpdate(timeSeries13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        fixedMillisecond16.peg(calendar17);
//        long long19 = fixedMillisecond16.getMiddleMillisecond();
//        long long20 = fixedMillisecond16.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, 0.0d);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class26);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries27.createCopy(4, 100);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries27.createCopy((int) 'a', (int) (short) 100);
//        boolean boolean34 = timeSeriesDataItem22.equals((java.lang.Object) 'a');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond35.next();
//        int int37 = timeSeriesDataItem22.compareTo((java.lang.Object) regularTimePeriod36);
//        try {
//            timeSeries13.add(timeSeriesDataItem22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560193164718L + "'", long19 == 1560193164718L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560193164718L + "'", long20 == 1560193164718L);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        long long28 = month23.getLastMillisecond();
        java.util.Calendar calendar29 = null;
        try {
            long long30 = month23.getLastMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1556693999999L + "'", long28 == 1556693999999L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.Object obj34 = null;
        boolean boolean35 = spreadsheetDate16.equals(obj34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SerialDate serialDate37 = null;
        try {
            boolean boolean38 = spreadsheetDate16.isAfter(serialDate37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        java.lang.String str27 = timeSeries4.getDescription();
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar34 = null;
        fixedMillisecond33.peg(calendar34);
        java.lang.Number number36 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        java.util.Date date37 = fixedMillisecond33.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond33.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 6);
        try {
            org.jfree.data.time.TimeSeries timeSeries41 = timeSeries4.createCopy(regularTimePeriod38, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start on or before end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNull(number36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.lang.Class class9 = timeSeries4.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries4.removeChangeListener(seriesChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getEnd();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone15);
        int int17 = day16.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) (byte) 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        timeSeries4.clear();
        java.util.Collection collection6 = timeSeries4.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.removeChangeListener(seriesChangeListener7);
        org.junit.Assert.assertNotNull(collection6);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        int int2 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar20 = null;
        fixedMillisecond19.peg(calendar20);
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries18.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
        try {
            java.lang.Number number30 = timeSeries28.getValue(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries28);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond19.peg(calendar20);
//        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries18.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
//        timeSeries28.setDescription("ERROR : Relative To String");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries28.removeChangeListener(seriesChangeListener31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date34 = fixedMillisecond33.getEnd();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getEnd();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date37);
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date37, timeZone39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date34, timeZone39);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar43 = null;
//        fixedMillisecond42.peg(calendar43);
//        long long45 = fixedMillisecond42.getMiddleMillisecond();
//        long long46 = fixedMillisecond42.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, 0.0d);
//        int int49 = month41.compareTo((java.lang.Object) timeSeriesDataItem48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month41.next();
//        int int51 = month41.getYearValue();
//        java.lang.Number number52 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month41);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
//        boolean boolean55 = year53.equals((java.lang.Object) 'a');
//        try {
//            timeSeries28.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 1560279599999L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560193165985L + "'", long45 == 1560193165985L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560193165985L + "'", long46 == 1560193165985L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries15.createCopy(4, 100);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries15.createCopy((int) 'a', (int) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.addAndOrUpdate(timeSeries21);
        try {
            timeSeries21.update(0, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(timeSeries22);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 8);
        java.lang.Object obj3 = null;
        int int4 = year0.compareTo(obj3);
        int int5 = year0.getYear();
        boolean boolean7 = year0.equals((java.lang.Object) 43626L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 11:59:22 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date35 = fixedMillisecond34.getEnd();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
        boolean boolean38 = spreadsheetDate16.isAfter(serialDate36);
        int int39 = spreadsheetDate16.getMonth();
        int int40 = spreadsheetDate16.getDayOfMonth();
        try {
            org.jfree.data.time.SerialDate serialDate42 = spreadsheetDate16.getPreviousDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month8.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:59:06 PDT 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable throwable5 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class12);
        int int14 = timeSeries13.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries4.addAndOrUpdate(timeSeries13);
        boolean boolean16 = timeSeries4.isEmpty();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date20 = fixedMillisecond19.getEnd();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
        int int23 = day22.getMonth();
        boolean boolean24 = spreadsheetDate18.equals((java.lang.Object) day22);
        org.jfree.data.time.SerialDate serialDate25 = day22.getSerialDate();
        boolean boolean26 = timeSeries4.equals((java.lang.Object) serialDate25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = null;
        try {
            timeSeries4.add(timeSeriesDataItem27, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
        boolean boolean5 = timeSeries4.isEmpty();
        try {
            org.jfree.data.time.TimeSeries timeSeries8 = timeSeries4.createCopy((int) '#', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        int int10 = year0.compareTo((java.lang.Object) propertyChangeListener8);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year0.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) 10.0f);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class10);
        boolean boolean12 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        long long15 = fixedMillisecond14.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries4.addAndOrUpdate(timeSeries11);
        try {
            timeSeries18.update((int) '#', (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getEnd();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
//        int int13 = day12.getMonth();
//        boolean boolean14 = spreadsheetDate8.equals((java.lang.Object) day12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getEnd();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
//        serialDate17.setDescription("ERROR : Relative To String");
//        java.lang.String str20 = serialDate17.getDescription();
//        boolean boolean21 = spreadsheetDate8.isOnOrBefore(serialDate17);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getEnd();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate26);
//        int int28 = day27.getMonth();
//        boolean boolean29 = spreadsheetDate23.equals((java.lang.Object) day27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date31 = fixedMillisecond30.getEnd();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
//        serialDate32.setDescription("ERROR : Relative To String");
//        java.lang.String str35 = serialDate32.getDescription();
//        boolean boolean36 = spreadsheetDate23.isOnOrBefore(serialDate32);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean39 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        boolean boolean40 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date42 = fixedMillisecond41.getEnd();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate43);
//        boolean boolean45 = spreadsheetDate23.isAfter(serialDate43);
//        boolean boolean46 = timeSeriesDataItem6.equals((java.lang.Object) serialDate43);
//        java.lang.Class class50 = null;
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class50);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar53 = null;
//        fixedMillisecond52.peg(calendar53);
//        java.lang.Number number55 = timeSeries51.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
//        timeSeries51.setMaximumItemCount(1900);
//        int int58 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries51);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = null;
//        try {
//            timeSeries51.add(timeSeriesDataItem59, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193167123L + "'", long3 == 1560193167123L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193167123L + "'", long4 == 1560193167123L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ERROR : Relative To String" + "'", str20.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ERROR : Relative To String" + "'", str35.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNull(number55);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, 1);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        long long4 = day3.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day3.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Third" + "'", str1.equals("Third"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((int) 'a', (int) (short) 100);
        java.lang.Number number12 = null;
        try {
            timeSeries10.update(31, number12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        timeSeries13.setMaximumItemCount(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getEnd();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date20 = fixedMillisecond19.getEnd();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20, timeZone22);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date17, timeZone22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar26 = null;
//        fixedMillisecond25.peg(calendar26);
//        long long28 = fixedMillisecond25.getMiddleMillisecond();
//        long long29 = fixedMillisecond25.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, 0.0d);
//        int int32 = month24.compareTo((java.lang.Object) timeSeriesDataItem31);
//        try {
//            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month24, 0.0d);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560193169619L + "'", long28 == 1560193169619L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560193169619L + "'", long29 == 1560193169619L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        serialDate11.setDescription("ERROR : Relative To String");
        java.lang.String str14 = serialDate11.getDescription();
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date19 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        int int22 = day21.getMonth();
        boolean boolean23 = spreadsheetDate17.equals((java.lang.Object) day21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date25 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        serialDate26.setDescription("ERROR : Relative To String");
        java.lang.String str29 = serialDate26.getDescription();
        boolean boolean30 = spreadsheetDate17.isOnOrBefore(serialDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean33 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean34 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.Object obj35 = null;
        boolean boolean36 = spreadsheetDate17.equals(obj35);
        try {
            org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ERROR : Relative To String" + "'", str29.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getEnd();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 1, (int) (short) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        fixedMillisecond20.peg(calendar21);
//        java.lang.Number number23 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        java.lang.String str24 = fixedMillisecond20.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond20.previous();
//        try {
//            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(class14);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Mon Jun 10 11:59:32 PDT 2019" + "'", str24.equals("Mon Jun 10 11:59:32 PDT 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2958465);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond9.peg(calendar10);
//        long long12 = fixedMillisecond9.getMiddleMillisecond();
//        long long13 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        int int16 = month8.compareTo((java.lang.Object) timeSeriesDataItem15);
//        long long17 = month8.getLastMillisecond();
//        java.util.Calendar calendar18 = null;
//        try {
//            long long19 = month8.getFirstMillisecond(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560193172601L + "'", long12 == 1560193172601L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560193172601L + "'", long13 == 1560193172601L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class12);
        int int14 = timeSeries13.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries4.addAndOrUpdate(timeSeries13);
        boolean boolean16 = timeSeries4.isEmpty();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date20 = fixedMillisecond19.getEnd();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
        int int23 = day22.getMonth();
        boolean boolean24 = spreadsheetDate18.equals((java.lang.Object) day22);
        org.jfree.data.time.SerialDate serialDate25 = day22.getSerialDate();
        boolean boolean26 = timeSeries4.equals((java.lang.Object) serialDate25);
        try {
            org.jfree.data.time.SerialDate serialDate28 = serialDate25.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "February" + "'", str1.equals("February"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date35 = fixedMillisecond34.getEnd();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
        boolean boolean38 = spreadsheetDate16.isAfter(serialDate36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date40 = fixedMillisecond39.getEnd();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(date40);
        serialDate41.setDescription("ERROR : Relative To String");
        java.lang.String str44 = serialDate41.getDescription();
        boolean boolean45 = spreadsheetDate16.isOn(serialDate41);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "ERROR : Relative To String" + "'", str44.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener27);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.util.Date date9 = fixedMillisecond5.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond5.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, number11);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) 1560193150522L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        long long2 = year1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, year1);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond10.peg(calendar11);
//        java.lang.Number number13 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        timeSeries9.setRangeDescription("hi!");
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class19);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(4, 100);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries20.createCopy((int) 'a', (int) (short) 100);
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries9.addAndOrUpdate(timeSeries26);
//        int int28 = year1.compareTo((java.lang.Object) timeSeries27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date30 = fixedMillisecond29.getEnd();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond29.getLastMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond29.getFirstMillisecond(calendar33);
//        try {
//            timeSeries27.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (double) 1560193151232L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560193177288L + "'", long32 == 1560193177288L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560193177288L + "'", long34 == 1560193177288L);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("11-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) 10.0f);
        timeSeries4.setDomainDescription("6-January-1900");
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getEnd();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date10, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month17, (double) 1560193162116L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
//        boolean boolean5 = timeSeries4.isEmpty();
//        timeSeries4.setNotify(true);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        fixedMillisecond13.peg(calendar14);
//        java.lang.Number number16 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        java.util.Date date17 = fixedMillisecond13.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond13.next();
//        long long19 = fixedMillisecond13.getSerialIndex();
//        long long20 = fixedMillisecond13.getFirstMillisecond();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 1560193146505L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560193177723L + "'", long19 == 1560193177723L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560193177723L + "'", long20 == 1560193177723L);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        java.lang.String str4 = serialDate2.getDescription();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 11:59:06 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class4);
//        timeSeries5.setDescription("6-January-1900");
//        java.lang.Class<?> wildcardClass8 = timeSeries5.getClass();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, (java.lang.Class) wildcardClass8);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond0.getLastMillisecond(calendar10);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560193177903L + "'", long11 == 1560193177903L);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.util.Date date9 = fixedMillisecond5.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        long long12 = month11.getFirstMillisecond();
        java.util.Calendar calendar13 = null;
        try {
            month11.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(3, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        timeSeries4.clear();
        int int6 = timeSeries4.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        int int6 = day5.getMonth();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        serialDate10.setDescription("ERROR : Relative To String");
//        java.lang.String str13 = serialDate10.getDescription();
//        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date19 = fixedMillisecond18.getEnd();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
//        serialDate20.setDescription("ERROR : Relative To String");
//        java.lang.String str23 = serialDate20.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getEnd();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(8, serialDate27);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate27.getFollowingDayOfWeek(1);
//        boolean boolean32 = spreadsheetDate16.isInRange(serialDate20, serialDate27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getEnd();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(8, serialDate36);
//        org.jfree.data.time.SerialDate serialDate40 = serialDate36.getFollowingDayOfWeek(1);
//        int int41 = spreadsheetDate16.compareTo((java.lang.Object) serialDate36);
//        java.util.Date date42 = spreadsheetDate16.toDate();
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
//        java.lang.String str44 = year43.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year43.previous();
//        java.util.Calendar calendar46 = null;
//        try {
//            year43.peg(calendar46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ERROR : Relative To String" + "'", str23.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-43619) + "'", int41 == (-43619));
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1900" + "'", str44.equals("1900"));
//        org.junit.Assert.assertNull(regularTimePeriod45);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        serialDate11.setDescription("ERROR : Relative To String");
        java.lang.String str14 = serialDate11.getDescription();
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date19 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        int int22 = day21.getMonth();
        boolean boolean23 = spreadsheetDate17.equals((java.lang.Object) day21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date25 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        serialDate26.setDescription("ERROR : Relative To String");
        java.lang.String str29 = serialDate26.getDescription();
        boolean boolean30 = spreadsheetDate17.isOnOrBefore(serialDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean33 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean34 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date39 = fixedMillisecond38.getEnd();
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate40);
        int int42 = day41.getMonth();
        boolean boolean43 = spreadsheetDate37.equals((java.lang.Object) day41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date45 = fixedMillisecond44.getEnd();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
        serialDate46.setDescription("ERROR : Relative To String");
        java.lang.String str49 = serialDate46.getDescription();
        boolean boolean50 = spreadsheetDate37.isOnOrBefore(serialDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean53 = spreadsheetDate37.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date55 = fixedMillisecond54.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        serialDate56.setDescription("ERROR : Relative To String");
        java.lang.String str59 = serialDate56.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date62 = fixedMillisecond61.getEnd();
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance(date62);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(serialDate63);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addMonths(8, serialDate63);
        org.jfree.data.time.SerialDate serialDate67 = serialDate63.getFollowingDayOfWeek(1);
        boolean boolean68 = spreadsheetDate52.isInRange(serialDate56, serialDate63);
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.addMonths(6, (org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean70 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        int int71 = spreadsheetDate2.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ERROR : Relative To String" + "'", str29.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "ERROR : Relative To String" + "'", str49.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "ERROR : Relative To String" + "'", str59.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 7 + "'", int71 == 7);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond19.peg(calendar20);
//        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries18.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
//        java.lang.Class class32 = null;
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class32);
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timeSeries33.addPropertyChangeListener(propertyChangeListener34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getEnd();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date37);
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date37, timeZone39);
//        boolean boolean41 = timeSeries33.equals((java.lang.Object) day40);
//        int int42 = day40.getMonth();
//        java.lang.String str43 = day40.toString();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day40, (double) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar20 = null;
        fixedMillisecond19.peg(calendar20);
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries18.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
        java.lang.Object obj29 = timeSeries28.clone();
        timeSeries28.setMaximumItemCount(0);
        boolean boolean32 = timeSeries28.isEmpty();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        int int6 = day5.getMonth();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        long long9 = day5.getSerialIndex();
//        int int10 = day5.getYear();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        int int16 = day11.compareTo((java.lang.Object) 6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setMaximumItemCount(1900);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries4.removeChangeListener(seriesChangeListener11);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
//        long long5 = day4.getLastMillisecond();
//        long long6 = day4.getLastMillisecond();
//        java.lang.Object obj7 = null;
//        int int8 = day4.compareTo(obj7);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries4.getTimePeriod((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number8);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Number number7 = timeSeriesDataItem6.getValue();
//        java.lang.Number number8 = timeSeriesDataItem6.getValue();
//        java.lang.Object obj9 = timeSeriesDataItem6.clone();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193178609L + "'", long3 == 1560193178609L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193178609L + "'", long4 == 1560193178609L);
//        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
//        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0d + "'", number8.equals(0.0d));
//        org.junit.Assert.assertNotNull(obj9);
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        java.lang.String str9 = fixedMillisecond5.toString();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond5.getMiddleMillisecond(calendar10);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Mon Jun 10 11:59:38 PDT 2019" + "'", str9.equals("Mon Jun 10 11:59:38 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560193178628L + "'", long11 == 1560193178628L);
//    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
//        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
//        long long13 = day11.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560150000000L + "'", long13 == 1560150000000L);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getLastMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193178716L + "'", long3 == 1560193178716L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193178716L + "'", long4 == 1560193178716L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560193178716L + "'", long6 == 1560193178716L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560193178716L + "'", long8 == 1560193178716L);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Mon Jun 10 11:59:22 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class12);
        int int14 = timeSeries13.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries4.addAndOrUpdate(timeSeries13);
        boolean boolean16 = timeSeries4.isEmpty();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date20 = fixedMillisecond19.getEnd();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
        int int23 = day22.getMonth();
        boolean boolean24 = spreadsheetDate18.equals((java.lang.Object) day22);
        org.jfree.data.time.SerialDate serialDate25 = day22.getSerialDate();
        boolean boolean26 = timeSeries4.equals((java.lang.Object) serialDate25);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries4.getTimePeriod(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        timeSeries13.setRangeDescription("February");
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(class14);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        try {
            java.lang.Number number10 = timeSeries4.getValue(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        serialDate11.setDescription("ERROR : Relative To String");
        java.lang.String str14 = serialDate11.getDescription();
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date22 = fixedMillisecond21.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        int int25 = day24.getMonth();
        boolean boolean26 = spreadsheetDate20.equals((java.lang.Object) day24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getEnd();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        serialDate29.setDescription("ERROR : Relative To String");
        java.lang.String str32 = serialDate29.getDescription();
        boolean boolean33 = spreadsheetDate20.isOnOrBefore(serialDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date37 = fixedMillisecond36.getEnd();
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(serialDate38);
        int int40 = day39.getMonth();
        boolean boolean41 = spreadsheetDate35.equals((java.lang.Object) day39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date43 = fixedMillisecond42.getEnd();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(date43);
        serialDate44.setDescription("ERROR : Relative To String");
        java.lang.String str47 = serialDate44.getDescription();
        boolean boolean48 = spreadsheetDate35.isOnOrBefore(serialDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean51 = spreadsheetDate35.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean52 = spreadsheetDate20.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean53 = spreadsheetDate17.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date55 = fixedMillisecond54.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        serialDate56.setDescription("ERROR : Relative To String");
        boolean boolean59 = spreadsheetDate35.isAfter(serialDate56);
        serialDate56.setDescription("org.jfree.data.time.TimePeriodFormatException: 6-January-1900");
        try {
            org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) '4', serialDate56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ERROR : Relative To String" + "'", str32.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ERROR : Relative To String" + "'", str47.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        java.lang.Comparable comparable0 = null;
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class6);
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date11 = fixedMillisecond10.getEnd();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date11);
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date11, timeZone13);
//        boolean boolean15 = timeSeries7.equals((java.lang.Object) day14);
//        int int16 = day14.getMonth();
//        java.lang.String str17 = day14.toString();
//        java.lang.Class<?> wildcardClass18 = day14.getClass();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries(comparable0, "ERROR : Relative To String", "Mon Jun 10 11:59:22 PDT 2019", (java.lang.Class) wildcardClass18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass18);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:59:06 PDT 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date35 = fixedMillisecond34.getEnd();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
        boolean boolean38 = spreadsheetDate16.isAfter(serialDate36);
        java.lang.String str39 = spreadsheetDate16.getDescription();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str39);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 2958465, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
//        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
//        int int13 = day11.getMonth();
//        java.lang.String str14 = day11.toString();
//        long long15 = day11.getFirstMillisecond();
//        java.util.Calendar calendar16 = null;
//        try {
//            day11.peg(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560150000000L + "'", long15 == 1560150000000L);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.lang.Class class9 = timeSeries4.getTimePeriodClass();
        java.util.Collection collection10 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(collection10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        java.util.Date date28 = month23.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1554102000000L + "'", long31 == 1554102000000L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.Object obj34 = null;
        boolean boolean35 = spreadsheetDate16.equals(obj34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.util.Calendar calendar37 = null;
        try {
            day36.peg(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        timeSeries4.setDescription("6-January-1900");
        timeSeries4.setMaximumItemAge((long) (short) 100);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(31, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar20 = null;
        fixedMillisecond19.peg(calendar20);
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries18.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener29);
        java.lang.Object obj31 = timeSeries18.clone();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date21 = fixedMillisecond20.getEnd();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        int int24 = day23.getMonth();
        boolean boolean25 = spreadsheetDate19.equals((java.lang.Object) day23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        serialDate28.setDescription("ERROR : Relative To String");
        java.lang.String str31 = serialDate28.getDescription();
        boolean boolean32 = spreadsheetDate19.isOnOrBefore(serialDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date36 = fixedMillisecond35.getEnd();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        int int39 = day38.getMonth();
        boolean boolean40 = spreadsheetDate34.equals((java.lang.Object) day38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date42 = fixedMillisecond41.getEnd();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
        serialDate43.setDescription("ERROR : Relative To String");
        java.lang.String str46 = serialDate43.getDescription();
        boolean boolean47 = spreadsheetDate34.isOnOrBefore(serialDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean50 = spreadsheetDate34.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean51 = spreadsheetDate19.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean52 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date61 = fixedMillisecond60.getEnd();
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(date61);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(serialDate62);
        int int64 = day63.getMonth();
        boolean boolean65 = spreadsheetDate59.equals((java.lang.Object) day63);
        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date67 = fixedMillisecond66.getEnd();
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance(date67);
        serialDate68.setDescription("ERROR : Relative To String");
        java.lang.String str71 = serialDate68.getDescription();
        boolean boolean72 = spreadsheetDate59.isOnOrBefore(serialDate68);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean75 = spreadsheetDate59.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate74);
        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date77 = fixedMillisecond76.getEnd();
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance(date77);
        serialDate78.setDescription("ERROR : Relative To String");
        java.lang.String str81 = serialDate78.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date84 = fixedMillisecond83.getEnd();
        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.createInstance(date84);
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(serialDate85);
        org.jfree.data.time.SerialDate serialDate87 = org.jfree.data.time.SerialDate.addMonths(8, serialDate85);
        org.jfree.data.time.SerialDate serialDate89 = serialDate85.getFollowingDayOfWeek(1);
        boolean boolean90 = spreadsheetDate74.isInRange(serialDate78, serialDate85);
        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.addMonths(6, (org.jfree.data.time.SerialDate) spreadsheetDate74);
        boolean boolean92 = spreadsheetDate54.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate56, (org.jfree.data.time.SerialDate) spreadsheetDate74);
        boolean boolean93 = spreadsheetDate34.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        try {
            org.jfree.data.time.SerialDate serialDate95 = spreadsheetDate34.getFollowingDayOfWeek(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ERROR : Relative To String" + "'", str31.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ERROR : Relative To String" + "'", str46.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "ERROR : Relative To String" + "'", str71.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "ERROR : Relative To String" + "'", str81.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertNotNull(serialDate89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(serialDate91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar1 = null;
        fixedMillisecond0.peg(calendar1);
        java.util.Calendar calendar3 = null;
        fixedMillisecond0.peg(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
//        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
//        int int13 = day11.getMonth();
//        java.lang.String str14 = day11.toString();
//        java.lang.Class<?> wildcardClass15 = day11.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getEnd();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date17);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar26 = null;
//        fixedMillisecond25.peg(calendar26);
//        java.lang.Number number28 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        java.util.Date date29 = fixedMillisecond25.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date29);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date33 = fixedMillisecond32.getEnd();
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date36 = fixedMillisecond35.getEnd();
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date36, timeZone38);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date33, timeZone38);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date29, timeZone38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date17, timeZone38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date17);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Third");
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, year1);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
        java.lang.Class<?> wildcardClass8 = timeZone6.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date2, timeZone6);
        java.util.Calendar calendar10 = null;
        try {
            year9.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
        long long13 = year9.getFirstMillisecond();
        long long14 = year9.getFirstMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            year9.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.Object obj34 = null;
        boolean boolean35 = spreadsheetDate16.equals(obj34);
        try {
            org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate16.getNearestDayOfWeek(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        int int6 = day5.getMonth();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        serialDate10.setDescription("ERROR : Relative To String");
//        java.lang.String str13 = serialDate10.getDescription();
//        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date19 = fixedMillisecond18.getEnd();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
//        serialDate20.setDescription("ERROR : Relative To String");
//        java.lang.String str23 = serialDate20.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getEnd();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(8, serialDate27);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate27.getFollowingDayOfWeek(1);
//        boolean boolean32 = spreadsheetDate16.isInRange(serialDate20, serialDate27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getEnd();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(8, serialDate36);
//        org.jfree.data.time.SerialDate serialDate40 = serialDate36.getFollowingDayOfWeek(1);
//        int int41 = spreadsheetDate16.compareTo((java.lang.Object) serialDate36);
//        java.util.Date date42 = spreadsheetDate16.toDate();
//        int int43 = spreadsheetDate16.getYYYY();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ERROR : Relative To String" + "'", str23.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-43619) + "'", int41 == (-43619));
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1900 + "'", int43 == 1900);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class16);
        java.lang.String str18 = timeSeries17.getDescription();
        boolean boolean19 = month12.equals((java.lang.Object) str18);
        long long20 = month12.getLastMillisecond();
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1556693999999L + "'", long20 == 1556693999999L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        java.util.Date date28 = month23.getStart();
        long long29 = month23.getLastMillisecond();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1556693999999L + "'", long29 == 1556693999999L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date21 = fixedMillisecond20.getEnd();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        int int24 = day23.getMonth();
        boolean boolean25 = spreadsheetDate19.equals((java.lang.Object) day23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        serialDate28.setDescription("ERROR : Relative To String");
        java.lang.String str31 = serialDate28.getDescription();
        boolean boolean32 = spreadsheetDate19.isOnOrBefore(serialDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date36 = fixedMillisecond35.getEnd();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        int int39 = day38.getMonth();
        boolean boolean40 = spreadsheetDate34.equals((java.lang.Object) day38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date42 = fixedMillisecond41.getEnd();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
        serialDate43.setDescription("ERROR : Relative To String");
        java.lang.String str46 = serialDate43.getDescription();
        boolean boolean47 = spreadsheetDate34.isOnOrBefore(serialDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean50 = spreadsheetDate34.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean51 = spreadsheetDate19.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean52 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date54 = fixedMillisecond53.getEnd();
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(date54);
        serialDate55.setDescription("ERROR : Relative To String");
        boolean boolean58 = spreadsheetDate34.isAfter(serialDate55);
        int int59 = spreadsheetDate34.getMonth();
        try {
            org.jfree.data.time.SerialDate serialDate61 = spreadsheetDate34.getNearestDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ERROR : Relative To String" + "'", str31.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ERROR : Relative To String" + "'", str46.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        int int7 = day6.getMonth();
//        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getEnd();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
//        serialDate11.setDescription("ERROR : Relative To String");
//        java.lang.String str14 = serialDate11.getDescription();
//        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean18 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date20 = fixedMillisecond19.getEnd();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
//        serialDate21.setDescription("ERROR : Relative To String");
//        java.lang.String str24 = serialDate21.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date27 = fixedMillisecond26.getEnd();
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(8, serialDate28);
//        org.jfree.data.time.SerialDate serialDate32 = serialDate28.getFollowingDayOfWeek(1);
//        boolean boolean33 = spreadsheetDate17.isInRange(serialDate21, serialDate28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date36 = fixedMillisecond35.getEnd();
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addMonths(8, serialDate37);
//        org.jfree.data.time.SerialDate serialDate41 = serialDate37.getFollowingDayOfWeek(1);
//        int int42 = spreadsheetDate17.compareTo((java.lang.Object) serialDate37);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getEnd();
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(serialDate47);
//        int int49 = day48.getMonth();
//        boolean boolean50 = spreadsheetDate44.equals((java.lang.Object) day48);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date52 = fixedMillisecond51.getEnd();
//        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(date52);
//        serialDate53.setDescription("ERROR : Relative To String");
//        java.lang.String str56 = serialDate53.getDescription();
//        boolean boolean57 = spreadsheetDate44.isOnOrBefore(serialDate53);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date61 = fixedMillisecond60.getEnd();
//        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(date61);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(serialDate62);
//        int int64 = day63.getMonth();
//        boolean boolean65 = spreadsheetDate59.equals((java.lang.Object) day63);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date67 = fixedMillisecond66.getEnd();
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance(date67);
//        serialDate68.setDescription("ERROR : Relative To String");
//        java.lang.String str71 = serialDate68.getDescription();
//        boolean boolean72 = spreadsheetDate59.isOnOrBefore(serialDate68);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean75 = spreadsheetDate59.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate74);
//        boolean boolean76 = spreadsheetDate44.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate59);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date78 = fixedMillisecond77.getEnd();
//        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.createInstance(date78);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(serialDate79);
//        boolean boolean81 = spreadsheetDate59.isAfter(serialDate79);
//        int int82 = spreadsheetDate59.getDayOfMonth();
//        boolean boolean83 = spreadsheetDate17.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate59);
//        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate59);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ERROR : Relative To String" + "'", str24.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-43619) + "'", int42 == (-43619));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "ERROR : Relative To String" + "'", str56.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "ERROR : Relative To String" + "'", str71.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNotNull(serialDate79);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 6 + "'", int82 == 6);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
//        org.junit.Assert.assertNotNull(serialDate84);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        int int11 = day10.getMonth();
        boolean boolean12 = spreadsheetDate6.equals((java.lang.Object) day10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        serialDate15.setDescription("ERROR : Relative To String");
        java.lang.String str18 = serialDate15.getDescription();
        boolean boolean19 = spreadsheetDate6.isOnOrBefore(serialDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean22 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date31 = fixedMillisecond30.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(serialDate32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths(8, serialDate32);
        org.jfree.data.time.SerialDate serialDate36 = serialDate32.getFollowingDayOfWeek(1);
        boolean boolean37 = spreadsheetDate21.isInRange(serialDate25, serialDate32);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(6, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean39 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int40 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ERROR : Relative To String" + "'", str18.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(4, 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(4, year17);
        java.lang.Number number21 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, number21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = null;
        try {
            timeSeries4.delete(regularTimePeriod23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        serialDate11.setDescription("ERROR : Relative To String");
        java.lang.String str14 = serialDate11.getDescription();
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date19 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        int int22 = day21.getMonth();
        boolean boolean23 = spreadsheetDate17.equals((java.lang.Object) day21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date25 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        serialDate26.setDescription("ERROR : Relative To String");
        java.lang.String str29 = serialDate26.getDescription();
        boolean boolean30 = spreadsheetDate17.isOnOrBefore(serialDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean33 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean34 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.Object obj35 = null;
        boolean boolean36 = spreadsheetDate17.equals(obj35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        try {
            org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ERROR : Relative To String" + "'", str29.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener7);
        timeSeries4.clear();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        int int6 = day5.getMonth();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        serialDate10.setDescription("ERROR : Relative To String");
//        java.lang.String str13 = serialDate10.getDescription();
//        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date19 = fixedMillisecond18.getEnd();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
//        serialDate20.setDescription("ERROR : Relative To String");
//        java.lang.String str23 = serialDate20.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getEnd();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(8, serialDate27);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate27.getFollowingDayOfWeek(1);
//        boolean boolean32 = spreadsheetDate16.isInRange(serialDate20, serialDate27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getEnd();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(8, serialDate36);
//        org.jfree.data.time.SerialDate serialDate40 = serialDate36.getFollowingDayOfWeek(1);
//        int int41 = spreadsheetDate16.compareTo((java.lang.Object) serialDate36);
//        java.util.Date date42 = spreadsheetDate16.toDate();
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
//        java.lang.String str44 = year43.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year43.previous();
//        java.util.Calendar calendar46 = null;
//        try {
//            long long47 = year43.getFirstMillisecond(calendar46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ERROR : Relative To String" + "'", str23.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-43619) + "'", int41 == (-43619));
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1900" + "'", str44.equals("1900"));
//        org.junit.Assert.assertNull(regularTimePeriod45);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate2 = null;
        try {
            boolean boolean3 = spreadsheetDate1.isOn(serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:59:06 PDT 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:59:06 PDT 2019");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException9);
        seriesException3.addSuppressed((java.lang.Throwable) seriesException9);
        java.lang.Throwable[] throwableArray12 = seriesException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019" + "'", str5.equals("org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019"));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        timeSeries4.setDescription("6-January-1900");
        org.jfree.data.time.TimeSeries timeSeries7 = null;
        try {
            java.util.Collection collection8 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(8, serialDate5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate5);
        boolean boolean9 = spreadsheetDate1.isAfter(serialDate5);
        java.lang.String str10 = serialDate5.getDescription();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.util.Date date9 = fixedMillisecond5.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        long long12 = month11.getFirstMillisecond();
        java.util.Date date13 = month11.getEnd();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar20 = null;
        fixedMillisecond19.peg(calendar20);
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries18.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
        timeSeries28.setDescription("ERROR : Relative To String");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries28.removeChangeListener(seriesChangeListener31);
        java.util.List list33 = timeSeries28.getItems();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        try {
            timeSeries28.update((org.jfree.data.time.RegularTimePeriod) day34, (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(list33);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year1.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        int int6 = day5.getMonth();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        serialDate10.setDescription("ERROR : Relative To String");
//        java.lang.String str13 = serialDate10.getDescription();
//        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getEnd();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
//        int int21 = day20.getMonth();
//        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date24 = fixedMillisecond23.getEnd();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
//        serialDate25.setDescription("ERROR : Relative To String");
//        java.lang.String str28 = serialDate25.getDescription();
//        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        java.lang.Object obj34 = null;
//        boolean boolean35 = spreadsheetDate16.equals(obj34);
//        java.lang.String str36 = spreadsheetDate16.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date39 = fixedMillisecond38.getEnd();
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date39);
//        serialDate40.setDescription("ERROR : Relative To String");
//        java.lang.String str43 = serialDate40.getDescription();
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(11, serialDate40);
//        boolean boolean45 = spreadsheetDate16.isAfter(serialDate40);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date47 = fixedMillisecond46.getEnd();
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
//        serialDate48.setDescription("ERROR : Relative To String");
//        java.lang.String str51 = serialDate48.toString();
//        int int52 = spreadsheetDate16.compare(serialDate48);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "6-January-1900" + "'", str36.equals("6-January-1900"));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "ERROR : Relative To String" + "'", str43.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "10-June-2019" + "'", str51.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-43619) + "'", int52 == (-43619));
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        long long28 = month23.getLastMillisecond();
        long long29 = month23.getLastMillisecond();
        int int30 = month23.getYearValue();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1556693999999L + "'", long28 == 1556693999999L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1556693999999L + "'", long29 == 1556693999999L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(8, serialDate4);
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Mon Jun 10 11:59:08 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        long long9 = year8.getFirstMillisecond();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        fixedMillisecond16.peg(calendar17);
//        java.lang.Number number19 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
//        timeSeries15.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries15.createCopy((int) (short) 1, 8);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond30.peg(calendar31);
//        java.lang.Number number33 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        timeSeries29.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries29.createCopy((int) (short) 1, 8);
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries15.addAndOrUpdate(timeSeries29);
//        java.lang.Object obj40 = timeSeries39.clone();
//        timeSeries39.setMaximumItemCount(0);
//        boolean boolean43 = timeSeries4.equals((java.lang.Object) 0);
//        java.lang.Class class48 = null;
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class48);
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries49.createCopy(4, 100);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
//        long long54 = year53.getFirstMillisecond();
//        timeSeries49.delete((org.jfree.data.time.RegularTimePeriod) year53);
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(4, year53);
//        java.lang.Object obj57 = null;
//        int int58 = month56.compareTo(obj57);
//        java.lang.Class class62 = null;
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class62);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar65 = null;
//        fixedMillisecond64.peg(calendar65);
//        java.lang.Number number67 = timeSeries63.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64);
//        java.util.Date date68 = fixedMillisecond64.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond(date68);
//        long long70 = fixedMillisecond69.getMiddleMillisecond();
//        int int71 = month56.compareTo((java.lang.Object) fixedMillisecond69);
//        java.lang.Class class75 = null;
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class75);
//        int int77 = timeSeries76.getItemCount();
//        timeSeries76.setNotify(true);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = day80.next();
//        java.lang.Number number82 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem83 = timeSeries76.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day80, number82);
//        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) month56, (org.jfree.data.time.RegularTimePeriod) day80);
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNull(number33);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertNotNull(obj40);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1546329600000L + "'", long54 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNull(number67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560193189603L + "'", long70 == 1560193189603L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertNull(timeSeriesDataItem83);
//        org.junit.Assert.assertNotNull(timeSeries84);
//    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getEnd();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
//        int int13 = day12.getMonth();
//        boolean boolean14 = spreadsheetDate8.equals((java.lang.Object) day12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getEnd();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
//        serialDate17.setDescription("ERROR : Relative To String");
//        java.lang.String str20 = serialDate17.getDescription();
//        boolean boolean21 = spreadsheetDate8.isOnOrBefore(serialDate17);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getEnd();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate26);
//        int int28 = day27.getMonth();
//        boolean boolean29 = spreadsheetDate23.equals((java.lang.Object) day27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date31 = fixedMillisecond30.getEnd();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
//        serialDate32.setDescription("ERROR : Relative To String");
//        java.lang.String str35 = serialDate32.getDescription();
//        boolean boolean36 = spreadsheetDate23.isOnOrBefore(serialDate32);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean39 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        boolean boolean40 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date42 = fixedMillisecond41.getEnd();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate43);
//        boolean boolean45 = spreadsheetDate23.isAfter(serialDate43);
//        boolean boolean46 = timeSeriesDataItem6.equals((java.lang.Object) serialDate43);
//        java.lang.Class class50 = null;
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class50);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar53 = null;
//        fixedMillisecond52.peg(calendar53);
//        java.lang.Number number55 = timeSeries51.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
//        timeSeries51.setMaximumItemCount(1900);
//        int int58 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries51);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = timeSeries51.getTimePeriod(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193190024L + "'", long3 == 1560193190024L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193190024L + "'", long4 == 1560193190024L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ERROR : Relative To String" + "'", str20.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ERROR : Relative To String" + "'", str35.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNull(number55);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        timeSeries4.setDescription("6-January-1900");
        timeSeries4.setRangeDescription("10-June-2019");
        try {
            java.lang.Number number10 = timeSeries4.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        java.lang.String str10 = month8.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(4, 100);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(4, year17);
        java.lang.Number number21 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, number21);
        java.util.Calendar calendar23 = null;
        try {
            year17.peg(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond6.peg(calendar7);
//        java.lang.Number number9 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        timeSeries5.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((int) (short) 1, 8);
//        timeSeries14.setMaximumItemCount(7);
//        boolean boolean17 = fixedMillisecond0.equals((java.lang.Object) 7);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date20 = fixedMillisecond19.getEnd();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date23 = fixedMillisecond22.getEnd();
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date20, timeZone25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar29 = null;
//        fixedMillisecond28.peg(calendar29);
//        long long31 = fixedMillisecond28.getMiddleMillisecond();
//        long long32 = fixedMillisecond28.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, 0.0d);
//        int int35 = month27.compareTo((java.lang.Object) timeSeriesDataItem34);
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) month27);
//        org.junit.Assert.assertNull(number9);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560193190706L + "'", long31 == 1560193190706L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560193190706L + "'", long32 == 1560193190706L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, year1);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar11 = null;
        fixedMillisecond10.peg(calendar11);
        java.lang.Number number13 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        timeSeries9.setRangeDescription("hi!");
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class19);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(4, 100);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries20.createCopy((int) 'a', (int) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries9.addAndOrUpdate(timeSeries26);
        int int28 = year1.compareTo((java.lang.Object) timeSeries27);
        java.util.Calendar calendar29 = null;
        try {
            long long30 = year1.getFirstMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) '4', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        int int6 = day5.getMonth();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        serialDate10.setDescription("ERROR : Relative To String");
//        java.lang.String str13 = serialDate10.getDescription();
//        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date19 = fixedMillisecond18.getEnd();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
//        serialDate20.setDescription("ERROR : Relative To String");
//        java.lang.String str23 = serialDate20.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getEnd();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(8, serialDate27);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate27.getFollowingDayOfWeek(1);
//        boolean boolean32 = spreadsheetDate16.isInRange(serialDate20, serialDate27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getEnd();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(8, serialDate36);
//        org.jfree.data.time.SerialDate serialDate40 = serialDate36.getFollowingDayOfWeek(1);
//        int int41 = spreadsheetDate16.compareTo((java.lang.Object) serialDate36);
//        java.util.Date date42 = spreadsheetDate16.toDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate16.getFollowingDayOfWeek((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ERROR : Relative To String" + "'", str23.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-43619) + "'", int41 == (-43619));
//        org.junit.Assert.assertNotNull(date42);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        int int13 = day11.getMonth();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class17);
        boolean boolean19 = timeSeries18.isEmpty();
        boolean boolean20 = day11.equals((java.lang.Object) timeSeries18);
        timeSeries18.setRangeDescription("10-June-2019");
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class18);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries19.createCopy(4, 100);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class30);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries31.createCopy(4, 100);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getFirstMillisecond();
        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) year35);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(4, year35);
        java.lang.Object obj39 = null;
        int int40 = month38.compareTo(obj39);
        int int41 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) month38);
        java.util.Collection collection42 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        long long44 = year43.getFirstMillisecond();
        int int45 = year43.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (double) 1560193159487L);
        java.lang.Number number48 = timeSeriesDataItem47.getValue();
        try {
            timeSeries13.add(timeSeriesDataItem47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1546329600000L + "'", long44 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 1.560193159487E12d + "'", number48.equals(1.560193159487E12d));
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
//        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
//        int int13 = day11.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        int int16 = day11.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date19 = fixedMillisecond18.getEnd();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(8, serialDate20);
//        boolean boolean23 = day11.equals((java.lang.Object) serialDate22);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: 6-January-1900");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10, timeZone12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day13);
        boolean boolean15 = timeSeries4.getNotify();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.getDataItem(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        int int13 = day11.getMonth();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class17);
        boolean boolean19 = timeSeries18.isEmpty();
        boolean boolean20 = day11.equals((java.lang.Object) timeSeries18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 2019);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) strArray0);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date35 = fixedMillisecond34.getEnd();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
        boolean boolean38 = spreadsheetDate16.isAfter(serialDate36);
        int int39 = spreadsheetDate16.getMonth();
        java.lang.Object obj40 = null;
        try {
            int int41 = spreadsheetDate16.compareTo(obj40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar7 = null;
        fixedMillisecond6.peg(calendar7);
        java.lang.Number number9 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        timeSeries5.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((int) (short) 1, 8);
        timeSeries14.setMaximumItemCount(7);
        boolean boolean17 = fixedMillisecond0.equals((java.lang.Object) 7);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ERROR : Relative To String");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(8, 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
        java.lang.Object obj13 = null;
        int int14 = month12.compareTo(obj13);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class19);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(4, 100);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getFirstMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) year24);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(4, year24);
        java.lang.Object obj28 = null;
        int int29 = month27.compareTo(obj28);
        long long30 = month27.getSerialIndex();
        int int31 = month12.compareTo((java.lang.Object) month27);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24232L + "'", long30 == 24232L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-43619));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10, (-43619), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries4.getTimePeriod(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar20 = null;
        fixedMillisecond19.peg(calendar20);
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries18.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
        java.lang.Comparable comparable29 = timeSeries28.getKey();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = null;
        try {
            timeSeries28.add(regularTimePeriod30, (java.lang.Number) 1560193177903L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + "Overwritten values from: " + "'", comparable29.equals("Overwritten values from: "));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        int int3 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.next();
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.removeChangeListener(seriesChangeListener7);
        timeSeries4.removeAgedItems(false);
        java.lang.Class class11 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date15 = fixedMillisecond14.getEnd();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        int int18 = day17.getMonth();
        boolean boolean19 = spreadsheetDate13.equals((java.lang.Object) day17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.next();
        java.util.Date date21 = day17.getStart();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day17);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(class11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond19.peg(calendar20);
//        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries18.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
//        timeSeries28.setDescription("ERROR : Relative To String");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries28.removeChangeListener(seriesChangeListener31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date34 = fixedMillisecond33.getEnd();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getEnd();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date37);
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date37, timeZone39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date34, timeZone39);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar43 = null;
//        fixedMillisecond42.peg(calendar43);
//        long long45 = fixedMillisecond42.getMiddleMillisecond();
//        long long46 = fixedMillisecond42.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, 0.0d);
//        int int49 = month41.compareTo((java.lang.Object) timeSeriesDataItem48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month41.next();
//        int int51 = month41.getYearValue();
//        java.lang.Number number52 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month41);
//        int int53 = timeSeries28.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = fixedMillisecond54.next();
//        try {
//            timeSeries28.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (java.lang.Number) 1560193188734L, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560193193203L + "'", long45 == 1560193193203L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560193193203L + "'", long46 == 1560193193203L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1560193159487L);
        int int5 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) 10.0f);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class10);
        boolean boolean12 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        long long15 = fixedMillisecond14.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries4.addAndOrUpdate(timeSeries11);
        java.lang.Object obj19 = timeSeries11.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(1900, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
//        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
//        int int13 = day11.getYear();
//        int int14 = day11.getYear();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        fixedMillisecond20.peg(calendar21);
//        java.lang.Number number23 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        java.lang.String str24 = fixedMillisecond20.toString();
//        long long25 = fixedMillisecond20.getFirstMillisecond();
//        java.lang.Number number26 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, number26);
//        int int28 = day11.compareTo((java.lang.Object) timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Mon Jun 10 11:59:54 PDT 2019" + "'", str24.equals("Mon Jun 10 11:59:54 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560193194819L + "'", long25 == 1560193194819L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException5);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        timeSeries4.setDescription("6-January-1900");
        timeSeries4.setRangeDescription("10-June-2019");
        java.util.List list9 = timeSeries4.getItems();
        try {
            timeSeries4.setMaximumItemAge((-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getEnd();
//        long long3 = fixedMillisecond1.getMiddleMillisecond();
//        long long4 = fixedMillisecond1.getFirstMillisecond();
//        boolean boolean5 = year0.equals((java.lang.Object) long4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
//        int int7 = year0.getYear();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193194915L + "'", long3 == 1560193194915L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193194915L + "'", long4 == 1560193194915L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        timeSeries4.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getEnd();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
        int int10 = day9.getMonth();
        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day9.next();
        boolean boolean13 = timeSeries4.equals((java.lang.Object) day9);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "February");
        try {
            timeSeries1.update(100, (java.lang.Number) 1560193192373L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560193150522L, class1);
//        java.lang.Comparable comparable3 = timeSeries2.getKey();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class7);
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12, timeZone14);
//        boolean boolean16 = timeSeries8.equals((java.lang.Object) day15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        fixedMillisecond24.peg(calendar25);
//        java.lang.Number number27 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.String str28 = fixedMillisecond24.toString();
//        long long29 = fixedMillisecond24.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        try {
//            java.lang.Number number32 = timeSeries2.getValue(9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 1560193150522L + "'", comparable3.equals(1560193150522L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Mon Jun 10 11:59:55 PDT 2019" + "'", str28.equals("Mon Jun 10 11:59:55 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560193195413L + "'", long29 == 1560193195413L);
//        org.junit.Assert.assertNotNull(timeSeries30);
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193195431L + "'", long3 == 1560193195431L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560193195431L + "'", long5 == 1560193195431L);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        try {
            timeSeries4.update(regularTimePeriod8, (java.lang.Number) 1560193178205L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Nearest");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:59:06 PDT 2019");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException5);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        long long5 = timeSeries4.getMaximumItemAge();
//        timeSeries4.clear();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class10);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries11.addPropertyChangeListener(propertyChangeListener12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getEnd();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15, timeZone17);
//        boolean boolean19 = timeSeries11.equals((java.lang.Object) day18);
//        int int20 = day18.getMonth();
//        java.lang.String str21 = day18.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
//        int int23 = day18.getMonth();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10-June-2019" + "'", str21.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        int int4 = day3.getMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getEnd();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths(8, serialDate8);
//        boolean boolean11 = day3.equals((java.lang.Object) 8);
//        java.lang.String str12 = day3.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day3.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        int int5 = timeSeries4.getItemCount();
        timeSeries4.setNotify(true);
        long long8 = timeSeries4.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        long long2 = fixedMillisecond1.getLastMillisecond();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        long long7 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond8.peg(calendar9);
//        long long11 = fixedMillisecond8.getMiddleMillisecond();
//        long long12 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, 0.0d);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class18);
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries19.createCopy(4, 100);
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries19.createCopy((int) 'a', (int) (short) 100);
//        boolean boolean26 = timeSeriesDataItem14.equals((java.lang.Object) 'a');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.next();
//        int int29 = timeSeriesDataItem14.compareTo((java.lang.Object) regularTimePeriod28);
//        timeSeriesDataItem14.setValue((java.lang.Number) 9223372036854775807L);
//        int int32 = fixedMillisecond0.compareTo((java.lang.Object) 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193196770L + "'", long3 == 1560193196770L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193196770L + "'", long4 == 1560193196770L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560193196770L + "'", long6 == 1560193196770L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560193196770L + "'", long7 == 1560193196770L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560193196771L + "'", long11 == 1560193196771L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560193196771L + "'", long12 == 1560193196771L);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
//        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
//        int int13 = day11.getMonth();
//        java.lang.String str14 = day11.toString();
//        long long15 = day11.getFirstMillisecond();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = day11.getLastMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560150000000L + "'", long15 == 1560150000000L);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
//        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
//        int int13 = day11.getYear();
//        long long14 = day11.getSerialIndex();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long14);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43626L + "'", long14 == 43626L);
//    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        int int6 = day5.getMonth();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        java.util.Date date9 = day5.getStart();
//        org.jfree.data.time.SerialDate serialDate10 = day5.getSerialDate();
//        java.lang.String str11 = day5.toString();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 8);
        long long3 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560193150522L, class1);
//        java.lang.Comparable comparable3 = timeSeries2.getKey();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class7);
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12, timeZone14);
//        boolean boolean16 = timeSeries8.equals((java.lang.Object) day15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        fixedMillisecond24.peg(calendar25);
//        java.lang.Number number27 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.String str28 = fixedMillisecond24.toString();
//        long long29 = fixedMillisecond24.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries30.removeChangeListener(seriesChangeListener31);
//        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 1560193150522L + "'", comparable3.equals(1560193150522L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Mon Jun 10 11:59:57 PDT 2019" + "'", str28.equals("Mon Jun 10 11:59:57 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560193197215L + "'", long29 == 1560193197215L);
//        org.junit.Assert.assertNotNull(timeSeries30);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar20 = null;
        fixedMillisecond19.peg(calendar20);
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries18.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
        timeSeries28.setDescription("ERROR : Relative To String");
        boolean boolean31 = timeSeries28.isEmpty();
        java.lang.Object obj32 = timeSeries28.clone();
        java.lang.String str33 = timeSeries28.getRangeDescription();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Value" + "'", str33.equals("Value"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setMaximumItemCount(1900);
        timeSeries4.setMaximumItemCount(1900);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            month0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        long long28 = month23.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month23.next();
        long long30 = month23.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month23.next();
        org.jfree.data.time.Year year32 = month23.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1556693999999L + "'", long28 == 1556693999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24232L + "'", long30 == 24232L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        serialDate11.setDescription("ERROR : Relative To String");
        java.lang.String str14 = serialDate11.getDescription();
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date23 = fixedMillisecond22.getEnd();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        int int26 = day25.getMonth();
        boolean boolean27 = spreadsheetDate21.equals((java.lang.Object) day25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date29 = fixedMillisecond28.getEnd();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        serialDate30.setDescription("ERROR : Relative To String");
        java.lang.String str33 = serialDate30.getDescription();
        boolean boolean34 = spreadsheetDate21.isOnOrBefore(serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean37 = spreadsheetDate21.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date39 = fixedMillisecond38.getEnd();
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date39);
        serialDate40.setDescription("ERROR : Relative To String");
        java.lang.String str43 = serialDate40.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date46 = fixedMillisecond45.getEnd();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(serialDate47);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addMonths(8, serialDate47);
        org.jfree.data.time.SerialDate serialDate51 = serialDate47.getFollowingDayOfWeek(1);
        boolean boolean52 = spreadsheetDate36.isInRange(serialDate40, serialDate47);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addMonths(6, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean54 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays(7, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ERROR : Relative To String" + "'", str33.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "ERROR : Relative To String" + "'", str43.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(serialDate55);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
        java.lang.Class<?> wildcardClass8 = timeZone6.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date2, timeZone6);
        long long10 = year9.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1969L + "'", long10 == 1969L);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setMaximumItemCount(1900);
//        timeSeries4.setDescription("");
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        fixedMillisecond18.peg(calendar19);
//        java.lang.Number number21 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
//        timeSeries17.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries17.createCopy((int) (short) 1, 8);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        fixedMillisecond32.peg(calendar33);
//        java.lang.Number number35 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        timeSeries31.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries31.createCopy((int) (short) 1, 8);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries17.addAndOrUpdate(timeSeries31);
//        timeSeries41.setDescription("ERROR : Relative To String");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries41.removeChangeListener(seriesChangeListener44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date47 = fixedMillisecond46.getEnd();
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date50 = fixedMillisecond49.getEnd();
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(date50);
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date50, timeZone52);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date47, timeZone52);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar56 = null;
//        fixedMillisecond55.peg(calendar56);
//        long long58 = fixedMillisecond55.getMiddleMillisecond();
//        long long59 = fixedMillisecond55.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, 0.0d);
//        int int62 = month54.compareTo((java.lang.Object) timeSeriesDataItem61);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month54.next();
//        int int64 = month54.getYearValue();
//        java.lang.Number number65 = timeSeries41.getValue((org.jfree.data.time.RegularTimePeriod) month54);
//        timeSeries41.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
//        long long69 = fixedMillisecond68.getLastMillisecond();
//        long long70 = fixedMillisecond68.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (java.lang.Number) 1560193146505L);
//        long long75 = fixedMillisecond68.getLastMillisecond();
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560193198940L + "'", long58 == 1560193198940L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560193198940L + "'", long59 == 1560193198940L);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2019 + "'", int64 == 2019);
//        org.junit.Assert.assertNull(number65);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 10L + "'", long69 == 10L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 10L + "'", long70 == 10L);
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNull(timeSeriesDataItem74);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 10L + "'", long75 == 10L);
//    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond9.peg(calendar10);
//        long long12 = fixedMillisecond9.getMiddleMillisecond();
//        long long13 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        int int16 = month8.compareTo((java.lang.Object) timeSeriesDataItem15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month8.next();
//        int int18 = month8.getYearValue();
//        long long19 = month8.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560193199171L + "'", long12 == 1560193199171L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560193199171L + "'", long13 == 1560193199171L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 24234L + "'", long19 == 24234L);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries15.createCopy(4, 100);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries15.createCopy((int) 'a', (int) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.addAndOrUpdate(timeSeries21);
        try {
            timeSeries21.delete((int) '4', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(timeSeries22);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        timeSeries4.setDescription("6-January-1900");
        try {
            timeSeries4.delete(3, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        long long28 = month23.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month23.next();
        long long30 = month23.getSerialIndex();
        java.util.Calendar calendar31 = null;
        try {
            long long32 = month23.getLastMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1556693999999L + "'", long28 == 1556693999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24232L + "'", long30 == 24232L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int34 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date39 = fixedMillisecond38.getEnd();
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate40);
        int int42 = day41.getMonth();
        boolean boolean43 = spreadsheetDate37.equals((java.lang.Object) day41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date45 = fixedMillisecond44.getEnd();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
        serialDate46.setDescription("ERROR : Relative To String");
        java.lang.String str49 = serialDate46.getDescription();
        boolean boolean50 = spreadsheetDate37.isOnOrBefore(serialDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean53 = spreadsheetDate37.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date55 = fixedMillisecond54.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        serialDate56.setDescription("ERROR : Relative To String");
        java.lang.String str59 = serialDate56.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date62 = fixedMillisecond61.getEnd();
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance(date62);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(serialDate63);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addMonths(8, serialDate63);
        org.jfree.data.time.SerialDate serialDate67 = serialDate63.getFollowingDayOfWeek(1);
        boolean boolean68 = spreadsheetDate52.isInRange(serialDate56, serialDate63);
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate63);
        org.jfree.data.time.SerialDate serialDate71 = serialDate63.getFollowingDayOfWeek(4);
        boolean boolean72 = spreadsheetDate1.isOn(serialDate71);
        org.jfree.data.time.SerialDate serialDate73 = null;
        try {
            boolean boolean74 = spreadsheetDate1.isOnOrBefore(serialDate73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "ERROR : Relative To String" + "'", str49.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "ERROR : Relative To String" + "'", str59.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getEnd();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9, timeZone11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date6, timeZone11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = regularTimePeriod16.getMiddleMillisecond();
//        java.lang.String str18 = regularTimePeriod16.toString();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) month13, regularTimePeriod16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        fixedMillisecond20.peg(calendar21);
//        long long23 = fixedMillisecond20.getMiddleMillisecond();
//        long long24 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, 0.0d);
//        try {
//            timeSeries19.add(timeSeriesDataItem26, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560279599999L + "'", long17 == 1560279599999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "11-June-2019" + "'", str18.equals("11-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560193199519L + "'", long23 == 1560193199519L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560193199519L + "'", long24 == 1560193199519L);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        timeSeries4.setDescription("6-January-1900");
        java.lang.Class<?> wildcardClass7 = timeSeries4.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class16);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy(4, 100);
        java.util.Collection collection21 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries4.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(collection21);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class18);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries19.createCopy(4, 100);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class30);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries31.createCopy(4, 100);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getFirstMillisecond();
        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) year35);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(4, year35);
        java.lang.Object obj39 = null;
        int int40 = month38.compareTo(obj39);
        int int41 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) month38);
        java.util.Collection collection42 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date45 = fixedMillisecond44.getEnd();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate46);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addMonths(8, serialDate46);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(serialDate46);
        try {
            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) day49, (java.lang.Number) 1969L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate48);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        java.lang.Class class15 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getEnd();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date17, timeZone19);
        boolean boolean21 = day11.equals((java.lang.Object) class15);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = day11.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193200034L + "'", long3 == 1560193200034L);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Mon Jun 10 11:59:54 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 'a');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        long long28 = month23.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month23.previous();
        java.lang.Number number30 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, number30);
        java.util.Calendar calendar32 = null;
        try {
            long long33 = month23.getMiddleMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1554102000000L + "'", long28 == 1554102000000L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.lang.Object obj9 = timeSeries4.clone();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        int int5 = timeSeries4.getItemCount();
        timeSeries4.setNotify(true);
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy(11, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        long long5 = timeSeries4.getMaximumItemAge();
//        timeSeries4.clear();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class10);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries11.addPropertyChangeListener(propertyChangeListener12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getEnd();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15, timeZone17);
//        boolean boolean19 = timeSeries11.equals((java.lang.Object) day18);
//        int int20 = day18.getMonth();
//        java.lang.String str21 = day18.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
//        java.util.Calendar calendar23 = null;
//        try {
//            long long24 = day18.getLastMillisecond(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10-June-2019" + "'", str21.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
        java.lang.String str13 = year9.toString();
        int int14 = year9.getYear();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year9.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
//        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
//        int int13 = day11.getMonth();
//        java.lang.String str14 = day11.toString();
//        org.jfree.data.time.SerialDate serialDate15 = day11.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = day11.getSerialDate();
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2958465);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getNearestDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-43619), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        timeSeries13.setMaximumItemCount(7);
        boolean boolean16 = timeSeries13.isEmpty();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = null;
        try {
            timeSeries13.update(regularTimePeriod17, (java.lang.Number) 1560193146210L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
        java.util.Calendar calendar9 = null;
        try {
            day5.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate8);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond9.peg(calendar10);
//        long long12 = fixedMillisecond9.getMiddleMillisecond();
//        long long13 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        int int16 = month8.compareTo((java.lang.Object) timeSeriesDataItem15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month8.next();
//        long long18 = month8.getFirstMillisecond();
//        java.lang.Object obj19 = null;
//        int int20 = month8.compareTo(obj19);
//        java.lang.String str21 = month8.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560193200944L + "'", long12 == 1560193200944L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560193200944L + "'", long13 == 1560193200944L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
//    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
//        int int11 = day10.getMonth();
//        boolean boolean12 = spreadsheetDate6.equals((java.lang.Object) day10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getEnd();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
//        serialDate15.setDescription("ERROR : Relative To String");
//        java.lang.String str18 = serialDate15.getDescription();
//        boolean boolean19 = spreadsheetDate6.isOnOrBefore(serialDate15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean22 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date24 = fixedMillisecond23.getEnd();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
//        serialDate25.setDescription("ERROR : Relative To String");
//        java.lang.String str28 = serialDate25.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date31 = fixedMillisecond30.getEnd();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(serialDate32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths(8, serialDate32);
//        org.jfree.data.time.SerialDate serialDate36 = serialDate32.getFollowingDayOfWeek(1);
//        boolean boolean37 = spreadsheetDate21.isInRange(serialDate25, serialDate32);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(6, (org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean39 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate21);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date48 = fixedMillisecond47.getEnd();
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date48, timeZone50);
//        boolean boolean52 = timeSeries44.equals((java.lang.Object) day51);
//        int int53 = day51.getMonth();
//        java.lang.String str54 = day51.toString();
//        org.jfree.data.time.SerialDate serialDate55 = day51.getSerialDate();
//        boolean boolean56 = spreadsheetDate3.isOn(serialDate55);
//        try {
//            org.jfree.data.time.SerialDate serialDate58 = spreadsheetDate3.getNearestDayOfWeek(12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ERROR : Relative To String" + "'", str18.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10-June-2019" + "'", str54.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond19.peg(calendar20);
//        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries18.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
//        timeSeries28.setDescription("ERROR : Relative To String");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries28.removeChangeListener(seriesChangeListener31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date34 = fixedMillisecond33.getEnd();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getEnd();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date37);
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date37, timeZone39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date34, timeZone39);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar43 = null;
//        fixedMillisecond42.peg(calendar43);
//        long long45 = fixedMillisecond42.getMiddleMillisecond();
//        long long46 = fixedMillisecond42.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, 0.0d);
//        int int49 = month41.compareTo((java.lang.Object) timeSeriesDataItem48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month41.next();
//        int int51 = month41.getYearValue();
//        java.lang.Number number52 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month41);
//        timeSeries28.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
//        long long56 = fixedMillisecond55.getLastMillisecond();
//        long long57 = fixedMillisecond55.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (java.lang.Number) 0L);
//        java.util.Calendar calendar60 = null;
//        long long61 = fixedMillisecond55.getFirstMillisecond(calendar60);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560193201225L + "'", long45 == 1560193201225L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560193201225L + "'", long46 == 1560193201225L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 10L + "'", long61 == 10L);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        timeSeries4.clear();
        java.util.Collection collection6 = timeSeries4.getTimePeriods();
        try {
            timeSeries4.update((int) (byte) 100, (java.lang.Number) 1560193200790L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection6);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 11, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class16);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy(4, 100);
        java.util.Collection collection21 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        java.util.List list22 = timeSeries4.getItems();
        timeSeries4.removeAgedItems(true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.Object obj34 = null;
        boolean boolean35 = spreadsheetDate16.equals(obj34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.Object obj37 = null;
        boolean boolean38 = spreadsheetDate16.equals(obj37);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(4, 100);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getFirstMillisecond();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(4, year10);
        long long14 = year10.getFirstMillisecond();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(8, year10);
        java.util.Date date16 = year10.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, (int) (byte) 10, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        int int6 = day5.getMonth();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        java.util.Date date9 = day5.getStart();
//        org.jfree.data.time.SerialDate serialDate10 = day5.getSerialDate();
//        long long11 = day5.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class12);
        int int14 = timeSeries13.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries4.addAndOrUpdate(timeSeries13);
        boolean boolean16 = timeSeries4.isEmpty();
        java.lang.Class class17 = timeSeries4.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(class17);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class18);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries19.createCopy(4, 100);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class30);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries31.createCopy(4, 100);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getFirstMillisecond();
        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) year35);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(4, year35);
        java.lang.Object obj39 = null;
        int int40 = month38.compareTo(obj39);
        int int41 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) month38);
        java.util.Collection collection42 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        java.lang.Object obj43 = timeSeries13.clone();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertNotNull(obj43);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10, timeZone12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.next();
        java.util.Calendar calendar16 = null;
        try {
            day13.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
        boolean boolean13 = timeSeries4.equals((java.lang.Object) date10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        java.util.Date date16 = fixedMillisecond15.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date18, timeZone20);
        java.lang.Class<?> wildcardClass22 = timeZone20.getClass();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date16, timeZone20);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date10, timeZone20);
        java.util.TimeZone timeZone25 = null;
        try {
            org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date10, timeZone25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.util.Date date9 = fixedMillisecond5.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getEnd();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date16 = fixedMillisecond15.getEnd();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date13, timeZone18);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date9, timeZone18);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date9);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(timeZone18);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getEnd();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9, timeZone11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date6, timeZone11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = regularTimePeriod16.getMiddleMillisecond();
//        java.lang.String str18 = regularTimePeriod16.toString();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) month13, regularTimePeriod16);
//        try {
//            java.lang.Number number21 = timeSeries19.getValue(7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560279599999L + "'", long17 == 1560279599999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "11-June-2019" + "'", str18.equals("11-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries19);
//    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond9.peg(calendar10);
//        long long12 = fixedMillisecond9.getMiddleMillisecond();
//        long long13 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        int int16 = month8.compareTo((java.lang.Object) timeSeriesDataItem15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month8.next();
//        long long18 = month8.getFirstMillisecond();
//        java.lang.Object obj19 = null;
//        int int20 = month8.compareTo(obj19);
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = month8.getMiddleMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560193202895L + "'", long12 == 1560193202895L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560193202895L + "'", long13 == 1560193202895L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar20 = null;
        fixedMillisecond19.peg(calendar20);
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries18.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
        java.lang.Object obj29 = timeSeries28.clone();
        try {
            timeSeries28.delete(1900, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        long long2 = fixedMillisecond1.getLastMillisecond();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) 1560193150924L);
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class16);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy(4, 100);
        java.util.Collection collection21 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        java.util.List list22 = timeSeries4.getItems();
        try {
            timeSeries4.removeAgedItems((long) 2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date21 = fixedMillisecond20.getEnd();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        int int24 = day23.getMonth();
        boolean boolean25 = spreadsheetDate19.equals((java.lang.Object) day23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        serialDate28.setDescription("ERROR : Relative To String");
        java.lang.String str31 = serialDate28.getDescription();
        boolean boolean32 = spreadsheetDate19.isOnOrBefore(serialDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date36 = fixedMillisecond35.getEnd();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        int int39 = day38.getMonth();
        boolean boolean40 = spreadsheetDate34.equals((java.lang.Object) day38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date42 = fixedMillisecond41.getEnd();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
        serialDate43.setDescription("ERROR : Relative To String");
        java.lang.String str46 = serialDate43.getDescription();
        boolean boolean47 = spreadsheetDate34.isOnOrBefore(serialDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean50 = spreadsheetDate34.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean51 = spreadsheetDate19.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean52 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int53 = spreadsheetDate16.getMonth();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ERROR : Relative To String" + "'", str31.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ERROR : Relative To String" + "'", str46.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.lang.Class class9 = timeSeries4.getTimePeriodClass();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class13);
        timeSeries14.clear();
        java.util.Collection collection16 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        java.lang.String str17 = timeSeries14.getDescription();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNull(str17);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        long long7 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long7);
//        java.lang.String str9 = seriesChangeEvent8.toString();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193203437L + "'", long3 == 1560193203437L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193203437L + "'", long4 == 1560193203437L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560193203437L + "'", long6 == 1560193203437L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560193203437L + "'", long7 == 1560193203437L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1560193203437]" + "'", str9.equals("org.jfree.data.general.SeriesChangeEvent[source=1560193203437]"));
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        timeSeries4.setDescription("6-January-1900");
        timeSeries4.setRangeDescription("10-June-2019");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        timeSeries4.fireSeriesChanged();
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(8, serialDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getEnd();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
//        int int13 = day12.getMonth();
//        boolean boolean14 = spreadsheetDate8.equals((java.lang.Object) day12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getEnd();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
//        serialDate17.setDescription("ERROR : Relative To String");
//        java.lang.String str20 = serialDate17.getDescription();
//        boolean boolean21 = spreadsheetDate8.isOnOrBefore(serialDate17);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean24 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getEnd();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
//        serialDate27.setDescription("ERROR : Relative To String");
//        java.lang.String str30 = serialDate27.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date33 = fixedMillisecond32.getEnd();
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate34);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths(8, serialDate34);
//        org.jfree.data.time.SerialDate serialDate38 = serialDate34.getFollowingDayOfWeek(1);
//        boolean boolean39 = spreadsheetDate23.isInRange(serialDate27, serialDate34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date42 = fixedMillisecond41.getEnd();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate43);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(8, serialDate43);
//        org.jfree.data.time.SerialDate serialDate47 = serialDate43.getFollowingDayOfWeek(1);
//        int int48 = spreadsheetDate23.compareTo((java.lang.Object) serialDate43);
//        org.jfree.data.time.SerialDate serialDate49 = serialDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addYears(4, serialDate49);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ERROR : Relative To String" + "'", str20.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ERROR : Relative To String" + "'", str30.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-43619) + "'", int48 == (-43619));
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        long long28 = month23.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month23.next();
        java.util.Calendar calendar30 = null;
        try {
            long long31 = month23.getFirstMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1556693999999L + "'", long28 == 1556693999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date21 = fixedMillisecond20.getEnd();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        int int24 = day23.getMonth();
        boolean boolean25 = spreadsheetDate19.equals((java.lang.Object) day23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        serialDate28.setDescription("ERROR : Relative To String");
        java.lang.String str31 = serialDate28.getDescription();
        boolean boolean32 = spreadsheetDate19.isOnOrBefore(serialDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date36 = fixedMillisecond35.getEnd();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        int int39 = day38.getMonth();
        boolean boolean40 = spreadsheetDate34.equals((java.lang.Object) day38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date42 = fixedMillisecond41.getEnd();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
        serialDate43.setDescription("ERROR : Relative To String");
        java.lang.String str46 = serialDate43.getDescription();
        boolean boolean47 = spreadsheetDate34.isOnOrBefore(serialDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean50 = spreadsheetDate34.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean51 = spreadsheetDate19.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean52 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int53 = spreadsheetDate16.getDayOfMonth();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ERROR : Relative To String" + "'", str31.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ERROR : Relative To String" + "'", str46.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class10);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(4, 100);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries11.createCopy((int) 'a', (int) (short) 100);
//        boolean boolean18 = timeSeriesDataItem6.equals((java.lang.Object) 'a');
//        int int20 = timeSeriesDataItem6.compareTo((java.lang.Object) 1560193153583L);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int20);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193204254L + "'", long3 == 1560193204254L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193204254L + "'", long4 == 1560193204254L);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) strArray0);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertNotNull(strArray0);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        serialDate2.setDescription("ERROR : Relative To String");
//        java.lang.String str5 = serialDate2.getDescription();
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class9);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getEnd();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14, timeZone16);
//        boolean boolean18 = timeSeries10.equals((java.lang.Object) day17);
//        int int19 = day17.getMonth();
//        java.lang.String str20 = day17.toString();
//        java.lang.Class<?> wildcardClass21 = day17.getClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate2, (java.lang.Class) wildcardClass21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate2);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ERROR : Relative To String" + "'", str5.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10-June-2019" + "'", str20.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass21);
//    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560193150522L, class1);
//        java.lang.Comparable comparable3 = timeSeries2.getKey();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class7);
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12, timeZone14);
//        boolean boolean16 = timeSeries8.equals((java.lang.Object) day15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        fixedMillisecond24.peg(calendar25);
//        java.lang.Number number27 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.String str28 = fixedMillisecond24.toString();
//        long long29 = fixedMillisecond24.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond24.getLastMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond24.getMiddleMillisecond(calendar33);
//        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 1560193150522L + "'", comparable3.equals(1560193150522L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Mon Jun 10 12:00:04 PDT 2019" + "'", str28.equals("Mon Jun 10 12:00:04 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560193204378L + "'", long29 == 1560193204378L);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560193204378L + "'", long32 == 1560193204378L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560193204378L + "'", long34 == 1560193204378L);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        long long9 = timeSeries4.getMaximumItemAge();
        boolean boolean10 = timeSeries4.isEmpty();
        try {
            timeSeries4.removeAgedItems(0L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getLastMillisecond(calendar4);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193204466L + "'", long3 == 1560193204466L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560193204466L + "'", long5 == 1560193204466L);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
        long long13 = year9.getFirstMillisecond();
        java.util.Calendar calendar14 = null;
        try {
            year9.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Nearest");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        long long28 = month23.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month23.next();
        long long30 = month23.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month23.next();
        java.util.Date date32 = regularTimePeriod31.getEnd();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1556693999999L + "'", long28 == 1556693999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24232L + "'", long30 == 24232L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond19.peg(calendar20);
//        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries18.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
//        timeSeries28.setDescription("ERROR : Relative To String");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries28.removeChangeListener(seriesChangeListener31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date34 = fixedMillisecond33.getEnd();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getEnd();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date37);
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date37, timeZone39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date34, timeZone39);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar43 = null;
//        fixedMillisecond42.peg(calendar43);
//        long long45 = fixedMillisecond42.getMiddleMillisecond();
//        long long46 = fixedMillisecond42.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, 0.0d);
//        int int49 = month41.compareTo((java.lang.Object) timeSeriesDataItem48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month41.next();
//        int int51 = month41.getYearValue();
//        java.lang.Number number52 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month41);
//        timeSeries28.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
//        long long56 = fixedMillisecond55.getLastMillisecond();
//        long long57 = fixedMillisecond55.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (java.lang.Number) 0L);
//        java.lang.String str60 = timeSeries28.getDescription();
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560193204646L + "'", long45 == 1560193204646L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560193204646L + "'", long46 == 1560193204646L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "ERROR : Relative To String" + "'", str60.equals("ERROR : Relative To String"));
//    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
//        int int11 = day10.getMonth();
//        boolean boolean12 = spreadsheetDate6.equals((java.lang.Object) day10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.next();
//        java.util.Date date14 = day10.getStart();
//        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.String str16 = day10.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getEnd();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date21 = fixedMillisecond20.getEnd();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21, timeZone23);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date18, timeZone23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar27 = null;
//        fixedMillisecond26.peg(calendar27);
//        long long29 = fixedMillisecond26.getMiddleMillisecond();
//        long long30 = fixedMillisecond26.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, 0.0d);
//        int int33 = month25.compareTo((java.lang.Object) timeSeriesDataItem32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month25.previous();
//        boolean boolean35 = day10.equals((java.lang.Object) month25);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560193204806L + "'", long29 == 1560193204806L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560193204806L + "'", long30 == 1560193204806L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond9.peg(calendar10);
//        long long12 = fixedMillisecond9.getMiddleMillisecond();
//        long long13 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        int int16 = month8.compareTo((java.lang.Object) timeSeriesDataItem15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class20);
//        timeSeries21.setDescription("6-January-1900");
//        timeSeries21.setRangeDescription("10-June-2019");
//        java.util.List list26 = timeSeries21.getItems();
//        boolean boolean27 = timeSeriesDataItem15.equals((java.lang.Object) list26);
//        java.lang.Number number28 = timeSeriesDataItem15.getValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560193205026L + "'", long12 == 1560193205026L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560193205026L + "'", long13 == 1560193205026L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(list26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 0.0d + "'", number28.equals(0.0d));
//    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond9.peg(calendar10);
//        long long12 = fixedMillisecond9.getMiddleMillisecond();
//        long long13 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries16 = timeSeries4.createCopy(regularTimePeriod8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560193205473L + "'", long12 == 1560193205473L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560193205473L + "'", long13 == 1560193205473L);
//    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        int int6 = day5.getMonth();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        long long9 = day5.getFirstMillisecond();
//        java.util.Calendar calendar10 = null;
//        try {
//            day5.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar20 = null;
        fixedMillisecond19.peg(calendar20);
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries18.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
        java.lang.Object obj29 = timeSeries28.clone();
        timeSeries28.setDomainDescription("");
        timeSeries28.setDescription("");
        timeSeries28.setKey((java.lang.Comparable) 100.0f);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        int int5 = timeSeries4.getItemCount();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14, timeZone16);
        boolean boolean18 = timeSeries10.equals((java.lang.Object) day17);
        int int19 = day17.getYear();
        int int20 = day17.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 1560193177306L);
        int int23 = timeSeries4.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.Object obj34 = null;
        boolean boolean35 = spreadsheetDate16.equals(obj34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int37 = spreadsheetDate16.toSerial();
        int int38 = spreadsheetDate16.getDayOfMonth();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        java.util.Date date9 = fixedMillisecond5.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond5.next();
//        long long11 = fixedMillisecond5.getSerialIndex();
//        long long12 = fixedMillisecond5.getFirstMillisecond();
//        long long13 = fixedMillisecond5.getLastMillisecond();
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560193205808L + "'", long11 == 1560193205808L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560193205808L + "'", long12 == 1560193205808L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560193205808L + "'", long13 == 1560193205808L);
//    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        long long9 = year8.getFirstMillisecond();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
//        java.lang.String str11 = timeSeries4.getDescription();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        long long14 = day12.getLastMillisecond();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day12, (double) 1554102000000L, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        try {
            int int9 = spreadsheetDate1.compareTo((java.lang.Object) 1560279599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Mon Jun 10 11:59:52 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.removeChangeListener(seriesChangeListener7);
        timeSeries4.removeAgedItems(false);
        java.lang.Class class11 = timeSeries4.getTimePeriodClass();
        try {
            timeSeries4.update((int) ' ', (java.lang.Number) 1560193203437L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(class11);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getEnd();
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(8, serialDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate3);
//        long long7 = day6.getSerialIndex();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        int int6 = day5.getMonth();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        serialDate10.setDescription("ERROR : Relative To String");
//        java.lang.String str13 = serialDate10.getDescription();
//        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date19 = fixedMillisecond18.getEnd();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
//        serialDate20.setDescription("ERROR : Relative To String");
//        java.lang.String str23 = serialDate20.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getEnd();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(8, serialDate27);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate27.getFollowingDayOfWeek(1);
//        boolean boolean32 = spreadsheetDate16.isInRange(serialDate20, serialDate27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getEnd();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(8, serialDate36);
//        org.jfree.data.time.SerialDate serialDate40 = serialDate36.getFollowingDayOfWeek(1);
//        int int41 = spreadsheetDate16.compareTo((java.lang.Object) serialDate36);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date45 = fixedMillisecond44.getEnd();
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate46);
//        int int48 = day47.getMonth();
//        boolean boolean49 = spreadsheetDate43.equals((java.lang.Object) day47);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date51 = fixedMillisecond50.getEnd();
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date51);
//        serialDate52.setDescription("ERROR : Relative To String");
//        java.lang.String str55 = serialDate52.getDescription();
//        boolean boolean56 = spreadsheetDate43.isOnOrBefore(serialDate52);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date60 = fixedMillisecond59.getEnd();
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(date60);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(serialDate61);
//        int int63 = day62.getMonth();
//        boolean boolean64 = spreadsheetDate58.equals((java.lang.Object) day62);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date66 = fixedMillisecond65.getEnd();
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance(date66);
//        serialDate67.setDescription("ERROR : Relative To String");
//        java.lang.String str70 = serialDate67.getDescription();
//        boolean boolean71 = spreadsheetDate58.isOnOrBefore(serialDate67);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean74 = spreadsheetDate58.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate73);
//        boolean boolean75 = spreadsheetDate43.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate58);
//        java.lang.Object obj76 = null;
//        boolean boolean77 = spreadsheetDate58.equals(obj76);
//        java.lang.String str78 = spreadsheetDate58.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date81 = fixedMillisecond80.getEnd();
//        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.createInstance(date81);
//        serialDate82.setDescription("ERROR : Relative To String");
//        java.lang.String str85 = serialDate82.getDescription();
//        org.jfree.data.time.SerialDate serialDate86 = org.jfree.data.time.SerialDate.addMonths(11, serialDate82);
//        boolean boolean87 = spreadsheetDate58.isAfter(serialDate82);
//        org.jfree.data.time.SerialDate serialDate88 = serialDate36.getEndOfCurrentMonth(serialDate82);
//        java.lang.String str89 = serialDate82.toString();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ERROR : Relative To String" + "'", str23.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-43619) + "'", int41 == (-43619));
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "ERROR : Relative To String" + "'", str55.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 6 + "'", int63 == 6);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "ERROR : Relative To String" + "'", str70.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "6-January-1900" + "'", str78.equals("6-January-1900"));
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(serialDate82);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "ERROR : Relative To String" + "'", str85.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(serialDate86);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertNotNull(serialDate88);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10-June-2019" + "'", str89.equals("10-June-2019"));
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class16);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy(4, 100);
        java.util.Collection collection21 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        java.util.List list22 = timeSeries4.getItems();
        try {
            timeSeries4.delete(2019, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        int int5 = timeSeries4.getItemCount();
        timeSeries4.setNotify(true);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        java.lang.Number number10 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day8, number10);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener12);
        timeSeries4.setNotify(false);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date20 = fixedMillisecond19.getEnd();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20, timeZone22);
        java.lang.Class<?> wildcardClass24 = timeZone22.getClass();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year16, "org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019", "Mon Jun 10 11:59:38 PDT 2019", (java.lang.Class) wildcardClass24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        long long5 = timeSeries4.getMaximumItemAge();
//        timeSeries4.clear();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class10);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries11.addPropertyChangeListener(propertyChangeListener12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getEnd();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15, timeZone17);
//        boolean boolean19 = timeSeries11.equals((java.lang.Object) day18);
//        int int20 = day18.getMonth();
//        java.lang.String str21 = day18.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
//        long long23 = day18.getSerialIndex();
//        long long24 = day18.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10-June-2019" + "'", str21.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560150000000L + "'", long24 == 1560150000000L);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date19 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        serialDate20.setDescription("ERROR : Relative To String");
        java.lang.String str23 = serialDate20.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date26 = fixedMillisecond25.getEnd();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(8, serialDate27);
        org.jfree.data.time.SerialDate serialDate31 = serialDate27.getFollowingDayOfWeek(1);
        boolean boolean32 = spreadsheetDate16.isInRange(serialDate20, serialDate27);
        java.util.Date date33 = spreadsheetDate16.toDate();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ERROR : Relative To String" + "'", str23.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int18 = spreadsheetDate16.getMonth();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.util.Date date9 = fixedMillisecond5.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getEnd();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date16 = fixedMillisecond15.getEnd();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date13, timeZone18);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date9, timeZone18);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date9);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = month22.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(timeZone18);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        timeSeries4.clear();
        java.util.Collection collection6 = timeSeries4.getTimePeriods();
        timeSeries4.setDomainDescription("Mon Jun 10 11:59:52 PDT 2019");
        org.junit.Assert.assertNotNull(collection6);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, 0);
        int int3 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int18 = spreadsheetDate16.toSerial();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date20 = fixedMillisecond19.getEnd();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
        int int23 = day22.getMonth();
        org.jfree.data.time.SerialDate serialDate24 = day22.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date26 = fixedMillisecond25.getEnd();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        serialDate27.setDescription("ERROR : Relative To String");
        java.lang.String str30 = serialDate27.getDescription();
        boolean boolean31 = spreadsheetDate16.isInRange(serialDate24, serialDate27);
        int int32 = spreadsheetDate16.getMonth();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ERROR : Relative To String" + "'", str30.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
//        long long5 = day4.getLastMillisecond();
//        long long6 = day4.getLastMillisecond();
//        java.lang.String str7 = day4.toString();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate8);
//    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class10);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(4, 100);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries11.createCopy((int) 'a', (int) (short) 100);
//        boolean boolean18 = timeSeriesDataItem6.equals((java.lang.Object) 'a');
//        int int20 = timeSeriesDataItem6.compareTo((java.lang.Object) 1560193153583L);
//        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
//        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("");
//        timePeriodFormatException24.addSuppressed((java.lang.Throwable) seriesException26);
//        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
//        int int29 = timeSeriesDataItem6.compareTo((java.lang.Object) timePeriodFormatException24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeriesDataItem6.getPeriod();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193208423L + "'", long3 == 1560193208423L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193208423L + "'", long4 == 1560193208423L);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar1 = null;
        fixedMillisecond0.peg(calendar1);
        java.util.Calendar calendar3 = null;
        fixedMillisecond0.peg(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries15.createCopy(4, 100);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries15.createCopy((int) 'a', (int) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.addAndOrUpdate(timeSeries21);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries21.removePropertyChangeListener(propertyChangeListener23);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(timeSeries22);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        int int13 = day11.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        java.lang.Number number16 = timeSeriesDataItem15.getValue();
        timeSeriesDataItem15.setValue((java.lang.Number) (-43619));
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(2, year20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year20.previous();
        boolean boolean25 = timeSeriesDataItem15.equals((java.lang.Object) year20);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 9999.0d + "'", number16.equals(9999.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        try {
            org.jfree.data.time.TimeSeries timeSeries8 = timeSeries4.createCopy((int) '#', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("6-January-1900");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:59:06 PDT 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:59:06 PDT 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException7);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.util.List list9 = timeSeries4.getItems();
        boolean boolean11 = timeSeries4.equals((java.lang.Object) "11-June-2019");
        int int12 = timeSeries4.getMaximumItemCount();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        long long5 = timeSeries4.getMaximumItemAge();
//        timeSeries4.clear();
//        timeSeries4.setMaximumItemCount((int) (short) 10);
//        java.util.List list9 = timeSeries4.getItems();
//        boolean boolean11 = timeSeries4.equals((java.lang.Object) "11-June-2019");
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar18 = null;
//        fixedMillisecond17.peg(calendar18);
//        java.lang.Number number20 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        java.util.Date date21 = fixedMillisecond17.getTime();
//        long long22 = fixedMillisecond17.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 10);
//        try {
//            timeSeries4.add(timeSeriesDataItem24, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560193209322L + "'", long22 == 1560193209322L);
//    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond19.peg(calendar20);
//        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries18.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
//        timeSeries28.setDescription("ERROR : Relative To String");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries28.removeChangeListener(seriesChangeListener31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date34 = fixedMillisecond33.getEnd();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getEnd();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date37);
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date37, timeZone39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date34, timeZone39);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar43 = null;
//        fixedMillisecond42.peg(calendar43);
//        long long45 = fixedMillisecond42.getMiddleMillisecond();
//        long long46 = fixedMillisecond42.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, 0.0d);
//        int int49 = month41.compareTo((java.lang.Object) timeSeriesDataItem48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month41.next();
//        int int51 = month41.getYearValue();
//        java.lang.Number number52 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month41);
//        timeSeries28.clear();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date57 = fixedMillisecond56.getEnd();
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(date57);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(serialDate58);
//        int int60 = day59.getMonth();
//        boolean boolean61 = spreadsheetDate55.equals((java.lang.Object) day59);
//        int int62 = day59.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day59, (double) 100);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560193209343L + "'", long45 == 1560193209343L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560193209343L + "'", long46 == 1560193209343L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 6 + "'", int60 == 6);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 6 + "'", int62 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem64);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.util.Date date0 = null;
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar7 = null;
        fixedMillisecond6.peg(calendar7);
        java.lang.Number number9 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.util.Date date10 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getEnd();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date17, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date14, timeZone19);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date10, timeZone19);
        try {
            org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date0, timeZone19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(timeZone19);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        int int14 = day11.getYear();
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 0, 2147483647, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.lang.Class class9 = timeSeries4.getTimePeriodClass();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class13);
        timeSeries14.clear();
        java.util.Collection collection16 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.setDescription("Overwritten values from: ");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(collection16);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar20 = null;
        fixedMillisecond19.peg(calendar20);
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries18.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
        java.lang.String str29 = timeSeries28.getDescription();
        boolean boolean30 = timeSeries28.getNotify();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1, timeZone6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.previous();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getEnd();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
//        int int17 = day16.getMonth();
//        boolean boolean18 = spreadsheetDate12.equals((java.lang.Object) day16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date20 = fixedMillisecond19.getEnd();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
//        serialDate21.setDescription("ERROR : Relative To String");
//        java.lang.String str24 = serialDate21.getDescription();
//        boolean boolean25 = spreadsheetDate12.isOnOrBefore(serialDate21);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean28 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date30 = fixedMillisecond29.getEnd();
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date30);
//        serialDate31.setDescription("ERROR : Relative To String");
//        java.lang.String str34 = serialDate31.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getEnd();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(serialDate38);
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths(8, serialDate38);
//        org.jfree.data.time.SerialDate serialDate42 = serialDate38.getFollowingDayOfWeek(1);
//        boolean boolean43 = spreadsheetDate27.isInRange(serialDate31, serialDate38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getEnd();
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(serialDate47);
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addMonths(8, serialDate47);
//        org.jfree.data.time.SerialDate serialDate51 = serialDate47.getFollowingDayOfWeek(1);
//        int int52 = spreadsheetDate27.compareTo((java.lang.Object) serialDate47);
//        int int53 = spreadsheetDate27.toSerial();
//        org.jfree.data.time.SerialDate serialDate55 = spreadsheetDate27.getFollowingDayOfWeek(6);
//        int int56 = month8.compareTo((java.lang.Object) spreadsheetDate27);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ERROR : Relative To String" + "'", str24.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "ERROR : Relative To String" + "'", str34.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-43619) + "'", int52 == (-43619));
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 7 + "'", int53 == 7);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getEnd();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(8, serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getEnd();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond15.getMiddleMillisecond(calendar17);
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        java.util.Date date20 = fixedMillisecond15.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date23 = fixedMillisecond22.getEnd();
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
//        serialDate24.setDescription("ERROR : Relative To String");
//        java.lang.String str27 = serialDate24.getDescription();
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class31);
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date36 = fixedMillisecond35.getEnd();
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date36, timeZone38);
//        boolean boolean40 = timeSeries32.equals((java.lang.Object) day39);
//        int int41 = day39.getMonth();
//        java.lang.String str42 = day39.toString();
//        java.lang.Class<?> wildcardClass43 = day39.getClass();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate24, (java.lang.Class) wildcardClass43);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date20, (java.lang.Class) wildcardClass43);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(class14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560193212493L + "'", long18 == 1560193212493L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ERROR : Relative To String" + "'", str27.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "10-June-2019" + "'", str42.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass43);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date22 = fixedMillisecond21.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        int int25 = day24.getMonth();
        boolean boolean26 = spreadsheetDate20.equals((java.lang.Object) day24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getEnd();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        serialDate29.setDescription("ERROR : Relative To String");
        java.lang.String str32 = serialDate29.getDescription();
        boolean boolean33 = spreadsheetDate20.isOnOrBefore(serialDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean36 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date38 = fixedMillisecond37.getEnd();
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date38);
        serialDate39.setDescription("ERROR : Relative To String");
        java.lang.String str42 = serialDate39.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date45 = fixedMillisecond44.getEnd();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate46);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addMonths(8, serialDate46);
        org.jfree.data.time.SerialDate serialDate50 = serialDate46.getFollowingDayOfWeek(1);
        boolean boolean51 = spreadsheetDate35.isInRange(serialDate39, serialDate46);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addMonths(6, (org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean53 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date57 = fixedMillisecond56.getEnd();
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(date57);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(serialDate58);
        int int60 = day59.getMonth();
        boolean boolean61 = spreadsheetDate55.equals((java.lang.Object) day59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date63 = fixedMillisecond62.getEnd();
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(date63);
        serialDate64.setDescription("ERROR : Relative To String");
        java.lang.String str67 = serialDate64.getDescription();
        boolean boolean68 = spreadsheetDate55.isOnOrBefore(serialDate64);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date72 = fixedMillisecond71.getEnd();
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.createInstance(date72);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(serialDate73);
        int int75 = day74.getMonth();
        boolean boolean76 = spreadsheetDate70.equals((java.lang.Object) day74);
        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date78 = fixedMillisecond77.getEnd();
        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.createInstance(date78);
        serialDate79.setDescription("ERROR : Relative To String");
        java.lang.String str82 = serialDate79.getDescription();
        boolean boolean83 = spreadsheetDate70.isOnOrBefore(serialDate79);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate85 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean86 = spreadsheetDate70.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate85);
        boolean boolean87 = spreadsheetDate55.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate70);
        org.jfree.data.time.FixedMillisecond fixedMillisecond88 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date89 = fixedMillisecond88.getEnd();
        org.jfree.data.time.SerialDate serialDate90 = org.jfree.data.time.SerialDate.createInstance(date89);
        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day(serialDate90);
        boolean boolean92 = spreadsheetDate70.isAfter(serialDate90);
        int int93 = spreadsheetDate70.getMonth();
        int int94 = spreadsheetDate70.getDayOfMonth();
        boolean boolean95 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate70);
        int int96 = spreadsheetDate35.getDayOfWeek();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ERROR : Relative To String" + "'", str32.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ERROR : Relative To String" + "'", str42.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 6 + "'", int60 == 6);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "ERROR : Relative To String" + "'", str67.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 6 + "'", int75 == 6);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "ERROR : Relative To String" + "'", str82.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 6 + "'", int94 == 6);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 7 + "'", int96 == 7);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560193150522L, class1);
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar11 = null;
        fixedMillisecond10.peg(calendar11);
        java.lang.Number number13 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        timeSeries9.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries9.createCopy((int) (short) 1, 8);
        timeSeries18.setMaximumItemCount(7);
        boolean boolean21 = fixedMillisecond4.equals((java.lang.Object) 7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar29 = null;
        fixedMillisecond28.peg(calendar29);
        java.lang.Number number31 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        timeSeries27.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries27.createCopy((int) (short) 1, 8);
        timeSeries36.setMaximumItemCount(7);
        boolean boolean39 = fixedMillisecond22.equals((java.lang.Object) 7);
        boolean boolean40 = fixedMillisecond4.equals((java.lang.Object) 7);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 2019, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, year1);
        long long5 = year1.getFirstMillisecond();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar12 = null;
        fixedMillisecond11.peg(calendar12);
        java.lang.Number number14 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        timeSeries10.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries10.createCopy((int) (short) 1, 8);
        timeSeries19.setMaximumItemAge(1560193177903L);
        boolean boolean22 = year1.equals((java.lang.Object) timeSeries19);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.util.List list9 = timeSeries4.getItems();
        boolean boolean11 = timeSeries4.equals((java.lang.Object) "11-June-2019");
        int int12 = timeSeries4.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        int int6 = day5.getMonth();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        serialDate10.setDescription("ERROR : Relative To String");
//        java.lang.String str13 = serialDate10.getDescription();
//        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getEnd();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
//        int int21 = day20.getMonth();
//        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date24 = fixedMillisecond23.getEnd();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
//        serialDate25.setDescription("ERROR : Relative To String");
//        java.lang.String str28 = serialDate25.getDescription();
//        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getEnd();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
//        boolean boolean38 = spreadsheetDate16.isAfter(serialDate36);
//        int int39 = spreadsheetDate16.getMonth();
//        int int40 = spreadsheetDate16.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date43 = fixedMillisecond42.getEnd();
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(date43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(serialDate44);
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addMonths(8, serialDate44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date50 = fixedMillisecond49.getEnd();
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(date50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
//        int int53 = day52.getMonth();
//        boolean boolean54 = spreadsheetDate48.equals((java.lang.Object) day52);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date56 = fixedMillisecond55.getEnd();
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date56);
//        serialDate57.setDescription("ERROR : Relative To String");
//        java.lang.String str60 = serialDate57.getDescription();
//        boolean boolean61 = spreadsheetDate48.isOnOrBefore(serialDate57);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean64 = spreadsheetDate48.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate63);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date66 = fixedMillisecond65.getEnd();
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance(date66);
//        serialDate67.setDescription("ERROR : Relative To String");
//        java.lang.String str70 = serialDate67.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date73 = fixedMillisecond72.getEnd();
//        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.createInstance(date73);
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(serialDate74);
//        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.addMonths(8, serialDate74);
//        org.jfree.data.time.SerialDate serialDate78 = serialDate74.getFollowingDayOfWeek(1);
//        boolean boolean79 = spreadsheetDate63.isInRange(serialDate67, serialDate74);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date82 = fixedMillisecond81.getEnd();
//        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance(date82);
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(serialDate83);
//        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.addMonths(8, serialDate83);
//        org.jfree.data.time.SerialDate serialDate87 = serialDate83.getFollowingDayOfWeek(1);
//        int int88 = spreadsheetDate63.compareTo((java.lang.Object) serialDate83);
//        org.jfree.data.time.SerialDate serialDate89 = serialDate44.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate63);
//        boolean boolean90 = spreadsheetDate16.isOn(serialDate89);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1900 + "'", int40 == 1900);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "ERROR : Relative To String" + "'", str60.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "ERROR : Relative To String" + "'", str70.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(serialDate76);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(serialDate83);
//        org.junit.Assert.assertNotNull(serialDate85);
//        org.junit.Assert.assertNotNull(serialDate87);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-43619) + "'", int88 == (-43619));
//        org.junit.Assert.assertNotNull(serialDate89);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getEnd();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9, timeZone11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date6, timeZone11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = regularTimePeriod16.getMiddleMillisecond();
//        java.lang.String str18 = regularTimePeriod16.toString();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) month13, regularTimePeriod16);
//        timeSeries4.setMaximumItemAge((long) 2019);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560279599999L + "'", long17 == 1560279599999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "11-June-2019" + "'", str18.equals("11-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries19);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        timeSeries7.setDomainDescription("org.jfree.data.general.SeriesException: Mon Jun 10 11:59:06 PDT 2019");
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar16 = null;
        fixedMillisecond15.peg(calendar16);
        java.lang.Number number18 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date20 = fixedMillisecond19.getEnd();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date20);
        boolean boolean23 = timeSeries14.equals((java.lang.Object) date20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        java.util.Date date26 = fixedMillisecond25.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getEnd();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date28, timeZone30);
        java.lang.Class<?> wildcardClass32 = timeZone30.getClass();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date26, timeZone30);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date20, timeZone30);
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day34, (java.lang.Number) 1560193200809L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=1560193203437]");
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar15 = null;
        fixedMillisecond14.peg(calendar15);
        java.lang.Number number17 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date19 = fixedMillisecond18.getEnd();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date19);
        boolean boolean22 = timeSeries13.equals((java.lang.Object) date19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date27, timeZone29);
        java.lang.Class<?> wildcardClass31 = timeZone29.getClass();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date25, timeZone29);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date19, timeZone29);
        java.lang.Number number34 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day33);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNull(number34);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date21 = fixedMillisecond20.getEnd();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        int int24 = day23.getMonth();
        boolean boolean25 = spreadsheetDate19.equals((java.lang.Object) day23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        serialDate28.setDescription("ERROR : Relative To String");
        java.lang.String str31 = serialDate28.getDescription();
        boolean boolean32 = spreadsheetDate19.isOnOrBefore(serialDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date36 = fixedMillisecond35.getEnd();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        int int39 = day38.getMonth();
        boolean boolean40 = spreadsheetDate34.equals((java.lang.Object) day38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date42 = fixedMillisecond41.getEnd();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
        serialDate43.setDescription("ERROR : Relative To String");
        java.lang.String str46 = serialDate43.getDescription();
        boolean boolean47 = spreadsheetDate34.isOnOrBefore(serialDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean50 = spreadsheetDate34.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean51 = spreadsheetDate19.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean52 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date54 = fixedMillisecond53.getEnd();
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(date54);
        serialDate55.setDescription("ERROR : Relative To String");
        boolean boolean58 = spreadsheetDate34.isAfter(serialDate55);
        java.lang.String str59 = spreadsheetDate34.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ERROR : Relative To String" + "'", str31.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ERROR : Relative To String" + "'", str46.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "6-January-1900" + "'", str59.equals("6-January-1900"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class16);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy(4, 100);
        java.util.Collection collection21 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries17.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(collection21);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getEnd();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond15.getMiddleMillisecond(calendar17);
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        java.util.Date date20 = fixedMillisecond15.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(class14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560193216654L + "'", long18 == 1560193216654L);
//        org.junit.Assert.assertNotNull(date20);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        java.util.Date date3 = year0.getStart();
        int int5 = year0.compareTo((java.lang.Object) 1560193204646L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, (int) (short) 10, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) -1, 1900, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        java.lang.String str5 = timeSeries4.getDescription();
        boolean boolean6 = timeSeries4.getNotify();
        java.lang.Object obj7 = timeSeries4.clone();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj7);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getEnd();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
//        boolean boolean13 = timeSeries4.equals((java.lang.Object) date10);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560193150522L, class15);
//        java.lang.Comparable comparable17 = timeSeries16.getKey();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getEnd();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26, timeZone28);
//        boolean boolean30 = timeSeries22.equals((java.lang.Object) day29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day29.next();
//        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        fixedMillisecond38.peg(calendar39);
//        java.lang.Number number41 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
//        java.lang.String str42 = fixedMillisecond38.toString();
//        long long43 = fixedMillisecond38.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) day29, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries4.addAndOrUpdate(timeSeries16);
//        java.lang.Object obj46 = timeSeries45.clone();
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 1560193150522L + "'", comparable17.equals(1560193150522L));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNull(number41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Mon Jun 10 12:00:17 PDT 2019" + "'", str42.equals("Mon Jun 10 12:00:17 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560193217117L + "'", long43 == 1560193217117L);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertNotNull(obj46);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.clear();
        timeSeries4.setMaximumItemCount((int) (short) 10);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class12);
        int int14 = timeSeries13.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries4.addAndOrUpdate(timeSeries13);
        timeSeries4.setKey((java.lang.Comparable) (-43619));
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = month18.getYearValue();
        timeSeries4.setKey((java.lang.Comparable) int19);
        timeSeries4.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        java.lang.String str9 = fixedMillisecond5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond5.previous();
//        long long11 = fixedMillisecond5.getFirstMillisecond();
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Mon Jun 10 12:00:17 PDT 2019" + "'", str9.equals("Mon Jun 10 12:00:17 PDT 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560193217387L + "'", long11 == 1560193217387L);
//    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getEnd();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond15.getMiddleMillisecond(calendar17);
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        java.util.Date date20 = fixedMillisecond15.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = year21.getLastMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(class14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560193217401L + "'", long18 == 1560193217401L);
//        org.junit.Assert.assertNotNull(date20);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "December" + "'", str1.equals("December"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getMonth();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        serialDate11.setDescription("ERROR : Relative To String");
        java.lang.String str14 = serialDate11.getDescription();
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date20 = fixedMillisecond19.getEnd();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        serialDate21.setDescription("ERROR : Relative To String");
        java.lang.String str24 = serialDate21.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(8, serialDate28);
        org.jfree.data.time.SerialDate serialDate32 = serialDate28.getFollowingDayOfWeek(1);
        boolean boolean33 = spreadsheetDate17.isInRange(serialDate21, serialDate28);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths(6, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date38 = fixedMillisecond37.getEnd();
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(serialDate39);
        int int41 = day40.getMonth();
        boolean boolean42 = spreadsheetDate36.equals((java.lang.Object) day40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date44 = fixedMillisecond43.getEnd();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date44);
        serialDate45.setDescription("ERROR : Relative To String");
        java.lang.String str48 = serialDate45.getDescription();
        boolean boolean49 = spreadsheetDate36.isOnOrBefore(serialDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date53 = fixedMillisecond52.getEnd();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(date53);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        int int56 = day55.getMonth();
        boolean boolean57 = spreadsheetDate51.equals((java.lang.Object) day55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date59 = fixedMillisecond58.getEnd();
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance(date59);
        serialDate60.setDescription("ERROR : Relative To String");
        java.lang.String str63 = serialDate60.getDescription();
        boolean boolean64 = spreadsheetDate51.isOnOrBefore(serialDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean67 = spreadsheetDate51.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate66);
        boolean boolean68 = spreadsheetDate36.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date70 = fixedMillisecond69.getEnd();
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance(date70);
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(serialDate71);
        boolean boolean73 = spreadsheetDate51.isAfter(serialDate71);
        int int74 = spreadsheetDate51.getMonth();
        int int75 = spreadsheetDate51.getDayOfMonth();
        boolean boolean76 = spreadsheetDate17.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ERROR : Relative To String" + "'", str24.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "ERROR : Relative To String" + "'", str48.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 6 + "'", int56 == 6);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "ERROR : Relative To String" + "'", str63.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 6 + "'", int75 == 6);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
//        java.lang.Class<?> wildcardClass8 = timeZone6.getClass();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560193165121L, "6-January-1900", "10-June-2019", (java.lang.Class) wildcardClass8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        fixedMillisecond15.peg(calendar16);
//        java.lang.Number number18 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        java.util.Date date19 = fixedMillisecond15.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond15.next();
//        long long21 = fixedMillisecond15.getSerialIndex();
//        long long22 = fixedMillisecond15.getFirstMillisecond();
//        java.lang.Number number23 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        java.util.Date date24 = fixedMillisecond15.getEnd();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560193218333L + "'", long21 == 1560193218333L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560193218333L + "'", long22 == 1560193218333L);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertNotNull(date24);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("6-January-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        int int13 = day11.getMonth();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class17);
        boolean boolean19 = timeSeries18.isEmpty();
        boolean boolean20 = day11.equals((java.lang.Object) timeSeries18);
        java.util.List list21 = timeSeries18.getItems();
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries15.createCopy(4, 100);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries15.createCopy((int) 'a', (int) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.addAndOrUpdate(timeSeries21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date26 = fixedMillisecond25.getEnd();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        int int29 = day28.getMonth();
        boolean boolean30 = spreadsheetDate24.equals((java.lang.Object) day28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date32 = fixedMillisecond31.getEnd();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
        serialDate33.setDescription("ERROR : Relative To String");
        java.lang.String str36 = serialDate33.getDescription();
        boolean boolean37 = spreadsheetDate24.isOnOrBefore(serialDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date41 = fixedMillisecond40.getEnd();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date41);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(serialDate42);
        int int44 = day43.getMonth();
        boolean boolean45 = spreadsheetDate39.equals((java.lang.Object) day43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date47 = fixedMillisecond46.getEnd();
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
        serialDate48.setDescription("ERROR : Relative To String");
        java.lang.String str51 = serialDate48.getDescription();
        boolean boolean52 = spreadsheetDate39.isOnOrBefore(serialDate48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean55 = spreadsheetDate39.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        boolean boolean56 = spreadsheetDate24.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate39);
        java.lang.Object obj57 = null;
        boolean boolean58 = spreadsheetDate39.equals(obj57);
        java.lang.String str59 = spreadsheetDate39.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date62 = fixedMillisecond61.getEnd();
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance(date62);
        serialDate63.setDescription("ERROR : Relative To String");
        java.lang.String str66 = serialDate63.getDescription();
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addMonths(11, serialDate63);
        boolean boolean68 = spreadsheetDate39.isAfter(serialDate63);
        timeSeries21.setKey((java.lang.Comparable) serialDate63);
        timeSeries21.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=1560193203437]");
        java.lang.Object obj72 = timeSeries21.clone();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ERROR : Relative To String" + "'", str36.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "ERROR : Relative To String" + "'", str51.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "6-January-1900" + "'", str59.equals("6-January-1900"));
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "ERROR : Relative To String" + "'", str66.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(obj72);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int18 = spreadsheetDate16.toSerial();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date20 = fixedMillisecond19.getEnd();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        serialDate21.setDescription("ERROR : Relative To String");
        boolean boolean24 = spreadsheetDate16.isAfter(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date33 = fixedMillisecond32.getEnd();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate34);
        int int36 = day35.getMonth();
        boolean boolean37 = spreadsheetDate31.equals((java.lang.Object) day35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date39 = fixedMillisecond38.getEnd();
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date39);
        serialDate40.setDescription("ERROR : Relative To String");
        java.lang.String str43 = serialDate40.getDescription();
        boolean boolean44 = spreadsheetDate31.isOnOrBefore(serialDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean47 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date49 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date49);
        serialDate50.setDescription("ERROR : Relative To String");
        java.lang.String str53 = serialDate50.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date56 = fixedMillisecond55.getEnd();
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addMonths(8, serialDate57);
        org.jfree.data.time.SerialDate serialDate61 = serialDate57.getFollowingDayOfWeek(1);
        boolean boolean62 = spreadsheetDate46.isInRange(serialDate50, serialDate57);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addMonths(6, (org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean64 = spreadsheetDate26.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate28, (org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean65 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate67 = spreadsheetDate26.getPreviousDayOfWeek(6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "ERROR : Relative To String" + "'", str43.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "ERROR : Relative To String" + "'", str53.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(serialDate67);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "First" + "'", str1.equals("First"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar20 = null;
        fixedMillisecond19.peg(calendar20);
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        timeSeries18.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
        java.lang.String str29 = timeSeries4.getDomainDescription();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.Object obj34 = null;
        boolean boolean35 = spreadsheetDate16.equals(obj34);
        java.lang.String str36 = spreadsheetDate16.toString();
        int int37 = spreadsheetDate16.toSerial();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "6-January-1900" + "'", str36.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date21 = fixedMillisecond20.getEnd();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        int int24 = day23.getMonth();
        boolean boolean25 = spreadsheetDate19.equals((java.lang.Object) day23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        serialDate28.setDescription("ERROR : Relative To String");
        java.lang.String str31 = serialDate28.getDescription();
        boolean boolean32 = spreadsheetDate19.isOnOrBefore(serialDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date36 = fixedMillisecond35.getEnd();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        int int39 = day38.getMonth();
        boolean boolean40 = spreadsheetDate34.equals((java.lang.Object) day38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date42 = fixedMillisecond41.getEnd();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
        serialDate43.setDescription("ERROR : Relative To String");
        java.lang.String str46 = serialDate43.getDescription();
        boolean boolean47 = spreadsheetDate34.isOnOrBefore(serialDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean50 = spreadsheetDate34.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean51 = spreadsheetDate19.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean52 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        try {
            int int54 = spreadsheetDate34.compareTo((java.lang.Object) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Short cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ERROR : Relative To String" + "'", str31.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ERROR : Relative To String" + "'", str46.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        long long10 = year9.getFirstMillisecond();
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
//        java.lang.Object obj13 = null;
//        int int14 = month12.compareTo(obj13);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        fixedMillisecond20.peg(calendar21);
//        java.lang.Number number23 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        java.util.Date date24 = fixedMillisecond20.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
//        long long26 = fixedMillisecond25.getMiddleMillisecond();
//        int int27 = month12.compareTo((java.lang.Object) fixedMillisecond25);
//        long long28 = month12.getSerialIndex();
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560193219844L + "'", long26 == 1560193219844L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24232L + "'", long28 == 24232L);
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) 10.0f);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ERROR : Relative To String", "ERROR : Relative To String", class10);
        boolean boolean12 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        long long15 = fixedMillisecond14.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries4.addAndOrUpdate(timeSeries11);
        java.lang.Object obj19 = timeSeries18.clone();
        boolean boolean20 = timeSeries18.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 1, 8);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond19.peg(calendar20);
//        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries18.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries18.createCopy((int) (short) 1, 8);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
//        timeSeries28.setDescription("ERROR : Relative To String");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries28.removeChangeListener(seriesChangeListener31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date34 = fixedMillisecond33.getEnd();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getEnd();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date37);
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date37, timeZone39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date34, timeZone39);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar43 = null;
//        fixedMillisecond42.peg(calendar43);
//        long long45 = fixedMillisecond42.getMiddleMillisecond();
//        long long46 = fixedMillisecond42.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, 0.0d);
//        int int49 = month41.compareTo((java.lang.Object) timeSeriesDataItem48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month41.next();
//        int int51 = month41.getYearValue();
//        java.lang.Number number52 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month41);
//        timeSeries28.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
//        long long56 = fixedMillisecond55.getLastMillisecond();
//        long long57 = fixedMillisecond55.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (java.lang.Number) 0L);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries28.getDataItem(1900);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560193219925L + "'", long45 == 1560193219925L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560193219925L + "'", long46 == 1560193219925L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        int int7 = day6.getMonth();
//        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getEnd();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
//        serialDate11.setDescription("ERROR : Relative To String");
//        java.lang.String str14 = serialDate11.getDescription();
//        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean18 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date20 = fixedMillisecond19.getEnd();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
//        serialDate21.setDescription("ERROR : Relative To String");
//        java.lang.String str24 = serialDate21.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date27 = fixedMillisecond26.getEnd();
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(8, serialDate28);
//        org.jfree.data.time.SerialDate serialDate32 = serialDate28.getFollowingDayOfWeek(1);
//        boolean boolean33 = spreadsheetDate17.isInRange(serialDate21, serialDate28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date36 = fixedMillisecond35.getEnd();
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addMonths(8, serialDate37);
//        org.jfree.data.time.SerialDate serialDate41 = serialDate37.getFollowingDayOfWeek(1);
//        int int42 = spreadsheetDate17.compareTo((java.lang.Object) serialDate37);
//        java.util.Date date43 = spreadsheetDate17.toDate();
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
//        java.lang.String str45 = year44.toString();
//        int int46 = year44.getYear();
//        try {
//            org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(0, year44);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ERROR : Relative To String" + "'", str14.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ERROR : Relative To String" + "'", str24.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-43619) + "'", int42 == (-43619));
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "1900" + "'", str45.equals("1900"));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1900 + "'", int46 == 1900);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        int int27 = month23.getYearValue();
        java.util.Date date28 = month23.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(date28);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
//        long long5 = timeSeries4.getMaximumItemAge();
//        timeSeries4.clear();
//        timeSeries4.setMaximumItemCount((int) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond9.peg(calendar10);
//        long long12 = fixedMillisecond9.getMiddleMillisecond();
//        long long13 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class19);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(4, 100);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries20.createCopy((int) 'a', (int) (short) 100);
//        boolean boolean27 = timeSeriesDataItem15.equals((java.lang.Object) 'a');
//        int int29 = timeSeriesDataItem15.compareTo((java.lang.Object) 1560193153583L);
//        java.lang.Object obj30 = timeSeriesDataItem15.clone();
//        try {
//            timeSeries4.add(timeSeriesDataItem15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560193220289L + "'", long12 == 1560193220289L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560193220289L + "'", long13 == 1560193220289L);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(obj30);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class3);
        int int5 = timeSeries4.getItemCount();
        timeSeries4.setNotify(true);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        java.lang.Number number10 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day8, number10);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener12);
        timeSeries4.fireSeriesChanged();
        timeSeries4.setNotify(false);
        try {
            timeSeries4.delete(31, (-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-43619), (int) (byte) -1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Nearest");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        java.lang.Number number8 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries4.setRangeDescription("hi!");
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries15.createCopy(4, 100);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries15.createCopy((int) 'a', (int) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.addAndOrUpdate(timeSeries21);
        int int23 = timeSeries22.getItemCount();
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class10);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(4, 100);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries11.createCopy((int) 'a', (int) (short) 100);
//        boolean boolean18 = timeSeriesDataItem6.equals((java.lang.Object) 'a');
//        timeSeriesDataItem6.setValue((java.lang.Number) 1554102000000L);
//        java.lang.Number number21 = timeSeriesDataItem6.getValue();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getEnd();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate26);
//        int int28 = day27.getMonth();
//        boolean boolean29 = spreadsheetDate23.equals((java.lang.Object) day27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date31 = fixedMillisecond30.getEnd();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
//        serialDate32.setDescription("ERROR : Relative To String");
//        java.lang.String str35 = serialDate32.getDescription();
//        boolean boolean36 = spreadsheetDate23.isOnOrBefore(serialDate32);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean39 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date44 = fixedMillisecond43.getEnd();
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate45);
//        int int47 = day46.getMonth();
//        boolean boolean48 = spreadsheetDate42.equals((java.lang.Object) day46);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date50 = fixedMillisecond49.getEnd();
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(date50);
//        serialDate51.setDescription("ERROR : Relative To String");
//        java.lang.String str54 = serialDate51.getDescription();
//        boolean boolean55 = spreadsheetDate42.isOnOrBefore(serialDate51);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean58 = spreadsheetDate42.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate57);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date60 = fixedMillisecond59.getEnd();
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(date60);
//        serialDate61.setDescription("ERROR : Relative To String");
//        java.lang.String str64 = serialDate61.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date67 = fixedMillisecond66.getEnd();
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance(date67);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(serialDate68);
//        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addMonths(8, serialDate68);
//        org.jfree.data.time.SerialDate serialDate72 = serialDate68.getFollowingDayOfWeek(1);
//        boolean boolean73 = spreadsheetDate57.isInRange(serialDate61, serialDate68);
//        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.addMonths(6, (org.jfree.data.time.SerialDate) spreadsheetDate57);
//        boolean boolean75 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate57);
//        boolean boolean76 = timeSeriesDataItem6.equals((java.lang.Object) spreadsheetDate57);
//        timeSeriesDataItem6.setValue((java.lang.Number) 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193220363L + "'", long3 == 1560193220363L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193220363L + "'", long4 == 1560193220363L);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1554102000000L + "'", number21.equals(1554102000000L));
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ERROR : Relative To String" + "'", str35.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ERROR : Relative To String" + "'", str54.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "ERROR : Relative To String" + "'", str64.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertNotNull(serialDate72);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond6.peg(calendar7);
//        java.lang.Number number9 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        timeSeries5.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((int) (short) 1, 8);
//        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getEnd();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond16.getMiddleMillisecond(calendar18);
//        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
//        java.util.Date date21 = fixedMillisecond16.getStart();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(8, year22);
//        org.junit.Assert.assertNull(number9);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(class15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560193220835L + "'", long19 == 1560193220835L);
//        org.junit.Assert.assertNotNull(date21);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(4, 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year9);
        java.lang.String str13 = year9.toString();
        int int14 = year9.getYear();
        long long15 = year9.getLastMillisecond();
        java.lang.Class<?> wildcardClass16 = year9.getClass();
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560193150522L, class1);
//        java.lang.Comparable comparable3 = timeSeries2.getKey();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class7);
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12, timeZone14);
//        boolean boolean16 = timeSeries8.equals((java.lang.Object) day15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        fixedMillisecond24.peg(calendar25);
//        java.lang.Number number27 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.String str28 = fixedMillisecond24.toString();
//        long long29 = fixedMillisecond24.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        timeSeries30.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 1560193150522L + "'", comparable3.equals(1560193150522L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Mon Jun 10 12:00:21 PDT 2019" + "'", str28.equals("Mon Jun 10 12:00:21 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560193221005L + "'", long29 == 1560193221005L);
//        org.junit.Assert.assertNotNull(timeSeries30);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        int int6 = day5.getMonth();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate10.setDescription("ERROR : Relative To String");
        java.lang.String str13 = serialDate10.getDescription();
        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        int int21 = day20.getMonth();
        boolean boolean22 = spreadsheetDate16.equals((java.lang.Object) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        serialDate25.setDescription("ERROR : Relative To String");
        java.lang.String str28 = serialDate25.getDescription();
        boolean boolean29 = spreadsheetDate16.isOnOrBefore(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.Object obj34 = null;
        boolean boolean35 = spreadsheetDate16.equals(obj34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.Class class40 = null;
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "", class40);
        int int42 = timeSeries41.getItemCount();
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class46);
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timeSeries47.addPropertyChangeListener(propertyChangeListener48);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date51 = fixedMillisecond50.getEnd();
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date51);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date51, timeZone53);
        boolean boolean55 = timeSeries47.equals((java.lang.Object) day54);
        int int56 = day54.getYear();
        int int57 = day54.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day54, (java.lang.Number) 1560193177306L);
        org.jfree.data.time.SerialDate serialDate60 = day54.getSerialDate();
        boolean boolean61 = spreadsheetDate16.isOn(serialDate60);
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(serialDate60);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ERROR : Relative To String" + "'", str28.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
        boolean boolean12 = timeSeries4.equals((java.lang.Object) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        int int14 = day11.getMonth();
        int int15 = day11.getYear();
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(4, 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "", "hi!", class15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(4, 100);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(4, year20);
        java.lang.Object obj24 = null;
        int int25 = month23.compareTo(obj24);
        int int26 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries4.removeChangeListener(seriesChangeListener27);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560193205808L);
    }
}

