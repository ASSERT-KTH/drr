import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Shape shape0 = null;
        org.jfree.chart.axis.Axis axis1 = null;
        try {
            org.jfree.chart.entity.AxisEntity axisEntity2 = new org.jfree.chart.entity.AxisEntity(shape0, axis1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            int int4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound(xYDataset0, (int) (byte) 1, 1.0d, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (short) 100, 0.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 100L, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("ThreadContext", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        boolean boolean4 = segmentedTimeline0.containsDomainValue((long) (short) 0);
        segmentedTimeline0.addException(0L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range1);
        org.jfree.data.Range range3 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toRangeHeight(range3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Paint paint2 = null;
        java.awt.Stroke stroke3 = null;
        java.awt.Paint paint4 = null;
        java.awt.Stroke stroke5 = null;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((double) 10L, 1.0d, paint2, stroke3, paint4, stroke5, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = java.text.NumberFormat.FRACTION_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1), (double) '#', rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 25566L, (double) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (25566.0) <= upper (5.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 1.0f, (double) 0, (int) '4', comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.DAY;
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 1, dateTickUnitType2, (-1), dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.KeyedValues keyedValues0 = null;
        try {
            org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset(keyedValues0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'data' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("ThreadContext", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("", class1);
        java.net.URLClassLoader uRLClassLoader3 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL2, uRLClassLoader3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(uRL2);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Shape shape0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity3 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart1, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        try {
            double double5 = timeSeriesCollection2.getXValue((int) (short) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = null;
        try {
            polarPlot3.setAngleLabelPaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            boolean boolean3 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 10L, 10.0d, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        chartChangeEvent3.setChart(jFreeChart4);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseOutlinePaint();
        java.awt.Paint paint2 = xYBarRenderer0.getBasePaint();
        try {
            xYBarRenderer0.setSeriesVisibleInLegend((int) (short) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = xYBarRenderer1.getBaseOutlinePaint();
        java.awt.Shape shape8 = null;
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color19 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape8, false, paint10, false, (java.awt.Paint) color12, stroke13, true, shape15, stroke16, (java.awt.Paint) color19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, paint2, stroke16);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = null;
        try {
            valueMarker21.setLabelOffset(rectangleInsets22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Stroke stroke4 = xYBarRenderer0.getItemStroke((int) 'a', (int) '#', true);
        java.lang.Object obj5 = null;
        boolean boolean6 = xYBarRenderer0.equals(obj5);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            polarPlot7.drawOutline(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = null;
        try {
            org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource1 = null;
        chartRenderingInfo0.setRenderingSource(renderingSource1);
        chartRenderingInfo0.clear();
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("ThreadContext", 2, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isOutlineVisible();
        try {
            double double5 = polarPlot3.getMaxRadius();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        java.util.List list4 = null;
        org.jfree.data.Range range5 = null;
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, (double) 100);
        try {
            org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, list4, range5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor1, textAnchor2, textAnchor3, (double) '#');
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor2, textAnchor6, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.lang.Boolean boolean10 = xYBarRenderer0.getSeriesItemLabelsVisible(10);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            xYBarRenderer0.fillDomainGridBand(graphics2D11, xYPlot12, valueAxis13, rectangle2D14, 0.0d, (double) 25566L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean10);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textFragment1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        numberFormat0.setParseIntegerOnly(false);
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 1, true, true);
        try {
            xYSeries3.update((java.lang.Number) (-1), (java.lang.Number) 0.5f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: No observation for x = -1");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer0.setShadowYOffset((double) 0L);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.Shape shape15 = null;
        java.awt.Paint paint17 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color19 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape22 = null;
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color26 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape15, false, paint17, false, (java.awt.Paint) color19, stroke20, true, shape22, stroke23, (java.awt.Paint) color26);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Stroke stroke32 = xYBarRenderer28.getItemStroke((int) 'a', (int) '#', true);
        try {
            xYBarRenderer0.drawRangeLine(graphics2D5, xYPlot6, valueAxis7, rectangle2D8, (double) 3, (java.awt.Paint) color19, stroke32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            categoryPlot0.handleClick((int) (byte) 10, 1, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "October" + "'", str1.equals("October"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            polarPlot3.setInsets(rectangleInsets4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        polarPlot7.setDrawingSupplier(drawingSupplier9);
        try {
            java.lang.Object obj11 = polarPlot7.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("SerialDate.weekInMonthToString(): invalid code.", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        java.awt.Font font5 = polarPlot4.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.DATASET_UPDATED", font5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.Color color9 = java.awt.Color.RED;
        try {
            java.lang.Object obj10 = labelBlock6.draw(graphics2D7, rectangle2D8, (java.lang.Object) color9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        java.awt.geom.Point2D point2D30 = null;
        org.jfree.chart.plot.PlotState plotState31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        try {
            categoryPlot0.draw(graphics2D28, rectangle2D29, point2D30, plotState31, plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1, timeZone2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3, true);
        org.jfree.data.Range range7 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        try {
            java.lang.Number number10 = timeSeriesCollection3.getX((int) (byte) 100, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        try {
            boolean boolean2 = categoryPlot0.removeAnnotation(categoryAnnotation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        java.awt.Font font5 = polarPlot4.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.DATASET_UPDATED", font5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            labelBlock6.draw(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color16 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape5, false, paint7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color16);
        java.awt.Paint paint18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem17.setLabelPaint(paint18);
        java.awt.Shape shape25 = null;
        java.awt.Paint paint27 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color29 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape32 = null;
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color36 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape25, false, paint27, false, (java.awt.Paint) color29, stroke30, true, shape32, stroke33, (java.awt.Paint) color36);
        java.lang.Object obj38 = null;
        boolean boolean39 = legendItem37.equals(obj38);
        java.awt.Shape shape45 = null;
        java.awt.Paint paint47 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color49 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape52 = null;
        java.awt.Stroke stroke53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color56 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem57 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape45, false, paint47, false, (java.awt.Paint) color49, stroke50, true, shape52, stroke53, (java.awt.Paint) color56);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer58 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint59 = xYBarRenderer58.getBaseOutlinePaint();
        legendItem57.setLinePaint(paint59);
        legendItem37.setLabelPaint(paint59);
        legendItem17.setFillPaint(paint59);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(paint59);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((-1), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color16 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape5, false, paint7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color16);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint19 = xYBarRenderer18.getBaseOutlinePaint();
        legendItem17.setLinePaint(paint19);
        java.lang.Object obj21 = legendItem17.clone();
        legendItem17.setShapeVisible(true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 100);
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord2 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            java.lang.Comparable comparable2 = defaultXYDataset0.getSeriesKey(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = legendTitle1.arrange(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Color color5 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) (short) 0, (double) ' ', (double) (-1.0f), (java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES_AND_LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, true);
        org.jfree.data.Range range11 = xYBarRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot0, (org.jfree.data.general.Dataset) timeSeriesCollection7);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            categoryPlot0.drawBackground(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        boolean boolean0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        java.lang.Object obj1 = null;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint0, obj1);
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number3 = xYDataItem2.getX();
        double double4 = xYDataItem2.getYValue();
        java.lang.String str5 = xYDataItem2.toString();
        java.lang.Object obj6 = null;
        int int7 = xYDataItem2.compareTo(obj6);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.0d + "'", double4 == 12.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[100.0, 12.0]" + "'", str5.equals("[100.0, 12.0]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor1, textAnchor2, textAnchor3, 0.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor2);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("SerialDate.weekInMonthToString(): invalid code.", (int) (short) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection2);
        java.lang.String str10 = rendererChangeEvent9.toString();
        java.lang.Object obj11 = rendererChangeEvent9.getRenderer();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = waferMapPlot2.getDataset();
        org.junit.Assert.assertNull(waferMapDataset3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline1.getSegment((long) (short) 100);
        long long4 = segment3.getSegmentCount();
        long long5 = segment3.getSegmentCount();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline6.getSegment((long) (short) 100);
        long long9 = segment8.getSegmentCount();
        segment8.dec();
        boolean boolean11 = segment3.contains(segment8);
        try {
            org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) segment3, 12.0d, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.lang.Boolean boolean10 = xYBarRenderer0.getSeriesItemLabelsVisible(10);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint16 = xYBarRenderer15.getBaseOutlinePaint();
        java.awt.Shape shape22 = null;
        java.awt.Paint paint24 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color26 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape29 = null;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color33 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape22, false, paint24, false, (java.awt.Paint) color26, stroke27, true, shape29, stroke30, (java.awt.Paint) color33);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(0.0d, paint16, stroke30);
        double double36 = valueMarker35.getValue();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean39 = categoryPlot12.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker35, layer37, false);
        try {
            xYBarRenderer0.addAnnotation(xYAnnotation11, layer37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        long long4 = segment2.calculateSegmentNumber(0L);
        boolean boolean7 = segment2.contained((long) (byte) 100, (long) (byte) -1);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 25566L + "'", long4 == 25566L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Paint paint5 = xYBarRenderer3.getBasePaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer3.setSeriesItemLabelPaint(1, paint7);
        legendTitle1.setBackgroundPaint(paint7);
        org.jfree.chart.block.BlockContainer blockContainer10 = null;
        legendTitle1.setWrapper(blockContainer10);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 1577894400005L, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 1, true, true);
        java.lang.Number number5 = null;
        xYSeries3.add((java.lang.Number) (byte) -1, number5);
        xYSeries3.setNotify(true);
        try {
            java.lang.Number number10 = xYSeries3.getY(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 0, 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        java.awt.Font font5 = polarPlot4.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.DATASET_UPDATED", font5);
        java.awt.Graphics2D graphics2D7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = labelBlock6.arrange(graphics2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer0.setShadowYOffset((double) 0L);
        java.awt.Stroke stroke5 = xYBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.LegendItem legendItem8 = xYBarRenderer0.getLegendItem(0, 100);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(legendItem8);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter2 = xYBarRenderer0.getBarPainter();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYBarRenderer0.getNegativeItemLabelPosition((int) (byte) 100, (-1), true);
        java.awt.Paint paint8 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        xYBarRenderer0.setLegendTextPaint((int) (short) 1, paint8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYBarPainter2);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((-1.0d), (double) 100.0f, 1.0d, 12.0d, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        polarPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        polarPlot7.addChangeListener(plotChangeListener11);
        java.lang.String str13 = polarPlot7.getNoDataMessage();
        polarPlot7.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        try {
            polarPlot7.zoomRangeAxes((double) (byte) 1, (double) (short) 0, plotRenderingInfo18, point2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        java.util.Date date3 = null;
        try {
            segmentedTimeline0.addBaseTimelineException(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Paint paint5 = xYBarRenderer3.getBasePaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer3.setSeriesItemLabelPaint(1, paint7);
        legendTitle1.setBackgroundPaint(paint7);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.Range range12 = null;
        org.jfree.data.Range range14 = org.jfree.data.Range.expandToInclude(range12, (double) 100);
        double double15 = range14.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range18 = null;
        org.jfree.data.Range range19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range19, (double) 10.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType22 = rectangleConstraint21.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) '4', range14, lengthConstraintType16, (double) 12, range18, lengthConstraintType22);
        java.lang.Object obj24 = null;
        boolean boolean25 = range14.equals(obj24);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint(range14, (double) (byte) 10);
        try {
            org.jfree.chart.util.Size2D size2D28 = legendTitle1.arrange(graphics2D10, rectangleConstraint27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
        org.junit.Assert.assertNotNull(lengthConstraintType22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        int int2 = month0.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        try {
            java.util.Collection collection2 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list1);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getStart();
        java.util.Date date5 = month3.getEnd();
        java.util.Date date6 = month3.getStart();
        java.util.TimeZone timeZone7 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone7;
        java.util.Locale locale9 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("[100.0, 12.0]", (org.jfree.data.time.RegularTimePeriod) month1, (org.jfree.data.time.RegularTimePeriod) month3, timeZone7, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 11);
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter2 = xYBarRenderer0.getBarPainter();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYBarRenderer0.getNegativeItemLabelPosition((int) (byte) 100, (-1), true);
        xYBarRenderer0.setDefaultEntityRadius(4);
        xYBarRenderer0.setBaseItemLabelsVisible(true, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYBarPainter2);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) -1, false, false);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem5 = xYSeries3.getDataItem((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter2 = xYBarRenderer0.getBarPainter();
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(xYBarPainter2);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYBarPainter2);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        numberFormat0.setMinimumFractionDigits((int) 'a');
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10, seriesChangeInfo1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseOutlinePaint();
        java.awt.Paint paint3 = xYBarRenderer0.lookupSeriesPaint(10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline1.getSegment((long) (short) 100);
        boolean boolean5 = segmentedTimeline1.containsDomainValue((long) (short) 0);
        boolean boolean6 = segmentedTimeline1.getAdjustForDaylightSaving();
        long long7 = segmentedTimeline1.getSegmentSize();
        long long8 = segmentedTimeline1.getSegmentsIncludedSize();
        boolean boolean9 = itemLabelAnchor0.equals((java.lang.Object) long8);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 432000000L + "'", long8 == 432000000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        long long3 = segment2.getSegmentCount();
        long long4 = segment2.getSegmentCount();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segmentedTimeline5.getSegment((long) (short) 100);
        long long8 = segment7.getSegmentCount();
        segment7.dec();
        boolean boolean10 = segment2.contains(segment7);
        segment2.moveIndexToEnd();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(segment7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.lang.String[] strArray1 = null;
        try {
            org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("[100.0, 12.0]", strArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        state1.setLastPointGood(false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        int int1 = numberFormat0.getMinimumIntegerDigits();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.plot.XYPlot xYPlot3 = xYBarRenderer0.getPlot();
        double double4 = xYBarRenderer0.getMargin();
        org.junit.Assert.assertNull(xYPlot3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        long long3 = segment2.getSegmentCount();
        long long4 = segment2.getSegmentCount();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) long4);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.setNoDataMessage("ThreadContext");
        org.jfree.chart.plot.Plot plot6 = polarPlot3.getParent();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        try {
            polarPlot3.zoomRangeAxes((double) 4, plotRenderingInfo8, point2D9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset2);
        org.jfree.data.xy.XYDataItem xYDataItem6 = new org.jfree.data.xy.XYDataItem((double) 432000000L, (double) (-460));
        int int7 = defaultXYDataset2.indexOf((java.lang.Comparable) 432000000L);
        try {
            state1.startSeriesPass((org.jfree.data.xy.XYDataset) defaultXYDataset2, 6, (int) (short) -1, 0, 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color16 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape5, false, paint7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color16);
        java.lang.Object obj18 = null;
        boolean boolean19 = legendItem17.equals(obj18);
        java.lang.Object obj20 = legendItem17.clone();
        org.jfree.data.time.TimeSeries timeSeries21 = null;
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection(timeSeries21, timeZone22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset25, valueAxis26, polarItemRenderer27);
        timeSeriesCollection23.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot28);
        legendItem17.setDataset((org.jfree.data.general.Dataset) timeSeriesCollection23);
        try {
            double double33 = timeSeriesCollection23.getYValue(10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(range24);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.awt.Shape shape17 = null;
        java.awt.Paint paint19 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color21 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color28 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape17, false, paint19, false, (java.awt.Paint) color21, stroke22, true, shape24, stroke25, (java.awt.Paint) color28);
        java.lang.Object obj30 = null;
        boolean boolean31 = legendItem29.equals(obj30);
        java.awt.Paint paint32 = legendItem29.getFillPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape10, paint32);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        try {
            legendGraphic33.draw(graphics2D34, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarksVisible(false);
        java.lang.Comparable comparable3 = null;
        try {
            categoryAxis0.removeCategoryLabelToolTip(comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection2);
        org.jfree.data.general.DatasetGroup datasetGroup10 = timeSeriesCollection2.getGroup();
        try {
            double double13 = timeSeriesCollection2.getStartYValue((int) (short) 100, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(datasetGroup10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.lang.Class class0 = null;
        try {
            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer((int) (short) 10);
        categoryPlot0.setBackgroundImageAlignment(0);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo7);
        org.jfree.chart.entity.EntityCollection entityCollection9 = state8.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        java.awt.Shape shape19 = null;
        java.awt.Paint paint21 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color23 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape26 = null;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color30 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape19, false, paint21, false, (java.awt.Paint) color23, stroke24, true, shape26, stroke27, (java.awt.Paint) color30);
        java.lang.Object obj32 = null;
        boolean boolean33 = legendItem31.equals(obj32);
        java.lang.Object obj34 = legendItem31.clone();
        org.jfree.data.time.TimeSeries timeSeries35 = null;
        java.util.TimeZone timeZone36 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection37 = new org.jfree.data.time.TimeSeriesCollection(timeSeries35, timeZone36);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection37);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer41 = null;
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot(xYDataset39, valueAxis40, polarItemRenderer41);
        timeSeriesCollection37.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot42);
        legendItem31.setDataset((org.jfree.data.general.Dataset) timeSeriesCollection37);
        try {
            xYBarRenderer0.drawItem(graphics2D6, (org.jfree.chart.renderer.xy.XYItemRendererState) state8, rectangle2D10, xYPlot11, valueAxis12, valueAxis13, (org.jfree.data.xy.XYDataset) timeSeriesCollection37, (int) '#', 6, false, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(entityCollection9);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(range38);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#', 2, 64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        boolean boolean1 = numberFormat0.isParseIntegerOnly();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        org.jfree.data.time.TimeSeries timeSeries2 = null;
        java.util.TimeZone timeZone3 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection(timeSeries2, timeZone3);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset6, valueAxis7, polarItemRenderer8);
        timeSeriesCollection4.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection4);
        org.jfree.data.general.DatasetGroup datasetGroup12 = timeSeriesCollection4.getGroup();
        try {
            state1.startSeriesPass((org.jfree.data.xy.XYDataset) timeSeriesCollection4, 3, (int) (byte) 100, 9999, 64, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(datasetGroup12);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = xYBarRenderer1.getBaseOutlinePaint();
        java.awt.Shape shape8 = null;
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color19 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape8, false, paint10, false, (java.awt.Paint) color12, stroke13, true, shape15, stroke16, (java.awt.Paint) color19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, paint2, stroke16);
        double double22 = valueMarker21.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection24 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo(entityCollection24);
        boolean boolean26 = chartChangeEventType23.equals((java.lang.Object) entityCollection24);
        java.lang.String str27 = chartChangeEventType23.toString();
        boolean boolean28 = valueMarker21.equals((java.lang.Object) chartChangeEventType23);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot(xYDataset29, valueAxis30, polarItemRenderer31);
        boolean boolean33 = polarPlot32.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent34 = null;
        polarPlot32.datasetChanged(datasetChangeEvent34);
        java.awt.Font font36 = polarPlot32.getNoDataMessageFont();
        valueMarker21.setLabelFont(font36);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str27.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(font36);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getNumberFormat();
        numberFormat1.setGroupingUsed(false);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.ui.ProjectInfo projectInfo30 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list31 = projectInfo30.getContributors();
        try {
            categoryPlot0.mapDatasetToDomainAxes((int) (short) -1, list31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(legendItemCollection28);
        org.junit.Assert.assertNotNull(projectInfo30);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(2, 2, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Font font4 = polarPlot3.getNoDataMessageFont();
        org.jfree.data.xy.XYDataset xYDataset5 = polarPlot3.getDataset();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(xYDataset5);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        boolean boolean2 = legendTitle1.isVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double9 = categoryAxis0.getCategoryMiddle(15, 0, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 15");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.setNoDataMessage("ThreadContext");
        java.awt.Paint paint6 = polarPlot3.getRadiusGridlinePaint();
        boolean boolean7 = polarPlot3.isRadiusGridlinesVisible();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 100);
        double double4 = range3.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range8, (double) 10.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = rectangleConstraint10.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '4', range3, lengthConstraintType5, (double) 12, range7, lengthConstraintType11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint12.toFixedWidth(0.0d);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.awt.Shape shape6 = null;
        java.awt.Paint paint8 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color10 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape13 = null;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color17 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape6, false, paint8, false, (java.awt.Paint) color10, stroke11, true, shape13, stroke14, (java.awt.Paint) color17);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint20 = xYBarRenderer19.getBaseOutlinePaint();
        legendItem18.setLinePaint(paint20);
        java.lang.Object obj22 = legendItem18.clone();
        boolean boolean23 = legendItemCollection0.equals(obj22);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        java.io.ObjectOutputStream objectOutputStream2 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color1, objectOutputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        java.awt.geom.GeneralPath generalPath2 = null;
        state1.seriesPath = generalPath2;
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.awt.Shape shape17 = null;
        java.awt.Paint paint19 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color21 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color28 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape17, false, paint19, false, (java.awt.Paint) color21, stroke22, true, shape24, stroke25, (java.awt.Paint) color28);
        java.lang.Object obj30 = null;
        boolean boolean31 = legendItem29.equals(obj30);
        java.awt.Paint paint32 = legendItem29.getFillPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape10, paint32);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.data.Range range35 = null;
        org.jfree.data.Range range37 = org.jfree.data.Range.expandToInclude(range35, (double) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint(range37, 0.0d);
        try {
            org.jfree.chart.util.Size2D size2D40 = legendGraphic33.arrange(graphics2D34, rectangleConstraint39);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(range37);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 100);
        pieLabelDistributor1.distributeLabels((double) 4, (double) 1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("ClassContext", "100", "", "[100.0, 12.0]");
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        java.util.Date date2 = month0.getEnd();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter2 = xYBarRenderer0.getBarPainter();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYBarRenderer0.getNegativeItemLabelPosition((int) (byte) 100, (-1), true);
        xYBarRenderer0.setDefaultEntityRadius(4);
        java.awt.Shape shape9 = null;
        try {
            xYBarRenderer0.setLegendBar(shape9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bar' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYBarPainter2);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        java.lang.String str1 = dateTickUnitType0.toString();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline2.getSegment((long) (short) 100);
        long long5 = segment4.getSegmentCount();
        long long6 = segment4.getSegmentCount();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segmentedTimeline7.getSegment((long) (short) 100);
        long long10 = segment9.getSegmentCount();
        segment9.dec();
        boolean boolean12 = segment4.contains(segment9);
        long long13 = segment9.getSegmentEnd();
        boolean boolean14 = dateTickUnitType0.equals((java.lang.Object) long13);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnitType.DAY" + "'", str1.equals("DateTickUnitType.DAY"));
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(segmentedTimeline7);
        org.junit.Assert.assertNotNull(segment9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-57600001L) + "'", long13 == (-57600001L));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 3, 0.0f);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        polarPlot7.removeCornerTextItem("DateTickUnitType.DAY");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        try {
            polarPlot7.zoomRangeAxes((double) 15, plotRenderingInfo12, point2D13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        int int2 = defaultXYDataset0.getSeriesCount();
        try {
            java.lang.Comparable comparable4 = defaultXYDataset0.getSeriesKey(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        boolean boolean12 = xYBarRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Stroke stroke4 = xYBarRenderer0.getItemStroke((int) 'a', (int) '#', true);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        polarPlot8.setNoDataMessage("ThreadContext");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        polarPlot8.setRenderer(polarItemRenderer11);
        boolean boolean13 = xYBarRenderer0.hasListener((java.util.EventListener) polarPlot8);
        java.awt.Paint paint14 = null;
        try {
            xYBarRenderer0.setBaseItemLabelPaint(paint14, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = null;
        try {
            blockContainer0.setArrangement(arrangement1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Paint paint5 = xYBarRenderer3.getBasePaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer3.setSeriesItemLabelPaint(1, paint7);
        legendTitle1.setBackgroundPaint(paint7);
        boolean boolean10 = legendTitle1.isVisible();
        legendTitle1.setPadding((double) 100, (double) (byte) 10, (double) 9999, (double) 100.0f);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot17.getRangeMarkers((int) '4', layer19);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries22 = null;
        java.util.TimeZone timeZone23 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeSeries22, timeZone23);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection24, true);
        org.jfree.data.Range range28 = xYBarRenderer21.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent29 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot17, (org.jfree.data.general.Dataset) timeSeriesCollection24);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource32 = null;
        chartRenderingInfo31.setRenderingSource(renderingSource32);
        java.awt.geom.Rectangle2D rectangle2D34 = chartRenderingInfo31.getChartArea();
        java.awt.geom.Point2D point2D35 = null;
        org.jfree.chart.plot.PlotState plotState36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        categoryPlot17.draw(graphics2D30, rectangle2D34, point2D35, plotState36, plotRenderingInfo37);
        java.util.TimeZone timeZone39 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        try {
            java.lang.Object obj40 = legendTitle1.draw(graphics2D16, rectangle2D34, (java.lang.Object) timeZone39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(timeZone39);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1, timeZone2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        timeSeriesCollection3.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = null;
        polarPlot8.setDrawingSupplier(drawingSupplier10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        polarPlot8.addChangeListener(plotChangeListener12);
        java.lang.String str14 = polarPlot8.getNoDataMessage();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) polarPlot8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        try {
            polarPlot8.zoomRangeAxes(1.0d, plotRenderingInfo17, point2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        boolean boolean10 = intervalXYDelegate9.isAutoWidth();
        try {
            double double13 = intervalXYDelegate9.getStartXValue(9999, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number3 = xYDataItem2.getX();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getStart();
        java.util.Date date9 = month7.getEnd();
        java.util.Date date10 = month7.getStart();
        try {
            timeSeries6.update((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.awt.Shape shape17 = null;
        java.awt.Paint paint19 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color21 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color28 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape17, false, paint19, false, (java.awt.Paint) color21, stroke22, true, shape24, stroke25, (java.awt.Paint) color28);
        java.lang.Object obj30 = null;
        boolean boolean31 = legendItem29.equals(obj30);
        java.awt.Paint paint32 = legendItem29.getFillPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape10, paint32);
        java.awt.Paint paint34 = legendGraphic33.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(paint34);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("SerialDate.weekInMonthToString(): invalid code.", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("October", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.plot.XYPlot xYPlot3 = xYBarRenderer0.getPlot();
        java.awt.Color color4 = java.awt.Color.yellow;
        xYBarRenderer0.setBasePaint((java.awt.Paint) color4, true);
        org.junit.Assert.assertNull(xYPlot3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        java.awt.Image image2 = null;
        projectInfo0.setLogo(image2);
        projectInfo0.setCopyright("ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Paint paint5 = xYBarRenderer3.getBasePaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer3.setSeriesItemLabelPaint(1, paint7);
        legendTitle1.setBackgroundPaint(paint7);
        org.jfree.chart.block.BlockContainer blockContainer10 = legendTitle1.getWrapper();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis12.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource15 = null;
        chartRenderingInfo14.setRenderingSource(renderingSource15);
        java.awt.geom.Rectangle2D rectangle2D17 = chartRenderingInfo14.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets13.createInsetRectangle(rectangle2D17, false, false);
        try {
            legendTitle1.draw(graphics2D11, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(blockContainer10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        try {
            java.awt.Color color1 = java.awt.Color.decode("ChartChangeEventType.DATASET_UPDATED");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ChartChangeEventType.DATASET_UPDATED\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (short) 100, (float) 5, (double) 1.0f, 10.0f, (float) (short) 100);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 100);
        pieLabelDistributor1.distributeLabels((double) 3, (double) 1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        java.lang.String str1 = tickType0.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAJOR" + "'", str1.equals("MAJOR"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3);
        try {
            int int8 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) timeSeriesCollection4, 100, (double) 1.0f, (double) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (100).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((double) 432000000L, (double) (-460));
        int int5 = defaultXYDataset0.indexOf((java.lang.Comparable) 432000000L);
        try {
            int int7 = defaultXYDataset0.getItemCount(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape1);
        java.lang.Object obj3 = chartEntity2.clone();
        java.awt.Shape shape4 = chartEntity2.getArea();
        java.lang.String str5 = chartEntity2.getURLText();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) -1, 28, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, true);
        org.jfree.data.Range range11 = xYBarRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot0, (org.jfree.data.general.Dataset) timeSeriesCollection7);
        try {
            java.lang.Comparable comparable14 = timeSeriesCollection7.getSeriesKey(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (11).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1, timeZone2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3, true);
        org.jfree.data.Range range7 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        try {
            timeSeriesCollection3.removeSeries(28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (28).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection4.getSeries((int) (byte) 0);
        try {
            java.lang.Number number9 = timeSeriesCollection4.getY(0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 100);
        double double3 = range2.getLength();
        double double4 = range2.getCentralValue();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        java.lang.Object obj1 = chartRenderingInfo0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        polarPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        polarPlot7.addChangeListener(plotChangeListener11);
        java.lang.String str13 = polarPlot7.getNoDataMessage();
        polarPlot7.setForegroundAlpha(0.5f);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.util.Date date6 = month5.getStart();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) (short) 0);
        java.lang.String str10 = month5.toString();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        try {
            org.jfree.data.time.TimeSeries timeSeries4 = timeSeriesCollection2.getSeries(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation28 = null;
        try {
            boolean boolean29 = categoryPlot0.removeAnnotation(categoryAnnotation28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color16 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape5, false, paint7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color16);
        java.lang.Object obj18 = null;
        boolean boolean19 = legendItem17.equals(obj18);
        java.awt.Shape shape25 = null;
        java.awt.Paint paint27 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color29 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape32 = null;
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color36 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape25, false, paint27, false, (java.awt.Paint) color29, stroke30, true, shape32, stroke33, (java.awt.Paint) color36);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer38 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint39 = xYBarRenderer38.getBaseOutlinePaint();
        legendItem37.setLinePaint(paint39);
        legendItem17.setLabelPaint(paint39);
        legendItem17.setURLText("ThreadContext");
        java.lang.String str44 = legendItem17.getDescription();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape14 = null;
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color25 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape14, false, paint16, false, (java.awt.Paint) color18, stroke19, true, shape21, stroke22, (java.awt.Paint) color25);
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem26.setLabelPaint(paint27);
        xYBarRenderer0.setBaseLegendTextPaint(paint27);
        java.awt.Stroke stroke31 = null;
        try {
            xYBarRenderer0.setSeriesOutlineStroke((int) (byte) -1, stroke31, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.lang.Comparable[] comparableArray0 = null;
        java.lang.String[] strArray2 = org.jfree.data.time.SerialDate.getMonths(false);
        double[] doubleArray4 = new double[] { 28 };
        double[] doubleArray6 = new double[] { 28 };
        double[][] doubleArray7 = new double[][] { doubleArray4, doubleArray6 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, (java.lang.Comparable[]) strArray2, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1, timeZone2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3, true);
        org.jfree.data.Range range7 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        try {
            double double10 = timeSeriesCollection3.getStartXValue(5, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        int int3 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        try {
            int[] intArray6 = timeSeriesCollection2.getSurroundingItems((int) '4', 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (52).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        long long3 = segment2.getSegmentCount();
        boolean boolean4 = segment2.inExceptionSegments();
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) segment2, false);
        double double7 = xYSeries6.getMaxX();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer0.setShadowYOffset((double) 0L);
        java.awt.Stroke stroke5 = xYBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = xYBarRenderer0.getSeriesItemLabelGenerator(4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(xYItemLabelGenerator7);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer1.setShadowYOffset((double) 0L);
        xYBarRenderer1.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer1.setBaseOutlinePaint((java.awt.Paint) color8);
        boolean boolean10 = standardXYToolTipGenerator0.equals((java.lang.Object) xYBarRenderer1);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset11 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset11);
        try {
            java.lang.String str15 = standardXYToolTipGenerator0.generateLabelString((org.jfree.data.xy.XYDataset) defaultXYDataset11, 100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = xYBarRenderer1.getBaseOutlinePaint();
        java.awt.Shape shape8 = null;
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color19 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape8, false, paint10, false, (java.awt.Paint) color12, stroke13, true, shape15, stroke16, (java.awt.Paint) color19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, paint2, stroke16);
        float float22 = valueMarker21.getAlpha();
        java.awt.Stroke stroke23 = valueMarker21.getStroke();
        java.awt.Paint paint24 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        boolean boolean25 = valueMarker21.equals((java.lang.Object) paint24);
        java.awt.Paint paint26 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        valueMarker21.setLabelPaint(paint26);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        boolean boolean34 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot(pieDataset35);
        java.awt.Stroke stroke37 = piePlot36.getLabelLinkStroke();
        java.awt.Font font38 = piePlot36.getLabelFont();
        categoryPlot0.setNoDataMessageFont(font38);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_ITEM_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "item" + "'", str0.equals("item"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, true);
        org.jfree.data.Range range11 = xYBarRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot0, (org.jfree.data.general.Dataset) timeSeriesCollection7);
        try {
            java.lang.Number number15 = timeSeriesCollection7.getY(28, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 28, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = xYBarRenderer1.getBaseOutlinePaint();
        java.awt.Shape shape8 = null;
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color19 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape8, false, paint10, false, (java.awt.Paint) color12, stroke13, true, shape15, stroke16, (java.awt.Paint) color19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, paint2, stroke16);
        double double22 = valueMarker21.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection24 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo(entityCollection24);
        boolean boolean26 = chartChangeEventType23.equals((java.lang.Object) entityCollection24);
        java.lang.String str27 = chartChangeEventType23.toString();
        boolean boolean28 = valueMarker21.equals((java.lang.Object) chartChangeEventType23);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot(xYDataset29, valueAxis30, polarItemRenderer31);
        polarPlot32.setNoDataMessage("ThreadContext");
        java.awt.Paint paint35 = polarPlot32.getRadiusGridlinePaint();
        valueMarker21.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot32);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType37 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker21.setLabelOffsetType(lengthAdjustmentType37);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str27.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(lengthAdjustmentType37);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.panRangeAxes((double) 3, plotRenderingInfo35, point2D36);
        org.jfree.chart.util.SortOrder sortOrder38 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape14 = null;
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color25 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape14, false, paint16, false, (java.awt.Paint) color18, stroke19, true, shape21, stroke22, (java.awt.Paint) color25);
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem26.setLabelPaint(paint27);
        xYBarRenderer0.setBaseLegendTextPaint(paint27);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator30 = null;
        try {
            xYBarRenderer0.setLegendItemLabelGenerator(xYSeriesLabelGenerator30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Paint paint5 = xYBarRenderer3.getBasePaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer3.setSeriesItemLabelPaint(1, paint7);
        legendTitle1.setBackgroundPaint(paint7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = legendTitle1.getHorizontalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendTitle13.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint16 = xYBarRenderer15.getBaseOutlinePaint();
        java.awt.Paint paint17 = xYBarRenderer15.getBasePaint();
        java.awt.Paint paint19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer15.setSeriesItemLabelPaint(1, paint19);
        legendTitle13.setBackgroundPaint(paint19);
        org.jfree.chart.block.BlockContainer blockContainer22 = legendTitle13.getWrapper();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        legendTitle13.setLegendItemGraphicLocation(rectangleAnchor23);
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor23);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(blockContainer22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        java.awt.Shape shape6 = xYBarRenderer0.getBaseLegendShape();
        java.awt.Paint paint8 = xYBarRenderer0.getLegendTextPaint(6);
        java.awt.Font font10 = xYBarRenderer0.getLegendTextFont((int) (byte) 100);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(font10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "item", keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.panRangeAxes((double) 3, plotRenderingInfo35, point2D36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset40 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer41 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot42 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset40, waferMapRenderer41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer46 = null;
        org.jfree.chart.plot.PolarPlot polarPlot47 = new org.jfree.chart.plot.PolarPlot(xYDataset44, valueAxis45, polarItemRenderer46);
        boolean boolean48 = polarPlot47.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent49 = null;
        polarPlot47.datasetChanged(datasetChangeEvent49);
        java.awt.Font font51 = polarPlot47.getNoDataMessageFont();
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer55 = null;
        java.util.Collection collection56 = categoryPlot53.getRangeMarkers((int) '4', layer55);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer57 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries58 = null;
        java.util.TimeZone timeZone59 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection60 = new org.jfree.data.time.TimeSeriesCollection(timeSeries58, timeZone59);
        org.jfree.data.Range range61 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection60);
        org.jfree.data.Range range63 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection60, true);
        org.jfree.data.Range range64 = xYBarRenderer57.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection60);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent65 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot53, (org.jfree.data.general.Dataset) timeSeriesCollection60);
        java.awt.Graphics2D graphics2D66 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo67 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource68 = null;
        chartRenderingInfo67.setRenderingSource(renderingSource68);
        java.awt.geom.Rectangle2D rectangle2D70 = chartRenderingInfo67.getChartArea();
        java.awt.geom.Point2D point2D71 = null;
        org.jfree.chart.plot.PlotState plotState72 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        categoryPlot53.draw(graphics2D66, rectangle2D70, point2D71, plotState72, plotRenderingInfo73);
        java.awt.geom.Point2D point2D75 = null;
        org.jfree.chart.plot.PlotState plotState76 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo77 = null;
        polarPlot47.draw(graphics2D52, rectangle2D70, point2D75, plotState76, plotRenderingInfo77);
        java.awt.geom.Point2D point2D79 = null;
        org.jfree.chart.plot.PlotState plotState80 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo81 = null;
        waferMapPlot42.draw(graphics2D43, rectangle2D70, point2D79, plotState80, plotRenderingInfo81);
        java.awt.geom.Point2D point2D83 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo84 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean86 = chartRenderingInfo84.equals((java.lang.Object) 0L);
        try {
            jFreeChart38.draw(graphics2D39, rectangle2D70, point2D83, chartRenderingInfo84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNull(collection56);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(range61);
        org.junit.Assert.assertNull(range63);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("[100.0, 12.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        java.awt.Font font6 = polarPlot5.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("ChartChangeEventType.DATASET_UPDATED", font6);
        java.awt.Color color8 = java.awt.Color.YELLOW;
        java.awt.Color color9 = color8.brighter();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("[100.0, 12.0]", font6, (java.awt.Paint) color8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis12.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource15 = null;
        chartRenderingInfo14.setRenderingSource(renderingSource15);
        java.awt.geom.Rectangle2D rectangle2D17 = chartRenderingInfo14.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets13.createInsetRectangle(rectangle2D17, false, false);
        try {
            labelBlock10.draw(graphics2D11, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getSegmentsIncluded();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) (short) 100, 0.0d, (double) 1);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint6 = xYBarRenderer5.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter7 = xYBarRenderer5.getBarPainter();
        java.awt.Shape shape13 = null;
        java.awt.Paint paint15 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color17 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color24 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape13, false, paint15, false, (java.awt.Paint) color17, stroke18, true, shape20, stroke21, (java.awt.Paint) color24);
        java.awt.Paint paint26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem25.setLabelPaint(paint26);
        xYBarRenderer5.setBasePaint(paint26, false);
        org.jfree.chart.LegendItem legendItem32 = xYBarRenderer5.getLegendItem(9999, 12);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource41 = null;
        chartRenderingInfo40.setRenderingSource(renderingSource41);
        java.awt.geom.Rectangle2D rectangle2D43 = chartRenderingInfo40.getChartArea();
        org.jfree.chart.axis.AxisState axisState44 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        axisState44.moveCursor((double) 0, rectangleEdge46);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState44.moveCursor((double) 100L, rectangleEdge49);
        double double51 = categoryAxis36.getCategoryJava2DCoordinate(categoryAnchor37, 10, (int) (short) 0, rectangle2D43, rectangleEdge49);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor53 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo56 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource57 = null;
        chartRenderingInfo56.setRenderingSource(renderingSource57);
        java.awt.geom.Rectangle2D rectangle2D59 = chartRenderingInfo56.getChartArea();
        org.jfree.chart.axis.AxisState axisState60 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = null;
        axisState60.moveCursor((double) 0, rectangleEdge62);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState60.moveCursor((double) 100L, rectangleEdge65);
        double double67 = categoryAxis52.getCategoryJava2DCoordinate(categoryAnchor53, 10, (int) (short) 0, rectangle2D59, rectangleEdge65);
        try {
            gradientXYBarPainter3.paintBarShadow(graphics2D4, xYBarRenderer5, 0, (int) (short) 1, false, (java.awt.geom.RectangularShape) rectangle2D43, rectangleEdge65, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(xYBarPainter7);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(legendItem32);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer0.setShadowYOffset((double) 0L);
        xYBarRenderer0.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource16 = null;
        chartRenderingInfo15.setRenderingSource(renderingSource16);
        java.awt.geom.Rectangle2D rectangle2D18 = chartRenderingInfo15.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets14.createInsetRectangle(rectangle2D18, false, false);
        try {
            xYBarRenderer0.drawDomainGridLine(graphics2D10, xYPlot11, valueAxis12, rectangle2D18, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Paint paint5 = xYBarRenderer3.getBasePaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer3.setSeriesItemLabelPaint(1, paint7);
        legendTitle1.setBackgroundPaint(paint7);
        boolean boolean10 = legendTitle1.isVisible();
        org.jfree.chart.block.BlockContainer blockContainer11 = null;
        legendTitle1.setWrapper(blockContainer11);
        java.awt.Font font13 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        legendTitle1.setItemFont(font13);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.TimeSeries timeSeries3 = null;
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3, timeZone4);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone4;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date2, timeZone4, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 1, true, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((java.lang.Number) (byte) 0, (java.lang.Number) 8);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        xYSeries3.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertNull(xYDataItem6);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, true);
        org.jfree.data.Range range11 = xYBarRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot0, (org.jfree.data.general.Dataset) timeSeriesCollection7);
        java.awt.Stroke stroke13 = categoryPlot0.getDomainGridlineStroke();
        int int14 = categoryPlot0.getWeight();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) int14);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        polarPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        polarPlot7.addChangeListener(plotChangeListener11);
        java.lang.String str13 = polarPlot7.getNoDataMessage();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        polarPlot7.zoomDomainAxes((double) 11, plotRenderingInfo15, point2D16, false);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate4);
        try {
            org.jfree.data.time.SerialDate serialDate7 = serialDate5.getPreviousDayOfWeek(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("MAJOR", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 100);
        double double4 = range3.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range8, (double) 10.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = rectangleConstraint10.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '4', range3, lengthConstraintType5, (double) 12, range7, lengthConstraintType11);
        java.lang.String str13 = lengthConstraintType11.toString();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleConstraintType.RANGE" + "'", str13.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color16 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape5, false, paint7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color16);
        java.lang.Object obj18 = null;
        boolean boolean19 = legendItem17.equals(obj18);
        java.lang.Comparable comparable20 = null;
        legendItem17.setSeriesKey(comparable20);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseOutlinePaint();
        java.awt.Paint paint2 = xYBarRenderer0.getBasePaint();
        java.awt.Font font4 = xYBarRenderer0.getSeriesItemLabelFont((int) (byte) 0);
        java.awt.Paint paint5 = xYBarRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (short) 1, xYToolTipGenerator7, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYBarRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(itemLabelPosition10);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer1.setShadowYOffset((double) 0L);
        xYBarRenderer1.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer1.setBaseOutlinePaint((java.awt.Paint) color8);
        boolean boolean10 = standardXYToolTipGenerator0.equals((java.lang.Object) xYBarRenderer1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint12 = xYBarRenderer11.getBaseItemLabelPaint();
        boolean boolean16 = xYBarRenderer11.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        xYBarRenderer11.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator18);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer11.setBaseLegendShape(shape21);
        java.awt.Shape shape28 = null;
        java.awt.Paint paint30 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color32 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape35 = null;
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color39 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape28, false, paint30, false, (java.awt.Paint) color32, stroke33, true, shape35, stroke36, (java.awt.Paint) color39);
        java.lang.Object obj41 = null;
        boolean boolean42 = legendItem40.equals(obj41);
        java.awt.Paint paint43 = legendItem40.getFillPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic44 = new org.jfree.chart.title.LegendGraphic(shape21, paint43);
        java.awt.Shape shape45 = legendGraphic44.getShape();
        xYBarRenderer1.setLegendBar(shape45);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(shape45);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color16 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape5, false, paint7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color16);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint19 = xYBarRenderer18.getBaseOutlinePaint();
        legendItem17.setLinePaint(paint19);
        java.awt.Paint paint21 = legendItem17.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxisForDataset((int) 'a');
        java.awt.Stroke stroke3 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        boolean boolean4 = segmentedTimeline0.containsDomainValue((long) (short) 0);
        boolean boolean5 = segmentedTimeline0.getAdjustForDaylightSaving();
        long long6 = segmentedTimeline0.getSegmentSize();
        long long7 = segmentedTimeline0.getSegmentsIncludedSize();
        boolean boolean9 = segmentedTimeline0.containsDomainValue(0L);
        segmentedTimeline0.setStartTime((long) 12);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86400000L + "'", long6 == 86400000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 432000000L + "'", long7 == 432000000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        int int30 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Paint paint5 = xYBarRenderer3.getBasePaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer3.setSeriesItemLabelPaint(1, paint7);
        legendTitle1.setBackgroundPaint(paint7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = legendTitle1.getHorizontalAlignment();
        java.lang.String str11 = horizontalAlignment10.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "HorizontalAlignment.CENTER" + "'", str11.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        float float5 = polarPlot4.getBackgroundImageAlpha();
        xYBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot4);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor8 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor8, textAnchor9, textAnchor10, (double) '#');
        xYBarRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 0, itemLabelPosition12, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor15 = itemLabelPosition12.getItemLabelAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor16 = itemLabelPosition12.getItemLabelAnchor();
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(itemLabelAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(itemLabelAnchor15);
        org.junit.Assert.assertNotNull(itemLabelAnchor16);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape14 = null;
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color25 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape14, false, paint16, false, (java.awt.Paint) color18, stroke19, true, shape21, stroke22, (java.awt.Paint) color25);
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem26.setLabelPaint(paint27);
        xYBarRenderer0.setBaseLegendTextPaint(paint27);
        java.awt.Stroke stroke31 = xYBarRenderer0.lookupSeriesOutlineStroke((int) (byte) 100);
        xYBarRenderer0.setShadowYOffset(0.0d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, true);
        org.jfree.data.general.DatasetGroup datasetGroup6 = timeSeriesCollection2.getGroup();
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        try {
            org.jfree.data.time.TimeSeries timeSeries9 = timeSeriesCollection2.getSeries(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (6).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(datasetGroup6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        long long4 = segmentedTimeline0.toTimelineValue((long) 5);
        segmentedTimeline0.setStartTime((long) 5);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577894400005L + "'", long4 == 1577894400005L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        java.awt.Paint paint5 = categoryAxis0.getAxisLinePaint();
        java.lang.String str7 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 1);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter2 = xYBarRenderer0.getBarPainter();
        java.awt.Paint paint3 = null;
        try {
            xYBarRenderer0.setBaseFillPaint(paint3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYBarPainter2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator0 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8);
        boolean boolean10 = categoryPlot0.isOutlineVisible();
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke11);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone1;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1);
        long long4 = month3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.CENTER" + "'", str1.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator2);
        int int4 = piePlot1.getPieIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection2);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertEquals((double) number10, Double.NaN, 0);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, (double) 7, (double) 1577894400001L, (double) (-1), (double) 0.5f, font5);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str1.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, 0.0d, 0.0f, (float) (byte) 10);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.String str1 = rectangleAnchor0.toString();
        java.lang.String str2 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str1.equals("RectangleAnchor.BOTTOM"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str2.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = null;
        xYBarRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator3, true);
        java.awt.Paint paint7 = xYBarRenderer0.getSeriesPaint(0);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.lang.String str2 = textFragment1.getText();
        java.awt.Font font3 = textFragment1.getFont();
        java.awt.Paint paint4 = textFragment1.getPaint();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        try {
            defaultPieDataset0.insertValue((int) (short) 100, (java.lang.Comparable) 10.0f, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 100);
        int int2 = pieLabelDistributor1.getItemCount();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str3 = projectInfo2.toString();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        java.lang.String str5 = projectInfo0.getName();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer6.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer6.setShadowYOffset((double) 0L);
        xYBarRenderer6.setShadowXOffset(100.0d);
        boolean boolean13 = xYBarRenderer6.getBaseItemLabelsVisible();
        boolean boolean14 = projectInfo0.equals((java.lang.Object) boolean13);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JFreeChart" + "'", str5.equals("JFreeChart"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource8 = null;
        chartRenderingInfo7.setRenderingSource(renderingSource8);
        java.awt.geom.Rectangle2D rectangle2D10 = chartRenderingInfo7.getChartArea();
        org.jfree.chart.axis.AxisState axisState11 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        axisState11.moveCursor((double) 0, rectangleEdge13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState11.moveCursor((double) 100L, rectangleEdge16);
        double double18 = categoryAxis3.getCategoryJava2DCoordinate(categoryAnchor4, 10, (int) (short) 0, rectangle2D10, rectangleEdge16);
        org.jfree.data.general.WaferMapDataset waferMapDataset19 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset19, waferMapRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot(xYDataset23, valueAxis24, polarItemRenderer25);
        boolean boolean27 = polarPlot26.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = null;
        polarPlot26.datasetChanged(datasetChangeEvent28);
        java.awt.Font font30 = polarPlot26.getNoDataMessageFont();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot32.getRangeMarkers((int) '4', layer34);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries37 = null;
        java.util.TimeZone timeZone38 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection39 = new org.jfree.data.time.TimeSeriesCollection(timeSeries37, timeZone38);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection39);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection39, true);
        org.jfree.data.Range range43 = xYBarRenderer36.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection39);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot32, (org.jfree.data.general.Dataset) timeSeriesCollection39);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource47 = null;
        chartRenderingInfo46.setRenderingSource(renderingSource47);
        java.awt.geom.Rectangle2D rectangle2D49 = chartRenderingInfo46.getChartArea();
        java.awt.geom.Point2D point2D50 = null;
        org.jfree.chart.plot.PlotState plotState51 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        categoryPlot32.draw(graphics2D45, rectangle2D49, point2D50, plotState51, plotRenderingInfo52);
        java.awt.geom.Point2D point2D54 = null;
        org.jfree.chart.plot.PlotState plotState55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        polarPlot26.draw(graphics2D31, rectangle2D49, point2D54, plotState55, plotRenderingInfo56);
        java.awt.geom.Point2D point2D58 = null;
        org.jfree.chart.plot.PlotState plotState59 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        waferMapPlot21.draw(graphics2D22, rectangle2D49, point2D58, plotState59, plotRenderingInfo60);
        org.jfree.chart.axis.AxisState axisState62 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        axisState62.moveCursor((double) 0, rectangleEdge64);
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState62.moveCursor((double) 100L, rectangleEdge67);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        try {
            org.jfree.chart.axis.AxisState axisState70 = categoryAxis3D0.draw(graphics2D1, (double) (short) 10, rectangle2D10, rectangle2D49, rectangleEdge67, plotRenderingInfo69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(range40);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangleEdge67);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        try {
            double double6 = timeSeriesCollection2.getXValue((int) 'a', (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Stroke stroke4 = xYBarRenderer0.getItemStroke((int) 'a', (int) '#', true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator5 = null;
        xYBarRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator5, false);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 1, true, true);
        xYSeries3.add((double) 0L, (double) (short) -1);
        xYSeries3.add((java.lang.Number) (byte) 0, (java.lang.Number) 64, true);
        xYSeries3.add((java.lang.Number) 1577894400005L, (java.lang.Number) 9999);
        try {
            xYSeries3.updateByIndex((int) (short) -1, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        float float5 = polarPlot4.getBackgroundImageAlpha();
        xYBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot4);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor8 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor8, textAnchor9, textAnchor10, (double) '#');
        xYBarRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 0, itemLabelPosition12, false);
        org.jfree.chart.LegendItem legendItem17 = xYBarRenderer0.getLegendItem((-460), 1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(itemLabelAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNull(legendItem17);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape1);
        java.lang.Object obj3 = chartEntity2.clone();
        java.awt.Shape shape4 = chartEntity2.getArea();
        java.awt.Shape shape5 = chartEntity2.getArea();
        chartEntity2.setURLText("Other");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer1.setShadowYOffset((double) 0L);
        xYBarRenderer1.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer1.setBaseOutlinePaint((java.awt.Paint) color8);
        boolean boolean10 = standardXYToolTipGenerator0.equals((java.lang.Object) xYBarRenderer1);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries14);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeriesCollection15.getSeries((int) (byte) 0);
        try {
            java.lang.String str20 = standardXYToolTipGenerator0.generateToolTip((org.jfree.data.xy.XYDataset) timeSeriesCollection15, (int) (byte) -1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (-1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer0.setShadowYOffset((double) 0L);
        xYBarRenderer0.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color7);
        int int9 = color7.getTransparency();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Paint paint4 = polarPlot3.getBackgroundPaint();
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8);
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot13.getRangeMarkers((int) '4', layer15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot13.setDomainAxis((int) (short) 0, categoryAxis18, true);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        categoryPlot13.setFixedRangeAxisSpace(axisSpace21);
        double double23 = categoryPlot13.getAnchorValue();
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot13.setRangeAxisLocation(axisLocation24);
        categoryPlot0.setRangeAxisLocation(0, axisLocation24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot0.panDomainAxes(0.0d, plotRenderingInfo28, point2D29);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number3 = xYDataItem2.getX();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset7.removeSeries((java.lang.Comparable) 'a');
        timeSeries6.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset7);
        org.jfree.data.time.TimeSeries timeSeries11 = null;
        java.util.TimeZone timeZone12 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries11, timeZone12);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection13, true);
        timeSeries6.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection13);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries6.getTimePeriod(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.addChangeListener(plotChangeListener3);
        org.jfree.data.general.PieDataset pieDataset5 = piePlot1.getDataset();
        boolean boolean6 = piePlot1.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        java.awt.Font font5 = polarPlot4.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("ChartChangeEventType.DATASET_UPDATED", font5);
        org.jfree.chart.text.TextFragment textFragment7 = textLine6.getFirstTextFragment();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor9, textAnchor10, textAnchor11, (double) '#');
        try {
            float float14 = textFragment7.calculateBaselineOffset(graphics2D8, textAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(textFragment7);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = state1.getEntityCollection();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState3 = state1.getSelectionState();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState4 = state1.getSelectionState();
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState5 = null;
        state1.setCrosshairState(xYCrosshairState5);
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertNull(xYDatasetSelectionState3);
        org.junit.Assert.assertNull(xYDatasetSelectionState4);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.plot.XYPlot xYPlot3 = xYBarRenderer0.getPlot();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator5 = null;
        xYBarRenderer0.setSeriesItemLabelGenerator((int) (byte) 100, xYItemLabelGenerator5);
        org.junit.Assert.assertNull(xYPlot3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Stroke stroke2 = null;
        try {
            combinedDomainXYPlot1.setRangeZeroBaselineStroke(stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint32 = xYBarRenderer31.getBaseItemLabelPaint();
        piePlot30.setLabelPaint(paint32);
        piePlot30.setIgnoreZeroValues(true);
        boolean boolean36 = rectangleEdge28.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        categoryAxis0.setCategoryMargin(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor2, textAnchor3, textAnchor4, (double) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor3, 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 0);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        boolean boolean3 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number3 = xYDataItem2.getX();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset7.removeSeries((java.lang.Comparable) 'a');
        timeSeries6.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset7);
        org.jfree.data.time.TimeSeries timeSeries11 = null;
        java.util.TimeZone timeZone12 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries11, timeZone12);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection13, true);
        timeSeries6.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection13);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.util.Date date19 = month18.getStart();
        long long20 = month18.getSerialIndex();
        org.jfree.data.time.Year year21 = month18.getYear();
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 0.05d, true);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection25 = new org.jfree.data.time.TimeSeriesCollection(timeSeries6);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 24234L + "'", long20 == 24234L);
        org.junit.Assert.assertNotNull(year21);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        try {
            double double12 = intervalXYDelegate9.getEndXValue((int) (byte) -1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long3 = segmentedTimeline1.getTimeFromLong(0L);
        java.util.List list4 = segmentedTimeline1.getExceptionSegments();
        try {
            org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset0, list4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        java.awt.Paint paint6 = categoryAxis1.getAxisLinePaint();
        org.jfree.chart.entity.AxisEntity axisEntity8 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis1, "ChartChangeEventType.DATASET_UPDATED");
        java.lang.String str9 = axisEntity8.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "AxisEntity: tooltip = ChartChangeEventType.DATASET_UPDATED" + "'", str9.equals("AxisEntity: tooltip = ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        java.awt.Font font5 = polarPlot4.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.DATASET_UPDATED", font5);
        java.lang.String str7 = labelBlock6.getToolTipText();
        labelBlock6.setWidth(0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8);
        double double10 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        try {
            int int12 = categoryPlot0.getRangeAxisIndex(valueAxis11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        xYBarRenderer0.setSeriesVisible(15, (java.lang.Boolean) false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator5 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(xYItemLabelGenerator5);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock3.draw(graphics2D4, (float) 8, 0.0f, textBlockAnchor7, (float) 'a', (-1.0f), 10.0d);
        java.lang.String str12 = textBlockAnchor7.toString();
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TextBlockAnchor.TOP_LEFT" + "'", str12.equals("TextBlockAnchor.TOP_LEFT"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        int int0 = java.text.NumberFormat.INTEGER_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 10.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.data.Range range4 = null;
        org.jfree.data.Range range6 = org.jfree.data.Range.expandToInclude(range4, (double) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range6, 0.0d);
        boolean boolean11 = range6.intersects((double) 'a', (double) (short) 0);
        boolean boolean12 = lengthConstraintType3.equals((java.lang.Object) boolean11);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection();
        java.lang.Object obj14 = xYSeriesCollection13.clone();
        boolean boolean15 = lengthConstraintType3.equals(obj14);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = categoryPlot1.getRangeMarkers((int) '4', layer3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries6 = null;
        java.util.TimeZone timeZone7 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeSeries6, timeZone7);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8, true);
        org.jfree.data.Range range12 = xYBarRenderer5.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot1, (org.jfree.data.general.Dataset) timeSeriesCollection8);
        java.awt.Stroke stroke14 = categoryPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot1.getRangeAxisLocation();
        boolean boolean16 = pieLabelLinkStyle0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot1.panDomainAxes((double) 28, plotRenderingInfo18, point2D19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot1.getFixedDomainAxisSpace();
        categoryPlot1.clearRangeMarkers(15);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(axisSpace21);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8);
        boolean boolean10 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot0.getRangeAxisForDataset(7);
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(axisSpace13);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        java.util.Currency currency1 = numberFormat0.getCurrency();
        numberFormat0.setMinimumFractionDigits(3);
        java.text.ParsePosition parsePosition5 = null;
        try {
            java.lang.Object obj6 = numberFormat0.parseObject("SerialDate.weekInMonthToString(): invalid code.", parsePosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(currency1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        java.lang.Comparable comparable3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeriesCollection2.getSeries(comparable3);
        timeSeriesCollection2.removeAllSeries();
        org.jfree.data.DomainOrder domainOrder6 = timeSeriesCollection2.getDomainOrder();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(timeSeries4);
        org.junit.Assert.assertNotNull(domainOrder6);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        java.lang.String str3 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 9999);
        categoryAxis0.setMinorTickMarksVisible(true);
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 100.0d, "");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint16 = xYBarRenderer15.getBaseOutlinePaint();
        java.awt.Shape shape22 = null;
        java.awt.Paint paint24 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color26 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape29 = null;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color33 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape22, false, paint24, false, (java.awt.Paint) color26, stroke27, true, shape29, stroke30, (java.awt.Paint) color33);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(0.0d, paint16, stroke30);
        double double36 = valueMarker35.getValue();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean39 = categoryPlot12.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker35, layer37, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot12.getDomainAxisEdge();
        try {
            double double41 = categoryAxis0.getCategoryStart((int) (short) -1, 12, rectangle2D11, rectangleEdge40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.addChangeListener(plotChangeListener3);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator5 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        piePlot1.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator5);
        piePlot1.setShadowYOffset((double) (-57600000L));
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str3 = projectInfo2.toString();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset6, valueAxis7, polarItemRenderer8);
        float float10 = polarPlot9.getBackgroundImageAlpha();
        xYBarRenderer5.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        boolean boolean12 = xYBarRenderer5.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = null;
        xYBarRenderer5.setGradientPaintTransformer(gradientPaintTransformer13);
        java.awt.Paint paint15 = xYBarRenderer5.getBasePaint();
        boolean boolean16 = projectInfo2.equals((java.lang.Object) xYBarRenderer5);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.panRangeAxes((double) 3, plotRenderingInfo35, point2D36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        try {
            java.awt.image.BufferedImage bufferedImage43 = jFreeChart38.createBufferedImage(2, (int) (short) -1, (int) '4', chartRenderingInfo42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer0.setShadowXOffset((double) (short) 100);
        java.awt.Stroke stroke8 = xYBarRenderer0.getItemOutlineStroke(64, 4, true);
        xYBarRenderer0.setBaseCreateEntities(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYBarRenderer0.getSeriesNegativeItemLabelPosition(11);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number3 = xYDataItem2.getX();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset7.removeSeries((java.lang.Comparable) 'a');
        timeSeries6.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset7);
        java.lang.Object obj11 = timeSeries6.clone();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        long long2 = month0.getSerialIndex();
        java.lang.String str3 = month0.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        boolean boolean5 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((double) 432000000L, (double) (-460));
        int int5 = defaultXYDataset0.indexOf((java.lang.Comparable) 432000000L);
        defaultXYDataset0.removeSeries((java.lang.Comparable) 4);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        try {
            java.lang.Number number11 = defaultXYDataset0.getY(0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection0.addAll(legendItemCollection1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.lang.Boolean boolean13 = xYBarRenderer0.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation14 = null;
        boolean boolean15 = xYBarRenderer0.removeAnnotation(xYAnnotation14);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint17 = xYBarRenderer16.getBaseOutlinePaint();
        xYBarRenderer0.setBaseOutlinePaint(paint17, true);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = xYBarRenderer0.getLegendItems();
        java.util.Iterator iterator21 = legendItemCollection20.iterator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(iterator21);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("VerticalAlignment.CENTER", (int) (byte) 10, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseOutlinePaint();
        java.awt.Paint paint2 = xYBarRenderer0.getBasePaint();
        java.awt.Font font4 = xYBarRenderer0.getSeriesItemLabelFont((int) (byte) 0);
        java.awt.Paint paint5 = xYBarRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (short) 1, xYToolTipGenerator7, true);
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor(0, 4, (int) '4');
        xYBarRenderer0.setSeriesFillPaint((int) (short) 0, (java.awt.Paint) chartColor14);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(font4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        float float5 = polarPlot4.getBackgroundImageAlpha();
        xYBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot4);
        boolean boolean7 = xYBarRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = null;
        xYBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer8);
        java.awt.Paint paint10 = xYBarRenderer0.getBasePaint();
        java.awt.Shape shape17 = null;
        java.awt.Paint paint19 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color21 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color28 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape17, false, paint19, false, (java.awt.Paint) color21, stroke22, true, shape24, stroke25, (java.awt.Paint) color28);
        java.lang.Object obj30 = null;
        boolean boolean31 = legendItem29.equals(obj30);
        java.awt.Shape shape37 = null;
        java.awt.Paint paint39 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color41 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape44 = null;
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color48 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape37, false, paint39, false, (java.awt.Paint) color41, stroke42, true, shape44, stroke45, (java.awt.Paint) color48);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer50 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint51 = xYBarRenderer50.getBaseOutlinePaint();
        legendItem49.setLinePaint(paint51);
        legendItem29.setLabelPaint(paint51);
        legendItem29.setURLText("ThreadContext");
        java.awt.Stroke stroke56 = legendItem29.getOutlineStroke();
        xYBarRenderer0.setSeriesOutlineStroke(0, stroke56);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = xYBarRenderer2.getBaseItemLabelPaint();
        piePlot1.setLabelPaint(paint3);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator5);
        piePlot1.setMaximumLabelWidth((double) 128);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 1, true, true);
        java.lang.Number number5 = null;
        xYSeries3.add((java.lang.Number) (byte) -1, number5);
        java.lang.Object obj7 = xYSeries3.clone();
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("October");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        legendItem1.setLinePaint((java.awt.Paint) color2);
        int int4 = legendItem1.getSeriesIndex();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraintType.RANGE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.lang.String str2 = textFragment1.getText();
        java.awt.Font font3 = textFragment1.getFont();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = null;
        try {
            float float6 = textFragment1.calculateBaselineOffset(graphics2D4, textAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource5 = null;
        chartRenderingInfo4.setRenderingSource(renderingSource5);
        java.awt.geom.Rectangle2D rectangle2D7 = chartRenderingInfo4.getChartArea();
        org.jfree.chart.axis.AxisState axisState8 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        axisState8.moveCursor((double) 0, rectangleEdge10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState8.moveCursor((double) 100L, rectangleEdge13);
        double double15 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor1, 10, (int) (short) 0, rectangle2D7, rectangleEdge13);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.awt.Stroke stroke20 = piePlot19.getLabelLinkStroke();
        java.awt.Font font21 = piePlot19.getLabelFont();
        java.awt.Paint paint22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("PlotOrientation.HORIZONTAL", font21, paint22);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 128, font21);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        boolean boolean3 = legendTitle1.isVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, 0.0d);
        boolean boolean7 = range2.intersects((double) 'a', (double) (short) 0);
        double double8 = range2.getUpperBound();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            int int2 = xYSeriesCollection0.getItemCount(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer1.setShadowYOffset((double) 0L);
        xYBarRenderer1.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer1.setBaseOutlinePaint((java.awt.Paint) color8);
        boolean boolean10 = standardXYToolTipGenerator0.equals((java.lang.Object) xYBarRenderer1);
        xYBarRenderer1.clearSeriesStrokes(false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers((int) '4', layer6);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        java.util.TimeZone timeZone10 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeSeries9, timeZone10);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection11, true);
        org.jfree.data.Range range15 = xYBarRenderer8.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot4, (org.jfree.data.general.Dataset) timeSeriesCollection11);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource19 = null;
        chartRenderingInfo18.setRenderingSource(renderingSource19);
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo18.getChartArea();
        java.awt.geom.Point2D point2D22 = null;
        org.jfree.chart.plot.PlotState plotState23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        categoryPlot4.draw(graphics2D17, rectangle2D21, point2D22, plotState23, plotRenderingInfo24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setRangeMinorGridlinesVisible(false);
        java.awt.Stroke stroke29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        categoryPlot26.setDomainGridlineStroke(stroke29);
        java.awt.Paint paint31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("DateTickUnitType.DAY", "100", "June 2019", "Other", (java.awt.Shape) rectangle2D21, stroke29, paint31);
        java.lang.Object obj33 = legendItem32.clone();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 24234L, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (24234.0) <= upper (100.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth((double) 10);
        ringPlot0.setInnerSeparatorExtension((double) 86400000L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        float float5 = polarPlot4.getBackgroundImageAlpha();
        xYBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYBarRenderer0.getNegativeItemLabelPosition(5, 6, false);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        java.util.Date date2 = month0.getEnd();
        java.util.Date date3 = month0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getStart();
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3, timeZone6, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, true);
        double double7 = timeSeriesCollection2.getDomainLowerBound(false);
        try {
            boolean boolean10 = timeSeriesCollection2.isSelected(9999, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (9999).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8);
        double double10 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation14 = null;
        try {
            boolean boolean16 = categoryPlot0.removeAnnotation(categoryAnnotation14, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long2 = segmentedTimeline0.getTimeFromLong(0L);
        int int3 = segmentedTimeline0.getSegmentsIncluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline0.getSegment((-57600001L));
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
        org.junit.Assert.assertNotNull(segment5);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.createCopy((int) (byte) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ThreadContext" + "'", str4.equals("ThreadContext"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        boolean boolean28 = chartChangeEventType25.equals((java.lang.Object) entityCollection26);
        java.lang.String str29 = chartChangeEventType25.toString();
        boolean boolean30 = valueMarker23.equals((java.lang.Object) chartChangeEventType25);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean33 = xYPlot0.removeRangeMarker(8, (org.jfree.chart.plot.Marker) valueMarker23, layer31, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        try {
            xYPlot0.handleClick(4, 9999, plotRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str29.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarksVisible(false);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(2);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(15, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        boolean boolean28 = chartChangeEventType25.equals((java.lang.Object) entityCollection26);
        java.lang.String str29 = chartChangeEventType25.toString();
        boolean boolean30 = valueMarker23.equals((java.lang.Object) chartChangeEventType25);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean33 = xYPlot0.removeRangeMarker(8, (org.jfree.chart.plot.Marker) valueMarker23, layer31, true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation34 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation34, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str29.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.plot.XYPlot xYPlot3 = xYBarRenderer0.getPlot();
        java.awt.Stroke stroke5 = xYBarRenderer0.getSeriesStroke((int) (byte) 100);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = xYBarRenderer0.getLegendItemLabelGenerator();
        xYBarRenderer0.setBaseSeriesVisible(false, true);
        org.junit.Assert.assertNull(xYPlot3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator6);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        java.lang.Object obj1 = xYSeriesCollection0.clone();
        try {
            java.lang.Number number4 = xYSeriesCollection0.getStartX(15, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getStart();
        java.util.Date date6 = month4.getEnd();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-57600001L));
        org.jfree.data.xy.XYDataItem xYDataItem11 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number12 = xYDataItem11.getX();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem11, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset16.removeSeries((java.lang.Comparable) 'a');
        timeSeries15.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset16);
        org.jfree.data.time.TimeSeries timeSeries20 = null;
        java.util.TimeZone timeZone21 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeSeries20, timeZone21);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection22);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection22, true);
        timeSeries15.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection22);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        java.util.Date date28 = month27.getStart();
        long long29 = month27.getSerialIndex();
        org.jfree.data.time.Year year30 = month27.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 0.05d, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 12);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        java.util.Date date37 = month36.getStart();
        long long38 = month36.getSerialIndex();
        org.jfree.data.time.Year year39 = month36.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.next();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year39, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0d + "'", number12.equals(100.0d));
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 24234L + "'", long29 == 24234L);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 24234L + "'", long38 == 24234L);
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        double double2 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Stroke stroke4 = piePlot3.getLabelLinkStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot6.getRangeMarkers((int) '4', layer8);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries11 = null;
        java.util.TimeZone timeZone12 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries11, timeZone12);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection13, true);
        org.jfree.data.Range range17 = xYBarRenderer10.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection13);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot6, (org.jfree.data.general.Dataset) timeSeriesCollection13);
        java.awt.Stroke stroke19 = categoryPlot6.getDomainGridlineStroke();
        piePlot3.setSectionOutlineStroke((java.lang.Comparable) 1.0f, stroke19);
        boolean boolean21 = textBlockAnchor0.equals((java.lang.Object) 1.0f);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.BOTTOM_CENTER" + "'", str1.equals("TextBlockAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        boolean boolean28 = chartChangeEventType25.equals((java.lang.Object) entityCollection26);
        java.lang.String str29 = chartChangeEventType25.toString();
        boolean boolean30 = valueMarker23.equals((java.lang.Object) chartChangeEventType25);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean33 = xYPlot0.removeRangeMarker(8, (org.jfree.chart.plot.Marker) valueMarker23, layer31, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryAxis34.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource37 = null;
        chartRenderingInfo36.setRenderingSource(renderingSource37);
        java.awt.geom.Rectangle2D rectangle2D39 = chartRenderingInfo36.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets35.createInsetRectangle(rectangle2D39, false, false);
        xYPlot0.setAxisOffset(rectangleInsets35);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str29.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D42);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) (short) 100, 0.0d, (double) 1);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource10 = null;
        chartRenderingInfo9.setRenderingSource(renderingSource10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo9.getChartArea();
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        axisState13.moveCursor((double) 0, rectangleEdge15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState13.moveCursor((double) 100L, rectangleEdge18);
        axisState13.setCursor((double) 3);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint27 = xYBarRenderer26.getBaseOutlinePaint();
        java.awt.Shape shape33 = null;
        java.awt.Paint paint35 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color37 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape40 = null;
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color44 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape33, false, paint35, false, (java.awt.Paint) color37, stroke38, true, shape40, stroke41, (java.awt.Paint) color44);
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker(0.0d, paint27, stroke41);
        double double47 = valueMarker46.getValue();
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean50 = categoryPlot23.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker46, layer48, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot23.getDomainAxisEdge();
        axisState13.moveCursor(2.0d, rectangleEdge51);
        try {
            gradientXYBarPainter3.paintBar(graphics2D4, xYBarRenderer5, 6, (int) '#', false, (java.awt.geom.RectangularShape) rectangle2D12, rectangleEdge51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangleEdge51);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, true);
        org.jfree.data.Range range11 = xYBarRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot0, (org.jfree.data.general.Dataset) timeSeriesCollection7);
        java.awt.Stroke stroke13 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryAxis16.getTickLabelInsets();
        categoryAxis16.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        double double21 = categoryAxis16.getUpperMargin();
        java.awt.Paint paint22 = categoryAxis16.getLabelPaint();
        int int23 = categoryPlot0.getDomainAxisIndex(categoryAxis16);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Paint paint5 = xYBarRenderer3.getBasePaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer3.setSeriesItemLabelPaint(1, paint7);
        legendTitle1.setBackgroundPaint(paint7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = legendTitle1.getHorizontalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle1.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 28, (double) '4');
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(2);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, serialDate2);
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate2.getNearestDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getRangeMarkers((int) '4', layer11);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        java.util.TimeZone timeZone15 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeSeries14, timeZone15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection16, true);
        org.jfree.data.Range range20 = xYBarRenderer13.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot9, (org.jfree.data.general.Dataset) timeSeriesCollection16);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource24 = null;
        chartRenderingInfo23.setRenderingSource(renderingSource24);
        java.awt.geom.Rectangle2D rectangle2D26 = chartRenderingInfo23.getChartArea();
        java.awt.geom.Point2D point2D27 = null;
        org.jfree.chart.plot.PlotState plotState28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        categoryPlot9.draw(graphics2D22, rectangle2D26, point2D27, plotState28, plotRenderingInfo29);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot31.setRangeMinorGridlinesVisible(false);
        java.awt.Stroke stroke34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        categoryPlot31.setDomainGridlineStroke(stroke34);
        java.awt.Paint paint36 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("DateTickUnitType.DAY", "100", "June 2019", "Other", (java.awt.Shape) rectangle2D26, stroke34, paint36);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = new org.jfree.chart.util.RectangleInsets((double) (-1), 12.0d, (double) '#', (double) 1577894400005L);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = categoryAxis43.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo45 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource46 = null;
        chartRenderingInfo45.setRenderingSource(renderingSource46);
        java.awt.geom.Rectangle2D rectangle2D48 = chartRenderingInfo45.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets44.createInsetRectangle(rectangle2D48, false, false);
        java.awt.geom.Rectangle2D rectangle2D54 = rectangleInsets42.createInsetRectangle(rectangle2D48, false, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor56 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo59 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource60 = null;
        chartRenderingInfo59.setRenderingSource(renderingSource60);
        java.awt.geom.Rectangle2D rectangle2D62 = chartRenderingInfo59.getChartArea();
        org.jfree.chart.axis.AxisState axisState63 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = null;
        axisState63.moveCursor((double) 0, rectangleEdge65);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState63.moveCursor((double) 100L, rectangleEdge68);
        double double70 = categoryAxis55.getCategoryJava2DCoordinate(categoryAnchor56, 10, (int) (short) 0, rectangle2D62, rectangleEdge68);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        try {
            org.jfree.chart.axis.AxisState axisState72 = symbolAxis2.draw(graphics2D3, (double) 1559372400000L, rectangle2D26, rectangle2D48, rectangleEdge68, plotRenderingInfo71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarksVisible(false);
        java.awt.Font font3 = categoryAxis0.getTickLabelFont();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Paint paint6 = categoryAxis0.getAxisLinePaint();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = xYBarRenderer2.getBaseItemLabelPaint();
        piePlot1.setLabelPaint(paint3);
        piePlot1.setIgnoreZeroValues(true);
        boolean boolean7 = piePlot1.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.awt.Color color0 = java.awt.Color.cyan;
        java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cyan" + "'", str1.equals("cyan"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        int int5 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.addChangeListener(plotChangeListener3);
        piePlot1.setCircular(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getLabelPadding();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline1.getSegment((long) (short) 100);
        long long4 = segment3.getSegmentCount();
        long long5 = segment3.getSegmentCount();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline6.getSegment((long) (short) 100);
        long long9 = segment8.getSegmentCount();
        segment8.dec();
        boolean boolean11 = segment3.contains(segment8);
        boolean boolean12 = rotation0.equals((java.lang.Object) segment3);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource2 = null;
        chartRenderingInfo1.setRenderingSource(renderingSource2);
        java.awt.geom.Rectangle2D rectangle2D4 = chartRenderingInfo1.getChartArea();
        try {
            boolean boolean5 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D4);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color16 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape5, false, paint7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color16);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint19 = xYBarRenderer18.getBaseOutlinePaint();
        legendItem17.setLinePaint(paint19);
        int int21 = legendItem17.getDatasetIndex();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        boolean boolean31 = categoryPlot0.isNotify();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) '4', "[100.0, 12.0]", "TextBlockAnchor.BOTTOM_CENTER", false);
        java.text.NumberFormat numberFormat5 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str7 = numberFormat5.format((-1.0d));
        logFormat4.setExponentFormat(numberFormat5);
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarksVisible(false);
        categoryAxis0.configure();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        combinedDomainXYPlot8.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = combinedDomainXYPlot8.getDomainAxisEdge((int) (byte) -1);
        try {
            double double13 = categoryAxis0.getCategoryEnd(0, (int) (short) 0, rectangle2D6, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape14 = null;
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color25 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape14, false, paint16, false, (java.awt.Paint) color18, stroke19, true, shape21, stroke22, (java.awt.Paint) color25);
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem26.setLabelPaint(paint27);
        xYBarRenderer0.setBaseLegendTextPaint(paint27);
        java.awt.Stroke stroke31 = xYBarRenderer0.lookupSeriesOutlineStroke((int) (byte) 100);
        xYBarRenderer0.setSeriesItemLabelsVisible(10, (java.lang.Boolean) false);
        java.lang.Boolean boolean36 = xYBarRenderer0.getSeriesVisibleInLegend((int) '#');
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator38 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer39 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer39.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer39.setShadowYOffset((double) 0L);
        xYBarRenderer39.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color46 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer39.setBaseOutlinePaint((java.awt.Paint) color46);
        boolean boolean48 = standardXYToolTipGenerator38.equals((java.lang.Object) xYBarRenderer39);
        xYBarRenderer0.setSeriesToolTipGenerator(2, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator38, true);
        xYBarRenderer0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) true, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(boolean36);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = valueMarker23.getLabelOffset();
        double double30 = rectangleInsets28.extendWidth(0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 6.0d + "'", double30 == 6.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        numberFormat2.setGroupingUsed(false);
        int int5 = numberFormat2.getMaximumFractionDigits();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator6 = new org.jfree.chart.labels.StandardPieToolTipGenerator("100", numberFormat1, numberFormat2);
        numberFormat1.setMaximumFractionDigits(100);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarksVisible(false);
        java.awt.Font font4 = categoryAxis1.getTickLabelFont();
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor(0, 4, (int) '4');
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) chartColor8, (float) (byte) 100, 100, textMeasurer11);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset14, valueAxis15, polarItemRenderer16);
        java.awt.Font font18 = polarPlot17.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("ChartChangeEventType.DATASET_UPDATED", font18);
        org.jfree.chart.text.TextFragment textFragment20 = textLine19.getFirstTextFragment();
        textBlock12.addLine(textLine19);
        java.awt.Font font23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer24 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint25 = xYBarRenderer24.getBaseItemLabelPaint();
        boolean boolean29 = xYBarRenderer24.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator31 = null;
        xYBarRenderer24.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator31);
        java.awt.Shape shape38 = null;
        java.awt.Paint paint40 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color42 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape45 = null;
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color49 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape38, false, paint40, false, (java.awt.Paint) color42, stroke43, true, shape45, stroke46, (java.awt.Paint) color49);
        java.awt.Paint paint51 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem50.setLabelPaint(paint51);
        xYBarRenderer24.setBaseLegendTextPaint(paint51);
        org.jfree.chart.text.TextFragment textFragment54 = new org.jfree.chart.text.TextFragment("ChartChangeEventType.DATASET_UPDATED", font23, paint51);
        textLine19.removeFragment(textFragment54);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(textFragment20);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number3 = xYDataItem2.getX();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2, "October", "RectangleAnchor.BOTTOM");
        timeSeries6.setKey((java.lang.Comparable) 4.0d);
        double double9 = timeSeries6.getMaxY();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str3 = projectInfo2.toString();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        java.lang.String str5 = projectInfo2.getInfo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str5.equals("http://www.jfree.org/jfreechart/index.html"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) 1577894400005L, range3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint4.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.panRangeAxes((double) 3, plotRenderingInfo35, point2D36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        java.awt.Paint paint39 = jFreeChart38.getBorderPaint();
        boolean boolean40 = jFreeChart38.isBorderVisible();
        try {
            org.jfree.chart.plot.XYPlot xYPlot41 = jFreeChart38.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 100);
        double double4 = range3.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range8, (double) 10.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = rectangleConstraint10.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '4', range3, lengthConstraintType5, (double) 12, range7, lengthConstraintType11);
        double double13 = range3.getLength();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer0.setShadowXOffset((double) (short) 100);
        java.awt.Stroke stroke8 = xYBarRenderer0.getItemOutlineStroke(64, 4, true);
        xYBarRenderer0.setBaseCreateEntities(true);
        boolean boolean11 = xYBarRenderer0.getUseYInterval();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        float float5 = polarPlot4.getBackgroundImageAlpha();
        xYBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        try {
            polarPlot4.zoomRangeAxes((double) 1559372400000L, (double) 1560495599999L, plotRenderingInfo9, point2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.addChangeListener(plotChangeListener3);
        java.awt.Paint paint5 = piePlot1.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.addChangeListener(plotChangeListener3);
        org.jfree.data.general.PieDataset pieDataset5 = piePlot1.getDataset();
        int int6 = piePlot1.getPieIndex();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.lang.Boolean boolean13 = xYBarRenderer0.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation14 = null;
        boolean boolean15 = xYBarRenderer0.removeAnnotation(xYAnnotation14);
        java.awt.Paint paint16 = xYBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor17, textAnchor18, textAnchor19, 0.0d);
        xYBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition21);
        boolean boolean24 = itemLabelPosition21.equals((java.lang.Object) "AxisLocation.TOP_OR_RIGHT");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYSeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.panRangeAxes((double) 3, plotRenderingInfo35, point2D36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) "Other");
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        java.lang.String str3 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 9999);
        categoryAxis0.setMinorTickMarksVisible(true);
        categoryAxis0.setVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.plot.XYPlot xYPlot3 = xYBarRenderer0.getPlot();
        java.awt.Stroke stroke5 = xYBarRenderer0.getSeriesStroke((int) (byte) 100);
        xYBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) true, false);
        org.junit.Assert.assertNull(xYPlot3);
        org.junit.Assert.assertNull(stroke5);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        legendTitle1.setPadding((double) 11, (double) 1577894400005L, (double) 9999, (double) (short) -1);
        boolean boolean8 = legendTitle1.isVisible();
        legendTitle1.setID("item");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = state1.getEntityCollection();
        java.awt.geom.Line2D line2D3 = state1.workingLine;
        boolean boolean4 = state1.isLastPointGood();
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertNotNull(line2D3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number3 = xYDataItem2.getX();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset7.removeSeries((java.lang.Comparable) 'a');
        timeSeries6.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset7);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint13 = xYBarRenderer12.getBaseOutlinePaint();
        java.awt.Shape shape19 = null;
        java.awt.Paint paint21 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color23 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape26 = null;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color30 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape19, false, paint21, false, (java.awt.Paint) color23, stroke24, true, shape26, stroke27, (java.awt.Paint) color30);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker(0.0d, paint13, stroke27);
        boolean boolean33 = defaultXYDataset7.equals((java.lang.Object) valueMarker32);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline34 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment36 = segmentedTimeline34.getSegment((long) (short) 100);
        long long37 = segment36.getSegmentCount();
        boolean boolean38 = segment36.inExceptionSegments();
        org.jfree.data.xy.XYSeries xYSeries40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) segment36, false);
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[][] doubleArray47 = new double[][] { doubleArray41, doubleArray42, doubleArray43, doubleArray44, doubleArray45, doubleArray46 };
        try {
            defaultXYDataset7.addSeries((java.lang.Comparable) false, doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'data' array must have length == 2.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline34);
        org.junit.Assert.assertNotNull(segment36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1L + "'", long37 == 1L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Stroke stroke3 = piePlot2.getLabelLinkStroke();
        java.awt.Font font4 = piePlot2.getLabelFont();
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("PlotOrientation.HORIZONTAL", font4, paint5);
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("");
        java.lang.String str9 = textFragment8.getText();
        java.awt.Font font10 = textFragment8.getFont();
        textLine6.removeFragment(textFragment8);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(100.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setTickMarksVisible(false);
        java.awt.Font font7 = categoryAxis4.getTickLabelFont();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint10 = xYBarRenderer9.getBaseOutlinePaint();
        java.awt.Shape shape16 = null;
        java.awt.Paint paint18 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color20 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape23 = null;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color27 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape16, false, paint18, false, (java.awt.Paint) color20, stroke21, true, shape23, stroke24, (java.awt.Paint) color27);
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.0d, paint10, stroke24);
        float float30 = valueMarker29.getAlpha();
        java.awt.Stroke stroke31 = valueMarker29.getStroke();
        java.awt.Paint paint32 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        boolean boolean33 = valueMarker29.equals((java.lang.Object) paint32);
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.DATASET_UPDATED", font7, paint32);
        categoryAxis0.setTickLabelPaint(paint32);
        java.awt.Shape shape36 = null;
        try {
            org.jfree.chart.entity.AxisLabelEntity axisLabelEntity39 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape36, "TextBlockAnchor.TOP_LEFT", "item");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.panRangeAxes((double) 3, plotRenderingInfo35, point2D36);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer38 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint39 = xYBarRenderer38.getBaseItemLabelPaint();
        boolean boolean43 = xYBarRenderer38.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator45 = null;
        xYBarRenderer38.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator45);
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer38.setBaseLegendShape(shape48);
        java.lang.Boolean boolean51 = xYBarRenderer38.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation52 = null;
        boolean boolean53 = xYBarRenderer38.removeAnnotation(xYAnnotation52);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer54 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint55 = xYBarRenderer54.getBaseOutlinePaint();
        xYBarRenderer38.setBaseOutlinePaint(paint55, true);
        categoryPlot0.setRangeCrosshairPaint(paint55);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNull(boolean51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(paint55);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            int int2 = xYSeriesCollection0.getItemCount((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        boolean boolean28 = chartChangeEventType25.equals((java.lang.Object) entityCollection26);
        java.lang.String str29 = chartChangeEventType25.toString();
        boolean boolean30 = valueMarker23.equals((java.lang.Object) chartChangeEventType25);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean33 = xYPlot0.removeRangeMarker(8, (org.jfree.chart.plot.Marker) valueMarker23, layer31, true);
        try {
            xYPlot0.mapDatasetToDomainAxis((int) (byte) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str29.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer0.setShadowYOffset((double) 0L);
        xYBarRenderer0.setShadowXOffset(100.0d);
        boolean boolean7 = xYBarRenderer0.getBaseItemLabelsVisible();
        java.awt.Shape shape8 = xYBarRenderer0.getBaseShape();
        java.awt.Stroke stroke10 = xYBarRenderer0.getSeriesStroke((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(stroke10);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.awt.Shape shape17 = null;
        java.awt.Paint paint19 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color21 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color28 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape17, false, paint19, false, (java.awt.Paint) color21, stroke22, true, shape24, stroke25, (java.awt.Paint) color28);
        java.lang.Object obj30 = null;
        boolean boolean31 = legendItem29.equals(obj30);
        java.awt.Paint paint32 = legendItem29.getFillPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape10, paint32);
        java.awt.Shape shape34 = legendGraphic33.getShape();
        java.lang.Object obj35 = legendGraphic33.clone();
        java.awt.Stroke stroke36 = legendGraphic33.getLineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNull(stroke36);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getStart();
        long long3 = month1.getSerialIndex();
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone5 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone5;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4, timeZone5);
        int int8 = month7.getMonth();
        int int9 = month7.getMonth();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getStart();
        java.util.TimeZone timeZone12 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11, timeZone12);
        java.util.Locale locale14 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("October", (org.jfree.data.time.RegularTimePeriod) month1, (org.jfree.data.time.RegularTimePeriod) month7, timeZone12, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8);
        double double10 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot0.getFixedRangeAxisSpace();
        categoryPlot0.clearDomainMarkers((int) (byte) -1);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNull(axisSpace13);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((double) 432000000L, (double) (-460));
        int int5 = defaultXYDataset0.indexOf((java.lang.Comparable) 432000000L);
        defaultXYDataset0.removeSeries((java.lang.Comparable) 4);
        try {
            java.lang.Number number10 = defaultXYDataset0.getY(0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }
}

