import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter2 = xYBarRenderer0.getBarPainter();
        xYBarRenderer0.setBaseSeriesVisible(false, true);
        xYBarRenderer0.setUseYInterval(true);
        xYBarRenderer0.setShadowXOffset((double) 2.0f);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYBarPainter2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setCrosshairX(0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = null;
        try {
            categoryPlot0.setRangeAxes(valueAxisArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.LegendItem legendItem3 = xYLineAndShapeRenderer0.getLegendItem(1, 10);
        org.junit.Assert.assertNull(legendItem3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.chart.renderer.RendererUtilities rendererUtilities0 = new org.jfree.chart.renderer.RendererUtilities();
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("JFreeChart");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis();
        java.lang.String[] strArray6 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis7 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray6);
        java.lang.Object obj8 = symbolAxis7.clone();
        symbolAxis7.setRangeWithMargins(0.05d, (double) 1560495599999L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource16 = null;
        chartRenderingInfo15.setRenderingSource(renderingSource16);
        java.awt.geom.Rectangle2D rectangle2D18 = chartRenderingInfo15.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets14.createInsetRectangle(rectangle2D18, false, false);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D18);
        org.jfree.chart.axis.AxisState axisState23 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        axisState23.moveCursor((double) 0, rectangleEdge25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState23.moveCursor((double) 100L, rectangleEdge28);
        double double30 = symbolAxis7.java2DToValue((double) 1577894400001L, rectangle2D18, rectangleEdge28);
        boolean boolean31 = logAxis4.equals((java.lang.Object) rectangle2D18);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot33 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis32);
        combinedDomainXYPlot33.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = combinedDomainXYPlot33.getDomainAxisEdge((int) (byte) -1);
        try {
            java.util.List list38 = dateAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D18, rectangleEdge37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.POSITIVE_INFINITY + "'", double30 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.setNoDataMessage("ThreadContext");
        boolean boolean6 = polarPlot3.isRangeZoomable();
        java.lang.Object obj7 = polarPlot3.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace6 = combinedDomainXYPlot1.getFixedRangeAxisSpace();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot7.getRangeMarkers((int) '4', layer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot7.setDomainAxis((int) (short) 0, categoryAxis12, true);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot7.setFixedRangeAxisSpace(axisSpace15);
        double double17 = categoryPlot7.getAnchorValue();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot7.setRangeAxisLocation(axisLocation18);
        combinedDomainXYPlot1.setRangeAxisLocation(axisLocation18, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot22.getRangeMarkers((int) '4', layer24);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries27 = null;
        java.util.TimeZone timeZone28 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection29 = new org.jfree.data.time.TimeSeriesCollection(timeSeries27, timeZone28);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection29);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection29, true);
        org.jfree.data.Range range33 = xYBarRenderer26.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection29);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent34 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot22, (org.jfree.data.general.Dataset) timeSeriesCollection29);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint37 = xYBarRenderer36.getBaseOutlinePaint();
        java.awt.Shape shape43 = null;
        java.awt.Paint paint45 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color47 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape50 = null;
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color54 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem55 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape43, false, paint45, false, (java.awt.Paint) color47, stroke48, true, shape50, stroke51, (java.awt.Paint) color54);
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker(0.0d, paint37, stroke51);
        double double57 = valueMarker56.getValue();
        valueMarker56.setLabel("");
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent60 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker56);
        org.jfree.chart.util.Layer layer61 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean62 = categoryPlot22.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker56, layer61);
        java.util.Collection collection63 = combinedDomainXYPlot1.getDomainMarkers(layer61);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(layer61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(collection63);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str3 = projectInfo2.toString();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        java.lang.String str5 = projectInfo0.getName();
        projectInfo0.setLicenceText("TextBlockAnchor.BOTTOM_CENTER");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JFreeChart" + "'", str5.equals("JFreeChart"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.addChangeListener(plotChangeListener3);
        java.awt.Stroke stroke5 = piePlot1.getLabelOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot1.getURLGenerator();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(pieURLGenerator6);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        long long3 = segment2.getSegmentStart();
        boolean boolean6 = segment2.contains((-57600001L), (long) 10);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-57600000L) + "'", long3 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.lang.String str2 = waferMapPlot1.getPlotType();
        java.awt.Stroke stroke3 = waferMapPlot1.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "WMAP_Plot" + "'", str2.equals("WMAP_Plot"));
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        combinedDomainXYPlot1.setDomainMinorGridlinesVisible(true);
        java.awt.Stroke stroke6 = combinedDomainXYPlot1.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape14 = null;
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color25 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape14, false, paint16, false, (java.awt.Paint) color18, stroke19, true, shape21, stroke22, (java.awt.Paint) color25);
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem26.setLabelPaint(paint27);
        xYBarRenderer0.setBaseLegendTextPaint(paint27);
        java.awt.Stroke stroke31 = xYBarRenderer0.lookupSeriesOutlineStroke((int) (byte) 100);
        xYBarRenderer0.setSeriesItemLabelsVisible(10, (java.lang.Boolean) false);
        java.lang.Boolean boolean36 = xYBarRenderer0.getSeriesVisibleInLegend((int) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = xYBarRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Shape shape38 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYBarRenderer0.setBaseShape(shape38);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(boolean36);
        org.junit.Assert.assertNull(itemLabelPosition37);
        org.junit.Assert.assertNotNull(shape38);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.panRangeAxes((double) 3, plotRenderingInfo35, point2D36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener39 = null;
        jFreeChart38.addProgressListener(chartProgressListener39);
        java.awt.RenderingHints renderingHints41 = jFreeChart38.getRenderingHints();
        jFreeChart38.setBackgroundImageAlpha((float) '4');
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer47 = null;
        org.jfree.chart.plot.PolarPlot polarPlot48 = new org.jfree.chart.plot.PolarPlot(xYDataset45, valueAxis46, polarItemRenderer47);
        boolean boolean49 = polarPlot48.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent50 = null;
        polarPlot48.datasetChanged(datasetChangeEvent50);
        java.awt.Font font52 = polarPlot48.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("12/31/69", font52);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = textTitle53.getMargin();
        jFreeChart38.setTitle(textTitle53);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(renderingHints41);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(rectangleInsets54);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color16 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape5, false, paint7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color16);
        java.awt.Color color21 = java.awt.Color.orange;
        float[] floatArray28 = new float[] { 1.0f, 1L, ' ', 3, 28, 0.0f };
        float[] floatArray29 = color21.getRGBComponents(floatArray28);
        float[] floatArray30 = java.awt.Color.RGBtoHSB((int) 'a', (int) (short) -1, (int) (short) 0, floatArray28);
        float[] floatArray31 = color9.getRGBColorComponents(floatArray30);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = state1.getEntityCollection();
        java.awt.geom.Line2D line2D3 = state1.workingLine;
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        timeSeriesCollection6.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot11);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = null;
        polarPlot11.setDrawingSupplier(drawingSupplier13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        polarPlot11.addChangeListener(plotChangeListener15);
        java.lang.String str17 = polarPlot11.getNoDataMessage();
        java.awt.Paint paint18 = null;
        polarPlot11.setAngleGridlinePaint(paint18);
        org.jfree.chart.axis.ValueAxis valueAxis20 = polarPlot11.getAxis();
        java.awt.Shape shape26 = null;
        java.awt.Paint paint28 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color30 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape33 = null;
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color37 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape26, false, paint28, false, (java.awt.Paint) color30, stroke31, true, shape33, stroke34, (java.awt.Paint) color37);
        polarPlot11.setAngleGridlinePaint(paint28);
        org.jfree.chart.title.LegendGraphic legendGraphic40 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) line2D3, paint28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = legendGraphic40.getShapeLocation();
        legendGraphic40.setShapeVisible(false);
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertNotNull(line2D3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 0);
        boolean boolean2 = xYStepAreaRenderer1.getShapesVisible();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        polarPlot7.datasetChanged(datasetChangeEvent9);
        java.awt.Font font11 = polarPlot7.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("12/31/69", font11);
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendTitle14.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint17 = xYBarRenderer16.getBaseOutlinePaint();
        java.awt.Paint paint18 = xYBarRenderer16.getBasePaint();
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer16.setSeriesItemLabelPaint(1, paint20);
        legendTitle14.setBackgroundPaint(paint20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = legendTitle14.getHorizontalAlignment();
        textTitle12.setTextAlignment(horizontalAlignment23);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType25 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType25, 5);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType28 = dateTickUnit27.getUnitType();
        boolean boolean29 = textTitle12.equals((java.lang.Object) dateTickUnitType28);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = textTitle12.getTextAlignment();
        boolean boolean31 = xYStepAreaRenderer1.equals((java.lang.Object) horizontalAlignment30);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation32 = null;
        try {
            xYStepAreaRenderer1.addAnnotation(xYAnnotation32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(dateTickUnitType25);
        org.junit.Assert.assertNotNull(dateTickUnitType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace6 = combinedDomainXYPlot1.getFixedRangeAxisSpace();
        combinedDomainXYPlot1.setDomainCrosshairValue(0.0d, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint12 = xYBarRenderer11.getBaseItemLabelPaint();
        boolean boolean16 = xYBarRenderer11.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        java.awt.Shape shape17 = xYBarRenderer11.getBaseLegendShape();
        java.awt.Paint paint19 = xYBarRenderer11.getLegendTextPaint(6);
        java.awt.Paint paint20 = xYBarRenderer11.getBasePaint();
        combinedDomainXYPlot1.setRenderer(4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer11);
        org.jfree.data.time.TimeSeries timeSeries23 = null;
        java.util.TimeZone timeZone24 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection25 = new org.jfree.data.time.TimeSeriesCollection(timeSeries23, timeZone24);
        java.lang.Comparable comparable26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeriesCollection25.getSeries(comparable26);
        timeSeriesCollection25.removeAllSeries();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline29 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long31 = segmentedTimeline29.getTimeFromLong(0L);
        java.util.List list32 = segmentedTimeline29.getExceptionSegments();
        org.jfree.data.Range range33 = null;
        org.jfree.data.Range range35 = org.jfree.data.Range.expandToInclude(range33, (double) 100);
        double double36 = range35.getLength();
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection25, list32, range35, false);
        try {
            combinedDomainXYPlot1.mapDatasetToDomainAxes(4, list32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(shape17);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(timeSeries27);
        org.junit.Assert.assertNotNull(segmentedTimeline29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNull(range38);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        boolean boolean12 = combinedDomainXYPlot1.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke13 = combinedDomainXYPlot1.getRangeZeroBaselineStroke();
        boolean boolean14 = combinedDomainXYPlot1.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer16.setAutoPopulateSeriesOutlinePaint(true);
        combinedDomainXYPlot1.setRenderer(28, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer16);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis21 = combinedDomainXYPlot1.getDomainAxisForDataset((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 32 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape9 = xYBarRenderer0.getBaseLegendShape();
        java.awt.Shape shape10 = xYBarRenderer0.getLegendBar();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint13 = xYBarRenderer12.getBaseOutlinePaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor14 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor14, textAnchor15, textAnchor16, (double) '#');
        xYBarRenderer12.setBasePositiveItemLabelPosition(itemLabelPosition18);
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(6, itemLabelPosition18);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelAnchor14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("ThreadContext");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj1 = datasetGroup0.clone();
        java.lang.Object obj2 = datasetGroup0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1, timeZone2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        timeSeriesCollection3.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("MAJOR", (org.jfree.chart.plot.Plot) polarPlot8);
        java.lang.Object obj11 = jFreeChart10.clone();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart10.createBufferedImage((int) ' ', (int) '4', 0.0d, (double) 100L, chartRenderingInfo16);
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        boolean boolean19 = jFreeChart10.equals((java.lang.Object) stroke18);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        int int1 = xYLineAndShapeRenderer0.getPassCount();
        boolean boolean5 = xYLineAndShapeRenderer0.getItemCreateEntity(4, (int) (byte) 1, true);
        java.awt.Paint paint7 = xYLineAndShapeRenderer0.getSeriesItemLabelPaint(4);
        xYLineAndShapeRenderer0.setUseFillPaint(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = xYBarRenderer2.getBaseItemLabelPaint();
        boolean boolean7 = xYBarRenderer2.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        xYBarRenderer2.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator9);
        java.awt.Shape shape16 = null;
        java.awt.Paint paint18 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color20 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape23 = null;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color27 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape16, false, paint18, false, (java.awt.Paint) color20, stroke21, true, shape23, stroke24, (java.awt.Paint) color27);
        java.awt.Paint paint29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem28.setLabelPaint(paint29);
        xYBarRenderer2.setBaseLegendTextPaint(paint29);
        java.awt.Stroke stroke33 = xYBarRenderer2.lookupSeriesOutlineStroke((int) (byte) 100);
        xYBarRenderer2.setSeriesItemLabelsVisible(10, (java.lang.Boolean) false);
        java.lang.Boolean boolean38 = xYBarRenderer2.getSeriesVisibleInLegend((int) '#');
        java.awt.Font font40 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        xYBarRenderer2.setLegendTextFont(28, font40);
        xYLineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font40);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(boolean38);
        org.junit.Assert.assertNotNull(font40);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.getHeight();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Stroke stroke5 = xYBarRenderer1.getItemStroke((int) 'a', (int) '#', true);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset6, valueAxis7, polarItemRenderer8);
        polarPlot9.setNoDataMessage("ThreadContext");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        polarPlot9.setRenderer(polarItemRenderer12);
        boolean boolean14 = xYBarRenderer1.hasListener((java.util.EventListener) polarPlot9);
        polarPlot9.setAngleLabelsVisible(false);
        java.awt.Paint paint17 = polarPlot9.getAngleLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("Range[100.0,100.0]", (org.jfree.chart.plot.Plot) polarPlot9);
        boolean boolean19 = polarPlot9.isAngleGridlinesVisible();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        java.awt.Font font3 = piePlot1.getLabelFont();
        piePlot1.setLabelGap((double) 4);
        piePlot1.setStartAngle((double) 5);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        java.lang.Object obj31 = categoryPlot0.clone();
        java.awt.Stroke stroke32 = categoryPlot0.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        polarPlot4.datasetChanged(datasetChangeEvent6);
        java.awt.Font font8 = polarPlot4.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("12/31/69", font8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle11.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint14 = xYBarRenderer13.getBaseOutlinePaint();
        java.awt.Paint paint15 = xYBarRenderer13.getBasePaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer13.setSeriesItemLabelPaint(1, paint17);
        legendTitle11.setBackgroundPaint(paint17);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = legendTitle11.getHorizontalAlignment();
        textTitle9.setTextAlignment(horizontalAlignment20);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType22 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType22, 5);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType25 = dateTickUnit24.getUnitType();
        boolean boolean26 = textTitle9.equals((java.lang.Object) dateTickUnitType25);
        java.lang.String str27 = textTitle9.getText();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(dateTickUnitType22);
        org.junit.Assert.assertNotNull(dateTickUnitType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "12/31/69" + "'", str27.equals("12/31/69"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        boolean boolean10 = intervalXYDelegate9.isAutoWidth();
        intervalXYDelegate9.setIntervalPositionFactor(0.0d);
        intervalXYDelegate9.setFixedIntervalWidth(0.0d);
        double double15 = intervalXYDelegate9.getIntervalWidth();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = combinedDomainXYPlot1.getDomainAxisEdge((int) (short) -1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = combinedDomainXYPlot1.getDomainAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        axisSpace6.setTop((double) 432000000L);
        combinedDomainXYPlot1.setFixedDomainAxisSpace(axisSpace6);
        java.lang.Object obj10 = axisSpace6.clone();
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.Range range2 = null;
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range2, (double) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) 1577894400005L, range4);
        boolean boolean6 = defaultPieDataset0.equals((java.lang.Object) rectangleConstraint5);
        try {
            defaultPieDataset0.remove((java.lang.Comparable) "86,400,000");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (86,400,000) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint5 = xYBarRenderer4.getBaseOutlinePaint();
        java.awt.Shape shape11 = null;
        java.awt.Paint paint13 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color15 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape18 = null;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color22 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape11, false, paint13, false, (java.awt.Paint) color15, stroke16, true, shape18, stroke19, (java.awt.Paint) color22);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(0.0d, paint5, stroke19);
        double double25 = valueMarker24.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection27 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo(entityCollection27);
        boolean boolean29 = chartChangeEventType26.equals((java.lang.Object) entityCollection27);
        java.lang.String str30 = chartChangeEventType26.toString();
        boolean boolean31 = valueMarker24.equals((java.lang.Object) chartChangeEventType26);
        org.jfree.chart.util.Layer layer32 = null;
        boolean boolean34 = xYPlot1.removeRangeMarker(8, (org.jfree.chart.plot.Marker) valueMarker24, layer32, true);
        java.awt.Paint paint35 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot1.setDomainTickBandPaint(paint35);
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart("cyan", (org.jfree.chart.plot.Plot) xYPlot1);
        java.awt.Paint paint38 = jFreeChart37.getBackgroundPaint();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str30.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = categoryPlot1.getRangeMarkers((int) '4', layer3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries6 = null;
        java.util.TimeZone timeZone7 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeSeries6, timeZone7);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8, true);
        org.jfree.data.Range range12 = xYBarRenderer5.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot1, (org.jfree.data.general.Dataset) timeSeriesCollection8);
        java.awt.Stroke stroke14 = categoryPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot1.getRangeAxisLocation();
        boolean boolean16 = pieLabelLinkStyle0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot1.panDomainAxes((double) 28, plotRenderingInfo18, point2D19);
        org.jfree.chart.util.Rotation rotation21 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) rotation21);
        categoryPlot1.rendererChanged(rendererChangeEvent22);
        java.awt.Image image24 = categoryPlot1.getBackgroundImage();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rotation21);
        org.junit.Assert.assertNull(image24);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.Year year3 = month0.getYear();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setRangeMinorGridlinesVisible(false);
        boolean boolean7 = year3.equals((java.lang.Object) categoryPlot4);
        long long8 = year3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor3, textAnchor4, textAnchor5, (double) '#');
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.NumberTick numberTick10 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 12, "", textAnchor4, textAnchor8, (double) 1L);
        org.jfree.chart.axis.TickType tickType11 = numberTick10.getTickType();
        java.lang.String str12 = numberTick10.getText();
        java.lang.String str13 = numberTick10.toString();
        java.lang.String str14 = numberTick10.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(tickType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer3D0.getSeriesItemLabelGenerator(15);
        double double3 = barRenderer3D0.getMinimumBarLength();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer3D0.getSeriesToolTipGenerator(0);
        java.awt.Shape shape6 = barRenderer3D0.getBaseShape();
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getLegendItemGraphicPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle1.getVerticalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer5 = legendTitle1.getWrapper();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNull(blockContainer5);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Paint paint5 = xYBarRenderer3.getBasePaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer3.setSeriesItemLabelPaint(1, paint7);
        legendTitle1.setBackgroundPaint(paint7);
        double double10 = legendTitle1.getHeight();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer3D0.getSeriesItemLabelGenerator(15);
        java.awt.Paint paint3 = barRenderer3D0.getWallPaint();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot6.getRangeMarkers((int) '4', layer8);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries11 = null;
        java.util.TimeZone timeZone12 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries11, timeZone12);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection13, true);
        org.jfree.data.Range range17 = xYBarRenderer10.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection13);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot6, (org.jfree.data.general.Dataset) timeSeriesCollection13);
        java.awt.Stroke stroke19 = categoryPlot6.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot6.getRangeAxisLocation();
        boolean boolean21 = pieLabelLinkStyle5.equals((java.lang.Object) categoryPlot6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot6.panDomainAxes((double) 28, plotRenderingInfo23, point2D24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = categoryPlot6.getFixedDomainAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot(xYDataset27, valueAxis28, polarItemRenderer29);
        boolean boolean31 = polarPlot30.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent32 = null;
        polarPlot30.datasetChanged(datasetChangeEvent32);
        java.awt.Font font34 = polarPlot30.getNoDataMessageFont();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = categoryPlot36.getRangeMarkers((int) '4', layer38);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer40 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries41 = null;
        java.util.TimeZone timeZone42 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection43 = new org.jfree.data.time.TimeSeriesCollection(timeSeries41, timeZone42);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection43);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection43, true);
        org.jfree.data.Range range47 = xYBarRenderer40.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection43);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent48 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot36, (org.jfree.data.general.Dataset) timeSeriesCollection43);
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource51 = null;
        chartRenderingInfo50.setRenderingSource(renderingSource51);
        java.awt.geom.Rectangle2D rectangle2D53 = chartRenderingInfo50.getChartArea();
        java.awt.geom.Point2D point2D54 = null;
        org.jfree.chart.plot.PlotState plotState55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        categoryPlot36.draw(graphics2D49, rectangle2D53, point2D54, plotState55, plotRenderingInfo56);
        java.awt.geom.Point2D point2D58 = null;
        org.jfree.chart.plot.PlotState plotState59 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        polarPlot30.draw(graphics2D35, rectangle2D53, point2D58, plotState59, plotRenderingInfo60);
        try {
            barRenderer3D0.drawBackground(graphics2D4, categoryPlot6, rectangle2D53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(axisSpace26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNotNull(rectangle2D53);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.awt.Shape shape17 = null;
        java.awt.Paint paint19 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color21 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color28 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape17, false, paint19, false, (java.awt.Paint) color21, stroke22, true, shape24, stroke25, (java.awt.Paint) color28);
        java.lang.Object obj30 = null;
        boolean boolean31 = legendItem29.equals(obj30);
        java.awt.Paint paint32 = legendItem29.getFillPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape10, paint32);
        java.awt.Shape shape34 = legendGraphic33.getShape();
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer39 = null;
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot(xYDataset37, valueAxis38, polarItemRenderer39);
        java.awt.Font font41 = polarPlot40.getNoDataMessageFont();
        org.jfree.chart.entity.PlotEntity plotEntity42 = new org.jfree.chart.entity.PlotEntity(shape36, (org.jfree.chart.plot.Plot) polarPlot40);
        boolean boolean43 = legendGraphic33.equals((java.lang.Object) plotEntity42);
        java.awt.Stroke stroke44 = legendGraphic33.getOutlineStroke();
        org.jfree.chart.plot.PlotState plotState45 = new org.jfree.chart.plot.PlotState();
        boolean boolean46 = legendGraphic33.equals((java.lang.Object) plotState45);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer1.setShadowYOffset((double) 0L);
        xYBarRenderer1.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer1.setBaseOutlinePaint((java.awt.Paint) color8);
        boolean boolean10 = standardXYToolTipGenerator0.equals((java.lang.Object) xYBarRenderer1);
        java.text.NumberFormat numberFormat11 = standardXYToolTipGenerator0.getYFormat();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint13 = xYBarRenderer12.getBaseOutlinePaint();
        java.awt.Paint paint14 = xYBarRenderer12.getBasePaint();
        java.awt.Font font16 = xYBarRenderer12.getSeriesItemLabelFont((int) (byte) 0);
        boolean boolean17 = xYBarRenderer12.getShadowsVisible();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator19 = new org.jfree.chart.urls.StandardXYURLGenerator("Combined_Domain_XYPlot");
        xYBarRenderer12.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator19);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer21 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator0, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator19);
        java.lang.Object obj22 = xYStepRenderer21.clone();
        java.lang.Object obj23 = xYStepRenderer21.clone();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, (double) 10.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getWidthConstraintType();
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range8, 0.0d);
        boolean boolean13 = range8.intersects((double) 'a', (double) (short) 0);
        boolean boolean14 = lengthConstraintType5.equals((java.lang.Object) boolean13);
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude(range17, (double) 100);
        double double20 = range19.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range23 = null;
        org.jfree.data.Range range24 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(range24, (double) 10.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType27 = rectangleConstraint26.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint((double) '4', range19, lengthConstraintType21, (double) 12, range23, lengthConstraintType27);
        java.lang.Object obj29 = null;
        boolean boolean30 = range19.equals(obj29);
        org.jfree.data.Range range32 = null;
        org.jfree.data.Range range34 = org.jfree.data.Range.expandToInclude(range32, (double) 100);
        double double35 = range34.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType36 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range38 = null;
        org.jfree.data.Range range39 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = new org.jfree.chart.block.RectangleConstraint(range39, (double) 10.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType42 = rectangleConstraint41.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint((double) '4', range34, lengthConstraintType36, (double) 12, range38, lengthConstraintType42);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint((double) 1.0f, range1, lengthConstraintType5, (double) 0.5f, range19, lengthConstraintType36);
        org.jfree.data.Range range45 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range46 = org.jfree.data.Range.combine(range19, range45);
        boolean boolean48 = range19.contains((double) 1560495599999L);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType21);
        org.junit.Assert.assertNotNull(lengthConstraintType27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType36);
        org.junit.Assert.assertNotNull(lengthConstraintType42);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        try {
            double double4 = defaultXYDataset0.getXValue(5, (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number1);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test057");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.lang.String str2 = day1.toString();
//        org.jfree.data.xy.XYDataset xYDataset3 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
//        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
//        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
//        boolean boolean7 = polarPlot6.isAngleLabelsVisible();
//        polarPlot6.setAngleLabelsVisible(true);
//        int int10 = day1.compareTo((java.lang.Object) polarPlot6);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        java.util.Date date12 = month11.getStart();
//        java.util.Date date13 = month11.getEnd();
//        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) month11);
//        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        java.awt.Paint paint19 = xYBarRenderer18.getBaseOutlinePaint();
//        java.awt.Shape shape25 = null;
//        java.awt.Paint paint27 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
//        java.awt.Color color29 = java.awt.Color.YELLOW;
//        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        java.awt.Shape shape32 = null;
//        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        java.awt.Color color36 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
//        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape25, false, paint27, false, (java.awt.Paint) color29, stroke30, true, shape32, stroke33, (java.awt.Paint) color36);
//        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker(0.0d, paint19, stroke33);
//        double double39 = valueMarker38.getValue();
//        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
//        boolean boolean42 = categoryPlot15.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker38, layer40, false);
//        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot15.getDomainAxisEdge();
//        double double44 = categoryPlot15.getRangeCrosshairValue();
//        double double45 = categoryPlot15.getAnchorValue();
//        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
//        categoryPlot15.setRangeAxis(1, valueAxis47);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
//        java.awt.geom.Point2D point2D51 = null;
//        categoryPlot15.panRangeAxes((double) 3, plotRenderingInfo50, point2D51);
//        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot15);
//        java.awt.Paint paint54 = jFreeChart53.getBorderPaint();
//        java.awt.Paint paint55 = jFreeChart53.getBorderPaint();
//        periodAxis14.setMinorTickMarkPaint(paint55);
//        java.lang.Class class57 = periodAxis14.getMajorTickTimePeriodClass();
//        java.lang.Object obj58 = periodAxis14.clone();
//        org.jfree.data.Range range59 = periodAxis14.getRange();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(paint19);
//        org.junit.Assert.assertNotNull(paint27);
//        org.junit.Assert.assertNotNull(color29);
//        org.junit.Assert.assertNotNull(stroke30);
//        org.junit.Assert.assertNotNull(stroke33);
//        org.junit.Assert.assertNotNull(color36);
//        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
//        org.junit.Assert.assertNotNull(layer40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge43);
//        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
//        org.junit.Assert.assertNotNull(paint54);
//        org.junit.Assert.assertNotNull(paint55);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertNotNull(obj58);
//        org.junit.Assert.assertNotNull(range59);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        org.jfree.data.Range range5 = null;
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, (double) 100);
        double double8 = range7.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range11 = null;
        org.jfree.data.Range range12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(range12, (double) 10.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) '4', range7, lengthConstraintType9, (double) 12, range11, lengthConstraintType15);
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude(range17, (double) 100);
        double double20 = range19.getLength();
        boolean boolean23 = range19.intersects((double) 4, (double) 0.0f);
        boolean boolean24 = range7.intersects(range19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = rectangleConstraint2.toRangeHeight(range19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint(range19, (double) '4');
        double double28 = range19.getUpperBound();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.0d + "'", double28 == 100.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) 1577894400005L, "NOID", true);
        logFormat3.setGroupingUsed(true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        java.lang.Object obj1 = xYSeriesCollection0.clone();
        xYSeriesCollection0.removeAllSeries();
        xYSeriesCollection0.setAutoWidth(true);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.util.Date date6 = month5.getStart();
        long long7 = month5.getSerialIndex();
        try {
            org.jfree.data.xy.XYSeries xYSeries8 = xYSeriesCollection0.getSeries((java.lang.Comparable) month5);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: June 2019");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint5 = xYBarRenderer4.getBaseOutlinePaint();
        java.awt.Shape shape11 = null;
        java.awt.Paint paint13 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color15 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape18 = null;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color22 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape11, false, paint13, false, (java.awt.Paint) color15, stroke16, true, shape18, stroke19, (java.awt.Paint) color22);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(0.0d, paint5, stroke19);
        double double25 = valueMarker24.getValue();
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean28 = categoryPlot1.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker24, layer26, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot1.getDomainAxisEdge();
        double double30 = categoryPlot1.getRangeCrosshairValue();
        java.awt.Stroke stroke31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        categoryPlot1.setRangeMinorGridlineStroke(stroke31);
        boolean boolean33 = unitType0.equals((java.lang.Object) categoryPlot1);
        java.lang.String str34 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1L), (-1.0d), Double.NaN, (double) (byte) -1);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "UnitType.ABSOLUTE" + "'", str34.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        double double5 = legendTitle4.getHeight();
        legendTitle4.setPadding((double) 11, (double) 1577894400005L, (double) 9999, (double) (short) -1);
        boolean boolean11 = legendTitle4.isVisible();
        boolean boolean12 = multiplePiePlot0.equals((java.lang.Object) boolean11);
        double double13 = multiplePiePlot0.getLimit();
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer1.setShadowYOffset((double) 0L);
        xYBarRenderer1.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer1.setBaseOutlinePaint((java.awt.Paint) color8);
        boolean boolean10 = standardXYToolTipGenerator0.equals((java.lang.Object) xYBarRenderer1);
        java.text.NumberFormat numberFormat11 = standardXYToolTipGenerator0.getYFormat();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint13 = xYBarRenderer12.getBaseOutlinePaint();
        java.awt.Paint paint14 = xYBarRenderer12.getBasePaint();
        java.awt.Font font16 = xYBarRenderer12.getSeriesItemLabelFont((int) (byte) 0);
        boolean boolean17 = xYBarRenderer12.getShadowsVisible();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator19 = new org.jfree.chart.urls.StandardXYURLGenerator("Combined_Domain_XYPlot");
        xYBarRenderer12.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator19);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer21 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator0, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator19);
        java.lang.Object obj22 = xYStepRenderer21.clone();
        java.lang.Boolean boolean24 = xYStepRenderer21.getSeriesShapesVisible(7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(boolean24);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer3D0.getSeriesItemLabelGenerator(15);
        double double3 = barRenderer3D0.getItemMargin();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(5, categoryURLGenerator5, true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = state1.getEntityCollection();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState3 = state1.getSelectionState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo4);
        org.jfree.chart.entity.EntityCollection entityCollection6 = state5.getEntityCollection();
        java.awt.geom.Line2D line2D7 = state5.workingLine;
        state1.workingLine = line2D7;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = state1.getInfo();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState10 = state1.getSelectionState();
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertNull(xYDatasetSelectionState3);
        org.junit.Assert.assertNull(entityCollection6);
        org.junit.Assert.assertNotNull(line2D7);
        org.junit.Assert.assertNull(plotRenderingInfo9);
        org.junit.Assert.assertNull(xYDatasetSelectionState10);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean((int) '4', (java.lang.Boolean) true);
        booleanList0.clear();
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D();
        size2D5.width = 0L;
        boolean boolean8 = booleanList0.equals((java.lang.Object) 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape14 = null;
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color25 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape14, false, paint16, false, (java.awt.Paint) color18, stroke19, true, shape21, stroke22, (java.awt.Paint) color25);
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem26.setLabelPaint(paint27);
        xYBarRenderer0.setBaseLegendTextPaint(paint27);
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle32 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = categoryPlot33.getRangeMarkers((int) '4', layer35);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries38 = null;
        java.util.TimeZone timeZone39 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection40 = new org.jfree.data.time.TimeSeriesCollection(timeSeries38, timeZone39);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection40);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection40, true);
        org.jfree.data.Range range44 = xYBarRenderer37.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection40);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent45 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot33, (org.jfree.data.general.Dataset) timeSeriesCollection40);
        java.awt.Stroke stroke46 = categoryPlot33.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation47 = categoryPlot33.getRangeAxisLocation();
        boolean boolean48 = pieLabelLinkStyle32.equals((java.lang.Object) categoryPlot33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        java.awt.geom.Point2D point2D51 = null;
        categoryPlot33.panDomainAxes((double) 28, plotRenderingInfo50, point2D51);
        org.jfree.chart.entity.PlotEntity plotEntity53 = new org.jfree.chart.entity.PlotEntity(shape31, (org.jfree.chart.plot.Plot) categoryPlot33);
        xYBarRenderer0.setLegendShape(2, shape31);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle32);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer0.setShadowYOffset((double) 0L);
        xYBarRenderer0.setShadowXOffset(100.0d);
        boolean boolean7 = xYBarRenderer0.getBaseItemLabelsVisible();
        java.awt.Shape shape8 = xYBarRenderer0.getBaseShape();
        java.awt.Font font10 = xYBarRenderer0.lookupLegendTextFont(0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(font10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        double double5 = categoryAxis0.getUpperMargin();
        categoryAxis0.setMinorTickMarkOutsideLength((float) (-57600001L));
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setCopyright("item");
        java.lang.String str3 = projectInfo0.getLicenceText();
        java.lang.String str4 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextBlockAnchor.BOTTOM_CENTER" + "'", str3.equals("TextBlockAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.BOTTOM_CENTER" + "'", str4.equals("TextBlockAnchor.BOTTOM_CENTER"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.addChangeListener(plotChangeListener3);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator5 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        piePlot1.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator5);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = piePlot1.getLabelLinkStyle();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        java.awt.Font font3 = piePlot1.getLabelFont();
        piePlot1.setLabelGap((double) 4);
        double double6 = piePlot1.getInteriorGap();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = piePlot1.getLegendItems();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test074");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.lang.String str2 = day1.toString();
//        org.jfree.data.xy.XYDataset xYDataset3 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
//        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
//        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
//        boolean boolean7 = polarPlot6.isAngleLabelsVisible();
//        polarPlot6.setAngleLabelsVisible(true);
//        int int10 = day1.compareTo((java.lang.Object) polarPlot6);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        java.util.Date date12 = month11.getStart();
//        java.util.Date date13 = month11.getEnd();
//        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) month11);
//        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        java.awt.Paint paint19 = xYBarRenderer18.getBaseOutlinePaint();
//        java.awt.Shape shape25 = null;
//        java.awt.Paint paint27 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
//        java.awt.Color color29 = java.awt.Color.YELLOW;
//        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        java.awt.Shape shape32 = null;
//        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        java.awt.Color color36 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
//        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape25, false, paint27, false, (java.awt.Paint) color29, stroke30, true, shape32, stroke33, (java.awt.Paint) color36);
//        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker(0.0d, paint19, stroke33);
//        double double39 = valueMarker38.getValue();
//        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
//        boolean boolean42 = categoryPlot15.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker38, layer40, false);
//        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot15.getDomainAxisEdge();
//        double double44 = categoryPlot15.getRangeCrosshairValue();
//        double double45 = categoryPlot15.getAnchorValue();
//        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
//        categoryPlot15.setRangeAxis(1, valueAxis47);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
//        java.awt.geom.Point2D point2D51 = null;
//        categoryPlot15.panRangeAxes((double) 3, plotRenderingInfo50, point2D51);
//        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot15);
//        java.awt.Paint paint54 = jFreeChart53.getBorderPaint();
//        java.awt.Paint paint55 = jFreeChart53.getBorderPaint();
//        periodAxis14.setMinorTickMarkPaint(paint55);
//        java.lang.Class class57 = periodAxis14.getMajorTickTimePeriodClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = periodAxis14.getLast();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(paint19);
//        org.junit.Assert.assertNotNull(paint27);
//        org.junit.Assert.assertNotNull(color29);
//        org.junit.Assert.assertNotNull(stroke30);
//        org.junit.Assert.assertNotNull(stroke33);
//        org.junit.Assert.assertNotNull(color36);
//        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
//        org.junit.Assert.assertNotNull(layer40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge43);
//        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
//        org.junit.Assert.assertNotNull(paint54);
//        org.junit.Assert.assertNotNull(paint55);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        java.awt.Image image2 = null;
        projectInfo0.setLogo(image2);
        projectInfo0.setInfo("WMAP_Plot");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JFreeChart version 1.2.0-pre.\nitem.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Greg Darke (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Martin Hoeller (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Peter Kolb (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Eric Penfold (-).Tomer Peretz (-).Diego Pierangeli (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Darshan Shah (-).Mofeed Shahin (-).Michael Siemer (-).Pady Srinivasan (-).Greg Steckman (-).Gerald Struck (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Jess Thrysoee (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Ulrich Voigt (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTextBlockAnchor.BOTTOM_CENTER" + "'", str1.equals("JFreeChart version 1.2.0-pre.\nitem.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Greg Darke (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Martin Hoeller (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Peter Kolb (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Eric Penfold (-).Tomer Peretz (-).Diego Pierangeli (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Darshan Shah (-).Mofeed Shahin (-).Michael Siemer (-).Pady Srinivasan (-).Greg Steckman (-).Gerald Struck (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Jess Thrysoee (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Ulrich Voigt (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTextBlockAnchor.BOTTOM_CENTER"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.width = 0L;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Font font7 = polarPlot6.getNoDataMessageFont();
        boolean boolean8 = size2D0.equals((java.lang.Object) font7);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection2);
        org.jfree.data.xy.XYDataItem xYDataItem12 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number13 = xYDataItem12.getX();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem12, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset17 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset17.removeSeries((java.lang.Comparable) 'a');
        timeSeries16.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset17);
        timeSeriesCollection2.addSeries(timeSeries16);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, false);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100.0d + "'", number13.equals(100.0d));
        org.junit.Assert.assertNull(range23);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Paint paint2 = xYLineAndShapeRenderer0.getSeriesItemLabelPaint(0);
        xYLineAndShapeRenderer0.setUseFillPaint(true);
        java.awt.Paint paint5 = xYLineAndShapeRenderer0.getBaseItemLabelPaint();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset6 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset6);
        org.jfree.data.Range range8 = xYLineAndShapeRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset6);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray1);
        java.lang.Object obj3 = symbolAxis2.clone();
        org.jfree.data.Range range4 = symbolAxis2.getRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.expandToInclude(range4, (double) (-1));
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        categoryPlot0.mapDatasetToDomainAxis(2, (int) (byte) 1);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.axis.ValueAxis valueAxis36 = categoryPlot0.getRangeAxis(8);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer39 = null;
        java.util.Collection collection40 = categoryPlot37.getRangeMarkers((int) '4', layer39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        categoryPlot37.setDomainAxis((int) (short) 0, categoryAxis42, true);
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        categoryPlot37.setFixedRangeAxisSpace(axisSpace45);
        double double47 = categoryPlot37.getAnchorValue();
        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot37.setRangeAxisLocation(axisLocation48);
        org.jfree.chart.axis.AxisLocation axisLocation50 = categoryPlot37.getRangeAxisLocation();
        categoryPlot0.setRangeAxisLocation(axisLocation50);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(axisLocation50);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        java.lang.String str1 = dateTickUnitType0.toString();
        java.awt.Shape shape7 = null;
        java.awt.Paint paint9 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color18 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape7, false, paint9, false, (java.awt.Paint) color11, stroke12, true, shape14, stroke15, (java.awt.Paint) color18);
        boolean boolean20 = dateTickUnitType0.equals((java.lang.Object) "ThreadContext");
        java.lang.Object obj21 = null;
        boolean boolean22 = dateTickUnitType0.equals(obj21);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnitType.DAY" + "'", str1.equals("DateTickUnitType.DAY"));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer0.setShadowXOffset((double) (short) 100);
        java.awt.Color color5 = java.awt.Color.pink;
        int int6 = color5.getTransparency();
        xYBarRenderer0.setBaseFillPaint((java.awt.Paint) color5);
        java.awt.Color color11 = java.awt.Color.orange;
        float[] floatArray18 = new float[] { 1.0f, 1L, ' ', 3, 28, 0.0f };
        float[] floatArray19 = color11.getRGBComponents(floatArray18);
        float[] floatArray20 = java.awt.Color.RGBtoHSB((int) 'a', (int) (short) -1, (int) (short) 0, floatArray18);
        float[] floatArray21 = color5.getComponents(floatArray18);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = combinedDomainXYPlot1.getDomainAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        axisSpace6.setTop((double) 432000000L);
        combinedDomainXYPlot1.setFixedDomainAxisSpace(axisSpace6);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = combinedDomainXYPlot1.getLegendItems();
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.awt.Color color0 = java.awt.Color.WHITE;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getStart();
        long long3 = month1.getSerialIndex();
        org.jfree.data.time.Year year4 = month1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] { 4.0d, regularTimePeriod5, "PlotOrientation.HORIZONTAL" };
        java.lang.String[] strArray8 = org.jfree.data.time.SerialDate.getMonths();
        double[] doubleArray10 = new double[] { 1 };
        double[] doubleArray12 = new double[] { 1 };
        double[] doubleArray14 = new double[] { 1 };
        double[] doubleArray16 = new double[] { 1 };
        double[][] doubleArray17 = new double[][] { doubleArray10, doubleArray12, doubleArray14, doubleArray16 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, (java.lang.Comparable[]) strArray8, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeSeries8);
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeriesCollection9.getSeries((int) (byte) 0);
        java.util.Collection collection12 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        timeSeries11.setMaximumItemCount((int) (byte) 10);
        try {
            timeSeries11.delete((int) '4', 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.NEGATIVE" + "'", str1.equals("RangeType.NEGATIVE"));
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test088");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.lang.String str2 = day1.toString();
//        org.jfree.data.xy.XYDataset xYDataset3 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
//        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
//        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
//        boolean boolean7 = polarPlot6.isAngleLabelsVisible();
//        polarPlot6.setAngleLabelsVisible(true);
//        int int10 = day1.compareTo((java.lang.Object) polarPlot6);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        java.util.Date date12 = month11.getStart();
//        java.util.Date date13 = month11.getEnd();
//        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) month11);
//        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        java.awt.Paint paint19 = xYBarRenderer18.getBaseOutlinePaint();
//        java.awt.Shape shape25 = null;
//        java.awt.Paint paint27 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
//        java.awt.Color color29 = java.awt.Color.YELLOW;
//        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        java.awt.Shape shape32 = null;
//        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        java.awt.Color color36 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
//        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape25, false, paint27, false, (java.awt.Paint) color29, stroke30, true, shape32, stroke33, (java.awt.Paint) color36);
//        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker(0.0d, paint19, stroke33);
//        double double39 = valueMarker38.getValue();
//        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
//        boolean boolean42 = categoryPlot15.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker38, layer40, false);
//        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot15.getDomainAxisEdge();
//        double double44 = categoryPlot15.getRangeCrosshairValue();
//        double double45 = categoryPlot15.getAnchorValue();
//        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
//        categoryPlot15.setRangeAxis(1, valueAxis47);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
//        java.awt.geom.Point2D point2D51 = null;
//        categoryPlot15.panRangeAxes((double) 3, plotRenderingInfo50, point2D51);
//        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot15);
//        java.awt.Paint paint54 = jFreeChart53.getBorderPaint();
//        java.awt.Paint paint55 = jFreeChart53.getBorderPaint();
//        periodAxis14.setMinorTickMarkPaint(paint55);
//        double double57 = periodAxis14.getUpperMargin();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(paint19);
//        org.junit.Assert.assertNotNull(paint27);
//        org.junit.Assert.assertNotNull(color29);
//        org.junit.Assert.assertNotNull(stroke30);
//        org.junit.Assert.assertNotNull(stroke33);
//        org.junit.Assert.assertNotNull(color36);
//        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
//        org.junit.Assert.assertNotNull(layer40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge43);
//        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
//        org.junit.Assert.assertNotNull(paint54);
//        org.junit.Assert.assertNotNull(paint55);
//        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.05d + "'", double57 == 0.05d);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 100.0d, false, false);
        double double4 = xYSeries3.getMaxY();
        java.lang.Number number6 = null;
        xYSeries3.add((double) (-2), number6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        xYSeriesCollection8.clearSelection();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 100.0d, false, false);
        double double4 = xYSeries3.getMaxY();
        java.lang.Number number6 = null;
        xYSeries3.add((double) (-2), number6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        boolean boolean9 = xYSeriesCollection8.isAutoWidth();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("{0}", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getStart();
        java.util.Date date6 = month4.getEnd();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-57600001L));
        org.jfree.data.xy.XYDataItem xYDataItem11 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number12 = xYDataItem11.getX();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem11, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset16.removeSeries((java.lang.Comparable) 'a');
        timeSeries15.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset16);
        org.jfree.data.time.TimeSeries timeSeries20 = null;
        java.util.TimeZone timeZone21 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeSeries20, timeZone21);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection22);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection22, true);
        timeSeries15.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection22);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        java.util.Date date28 = month27.getStart();
        long long29 = month27.getSerialIndex();
        org.jfree.data.time.Year year30 = month27.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 0.05d, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 12);
        java.lang.Object obj36 = timeSeriesDataItem35.clone();
        java.lang.Object obj37 = timeSeriesDataItem35.clone();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0d + "'", number12.equals(100.0d));
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 24234L + "'", long29 == 24234L);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.awt.Shape shape17 = null;
        java.awt.Paint paint19 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color21 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color28 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape17, false, paint19, false, (java.awt.Paint) color21, stroke22, true, shape24, stroke25, (java.awt.Paint) color28);
        java.lang.Object obj30 = null;
        boolean boolean31 = legendItem29.equals(obj30);
        java.awt.Paint paint32 = legendItem29.getFillPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape10, paint32);
        java.awt.Shape shape34 = legendGraphic33.getShape();
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 100);
        legendGraphic33.setLine(shape36);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape36);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) 10.0f, (double) 432000000L, (double) (short) 0);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer5.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.plot.XYPlot xYPlot8 = xYBarRenderer5.getPlot();
        xYBarRenderer5.setShadowYOffset(Double.NaN);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarksVisible(false);
        categoryAxis14.configure();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource25 = null;
        chartRenderingInfo24.setRenderingSource(renderingSource25);
        java.awt.geom.Rectangle2D rectangle2D27 = chartRenderingInfo24.getChartArea();
        org.jfree.chart.axis.AxisState axisState28 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        axisState28.moveCursor((double) 0, rectangleEdge30);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState28.moveCursor((double) 100L, rectangleEdge33);
        double double35 = categoryAxis20.getCategoryJava2DCoordinate(categoryAnchor21, 10, (int) (short) 0, rectangle2D27, rectangleEdge33);
        org.jfree.chart.axis.AxisState axisState36 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        axisState36.moveCursor((double) 0, rectangleEdge38);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState36.moveCursor((double) 100L, rectangleEdge41);
        axisState36.setCursor((double) 3);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer49 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint50 = xYBarRenderer49.getBaseOutlinePaint();
        java.awt.Shape shape56 = null;
        java.awt.Paint paint58 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color60 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke61 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape63 = null;
        java.awt.Stroke stroke64 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color67 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape56, false, paint58, false, (java.awt.Paint) color60, stroke61, true, shape63, stroke64, (java.awt.Paint) color67);
        org.jfree.chart.plot.ValueMarker valueMarker69 = new org.jfree.chart.plot.ValueMarker(0.0d, paint50, stroke64);
        double double70 = valueMarker69.getValue();
        org.jfree.chart.util.Layer layer71 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean73 = categoryPlot46.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker69, layer71, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = categoryPlot46.getDomainAxisEdge();
        axisState36.moveCursor(2.0d, rectangleEdge74);
        org.jfree.chart.axis.AxisState axisState76 = null;
        categoryAxis14.drawTickMarks(graphics2D18, (double) 9, rectangle2D27, rectangleEdge74, axisState76);
        org.jfree.chart.axis.ValueAxis valueAxis78 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot79 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis78);
        combinedDomainXYPlot79.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = combinedDomainXYPlot79.getDomainAxisEdge((int) (byte) -1);
        try {
            gradientXYBarPainter3.paintBar(graphics2D4, xYBarRenderer5, 5, 2147483647, false, (java.awt.geom.RectangularShape) rectangle2D27, rectangleEdge83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYPlot8);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(layer71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(rectangleEdge83);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        legendTitle1.setPadding((double) 11, (double) 1577894400005L, (double) 9999, (double) (short) -1);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendTitle9.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint12 = xYBarRenderer11.getBaseOutlinePaint();
        java.awt.Paint paint13 = xYBarRenderer11.getBasePaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer11.setSeriesItemLabelPaint(1, paint15);
        legendTitle9.setBackgroundPaint(paint15);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray18 = legendTitle9.getSources();
        legendTitle1.setSources(legendItemSourceArray18);
        java.lang.Object obj20 = legendTitle1.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(legendItemSourceArray18);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isAngleLabelsVisible();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = null;
        polarPlot3.axisChanged(axisChangeEvent5);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint8 = xYBarRenderer7.getBaseItemLabelPaint();
        boolean boolean12 = xYBarRenderer7.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        xYBarRenderer7.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator14);
        java.awt.Shape shape21 = null;
        java.awt.Paint paint23 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape28 = null;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color32 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape21, false, paint23, false, (java.awt.Paint) color25, stroke26, true, shape28, stroke29, (java.awt.Paint) color32);
        java.awt.Paint paint34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem33.setLabelPaint(paint34);
        xYBarRenderer7.setBaseLegendTextPaint(paint34);
        java.awt.Stroke stroke38 = xYBarRenderer7.lookupSeriesOutlineStroke((int) (byte) 100);
        xYBarRenderer7.setSeriesItemLabelsVisible(10, (java.lang.Boolean) false);
        java.lang.Boolean boolean43 = xYBarRenderer7.getSeriesVisibleInLegend((int) '#');
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator45 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer46 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer46.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer46.setShadowYOffset((double) 0L);
        xYBarRenderer46.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color53 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer46.setBaseOutlinePaint((java.awt.Paint) color53);
        boolean boolean55 = standardXYToolTipGenerator45.equals((java.lang.Object) xYBarRenderer46);
        xYBarRenderer7.setSeriesToolTipGenerator(2, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator45, true);
        java.lang.Object obj58 = standardXYToolTipGenerator45.clone();
        boolean boolean59 = polarPlot3.equals((java.lang.Object) standardXYToolTipGenerator45);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNull(boolean43);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Year year3 = month0.getYear();
        java.awt.Shape shape8 = null;
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendTitle10.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint13 = xYBarRenderer12.getBaseOutlinePaint();
        java.awt.Paint paint14 = xYBarRenderer12.getBasePaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer12.setSeriesItemLabelPaint(1, paint16);
        legendTitle10.setBackgroundPaint(paint16);
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("October", "DateTickUnitType.DAY", "", "", shape8, paint16);
        legendItem19.setShapeVisible(false);
        boolean boolean22 = year3.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Stroke stroke8 = xYBarRenderer4.getItemStroke((int) 'a', (int) '#', true);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset9, valueAxis10, polarItemRenderer11);
        polarPlot12.setNoDataMessage("ThreadContext");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        polarPlot12.setRenderer(polarItemRenderer15);
        boolean boolean17 = xYBarRenderer4.hasListener((java.util.EventListener) polarPlot12);
        polarPlot12.setAngleLabelsVisible(false);
        java.awt.Paint paint20 = polarPlot12.getAngleLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("Range[100.0,100.0]", (org.jfree.chart.plot.Plot) polarPlot12);
        try {
            multiplePiePlot0.setPieChart(jFreeChart21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'pieChart' argument must be a chart based on a PiePlot.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace6 = combinedDomainXYPlot1.getFixedRangeAxisSpace();
        combinedDomainXYPlot1.setDomainCrosshairValue(0.0d, false);
        java.util.List list10 = combinedDomainXYPlot1.getSubplots();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer0.setShadowYOffset((double) 0L);
        xYBarRenderer0.setShadowXOffset(100.0d);
        xYBarRenderer0.setBarAlignmentFactor((double) 9223372036854775807L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape14 = null;
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color25 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape14, false, paint16, false, (java.awt.Paint) color18, stroke19, true, shape21, stroke22, (java.awt.Paint) color25);
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem26.setLabelPaint(paint27);
        xYBarRenderer0.setBaseLegendTextPaint(paint27);
        java.awt.Stroke stroke31 = xYBarRenderer0.lookupSeriesOutlineStroke((int) (byte) 100);
        xYBarRenderer0.setSeriesItemLabelsVisible(10, (java.lang.Boolean) false);
        java.lang.Boolean boolean36 = xYBarRenderer0.getSeriesVisibleInLegend((int) '#');
        java.awt.Font font38 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        xYBarRenderer0.setLegendTextFont(28, font38);
        java.awt.Stroke stroke43 = xYBarRenderer0.getItemStroke(8, 0, false);
        java.awt.Paint paint47 = xYBarRenderer0.getItemFillPaint(4, (int) (byte) 100, true);
        xYBarRenderer0.removeAnnotations();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(boolean36);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth((double) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        combinedDomainXYPlot4.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = combinedDomainXYPlot4.getAxisOffset();
        ringPlot0.setInsets(rectangleInsets7, false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = state1.getEntityCollection();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState3 = state1.getSelectionState();
        state1.setLastPointGood(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = state1.getInfo();
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertNull(xYDatasetSelectionState3);
        org.junit.Assert.assertNull(plotRenderingInfo6);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        java.awt.Stroke stroke12 = combinedDomainXYPlot1.getDomainMinorGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.lang.String[] strArray16 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis17 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray16);
        java.lang.Object obj18 = symbolAxis17.clone();
        symbolAxis17.setRangeWithMargins(0.05d, (double) 1560495599999L);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis23.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource26 = null;
        chartRenderingInfo25.setRenderingSource(renderingSource26);
        java.awt.geom.Rectangle2D rectangle2D28 = chartRenderingInfo25.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets24.createInsetRectangle(rectangle2D28, false, false);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D28);
        org.jfree.chart.axis.AxisState axisState33 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        axisState33.moveCursor((double) 0, rectangleEdge35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState33.moveCursor((double) 100L, rectangleEdge38);
        double double40 = symbolAxis17.java2DToValue((double) 1577894400001L, rectangle2D28, rectangleEdge38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D28, rectangleAnchor41);
        combinedDomainXYPlot1.panRangeAxes((double) (-57600000L), plotRenderingInfo14, point2D42);
        boolean boolean44 = combinedDomainXYPlot1.isDomainMinorGridlinesVisible();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        java.lang.Object obj1 = xYSeriesCollection0.clone();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        combinedDomainXYPlot3.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = combinedDomainXYPlot3.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = combinedDomainXYPlot3.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace8 = combinedDomainXYPlot3.getFixedRangeAxisSpace();
        combinedDomainXYPlot3.setDomainCrosshairValue(0.0d, false);
        org.jfree.chart.axis.AxisSpace axisSpace12 = combinedDomainXYPlot3.getFixedDomainAxisSpace();
        xYSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) combinedDomainXYPlot3);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.awt.Stroke stroke16 = piePlot15.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot15.addChangeListener(plotChangeListener17);
        java.awt.Stroke stroke19 = piePlot15.getLabelOutlineStroke();
        combinedDomainXYPlot3.setRangeZeroBaselineStroke(stroke19);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer3D0.getSeriesItemLabelGenerator(15);
        barRenderer3D0.setItemMargin((double) 100);
        boolean boolean5 = barRenderer3D0.getAutoPopulateSeriesFillPaint();
        double double6 = barRenderer3D0.getShadowXOffset();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '4', layer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot8.setDomainAxis((int) (short) 0, categoryAxis13, true);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        categoryPlot8.setFixedRangeAxisSpace(axisSpace16);
        boolean boolean18 = categoryPlot8.isOutlineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot8.setDomainAxisLocation(axisLocation19);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource22 = null;
        chartRenderingInfo21.setRenderingSource(renderingSource22);
        java.awt.geom.Rectangle2D rectangle2D24 = chartRenderingInfo21.getChartArea();
        try {
            barRenderer3D0.drawOutline(graphics2D7, categoryPlot8, rectangle2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(rectangle2D24);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((double) 432000000L, (double) (-460));
        double double5 = ringPlot0.getExplodePercent((java.lang.Comparable) (-460));
        boolean boolean6 = ringPlot0.getSectionOutlinesVisible();
        ringPlot0.setAutoPopulateSectionOutlinePaint(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        boolean boolean28 = chartChangeEventType25.equals((java.lang.Object) entityCollection26);
        java.lang.String str29 = chartChangeEventType25.toString();
        boolean boolean30 = valueMarker23.equals((java.lang.Object) chartChangeEventType25);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean33 = xYPlot0.removeRangeMarker(8, (org.jfree.chart.plot.Marker) valueMarker23, layer31, true);
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot0.getDataset();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder35 = xYPlot0.getSeriesRenderingOrder();
        java.lang.String str36 = seriesRenderingOrder35.toString();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str29.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNotNull(seriesRenderingOrder35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str36.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getStart();
        java.util.Date date6 = month4.getEnd();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-57600001L));
        org.jfree.data.xy.XYDataItem xYDataItem11 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number12 = xYDataItem11.getX();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem11, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset16.removeSeries((java.lang.Comparable) 'a');
        timeSeries15.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset16);
        org.jfree.data.time.TimeSeries timeSeries20 = null;
        java.util.TimeZone timeZone21 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeSeries20, timeZone21);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection22);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection22, true);
        timeSeries15.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection22);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        java.util.Date date28 = month27.getStart();
        long long29 = month27.getSerialIndex();
        org.jfree.data.time.Year year30 = month27.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 0.05d, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 12);
        timeSeriesDataItem35.setSelected(false);
        java.lang.Number number38 = timeSeriesDataItem35.getValue();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0d + "'", number12.equals(100.0d));
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 24234L + "'", long29 == 24234L);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + (-5.7600001E7d) + "'", number38.equals((-5.7600001E7d)));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        float float4 = polarPlot3.getBackgroundImageAlpha();
        java.awt.Image image5 = polarPlot3.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
        org.junit.Assert.assertNull(image5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str3 = projectInfo2.toString();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        projectInfo2.setLicenceName("PlotEntity: tooltip = null");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JFreeChart version 1.2.0-pre.\nitem.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:WMAP_Plot\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Greg Darke (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Martin Hoeller (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Peter Kolb (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Eric Penfold (-).Tomer Peretz (-).Diego Pierangeli (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Darshan Shah (-).Mofeed Shahin (-).Michael Siemer (-).Pady Srinivasan (-).Greg Steckman (-).Gerald Struck (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Jess Thrysoee (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Ulrich Voigt (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTextBlockAnchor.BOTTOM_CENTER" + "'", str1.equals("JFreeChart version 1.2.0-pre.\nitem.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:WMAP_Plot\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Greg Darke (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Martin Hoeller (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Peter Kolb (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Eric Penfold (-).Tomer Peretz (-).Diego Pierangeli (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Darshan Shah (-).Mofeed Shahin (-).Michael Siemer (-).Pady Srinivasan (-).Greg Steckman (-).Gerald Struck (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Jess Thrysoee (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Ulrich Voigt (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTextBlockAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JFreeChart version 1.2.0-pre.\nitem.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:WMAP_Plot\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Greg Darke (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Martin Hoeller (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Peter Kolb (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Eric Penfold (-).Tomer Peretz (-).Diego Pierangeli (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Darshan Shah (-).Mofeed Shahin (-).Michael Siemer (-).Pady Srinivasan (-).Greg Steckman (-).Gerald Struck (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Jess Thrysoee (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Ulrich Voigt (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTextBlockAnchor.BOTTOM_CENTER" + "'", str3.equals("JFreeChart version 1.2.0-pre.\nitem.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:WMAP_Plot\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Greg Darke (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Martin Hoeller (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Peter Kolb (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Eric Penfold (-).Tomer Peretz (-).Diego Pierangeli (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Darshan Shah (-).Mofeed Shahin (-).Michael Siemer (-).Pady Srinivasan (-).Greg Steckman (-).Gerald Struck (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Jess Thrysoee (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Ulrich Voigt (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTextBlockAnchor.BOTTOM_CENTER"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth((double) 10);
        boolean boolean3 = ringPlot0.getAutoPopulateSectionOutlineStroke();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getStart();
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        java.awt.Paint paint8 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) date5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("JFreeChart");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo5);
        org.jfree.chart.entity.EntityCollection entityCollection7 = state6.getEntityCollection();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState8 = state6.getSelectionState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo9);
        org.jfree.chart.entity.EntityCollection entityCollection11 = state10.getEntityCollection();
        java.awt.geom.Line2D line2D12 = state10.workingLine;
        state6.workingLine = line2D12;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryAxis14.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource17 = null;
        chartRenderingInfo16.setRenderingSource(renderingSource17);
        java.awt.geom.Rectangle2D rectangle2D19 = chartRenderingInfo16.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets15.createInsetRectangle(rectangle2D19, false, false);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D19);
        boolean boolean24 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D12, rectangle2D19);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.Object obj26 = null;
        boolean boolean27 = rectangleEdge25.equals(obj26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            org.jfree.chart.axis.AxisState axisState29 = dateAxis1.draw(graphics2D2, 1.0E-8d, rectangle2D4, rectangle2D19, rectangleEdge25, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(entityCollection7);
        org.junit.Assert.assertNull(xYDatasetSelectionState8);
        org.junit.Assert.assertNull(entityCollection11);
        org.junit.Assert.assertNotNull(line2D12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer3D0.getSeriesItemLabelGenerator(15);
        double double3 = barRenderer3D0.getItemMargin();
        boolean boolean4 = barRenderer3D0.isDrawBarOutline();
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        int int1 = xYLineAndShapeRenderer0.getPassCount();
        boolean boolean5 = xYLineAndShapeRenderer0.getItemCreateEntity(4, (int) (byte) 1, true);
        java.awt.Paint paint7 = xYLineAndShapeRenderer0.getSeriesItemLabelPaint(4);
        org.jfree.chart.LegendItem legendItem10 = xYLineAndShapeRenderer0.getLegendItem(5, (int) '#');
        xYLineAndShapeRenderer0.setDrawSeriesLineAsPath(true);
        java.lang.String[] strArray14 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis15 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray14);
        java.lang.Object obj16 = symbolAxis15.clone();
        symbolAxis15.setRangeWithMargins(0.05d, (double) 1560495599999L);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryAxis21.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource24 = null;
        chartRenderingInfo23.setRenderingSource(renderingSource24);
        java.awt.geom.Rectangle2D rectangle2D26 = chartRenderingInfo23.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets22.createInsetRectangle(rectangle2D26, false, false);
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D26);
        org.jfree.chart.axis.AxisState axisState31 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        axisState31.moveCursor((double) 0, rectangleEdge33);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState31.moveCursor((double) 100L, rectangleEdge36);
        double double38 = symbolAxis15.java2DToValue((double) 1577894400001L, rectangle2D26, rectangleEdge36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = null;
        java.awt.geom.Point2D point2D40 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor39);
        xYLineAndShapeRenderer0.setBaseShape((java.awt.Shape) rectangle2D26, true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(legendItem10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.POSITIVE_INFINITY + "'", double38 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D40);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, true);
        org.jfree.data.Range range11 = xYBarRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot0, (org.jfree.data.general.Dataset) timeSeriesCollection7);
        java.awt.Stroke stroke13 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot0.getDrawingSupplier();
        java.awt.Stroke stroke16 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = categoryPlot0.getRenderer(0);
        int int19 = categoryPlot0.getCrosshairDatasetIndex();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryItemRenderer18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        polarPlot3.datasetChanged(datasetChangeEvent5);
        java.awt.Font font7 = polarPlot3.getNoDataMessageFont();
        java.awt.Stroke stroke8 = polarPlot3.getRadiusGridlineStroke();
        java.awt.Paint paint9 = polarPlot3.getAngleGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 0);
        boolean boolean2 = xYStepAreaRenderer1.getShapesVisible();
        xYStepAreaRenderer1.setRangeBase(0.0d);
        xYStepAreaRenderer1.setPlotArea(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        java.awt.Font font3 = piePlot1.getLabelFont();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot1.setLabelLinkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getSimpleLabelOffset();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        java.lang.Number[][] numberArray5 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "ClassContext", numberArray5);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset6);
        multiplePiePlot1.setDataset(categoryDataset6);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset6, (-1.0d));
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset6, 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(pieDataset12);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1, timeZone2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone2);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(tickUnitSource5);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        float[] floatArray7 = new float[] { 'a', 24234L, (-57600001L), 0L };
        float[] floatArray8 = java.awt.Color.RGBtoHSB((int) (short) 10, 0, 5, floatArray7);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 5);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType3 = dateTickUnit2.getUnitType();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = null;
        java.util.TimeZone timeZone7 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeSeries6, timeZone7);
        java.util.Date date9 = dateTickUnit2.addToDate(date5, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone10;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date5, timeZone10);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.panRangeAxes((double) 3, plotRenderingInfo35, point2D36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener39 = null;
        jFreeChart38.addProgressListener(chartProgressListener39);
        java.awt.RenderingHints renderingHints41 = jFreeChart38.getRenderingHints();
        java.awt.RenderingHints renderingHints42 = jFreeChart38.getRenderingHints();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline43 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment45 = segmentedTimeline43.getSegment((long) (short) 100);
        long long46 = segment45.getSegmentCount();
        segment45.dec();
        boolean boolean48 = jFreeChart38.equals((java.lang.Object) segment45);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(renderingHints41);
        org.junit.Assert.assertNotNull(renderingHints42);
        org.junit.Assert.assertNotNull(segmentedTimeline43);
        org.junit.Assert.assertNotNull(segment45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1L + "'", long46 == 1L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Paint paint2 = xYLineAndShapeRenderer0.getSeriesItemLabelPaint(0);
        xYLineAndShapeRenderer0.setUseFillPaint(true);
        java.awt.Paint paint5 = xYLineAndShapeRenderer0.getBaseItemLabelPaint();
        xYLineAndShapeRenderer0.setBaseShapesFilled(false);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.xy.XYDataItem xYDataItem3 = new org.jfree.data.xy.XYDataItem((double) (short) 100, (double) (-1));
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, (java.lang.Comparable) (short) 100, (double) 2.0f, 1);
        defaultPieDataset0.setValue((java.lang.Comparable) "RectangleAnchor.BOTTOM", 2.0d);
        java.lang.Object obj10 = null;
        boolean boolean11 = defaultPieDataset0.equals(obj10);
        java.lang.Comparable comparable13 = defaultPieDataset0.getKey(0);
        defaultPieDataset0.clear();
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + "RectangleAnchor.BOTTOM" + "'", comparable13.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8);
        double double10 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace14, true);
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot0.removeDomainMarker((int) (byte) 0, marker18, layer19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer24 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint25 = xYBarRenderer24.getBaseOutlinePaint();
        java.awt.Shape shape31 = null;
        java.awt.Paint paint33 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color35 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape38 = null;
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color42 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape31, false, paint33, false, (java.awt.Paint) color35, stroke36, true, shape38, stroke39, (java.awt.Paint) color42);
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker(0.0d, paint25, stroke39);
        double double45 = valueMarker44.getValue();
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean48 = categoryPlot21.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker44, layer46, false);
        org.jfree.chart.LegendItemCollection legendItemCollection49 = categoryPlot21.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = categoryAxis53.getTickLabelInsets();
        categoryAxis53.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        double double58 = categoryAxis53.getUpperMargin();
        java.awt.Paint paint59 = categoryAxis53.getLabelPaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker60 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d, paint59);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType61 = intervalMarker60.getLabelOffsetType();
        org.jfree.chart.util.Layer layer62 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean64 = categoryPlot21.removeDomainMarker((-460), (org.jfree.chart.plot.Marker) intervalMarker60, layer62, true);
        java.util.Collection collection65 = categoryPlot0.getDomainMarkers(layer62);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(legendItemCollection49);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.05d + "'", double58 == 0.05d);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(lengthAdjustmentType61);
        org.junit.Assert.assertNotNull(layer62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNull(collection65);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getStart();
        java.util.Date date6 = month4.getEnd();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-57600001L));
        org.jfree.data.xy.XYDataItem xYDataItem11 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number12 = xYDataItem11.getX();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem11, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset16.removeSeries((java.lang.Comparable) 'a');
        timeSeries15.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset16);
        org.jfree.data.time.TimeSeries timeSeries20 = null;
        java.util.TimeZone timeZone21 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeSeries20, timeZone21);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection22);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection22, true);
        timeSeries15.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection22);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        java.util.Date date28 = month27.getStart();
        long long29 = month27.getSerialIndex();
        org.jfree.data.time.Year year30 = month27.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 0.05d, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 12);
        timeSeriesDataItem35.setSelected(false);
        timeSeriesDataItem35.setSelected(false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0d + "'", number12.equals(100.0d));
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 24234L + "'", long29 == 24234L);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(timeSeriesDataItem35);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape14 = null;
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color25 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape14, false, paint16, false, (java.awt.Paint) color18, stroke19, true, shape21, stroke22, (java.awt.Paint) color25);
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem26.setLabelPaint(paint27);
        xYBarRenderer0.setBaseLegendTextPaint(paint27);
        java.awt.Stroke stroke31 = xYBarRenderer0.lookupSeriesOutlineStroke((int) (byte) 100);
        xYBarRenderer0.setShadowXOffset((double) 2);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle35 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = categoryPlot36.getRangeMarkers((int) '4', layer38);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer40 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries41 = null;
        java.util.TimeZone timeZone42 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection43 = new org.jfree.data.time.TimeSeriesCollection(timeSeries41, timeZone42);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection43);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection43, true);
        org.jfree.data.Range range47 = xYBarRenderer40.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection43);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent48 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot36, (org.jfree.data.general.Dataset) timeSeriesCollection43);
        java.awt.Stroke stroke49 = categoryPlot36.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation50 = categoryPlot36.getRangeAxisLocation();
        boolean boolean51 = pieLabelLinkStyle35.equals((java.lang.Object) categoryPlot36);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer53 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint54 = xYBarRenderer53.getBaseOutlinePaint();
        java.awt.Shape shape60 = null;
        java.awt.Paint paint62 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color64 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke65 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape67 = null;
        java.awt.Stroke stroke68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color71 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem72 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape60, false, paint62, false, (java.awt.Paint) color64, stroke65, true, shape67, stroke68, (java.awt.Paint) color71);
        org.jfree.chart.plot.ValueMarker valueMarker73 = new org.jfree.chart.plot.ValueMarker(0.0d, paint54, stroke68);
        float float74 = valueMarker73.getAlpha();
        java.awt.Stroke stroke75 = valueMarker73.getStroke();
        categoryPlot36.setRangeGridlineStroke(stroke75);
        try {
            xYBarRenderer0.setSeriesOutlineStroke((-460), stroke75);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle35);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertTrue("'" + float74 + "' != '" + 1.0f + "'", float74 == 1.0f);
        org.junit.Assert.assertNotNull(stroke75);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        java.lang.String[] strArray5 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis6 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray5);
        java.lang.Object obj7 = symbolAxis6.clone();
        org.jfree.data.RangeType rangeType8 = org.jfree.data.RangeType.POSITIVE;
        java.lang.Object obj9 = null;
        boolean boolean10 = rangeType8.equals(obj9);
        symbolAxis6.setRangeType(rangeType8);
        org.jfree.data.Range range12 = combinedDomainXYPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) symbolAxis6);
        symbolAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = symbolAxis6.getMarkerBand();
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rangeType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(markerAxisBand15);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("SerialDate.weekInMonthToString(): invalid code.");
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape3);
        java.awt.Shape shape5 = chartEntity4.getArea();
        logAxis1.setLeftArrow(shape5);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        java.lang.Object obj1 = null;
        boolean boolean2 = textAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(2);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = state1.getEntityCollection();
        java.awt.geom.Line2D line2D3 = state1.workingLine;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            boolean boolean5 = org.jfree.chart.util.LineUtilities.clipLine(line2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertNotNull(line2D3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Paint paint2 = xYLineAndShapeRenderer0.getSeriesItemLabelPaint(0);
        xYLineAndShapeRenderer0.setUseFillPaint(true);
        xYLineAndShapeRenderer0.setSeriesShapesVisible(0, false);
        java.awt.Stroke stroke9 = xYLineAndShapeRenderer0.lookupSeriesOutlineStroke(0);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("JFreeChart");
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRange((org.jfree.data.Range) dateRange2);
        org.junit.Assert.assertNotNull(dateRange2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.setStartTime((long) 12);
        long long5 = segmentedTimeline0.getExceptionSegmentCount(0L, (long) 15);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        java.lang.Object obj1 = xYSeriesCollection0.clone();
        xYSeriesCollection0.removeAllSeries();
        xYSeriesCollection0.setAutoWidth(true);
        boolean boolean5 = xYSeriesCollection0.isAutoWidth();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1, timeZone2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        timeSeriesCollection3.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection3);
        org.jfree.data.general.DatasetGroup datasetGroup11 = timeSeriesCollection3.getGroup();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset16, valueAxis17, polarItemRenderer18);
        polarPlot19.setNoDataMessage("ThreadContext");
        java.awt.Paint paint22 = polarPlot19.getRadiusGridlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) 9999, (double) 0, (double) '#', paint22);
        boolean boolean24 = datasetGroup11.equals((java.lang.Object) blockBorder23);
        blockContainer0.setFrame((org.jfree.chart.block.BlockFrame) blockBorder23);
        org.jfree.chart.block.Arrangement arrangement26 = blockContainer0.getArrangement();
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer(arrangement26);
        java.lang.Object obj28 = blockContainer27.clone();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(arrangement26);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.jfree.chart.axis.Axis axis0 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer1.setShadowYOffset((double) 0L);
        xYBarRenderer1.setShadowXOffset(100.0d);
        boolean boolean8 = xYBarRenderer1.getBaseItemLabelsVisible();
        java.awt.Shape shape9 = xYBarRenderer1.getBaseShape();
        try {
            org.jfree.chart.entity.AxisLabelEntity axisLabelEntity12 = new org.jfree.chart.entity.AxisLabelEntity(axis0, shape9, "TextBlockAnchor.BOTTOM_CENTER", "{0}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.xy.XYDataItem xYDataItem3 = new org.jfree.data.xy.XYDataItem((double) (short) 100, (double) (-1));
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, (java.lang.Comparable) (short) 100, (double) 2.0f, 1);
        defaultPieDataset0.setValue((java.lang.Comparable) "RectangleAnchor.BOTTOM", 2.0d);
        java.lang.Object obj10 = null;
        boolean boolean11 = defaultPieDataset0.equals(obj10);
        java.lang.Comparable comparable13 = defaultPieDataset0.getKey(0);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.util.Date date16 = month15.getStart();
        java.util.Date date17 = month15.getEnd();
        try {
            defaultPieDataset0.insertValue(100, (java.lang.Comparable) date17, (java.lang.Number) (-4.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + "RectangleAnchor.BOTTOM" + "'", comparable13.equals("RectangleAnchor.BOTTOM"));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers(layer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset(0);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 0);
        boolean boolean2 = xYStepAreaRenderer1.getShapesVisible();
        boolean boolean5 = xYStepAreaRenderer1.getItemVisible(500, 3);
        xYStepAreaRenderer1.setRangeBase((double) 2);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setTickMarksVisible(false);
        java.awt.Font font12 = categoryAxis9.getTickLabelFont();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint15 = xYBarRenderer14.getBaseOutlinePaint();
        java.awt.Shape shape21 = null;
        java.awt.Paint paint23 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape28 = null;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color32 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape21, false, paint23, false, (java.awt.Paint) color25, stroke26, true, shape28, stroke29, (java.awt.Paint) color32);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(0.0d, paint15, stroke29);
        double double35 = valueMarker34.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType36 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo(entityCollection37);
        boolean boolean39 = chartChangeEventType36.equals((java.lang.Object) entityCollection37);
        java.lang.String str40 = chartChangeEventType36.toString();
        boolean boolean41 = valueMarker34.equals((java.lang.Object) chartChangeEventType36);
        java.awt.Shape shape47 = null;
        java.awt.Paint paint49 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color51 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape54 = null;
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color58 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem59 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape47, false, paint49, false, (java.awt.Paint) color51, stroke52, true, shape54, stroke55, (java.awt.Paint) color58);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer60 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint61 = xYBarRenderer60.getBaseOutlinePaint();
        legendItem59.setLinePaint(paint61);
        boolean boolean63 = valueMarker34.equals((java.lang.Object) paint61);
        org.jfree.chart.text.TextBlock textBlock64 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", font12, paint61);
        xYStepAreaRenderer1.setBaseLegendTextFont(font12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str40.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(textBlock64);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection2);
        java.lang.String str10 = rendererChangeEvent9.toString();
        java.lang.Object obj11 = rendererChangeEvent9.getSource();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("JFreeChart");
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        java.awt.Shape shape3 = dateAxis1.getLeftArrow();
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        long long6 = timeSeries5.getMaximumItemAge();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getStart();
        int int9 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) month7);
        boolean boolean10 = strokeList0.equals((java.lang.Object) int9);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Paint paint2 = ringPlot0.getShadowPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot3.getRangeMarkers((int) '4', layer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot3.setDomainAxis((int) (short) 0, categoryAxis8, true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot3.setFixedRangeAxisSpace(axisSpace11);
        boolean boolean13 = categoryPlot3.isOutlineVisible();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot3.getRangeAxisForDataset(7);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset16, valueAxis17, polarItemRenderer18);
        boolean boolean20 = polarPlot19.isAngleLabelsVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) polarPlot19);
        categoryPlot3.notifyListeners(plotChangeEvent21);
        ringPlot0.notifyListeners(plotChangeEvent21);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource3 = null;
        chartRenderingInfo2.setRenderingSource(renderingSource3);
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo2.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D6 = chartRenderingInfo2.getChartArea();
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 100.0f, 6.0d, rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(point2D7);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getNumberFormat();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean3 = standardPieSectionLabelGenerator0.equals((java.lang.Object) date2);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset4 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) 1577894400005L, range8);
        boolean boolean10 = defaultPieDataset4.equals((java.lang.Object) rectangleConstraint9);
        try {
            java.lang.String str12 = standardPieSectionLabelGenerator0.generateSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset4, (java.lang.Comparable) 4.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 4.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean2 = dateRange0.contains((double) 1577894400005L);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer3D0.getSeriesItemLabelGenerator(15);
        java.awt.Paint paint3 = barRenderer3D0.getWallPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer3D0.getBaseToolTipGenerator();
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.clone(shape0);
        org.junit.Assert.assertNull(shape1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape14 = null;
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color25 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape14, false, paint16, false, (java.awt.Paint) color18, stroke19, true, shape21, stroke22, (java.awt.Paint) color25);
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem26.setLabelPaint(paint27);
        xYBarRenderer0.setBaseLegendTextPaint(paint27);
        java.awt.Stroke stroke31 = xYBarRenderer0.lookupSeriesOutlineStroke((int) (byte) 100);
        xYBarRenderer0.setSeriesItemLabelsVisible(10, (java.lang.Boolean) false);
        java.lang.Boolean boolean36 = xYBarRenderer0.getSeriesVisibleInLegend((int) '#');
        java.awt.Paint paint37 = xYBarRenderer0.getBasePaint();
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer41 = null;
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot(xYDataset39, valueAxis40, polarItemRenderer41);
        java.awt.Paint paint43 = polarPlot42.getOutlinePaint();
        xYBarRenderer0.setSeriesFillPaint(10, paint43);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(boolean36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        boolean boolean12 = combinedDomainXYPlot1.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint15 = xYBarRenderer14.getBaseOutlinePaint();
        java.awt.Shape shape21 = null;
        java.awt.Paint paint23 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape28 = null;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color32 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape21, false, paint23, false, (java.awt.Paint) color25, stroke26, true, shape28, stroke29, (java.awt.Paint) color32);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(0.0d, paint15, stroke29);
        double double35 = valueMarker34.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType36 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo(entityCollection37);
        boolean boolean39 = chartChangeEventType36.equals((java.lang.Object) entityCollection37);
        java.lang.String str40 = chartChangeEventType36.toString();
        boolean boolean41 = valueMarker34.equals((java.lang.Object) chartChangeEventType36);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer44 = null;
        org.jfree.chart.plot.PolarPlot polarPlot45 = new org.jfree.chart.plot.PolarPlot(xYDataset42, valueAxis43, polarItemRenderer44);
        polarPlot45.setNoDataMessage("ThreadContext");
        java.awt.Paint paint48 = polarPlot45.getRadiusGridlinePaint();
        valueMarker34.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot45);
        boolean boolean50 = combinedDomainXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker34);
        java.lang.Object obj51 = combinedDomainXYPlot1.clone();
        java.lang.String[] strArray54 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis55 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray54);
        combinedDomainXYPlot1.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) symbolAxis55, true);
        try {
            java.awt.Paint paint59 = combinedDomainXYPlot1.getQuadrantPaint(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (11) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str40.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(strArray54);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape14 = null;
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color25 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape14, false, paint16, false, (java.awt.Paint) color18, stroke19, true, shape21, stroke22, (java.awt.Paint) color25);
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem26.setLabelPaint(paint27);
        xYBarRenderer0.setBaseLegendTextPaint(paint27);
        java.awt.Stroke stroke31 = xYBarRenderer0.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer32 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint33 = xYBarRenderer32.getBaseItemLabelPaint();
        boolean boolean37 = xYBarRenderer32.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator39 = null;
        xYBarRenderer32.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator39);
        java.awt.Shape shape41 = xYBarRenderer32.getBaseLegendShape();
        java.awt.Shape shape42 = xYBarRenderer32.getLegendBar();
        xYBarRenderer0.setBaseLegendShape(shape42);
        java.lang.Boolean boolean45 = xYBarRenderer0.getSeriesVisible((int) (short) 10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(shape41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(boolean45);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        java.awt.Shape shape6 = xYBarRenderer0.getBaseLegendShape();
        java.awt.Paint paint8 = xYBarRenderer0.getLegendTextPaint(6);
        org.jfree.chart.plot.XYPlot xYPlot9 = xYBarRenderer0.getPlot();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(xYPlot9);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 8);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator2);
        java.awt.Paint paint4 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot5.getRangeMarkers((int) '4', layer7);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries10 = null;
        java.util.TimeZone timeZone11 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeSeries10, timeZone11);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection12, true);
        org.jfree.data.Range range16 = xYBarRenderer9.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot5, (org.jfree.data.general.Dataset) timeSeriesCollection12);
        piePlot1.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint23 = xYBarRenderer22.getBaseOutlinePaint();
        java.awt.Shape shape29 = null;
        java.awt.Paint paint31 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color33 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape36 = null;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color40 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape29, false, paint31, false, (java.awt.Paint) color33, stroke34, true, shape36, stroke37, (java.awt.Paint) color40);
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker(0.0d, paint23, stroke37);
        double double43 = valueMarker42.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType44 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection45 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = new org.jfree.chart.ChartRenderingInfo(entityCollection45);
        boolean boolean47 = chartChangeEventType44.equals((java.lang.Object) entityCollection45);
        java.lang.String str48 = chartChangeEventType44.toString();
        boolean boolean49 = valueMarker42.equals((java.lang.Object) chartChangeEventType44);
        org.jfree.chart.util.Layer layer50 = null;
        boolean boolean52 = xYPlot19.removeRangeMarker(8, (org.jfree.chart.plot.Marker) valueMarker42, layer50, true);
        java.awt.Paint paint53 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot19.setDomainTickBandPaint(paint53);
        piePlot1.setBaseSectionPaint(paint53);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str48.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.Object obj1 = size2D0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedHeight();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        boolean boolean10 = intervalXYDelegate9.isAutoWidth();
        try {
            double double13 = intervalXYDelegate9.getStartXValue(9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color16 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape5, false, paint7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color16);
        java.awt.Paint paint18 = legendItem17.getOutlinePaint();
        boolean boolean19 = legendItem17.isShapeFilled();
        boolean boolean20 = legendItem17.isLineVisible();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray1);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        symbolAxis2.setStandardTickUnits(tickUnitSource3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = symbolAxis2.getTickLabelInsets();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }
}

