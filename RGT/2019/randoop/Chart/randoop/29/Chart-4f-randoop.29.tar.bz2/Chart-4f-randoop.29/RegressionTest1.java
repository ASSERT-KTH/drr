import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection2);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint14 = xYBarRenderer13.getBaseOutlinePaint();
        java.awt.Shape shape20 = null;
        java.awt.Paint paint22 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color24 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape27 = null;
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color31 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape20, false, paint22, false, (java.awt.Paint) color24, stroke25, true, shape27, stroke28, (java.awt.Paint) color31);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker(0.0d, paint14, stroke28);
        double double34 = valueMarker33.getValue();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean37 = categoryPlot10.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker33, layer35, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot10.getDomainAxisEdge();
        double double39 = categoryPlot10.getRangeCrosshairValue();
        double double40 = categoryPlot10.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        categoryPlot10.setRangeAxis(1, valueAxis42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        categoryPlot10.panRangeAxes((double) 3, plotRenderingInfo45, point2D46);
        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot10);
        java.lang.Object obj49 = jFreeChart48.getTextAntiAlias();
        rendererChangeEvent9.setChart(jFreeChart48);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNull(obj49);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1, timeZone2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        timeSeriesCollection3.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = null;
        polarPlot8.setDrawingSupplier(drawingSupplier10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        polarPlot8.addChangeListener(plotChangeListener12);
        java.lang.String str14 = polarPlot8.getNoDataMessage();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) polarPlot8);
        try {
            categoryPlot0.zoom((double) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 432000000L, (double) (-460));
        xYDataItem2.setY((double) (-1L));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("TextBlockAnchor.TOP_LEFT");
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseOutlinePaint();
        java.awt.Paint paint2 = xYBarRenderer0.getBasePaint();
        java.awt.Font font4 = xYBarRenderer0.getSeriesItemLabelFont((int) (byte) 0);
        java.awt.Paint paint5 = xYBarRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator6 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(xYItemLabelGenerator6);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = null;
        axisState0.moveCursor((double) 0, rectangleEdge2);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState0.moveCursor((double) 100L, rectangleEdge5);
        java.lang.String str7 = rectangleEdge5.toString();
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleEdge.BOTTOM" + "'", str7.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = xYBarRenderer1.getBaseOutlinePaint();
        java.awt.Shape shape8 = null;
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color19 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape8, false, paint10, false, (java.awt.Paint) color12, stroke13, true, shape15, stroke16, (java.awt.Paint) color19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, paint2, stroke16);
        double double22 = valueMarker21.getValue();
        valueMarker21.setLabel("");
        org.jfree.chart.text.TextAnchor textAnchor25 = valueMarker21.getLabelTextAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = null;
        try {
            valueMarker21.setLabelOffsetType(lengthAdjustmentType26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor25);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Font font4 = xYBarRenderer0.getItemLabelFont((int) '4', 4, true);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("October");
        legendItem1.setSeriesIndex(6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        java.awt.Paint paint5 = categoryAxis0.getLabelPaint();
        float float6 = categoryAxis0.getMinorTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection4.getSeries((int) (byte) 0);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segmentedTimeline7.getSegment((long) (short) 100);
        boolean boolean11 = segmentedTimeline7.containsDomainValue((long) (short) 0);
        long long13 = segmentedTimeline7.toTimelineValue((long) 1);
        boolean boolean14 = timeSeries6.equals((java.lang.Object) 1);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(segmentedTimeline7);
        org.junit.Assert.assertNotNull(segment9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577894400001L + "'", long13 == 1577894400001L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        boolean boolean10 = intervalXYDelegate9.isAutoWidth();
        java.lang.Object obj11 = intervalXYDelegate9.clone();
        double double12 = intervalXYDelegate9.getFixedIntervalWidth();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        boolean boolean12 = combinedDomainXYPlot1.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint15 = xYBarRenderer14.getBaseOutlinePaint();
        java.awt.Shape shape21 = null;
        java.awt.Paint paint23 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape28 = null;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color32 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape21, false, paint23, false, (java.awt.Paint) color25, stroke26, true, shape28, stroke29, (java.awt.Paint) color32);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(0.0d, paint15, stroke29);
        double double35 = valueMarker34.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType36 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo(entityCollection37);
        boolean boolean39 = chartChangeEventType36.equals((java.lang.Object) entityCollection37);
        java.lang.String str40 = chartChangeEventType36.toString();
        boolean boolean41 = valueMarker34.equals((java.lang.Object) chartChangeEventType36);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer44 = null;
        org.jfree.chart.plot.PolarPlot polarPlot45 = new org.jfree.chart.plot.PolarPlot(xYDataset42, valueAxis43, polarItemRenderer44);
        polarPlot45.setNoDataMessage("ThreadContext");
        java.awt.Paint paint48 = polarPlot45.getRadiusGridlinePaint();
        valueMarker34.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot45);
        boolean boolean50 = combinedDomainXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker34);
        java.awt.Paint paint51 = valueMarker34.getOutlinePaint();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str40.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape14 = null;
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color25 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape14, false, paint16, false, (java.awt.Paint) color18, stroke19, true, shape21, stroke22, (java.awt.Paint) color25);
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem26.setLabelPaint(paint27);
        xYBarRenderer0.setBaseLegendTextPaint(paint27);
        java.awt.Stroke stroke31 = xYBarRenderer0.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator32 = xYBarRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(xYURLGenerator32);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray33 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer32 };
        categoryPlot0.setRenderers(categoryItemRendererArray33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace35);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(categoryItemRendererArray33);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection2);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        double double12 = timeSeriesCollection2.getDomainLowerBound(false);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertEquals((double) number10, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (-1), (double) 28);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray1);
        java.lang.Object obj3 = symbolAxis2.clone();
        org.jfree.data.RangeType rangeType4 = org.jfree.data.RangeType.POSITIVE;
        java.lang.Object obj5 = null;
        boolean boolean6 = rangeType4.equals(obj5);
        symbolAxis2.setRangeType(rangeType4);
        symbolAxis2.setGridBandsVisible(true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint11 = xYBarRenderer10.getBaseItemLabelPaint();
        boolean boolean15 = xYBarRenderer10.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator17 = null;
        xYBarRenderer10.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator17);
        java.awt.Shape shape24 = null;
        java.awt.Paint paint26 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color28 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape31 = null;
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color35 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape24, false, paint26, false, (java.awt.Paint) color28, stroke29, true, shape31, stroke32, (java.awt.Paint) color35);
        java.awt.Paint paint37 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem36.setLabelPaint(paint37);
        xYBarRenderer10.setBaseLegendTextPaint(paint37);
        java.awt.Stroke stroke41 = xYBarRenderer10.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer42 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint43 = xYBarRenderer42.getBaseItemLabelPaint();
        boolean boolean47 = xYBarRenderer42.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator49 = null;
        xYBarRenderer42.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator49);
        java.awt.Shape shape51 = xYBarRenderer42.getBaseLegendShape();
        java.awt.Shape shape52 = xYBarRenderer42.getLegendBar();
        xYBarRenderer10.setBaseLegendShape(shape52);
        symbolAxis2.setUpArrow(shape52);
        org.jfree.data.RangeType rangeType55 = org.jfree.data.RangeType.NEGATIVE;
        symbolAxis2.setRangeType(rangeType55);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNull(shape51);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(rangeType55);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        long long3 = segment2.getSegmentCount();
        boolean boolean4 = segment2.inExceptionSegments();
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) segment2, false);
        org.jfree.data.time.TimeSeries timeSeries7 = null;
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeSeries7, timeZone8);
        java.lang.Comparable comparable10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeriesCollection9.getSeries(comparable10);
        xYSeries6.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection9);
        try {
            int int14 = timeSeriesCollection9.getItemCount((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(timeSeries11);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer0.setShadowYOffset((double) 0L);
        xYBarRenderer0.setDefaultEntityRadius((int) (short) 1);
        xYBarRenderer0.clearSeriesStrokes(false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        java.awt.Shape shape6 = xYBarRenderer0.getBaseLegendShape();
        java.awt.Paint paint8 = xYBarRenderer0.getLegendTextPaint(6);
        boolean boolean9 = xYBarRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint10 = null;
        xYBarRenderer0.setBaseLegendTextPaint(paint10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("100");
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 11, (float) (-460));
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        java.awt.Font font5 = polarPlot4.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.DATASET_UPDATED", font5);
        java.lang.String str7 = labelBlock6.getToolTipText();
        labelBlock6.setURLText("");
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.Year year3 = month0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long2 = segmentedTimeline0.getTimeFromLong(0L);
        int int3 = segmentedTimeline0.getSegmentsIncluded();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long6 = segmentedTimeline4.getTimeFromLong(0L);
        int int7 = segmentedTimeline4.getSegmentsIncluded();
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        segmentedTimeline4.addException(date8);
        java.util.Date date10 = null;
        try {
            boolean boolean11 = segmentedTimeline0.containsDomainRange(date8, date10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 28 + "'", int7 == 28);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, true);
        org.jfree.data.Range range11 = xYBarRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot0, (org.jfree.data.general.Dataset) timeSeriesCollection7);
        java.awt.Stroke stroke13 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint20 = xYBarRenderer19.getBaseOutlinePaint();
        java.awt.Shape shape26 = null;
        java.awt.Paint paint28 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color30 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape33 = null;
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color37 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape26, false, paint28, false, (java.awt.Paint) color30, stroke31, true, shape33, stroke34, (java.awt.Paint) color37);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(0.0d, paint20, stroke34);
        double double40 = valueMarker39.getValue();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean43 = categoryPlot16.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker39, layer41, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot16.getDomainAxisEdge();
        double double45 = categoryPlot16.getRangeCrosshairValue();
        double double46 = categoryPlot16.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        categoryPlot16.setRangeAxis(1, valueAxis48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        java.awt.geom.Point2D point2D52 = null;
        categoryPlot16.panRangeAxes((double) 3, plotRenderingInfo51, point2D52);
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener55 = null;
        jFreeChart54.addProgressListener(chartProgressListener55);
        java.awt.RenderingHints renderingHints57 = jFreeChart54.getRenderingHints();
        jFreeChart54.setBackgroundImageAlpha((float) '4');
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart54);
        categoryPlot0.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(renderingHints57);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.util.Date date3 = dateRange2.getUpperDate();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        boolean boolean10 = intervalXYDelegate9.isAutoWidth();
        try {
            java.lang.Number number13 = intervalXYDelegate9.getEndX(500, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 5);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType3 = dateTickUnit2.getUnitType();
        int int4 = dateTickUnit2.getCalendarField();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        java.lang.Object obj8 = chartEntity7.clone();
        java.awt.Shape shape9 = chartEntity7.getArea();
        java.awt.Shape shape10 = chartEntity7.getArea();
        boolean boolean11 = dateTickUnit2.equals((java.lang.Object) chartEntity7);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 11 + "'", int4 == 11);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset(0.0d);
        double double3 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        long long3 = segment2.getSegmentCount();
        boolean boolean4 = segment2.inExceptionSegments();
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) segment2, false);
        try {
            java.lang.Number number8 = xYSeries6.getX((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape14 = null;
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color25 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape14, false, paint16, false, (java.awt.Paint) color18, stroke19, true, shape21, stroke22, (java.awt.Paint) color25);
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem26.setLabelPaint(paint27);
        xYBarRenderer0.setBaseLegendTextPaint(paint27);
        java.awt.Stroke stroke31 = xYBarRenderer0.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer32 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint33 = xYBarRenderer32.getBaseItemLabelPaint();
        boolean boolean37 = xYBarRenderer32.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator39 = null;
        xYBarRenderer32.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator39);
        java.awt.Shape shape41 = xYBarRenderer32.getBaseLegendShape();
        java.awt.Shape shape42 = xYBarRenderer32.getLegendBar();
        xYBarRenderer0.setBaseLegendShape(shape42);
        boolean boolean44 = xYBarRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(shape41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        combinedDomainXYPlot1.setDomainMinorGridlinesVisible(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.awt.Stroke stroke9 = piePlot8.getLabelLinkStroke();
        java.awt.Font font10 = piePlot8.getLabelFont();
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("PlotOrientation.HORIZONTAL", font10, paint11);
        combinedDomainXYPlot1.setRangeTickBandPaint(paint11);
        java.awt.geom.GeneralPath generalPath14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis15.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource18 = null;
        chartRenderingInfo17.setRenderingSource(renderingSource18);
        java.awt.geom.Rectangle2D rectangle2D20 = chartRenderingInfo17.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets16.createInsetRectangle(rectangle2D20, false, false);
        org.jfree.chart.RenderingSource renderingSource24 = null;
        combinedDomainXYPlot1.select(generalPath14, rectangle2D23, renderingSource24);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D23);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        boolean boolean12 = combinedDomainXYPlot1.isRangeZeroBaselineVisible();
        combinedDomainXYPlot1.setDomainCrosshairValue(10.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            java.lang.Comparable comparable2 = defaultXYDataset0.getSeriesKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Other", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        try {
            barRenderer3D0.addAnnotation(categoryAnnotation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "ClassContext", numberArray2);
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        axisState4.moveCursor((double) 0, rectangleEdge6);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState4.moveCursor((double) 100L, rectangleEdge9);
        org.jfree.chart.axis.AxisState axisState11 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        axisState11.moveCursor((double) 0, rectangleEdge13);
        axisState11.cursorUp((double) 1577894400005L);
        org.jfree.chart.ui.ProjectInfo projectInfo17 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list18 = projectInfo17.getContributors();
        axisState11.setTicks(list18);
        axisState4.setTicks(list18);
        try {
            org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset3, list18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.ui.Contributor cannot be cast to java.lang.Comparable");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(projectInfo17);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        numberFormat2.setGroupingUsed(false);
        int int5 = numberFormat2.getMaximumFractionDigits();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator6 = new org.jfree.chart.labels.StandardPieToolTipGenerator("100", numberFormat1, numberFormat2);
        java.lang.Object obj7 = standardPieToolTipGenerator6.clone();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (byte) 0, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.panRangeAxes((double) 3, plotRenderingInfo35, point2D36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener39 = null;
        jFreeChart38.addProgressListener(chartProgressListener39);
        org.jfree.chart.event.ChartChangeListener chartChangeListener41 = null;
        try {
            jFreeChart38.addChangeListener(chartChangeListener41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) '4', "[100.0, 12.0]", "TextBlockAnchor.BOTTOM_CENTER", false);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeSeries8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getStart();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (short) 0);
        boolean boolean15 = logFormat4.equals((java.lang.Object) month10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 11);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.lang.Boolean boolean13 = xYBarRenderer0.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation14 = null;
        boolean boolean15 = xYBarRenderer0.removeAnnotation(xYAnnotation14);
        java.awt.Paint paint16 = xYBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYBarRenderer0.getNegativeItemLabelPosition(11, (int) (short) 1, true);
        boolean boolean21 = xYBarRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        java.util.Locale locale2 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("October", timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.lang.String str2 = textFragment1.getText();
        java.lang.String str3 = textFragment1.getText();
        java.awt.Graphics2D graphics2D4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textFragment1.calculateDimensions(graphics2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.panRangeAxes((double) 3, plotRenderingInfo35, point2D36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        java.awt.Paint paint39 = jFreeChart38.getBorderPaint();
        java.awt.Image image40 = null;
        jFreeChart38.setBackgroundImage(image40);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot43 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis42);
        combinedDomainXYPlot43.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = combinedDomainXYPlot43.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder47 = combinedDomainXYPlot43.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double50 = rectangleInsets48.calculateRightInset(0.0d);
        double double52 = rectangleInsets48.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot43.setAxisOffset(rectangleInsets48);
        boolean boolean54 = combinedDomainXYPlot43.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer56 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint57 = xYBarRenderer56.getBaseOutlinePaint();
        java.awt.Shape shape63 = null;
        java.awt.Paint paint65 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color67 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape70 = null;
        java.awt.Stroke stroke71 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color74 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem75 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape63, false, paint65, false, (java.awt.Paint) color67, stroke68, true, shape70, stroke71, (java.awt.Paint) color74);
        org.jfree.chart.plot.ValueMarker valueMarker76 = new org.jfree.chart.plot.ValueMarker(0.0d, paint57, stroke71);
        double double77 = valueMarker76.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType78 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection79 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo80 = new org.jfree.chart.ChartRenderingInfo(entityCollection79);
        boolean boolean81 = chartChangeEventType78.equals((java.lang.Object) entityCollection79);
        java.lang.String str82 = chartChangeEventType78.toString();
        boolean boolean83 = valueMarker76.equals((java.lang.Object) chartChangeEventType78);
        org.jfree.data.xy.XYDataset xYDataset84 = null;
        org.jfree.chart.axis.ValueAxis valueAxis85 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer86 = null;
        org.jfree.chart.plot.PolarPlot polarPlot87 = new org.jfree.chart.plot.PolarPlot(xYDataset84, valueAxis85, polarItemRenderer86);
        polarPlot87.setNoDataMessage("ThreadContext");
        java.awt.Paint paint90 = polarPlot87.getRadiusGridlinePaint();
        valueMarker76.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot87);
        boolean boolean92 = combinedDomainXYPlot43.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker76);
        java.lang.Object obj93 = combinedDomainXYPlot43.clone();
        try {
            jFreeChart38.setTextAntiAlias((java.lang.Object) combinedDomainXYPlot43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.plot.CombinedDomainXYPlot@7591dcda incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(datasetRenderingOrder47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 4.0d + "'", double50 == 4.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 4.0d + "'", double52 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType78);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str82.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(paint90);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(obj93);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isAngleLabelsVisible();
        int int5 = polarPlot3.getSeriesCount();
        polarPlot3.removeCornerTextItem("RectangleConstraintType.RANGE");
        java.awt.Paint paint8 = polarPlot3.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        java.util.Currency currency1 = numberFormat0.getCurrency();
        java.math.RoundingMode roundingMode2 = numberFormat0.getRoundingMode();
        java.math.RoundingMode roundingMode3 = numberFormat0.getRoundingMode();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(currency1);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode2.equals(java.math.RoundingMode.HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode3.equals(java.math.RoundingMode.HALF_EVEN));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, true);
        org.jfree.data.general.DatasetGroup datasetGroup6 = timeSeriesCollection2.getGroup();
        timeSeriesCollection2.removeAllSeries();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean9 = timeSeriesCollection2.equals((java.lang.Object) rectangleAnchor8);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(datasetGroup6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        java.awt.Paint paint6 = categoryAxis1.getAxisLinePaint();
        org.jfree.chart.entity.AxisEntity axisEntity8 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis1, "ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.plot.Plot plot9 = categoryAxis1.getPlot();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(plot9);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator2);
        java.awt.Paint paint4 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle5);
        java.awt.Paint paint7 = piePlot1.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        polarPlot7.setDrawingSupplier(drawingSupplier9);
        polarPlot7.setRadiusGridlinesVisible(false);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = categoryPlot1.getRangeMarkers((int) '4', layer3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries6 = null;
        java.util.TimeZone timeZone7 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeSeries6, timeZone7);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8, true);
        org.jfree.data.Range range12 = xYBarRenderer5.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot1, (org.jfree.data.general.Dataset) timeSeriesCollection8);
        java.awt.Stroke stroke14 = categoryPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot1.getRangeAxisLocation();
        boolean boolean16 = pieLabelLinkStyle0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot1.panDomainAxes((double) 28, plotRenderingInfo18, point2D19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot1.getFixedDomainAxisSpace();
        org.jfree.chart.util.SortOrder sortOrder22 = null;
        try {
            categoryPlot1.setRowRenderingOrder(sortOrder22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(axisSpace21);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = xYBarRenderer2.getBaseItemLabelPaint();
        piePlot1.setLabelPaint(paint3);
        piePlot1.setOutlineVisible(true);
        piePlot1.setIgnoreZeroValues(false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1, timeZone2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        timeSeriesCollection3.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection3);
        org.jfree.data.general.DatasetGroup datasetGroup11 = timeSeriesCollection3.getGroup();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset16, valueAxis17, polarItemRenderer18);
        polarPlot19.setNoDataMessage("ThreadContext");
        java.awt.Paint paint22 = polarPlot19.getRadiusGridlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) 9999, (double) 0, (double) '#', paint22);
        boolean boolean24 = datasetGroup11.equals((java.lang.Object) blockBorder23);
        blockContainer0.setFrame((org.jfree.chart.block.BlockFrame) blockBorder23);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryAxis27.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource30 = null;
        chartRenderingInfo29.setRenderingSource(renderingSource30);
        java.awt.geom.Rectangle2D rectangle2D32 = chartRenderingInfo29.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets28.createInsetRectangle(rectangle2D32, false, false);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D32);
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_YELLOW;
        try {
            java.lang.Object obj38 = blockContainer0.draw(graphics2D26, rectangle2D32, (java.lang.Object) color37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ClassContext", "RectangleConstraintType.RANGE");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraintType.RANGE" + "'", str3.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        java.lang.Object obj1 = null;
        boolean boolean2 = itemLabelAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        java.awt.Paint paint5 = categoryAxis0.getAxisLinePaint();
        double double6 = categoryAxis0.getFixedDimension();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.Object obj1 = null;
        boolean boolean2 = datasetRenderingOrder0.equals(obj1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer3.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer3.setShadowYOffset((double) 0L);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint10 = xYBarRenderer9.getBaseItemLabelPaint();
        boolean boolean14 = xYBarRenderer9.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        xYBarRenderer9.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator16);
        java.awt.Shape shape23 = null;
        java.awt.Paint paint25 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color27 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape30 = null;
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color34 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape23, false, paint25, false, (java.awt.Paint) color27, stroke28, true, shape30, stroke31, (java.awt.Paint) color34);
        java.awt.Paint paint36 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem35.setLabelPaint(paint36);
        xYBarRenderer9.setBaseLegendTextPaint(paint36);
        java.awt.Stroke stroke40 = xYBarRenderer9.lookupSeriesOutlineStroke((int) (byte) 100);
        xYBarRenderer9.setSeriesItemLabelsVisible(10, (java.lang.Boolean) false);
        java.lang.Boolean boolean45 = xYBarRenderer9.getSeriesVisibleInLegend((int) '#');
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator47 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer48 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer48.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer48.setShadowYOffset((double) 0L);
        xYBarRenderer48.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color55 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer48.setBaseOutlinePaint((java.awt.Paint) color55);
        boolean boolean57 = standardXYToolTipGenerator47.equals((java.lang.Object) xYBarRenderer48);
        xYBarRenderer9.setSeriesToolTipGenerator(2, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator47, true);
        java.text.DateFormat dateFormat60 = standardXYToolTipGenerator47.getXDateFormat();
        xYBarRenderer3.setSeriesToolTipGenerator(64, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator47);
        boolean boolean62 = datasetRenderingOrder0.equals((java.lang.Object) 64);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(dateFormat60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1, timeZone2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        timeSeriesCollection3.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = null;
        polarPlot8.setDrawingSupplier(drawingSupplier10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        polarPlot8.addChangeListener(plotChangeListener12);
        java.lang.String str14 = polarPlot8.getNoDataMessage();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) polarPlot8);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = polarPlot8.getRenderer();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(polarItemRenderer16);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 5);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType3 = dateTickUnit2.getUnitType();
        int int4 = dateTickUnit2.getCalendarField();
        java.lang.String str6 = dateTickUnit2.valueToString(0.0d);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '4', layer10);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries13 = null;
        java.util.TimeZone timeZone14 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries13, timeZone14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15, true);
        org.jfree.data.Range range19 = xYBarRenderer12.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot8, (org.jfree.data.general.Dataset) timeSeriesCollection15);
        java.awt.Stroke stroke21 = categoryPlot8.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot8.getRangeAxisLocation();
        boolean boolean23 = pieLabelLinkStyle7.equals((java.lang.Object) categoryPlot8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot8.panDomainAxes((double) 28, plotRenderingInfo25, point2D26);
        boolean boolean28 = dateTickUnit2.equals((java.lang.Object) categoryPlot8);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        java.util.Date date30 = month29.getStart();
        java.util.Date date31 = dateTickUnit2.rollDate(date30);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 11 + "'", int4 == 11);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "12/31/69" + "'", str6.equals("12/31/69"));
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(100.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setTickMarksVisible(false);
        java.awt.Font font7 = categoryAxis4.getTickLabelFont();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint10 = xYBarRenderer9.getBaseOutlinePaint();
        java.awt.Shape shape16 = null;
        java.awt.Paint paint18 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color20 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape23 = null;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color27 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape16, false, paint18, false, (java.awt.Paint) color20, stroke21, true, shape23, stroke24, (java.awt.Paint) color27);
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.0d, paint10, stroke24);
        float float30 = valueMarker29.getAlpha();
        java.awt.Stroke stroke31 = valueMarker29.getStroke();
        java.awt.Paint paint32 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        boolean boolean33 = valueMarker29.equals((java.lang.Object) paint32);
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.DATASET_UPDATED", font7, paint32);
        categoryAxis0.setTickLabelPaint(paint32);
        categoryAxis0.setMinorTickMarksVisible(false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.awt.Image image0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeImage(image0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer3D0.getSeriesItemLabelGenerator(15);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer3 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj4 = standardGradientPaintTransformer3.clone();
        barRenderer3D0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean((int) '4', (java.lang.Boolean) true);
        booleanList0.clear();
        java.lang.Boolean boolean6 = booleanList0.getBoolean(2);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.util.Date date6 = month5.getStart();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) (short) 0);
        int int10 = timeSeries3.getItemCount();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter2 = xYBarRenderer0.getBarPainter();
        java.awt.Shape shape8 = null;
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color19 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape8, false, paint10, false, (java.awt.Paint) color12, stroke13, true, shape15, stroke16, (java.awt.Paint) color19);
        java.awt.Paint paint21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem20.setLabelPaint(paint21);
        xYBarRenderer0.setBasePaint(paint21, false);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset25, valueAxis26, polarItemRenderer27);
        boolean boolean29 = polarPlot28.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        polarPlot28.datasetChanged(datasetChangeEvent30);
        java.awt.Font font32 = polarPlot28.getNoDataMessageFont();
        java.awt.Stroke stroke33 = polarPlot28.getRadiusGridlineStroke();
        xYBarRenderer0.setBaseStroke(stroke33);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYBarPainter2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        long long3 = segment2.getSegmentCount();
        boolean boolean4 = segment2.inExceptionSegments();
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) segment2, false);
        xYSeries6.add((double) 12, (java.lang.Number) 12.0d);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot1.getRangeAxis((int) (byte) 100);
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        double double3 = piePlot1.getShadowYOffset();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray1);
        java.lang.Object obj3 = symbolAxis2.clone();
        symbolAxis2.setAutoRangeMinimumSize((double) 1560495599999L);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        java.util.Date date2 = month0.getEnd();
        java.util.Date date3 = month0.getStart();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, (double) (byte) 10, (double) (byte) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity18 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis15, "JFreeChart", "PlotOrientation.HORIZONTAL");
        categoryAxis15.setMinorTickMarkOutsideLength((float) 3);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        try {
            double double12 = intervalXYDelegate9.getEndXValue(0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.Year year3 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (java.lang.Number) (-1.0d));
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 100.0d, false, false);
        try {
            java.lang.Number number5 = xYSeries3.getY((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        boolean boolean3 = multiplePiePlot1.isOutlineVisible();
        java.lang.Comparable comparable4 = multiplePiePlot1.getAggregatedItemsKey();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "Other" + "'", comparable4.equals("Other"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray1);
        java.lang.Object obj3 = symbolAxis2.clone();
        symbolAxis2.setRangeWithMargins(0.05d, (double) 1560495599999L);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis8.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource11 = null;
        chartRenderingInfo10.setRenderingSource(renderingSource11);
        java.awt.geom.Rectangle2D rectangle2D13 = chartRenderingInfo10.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets9.createInsetRectangle(rectangle2D13, false, false);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D13);
        org.jfree.chart.axis.AxisState axisState18 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        axisState18.moveCursor((double) 0, rectangleEdge20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState18.moveCursor((double) 100L, rectangleEdge23);
        double double25 = symbolAxis2.java2DToValue((double) 1577894400001L, rectangle2D13, rectangleEdge23);
        boolean boolean26 = symbolAxis2.isMinorTickMarksVisible();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.lang.Boolean boolean13 = xYBarRenderer0.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation14 = null;
        boolean boolean15 = xYBarRenderer0.removeAnnotation(xYAnnotation14);
        java.awt.Paint paint16 = xYBarRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint20 = xYBarRenderer0.getItemPaint((-460), 0, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis22.setTickMarksVisible(false);
        java.awt.Font font25 = categoryAxis22.getTickLabelFont();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint28 = xYBarRenderer27.getBaseOutlinePaint();
        java.awt.Shape shape34 = null;
        java.awt.Paint paint36 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color38 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape41 = null;
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color45 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape34, false, paint36, false, (java.awt.Paint) color38, stroke39, true, shape41, stroke42, (java.awt.Paint) color45);
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker(0.0d, paint28, stroke42);
        float float48 = valueMarker47.getAlpha();
        java.awt.Stroke stroke49 = valueMarker47.getStroke();
        java.awt.Paint paint50 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        boolean boolean51 = valueMarker47.equals((java.lang.Object) paint50);
        org.jfree.chart.block.LabelBlock labelBlock52 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.DATASET_UPDATED", font25, paint50);
        xYBarRenderer0.setBaseItemLabelFont(font25);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 1.0f + "'", float48 == 1.0f);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        boolean boolean34 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer3D0.getSeriesItemLabelGenerator(15);
        double double3 = barRenderer3D0.getItemMargin();
        boolean boolean5 = barRenderer3D0.isSeriesVisibleInLegend(7);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        boolean boolean12 = polarPlot11.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        polarPlot11.datasetChanged(datasetChangeEvent13);
        java.awt.Font font15 = polarPlot11.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("12/31/69", font15);
        try {
            barRenderer3D0.setSeriesItemLabelFont((-1), font15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.lang.Boolean boolean13 = xYBarRenderer0.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation14 = null;
        boolean boolean15 = xYBarRenderer0.removeAnnotation(xYAnnotation14);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint17 = xYBarRenderer16.getBaseOutlinePaint();
        xYBarRenderer0.setBaseOutlinePaint(paint17, true);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = xYBarRenderer0.getLegendItems();
        double double21 = xYBarRenderer0.getBase();
        double double22 = xYBarRenderer0.getShadowYOffset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 1, true, true);
        java.lang.Number number5 = null;
        xYSeries3.add((java.lang.Number) (byte) -1, number5);
        double double7 = xYSeries3.getMinX();
        try {
            java.lang.Number number9 = xYSeries3.getX((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        java.lang.String[] strArray5 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis6 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray5);
        java.lang.Object obj7 = symbolAxis6.clone();
        org.jfree.data.RangeType rangeType8 = org.jfree.data.RangeType.POSITIVE;
        java.lang.Object obj9 = null;
        boolean boolean10 = rangeType8.equals(obj9);
        symbolAxis6.setRangeType(rangeType8);
        org.jfree.data.Range range12 = combinedDomainXYPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) symbolAxis6);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        axisState14.moveCursor((double) 0, rectangleEdge16);
        axisState14.cursorUp((double) 1577894400005L);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryAxis20.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource23 = null;
        chartRenderingInfo22.setRenderingSource(renderingSource23);
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo22.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets21.createInsetRectangle(rectangle2D25, false, false);
        org.jfree.chart.axis.AxisState axisState29 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        axisState29.moveCursor((double) 0, rectangleEdge31);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState29.moveCursor((double) 100L, rectangleEdge34);
        axisState29.setCursor((double) 3);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer42 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint43 = xYBarRenderer42.getBaseOutlinePaint();
        java.awt.Shape shape49 = null;
        java.awt.Paint paint51 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color53 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape56 = null;
        java.awt.Stroke stroke57 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color60 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem61 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape49, false, paint51, false, (java.awt.Paint) color53, stroke54, true, shape56, stroke57, (java.awt.Paint) color60);
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker(0.0d, paint43, stroke57);
        double double63 = valueMarker62.getValue();
        org.jfree.chart.util.Layer layer64 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean66 = categoryPlot39.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker62, layer64, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = categoryPlot39.getDomainAxisEdge();
        axisState29.moveCursor(2.0d, rectangleEdge67);
        try {
            java.util.List list69 = symbolAxis6.refreshTicks(graphics2D13, axisState14, rectangle2D28, rectangleEdge67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rangeType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(layer64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(rectangleEdge67);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = state1.getEntityCollection();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState3 = state1.getSelectionState();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState4 = state1.getSelectionState();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset5 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset5);
        org.jfree.data.xy.XYDataItem xYDataItem9 = new org.jfree.data.xy.XYDataItem((double) 432000000L, (double) (-460));
        int int10 = defaultXYDataset5.indexOf((java.lang.Comparable) 432000000L);
        defaultXYDataset5.removeSeries((java.lang.Comparable) 4);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset5);
        try {
            state1.startSeriesPass((org.jfree.data.xy.XYDataset) defaultXYDataset5, 128, 128, (int) '#', 2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertNull(xYDatasetSelectionState3);
        org.junit.Assert.assertNull(xYDatasetSelectionState4);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.RenderingSource renderingSource2 = chartRenderingInfo1.getRenderingSource();
        org.junit.Assert.assertNull(renderingSource2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        java.util.Currency currency1 = numberFormat0.getCurrency();
        java.lang.String str3 = numberFormat0.format(86400000L);
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(currency1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "86,400,000" + "'", str3.equals("86,400,000"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number3 = xYDataItem2.getX();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        long long11 = timeSeries10.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries6.addAndOrUpdate(timeSeries10);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries12);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, (double) (byte) 10, (double) (byte) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.entity.AxisEntity axisEntity18 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis15, "JFreeChart", "PlotOrientation.HORIZONTAL");
        java.lang.String str19 = axisEntity18.getURLText();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str19.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis4);
        combinedDomainXYPlot5.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = combinedDomainXYPlot5.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = combinedDomainXYPlot5.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets10.calculateRightInset(0.0d);
        double double14 = rectangleInsets10.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot5.setAxisOffset(rectangleInsets10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        java.lang.String[] strArray18 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis19 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray18);
        java.lang.Object obj20 = symbolAxis19.clone();
        symbolAxis19.setRangeWithMargins(0.05d, (double) 1560495599999L);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryAxis24.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource27 = null;
        chartRenderingInfo26.setRenderingSource(renderingSource27);
        java.awt.geom.Rectangle2D rectangle2D29 = chartRenderingInfo26.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets25.createInsetRectangle(rectangle2D29, false, false);
        symbolAxis19.setDownArrow((java.awt.Shape) rectangle2D32);
        try {
            xYLineAndShapeRenderer0.drawDomainGridLine(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot5, valueAxis16, rectangle2D32, (double) 28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((double) 432000000L, (double) (-460));
        double double5 = ringPlot0.getExplodePercent((java.lang.Comparable) (-460));
        java.awt.Paint paint6 = ringPlot0.getSeparatorPaint();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        boolean boolean12 = polarPlot11.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        polarPlot11.datasetChanged(datasetChangeEvent13);
        java.awt.Font font15 = polarPlot11.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("DateTickUnitType.DAY", font15);
        boolean boolean17 = ringPlot0.equals((java.lang.Object) "DateTickUnitType.DAY");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color16 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape5, false, paint7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color16);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint19 = xYBarRenderer18.getBaseOutlinePaint();
        legendItem17.setLinePaint(paint19);
        legendItem17.setLineVisible(true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = state1.getEntityCollection();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo3);
        org.jfree.chart.entity.EntityCollection entityCollection5 = state4.getEntityCollection();
        java.awt.geom.Line2D line2D6 = state4.workingLine;
        state1.workingLine = line2D6;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D6, (float) (short) -1);
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertNull(entityCollection5);
        org.junit.Assert.assertNotNull(line2D6);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        polarPlot3.datasetChanged(datasetChangeEvent5);
        java.awt.Font font7 = polarPlot3.getNoDataMessageFont();
        java.awt.Stroke stroke8 = polarPlot3.getRadiusGridlineStroke();
        java.lang.String[] strArray10 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis11 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray10);
        java.lang.Object obj12 = symbolAxis11.clone();
        org.jfree.data.Range range13 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) symbolAxis11);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        float float5 = polarPlot4.getBackgroundImageAlpha();
        xYBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot4);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        polarPlot4.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.lang.String[] strArray13 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis14 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray13);
        java.lang.Object obj15 = symbolAxis14.clone();
        symbolAxis14.setRangeWithMargins(0.05d, (double) 1560495599999L);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryAxis20.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource23 = null;
        chartRenderingInfo22.setRenderingSource(renderingSource23);
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo22.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets21.createInsetRectangle(rectangle2D25, false, false);
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D25);
        org.jfree.chart.axis.AxisState axisState30 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        axisState30.moveCursor((double) 0, rectangleEdge32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState30.moveCursor((double) 100L, rectangleEdge35);
        double double37 = symbolAxis14.java2DToValue((double) 1577894400001L, rectangle2D25, rectangleEdge35);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = null;
        java.awt.geom.Point2D point2D39 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor38);
        try {
            polarPlot4.zoomRangeAxes(0.0d, 12.0d, plotRenderingInfo11, point2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.POSITIVE_INFINITY + "'", double37 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D39);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = combinedDomainXYPlot1.getDomainAxisEdge((int) (byte) -1);
        java.lang.String[] strArray7 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray7);
        java.lang.Object obj9 = symbolAxis8.clone();
        org.jfree.data.RangeType rangeType10 = org.jfree.data.RangeType.POSITIVE;
        java.lang.Object obj11 = null;
        boolean boolean12 = rangeType10.equals(obj11);
        symbolAxis8.setRangeType(rangeType10);
        java.lang.Object obj14 = null;
        boolean boolean15 = symbolAxis8.equals(obj14);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        java.lang.String str19 = numberTickUnit17.valueToString((double) 100L);
        symbolAxis8.setTickUnit(numberTickUnit17, false, false);
        symbolAxis8.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray25 = new org.jfree.chart.axis.ValueAxis[] { symbolAxis8 };
        combinedDomainXYPlot1.setRangeAxes(valueAxisArray25);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rangeType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(valueAxisArray25);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = piePlot1.getLegendLabelURLGenerator();
        piePlot1.clearSectionOutlinePaints(true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(pieURLGenerator3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.panRangeAxes((double) 3, plotRenderingInfo35, point2D36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener39 = null;
        jFreeChart38.addProgressListener(chartProgressListener39);
        java.awt.RenderingHints renderingHints41 = jFreeChart38.getRenderingHints();
        jFreeChart38.setBackgroundImageAlpha((float) '4');
        jFreeChart38.setBorderVisible(true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(renderingHints41);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color16 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape5, false, paint7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color16);
        java.awt.Paint paint18 = legendItem17.getOutlinePaint();
        boolean boolean19 = legendItem17.isShapeFilled();
        java.awt.Paint paint20 = legendItem17.getFillPaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer21 = legendItem17.getFillPaintTransformer();
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        legendItem17.setLine(shape22);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(gradientPaintTransformer21);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        boolean boolean12 = combinedDomainXYPlot1.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint15 = xYBarRenderer14.getBaseOutlinePaint();
        java.awt.Shape shape21 = null;
        java.awt.Paint paint23 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape28 = null;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color32 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape21, false, paint23, false, (java.awt.Paint) color25, stroke26, true, shape28, stroke29, (java.awt.Paint) color32);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(0.0d, paint15, stroke29);
        double double35 = valueMarker34.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType36 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo(entityCollection37);
        boolean boolean39 = chartChangeEventType36.equals((java.lang.Object) entityCollection37);
        java.lang.String str40 = chartChangeEventType36.toString();
        boolean boolean41 = valueMarker34.equals((java.lang.Object) chartChangeEventType36);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer44 = null;
        org.jfree.chart.plot.PolarPlot polarPlot45 = new org.jfree.chart.plot.PolarPlot(xYDataset42, valueAxis43, polarItemRenderer44);
        polarPlot45.setNoDataMessage("ThreadContext");
        java.awt.Paint paint48 = polarPlot45.getRadiusGridlinePaint();
        valueMarker34.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot45);
        boolean boolean50 = combinedDomainXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker34);
        java.lang.Object obj51 = combinedDomainXYPlot1.clone();
        float float52 = combinedDomainXYPlot1.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str40.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 1.0f + "'", float52 == 1.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        polarPlot3.datasetChanged(datasetChangeEvent5);
        java.awt.Font font7 = polarPlot3.getNoDataMessageFont();
        java.awt.Stroke stroke8 = polarPlot3.getRadiusGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getRangeMarkers((int) '4', layer11);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        java.util.TimeZone timeZone15 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeSeries14, timeZone15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection16, true);
        org.jfree.data.Range range20 = xYBarRenderer13.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot9, (org.jfree.data.general.Dataset) timeSeriesCollection16);
        java.awt.Stroke stroke22 = categoryPlot9.getDomainGridlineStroke();
        polarPlot3.setRadiusGridlineStroke(stroke22);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        combinedDomainXYPlot1.setRangeGridlineStroke(stroke6);
        int int8 = combinedDomainXYPlot1.getSeriesCount();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = xYBarRenderer1.getBaseOutlinePaint();
        java.awt.Shape shape8 = null;
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color19 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape8, false, paint10, false, (java.awt.Paint) color12, stroke13, true, shape15, stroke16, (java.awt.Paint) color19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, paint2, stroke16);
        double double22 = valueMarker21.getValue();
        valueMarker21.setLabel("");
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot25.getRangeMarkers((int) '4', layer27);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        categoryPlot25.setDomainAxis((int) (short) 0, categoryAxis30, true);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        categoryPlot25.setFixedRangeAxisSpace(axisSpace33);
        double double35 = categoryPlot25.getAnchorValue();
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot25.setRangeAxisLocation(axisLocation36);
        org.jfree.chart.axis.AxisLocation axisLocation38 = categoryPlot25.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        categoryPlot25.setFixedRangeAxisSpace(axisSpace39, true);
        org.jfree.chart.plot.Marker marker43 = null;
        org.jfree.chart.util.Layer layer44 = null;
        boolean boolean45 = categoryPlot25.removeDomainMarker((int) (byte) 0, marker43, layer44);
        valueMarker21.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot25);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 1, true, true);
        xYSeries3.add(0.2d, 1.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.addChangeListener(plotChangeListener3);
        org.jfree.data.general.PieDataset pieDataset5 = piePlot1.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1), 12.0d, (double) '#', (double) 1577894400005L);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource14 = null;
        chartRenderingInfo13.setRenderingSource(renderingSource14);
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo13.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets12.createInsetRectangle(rectangle2D16, false, false);
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets10.createInsetRectangle(rectangle2D16, false, true);
        piePlot1.setInsets(rectangleInsets10, true);
        java.awt.Color color25 = java.awt.Color.GREEN;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color25);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = xYBarRenderer2.getBaseItemLabelPaint();
        boolean boolean7 = xYBarRenderer2.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        xYBarRenderer2.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator9);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer2.setBaseLegendShape(shape12);
        java.lang.Boolean boolean15 = xYBarRenderer2.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation16 = null;
        boolean boolean17 = xYBarRenderer2.removeAnnotation(xYAnnotation16);
        java.awt.Paint paint18 = xYBarRenderer2.getBaseItemLabelPaint();
        java.awt.Paint paint22 = xYBarRenderer2.getItemPaint((-460), 0, true);
        boolean boolean23 = standardGradientPaintTransformer0.equals((java.lang.Object) (-460));
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = null;
        try {
            org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 5, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.util.Date date6 = month5.getStart();
        int int7 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        java.util.Date date10 = month8.getEnd();
        java.util.Date date11 = month8.getStart();
        java.util.TimeZone timeZone12 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone12;
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date11, timeZone12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) '4');
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "PlotOrientation.HORIZONTAL", "hi!");
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8);
        boolean boolean10 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot0.getRenderer(9999);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(categoryItemRenderer12);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.addChangeListener(plotChangeListener3);
        piePlot1.setCircular(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot1.getLabelGenerator();
        java.lang.Comparable comparable8 = null;
        java.awt.Paint paint9 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        try {
            piePlot1.setSectionPaint(comparable8, paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number3 = xYDataItem2.getX();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset7.removeSeries((java.lang.Comparable) 'a');
        timeSeries6.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset7);
        try {
            double double13 = defaultXYDataset7.getYValue(3, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.lang.Boolean boolean13 = xYBarRenderer0.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation14 = null;
        boolean boolean15 = xYBarRenderer0.removeAnnotation(xYAnnotation14);
        java.awt.Paint paint16 = xYBarRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint20 = xYBarRenderer0.getItemPaint((-460), 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer22.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.plot.XYPlot xYPlot25 = xYBarRenderer22.getPlot();
        java.awt.Stroke stroke27 = xYBarRenderer22.getSeriesStroke((int) (byte) 100);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint29 = xYBarRenderer28.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter30 = xYBarRenderer28.getBarPainter();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = xYBarRenderer28.getNegativeItemLabelPosition((int) (byte) 100, (-1), true);
        xYBarRenderer22.setBaseNegativeItemLabelPosition(itemLabelPosition34);
        xYBarRenderer0.setSeriesPositiveItemLabelPosition(15, itemLabelPosition34);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(xYPlot25);
        org.junit.Assert.assertNull(stroke27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(xYBarPainter30);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter2 = xYBarRenderer0.getBarPainter();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYBarRenderer0.getNegativeItemLabelPosition((int) (byte) 100, (-1), true);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesOutlinePaint((int) (byte) 1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYBarPainter2);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = null;
        axisState0.moveCursor((double) 0, rectangleEdge2);
        axisState0.cursorRight(0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number3 = xYDataItem2.getX();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2, "October", "RectangleAnchor.BOTTOM");
        timeSeries6.setKey((java.lang.Comparable) 4.0d);
        java.lang.Class class9 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getStart();
        long long12 = month10.getSerialIndex();
        org.jfree.data.time.Year year13 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year13, regularTimePeriod14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
        org.junit.Assert.assertNotNull(year13);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        polarPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        polarPlot7.addChangeListener(plotChangeListener11);
        java.lang.String str13 = polarPlot7.getNoDataMessage();
        polarPlot7.setAngleGridlinesVisible(true);
        org.jfree.data.general.WaferMapDataset waferMapDataset18 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer19 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot20 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset18, waferMapRenderer19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot(xYDataset22, valueAxis23, polarItemRenderer24);
        boolean boolean26 = polarPlot25.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        polarPlot25.datasetChanged(datasetChangeEvent27);
        java.awt.Font font29 = polarPlot25.getNoDataMessageFont();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot31.getRangeMarkers((int) '4', layer33);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer35 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries36 = null;
        java.util.TimeZone timeZone37 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection38 = new org.jfree.data.time.TimeSeriesCollection(timeSeries36, timeZone37);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection38, true);
        org.jfree.data.Range range42 = xYBarRenderer35.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection38);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent43 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot31, (org.jfree.data.general.Dataset) timeSeriesCollection38);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo45 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource46 = null;
        chartRenderingInfo45.setRenderingSource(renderingSource46);
        java.awt.geom.Rectangle2D rectangle2D48 = chartRenderingInfo45.getChartArea();
        java.awt.geom.Point2D point2D49 = null;
        org.jfree.chart.plot.PlotState plotState50 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        categoryPlot31.draw(graphics2D44, rectangle2D48, point2D49, plotState50, plotRenderingInfo51);
        java.awt.geom.Point2D point2D53 = null;
        org.jfree.chart.plot.PlotState plotState54 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        polarPlot25.draw(graphics2D30, rectangle2D48, point2D53, plotState54, plotRenderingInfo55);
        java.awt.geom.Point2D point2D57 = null;
        org.jfree.chart.plot.PlotState plotState58 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        waferMapPlot20.draw(graphics2D21, rectangle2D48, point2D57, plotState58, plotRenderingInfo59);
        try {
            java.awt.Point point61 = polarPlot7.translateValueThetaRadiusToJava2D((double) 1.0f, (double) 100.0f, rectangle2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(rectangle2D48);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        java.lang.Object obj1 = xYSeriesCollection0.clone();
        try {
            java.lang.Number number4 = xYSeriesCollection0.getStartX(5, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str2 = numberFormat0.format((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot3.getRangeMarkers((int) '4', layer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot3.setDomainAxis((int) (short) 0, categoryAxis8, true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot3.setFixedRangeAxisSpace(axisSpace11);
        double double13 = categoryPlot3.getAnchorValue();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarksVisible(false);
        java.awt.Font font17 = categoryAxis14.getTickLabelFont();
        categoryPlot3.setDomainAxis(categoryAxis14);
        java.lang.StringBuffer stringBuffer19 = null;
        java.text.FieldPosition fieldPosition20 = null;
        try {
            java.lang.StringBuffer stringBuffer21 = numberFormat0.format((java.lang.Object) categoryAxis14, stringBuffer19, fieldPosition20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1" + "'", str2.equals("-1"));
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        categoryPlot0.setRangeMinorGridlineStroke(stroke30);
        java.lang.String str32 = categoryPlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.addChangeListener(plotChangeListener3);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator5 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        piePlot1.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator5);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        float float12 = polarPlot11.getBackgroundImageAlpha();
        xYBarRenderer7.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot11);
        java.awt.Color color15 = java.awt.Color.orange;
        xYBarRenderer7.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color15);
        piePlot1.setOutlinePaint((java.awt.Paint) color15);
        java.lang.String str18 = color15.toString();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str18.equals("java.awt.Color[r=255,g=200,b=0]"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection2);
        org.jfree.data.general.DatasetGroup datasetGroup10 = timeSeriesCollection2.getGroup();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset15, valueAxis16, polarItemRenderer17);
        polarPlot18.setNoDataMessage("ThreadContext");
        java.awt.Paint paint21 = polarPlot18.getRadiusGridlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) 9999, (double) 0, (double) '#', paint21);
        boolean boolean23 = datasetGroup10.equals((java.lang.Object) blockBorder22);
        java.lang.String str24 = datasetGroup10.getID();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(datasetGroup10);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "NOID" + "'", str24.equals("NOID"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.lang.Boolean boolean13 = xYBarRenderer0.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis14);
        combinedDomainXYPlot15.setRangeCrosshairValue(0.0d);
        combinedDomainXYPlot15.setDomainMinorGridlinesVisible(true);
        xYBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot15);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint22 = xYBarRenderer21.getBaseItemLabelPaint();
        boolean boolean26 = xYBarRenderer21.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator28 = null;
        xYBarRenderer21.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator28);
        java.awt.Shape shape35 = null;
        java.awt.Paint paint37 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color39 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape42 = null;
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color46 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape35, false, paint37, false, (java.awt.Paint) color39, stroke40, true, shape42, stroke43, (java.awt.Paint) color46);
        java.awt.Paint paint48 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem47.setLabelPaint(paint48);
        xYBarRenderer21.setBaseLegendTextPaint(paint48);
        java.awt.Stroke stroke52 = xYBarRenderer21.lookupSeriesOutlineStroke((int) (byte) 100);
        xYBarRenderer21.setSeriesItemLabelsVisible(10, (java.lang.Boolean) false);
        java.lang.Boolean boolean57 = xYBarRenderer21.getSeriesVisibleInLegend((int) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition58 = xYBarRenderer21.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition62 = xYBarRenderer21.getNegativeItemLabelPosition((int) (short) 10, (int) ' ', true);
        xYBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition62, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(boolean57);
        org.junit.Assert.assertNull(itemLabelPosition58);
        org.junit.Assert.assertNotNull(itemLabelPosition62);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        java.text.ParsePosition parsePosition2 = null;
        try {
            java.lang.Object obj3 = numberFormat0.parseObject("NOID", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray2 = new float[] { (byte) 1 };
        try {
            float[] floatArray3 = color0.getRGBComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate4);
        java.lang.String str6 = serialDate5.toString();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "11-April-1900" + "'", str6.equals("11-April-1900"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        polarPlot3.datasetChanged(datasetChangeEvent5);
        java.awt.Font font7 = polarPlot3.getNoDataMessageFont();
        java.awt.Stroke stroke8 = polarPlot3.getRadiusGridlineStroke();
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        java.util.TimeZone timeZone10 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeSeries9, timeZone10);
        java.lang.Comparable comparable12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeriesCollection11.getSeries(comparable12);
        timeSeriesCollection11.removeAllSeries();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long17 = segmentedTimeline15.getTimeFromLong(0L);
        java.util.List list18 = segmentedTimeline15.getExceptionSegments();
        org.jfree.data.Range range19 = null;
        org.jfree.data.Range range21 = org.jfree.data.Range.expandToInclude(range19, (double) 100);
        double double22 = range21.getLength();
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection11, list18, range21, false);
        polarPlot3.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot26.getRangeMarkers((int) '4', layer28);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        categoryPlot26.setDomainAxis((int) (short) 0, categoryAxis31, true);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot26.setFixedRangeAxisSpace(axisSpace34);
        double double36 = categoryPlot26.getAnchorValue();
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot26.setRangeAxisLocation(axisLocation37);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot26.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace40 = null;
        categoryPlot26.setFixedRangeAxisSpace(axisSpace40, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        java.util.List list44 = categoryPlot26.getCategoriesForAxis(categoryAxis43);
        org.jfree.data.Range range46 = timeSeriesCollection11.getDomainBounds(list44, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(timeSeries13);
        org.junit.Assert.assertNotNull(segmentedTimeline15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertNull(range46);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer3D0.getSeriesItemLabelGenerator(15);
        double double3 = barRenderer3D0.getXOffset();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint9 = xYBarRenderer8.getBaseOutlinePaint();
        java.awt.Shape shape15 = null;
        java.awt.Paint paint17 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color19 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape22 = null;
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color26 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape15, false, paint17, false, (java.awt.Paint) color19, stroke20, true, shape22, stroke23, (java.awt.Paint) color26);
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d, paint9, stroke23);
        double double29 = valueMarker28.getValue();
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean32 = categoryPlot5.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker28, layer30, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot5.getDomainAxisEdge();
        double double34 = categoryPlot5.getRangeCrosshairValue();
        double double35 = categoryPlot5.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        categoryPlot5.setRangeAxis(1, valueAxis37);
        boolean boolean39 = categoryPlot5.isDomainGridlinesVisible();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        try {
            barRenderer3D0.drawDomainGridline(graphics2D4, categoryPlot5, rectangle2D40, (double) (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number3 = xYDataItem2.getX();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2, "October", "RectangleAnchor.BOTTOM");
        xYDataItem2.setY((double) 1L);
        xYDataItem2.setY((double) 24234L);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = standardPieSectionLabelGenerator0.getAttributedLabel((int) ' ');
        java.text.AttributedString attributedString4 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel(2, attributedString4);
        org.junit.Assert.assertNull(attributedString2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.lang.Boolean boolean13 = xYBarRenderer0.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation14 = null;
        boolean boolean15 = xYBarRenderer0.removeAnnotation(xYAnnotation14);
        java.awt.Paint paint16 = xYBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor17, textAnchor18, textAnchor19, 0.0d);
        xYBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition21);
        boolean boolean23 = xYBarRenderer0.getAutoPopulateSeriesFillPaint();
        boolean boolean24 = xYBarRenderer0.getAutoPopulateSeriesStroke();
        boolean boolean25 = xYBarRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        java.lang.Object obj1 = xYSeriesCollection0.clone();
        try {
            xYSeriesCollection0.setSelected((int) (short) 1, 7, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.LEFT" + "'", str1.equals("HorizontalAlignment.LEFT"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 1, true, true);
        java.awt.Color color4 = java.awt.Color.magenta;
        boolean boolean5 = xYSeries3.equals((java.lang.Object) color4);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.lang.Object obj1 = legendItemCollection0.clone();
        try {
            org.jfree.chart.LegendItem legendItem3 = legendItemCollection0.get(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator2);
        java.awt.Paint paint4 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot5.getRangeMarkers((int) '4', layer7);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries10 = null;
        java.util.TimeZone timeZone11 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeSeries10, timeZone11);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection12, true);
        org.jfree.data.Range range16 = xYBarRenderer9.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot5, (org.jfree.data.general.Dataset) timeSeriesCollection12);
        piePlot1.datasetChanged(datasetChangeEvent17);
        piePlot1.setMaximumLabelWidth((double) 2);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape22);
        java.lang.Object obj24 = chartEntity23.clone();
        java.awt.Shape shape25 = chartEntity23.getArea();
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent29 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) shape25, jFreeChart26, (-460), (int) (byte) 100);
        piePlot1.setLegendItemShape(shape25);
        java.awt.Color color34 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "October", (java.awt.Paint) color34);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(color34);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = state1.getEntityCollection();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState3 = state1.getSelectionState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo4);
        org.jfree.chart.entity.EntityCollection entityCollection6 = state5.getEntityCollection();
        java.awt.geom.Line2D line2D7 = state5.workingLine;
        state1.workingLine = line2D7;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection9 = new org.jfree.data.xy.XYSeriesCollection();
        java.lang.Object obj10 = xYSeriesCollection9.clone();
        try {
            state1.startSeriesPass((org.jfree.data.xy.XYDataset) xYSeriesCollection9, 5, 7, (int) 'a', (int) ' ', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertNull(xYDatasetSelectionState3);
        org.junit.Assert.assertNull(entityCollection6);
        org.junit.Assert.assertNotNull(line2D7);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection4.getSeries((int) (byte) 0);
        boolean boolean7 = timeSeries6.isEmpty();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape14 = null;
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color25 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape14, false, paint16, false, (java.awt.Paint) color18, stroke19, true, shape21, stroke22, (java.awt.Paint) color25);
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem26.setLabelPaint(paint27);
        xYBarRenderer0.setBaseLegendTextPaint(paint27);
        java.awt.Stroke stroke31 = xYBarRenderer0.lookupSeriesOutlineStroke((int) (byte) 100);
        xYBarRenderer0.setSeriesItemLabelsVisible(10, (java.lang.Boolean) false);
        java.lang.Boolean boolean36 = xYBarRenderer0.getSeriesVisibleInLegend((int) '#');
        xYBarRenderer0.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(boolean36);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        boolean boolean12 = combinedDomainXYPlot1.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint15 = xYBarRenderer14.getBaseOutlinePaint();
        java.awt.Shape shape21 = null;
        java.awt.Paint paint23 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape28 = null;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color32 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape21, false, paint23, false, (java.awt.Paint) color25, stroke26, true, shape28, stroke29, (java.awt.Paint) color32);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(0.0d, paint15, stroke29);
        double double35 = valueMarker34.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType36 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo(entityCollection37);
        boolean boolean39 = chartChangeEventType36.equals((java.lang.Object) entityCollection37);
        java.lang.String str40 = chartChangeEventType36.toString();
        boolean boolean41 = valueMarker34.equals((java.lang.Object) chartChangeEventType36);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer44 = null;
        org.jfree.chart.plot.PolarPlot polarPlot45 = new org.jfree.chart.plot.PolarPlot(xYDataset42, valueAxis43, polarItemRenderer44);
        polarPlot45.setNoDataMessage("ThreadContext");
        java.awt.Paint paint48 = polarPlot45.getRadiusGridlinePaint();
        valueMarker34.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot45);
        boolean boolean50 = combinedDomainXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker34);
        valueMarker34.setValue(12.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str40.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long2 = segmentedTimeline0.getTimeFromLong(0L);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType3 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType3, 5);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType6 = dateTickUnit5.getUnitType();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getStart();
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        java.util.TimeZone timeZone10 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeSeries9, timeZone10);
        java.util.Date date12 = dateTickUnit5.addToDate(date8, timeZone10);
        segmentedTimeline0.addBaseTimelineException(date12);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(dateTickUnitType3);
        org.junit.Assert.assertNotNull(dateTickUnitType6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        boolean boolean4 = segmentedTimeline0.containsDomainValue((long) (short) 0);
        boolean boolean5 = segmentedTimeline0.getAdjustForDaylightSaving();
        long long6 = segmentedTimeline0.getSegmentSize();
        long long7 = segmentedTimeline0.getSegmentsIncludedSize();
        boolean boolean9 = segmentedTimeline0.containsDomainValue(0L);
        segmentedTimeline0.addException((-1L));
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86400000L + "'", long6 == 86400000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 432000000L + "'", long7 == 432000000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) 1577894400005L, range3);
        java.lang.String str5 = range3.toString();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Range[100.0,100.0]" + "'", str5.equals("Range[100.0,100.0]"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = state1.getEntityCollection();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState3 = state1.getSelectionState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo4);
        org.jfree.chart.entity.EntityCollection entityCollection6 = state5.getEntityCollection();
        java.awt.geom.Line2D line2D7 = state5.workingLine;
        state1.workingLine = line2D7;
        java.awt.geom.GeneralPath generalPath9 = null;
        state1.seriesPath = generalPath9;
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertNull(xYDatasetSelectionState3);
        org.junit.Assert.assertNull(entityCollection6);
        org.junit.Assert.assertNotNull(line2D7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("");
        java.lang.String str3 = textFragment2.getText();
        java.awt.Font font4 = textFragment2.getFont();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        java.lang.Object obj23 = null;
        boolean boolean24 = legendItem22.equals(obj23);
        java.awt.Paint paint25 = legendItem22.getFillPaint();
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.DATASET_UPDATED", font4, paint25);
        labelBlock26.setHeight((double) '4');
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor29 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.lang.String str30 = textBlockAnchor29.toString();
        labelBlock26.setContentAlignmentPoint(textBlockAnchor29);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot33 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis32);
        combinedDomainXYPlot33.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = combinedDomainXYPlot33.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = combinedDomainXYPlot33.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double40 = rectangleInsets38.calculateRightInset(0.0d);
        double double42 = rectangleInsets38.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot33.setAxisOffset(rectangleInsets38);
        boolean boolean44 = textBlockAnchor29.equals((java.lang.Object) rectangleInsets38);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(textBlockAnchor29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "TextBlockAnchor.BOTTOM_CENTER" + "'", str30.equals("TextBlockAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 4.0d + "'", double40 == 4.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.awt.Shape shape4 = null;
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendTitle6.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint9 = xYBarRenderer8.getBaseOutlinePaint();
        java.awt.Paint paint10 = xYBarRenderer8.getBasePaint();
        java.awt.Paint paint12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer8.setSeriesItemLabelPaint(1, paint12);
        legendTitle6.setBackgroundPaint(paint12);
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("October", "DateTickUnitType.DAY", "", "", shape4, paint12);
        legendItem15.setShapeVisible(false);
        boolean boolean18 = legendItem15.isLineVisible();
        java.awt.Paint paint19 = legendItem15.getLabelPaint();
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        xYBarRenderer0.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("October");
        int int2 = legendItem1.getDatasetIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        int int1 = numberFormat0.getMaximumFractionDigits();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.setTickMarksVisible(false);
        java.awt.Font font6 = categoryAxis3.getTickLabelFont();
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor(0, 4, (int) '4');
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font6, (java.awt.Paint) chartColor10, (float) (byte) 100, 100, textMeasurer13);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset16, valueAxis17, polarItemRenderer18);
        java.awt.Font font20 = polarPlot19.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("ChartChangeEventType.DATASET_UPDATED", font20);
        org.jfree.chart.text.TextFragment textFragment22 = textLine21.getFirstTextFragment();
        textBlock14.addLine(textLine21);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline24 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment26 = segmentedTimeline24.getSegment((long) (short) 100);
        long long27 = segment26.getSegmentCount();
        long long28 = segment26.getSegmentCount();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline29 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment31 = segmentedTimeline29.getSegment((long) (short) 100);
        long long32 = segment31.getSegmentCount();
        segment31.dec();
        boolean boolean34 = segment26.contains(segment31);
        long long35 = segment31.getSegmentEnd();
        boolean boolean36 = textLine21.equals((java.lang.Object) long35);
        java.text.AttributedCharacterIterator attributedCharacterIterator37 = numberFormat0.formatToCharacterIterator((java.lang.Object) long35);
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(textFragment22);
        org.junit.Assert.assertNotNull(segmentedTimeline24);
        org.junit.Assert.assertNotNull(segment26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
        org.junit.Assert.assertNotNull(segmentedTimeline29);
        org.junit.Assert.assertNotNull(segment31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-57600001L) + "'", long35 == (-57600001L));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(attributedCharacterIterator37);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, true);
        org.jfree.data.Range range11 = xYBarRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot0, (org.jfree.data.general.Dataset) timeSeriesCollection7);
        java.awt.Stroke stroke13 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot0.panRangeAxes(0.0d, plotRenderingInfo15, point2D16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryAxis18.getTickLabelInsets();
        java.util.List list20 = categoryPlot0.getCategoriesForAxis(categoryAxis18);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.lang.Boolean boolean13 = xYBarRenderer0.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation14 = null;
        boolean boolean15 = xYBarRenderer0.removeAnnotation(xYAnnotation14);
        java.awt.Paint paint16 = xYBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYBarRenderer0.getNegativeItemLabelPosition(11, (int) (short) 1, true);
        java.awt.Shape shape26 = null;
        java.awt.Paint paint28 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color30 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape33 = null;
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color37 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape26, false, paint28, false, (java.awt.Paint) color30, stroke31, true, shape33, stroke34, (java.awt.Paint) color37);
        xYBarRenderer0.setBaseOutlineStroke(stroke31);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        boolean boolean28 = chartChangeEventType25.equals((java.lang.Object) entityCollection26);
        java.lang.String str29 = chartChangeEventType25.toString();
        boolean boolean30 = valueMarker23.equals((java.lang.Object) chartChangeEventType25);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean33 = xYPlot0.removeRangeMarker(8, (org.jfree.chart.plot.Marker) valueMarker23, layer31, true);
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot0.getDataset();
        try {
            java.awt.Paint paint36 = xYPlot0.getQuadrantPaint(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (12) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str29.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(xYDataset34);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Paint paint5 = xYBarRenderer3.getBasePaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer3.setSeriesItemLabelPaint(1, paint7);
        legendTitle1.setBackgroundPaint(paint7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = legendTitle1.getHorizontalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.title.Title title12 = titleChangeEvent11.getTitle();
        boolean boolean13 = title12.visible;
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(title12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setSectionDepth((double) 10);
        boolean boolean4 = itemLabelAnchor0.equals((java.lang.Object) 10);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (short) 100, (double) (-1));
        java.lang.String str3 = xYDataItem2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[100.0, -1.0]" + "'", str3.equals("[100.0, -1.0]"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter2 = xYBarRenderer0.getBarPainter();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYBarRenderer0.getNegativeItemLabelPosition((int) (byte) 100, (-1), true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYBarRenderer0.setSeriesURLGenerator((int) (short) 0, xYURLGenerator8, true);
        boolean boolean11 = xYBarRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYBarPainter2);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        java.awt.Paint paint5 = categoryAxis0.getLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
        combinedDomainXYPlot7.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = combinedDomainXYPlot7.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = combinedDomainXYPlot7.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset(0.0d);
        double double16 = rectangleInsets12.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot7.setAxisOffset(rectangleInsets12);
        boolean boolean18 = combinedDomainXYPlot7.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke19 = combinedDomainXYPlot7.getRangeZeroBaselineStroke();
        boolean boolean20 = combinedDomainXYPlot7.isRangeZoomable();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) combinedDomainXYPlot7);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        double double3 = xYDataItem2.getYValue();
        xYDataItem2.setSelected(false);
        java.lang.String str6 = xYDataItem2.toString();
        java.lang.Object obj7 = xYDataItem2.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[100.0, 12.0]" + "'", str6.equals("[100.0, 12.0]"));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.addChangeListener(plotChangeListener3);
        org.jfree.data.general.PieDataset pieDataset5 = piePlot1.getDataset();
        boolean boolean6 = piePlot1.getIgnoreZeroValues();
        piePlot1.setBackgroundAlpha((float) 0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = combinedDomainXYPlot1.getDomainAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = combinedDomainXYPlot1.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(axisSpace6);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        xYLineAndShapeRenderer0.setSeriesShapesFilled((int) (short) 100, (java.lang.Boolean) false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        int int1 = numberFormat0.getMaximumFractionDigits();
        boolean boolean2 = numberFormat0.isParseIntegerOnly();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        long long3 = segment2.getSegmentCount();
        boolean boolean4 = segment2.inExceptionSegments();
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) segment2, false);
        xYSeries6.add(Double.POSITIVE_INFINITY, (double) (byte) -1);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1, timeZone2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        timeSeriesCollection3.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = null;
        polarPlot8.setDrawingSupplier(drawingSupplier10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        polarPlot8.addChangeListener(plotChangeListener12);
        java.lang.String str14 = polarPlot8.getNoDataMessage();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) polarPlot8);
        categoryPlot0.setCrosshairDatasetIndex(9999);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        polarPlot7.removeCornerTextItem("DateTickUnitType.DAY");
        org.jfree.chart.LegendItemCollection legendItemCollection11 = polarPlot7.getLegendItems();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint5 = xYBarRenderer4.getBaseItemLabelPaint();
        boolean boolean9 = xYBarRenderer4.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYBarRenderer4.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator11);
        java.awt.Shape shape18 = null;
        java.awt.Paint paint20 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color22 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape25 = null;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color29 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape18, false, paint20, false, (java.awt.Paint) color22, stroke23, true, shape25, stroke26, (java.awt.Paint) color29);
        java.awt.Paint paint31 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem30.setLabelPaint(paint31);
        xYBarRenderer4.setBaseLegendTextPaint(paint31);
        java.awt.Stroke stroke35 = xYBarRenderer4.lookupSeriesOutlineStroke((int) (byte) 100);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint37 = xYBarRenderer36.getBaseItemLabelPaint();
        boolean boolean41 = xYBarRenderer36.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator43 = null;
        xYBarRenderer36.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator43);
        java.awt.Shape shape45 = xYBarRenderer36.getBaseLegendShape();
        java.awt.Shape shape46 = xYBarRenderer36.getLegendBar();
        xYBarRenderer4.setBaseLegendShape(shape46);
        java.awt.Shape shape53 = null;
        java.awt.Paint paint55 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color57 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke58 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape60 = null;
        java.awt.Stroke stroke61 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color64 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem65 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape53, false, paint55, false, (java.awt.Paint) color57, stroke58, true, shape60, stroke61, (java.awt.Paint) color64);
        java.awt.Color color66 = java.awt.Color.RED;
        try {
            org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem(attributedString0, "http://www.jfree.org/jfreechart/index.html", "java.awt.Color[r=255,g=200,b=0]", "NOID", shape46, stroke61, (java.awt.Paint) color66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNull(shape45);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(color66);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1, timeZone2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3, true);
        org.jfree.data.Range range7 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        boolean boolean12 = polarPlot11.isAngleLabelsVisible();
        polarPlot11.setAngleLabelsVisible(true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint16 = xYBarRenderer15.getBaseItemLabelPaint();
        boolean boolean20 = xYBarRenderer15.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        java.awt.Shape shape21 = xYBarRenderer15.getBaseLegendShape();
        java.awt.Paint paint23 = xYBarRenderer15.getLegendTextPaint(6);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint26 = xYBarRenderer25.getBaseItemLabelPaint();
        boolean boolean30 = xYBarRenderer25.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator32 = null;
        xYBarRenderer25.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator32);
        java.awt.Shape shape39 = null;
        java.awt.Paint paint41 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color43 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape46 = null;
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color50 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem51 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape39, false, paint41, false, (java.awt.Paint) color43, stroke44, true, shape46, stroke47, (java.awt.Paint) color50);
        java.awt.Paint paint52 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem51.setLabelPaint(paint52);
        xYBarRenderer25.setBaseLegendTextPaint(paint52);
        java.awt.Stroke stroke56 = xYBarRenderer25.lookupSeriesOutlineStroke((int) (byte) 100);
        xYBarRenderer25.setSeriesItemLabelsVisible(10, (java.lang.Boolean) false);
        java.lang.Boolean boolean61 = xYBarRenderer25.getSeriesVisibleInLegend((int) '#');
        java.awt.Font font63 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        xYBarRenderer25.setLegendTextFont(28, font63);
        xYBarRenderer15.setSeriesItemLabelFont(64, font63, false);
        polarPlot11.setNoDataMessageFont(font63);
        xYBarRenderer0.setBaseItemLabelFont(font63);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNull(boolean61);
        org.junit.Assert.assertNotNull(font63);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "ClassContext", numberArray3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        double double8 = legendTitle7.getHeight();
        legendTitle7.setPadding((double) 11, (double) 1577894400005L, (double) 9999, (double) (short) -1);
        boolean boolean14 = legendTitle7.isVisible();
        int int15 = day5.compareTo((java.lang.Object) boolean14);
        org.jfree.data.general.PieDataset pieDataset16 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset4, (java.lang.Comparable) day5);
        java.text.AttributedString attributedString18 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset16, (java.lang.Comparable) (short) 0);
        java.text.NumberFormat numberFormat19 = standardPieSectionLabelGenerator0.getPercentFormat();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(categoryDataset4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(pieDataset16);
        org.junit.Assert.assertNull(attributedString18);
        org.junit.Assert.assertNotNull(numberFormat19);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(8, 5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxisForDataset((int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot3.getRangeMarkers((int) '4', layer5);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries8 = null;
        java.util.TimeZone timeZone9 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeSeries8, timeZone9);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, true);
        org.jfree.data.Range range14 = xYBarRenderer7.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot3, (org.jfree.data.general.Dataset) timeSeriesCollection10);
        java.awt.Stroke stroke16 = categoryPlot3.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot3.getRangeAxisLocation();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = categoryPlot3.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier18);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(drawingSupplier18);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        polarPlot3.datasetChanged(datasetChangeEvent5);
        java.awt.Font font7 = polarPlot3.getNoDataMessageFont();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getRangeMarkers((int) '4', layer11);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        java.util.TimeZone timeZone15 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeSeries14, timeZone15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection16, true);
        org.jfree.data.Range range20 = xYBarRenderer13.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot9, (org.jfree.data.general.Dataset) timeSeriesCollection16);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource24 = null;
        chartRenderingInfo23.setRenderingSource(renderingSource24);
        java.awt.geom.Rectangle2D rectangle2D26 = chartRenderingInfo23.getChartArea();
        java.awt.geom.Point2D point2D27 = null;
        org.jfree.chart.plot.PlotState plotState28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        categoryPlot9.draw(graphics2D22, rectangle2D26, point2D27, plotState28, plotRenderingInfo29);
        java.awt.geom.Point2D point2D31 = null;
        org.jfree.chart.plot.PlotState plotState32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        polarPlot3.draw(graphics2D8, rectangle2D26, point2D31, plotState32, plotRenderingInfo33);
        org.jfree.chart.axis.ValueAxis valueAxis35 = polarPlot3.getAxis();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNull(valueAxis35);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        long long3 = segment2.getSegmentCount();
        boolean boolean4 = segment2.inExceptionSegments();
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) segment2, false);
        org.jfree.data.time.TimeSeries timeSeries7 = null;
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeSeries7, timeZone8);
        java.lang.Comparable comparable10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeriesCollection9.getSeries(comparable10);
        xYSeries6.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection9);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate13 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(timeSeries11);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        combinedDomainXYPlot1.setDomainMinorGridlinesVisible(true);
        int int6 = combinedDomainXYPlot1.getRendererCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis32.getTickLabelInsets();
        categoryAxis32.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        double double37 = categoryAxis32.getUpperMargin();
        java.awt.Paint paint38 = categoryAxis32.getLabelPaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker39 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d, paint38);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = intervalMarker39.getLabelOffsetType();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean43 = categoryPlot0.removeDomainMarker((-460), (org.jfree.chart.plot.Marker) intervalMarker39, layer41, true);
        java.awt.Paint paint44 = categoryPlot0.getDomainCrosshairPaint();
        java.awt.Paint paint45 = null;
        try {
            categoryPlot0.setRangeCrosshairPaint(paint45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(legendItemCollection28);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(lengthAdjustmentType40);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 100);
        double double3 = range2.getLength();
        boolean boolean6 = range2.intersects((double) 4, (double) 0.0f);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift(range2, (double) 10L, true);
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range2, (double) 7);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer3D0.getSeriesItemLabelGenerator(15);
        barRenderer3D0.setItemMargin((double) 100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = barRenderer3D0.getSeriesItemLabelGenerator(0);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8);
        double double10 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation11);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation11, plotOrientation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, serialDate6);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis10.getTickLabelInsets();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        java.awt.Paint paint15 = categoryAxis10.getAxisLinePaint();
        java.lang.String str17 = categoryAxis10.getCategoryLabelToolTip((java.lang.Comparable) 1);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray18 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis10 };
        categoryPlot0.setDomainAxes(categoryAxisArray18);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint23 = xYBarRenderer22.getBaseItemLabelPaint();
        piePlot21.setLabelPaint(paint23);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator25 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot21.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator25);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) piePlot21);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(categoryAxisArray18);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 100);
        int int2 = pieLabelDistributor1.getItemCount();
        java.lang.String str3 = pieLabelDistributor1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str1.equals("HorizontalAlignment.RIGHT"));
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getMonth();
//        java.util.Calendar calendar3 = null;
//        try {
//            day0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = xYBarRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("");
        java.lang.String str15 = textFragment14.getText();
        java.awt.Font font16 = textFragment14.getFont();
        xYBarRenderer0.setBaseItemLabelFont(font16, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(xYToolTipGenerator12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Paint paint5 = xYBarRenderer3.getBasePaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer3.setSeriesItemLabelPaint(1, paint7);
        legendTitle1.setBackgroundPaint(paint7);
        org.jfree.chart.block.BlockContainer blockContainer10 = legendTitle1.getWrapper();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor11);
        double double13 = legendTitle1.getHeight();
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        legendTitle1.setVerticalAlignment(verticalAlignment14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource18 = null;
        chartRenderingInfo17.setRenderingSource(renderingSource18);
        java.awt.geom.Rectangle2D rectangle2D20 = chartRenderingInfo17.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo17.getChartArea();
        try {
            legendTitle1.draw(graphics2D16, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(blockContainer10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter2 = xYBarRenderer0.getBarPainter();
        java.awt.Shape shape8 = null;
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color19 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape8, false, paint10, false, (java.awt.Paint) color12, stroke13, true, shape15, stroke16, (java.awt.Paint) color19);
        java.awt.Paint paint21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem20.setLabelPaint(paint21);
        xYBarRenderer0.setBasePaint(paint21, false);
        org.jfree.chart.LegendItem legendItem27 = xYBarRenderer0.getLegendItem(9999, 12);
        xYBarRenderer0.setBarAlignmentFactor(0.0d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYBarPainter2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(legendItem27);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo3);
        org.jfree.chart.entity.EntityCollection entityCollection5 = state4.getEntityCollection();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState6 = state4.getSelectionState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo7);
        org.jfree.chart.entity.EntityCollection entityCollection9 = state8.getEntityCollection();
        java.awt.geom.Line2D line2D10 = state8.workingLine;
        state4.workingLine = line2D10;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis12.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource15 = null;
        chartRenderingInfo14.setRenderingSource(renderingSource15);
        java.awt.geom.Rectangle2D rectangle2D17 = chartRenderingInfo14.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets13.createInsetRectangle(rectangle2D17, false, false);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D17);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis22);
        java.lang.String[] strArray25 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis26 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray25);
        int int27 = symbolAxis26.getMinorTickCount();
        java.lang.String[] strArray29 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis30 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray29);
        java.lang.Object obj31 = symbolAxis30.clone();
        org.jfree.data.RangeType rangeType32 = org.jfree.data.RangeType.POSITIVE;
        java.lang.Object obj33 = null;
        boolean boolean34 = rangeType32.equals(obj33);
        symbolAxis30.setRangeType(rangeType32);
        java.lang.Object obj36 = null;
        boolean boolean37 = symbolAxis30.equals(obj36);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit39 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        java.lang.String str41 = numberTickUnit39.valueToString((double) 100L);
        symbolAxis30.setTickUnit(numberTickUnit39, false, false);
        symbolAxis30.setAutoRangeIncludesZero(false);
        org.jfree.data.time.TimeSeries timeSeries47 = null;
        java.util.TimeZone timeZone48 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection(timeSeries47, timeZone48);
        org.jfree.data.Range range50 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        org.jfree.data.Range range52 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection49, true);
        org.jfree.data.general.DatasetGroup datasetGroup53 = timeSeriesCollection49.getGroup();
        boolean boolean54 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        try {
            xYStepAreaRenderer1.drawItem(graphics2D2, (org.jfree.chart.renderer.xy.XYItemRendererState) state4, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot23, (org.jfree.chart.axis.ValueAxis) symbolAxis26, (org.jfree.chart.axis.ValueAxis) symbolAxis30, (org.jfree.data.xy.XYDataset) timeSeriesCollection49, 3, (-1), false, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (3).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(entityCollection5);
        org.junit.Assert.assertNull(xYDatasetSelectionState6);
        org.junit.Assert.assertNull(entityCollection9);
        org.junit.Assert.assertNotNull(line2D10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(rangeType32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "100" + "'", str41.equals("100"));
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNotNull(datasetGroup53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color16 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape5, false, paint7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color16);
        java.awt.Paint paint18 = legendItem17.getOutlinePaint();
        boolean boolean19 = legendItem17.isShapeFilled();
        java.awt.Paint paint20 = legendItem17.getFillPaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer21 = legendItem17.getFillPaintTransformer();
        java.awt.Paint paint22 = legendItem17.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(gradientPaintTransformer21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        java.lang.String str2 = color1.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str2.equals("java.awt.Color[r=0,g=0,b=0]"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.addChangeListener(plotChangeListener3);
        org.jfree.data.general.PieDataset pieDataset5 = piePlot1.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1), 12.0d, (double) '#', (double) 1577894400005L);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource14 = null;
        chartRenderingInfo13.setRenderingSource(renderingSource14);
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo13.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets12.createInsetRectangle(rectangle2D16, false, false);
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets10.createInsetRectangle(rectangle2D16, false, true);
        piePlot1.setInsets(rectangleInsets10, true);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType25 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType25, 5);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType28 = dateTickUnit27.getUnitType();
        int int29 = dateTickUnit27.getCalendarField();
        int int30 = dateTickUnit27.getMultiple();
        java.awt.Stroke stroke31 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) int30, stroke31);
        piePlot1.setBackgroundAlpha((float) 432000000L);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(dateTickUnitType25);
        org.junit.Assert.assertNotNull(dateTickUnitType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 5 + "'", int30 == 5);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        java.lang.Object obj1 = xYSeriesCollection0.clone();
        xYSeriesCollection0.removeAllSeries();
        try {
            java.lang.Number number5 = xYSeriesCollection0.getEndY((-1), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("RectangleConstraintType.RANGE", (int) '4', 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer1.setShadowYOffset((double) 0L);
        xYBarRenderer1.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer1.setBaseOutlinePaint((java.awt.Paint) color8);
        boolean boolean10 = standardXYToolTipGenerator0.equals((java.lang.Object) xYBarRenderer1);
        boolean boolean11 = xYBarRenderer1.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number3 = xYDataItem2.getX();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset7.removeSeries((java.lang.Comparable) 'a');
        timeSeries6.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset7);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint13 = xYBarRenderer12.getBaseOutlinePaint();
        java.awt.Shape shape19 = null;
        java.awt.Paint paint21 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color23 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape26 = null;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color30 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape19, false, paint21, false, (java.awt.Paint) color23, stroke24, true, shape26, stroke27, (java.awt.Paint) color30);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker(0.0d, paint13, stroke27);
        boolean boolean33 = defaultXYDataset7.equals((java.lang.Object) valueMarker32);
        try {
            double double36 = defaultXYDataset7.getYValue(15, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("NOID", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = xYBarRenderer0.getBaseToolTipGenerator();
        xYBarRenderer0.setSeriesItemLabelsVisible(100, (java.lang.Boolean) false, false);
        xYBarRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition19);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(xYToolTipGenerator12);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource5 = null;
        chartRenderingInfo4.setRenderingSource(renderingSource5);
        java.awt.geom.Rectangle2D rectangle2D7 = chartRenderingInfo4.getChartArea();
        org.jfree.chart.axis.AxisState axisState8 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        axisState8.moveCursor((double) 0, rectangleEdge10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState8.moveCursor((double) 100L, rectangleEdge13);
        double double15 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor1, 10, (int) (short) 0, rectangle2D7, rectangleEdge13);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D7, "86,400,000", "100");
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Paint paint5 = xYBarRenderer3.getBasePaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer3.setSeriesItemLabelPaint(1, paint7);
        legendTitle1.setBackgroundPaint(paint7);
        org.jfree.chart.block.BlockContainer blockContainer10 = legendTitle1.getWrapper();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent12 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(blockContainer10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        boolean boolean12 = combinedDomainXYPlot1.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint15 = xYBarRenderer14.getBaseOutlinePaint();
        java.awt.Shape shape21 = null;
        java.awt.Paint paint23 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape28 = null;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color32 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape21, false, paint23, false, (java.awt.Paint) color25, stroke26, true, shape28, stroke29, (java.awt.Paint) color32);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(0.0d, paint15, stroke29);
        double double35 = valueMarker34.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType36 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo(entityCollection37);
        boolean boolean39 = chartChangeEventType36.equals((java.lang.Object) entityCollection37);
        java.lang.String str40 = chartChangeEventType36.toString();
        boolean boolean41 = valueMarker34.equals((java.lang.Object) chartChangeEventType36);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer44 = null;
        org.jfree.chart.plot.PolarPlot polarPlot45 = new org.jfree.chart.plot.PolarPlot(xYDataset42, valueAxis43, polarItemRenderer44);
        polarPlot45.setNoDataMessage("ThreadContext");
        java.awt.Paint paint48 = polarPlot45.getRadiusGridlinePaint();
        valueMarker34.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot45);
        boolean boolean50 = combinedDomainXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker34);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer51 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint52 = xYBarRenderer51.getBaseItemLabelPaint();
        boolean boolean56 = xYBarRenderer51.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator58 = null;
        xYBarRenderer51.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator58);
        java.awt.Shape shape61 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer51.setBaseLegendShape(shape61);
        java.lang.Boolean boolean64 = xYBarRenderer51.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation65 = null;
        boolean boolean66 = xYBarRenderer51.removeAnnotation(xYAnnotation65);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer67 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint68 = xYBarRenderer67.getBaseOutlinePaint();
        xYBarRenderer51.setBaseOutlinePaint(paint68, true);
        org.jfree.chart.LegendItemCollection legendItemCollection71 = xYBarRenderer51.getLegendItems();
        double double72 = xYBarRenderer51.getBase();
        int int73 = combinedDomainXYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer51);
        boolean boolean74 = combinedDomainXYPlot1.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str40.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNull(boolean64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(legendItemCollection71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        boolean boolean10 = intervalXYDelegate9.isAutoWidth();
        try {
            double double13 = intervalXYDelegate9.getEndXValue((int) (short) 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMinimumArcAngleToDraw((double) 100L);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset4 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.xy.XYDataItem xYDataItem7 = new org.jfree.data.xy.XYDataItem((double) (short) 100, (double) (-1));
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset4, (java.lang.Comparable) (short) 100, (double) 2.0f, 1);
        defaultPieDataset4.setValue((java.lang.Comparable) "RectangleAnchor.BOTTOM", 2.0d);
        piePlot1.setDataset((org.jfree.data.general.PieDataset) defaultPieDataset4);
        org.junit.Assert.assertNotNull(pieDataset10);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 5);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType3 = dateTickUnit2.getUnitType();
        int int4 = dateTickUnit2.getCalendarField();
        java.lang.String str6 = dateTickUnit2.valueToString(0.0d);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers((int) '4', layer10);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries13 = null;
        java.util.TimeZone timeZone14 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries13, timeZone14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15, true);
        org.jfree.data.Range range19 = xYBarRenderer12.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot8, (org.jfree.data.general.Dataset) timeSeriesCollection15);
        java.awt.Stroke stroke21 = categoryPlot8.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot8.getRangeAxisLocation();
        boolean boolean23 = pieLabelLinkStyle7.equals((java.lang.Object) categoryPlot8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot8.panDomainAxes((double) 28, plotRenderingInfo25, point2D26);
        boolean boolean28 = dateTickUnit2.equals((java.lang.Object) categoryPlot8);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot8.getDomainAxis();
        java.awt.Shape shape35 = null;
        java.awt.Paint paint37 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color39 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape42 = null;
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color46 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape35, false, paint37, false, (java.awt.Paint) color39, stroke40, true, shape42, stroke43, (java.awt.Paint) color46);
        categoryPlot8.setRangeCrosshairPaint((java.awt.Paint) color39);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 11 + "'", int4 == 11);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "12/31/69" + "'", str6.equals("12/31/69"));
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color46);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color16 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape5, false, paint7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color16);
        java.awt.Paint paint18 = legendItem17.getOutlinePaint();
        boolean boolean19 = legendItem17.isShapeFilled();
        java.awt.Paint paint20 = legendItem17.getFillPaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer21 = legendItem17.getFillPaintTransformer();
        java.awt.Stroke stroke22 = legendItem17.getLineStroke();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(gradientPaintTransformer21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        boolean boolean5 = timeSeries3.isEmpty();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.util.Date date7 = month6.getStart();
        long long8 = month6.getSerialIndex();
        org.jfree.data.time.Year year9 = month6.getYear();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setRangeMinorGridlinesVisible(false);
        boolean boolean13 = year9.equals((java.lang.Object) categoryPlot10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ThreadContext" + "'", str4.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24234L + "'", long8 == 24234L);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number3 = xYDataItem2.getX();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset7.removeSeries((java.lang.Comparable) 'a');
        timeSeries6.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset7);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint13 = xYBarRenderer12.getBaseOutlinePaint();
        java.awt.Shape shape19 = null;
        java.awt.Paint paint21 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color23 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape26 = null;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color30 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape19, false, paint21, false, (java.awt.Paint) color23, stroke24, true, shape26, stroke27, (java.awt.Paint) color30);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker(0.0d, paint13, stroke27);
        boolean boolean33 = defaultXYDataset7.equals((java.lang.Object) valueMarker32);
        try {
            double double36 = defaultXYDataset7.getYValue((int) (short) 100, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        double double5 = categoryAxis0.getUpperMargin();
        java.awt.Paint paint6 = categoryAxis0.getLabelPaint();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType7 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType7, 5);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType10 = dateTickUnit9.getUnitType();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.util.Date date12 = month11.getStart();
        org.jfree.data.time.TimeSeries timeSeries13 = null;
        java.util.TimeZone timeZone14 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries13, timeZone14);
        java.util.Date date16 = dateTickUnit9.addToDate(date12, timeZone14);
        java.lang.String str17 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) dateTickUnit9);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource23 = null;
        chartRenderingInfo22.setRenderingSource(renderingSource23);
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo22.getChartArea();
        org.jfree.chart.axis.AxisState axisState26 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        axisState26.moveCursor((double) 0, rectangleEdge28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState26.moveCursor((double) 100L, rectangleEdge31);
        double double33 = categoryAxis18.getCategoryJava2DCoordinate(categoryAnchor19, 10, (int) (short) 0, rectangle2D25, rectangleEdge31);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double36 = rectangleInsets34.calculateRightInset(0.0d);
        categoryAxis18.setLabelInsets(rectangleInsets34, false);
        categoryAxis0.setLabelInsets(rectangleInsets34);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(dateTickUnitType7);
        org.junit.Assert.assertNotNull(dateTickUnitType10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 4.0d + "'", double36 == 4.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        java.awt.Paint paint6 = categoryAxis1.getAxisLinePaint();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(2);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate11);
        java.lang.String str13 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) serialDate11);
        serialDate11.setDescription("{0}");
        try {
            org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) -1, serialDate11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        double double13 = rectangleInsets6.calculateRightInset((double) (short) 1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        org.jfree.data.Range range5 = null;
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, (double) 100);
        double double8 = range7.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range11 = null;
        org.jfree.data.Range range12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(range12, (double) 10.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) '4', range7, lengthConstraintType9, (double) 12, range11, lengthConstraintType15);
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude(range17, (double) 100);
        double double20 = range19.getLength();
        boolean boolean23 = range19.intersects((double) 4, (double) 0.0f);
        boolean boolean24 = range7.intersects(range19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = rectangleConstraint2.toRangeHeight(range19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint25.toUnconstrainedWidth();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        boolean boolean28 = chartChangeEventType25.equals((java.lang.Object) entityCollection26);
        java.lang.String str29 = chartChangeEventType25.toString();
        boolean boolean30 = valueMarker23.equals((java.lang.Object) chartChangeEventType25);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean33 = xYPlot0.removeRangeMarker(8, (org.jfree.chart.plot.Marker) valueMarker23, layer31, true);
        java.awt.Paint paint34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot0.setDomainTickBandPaint(paint34);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation36 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str29.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection2);
        java.lang.String str10 = rendererChangeEvent9.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rendererChangeEvent9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        chartChangeEvent11.setType(chartChangeEventType12);
        org.jfree.chart.JFreeChart jFreeChart14 = chartChangeEvent11.getChart();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertNull(jFreeChart14);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection28);
        boolean boolean30 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean32 = categoryPlot0.equals((java.lang.Object) textAnchor31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = null;
        try {
            categoryPlot0.setDomainAxisLocation(axisLocation33, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        java.awt.Paint paint6 = categoryAxis1.getAxisLinePaint();
        org.jfree.chart.entity.AxisEntity axisEntity8 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) categoryAxis1, "ChartChangeEventType.DATASET_UPDATED");
        java.lang.Object obj9 = axisEntity8.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint4.toUnconstrainedHeight();
        org.jfree.data.Range range6 = rectangleConstraint5.getWidthRange();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.PlotState plotState0 = new org.jfree.chart.plot.PlotState();
        java.util.Map map1 = plotState0.getSharedAxisStates();
        org.junit.Assert.assertNotNull(map1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        java.awt.Paint paint3 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection2);
        java.lang.String str10 = rendererChangeEvent9.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rendererChangeEvent9);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint16 = xYBarRenderer15.getBaseOutlinePaint();
        java.awt.Shape shape22 = null;
        java.awt.Paint paint24 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color26 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape29 = null;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color33 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape22, false, paint24, false, (java.awt.Paint) color26, stroke27, true, shape29, stroke30, (java.awt.Paint) color33);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(0.0d, paint16, stroke30);
        double double36 = valueMarker35.getValue();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean39 = categoryPlot12.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker35, layer37, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot12.getDomainAxisEdge();
        double double41 = categoryPlot12.getRangeCrosshairValue();
        double double42 = categoryPlot12.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        categoryPlot12.setRangeAxis(1, valueAxis44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        categoryPlot12.panRangeAxes((double) 3, plotRenderingInfo47, point2D48);
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot12);
        java.awt.Paint paint51 = jFreeChart50.getBorderPaint();
        boolean boolean52 = jFreeChart50.isBorderVisible();
        rendererChangeEvent9.setChart(jFreeChart50);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = jFreeChart50.getPadding();
        java.awt.Image image55 = jFreeChart50.getBackgroundImage();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNull(image55);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 100);
        boolean boolean4 = strokeMap0.equals((java.lang.Object) range3);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        java.lang.Comparable comparable3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeriesCollection2.getSeries(comparable3);
        timeSeriesCollection2.removeAllSeries();
        try {
            boolean boolean8 = timeSeriesCollection2.isSelected(0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(timeSeries4);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.data.time.TimeSeries timeSeries3 = null;
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3, timeZone4);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        timeSeriesCollection5.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection5);
        java.lang.String str13 = rendererChangeEvent12.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rendererChangeEvent12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint19 = xYBarRenderer18.getBaseOutlinePaint();
        java.awt.Shape shape25 = null;
        java.awt.Paint paint27 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color29 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape32 = null;
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color36 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape25, false, paint27, false, (java.awt.Paint) color29, stroke30, true, shape32, stroke33, (java.awt.Paint) color36);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker(0.0d, paint19, stroke33);
        double double39 = valueMarker38.getValue();
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean42 = categoryPlot15.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker38, layer40, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot15.getDomainAxisEdge();
        double double44 = categoryPlot15.getRangeCrosshairValue();
        double double45 = categoryPlot15.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        categoryPlot15.setRangeAxis(1, valueAxis47);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        java.awt.geom.Point2D point2D51 = null;
        categoryPlot15.panRangeAxes((double) 3, plotRenderingInfo50, point2D51);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot15);
        java.awt.Paint paint54 = jFreeChart53.getBorderPaint();
        boolean boolean55 = jFreeChart53.isBorderVisible();
        rendererChangeEvent12.setChart(jFreeChart53);
        org.jfree.chart.JFreeChart jFreeChart57 = rendererChangeEvent12.getChart();
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart57);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(jFreeChart57);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        java.lang.String str12 = combinedDomainXYPlot1.getPlotType();
        java.lang.String[] strArray14 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis15 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray14);
        java.lang.Object obj16 = symbolAxis15.clone();
        symbolAxis15.setRangeWithMargins(0.05d, (double) 1560495599999L);
        combinedDomainXYPlot1.setRangeAxis((org.jfree.chart.axis.ValueAxis) symbolAxis15);
        java.awt.Paint paint21 = combinedDomainXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation22 = null;
        try {
            combinedDomainXYPlot1.addAnnotation(xYAnnotation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Combined_Domain_XYPlot" + "'", str12.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        polarPlot7.setDrawingSupplier(drawingSupplier9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setTickMarksVisible(false);
        categoryAxis12.configure();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource23 = null;
        chartRenderingInfo22.setRenderingSource(renderingSource23);
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo22.getChartArea();
        org.jfree.chart.axis.AxisState axisState26 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        axisState26.moveCursor((double) 0, rectangleEdge28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState26.moveCursor((double) 100L, rectangleEdge31);
        double double33 = categoryAxis18.getCategoryJava2DCoordinate(categoryAnchor19, 10, (int) (short) 0, rectangle2D25, rectangleEdge31);
        org.jfree.chart.axis.AxisState axisState34 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        axisState34.moveCursor((double) 0, rectangleEdge36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState34.moveCursor((double) 100L, rectangleEdge39);
        axisState34.setCursor((double) 3);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer47 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint48 = xYBarRenderer47.getBaseOutlinePaint();
        java.awt.Shape shape54 = null;
        java.awt.Paint paint56 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color58 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape61 = null;
        java.awt.Stroke stroke62 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color65 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem66 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape54, false, paint56, false, (java.awt.Paint) color58, stroke59, true, shape61, stroke62, (java.awt.Paint) color65);
        org.jfree.chart.plot.ValueMarker valueMarker67 = new org.jfree.chart.plot.ValueMarker(0.0d, paint48, stroke62);
        double double68 = valueMarker67.getValue();
        org.jfree.chart.util.Layer layer69 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean71 = categoryPlot44.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker67, layer69, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = categoryPlot44.getDomainAxisEdge();
        axisState34.moveCursor(2.0d, rectangleEdge72);
        org.jfree.chart.axis.AxisState axisState74 = null;
        categoryAxis12.drawTickMarks(graphics2D16, (double) 9, rectangle2D25, rectangleEdge72, axisState74);
        try {
            polarPlot7.drawBackground(graphics2D11, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(layer69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(rectangleEdge72);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, true);
        org.jfree.data.Range range11 = xYBarRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot0, (org.jfree.data.general.Dataset) timeSeriesCollection7);
        java.awt.Stroke stroke13 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint20 = xYBarRenderer19.getBaseOutlinePaint();
        java.awt.Shape shape26 = null;
        java.awt.Paint paint28 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color30 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape33 = null;
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color37 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape26, false, paint28, false, (java.awt.Paint) color30, stroke31, true, shape33, stroke34, (java.awt.Paint) color37);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(0.0d, paint20, stroke34);
        double double40 = valueMarker39.getValue();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean43 = categoryPlot16.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker39, layer41, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot16.getDomainAxisEdge();
        double double45 = categoryPlot16.getRangeCrosshairValue();
        double double46 = categoryPlot16.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        categoryPlot16.setRangeAxis(1, valueAxis48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        java.awt.geom.Point2D point2D52 = null;
        categoryPlot16.panRangeAxes((double) 3, plotRenderingInfo51, point2D52);
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener55 = null;
        jFreeChart54.addProgressListener(chartProgressListener55);
        java.awt.RenderingHints renderingHints57 = jFreeChart54.getRenderingHints();
        jFreeChart54.setBackgroundImageAlpha((float) '4');
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart54);
        org.jfree.chart.axis.AxisLocation axisLocation62 = categoryPlot0.getDomainAxisLocation(100);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(renderingHints57);
        org.junit.Assert.assertNotNull(axisLocation62);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8);
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot13.getRangeMarkers((int) '4', layer15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot13.setDomainAxis((int) (short) 0, categoryAxis18, true);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        categoryPlot13.setFixedRangeAxisSpace(axisSpace21);
        double double23 = categoryPlot13.getAnchorValue();
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot13.setRangeAxisLocation(axisLocation24);
        categoryPlot0.setRangeAxisLocation(0, axisLocation24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor28 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource32 = null;
        chartRenderingInfo31.setRenderingSource(renderingSource32);
        java.awt.geom.Rectangle2D rectangle2D34 = chartRenderingInfo31.getChartArea();
        org.jfree.chart.axis.AxisState axisState35 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        axisState35.moveCursor((double) 0, rectangleEdge37);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState35.moveCursor((double) 100L, rectangleEdge40);
        double double42 = categoryAxis27.getCategoryJava2DCoordinate(categoryAnchor28, 10, (int) (short) 0, rectangle2D34, rectangleEdge40);
        int int43 = categoryPlot0.getDomainAxisIndex(categoryAxis27);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int1 = numberTickUnit0.getMinorTickCount();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        java.awt.Font font3 = piePlot1.getLabelFont();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        piePlot1.setBackgroundImageAlignment(4);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        int int1 = dateTickUnitType0.getCalendarField();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.addChangeListener(plotChangeListener3);
        org.jfree.data.general.PieDataset pieDataset5 = piePlot1.getDataset();
        boolean boolean6 = piePlot1.getIgnoreZeroValues();
        piePlot1.setStartAngle((double) (byte) -1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-8355840) + "'", int1 == (-8355840));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        double double5 = categoryAxis0.getUpperMargin();
        java.awt.Paint paint6 = categoryAxis0.getLabelPaint();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType7 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType7, 5);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType10 = dateTickUnit9.getUnitType();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.util.Date date12 = month11.getStart();
        org.jfree.data.time.TimeSeries timeSeries13 = null;
        java.util.TimeZone timeZone14 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries13, timeZone14);
        java.util.Date date16 = dateTickUnit9.addToDate(date12, timeZone14);
        java.lang.String str17 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) dateTickUnit9);
        double double18 = categoryAxis0.getCategoryMargin();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(dateTickUnitType7);
        org.junit.Assert.assertNotNull(dateTickUnitType10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        java.lang.Number[][] numberArray5 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "ClassContext", numberArray5);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset6);
        multiplePiePlot1.setDataset(categoryDataset6);
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset6, 9999);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(pieDataset10);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.panRangeAxes((double) 3, plotRenderingInfo35, point2D36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener39 = null;
        jFreeChart38.addProgressListener(chartProgressListener39);
        java.awt.RenderingHints renderingHints41 = jFreeChart38.getRenderingHints();
        jFreeChart38.setBackgroundImageAlpha((float) '4');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection49 = null;
        chartRenderingInfo48.setEntityCollection(entityCollection49);
        chartRenderingInfo48.clear();
        try {
            java.awt.image.BufferedImage bufferedImage52 = jFreeChart38.createBufferedImage(0, (int) 'a', (double) (-57600001L), (double) 43629L, chartRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (97) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(renderingHints41);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer3D0.getSeriesItemLabelGenerator(15);
        java.awt.Shape shape8 = null;
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color19 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape8, false, paint10, false, (java.awt.Paint) color12, stroke13, true, shape15, stroke16, (java.awt.Paint) color19);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint22 = xYBarRenderer21.getBaseOutlinePaint();
        legendItem20.setLinePaint(paint22);
        boolean boolean24 = barRenderer3D0.equals((java.lang.Object) paint22);
        int int25 = barRenderer3D0.getColumnCount();
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        boolean boolean4 = segmentedTimeline0.containsDomainValue((long) (short) 0);
        boolean boolean5 = segmentedTimeline0.getAdjustForDaylightSaving();
        long long6 = segmentedTimeline0.getSegmentSize();
        long long7 = segmentedTimeline0.getSegmentsIncludedSize();
        boolean boolean9 = segmentedTimeline0.containsDomainValue(0L);
        long long11 = segmentedTimeline0.toTimelineValue(432000000L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86400000L + "'", long6 == 86400000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 432000000L + "'", long7 == 432000000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1578153600000L + "'", long11 == 1578153600000L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((double) 432000000L, (double) (-460));
        int int5 = defaultXYDataset0.indexOf((java.lang.Comparable) 432000000L);
        defaultXYDataset0.removeSeries((java.lang.Comparable) 4);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        defaultXYDataset0.removeSeries((java.lang.Comparable) "java.awt.Color[r=0,g=0,b=0]");
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, true);
        org.jfree.data.general.DatasetGroup datasetGroup6 = timeSeriesCollection2.getGroup();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        boolean boolean12 = polarPlot11.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        polarPlot11.datasetChanged(datasetChangeEvent13);
        java.awt.Font font15 = polarPlot11.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("DateTickUnitType.DAY", font15);
        boolean boolean17 = datasetGroup6.equals((java.lang.Object) font15);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(datasetGroup6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8);
        boolean boolean10 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot0.getRangeAxisForDataset(7);
        java.awt.Stroke stroke13 = categoryPlot0.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, true);
        org.jfree.data.Range range11 = xYBarRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot0, (org.jfree.data.general.Dataset) timeSeriesCollection7);
        java.awt.Stroke stroke13 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot0.getDrawingSupplier();
        java.awt.Stroke stroke16 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot0.zoomRangeAxes((-1.0d), (double) 28, plotRenderingInfo19, point2D20);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean2 = chartRenderingInfo0.equals((java.lang.Object) 0L);
        java.lang.Object obj3 = null;
        boolean boolean4 = chartRenderingInfo0.equals(obj3);
        org.jfree.chart.entity.EntityCollection entityCollection5 = null;
        chartRenderingInfo0.setEntityCollection(entityCollection5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        polarPlot3.datasetChanged(datasetChangeEvent5);
        java.awt.Font font7 = polarPlot3.getNoDataMessageFont();
        java.awt.Stroke stroke8 = polarPlot3.getRadiusGridlineStroke();
        polarPlot3.setRadiusGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number3 = xYDataItem2.getX();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset7.removeSeries((java.lang.Comparable) 'a');
        timeSeries6.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset7);
        java.lang.Object obj11 = timeSeries6.clone();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.createCopy(15, 64);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(timeSeries14);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isAngleLabelsVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis5.getTickLabelInsets();
        polarPlot3.setInsets(rectangleInsets6);
        double double9 = rectangleInsets6.calculateTopInset((double) (-460));
        double double10 = rectangleInsets6.getRight();
        java.lang.Class<?> wildcardClass11 = rectangleInsets6.getClass();
        boolean boolean12 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        long long3 = segment2.getSegmentStart();
        long long5 = segment2.calculateSegmentNumber((long) (short) 100);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-57600000L) + "'", long3 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 25566L + "'", long5 == 25566L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Stroke stroke3 = piePlot2.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot2.addChangeListener(plotChangeListener4);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator6 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        piePlot2.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator6);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset9, valueAxis10, polarItemRenderer11);
        float float13 = polarPlot12.getBackgroundImageAlpha();
        xYBarRenderer8.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot12);
        java.awt.Color color16 = java.awt.Color.orange;
        xYBarRenderer8.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color16);
        piePlot2.setOutlinePaint((java.awt.Paint) color16);
        java.awt.Color color19 = java.awt.Color.getColor("ChartChangeEventType.DATASET_UPDATED", color16);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getInstance();
        java.math.RoundingMode roundingMode1 = numberFormat0.getRoundingMode();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + roundingMode1 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode1.equals(java.math.RoundingMode.HALF_EVEN));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor3, textAnchor4, textAnchor5, (double) '#');
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.NumberTick numberTick10 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 12, "", textAnchor4, textAnchor8, (double) 1L);
        org.jfree.chart.axis.TickType tickType11 = numberTick10.getTickType();
        double double12 = numberTick10.getValue();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(tickType11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 12.0d + "'", double12 == 12.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getInfo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str1.equals("http://www.jfree.org/jfreechart/index.html"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((double) 432000000L, (double) (-460));
        double double5 = ringPlot0.getExplodePercent((java.lang.Comparable) (-460));
        ringPlot0.setOuterSeparatorExtension(100.0d);
        double double8 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray1);
        java.lang.Object obj3 = symbolAxis2.clone();
        java.awt.Shape shape4 = null;
        try {
            symbolAxis2.setDownArrow(shape4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = xYBarRenderer1.getBaseOutlinePaint();
        java.awt.Shape shape8 = null;
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color19 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape8, false, paint10, false, (java.awt.Paint) color12, stroke13, true, shape15, stroke16, (java.awt.Paint) color19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, paint2, stroke16);
        float float22 = valueMarker21.getAlpha();
        java.awt.Stroke stroke23 = valueMarker21.getStroke();
        java.awt.Paint paint24 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        boolean boolean25 = valueMarker21.equals((java.lang.Object) paint24);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint27 = xYBarRenderer26.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter28 = xYBarRenderer26.getBarPainter();
        java.awt.Color color29 = java.awt.Color.lightGray;
        xYBarRenderer26.setBaseLegendTextPaint((java.awt.Paint) color29);
        valueMarker21.setOutlinePaint((java.awt.Paint) color29);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(xYBarPainter28);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator2);
        java.awt.Paint paint4 = piePlot1.getLabelOutlinePaint();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_BLUE;
        piePlot1.setNoDataMessagePaint((java.awt.Paint) color5);
        piePlot1.setLabelGap((double) 2147483647);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarksVisible(false);
        categoryAxis0.configure();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource11 = null;
        chartRenderingInfo10.setRenderingSource(renderingSource11);
        java.awt.geom.Rectangle2D rectangle2D13 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.axis.AxisState axisState14 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        axisState14.moveCursor((double) 0, rectangleEdge16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState14.moveCursor((double) 100L, rectangleEdge19);
        double double21 = categoryAxis6.getCategoryJava2DCoordinate(categoryAnchor7, 10, (int) (short) 0, rectangle2D13, rectangleEdge19);
        org.jfree.chart.axis.AxisState axisState22 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        axisState22.moveCursor((double) 0, rectangleEdge24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState22.moveCursor((double) 100L, rectangleEdge27);
        axisState22.setCursor((double) 3);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer35 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint36 = xYBarRenderer35.getBaseOutlinePaint();
        java.awt.Shape shape42 = null;
        java.awt.Paint paint44 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color46 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape49 = null;
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color53 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem54 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape42, false, paint44, false, (java.awt.Paint) color46, stroke47, true, shape49, stroke50, (java.awt.Paint) color53);
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker(0.0d, paint36, stroke50);
        double double56 = valueMarker55.getValue();
        org.jfree.chart.util.Layer layer57 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean59 = categoryPlot32.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker55, layer57, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = categoryPlot32.getDomainAxisEdge();
        axisState22.moveCursor(2.0d, rectangleEdge60);
        org.jfree.chart.axis.AxisState axisState62 = null;
        categoryAxis0.drawTickMarks(graphics2D4, (double) 9, rectangle2D13, rectangleEdge60, axisState62);
        java.lang.String[] strArray65 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis66 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray65);
        java.lang.Object obj67 = symbolAxis66.clone();
        symbolAxis66.setRangeWithMargins(0.05d, (double) 1560495599999L);
        org.jfree.chart.entity.AxisEntity axisEntity73 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D13, (org.jfree.chart.axis.Axis) symbolAxis66, "HorizontalAlignment.CENTER", "Range[100.0,100.0]");
        java.text.NumberFormat numberFormat74 = symbolAxis66.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(layer57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNotNull(strArray65);
        org.junit.Assert.assertNotNull(obj67);
        org.junit.Assert.assertNull(numberFormat74);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getStart();
        java.util.Date date6 = month4.getEnd();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (double) (-57600001L));
        org.jfree.data.xy.XYDataItem xYDataItem11 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number12 = xYDataItem11.getX();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem11, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset16.removeSeries((java.lang.Comparable) 'a');
        timeSeries15.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset16);
        org.jfree.data.time.TimeSeries timeSeries20 = null;
        java.util.TimeZone timeZone21 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeSeries20, timeZone21);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection22);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection22, true);
        timeSeries15.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection22);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        java.util.Date date28 = month27.getStart();
        long long29 = month27.getSerialIndex();
        org.jfree.data.time.Year year30 = month27.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 0.05d, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 12);
        long long36 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0d + "'", number12.equals(100.0d));
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 24234L + "'", long29 == 24234L);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        double double3 = xYDataItem2.getYValue();
        xYDataItem2.setSelected(false);
        java.lang.String str6 = xYDataItem2.toString();
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude(range8, (double) 100);
        double double11 = range10.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range14 = null;
        org.jfree.data.Range range15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint(range15, (double) 10.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = rectangleConstraint17.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((double) '4', range10, lengthConstraintType12, (double) 12, range14, lengthConstraintType18);
        org.jfree.data.Range range20 = null;
        org.jfree.data.Range range22 = org.jfree.data.Range.expandToInclude(range20, (double) 100);
        double double23 = range22.getLength();
        boolean boolean26 = range22.intersects((double) 4, (double) 0.0f);
        boolean boolean27 = range10.intersects(range22);
        boolean boolean28 = xYDataItem2.equals((java.lang.Object) boolean27);
        java.lang.Number number29 = xYDataItem2.getX();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[100.0, 12.0]" + "'", str6.equals("[100.0, 12.0]"));
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertNotNull(lengthConstraintType18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 100.0d + "'", number29.equals(100.0d));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        boolean boolean10 = intervalXYDelegate9.isAutoWidth();
        intervalXYDelegate9.setIntervalPositionFactor(0.0d);
        double double13 = intervalXYDelegate9.getIntervalPositionFactor();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getInfo();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        combinedDomainXYPlot1.setDomainMinorGridlinesVisible(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.awt.Stroke stroke9 = piePlot8.getLabelLinkStroke();
        java.awt.Font font10 = piePlot8.getLabelFont();
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("PlotOrientation.HORIZONTAL", font10, paint11);
        combinedDomainXYPlot1.setRangeTickBandPaint(paint11);
        boolean boolean14 = combinedDomainXYPlot1.isRangeCrosshairVisible();
        java.awt.Paint paint15 = combinedDomainXYPlot1.getRangeMinorGridlinePaint();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 11, 12, 500);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ClassContext", "UnitType.ABSOLUTE");
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource11 = null;
        chartRenderingInfo10.setRenderingSource(renderingSource11);
        java.awt.geom.Rectangle2D rectangle2D13 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.axis.AxisState axisState14 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        axisState14.moveCursor((double) 0, rectangleEdge16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState14.moveCursor((double) 100L, rectangleEdge19);
        double double21 = categoryAxis6.getCategoryJava2DCoordinate(categoryAnchor7, 10, (int) (short) 0, rectangle2D13, rectangleEdge19);
        org.jfree.chart.axis.AxisState axisState22 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        axisState22.moveCursor((double) 0, rectangleEdge24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState22.moveCursor((double) 100L, rectangleEdge27);
        axisState22.setCursor((double) 3);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer35 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint36 = xYBarRenderer35.getBaseOutlinePaint();
        java.awt.Shape shape42 = null;
        java.awt.Paint paint44 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color46 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape49 = null;
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color53 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem54 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape42, false, paint44, false, (java.awt.Paint) color46, stroke47, true, shape49, stroke50, (java.awt.Paint) color53);
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker(0.0d, paint36, stroke50);
        double double56 = valueMarker55.getValue();
        org.jfree.chart.util.Layer layer57 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean59 = categoryPlot32.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker55, layer57, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = categoryPlot32.getDomainAxisEdge();
        axisState22.moveCursor(2.0d, rectangleEdge60);
        try {
            gradientBarPainter0.paintBarShadow(graphics2D1, barRenderer2, (int) '4', 100, true, (java.awt.geom.RectangularShape) rectangle2D13, rectangleEdge60, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(layer57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleEdge60);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = xYBarRenderer2.getBaseItemLabelPaint();
        piePlot1.setLabelPaint(paint3);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator5);
        piePlot1.setAutoPopulateSectionOutlineStroke(true);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        long long3 = segment2.getSegmentCount();
        boolean boolean4 = segment2.inExceptionSegments();
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) segment2, false);
        org.jfree.data.time.TimeSeries timeSeries7 = null;
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeSeries7, timeZone8);
        java.lang.Comparable comparable10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeriesCollection9.getSeries(comparable10);
        xYSeries6.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection9);
        try {
            int[] intArray16 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) timeSeriesCollection9, 0, 0.05d, 4.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(timeSeries11);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Stroke stroke5 = xYBarRenderer1.getItemStroke((int) 'a', (int) '#', true);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset6, valueAxis7, polarItemRenderer8);
        polarPlot9.setNoDataMessage("ThreadContext");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        polarPlot9.setRenderer(polarItemRenderer12);
        boolean boolean14 = xYBarRenderer1.hasListener((java.util.EventListener) polarPlot9);
        polarPlot9.setAngleLabelsVisible(false);
        java.awt.Paint paint17 = polarPlot9.getAngleLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("Range[100.0,100.0]", (org.jfree.chart.plot.Plot) polarPlot9);
        java.util.List list19 = null;
        try {
            jFreeChart18.setSubtitles(list19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 1, true, true);
        xYSeries3.add((double) 0L, (double) (short) -1);
        org.jfree.data.xy.XYDataItem xYDataItem7 = null;
        try {
            xYSeries3.add(xYDataItem7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 5);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.Range range2 = null;
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range2, (double) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) 1577894400005L, range4);
        boolean boolean6 = defaultPieDataset0.equals((java.lang.Object) rectangleConstraint5);
        org.jfree.chart.util.SortOrder sortOrder7 = null;
        try {
            defaultPieDataset0.sortByKeys(sortOrder7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace6 = combinedDomainXYPlot1.getFixedRangeAxisSpace();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot7.getRangeMarkers((int) '4', layer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot7.setDomainAxis((int) (short) 0, categoryAxis12, true);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot7.setFixedRangeAxisSpace(axisSpace15);
        double double17 = categoryPlot7.getAnchorValue();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot7.setRangeAxisLocation(axisLocation18);
        combinedDomainXYPlot1.setRangeAxisLocation(axisLocation18, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint29 = xYBarRenderer28.getBaseOutlinePaint();
        java.awt.Shape shape35 = null;
        java.awt.Paint paint37 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color39 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape42 = null;
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color46 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape35, false, paint37, false, (java.awt.Paint) color39, stroke40, true, shape42, stroke43, (java.awt.Paint) color46);
        org.jfree.chart.plot.ValueMarker valueMarker48 = new org.jfree.chart.plot.ValueMarker(0.0d, paint29, stroke43);
        double double49 = valueMarker48.getValue();
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean52 = categoryPlot25.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker48, layer50, false);
        org.jfree.chart.LegendItemCollection legendItemCollection53 = null;
        categoryPlot25.setFixedLegendItems(legendItemCollection53);
        categoryPlot25.clearRangeMarkers(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D60 = xYPlot59.getQuadrantOrigin();
        categoryPlot25.zoomRangeAxes((double) 43629L, plotRenderingInfo58, point2D60);
        try {
            combinedDomainXYPlot1.zoomRangeAxes(0.05d, (double) 86400000L, plotRenderingInfo24, point2D60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(point2D60);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 9999);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
//        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
//        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
//        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
//        java.awt.Shape shape14 = null;
//        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
//        java.awt.Color color18 = java.awt.Color.YELLOW;
//        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        java.awt.Shape shape21 = null;
//        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        java.awt.Color color25 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
//        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape14, false, paint16, false, (java.awt.Paint) color18, stroke19, true, shape21, stroke22, (java.awt.Paint) color25);
//        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
//        legendItem26.setLabelPaint(paint27);
//        xYBarRenderer0.setBaseLegendTextPaint(paint27);
//        java.awt.Stroke stroke31 = xYBarRenderer0.lookupSeriesOutlineStroke((int) (byte) 100);
//        xYBarRenderer0.setSeriesItemLabelsVisible(10, (java.lang.Boolean) false);
//        java.lang.Boolean boolean36 = xYBarRenderer0.getSeriesVisibleInLegend((int) '#');
//        java.awt.Font font38 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
//        xYBarRenderer0.setLegendTextFont(28, font38);
//        boolean boolean40 = xYBarRenderer0.getShadowsVisible();
//        org.junit.Assert.assertNotNull(paint1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(paint16);
//        org.junit.Assert.assertNotNull(color18);
//        org.junit.Assert.assertNotNull(stroke19);
//        org.junit.Assert.assertNotNull(stroke22);
//        org.junit.Assert.assertNotNull(color25);
//        org.junit.Assert.assertNotNull(paint27);
//        org.junit.Assert.assertNotNull(stroke31);
//        org.junit.Assert.assertNull(boolean36);
//        org.junit.Assert.assertNotNull(font38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        polarPlot3.datasetChanged(datasetChangeEvent5);
        java.awt.Font font7 = polarPlot3.getNoDataMessageFont();
        java.awt.Stroke stroke8 = polarPlot3.getRadiusGridlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        combinedDomainXYPlot10.setRangeCrosshairValue(0.0d);
        combinedDomainXYPlot10.setDomainMinorGridlinesVisible(true);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        java.awt.Stroke stroke18 = piePlot17.getLabelLinkStroke();
        java.awt.Font font19 = piePlot17.getLabelFont();
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("PlotOrientation.HORIZONTAL", font19, paint20);
        combinedDomainXYPlot10.setRangeTickBandPaint(paint20);
        polarPlot3.setAngleLabelPaint(paint20);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis12);
        combinedDomainXYPlot13.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = combinedDomainXYPlot13.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = combinedDomainXYPlot13.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double20 = rectangleInsets18.calculateRightInset(0.0d);
        double double22 = rectangleInsets18.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot13.setAxisOffset(rectangleInsets18);
        boolean boolean24 = combinedDomainXYPlot13.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint27 = xYBarRenderer26.getBaseOutlinePaint();
        java.awt.Shape shape33 = null;
        java.awt.Paint paint35 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color37 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape40 = null;
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color44 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape33, false, paint35, false, (java.awt.Paint) color37, stroke38, true, shape40, stroke41, (java.awt.Paint) color44);
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker(0.0d, paint27, stroke41);
        double double47 = valueMarker46.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType48 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection49 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo(entityCollection49);
        boolean boolean51 = chartChangeEventType48.equals((java.lang.Object) entityCollection49);
        java.lang.String str52 = chartChangeEventType48.toString();
        boolean boolean53 = valueMarker46.equals((java.lang.Object) chartChangeEventType48);
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer56 = null;
        org.jfree.chart.plot.PolarPlot polarPlot57 = new org.jfree.chart.plot.PolarPlot(xYDataset54, valueAxis55, polarItemRenderer56);
        polarPlot57.setNoDataMessage("ThreadContext");
        java.awt.Paint paint60 = polarPlot57.getRadiusGridlinePaint();
        valueMarker46.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot57);
        boolean boolean62 = combinedDomainXYPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker46);
        org.jfree.chart.util.Layer layer63 = null;
        boolean boolean64 = categoryPlot0.removeRangeMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker46, layer63);
        org.jfree.chart.plot.Plot plot65 = categoryPlot0.getParent();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str52.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNull(plot65);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-57600000L), 1.0d);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint5 = xYBarRenderer4.getBaseOutlinePaint();
        java.awt.Shape shape11 = null;
        java.awt.Paint paint13 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color15 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape18 = null;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color22 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape11, false, paint13, false, (java.awt.Paint) color15, stroke16, true, shape18, stroke19, (java.awt.Paint) color22);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(0.0d, paint5, stroke19);
        double double25 = valueMarker24.getValue();
        valueMarker24.setLabel("");
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker24);
        intervalMarker2.notifyListeners(markerChangeEvent28);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone1;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1);
        long long4 = month3.getSerialIndex();
        int int5 = month3.getYearValue();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter2 = xYBarRenderer0.getBarPainter();
        java.awt.Color color3 = java.awt.Color.lightGray;
        xYBarRenderer0.setBaseLegendTextPaint((java.awt.Paint) color3);
        java.awt.Paint paint5 = null;
        xYBarRenderer0.setBaseLegendTextPaint(paint5);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(xYBarPainter2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        double double2 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        try {
            double double5 = timeSeriesCollection2.getEndXValue((-9999), 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(500);
        org.jfree.data.time.SerialDate serialDate8 = serialDate5.getEndOfCurrentMonth(serialDate7);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        logAxis0.centerRange((double) 8);
        logAxis0.setTickMarkInsideLength(2.0f);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 1, true, true);
        java.lang.Number number5 = null;
        xYSeries3.add((java.lang.Number) (byte) -1, number5);
        int int8 = xYSeries3.indexOf((java.lang.Number) (byte) 1);
        int int9 = xYSeries3.getMaximumItemCount();
        try {
            xYSeries3.update((java.lang.Number) 9223372036854775807L, (java.lang.Number) (-8355840));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: No observation for x = 9223372036854775807");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-2) + "'", int8 == (-2));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarksVisible(false);
        java.awt.Font font4 = categoryAxis1.getTickLabelFont();
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor(0, 4, (int) '4');
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) chartColor8, (float) (byte) 100, 100, textMeasurer11);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset14, valueAxis15, polarItemRenderer16);
        java.awt.Font font18 = polarPlot17.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("ChartChangeEventType.DATASET_UPDATED", font18);
        org.jfree.chart.text.TextFragment textFragment20 = textLine19.getFirstTextFragment();
        textBlock12.addLine(textLine19);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline22 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment24 = segmentedTimeline22.getSegment((long) (short) 100);
        long long25 = segment24.getSegmentCount();
        long long26 = segment24.getSegmentCount();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline27 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment29 = segmentedTimeline27.getSegment((long) (short) 100);
        long long30 = segment29.getSegmentCount();
        segment29.dec();
        boolean boolean32 = segment24.contains(segment29);
        long long33 = segment29.getSegmentEnd();
        boolean boolean34 = textLine19.equals((java.lang.Object) long33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state36 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo35);
        org.jfree.chart.entity.EntityCollection entityCollection37 = state36.getEntityCollection();
        java.awt.geom.Line2D line2D38 = state36.workingLine;
        org.jfree.data.time.TimeSeries timeSeries39 = null;
        java.util.TimeZone timeZone40 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection41 = new org.jfree.data.time.TimeSeriesCollection(timeSeries39, timeZone40);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection41);
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot(xYDataset43, valueAxis44, polarItemRenderer45);
        timeSeriesCollection41.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot46);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier48 = null;
        polarPlot46.setDrawingSupplier(drawingSupplier48);
        org.jfree.chart.event.PlotChangeListener plotChangeListener50 = null;
        polarPlot46.addChangeListener(plotChangeListener50);
        java.lang.String str52 = polarPlot46.getNoDataMessage();
        java.awt.Paint paint53 = null;
        polarPlot46.setAngleGridlinePaint(paint53);
        org.jfree.chart.axis.ValueAxis valueAxis55 = polarPlot46.getAxis();
        java.awt.Shape shape61 = null;
        java.awt.Paint paint63 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color65 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke66 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape68 = null;
        java.awt.Stroke stroke69 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color72 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem73 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape61, false, paint63, false, (java.awt.Paint) color65, stroke66, true, shape68, stroke69, (java.awt.Paint) color72);
        polarPlot46.setAngleGridlinePaint(paint63);
        org.jfree.chart.title.LegendGraphic legendGraphic75 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape) line2D38, paint63);
        boolean boolean76 = textLine19.equals((java.lang.Object) line2D38);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(textFragment20);
        org.junit.Assert.assertNotNull(segmentedTimeline22);
        org.junit.Assert.assertNotNull(segment24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(segmentedTimeline27);
        org.junit.Assert.assertNotNull(segment29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-57600001L) + "'", long33 == (-57600001L));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(entityCollection37);
        org.junit.Assert.assertNotNull(line2D38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNull(valueAxis55);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 1577894400001L, Double.POSITIVE_INFINITY);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle1.getLegendItemGraphicEdge();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 100.0d, false, false);
        double double4 = xYSeries3.getMaxX();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        boolean boolean28 = chartChangeEventType25.equals((java.lang.Object) entityCollection26);
        java.lang.String str29 = chartChangeEventType25.toString();
        boolean boolean30 = valueMarker23.equals((java.lang.Object) chartChangeEventType25);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean33 = xYPlot0.removeRangeMarker(8, (org.jfree.chart.plot.Marker) valueMarker23, layer31, true);
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot0.getDataset();
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot0.setOrientation(plotOrientation35);
        java.awt.Paint paint37 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str29.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNotNull(plotOrientation35);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        java.lang.String str12 = combinedDomainXYPlot1.getPlotType();
        java.lang.String[] strArray14 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis15 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray14);
        java.lang.Object obj16 = symbolAxis15.clone();
        symbolAxis15.setRangeWithMargins(0.05d, (double) 1560495599999L);
        combinedDomainXYPlot1.setRangeAxis((org.jfree.chart.axis.ValueAxis) symbolAxis15);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        java.awt.Stroke stroke23 = piePlot22.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        piePlot22.addChangeListener(plotChangeListener24);
        org.jfree.data.general.PieDataset pieDataset26 = piePlot22.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = new org.jfree.chart.util.RectangleInsets((double) (-1), 12.0d, (double) '#', (double) 1577894400005L);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis32.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource35 = null;
        chartRenderingInfo34.setRenderingSource(renderingSource35);
        java.awt.geom.Rectangle2D rectangle2D37 = chartRenderingInfo34.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets33.createInsetRectangle(rectangle2D37, false, false);
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets31.createInsetRectangle(rectangle2D37, false, true);
        piePlot22.setInsets(rectangleInsets31, true);
        symbolAxis15.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot22);
        int int47 = symbolAxis15.getMinorTickCount();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Combined_Domain_XYPlot" + "'", str12.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(pieDataset26);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        java.awt.Font font5 = polarPlot4.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.DATASET_UPDATED", font5);
        java.lang.String str7 = labelBlock6.getToolTipText();
        labelBlock6.setToolTipText("MAJOR");
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource14 = null;
        chartRenderingInfo13.setRenderingSource(renderingSource14);
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo13.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets12.createInsetRectangle(rectangle2D16, false, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint21 = xYBarRenderer20.getBaseItemLabelPaint();
        boolean boolean25 = xYBarRenderer20.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator27 = null;
        xYBarRenderer20.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator27);
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer20.setBaseLegendShape(shape30);
        java.lang.Boolean boolean33 = xYBarRenderer20.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation34 = null;
        boolean boolean35 = xYBarRenderer20.removeAnnotation(xYAnnotation34);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint38 = xYBarRenderer37.getBaseOutlinePaint();
        java.awt.Shape shape44 = null;
        java.awt.Paint paint46 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color48 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape51 = null;
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color55 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem56 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape44, false, paint46, false, (java.awt.Paint) color48, stroke49, true, shape51, stroke52, (java.awt.Paint) color55);
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker(0.0d, paint38, stroke52);
        float float58 = valueMarker57.getAlpha();
        java.awt.Stroke stroke59 = valueMarker57.getStroke();
        xYBarRenderer20.setBaseStroke(stroke59);
        try {
            java.lang.Object obj61 = labelBlock6.draw(graphics2D10, rectangle2D16, (java.lang.Object) xYBarRenderer20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(boolean33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 1.0f + "'", float58 == 1.0f);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        blockResult0.setEntityCollection(entityCollection1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        logAxis0.centerRange((double) 8);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = null;
        try {
            logAxis0.setTickUnit(numberTickUnit3, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseOutlinePaint();
        java.awt.Paint paint2 = xYBarRenderer0.getBasePaint();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer0.setSeriesItemLabelPaint(1, paint4);
        boolean boolean6 = xYBarRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, true);
        org.jfree.data.Range range11 = xYBarRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot0, (org.jfree.data.general.Dataset) timeSeriesCollection7);
        java.awt.Stroke stroke13 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot0.getDrawingSupplier();
        java.awt.Stroke stroke16 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = categoryPlot0.getRenderer(0);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D20 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = barRenderer3D20.getSeriesItemLabelGenerator(15);
        double double23 = barRenderer3D20.getMinimumBarLength();
        categoryPlot0.setRenderer(500, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D20, false);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryItemRenderer18);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        java.awt.Paint paint5 = categoryAxis0.getAxisLinePaint();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryAxis0.setAxisLineStroke(stroke6);
        java.lang.Object obj8 = categoryAxis0.clone();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(128, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        java.lang.Object obj11 = xYSeriesCollection10.clone();
        xYSeriesCollection10.removeAllSeries();
        timeSeriesCollection2.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection10);
        try {
            java.lang.Number number16 = xYSeriesCollection10.getStartY(100, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        java.awt.Shape shape6 = xYBarRenderer0.getBaseLegendShape();
        java.awt.Paint paint8 = xYBarRenderer0.getLegendTextPaint(6);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint11 = xYBarRenderer10.getBaseItemLabelPaint();
        boolean boolean15 = xYBarRenderer10.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator17 = null;
        xYBarRenderer10.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator17);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer10.setBaseLegendShape(shape20);
        java.lang.Boolean boolean23 = xYBarRenderer10.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot25 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis24);
        combinedDomainXYPlot25.setRangeCrosshairValue(0.0d);
        combinedDomainXYPlot25.setDomainMinorGridlinesVisible(true);
        xYBarRenderer10.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot25);
        combinedDomainXYPlot25.setDomainZeroBaselineVisible(false);
        combinedDomainXYPlot25.setGap(1.0d);
        java.util.List list35 = combinedDomainXYPlot25.getSubplots();
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) (-1), 12.0d, (double) '#', (double) 1577894400005L);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = categoryAxis42.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource45 = null;
        chartRenderingInfo44.setRenderingSource(renderingSource45);
        java.awt.geom.Rectangle2D rectangle2D47 = chartRenderingInfo44.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets43.createInsetRectangle(rectangle2D47, false, false);
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets41.createInsetRectangle(rectangle2D47, false, true);
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer57 = null;
        org.jfree.chart.plot.PolarPlot polarPlot58 = new org.jfree.chart.plot.PolarPlot(xYDataset55, valueAxis56, polarItemRenderer57);
        boolean boolean59 = polarPlot58.isOutlineVisible();
        java.awt.Paint paint60 = polarPlot58.getAngleGridlinePaint();
        org.jfree.data.time.TimeSeries timeSeries61 = null;
        java.util.TimeZone timeZone62 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection63 = new org.jfree.data.time.TimeSeriesCollection(timeSeries61, timeZone62);
        org.jfree.data.Range range64 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection63);
        org.jfree.data.xy.XYDataset xYDataset65 = null;
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer67 = null;
        org.jfree.chart.plot.PolarPlot polarPlot68 = new org.jfree.chart.plot.PolarPlot(xYDataset65, valueAxis66, polarItemRenderer67);
        timeSeriesCollection63.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot68);
        org.jfree.chart.axis.ValueAxis valueAxis70 = null;
        org.jfree.data.Range range71 = polarPlot68.getDataRange(valueAxis70);
        java.awt.Stroke stroke72 = polarPlot68.getAngleGridlineStroke();
        try {
            xYBarRenderer0.drawRangeLine(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot25, valueAxis36, rectangle2D53, (double) '4', paint60, stroke72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertNull(range71);
        org.junit.Assert.assertNotNull(stroke72);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        polarPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        polarPlot7.addChangeListener(plotChangeListener11);
        java.lang.String str13 = polarPlot7.getNoDataMessage();
        java.awt.Paint paint14 = null;
        polarPlot7.setAngleGridlinePaint(paint14);
        polarPlot7.setRadiusGridlinesVisible(true);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.awt.Stroke stroke20 = piePlot19.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        piePlot19.addChangeListener(plotChangeListener21);
        org.jfree.data.general.PieDataset pieDataset23 = piePlot19.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (-1), 12.0d, (double) '#', (double) 1577894400005L);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource32 = null;
        chartRenderingInfo31.setRenderingSource(renderingSource32);
        java.awt.geom.Rectangle2D rectangle2D34 = chartRenderingInfo31.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets30.createInsetRectangle(rectangle2D34, false, false);
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets28.createInsetRectangle(rectangle2D34, false, true);
        piePlot19.setInsets(rectangleInsets28, true);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType43 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit45 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType43, 5);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType46 = dateTickUnit45.getUnitType();
        int int47 = dateTickUnit45.getCalendarField();
        int int48 = dateTickUnit45.getMultiple();
        java.awt.Stroke stroke49 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot19.setSectionOutlineStroke((java.lang.Comparable) int48, stroke49);
        polarPlot7.setRadiusGridlineStroke(stroke49);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(pieDataset23);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(dateTickUnitType43);
        org.junit.Assert.assertNotNull(dateTickUnitType46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 11 + "'", int47 == 11);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 5 + "'", int48 == 5);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        boolean boolean1 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = xYBarRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator14 = null;
        xYBarRenderer0.setSeriesItemLabelGenerator(0, xYItemLabelGenerator14, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer18.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer18.setShadowYOffset((double) 0L);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer24 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint25 = xYBarRenderer24.getBaseItemLabelPaint();
        boolean boolean29 = xYBarRenderer24.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator31 = null;
        xYBarRenderer24.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator31);
        java.awt.Shape shape38 = null;
        java.awt.Paint paint40 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color42 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape45 = null;
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color49 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape38, false, paint40, false, (java.awt.Paint) color42, stroke43, true, shape45, stroke46, (java.awt.Paint) color49);
        java.awt.Paint paint51 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem50.setLabelPaint(paint51);
        xYBarRenderer24.setBaseLegendTextPaint(paint51);
        java.awt.Stroke stroke55 = xYBarRenderer24.lookupSeriesOutlineStroke((int) (byte) 100);
        xYBarRenderer24.setSeriesItemLabelsVisible(10, (java.lang.Boolean) false);
        java.lang.Boolean boolean60 = xYBarRenderer24.getSeriesVisibleInLegend((int) '#');
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator62 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer63 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer63.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer63.setShadowYOffset((double) 0L);
        xYBarRenderer63.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color70 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer63.setBaseOutlinePaint((java.awt.Paint) color70);
        boolean boolean72 = standardXYToolTipGenerator62.equals((java.lang.Object) xYBarRenderer63);
        xYBarRenderer24.setSeriesToolTipGenerator(2, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator62, true);
        java.text.DateFormat dateFormat75 = standardXYToolTipGenerator62.getXDateFormat();
        xYBarRenderer18.setSeriesToolTipGenerator(64, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator62);
        xYBarRenderer0.setSeriesToolTipGenerator(9, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator62);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(xYToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNull(boolean60);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNull(dateFormat75);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.panRangeAxes((double) 3, plotRenderingInfo35, point2D36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener39 = null;
        jFreeChart38.addProgressListener(chartProgressListener39);
        java.awt.RenderingHints renderingHints41 = jFreeChart38.getRenderingHints();
        java.awt.RenderingHints renderingHints42 = jFreeChart38.getRenderingHints();
        boolean boolean43 = jFreeChart38.isNotify();
        jFreeChart38.clearSubtitles();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(renderingHints41);
        org.junit.Assert.assertNotNull(renderingHints42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer3D0.getSeriesItemLabelGenerator(15);
        java.awt.Shape shape8 = null;
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color19 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape8, false, paint10, false, (java.awt.Paint) color12, stroke13, true, shape15, stroke16, (java.awt.Paint) color19);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint22 = xYBarRenderer21.getBaseOutlinePaint();
        legendItem20.setLinePaint(paint22);
        boolean boolean24 = barRenderer3D0.equals((java.lang.Object) paint22);
        org.jfree.chart.renderer.category.BarPainter barPainter25 = barRenderer3D0.getBarPainter();
        boolean boolean27 = barRenderer3D0.isSeriesVisible(2019);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(barPainter25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) '#');
        java.lang.String str5 = textAnchor1.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.CENTER_LEFT" + "'", str5.equals("TextAnchor.CENTER_LEFT"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        java.lang.Object obj3 = legendTitle1.clone();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis4);
        combinedDomainXYPlot5.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = combinedDomainXYPlot5.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = combinedDomainXYPlot5.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets10.calculateRightInset(0.0d);
        double double14 = rectangleInsets10.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot5.setAxisOffset(rectangleInsets10);
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, paint16);
        legendTitle1.setPadding(rectangleInsets10);
        java.awt.Paint paint19 = legendTitle1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.panRangeAxes((double) 3, plotRenderingInfo35, point2D36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        java.awt.Paint paint39 = jFreeChart38.getBorderPaint();
        java.awt.Color color40 = java.awt.Color.MAGENTA;
        jFreeChart38.setBackgroundPaint((java.awt.Paint) color40);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarksVisible(false);
        categoryAxis0.configure();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource11 = null;
        chartRenderingInfo10.setRenderingSource(renderingSource11);
        java.awt.geom.Rectangle2D rectangle2D13 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.axis.AxisState axisState14 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        axisState14.moveCursor((double) 0, rectangleEdge16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState14.moveCursor((double) 100L, rectangleEdge19);
        double double21 = categoryAxis6.getCategoryJava2DCoordinate(categoryAnchor7, 10, (int) (short) 0, rectangle2D13, rectangleEdge19);
        org.jfree.chart.axis.AxisState axisState22 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        axisState22.moveCursor((double) 0, rectangleEdge24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState22.moveCursor((double) 100L, rectangleEdge27);
        axisState22.setCursor((double) 3);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer35 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint36 = xYBarRenderer35.getBaseOutlinePaint();
        java.awt.Shape shape42 = null;
        java.awt.Paint paint44 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color46 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape49 = null;
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color53 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem54 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape42, false, paint44, false, (java.awt.Paint) color46, stroke47, true, shape49, stroke50, (java.awt.Paint) color53);
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker(0.0d, paint36, stroke50);
        double double56 = valueMarker55.getValue();
        org.jfree.chart.util.Layer layer57 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean59 = categoryPlot32.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker55, layer57, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = categoryPlot32.getDomainAxisEdge();
        axisState22.moveCursor(2.0d, rectangleEdge60);
        org.jfree.chart.axis.AxisState axisState62 = null;
        categoryAxis0.drawTickMarks(graphics2D4, (double) 9, rectangle2D13, rectangleEdge60, axisState62);
        java.lang.String[] strArray65 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis66 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray65);
        java.lang.Object obj67 = symbolAxis66.clone();
        symbolAxis66.setRangeWithMargins(0.05d, (double) 1560495599999L);
        org.jfree.chart.entity.AxisEntity axisEntity73 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D13, (org.jfree.chart.axis.Axis) symbolAxis66, "HorizontalAlignment.CENTER", "Range[100.0,100.0]");
        boolean boolean74 = symbolAxis66.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(layer57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNotNull(strArray65);
        org.junit.Assert.assertNotNull(obj67);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis2.getTickLabelInsets();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        double double7 = categoryAxis2.getUpperMargin();
        java.awt.Paint paint8 = categoryAxis2.getLabelPaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d, paint8);
        double double10 = intervalMarker9.getStartValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = intervalMarker9.getLabelAnchor();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleAnchor11);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        boolean boolean28 = chartChangeEventType25.equals((java.lang.Object) entityCollection26);
        java.lang.String str29 = chartChangeEventType25.toString();
        boolean boolean30 = valueMarker23.equals((java.lang.Object) chartChangeEventType25);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean33 = xYPlot0.removeRangeMarker(8, (org.jfree.chart.plot.Marker) valueMarker23, layer31, true);
        java.awt.Paint paint34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot0.setDomainTickBandPaint(paint34);
        boolean boolean36 = xYPlot0.isSubplot();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str29.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.setNoDataMessage("ThreadContext");
        org.jfree.chart.plot.Plot plot6 = polarPlot3.getParent();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D11 = xYPlot10.getQuadrantOrigin();
        try {
            polarPlot3.zoomRangeAxes(0.0d, (double) (short) 0, plotRenderingInfo9, point2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(point2D11);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8);
        double double10 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setTickMarksVisible(false);
        java.awt.Font font14 = categoryAxis11.getTickLabelFont();
        categoryPlot0.setDomainAxis(categoryAxis11);
        boolean boolean16 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer3D0.getSeriesItemLabelGenerator(15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator5, false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) rotation0);
        boolean boolean2 = rendererChangeEvent1.getSeriesVisibilityChanged();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        java.awt.Font font3 = piePlot1.getLabelFont();
        piePlot1.setLabelGap((double) 4);
        double double6 = piePlot1.getInteriorGap();
        piePlot1.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray1);
        java.lang.Object obj3 = symbolAxis2.clone();
        org.jfree.data.RangeType rangeType4 = org.jfree.data.RangeType.POSITIVE;
        java.lang.Object obj5 = null;
        boolean boolean6 = rangeType4.equals(obj5);
        symbolAxis2.setRangeType(rangeType4);
        java.lang.Object obj8 = null;
        boolean boolean9 = symbolAxis2.equals(obj8);
        symbolAxis2.setInverted(false);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color16 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape5, false, paint7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color16);
        java.lang.Object obj18 = null;
        boolean boolean19 = legendItem17.equals(obj18);
        java.awt.Shape shape20 = legendItem17.getShape();
        java.lang.String str21 = legendItem17.getLabel();
        java.awt.Stroke stroke22 = legendItem17.getLineStroke();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(shape20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ThreadContext" + "'", str21.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setTickMarksVisible(false);
        categoryAxis2.configure();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource13 = null;
        chartRenderingInfo12.setRenderingSource(renderingSource13);
        java.awt.geom.Rectangle2D rectangle2D15 = chartRenderingInfo12.getChartArea();
        org.jfree.chart.axis.AxisState axisState16 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        axisState16.moveCursor((double) 0, rectangleEdge18);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState16.moveCursor((double) 100L, rectangleEdge21);
        double double23 = categoryAxis8.getCategoryJava2DCoordinate(categoryAnchor9, 10, (int) (short) 0, rectangle2D15, rectangleEdge21);
        org.jfree.chart.axis.AxisState axisState24 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        axisState24.moveCursor((double) 0, rectangleEdge26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState24.moveCursor((double) 100L, rectangleEdge29);
        axisState24.setCursor((double) 3);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint38 = xYBarRenderer37.getBaseOutlinePaint();
        java.awt.Shape shape44 = null;
        java.awt.Paint paint46 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color48 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape51 = null;
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color55 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem56 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape44, false, paint46, false, (java.awt.Paint) color48, stroke49, true, shape51, stroke52, (java.awt.Paint) color55);
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker(0.0d, paint38, stroke52);
        double double58 = valueMarker57.getValue();
        org.jfree.chart.util.Layer layer59 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean61 = categoryPlot34.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker57, layer59, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = categoryPlot34.getDomainAxisEdge();
        axisState24.moveCursor(2.0d, rectangleEdge62);
        org.jfree.chart.axis.AxisState axisState64 = null;
        categoryAxis2.drawTickMarks(graphics2D6, (double) 9, rectangle2D15, rectangleEdge62, axisState64);
        boolean boolean66 = org.jfree.chart.util.ShapeUtilities.isPointInRect(0.0d, (double) (short) -1, rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(layer59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer3D0.getSeriesItemLabelGenerator(15);
        java.awt.Shape shape8 = null;
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color19 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape8, false, paint10, false, (java.awt.Paint) color12, stroke13, true, shape15, stroke16, (java.awt.Paint) color19);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint22 = xYBarRenderer21.getBaseOutlinePaint();
        legendItem20.setLinePaint(paint22);
        boolean boolean24 = barRenderer3D0.equals((java.lang.Object) paint22);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = barRenderer3D0.getLegendItems();
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(legendItemCollection25);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        boolean boolean10 = intervalXYDelegate9.isAutoWidth();
        java.lang.Object obj11 = intervalXYDelegate9.clone();
        try {
            intervalXYDelegate9.setIntervalPositionFactor(10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument 'd' outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 1, true, true);
        xYSeries3.add((double) 0L, (double) (short) -1);
        xYSeries3.add((java.lang.Number) (byte) 0, (java.lang.Number) 64, true);
        org.jfree.data.xy.XYDataItem xYDataItem13 = xYSeries3.addOrUpdate((double) ' ', 0.0d);
        org.junit.Assert.assertNull(xYDataItem13);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.addChangeListener(plotChangeListener3);
        java.awt.Stroke stroke5 = piePlot1.getLabelOutlineStroke();
        piePlot1.setShadowXOffset(12.0d);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("[100.0, -1.0]");
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 100);
        double double3 = range2.getLength();
        boolean boolean5 = range2.contains((double) 10);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.awt.Shape shape17 = null;
        java.awt.Paint paint19 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color21 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color28 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape17, false, paint19, false, (java.awt.Paint) color21, stroke22, true, shape24, stroke25, (java.awt.Paint) color28);
        java.lang.Object obj30 = null;
        boolean boolean31 = legendItem29.equals(obj30);
        java.awt.Paint paint32 = legendItem29.getFillPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape10, paint32);
        java.awt.Shape shape34 = legendGraphic33.getShape();
        java.awt.Stroke stroke35 = legendGraphic33.getLineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer36 = legendGraphic33.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertNotNull(gradientPaintTransformer36);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = categoryPlot1.getRangeMarkers((int) '4', layer3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries6 = null;
        java.util.TimeZone timeZone7 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeSeries6, timeZone7);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8, true);
        org.jfree.data.Range range12 = xYBarRenderer5.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot1, (org.jfree.data.general.Dataset) timeSeriesCollection8);
        java.awt.Stroke stroke14 = categoryPlot1.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot1.getRangeAxisLocation();
        boolean boolean16 = pieLabelLinkStyle0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot1.panDomainAxes((double) 28, plotRenderingInfo18, point2D19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot1.getFixedDomainAxisSpace();
        categoryPlot1.setRangeZeroBaselineVisible(false);
        float float24 = categoryPlot1.getForegroundAlpha();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        blockParams0.setTranslateY((double) (-9999));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number3 = xYDataItem2.getX();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2, "October", "RectangleAnchor.BOTTOM");
        timeSeries6.setKey((java.lang.Comparable) 4.0d);
        try {
            timeSeries6.delete(6, 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.plot.XYPlot xYPlot3 = xYBarRenderer0.getPlot();
        java.awt.Stroke stroke5 = xYBarRenderer0.getSeriesStroke((int) (byte) 100);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator6 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNull(xYPlot3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNull(xYItemLabelGenerator6);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleLabelsVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis6.getTickLabelInsets();
        polarPlot4.setInsets(rectangleInsets7);
        double double10 = rectangleInsets7.calculateTopInset((double) (-460));
        double double11 = rectangleInsets7.getRight();
        java.lang.Class<?> wildcardClass12 = rectangleInsets7.getClass();
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResource("AxisLocation.TOP_OR_RIGHT", (java.lang.Class) wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(uRL13);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.xy.XYDataItem xYDataItem3 = new org.jfree.data.xy.XYDataItem((double) (short) 100, (double) (-1));
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, (java.lang.Comparable) (short) 100, (double) 2.0f, 1);
        defaultPieDataset0.setValue((java.lang.Comparable) "RectangleAnchor.BOTTOM", 2.0d);
        java.lang.Object obj10 = null;
        boolean boolean11 = defaultPieDataset0.equals(obj10);
        java.lang.Comparable comparable13 = defaultPieDataset0.getKey(0);
        java.lang.Comparable comparable14 = null;
        try {
            int int15 = defaultPieDataset0.getIndex(comparable14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + "RectangleAnchor.BOTTOM" + "'", comparable13.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace8);
        boolean boolean10 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation11);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis14);
        combinedDomainXYPlot15.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = combinedDomainXYPlot15.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = combinedDomainXYPlot15.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace20 = combinedDomainXYPlot15.getFixedRangeAxisSpace();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot21.getRangeMarkers((int) '4', layer23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot21.setDomainAxis((int) (short) 0, categoryAxis26, true);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot21.setFixedRangeAxisSpace(axisSpace29);
        double double31 = categoryPlot21.getAnchorValue();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot21.setRangeAxisLocation(axisLocation32);
        combinedDomainXYPlot15.setRangeAxisLocation(axisLocation32, true);
        try {
            categoryPlot0.setDomainAxisLocation((int) (short) -1, axisLocation32, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation32);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        java.lang.Object obj1 = xYSeriesCollection0.clone();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        combinedDomainXYPlot3.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = combinedDomainXYPlot3.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = combinedDomainXYPlot3.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace8 = combinedDomainXYPlot3.getFixedRangeAxisSpace();
        combinedDomainXYPlot3.setDomainCrosshairValue(0.0d, false);
        org.jfree.chart.axis.AxisSpace axisSpace12 = combinedDomainXYPlot3.getFixedDomainAxisSpace();
        xYSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) combinedDomainXYPlot3);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        org.jfree.data.time.TimeSeries timeSeries16 = null;
        java.util.TimeZone timeZone17 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeSeries16, timeZone17);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot(xYDataset20, valueAxis21, polarItemRenderer22);
        timeSeriesCollection18.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot23);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection18);
        org.jfree.data.general.DatasetGroup datasetGroup26 = timeSeriesCollection18.getGroup();
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot(xYDataset31, valueAxis32, polarItemRenderer33);
        polarPlot34.setNoDataMessage("ThreadContext");
        java.awt.Paint paint37 = polarPlot34.getRadiusGridlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) 9999, (double) 0, (double) '#', paint37);
        boolean boolean39 = datasetGroup26.equals((java.lang.Object) blockBorder38);
        blockContainer15.setFrame((org.jfree.chart.block.BlockFrame) blockBorder38);
        org.jfree.chart.block.Arrangement arrangement41 = blockContainer15.getArrangement();
        java.util.List list42 = blockContainer15.getBlocks();
        try {
            combinedDomainXYPlot3.mapDatasetToRangeAxes(8, list42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(datasetGroup26);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(arrangement41);
        org.junit.Assert.assertNotNull(list42);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = xYBarRenderer1.getBaseOutlinePaint();
        java.awt.Shape shape8 = null;
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color19 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape8, false, paint10, false, (java.awt.Paint) color12, stroke13, true, shape15, stroke16, (java.awt.Paint) color19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, paint2, stroke16);
        double double22 = valueMarker21.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection24 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo(entityCollection24);
        boolean boolean26 = chartChangeEventType23.equals((java.lang.Object) entityCollection24);
        java.lang.String str27 = chartChangeEventType23.toString();
        boolean boolean28 = valueMarker21.equals((java.lang.Object) chartChangeEventType23);
        java.awt.Stroke stroke29 = valueMarker21.getStroke();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str27.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer0.setShadowYOffset((double) 0L);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint7 = xYBarRenderer6.getBaseItemLabelPaint();
        boolean boolean11 = xYBarRenderer6.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = null;
        xYBarRenderer6.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator13);
        java.awt.Shape shape20 = null;
        java.awt.Paint paint22 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color24 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape27 = null;
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color31 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape20, false, paint22, false, (java.awt.Paint) color24, stroke25, true, shape27, stroke28, (java.awt.Paint) color31);
        java.awt.Paint paint33 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem32.setLabelPaint(paint33);
        xYBarRenderer6.setBaseLegendTextPaint(paint33);
        java.awt.Stroke stroke37 = xYBarRenderer6.lookupSeriesOutlineStroke((int) (byte) 100);
        xYBarRenderer6.setSeriesItemLabelsVisible(10, (java.lang.Boolean) false);
        java.lang.Boolean boolean42 = xYBarRenderer6.getSeriesVisibleInLegend((int) '#');
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator44 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer45 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer45.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer45.setShadowYOffset((double) 0L);
        xYBarRenderer45.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color52 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer45.setBaseOutlinePaint((java.awt.Paint) color52);
        boolean boolean54 = standardXYToolTipGenerator44.equals((java.lang.Object) xYBarRenderer45);
        xYBarRenderer6.setSeriesToolTipGenerator(2, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator44, true);
        java.text.DateFormat dateFormat57 = standardXYToolTipGenerator44.getXDateFormat();
        xYBarRenderer0.setSeriesToolTipGenerator(64, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator44);
        java.lang.String str59 = standardXYToolTipGenerator44.getFormatString();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(boolean42);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(dateFormat57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "{0}: ({1}, {2})" + "'", str59.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.Stroke stroke5 = categoryPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint5 = xYBarRenderer4.getBaseItemLabelPaint();
        boolean boolean9 = xYBarRenderer4.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYBarRenderer4.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator11);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer4.setBaseLegendShape(shape14);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.clone(shape14);
        java.awt.Color color17 = java.awt.Color.YELLOW;
        java.awt.Color color18 = color17.brighter();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint20 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem(attributedString0, "java.awt.Color[r=0,g=0,b=0]", "", "Range[100.0,100.0]", shape16, (java.awt.Paint) color17, stroke19, paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, true);
        org.jfree.data.Range range11 = xYBarRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot0, (org.jfree.data.general.Dataset) timeSeriesCollection7);
        java.awt.Stroke stroke13 = categoryPlot0.getDomainGridlineStroke();
        int int14 = categoryPlot0.getWeight();
        java.awt.Shape shape20 = null;
        java.awt.Paint paint22 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color24 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape27 = null;
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color31 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape20, false, paint22, false, (java.awt.Paint) color24, stroke25, true, shape27, stroke28, (java.awt.Paint) color31);
        categoryPlot0.setOutlineStroke(stroke25);
        java.awt.Paint paint34 = categoryPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        java.lang.String str3 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 9999);
        categoryAxis0.setMinorTickMarksVisible(true);
        categoryAxis0.setCategoryMargin((double) 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) 12);
        java.lang.Number number3 = xYDataItem2.getX();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2, "October", "RectangleAnchor.BOTTOM");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset7 = new org.jfree.data.xy.DefaultXYDataset();
        defaultXYDataset7.removeSeries((java.lang.Comparable) 'a');
        timeSeries6.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset7);
        org.jfree.data.time.TimeSeries timeSeries11 = null;
        java.util.TimeZone timeZone12 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries11, timeZone12);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection13, true);
        timeSeries6.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection13);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.util.Date date19 = month18.getStart();
        long long20 = month18.getSerialIndex();
        org.jfree.data.time.Year year21 = month18.getYear();
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 0.05d, true);
        java.lang.Object obj25 = timeSeries6.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries6.getNextTimePeriod();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 24234L + "'", long20 == 24234L);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.lang.Boolean boolean13 = xYBarRenderer0.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis14);
        combinedDomainXYPlot15.setRangeCrosshairValue(0.0d);
        combinedDomainXYPlot15.setDomainMinorGridlinesVisible(true);
        xYBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot15);
        combinedDomainXYPlot15.setDomainZeroBaselineVisible(false);
        java.awt.Paint paint23 = combinedDomainXYPlot15.getDomainTickBandPaint();
        combinedDomainXYPlot15.clearDomainAxes();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Font font4 = polarPlot3.getNoDataMessageFont();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        boolean boolean9 = polarPlot8.isAngleLabelsVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) polarPlot8);
        polarPlot3.notifyListeners(plotChangeEvent10);
        polarPlot3.setBackgroundImageAlignment(0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, true);
        org.jfree.data.Range range11 = xYBarRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot0, (org.jfree.data.general.Dataset) timeSeriesCollection7);
        java.awt.Stroke stroke13 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot0.getDrawingSupplier();
        java.awt.Stroke stroke16 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = categoryPlot0.getRenderer(0);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryAxis20.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource23 = null;
        chartRenderingInfo22.setRenderingSource(renderingSource23);
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo22.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets21.createInsetRectangle(rectangle2D25, false, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState31 = null;
        boolean boolean32 = categoryPlot0.render(graphics2D19, rectangle2D28, 4, plotRenderingInfo30, categoryCrosshairState31);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryItemRenderer18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 10);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer0.setShadowYOffset((double) 0L);
        xYBarRenderer0.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color7);
        double double9 = xYBarRenderer0.getShadowYOffset();
        xYBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke14 = xYPlot13.getDomainMinorGridlineStroke();
        xYBarRenderer0.setBaseStroke(stroke14);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection2);
        java.lang.String str10 = rendererChangeEvent9.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rendererChangeEvent9);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint16 = xYBarRenderer15.getBaseOutlinePaint();
        java.awt.Shape shape22 = null;
        java.awt.Paint paint24 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color26 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape29 = null;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color33 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape22, false, paint24, false, (java.awt.Paint) color26, stroke27, true, shape29, stroke30, (java.awt.Paint) color33);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(0.0d, paint16, stroke30);
        double double36 = valueMarker35.getValue();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean39 = categoryPlot12.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker35, layer37, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot12.getDomainAxisEdge();
        double double41 = categoryPlot12.getRangeCrosshairValue();
        double double42 = categoryPlot12.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        categoryPlot12.setRangeAxis(1, valueAxis44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        categoryPlot12.panRangeAxes((double) 3, plotRenderingInfo47, point2D48);
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot12);
        java.awt.Paint paint51 = jFreeChart50.getBorderPaint();
        boolean boolean52 = jFreeChart50.isBorderVisible();
        rendererChangeEvent9.setChart(jFreeChart50);
        java.lang.String str54 = rendererChangeEvent9.toString();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.data.Range range10 = polarPlot7.getDataRange(valueAxis9);
        boolean boolean11 = polarPlot7.isSubplot();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.lang.Object obj1 = axisSpace0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        combinedDomainXYPlot1.setDomainMinorGridlinesVisible(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.awt.Stroke stroke9 = piePlot8.getLabelLinkStroke();
        java.awt.Font font10 = piePlot8.getLabelFont();
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("PlotOrientation.HORIZONTAL", font10, paint11);
        combinedDomainXYPlot1.setRangeTickBandPaint(paint11);
        java.awt.Stroke stroke14 = combinedDomainXYPlot1.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo4);
        org.jfree.chart.entity.EntityCollection entityCollection6 = state5.getEntityCollection();
        java.awt.geom.Line2D line2D7 = state5.workingLine;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) (-1), 12.0d, (double) '#', (double) 1577894400005L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource16 = null;
        chartRenderingInfo15.setRenderingSource(renderingSource16);
        java.awt.geom.Rectangle2D rectangle2D18 = chartRenderingInfo15.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets14.createInsetRectangle(rectangle2D18, false, false);
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets12.createInsetRectangle(rectangle2D18, false, true);
        boolean boolean25 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) line2D7, (java.awt.Shape) rectangle2D18);
        java.awt.Color color26 = java.awt.Color.GREEN;
        try {
            org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "100", "RectangleEdge.BOTTOM", (java.awt.Shape) rectangle2D18, (java.awt.Paint) color26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(entityCollection6);
        org.junit.Assert.assertNotNull(line2D7);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.data.Range range10 = polarPlot7.getDataRange(valueAxis9);
        boolean boolean11 = polarPlot7.isOutlineVisible();
        polarPlot7.setRadiusGridlinesVisible(false);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.addChangeListener(plotChangeListener3);
        java.awt.Stroke stroke5 = piePlot1.getLabelOutlineStroke();
        java.lang.String[] strArray7 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis8 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray7);
        int int9 = symbolAxis8.getMinorTickCount();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        symbolAxis8.setTickUnit(numberTickUnit10);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint13 = xYBarRenderer12.getBaseItemLabelPaint();
        boolean boolean17 = xYBarRenderer12.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator19 = null;
        xYBarRenderer12.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator19);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer12.setBaseLegendShape(shape22);
        java.awt.Shape shape29 = null;
        java.awt.Paint paint31 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color33 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape36 = null;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color40 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape29, false, paint31, false, (java.awt.Paint) color33, stroke34, true, shape36, stroke37, (java.awt.Paint) color40);
        java.lang.Object obj42 = null;
        boolean boolean43 = legendItem41.equals(obj42);
        java.awt.Paint paint44 = legendItem41.getFillPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic45 = new org.jfree.chart.title.LegendGraphic(shape22, paint44);
        java.awt.Shape shape46 = legendGraphic45.getShape();
        java.awt.Stroke stroke47 = legendGraphic45.getLineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot48.setRangeMinorGridlinesVisible(false);
        java.awt.Stroke stroke51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        categoryPlot48.setDomainGridlineStroke(stroke51);
        legendGraphic45.setOutlineStroke(stroke51);
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) numberTickUnit10, stroke51);
        double double55 = piePlot1.getMaximumExplodePercent();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNull(stroke47);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("October");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        legendItem1.setLinePaint((java.awt.Paint) color2);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = color2.equals((java.lang.Object) categoryPlot4);
        categoryPlot4.setRangeZeroBaselineVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setTickMarksVisible(false);
        categoryPlot4.setDomainAxis(categoryAxis8);
        int int12 = categoryPlot4.getWeight();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = xYBarRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator14 = null;
        xYBarRenderer0.setSeriesItemLabelGenerator(0, xYItemLabelGenerator14, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = xYBarRenderer0.getGradientPaintTransformer();
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(xYToolTipGenerator12);
        org.junit.Assert.assertNotNull(gradientPaintTransformer17);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = xYBarRenderer2.getBaseItemLabelPaint();
        piePlot1.setLabelPaint(paint3);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = piePlot1.getToolTipGenerator();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint8 = xYBarRenderer7.getBaseOutlinePaint();
        java.awt.Paint paint9 = xYBarRenderer7.getBasePaint();
        piePlot1.setSectionPaint((java.lang.Comparable) "PlotOrientation.HORIZONTAL", paint9);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint13 = piePlot1.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(pieToolTipGenerator5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Stroke stroke4 = piePlot3.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot3.addChangeListener(plotChangeListener5);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator7 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        piePlot3.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator7);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset10, valueAxis11, polarItemRenderer12);
        float float14 = polarPlot13.getBackgroundImageAlpha();
        xYBarRenderer9.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot13);
        java.awt.Color color17 = java.awt.Color.orange;
        xYBarRenderer9.setSeriesItemLabelPaint((int) 'a', (java.awt.Paint) color17);
        piePlot3.setOutlinePaint((java.awt.Paint) color17);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot(xYDataset24, valueAxis25, polarItemRenderer26);
        polarPlot27.setNoDataMessage("ThreadContext");
        java.awt.Paint paint30 = polarPlot27.getRadiusGridlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) 9999, (double) 0, (double) '#', paint30);
        piePlot3.setLabelBackgroundPaint(paint30);
        piePlot1.setLabelShadowPaint(paint30);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle1 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot2.getRangeMarkers((int) '4', layer4);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries7 = null;
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeSeries7, timeZone8);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection9, true);
        org.jfree.data.Range range13 = xYBarRenderer6.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot2, (org.jfree.data.general.Dataset) timeSeriesCollection9);
        java.awt.Stroke stroke15 = categoryPlot2.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot2.getRangeAxisLocation();
        boolean boolean17 = pieLabelLinkStyle1.equals((java.lang.Object) categoryPlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot2.panDomainAxes((double) 28, plotRenderingInfo19, point2D20);
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot2.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle1);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(sortOrder23);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.awt.Shape shape17 = null;
        java.awt.Paint paint19 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color21 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color28 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape17, false, paint19, false, (java.awt.Paint) color21, stroke22, true, shape24, stroke25, (java.awt.Paint) color28);
        java.lang.Object obj30 = null;
        boolean boolean31 = legendItem29.equals(obj30);
        java.awt.Paint paint32 = legendItem29.getFillPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape10, paint32);
        java.awt.Shape shape34 = legendGraphic33.getShape();
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer39 = null;
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot(xYDataset37, valueAxis38, polarItemRenderer39);
        java.awt.Font font41 = polarPlot40.getNoDataMessageFont();
        org.jfree.chart.entity.PlotEntity plotEntity42 = new org.jfree.chart.entity.PlotEntity(shape36, (org.jfree.chart.plot.Plot) polarPlot40);
        boolean boolean43 = legendGraphic33.equals((java.lang.Object) plotEntity42);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer44 = legendGraphic33.getFillPaintTransformer();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = legendGraphic33.getShapeAnchor();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer44);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator2);
        java.awt.Paint paint4 = piePlot1.getLabelOutlinePaint();
        piePlot1.setAutoPopulateSectionOutlinePaint(true);
        piePlot1.setInteriorGap(Double.NaN);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isAngleLabelsVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis5.getTickLabelInsets();
        polarPlot3.setInsets(rectangleInsets6);
        double double8 = rectangleInsets6.getLeft();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        java.lang.String str12 = combinedDomainXYPlot1.getPlotType();
        java.lang.String[] strArray14 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis15 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray14);
        java.lang.Object obj16 = symbolAxis15.clone();
        symbolAxis15.setRangeWithMargins(0.05d, (double) 1560495599999L);
        combinedDomainXYPlot1.setRangeAxis((org.jfree.chart.axis.ValueAxis) symbolAxis15);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint23 = xYBarRenderer22.getBaseOutlinePaint();
        java.awt.Shape shape29 = null;
        java.awt.Paint paint31 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color33 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape36 = null;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color40 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape29, false, paint31, false, (java.awt.Paint) color33, stroke34, true, shape36, stroke37, (java.awt.Paint) color40);
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker(0.0d, paint23, stroke37);
        double double43 = valueMarker42.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType44 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection45 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = new org.jfree.chart.ChartRenderingInfo(entityCollection45);
        boolean boolean47 = chartChangeEventType44.equals((java.lang.Object) entityCollection45);
        java.lang.String str48 = chartChangeEventType44.toString();
        boolean boolean49 = valueMarker42.equals((java.lang.Object) chartChangeEventType44);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer52 = null;
        org.jfree.chart.plot.PolarPlot polarPlot53 = new org.jfree.chart.plot.PolarPlot(xYDataset50, valueAxis51, polarItemRenderer52);
        polarPlot53.setNoDataMessage("ThreadContext");
        java.awt.Paint paint56 = polarPlot53.getRadiusGridlinePaint();
        valueMarker42.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot53);
        combinedDomainXYPlot1.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker42);
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = categoryAxis61.getTickLabelInsets();
        categoryAxis61.addCategoryLabelToolTip((java.lang.Comparable) (-1.0d), "hi!");
        double double66 = categoryAxis61.getUpperMargin();
        java.awt.Paint paint67 = categoryAxis61.getLabelPaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker68 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 0.0d, paint67);
        valueMarker42.setOutlinePaint(paint67);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Combined_Domain_XYPlot" + "'", str12.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str48.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.05d + "'", double66 == 0.05d);
        org.junit.Assert.assertNotNull(paint67);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        java.awt.Stroke stroke12 = combinedDomainXYPlot1.getDomainMinorGridlineStroke();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint15 = xYBarRenderer14.getBaseItemLabelPaint();
        boolean boolean19 = xYBarRenderer14.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator21 = null;
        xYBarRenderer14.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator21);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer14.setBaseLegendShape(shape24);
        java.lang.Boolean boolean27 = xYBarRenderer14.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot29 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis28);
        combinedDomainXYPlot29.setRangeCrosshairValue(0.0d);
        combinedDomainXYPlot29.setDomainMinorGridlinesVisible(true);
        xYBarRenderer14.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot29);
        combinedDomainXYPlot29.setDomainZeroBaselineVisible(false);
        combinedDomainXYPlot29.setGap(1.0d);
        java.awt.Paint paint40 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot41.setRangeMinorGridlinesVisible(false);
        java.awt.Stroke stroke44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        categoryPlot41.setDomainGridlineStroke(stroke44);
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) 0.5f, paint40, stroke44);
        combinedDomainXYPlot29.setRangeCrosshairStroke(stroke44);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder(paint13, stroke44, rectangleInsets48);
        combinedDomainXYPlot1.setDomainZeroBaselineStroke(stroke44);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleInsets48);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, true);
        org.jfree.data.Range range11 = xYBarRenderer4.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot0, (org.jfree.data.general.Dataset) timeSeriesCollection7);
        java.awt.Stroke stroke13 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint20 = xYBarRenderer19.getBaseOutlinePaint();
        java.awt.Shape shape26 = null;
        java.awt.Paint paint28 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color30 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape33 = null;
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color37 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape26, false, paint28, false, (java.awt.Paint) color30, stroke31, true, shape33, stroke34, (java.awt.Paint) color37);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(0.0d, paint20, stroke34);
        double double40 = valueMarker39.getValue();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean43 = categoryPlot16.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker39, layer41, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot16.getDomainAxisEdge();
        double double45 = categoryPlot16.getRangeCrosshairValue();
        double double46 = categoryPlot16.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        categoryPlot16.setRangeAxis(1, valueAxis48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        java.awt.geom.Point2D point2D52 = null;
        categoryPlot16.panRangeAxes((double) 3, plotRenderingInfo51, point2D52);
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener55 = null;
        jFreeChart54.addProgressListener(chartProgressListener55);
        java.awt.RenderingHints renderingHints57 = jFreeChart54.getRenderingHints();
        jFreeChart54.setBackgroundImageAlpha((float) '4');
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart54);
        java.awt.Paint paint61 = categoryPlot0.getRangeMinorGridlinePaint();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(renderingHints57);
        org.junit.Assert.assertNotNull(paint61);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = xYBarRenderer0.getBaseToolTipGenerator();
        xYBarRenderer0.setSeriesItemLabelsVisible(100, (java.lang.Boolean) false, false);
        xYBarRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter19 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
        xYBarRenderer0.setBarPainter(xYBarPainter19);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(xYToolTipGenerator12);
        org.junit.Assert.assertNotNull(xYBarPainter19);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        long long3 = segment2.getSegmentCount();
        long long4 = segment2.getSegmentCount();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segmentedTimeline5.getSegment((long) (short) 100);
        long long8 = segment7.getSegmentCount();
        segment7.dec();
        boolean boolean10 = segment2.contains(segment7);
        long long11 = segment7.getSegmentEnd();
        segment7.inc();
        segment7.dec((long) 7);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(segment7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600001L) + "'", long11 == (-57600001L));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        boolean boolean3 = multiplePiePlot1.isOutlineVisible();
        org.jfree.chart.util.TableOrder tableOrder4 = multiplePiePlot1.getDataExtractOrder();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(tableOrder4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray1);
        int int3 = symbolAxis2.getMinorTickCount();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        symbolAxis2.setTickUnit(numberTickUnit4);
        symbolAxis2.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(numberTickUnit4);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray1);
        java.lang.Object obj3 = symbolAxis2.clone();
        org.jfree.data.RangeType rangeType4 = org.jfree.data.RangeType.POSITIVE;
        java.lang.Object obj5 = null;
        boolean boolean6 = rangeType4.equals(obj5);
        symbolAxis2.setRangeType(rangeType4);
        java.lang.Object obj8 = null;
        boolean boolean9 = symbolAxis2.equals(obj8);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        java.lang.String str13 = numberTickUnit11.valueToString((double) 100L);
        symbolAxis2.setTickUnit(numberTickUnit11, false, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer17.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer17.setShadowYOffset((double) 0L);
        xYBarRenderer17.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer17.setBaseOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = xYBarRenderer17.getBasePositiveItemLabelPosition();
        boolean boolean27 = symbolAxis2.equals((java.lang.Object) xYBarRenderer17);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = null;
        java.util.TimeZone timeZone30 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection31 = new org.jfree.data.time.TimeSeriesCollection(timeSeries29, timeZone30);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection31);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset33, valueAxis34, polarItemRenderer35);
        timeSeriesCollection31.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot36);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier38 = null;
        polarPlot36.setDrawingSupplier(drawingSupplier38);
        org.jfree.chart.event.PlotChangeListener plotChangeListener40 = null;
        polarPlot36.addChangeListener(plotChangeListener40);
        java.lang.String str42 = polarPlot36.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = new org.jfree.chart.util.RectangleInsets((double) (-1), 12.0d, (double) '#', (double) 1577894400005L);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = categoryAxis48.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource51 = null;
        chartRenderingInfo50.setRenderingSource(renderingSource51);
        java.awt.geom.Rectangle2D rectangle2D53 = chartRenderingInfo50.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets49.createInsetRectangle(rectangle2D53, false, false);
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets47.createInsetRectangle(rectangle2D53, false, true);
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot61 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis60);
        combinedDomainXYPlot61.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = combinedDomainXYPlot61.getDomainAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot67 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis66);
        combinedDomainXYPlot67.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = combinedDomainXYPlot67.getDomainAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.AxisSpace axisSpace72 = new org.jfree.chart.axis.AxisSpace();
        axisSpace72.setTop((double) 432000000L);
        combinedDomainXYPlot67.setFixedDomainAxisSpace(axisSpace72);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace76 = symbolAxis2.reserveSpace(graphics2D28, (org.jfree.chart.plot.Plot) polarPlot36, rectangle2D59, rectangleEdge65, axisSpace72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertNotNull(rectangleEdge71);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        java.awt.Font font7 = polarPlot6.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("ChartChangeEventType.DATASET_UPDATED", font7);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Color color10 = color9.brighter();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("[100.0, 12.0]", font7, (java.awt.Paint) color9);
        java.awt.Color color12 = java.awt.Color.getColor("ThreadContext", color9);
        int int13 = color9.getRGB();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-256) + "'", int13 == (-256));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = null;
        axisState0.moveCursor((double) 0, rectangleEdge2);
        axisState0.cursorUp(0.0d);
        axisState0.cursorRight((double) (-2));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean2 = chartRenderingInfo0.equals((java.lang.Object) 0L);
        org.jfree.chart.RenderingSource renderingSource3 = chartRenderingInfo0.getRenderingSource();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(renderingSource3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        try {
            categoryPlot0.handleClick((int) '4', 6, plotRenderingInfo33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.panRangeAxes((double) 3, plotRenderingInfo35, point2D36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener39 = null;
        jFreeChart38.addProgressListener(chartProgressListener39);
        java.awt.RenderingHints renderingHints41 = jFreeChart38.getRenderingHints();
        java.awt.RenderingHints renderingHints42 = jFreeChart38.getRenderingHints();
        boolean boolean43 = jFreeChart38.isNotify();
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer51 = null;
        java.util.Collection collection52 = categoryPlot49.getRangeMarkers((int) '4', layer51);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer53 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries54 = null;
        java.util.TimeZone timeZone55 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection56 = new org.jfree.data.time.TimeSeriesCollection(timeSeries54, timeZone55);
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection56);
        org.jfree.data.Range range59 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection56, true);
        org.jfree.data.Range range60 = xYBarRenderer53.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection56);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent61 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot49, (org.jfree.data.general.Dataset) timeSeriesCollection56);
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo63 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource64 = null;
        chartRenderingInfo63.setRenderingSource(renderingSource64);
        java.awt.geom.Rectangle2D rectangle2D66 = chartRenderingInfo63.getChartArea();
        java.awt.geom.Point2D point2D67 = null;
        org.jfree.chart.plot.PlotState plotState68 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        categoryPlot49.draw(graphics2D62, rectangle2D66, point2D67, plotState68, plotRenderingInfo69);
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot71.setRangeMinorGridlinesVisible(false);
        java.awt.Stroke stroke74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        categoryPlot71.setDomainGridlineStroke(stroke74);
        java.awt.Paint paint76 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.LegendItem legendItem77 = new org.jfree.chart.LegendItem("DateTickUnitType.DAY", "100", "June 2019", "Other", (java.awt.Shape) rectangle2D66, stroke74, paint76);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo78 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean80 = chartRenderingInfo78.equals((java.lang.Object) 0L);
        chartRenderingInfo78.clear();
        try {
            jFreeChart38.draw(graphics2D44, rectangle2D66, chartRenderingInfo78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(renderingHints41);
        org.junit.Assert.assertNotNull(renderingHints42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertNull(range59);
        org.junit.Assert.assertNull(range60);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.lang.Boolean boolean13 = xYBarRenderer0.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis14);
        combinedDomainXYPlot15.setRangeCrosshairValue(0.0d);
        combinedDomainXYPlot15.setDomainMinorGridlinesVisible(true);
        xYBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot15);
        combinedDomainXYPlot15.setDomainZeroBaselineVisible(false);
        combinedDomainXYPlot15.setGap(1.0d);
        java.util.List list25 = combinedDomainXYPlot15.getSubplots();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot27.getRangeMarkers((int) '4', layer29);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries32 = null;
        java.util.TimeZone timeZone33 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection34 = new org.jfree.data.time.TimeSeriesCollection(timeSeries32, timeZone33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection34);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection34, true);
        org.jfree.data.Range range38 = xYBarRenderer31.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot27, (org.jfree.data.general.Dataset) timeSeriesCollection34);
        java.awt.Stroke stroke40 = categoryPlot27.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot27.getRangeAxisLocation();
        combinedDomainXYPlot15.setDomainAxisLocation((int) '4', axisLocation41, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot47 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis46);
        combinedDomainXYPlot47.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = combinedDomainXYPlot47.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder51 = combinedDomainXYPlot47.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double54 = rectangleInsets52.calculateRightInset(0.0d);
        double double56 = rectangleInsets52.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot47.setAxisOffset(rectangleInsets52);
        java.awt.Stroke stroke58 = combinedDomainXYPlot47.getDomainMinorGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        java.lang.String[] strArray62 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis63 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray62);
        java.lang.Object obj64 = symbolAxis63.clone();
        symbolAxis63.setRangeWithMargins(0.05d, (double) 1560495599999L);
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = categoryAxis69.getTickLabelInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo71 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource72 = null;
        chartRenderingInfo71.setRenderingSource(renderingSource72);
        java.awt.geom.Rectangle2D rectangle2D74 = chartRenderingInfo71.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D77 = rectangleInsets70.createInsetRectangle(rectangle2D74, false, false);
        java.awt.Shape shape78 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D74);
        org.jfree.chart.axis.AxisState axisState79 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = null;
        axisState79.moveCursor((double) 0, rectangleEdge81);
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState79.moveCursor((double) 100L, rectangleEdge84);
        double double86 = symbolAxis63.java2DToValue((double) 1577894400001L, rectangle2D74, rectangleEdge84);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor87 = null;
        java.awt.geom.Point2D point2D88 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D74, rectangleAnchor87);
        combinedDomainXYPlot47.panRangeAxes((double) (-57600000L), plotRenderingInfo60, point2D88);
        try {
            combinedDomainXYPlot15.zoomRangeAxes((double) 43629L, plotRenderingInfo45, point2D88, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(datasetRenderingOrder51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 4.0d + "'", double54 == 4.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 4.0d + "'", double56 == 4.0d);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(strArray62);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertNotNull(shape78);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + Double.POSITIVE_INFINITY + "'", double86 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(point2D88);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        boolean boolean10 = intervalXYDelegate9.isAutoWidth();
        intervalXYDelegate9.setIntervalPositionFactor(0.0d);
        double double13 = intervalXYDelegate9.getFixedIntervalWidth();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        boolean boolean12 = combinedDomainXYPlot1.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint15 = xYBarRenderer14.getBaseOutlinePaint();
        java.awt.Shape shape21 = null;
        java.awt.Paint paint23 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape28 = null;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color32 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape21, false, paint23, false, (java.awt.Paint) color25, stroke26, true, shape28, stroke29, (java.awt.Paint) color32);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(0.0d, paint15, stroke29);
        double double35 = valueMarker34.getValue();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType36 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.entity.EntityCollection entityCollection37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo(entityCollection37);
        boolean boolean39 = chartChangeEventType36.equals((java.lang.Object) entityCollection37);
        java.lang.String str40 = chartChangeEventType36.toString();
        boolean boolean41 = valueMarker34.equals((java.lang.Object) chartChangeEventType36);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer44 = null;
        org.jfree.chart.plot.PolarPlot polarPlot45 = new org.jfree.chart.plot.PolarPlot(xYDataset42, valueAxis43, polarItemRenderer44);
        polarPlot45.setNoDataMessage("ThreadContext");
        java.awt.Paint paint48 = polarPlot45.getRadiusGridlinePaint();
        valueMarker34.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot45);
        boolean boolean50 = combinedDomainXYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker34);
        java.lang.Object obj51 = combinedDomainXYPlot1.clone();
        combinedDomainXYPlot1.setRangeMinorGridlinesVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str40.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(obj51);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        float float5 = polarPlot4.getBackgroundImageAlpha();
        xYBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot4);
        boolean boolean7 = xYBarRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape12 = null;
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendTitle14.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint17 = xYBarRenderer16.getBaseOutlinePaint();
        java.awt.Paint paint18 = xYBarRenderer16.getBasePaint();
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer16.setSeriesItemLabelPaint(1, paint20);
        legendTitle14.setBackgroundPaint(paint20);
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("October", "DateTickUnitType.DAY", "", "", shape12, paint20);
        xYBarRenderer0.setBaseOutlinePaint(paint20);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1), 12.0d, (double) '#', (double) 1577894400005L);
        double double6 = rectangleInsets4.calculateLeftOutset((double) 0.5f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.0d + "'", double6 == 12.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        boolean boolean3 = multiplePiePlot1.isOutlineVisible();
        multiplePiePlot1.setBackgroundAlpha((float) 15);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test428");
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        java.awt.Paint paint1 = xYBarRenderer0.getBaseOutlinePaint();
//        java.awt.Paint paint2 = xYBarRenderer0.getBasePaint();
//        java.awt.Font font4 = xYBarRenderer0.getSeriesItemLabelFont((int) (byte) 0);
//        boolean boolean5 = xYBarRenderer0.getShadowsVisible();
//        java.awt.Font font7 = xYBarRenderer0.lookupLegendTextFont(0);
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        java.awt.Paint paint10 = xYBarRenderer9.getBaseOutlinePaint();
//        java.awt.Shape shape16 = null;
//        java.awt.Paint paint18 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
//        java.awt.Color color20 = java.awt.Color.YELLOW;
//        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        java.awt.Shape shape23 = null;
//        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        java.awt.Color color27 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
//        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape16, false, paint18, false, (java.awt.Paint) color20, stroke21, true, shape23, stroke24, (java.awt.Paint) color27);
//        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.0d, paint10, stroke24);
//        xYBarRenderer0.setBaseLegendTextPaint(paint10);
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        java.awt.Paint paint32 = xYBarRenderer31.getBaseItemLabelPaint();
//        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter33 = xYBarRenderer31.getBarPainter();
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = xYBarRenderer31.getNegativeItemLabelPosition((int) (byte) 100, (-1), true);
//        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition37);
//        org.junit.Assert.assertNotNull(paint1);
//        org.junit.Assert.assertNotNull(paint2);
//        org.junit.Assert.assertNull(font4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNull(font7);
//        org.junit.Assert.assertNotNull(paint10);
//        org.junit.Assert.assertNotNull(paint18);
//        org.junit.Assert.assertNotNull(color20);
//        org.junit.Assert.assertNotNull(stroke21);
//        org.junit.Assert.assertNotNull(stroke24);
//        org.junit.Assert.assertNotNull(color27);
//        org.junit.Assert.assertNotNull(paint32);
//        org.junit.Assert.assertNotNull(xYBarPainter33);
//        org.junit.Assert.assertNotNull(itemLabelPosition37);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("SerialDate.weekInMonthToString(): invalid code.");
        logAxis1.zoomRange(0.2d, (double) 10);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        java.lang.Object obj1 = xYSeriesCollection0.clone();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        combinedDomainXYPlot3.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = combinedDomainXYPlot3.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = combinedDomainXYPlot3.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace8 = combinedDomainXYPlot3.getFixedRangeAxisSpace();
        combinedDomainXYPlot3.setDomainCrosshairValue(0.0d, false);
        org.jfree.chart.axis.AxisSpace axisSpace12 = combinedDomainXYPlot3.getFixedDomainAxisSpace();
        xYSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) combinedDomainXYPlot3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = combinedDomainXYPlot3.getRangeAxisForDataset(0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(valueAxis15);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke6 = xYPlot5.getDomainMinorGridlineStroke();
        combinedDomainXYPlot1.setRangeMinorGridlineStroke(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-2));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.awt.Shape shape17 = null;
        java.awt.Paint paint19 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color21 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color28 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape17, false, paint19, false, (java.awt.Paint) color21, stroke22, true, shape24, stroke25, (java.awt.Paint) color28);
        java.lang.Object obj30 = null;
        boolean boolean31 = legendItem29.equals(obj30);
        java.awt.Paint paint32 = legendItem29.getFillPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape10, paint32);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendGraphic33.setShapeAnchor(rectangleAnchor34);
        legendGraphic33.setShapeVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setCopyright("item");
        java.lang.String str3 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "LGPL" + "'", str3.equals("LGPL"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint3 = categoryAxis3D1.getTickLabelPaint((java.lang.Comparable) "HorizontalAlignment.LEFT");
        boolean boolean4 = gradientBarPainter0.equals((java.lang.Object) "HorizontalAlignment.LEFT");
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setAnchorX((double) 0.5f);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint7 = xYBarRenderer6.getBaseOutlinePaint();
        java.awt.Shape shape13 = null;
        java.awt.Paint paint15 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color17 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color24 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape13, false, paint15, false, (java.awt.Paint) color17, stroke18, true, shape20, stroke21, (java.awt.Paint) color24);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d, paint7, stroke21);
        double double27 = valueMarker26.getValue();
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = categoryPlot3.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker26, layer28, false);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        categoryPlot3.setFixedLegendItems(legendItemCollection31);
        categoryPlot3.clearRangeMarkers(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D38 = xYPlot37.getQuadrantOrigin();
        categoryPlot3.zoomRangeAxes((double) 43629L, plotRenderingInfo36, point2D38);
        crosshairState0.setAnchor(point2D38);
        crosshairState0.updateCrosshairY(0.2d, (int) (byte) 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(point2D38);
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test437");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.chart.LegendItemSource legendItemSource1 = null;
//        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
//        double double3 = legendTitle2.getHeight();
//        legendTitle2.setPadding((double) 11, (double) 1577894400005L, (double) 9999, (double) (short) -1);
//        boolean boolean9 = legendTitle2.isVisible();
//        int int10 = day0.compareTo((java.lang.Object) boolean9);
//        long long11 = day0.getLastMillisecond();
//        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        java.awt.Paint paint16 = xYBarRenderer15.getBaseOutlinePaint();
//        java.awt.Shape shape22 = null;
//        java.awt.Paint paint24 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
//        java.awt.Color color26 = java.awt.Color.YELLOW;
//        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        java.awt.Shape shape29 = null;
//        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        java.awt.Color color33 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
//        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape22, false, paint24, false, (java.awt.Paint) color26, stroke27, true, shape29, stroke30, (java.awt.Paint) color33);
//        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(0.0d, paint16, stroke30);
//        double double36 = valueMarker35.getValue();
//        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
//        boolean boolean39 = categoryPlot12.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker35, layer37, false);
//        org.jfree.chart.LegendItemCollection legendItemCollection40 = null;
//        categoryPlot12.setFixedLegendItems(legendItemCollection40);
//        categoryPlot12.clearRangeMarkers(1);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
//        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
//        java.awt.geom.Point2D point2D47 = xYPlot46.getQuadrantOrigin();
//        categoryPlot12.zoomRangeAxes((double) 43629L, plotRenderingInfo45, point2D47);
//        boolean boolean49 = day0.equals((java.lang.Object) point2D47);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertNotNull(paint16);
//        org.junit.Assert.assertNotNull(paint24);
//        org.junit.Assert.assertNotNull(color26);
//        org.junit.Assert.assertNotNull(stroke27);
//        org.junit.Assert.assertNotNull(stroke30);
//        org.junit.Assert.assertNotNull(color33);
//        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
//        org.junit.Assert.assertNotNull(layer37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(point2D47);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        try {
            double double5 = timeSeriesCollection2.getXValue((int) '4', 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseOutlinePaint();
        java.awt.Paint paint2 = xYBarRenderer0.getBasePaint();
        java.awt.Font font4 = xYBarRenderer0.getSeriesItemLabelFont((int) (byte) 0);
        java.awt.Paint paint5 = xYBarRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (short) 1, xYToolTipGenerator7, true);
        org.jfree.chart.LegendItem legendItem12 = xYBarRenderer0.getLegendItem(0, (int) '#');
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(legendItem12);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        long long4 = segmentedTimeline0.toTimelineValue((long) 5);
        long long5 = segmentedTimeline0.getSegmentsGroupSize();
        long long6 = segmentedTimeline0.getSegmentsGroupSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577894400005L + "'", long4 == 1577894400005L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 604800000L + "'", long5 == 604800000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604800000L + "'", long6 == 604800000L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        float float6 = polarPlot5.getBackgroundImageAlpha();
        xYBarRenderer1.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        polarPlot5.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.entity.PlotEntity plotEntity12 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) polarPlot5, "", "AxisEntity: tooltip = ChartChangeEventType.DATASET_UPDATED");
        java.lang.Object obj13 = plotEntity12.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.5f + "'", float6 == 0.5f);
        org.junit.Assert.assertNotNull(obj13);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test442");
//        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
//        java.lang.String str2 = standardXYToolTipGenerator1.getFormatString();
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
//        java.awt.Paint paint5 = xYBarRenderer3.getBasePaint();
//        java.awt.Font font7 = xYBarRenderer3.getSeriesItemLabelFont((int) (byte) 0);
//        boolean boolean8 = xYBarRenderer3.getShadowsVisible();
//        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator10 = new org.jfree.chart.urls.StandardXYURLGenerator("Combined_Domain_XYPlot");
//        xYBarRenderer3.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator10);
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer(2019, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator10);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}: ({1}, {2})" + "'", str2.equals("{0}: ({1}, {2})"));
//        org.junit.Assert.assertNotNull(paint4);
//        org.junit.Assert.assertNotNull(paint5);
//        org.junit.Assert.assertNull(font7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 1, true, true);
        java.lang.Number number5 = null;
        xYSeries3.add((java.lang.Number) (byte) -1, number5);
        xYSeries3.add((double) 0L, (java.lang.Number) 1560457873763L, false);
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test444");
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        java.awt.Paint paint1 = xYBarRenderer0.getBaseOutlinePaint();
//        java.awt.Paint paint2 = xYBarRenderer0.getBasePaint();
//        java.awt.Font font4 = xYBarRenderer0.getSeriesItemLabelFont((int) (byte) 0);
//        boolean boolean5 = xYBarRenderer0.getShadowsVisible();
//        java.awt.Font font7 = xYBarRenderer0.lookupLegendTextFont(0);
//        boolean boolean11 = xYBarRenderer0.isItemLabelVisible(64, (-9999), true);
//        org.junit.Assert.assertNotNull(paint1);
//        org.junit.Assert.assertNotNull(paint2);
//        org.junit.Assert.assertNull(font4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNull(font7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.util.Date date3 = dateRange2.getLowerDate();
        long long4 = dateRange2.getUpperMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1, timeZone2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        timeSeriesCollection3.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("MAJOR", (org.jfree.chart.plot.Plot) polarPlot8);
        java.awt.Stroke stroke11 = polarPlot8.getAngleGridlineStroke();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 432000000L, (double) 1560457873763L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        java.lang.Object obj1 = xYSeriesCollection0.clone();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        combinedDomainXYPlot3.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = combinedDomainXYPlot3.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = combinedDomainXYPlot3.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace8 = combinedDomainXYPlot3.getFixedRangeAxisSpace();
        combinedDomainXYPlot3.setDomainCrosshairValue(0.0d, false);
        org.jfree.chart.axis.AxisSpace axisSpace12 = combinedDomainXYPlot3.getFixedDomainAxisSpace();
        xYSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) combinedDomainXYPlot3);
        java.awt.Paint paint14 = combinedDomainXYPlot3.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Paint paint5 = xYBarRenderer3.getBasePaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer3.setSeriesItemLabelPaint(1, paint7);
        legendTitle1.setBackgroundPaint(paint7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = legendTitle1.getHorizontalAlignment();
        java.lang.String str11 = legendTitle1.getID();
        legendTitle1.setID("[100.0, -1.0]");
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource5 = null;
        chartRenderingInfo4.setRenderingSource(renderingSource5);
        java.awt.geom.Rectangle2D rectangle2D7 = chartRenderingInfo4.getChartArea();
        org.jfree.chart.axis.AxisState axisState8 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        axisState8.moveCursor((double) 0, rectangleEdge10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisState8.moveCursor((double) 100L, rectangleEdge13);
        double double15 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor1, 10, (int) (short) 0, rectangle2D7, rectangleEdge13);
        java.awt.Shape shape16 = null;
        try {
            org.jfree.chart.entity.AxisLabelEntity axisLabelEntity19 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape16, "{0}: ({1}, {2})", "RectangleAnchor.BOTTOM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = xYBarRenderer2.getBaseItemLabelPaint();
        piePlot1.setLabelPaint(paint3);
        piePlot1.setAutoPopulateSectionOutlinePaint(false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        java.awt.Stroke stroke12 = combinedDomainXYPlot1.getDomainMinorGridlineStroke();
        boolean boolean14 = combinedDomainXYPlot1.equals((java.lang.Object) "AxisLocation.TOP_OR_RIGHT");
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer0.setShadowXOffset((double) (short) 100);
        java.awt.Stroke stroke8 = xYBarRenderer0.getItemOutlineStroke(64, 4, true);
        double double9 = xYBarRenderer0.getShadowXOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setTickMarksVisible(false);
        java.awt.Font font14 = categoryAxis11.getTickLabelFont();
        java.awt.Paint paint15 = categoryAxis11.getAxisLinePaint();
        xYBarRenderer0.setLegendTextPaint((int) '4', paint15);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        java.awt.Font font5 = polarPlot4.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.DATASET_UPDATED", font5);
        java.lang.String str7 = labelBlock6.getToolTipText();
        labelBlock6.setToolTipText("MAJOR");
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis10.getTickLabelInsets();
        double double13 = rectangleInsets11.trimWidth(4.0d);
        labelBlock6.setMargin(rectangleInsets11);
        java.lang.String str15 = rectangleInsets11.toString();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-4.0d) + "'", double13 == (-4.0d));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str15.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer0.setBaseLegendShape(shape10);
        java.awt.Shape shape17 = null;
        java.awt.Paint paint19 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color21 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color28 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape17, false, paint19, false, (java.awt.Paint) color21, stroke22, true, shape24, stroke25, (java.awt.Paint) color28);
        java.lang.Object obj30 = null;
        boolean boolean31 = legendItem29.equals(obj30);
        java.awt.Paint paint32 = legendItem29.getFillPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape10, paint32);
        java.awt.Shape shape34 = legendGraphic33.getShape();
        java.awt.Stroke stroke35 = legendGraphic33.getLineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot36.setRangeMinorGridlinesVisible(false);
        java.awt.Stroke stroke39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        categoryPlot36.setDomainGridlineStroke(stroke39);
        legendGraphic33.setOutlineStroke(stroke39);
        boolean boolean42 = legendGraphic33.isShapeFilled();
        java.awt.Paint paint43 = legendGraphic33.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNull(paint43);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot0.getDomainAxisEdge();
        double double29 = categoryPlot0.getRangeCrosshairValue();
        double double30 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        categoryPlot0.setRangeAxis(1, valueAxis32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.panRangeAxes((double) 3, plotRenderingInfo35, point2D36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener39 = null;
        jFreeChart38.addProgressListener(chartProgressListener39);
        java.awt.RenderingHints renderingHints41 = jFreeChart38.getRenderingHints();
        java.awt.RenderingHints renderingHints42 = jFreeChart38.getRenderingHints();
        boolean boolean43 = jFreeChart38.isNotify();
        jFreeChart38.setBackgroundImageAlignment((int) (byte) 0);
        java.awt.Paint paint46 = jFreeChart38.getBorderPaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(renderingHints41);
        org.junit.Assert.assertNotNull(renderingHints42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer3D0.getSeriesItemLabelGenerator(15);
        double double3 = barRenderer3D0.getItemMargin();
        boolean boolean5 = barRenderer3D0.isSeriesVisibleInLegend(7);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_CYAN;
        barRenderer3D0.setBasePaint((java.awt.Paint) color6, false);
        barRenderer3D0.setItemLabelAnchorOffset((double) 8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Shape shape10 = null;
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color14 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color21 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape10, false, paint12, false, (java.awt.Paint) color14, stroke15, true, shape17, stroke18, (java.awt.Paint) color21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, paint4, stroke18);
        double double24 = valueMarker23.getValue();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = categoryPlot0.removeRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker23, layer25, false);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot0.getFixedLegendItems();
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot0.setRangeZeroBaselineStroke(stroke29);
        java.awt.Paint paint31 = null;
        try {
            categoryPlot0.setRangeZeroBaselinePaint(paint31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(legendItemCollection28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers((int) '4', layer2);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.setNoDataMessage("");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer7.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer7.setShadowYOffset((double) 0L);
        java.awt.Stroke stroke12 = xYBarRenderer7.getBaseOutlineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke12);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape1);
        java.lang.Object obj3 = chartEntity2.clone();
        java.awt.Shape shape4 = chartEntity2.getArea();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) shape4, jFreeChart5, (-460), (int) (byte) 100);
        int int9 = chartProgressEvent8.getPercent();
        chartProgressEvent8.setPercent((int) (byte) 10);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        java.lang.Comparable comparable3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeriesCollection2.getSeries(comparable3);
        timeSeriesCollection2.removeAllSeries();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long8 = segmentedTimeline6.getTimeFromLong(0L);
        java.util.List list9 = segmentedTimeline6.getExceptionSegments();
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (double) 100);
        double double13 = range12.getLength();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, list9, range12, false);
        org.jfree.data.Range range17 = org.jfree.data.Range.scale(range12, (double) '4');
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(timeSeries4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator7);
        java.awt.Shape shape14 = null;
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color25 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape14, false, paint16, false, (java.awt.Paint) color18, stroke19, true, shape21, stroke22, (java.awt.Paint) color25);
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem26.setLabelPaint(paint27);
        xYBarRenderer0.setBaseLegendTextPaint(paint27);
        boolean boolean30 = xYBarRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.LegendItem legendItem33 = xYBarRenderer0.getLegendItem(0, 0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(legendItem33);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot1.addChangeListener(plotChangeListener3);
        piePlot1.setCircular(true);
        double double7 = piePlot1.getStartAngle();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setRight(0.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        timeSeriesCollection2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeriesCollection2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        java.lang.Object obj11 = xYSeriesCollection10.clone();
        xYSeriesCollection10.removeAllSeries();
        timeSeriesCollection2.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection10);
        boolean boolean14 = xYSeriesCollection10.isAutoWidth();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (byte) 1);
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        combinedDomainXYPlot1.remove(xYPlot6);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        java.lang.String str1 = dateTickUnitType0.toString();
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'multiple' > 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnitType.DAY" + "'", str1.equals("DateTickUnitType.DAY"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(100.0f);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        categoryAxis0.setTickLabelPaint(paint3);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        java.awt.Font font5 = polarPlot4.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("ChartChangeEventType.DATASET_UPDATED", font5);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "DateTickUnitType.DAY", "ThreadContext", "");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeriesCollection11.getSeries((int) (byte) 0);
        boolean boolean14 = textLine6.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarksVisible(false);
        java.lang.Object obj3 = categoryAxis0.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        polarPlot3.datasetChanged(datasetChangeEvent5);
        java.awt.Font font7 = polarPlot3.getNoDataMessageFont();
        java.awt.Stroke stroke8 = polarPlot3.getRadiusGridlineStroke();
        org.jfree.chart.plot.Plot plot9 = polarPlot3.getRootPlot();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(plot9);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        boolean boolean3 = multiplePiePlot1.isOutlineVisible();
        java.lang.String str4 = multiplePiePlot1.getPlotType();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Multiple Pie Plot" + "'", str4.equals("Multiple Pie Plot"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        boolean boolean4 = dateRange2.contains(6.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test478");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getMonth();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBaseItemLabelPaint();
        boolean boolean5 = xYBarRenderer0.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        java.awt.Shape shape6 = xYBarRenderer0.getBaseLegendShape();
        java.awt.Paint paint8 = xYBarRenderer0.getLegendTextPaint(6);
        boolean boolean9 = xYBarRenderer0.getBaseSeriesVisibleInLegend();
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        try {
            xYBarRenderer0.setSeriesNegativeItemLabelPosition((-8355840), itemLabelPosition13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint5 = xYBarRenderer4.getBaseItemLabelPaint();
        boolean boolean9 = xYBarRenderer4.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYBarRenderer4.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator11);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer4.setBaseLegendShape(shape14);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = xYBarRenderer4.getBaseToolTipGenerator();
        java.awt.Paint paint20 = xYBarRenderer4.getItemOutlinePaint((int) (short) 1, 28, true);
        xYBarRenderer4.setMargin((double) 4);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 100);
        xYBarRenderer4.setBaseShape(shape24, false);
        java.awt.Paint paint27 = null;
        try {
            org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("[100.0, -1.0]", "java.awt.Color[r=0,g=0,b=0]", "PlotOrientation.HORIZONTAL", "-1", shape24, paint27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(xYToolTipGenerator16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        boolean boolean12 = combinedDomainXYPlot1.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke13 = combinedDomainXYPlot1.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint16 = xYBarRenderer15.getBaseOutlinePaint();
        java.awt.Shape shape22 = null;
        java.awt.Paint paint24 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color26 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape29 = null;
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color33 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape22, false, paint24, false, (java.awt.Paint) color26, stroke27, true, shape29, stroke30, (java.awt.Paint) color33);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(0.0d, paint16, stroke30);
        combinedDomainXYPlot1.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker35);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint4 = xYBarRenderer3.getBaseOutlinePaint();
        java.awt.Paint paint5 = xYBarRenderer3.getBasePaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYBarRenderer3.setSeriesItemLabelPaint(1, paint7);
        legendTitle1.setBackgroundPaint(paint7);
        boolean boolean10 = legendTitle1.isVisible();
        org.jfree.chart.block.BlockContainer blockContainer11 = null;
        legendTitle1.setWrapper(blockContainer11);
        legendTitle1.visible = false;
        org.jfree.chart.event.TitleChangeListener titleChangeListener15 = null;
        legendTitle1.addChangeListener(titleChangeListener15);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test483");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.xy.XYDataset xYDataset2 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
//        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
//        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
//        boolean boolean6 = polarPlot5.isAngleLabelsVisible();
//        polarPlot5.setAngleLabelsVisible(true);
//        int int9 = day0.compareTo((java.lang.Object) polarPlot5);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day0.getLastMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape1);
        java.lang.Object obj3 = chartEntity2.clone();
        java.awt.Shape shape4 = chartEntity2.getArea();
        java.awt.Shape shape5 = chartEntity2.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer3.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer3.setShadowYOffset((double) 0L);
        xYBarRenderer3.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer3.setBaseOutlinePaint((java.awt.Paint) color10);
        boolean boolean12 = rectangleEdge2.equals((java.lang.Object) xYBarRenderer3);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray1);
        java.lang.Object obj3 = symbolAxis2.clone();
        org.jfree.data.RangeType rangeType4 = org.jfree.data.RangeType.POSITIVE;
        java.lang.Object obj5 = null;
        boolean boolean6 = rangeType4.equals(obj5);
        symbolAxis2.setRangeType(rangeType4);
        java.lang.Object obj8 = null;
        boolean boolean9 = symbolAxis2.equals(obj8);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        java.lang.String str13 = numberTickUnit11.valueToString((double) 100L);
        symbolAxis2.setTickUnit(numberTickUnit11, false, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer17.setAutoPopulateSeriesOutlinePaint(true);
        xYBarRenderer17.setShadowYOffset((double) 0L);
        xYBarRenderer17.setDefaultEntityRadius((int) (short) 1);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYBarRenderer17.setBaseOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = xYBarRenderer17.getBasePositiveItemLabelPosition();
        boolean boolean27 = symbolAxis2.equals((java.lang.Object) xYBarRenderer17);
        boolean boolean28 = xYBarRenderer17.getUseYInterval();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        java.awt.Font font6 = polarPlot5.getNoDataMessageFont();
        org.jfree.chart.entity.PlotEntity plotEntity7 = new org.jfree.chart.entity.PlotEntity(shape1, (org.jfree.chart.plot.Plot) polarPlot5);
        java.lang.String str8 = plotEntity7.toString();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PlotEntity: tooltip = null" + "'", str8.equals("PlotEntity: tooltip = null"));
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test488");
//        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.xy.XYDataset xYDataset4 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
//        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
//        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
//        boolean boolean8 = polarPlot7.isAngleLabelsVisible();
//        polarPlot7.setAngleLabelsVisible(true);
//        int int11 = day2.compareTo((java.lang.Object) polarPlot7);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.util.Date date13 = month12.getStart();
//        java.util.Date date14 = month12.getEnd();
//        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) month12);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        int int18 = day16.getMonth();
//        long long19 = day16.getSerialIndex();
//        periodAxis15.setLast((org.jfree.data.time.RegularTimePeriod) day16);
//        boolean boolean21 = strokeMap0.containsKey((java.lang.Comparable) day16);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer3D0.getSeriesItemLabelGenerator(15);
        double double3 = barRenderer3D0.getMinimumBarLength();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer3D0.getSeriesToolTipGenerator(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator6, false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setRangeMinorGridlinesVisible(false);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        categoryPlot3.setDomainGridlineStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 0.5f, paint2, stroke6);
        xYPlot0.setRangeCrosshairStroke(stroke6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle10 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot11.getRangeMarkers((int) '4', layer13);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeries timeSeries16 = null;
        java.util.TimeZone timeZone17 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeSeries16, timeZone17);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection18, true);
        org.jfree.data.Range range22 = xYBarRenderer15.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryPlot11, (org.jfree.data.general.Dataset) timeSeriesCollection18);
        java.awt.Stroke stroke24 = categoryPlot11.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot11.getRangeAxisLocation();
        boolean boolean26 = pieLabelLinkStyle10.equals((java.lang.Object) categoryPlot11);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint29 = xYBarRenderer28.getBaseOutlinePaint();
        java.awt.Shape shape35 = null;
        java.awt.Paint paint37 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color39 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape42 = null;
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color46 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape35, false, paint37, false, (java.awt.Paint) color39, stroke40, true, shape42, stroke43, (java.awt.Paint) color46);
        org.jfree.chart.plot.ValueMarker valueMarker48 = new org.jfree.chart.plot.ValueMarker(0.0d, paint29, stroke43);
        float float49 = valueMarker48.getAlpha();
        java.awt.Stroke stroke50 = valueMarker48.getStroke();
        categoryPlot11.setRangeGridlineStroke(stroke50);
        xYPlot0.setRangeCrosshairStroke(stroke50);
        boolean boolean53 = xYPlot0.canSelectByRegion();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle10);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 1.0f + "'", float49 == 1.0f);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Stroke stroke3 = piePlot2.getLabelLinkStroke();
        java.awt.Font font4 = piePlot2.getLabelFont();
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("PlotOrientation.HORIZONTAL", font4, paint5);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint8 = xYBarRenderer7.getBaseItemLabelPaint();
        boolean boolean12 = xYBarRenderer7.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        xYBarRenderer7.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator14);
        java.awt.Shape shape21 = null;
        java.awt.Paint paint23 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape28 = null;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color32 = java.awt.Color.getColor("ThreadContext", (int) (byte) 10);
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("ThreadContext", "hi!", "ThreadContext", "ThreadContext", true, shape21, false, paint23, false, (java.awt.Paint) color25, stroke26, true, shape28, stroke29, (java.awt.Paint) color32);
        java.awt.Paint paint34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem33.setLabelPaint(paint34);
        xYBarRenderer7.setBaseLegendTextPaint(paint34);
        java.awt.Stroke stroke38 = xYBarRenderer7.lookupSeriesOutlineStroke((int) (byte) 100);
        boolean boolean39 = textLine6.equals((java.lang.Object) stroke38);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedDomainXYPlot1.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = combinedDomainXYPlot1.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateRightInset(0.0d);
        double double10 = rectangleInsets6.calculateLeftInset((double) 1577894400005L);
        combinedDomainXYPlot1.setAxisOffset(rectangleInsets6);
        java.lang.String str12 = combinedDomainXYPlot1.getPlotType();
        java.lang.String[] strArray14 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis15 = new org.jfree.chart.axis.SymbolAxis("RectangleConstraintType.RANGE", strArray14);
        java.lang.Object obj16 = symbolAxis15.clone();
        symbolAxis15.setRangeWithMargins(0.05d, (double) 1560495599999L);
        combinedDomainXYPlot1.setRangeAxis((org.jfree.chart.axis.ValueAxis) symbolAxis15);
        java.text.NumberFormat numberFormat21 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str23 = numberFormat21.format((-1.0d));
        boolean boolean24 = symbolAxis15.equals((java.lang.Object) (-1.0d));
        double double25 = symbolAxis15.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Combined_Domain_XYPlot" + "'", str12.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(numberFormat21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "-1" + "'", str23.equals("-1"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0E-8d + "'", double25 == 1.0E-8d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RectangleEdge.BOTTOM");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RectangleEdge.BOTTOM, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = xYBarRenderer1.getBaseItemLabelPaint();
        boolean boolean6 = xYBarRenderer1.getItemCreateEntity((int) (byte) 10, (int) (short) 10, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYBarRenderer1.setSeriesToolTipGenerator((int) (byte) 100, xYToolTipGenerator8);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        xYBarRenderer1.setBaseLegendShape(shape11);
        java.lang.Boolean boolean14 = xYBarRenderer1.getSeriesVisibleInLegend((int) (byte) 0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation15 = null;
        boolean boolean16 = xYBarRenderer1.removeAnnotation(xYAnnotation15);
        boolean boolean17 = plotOrientation0.equals((java.lang.Object) boolean16);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 100);
        double double4 = range3.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range8, (double) 10.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = rectangleConstraint10.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '4', range3, lengthConstraintType5, (double) 12, range7, lengthConstraintType11);
        double double13 = range3.getLowerBound();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) (short) 100);
        boolean boolean5 = segment2.contains((long) 11, 0L);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segment2.intersect(1577894400005L, (long) 128);
        segment2.dec((long) 1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segmentedTimeline11.getSegment((long) (short) 100);
        long long14 = segment13.getSegmentCount();
        long long15 = segment13.getSegmentCount();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment18 = segmentedTimeline16.getSegment((long) (short) 100);
        long long19 = segment18.getSegmentCount();
        segment18.dec();
        boolean boolean21 = segment13.contains(segment18);
        boolean boolean22 = segment2.contains(segment13);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(segment8);
        org.junit.Assert.assertNotNull(segmentedTimeline11);
        org.junit.Assert.assertNotNull(segment13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertNotNull(segmentedTimeline16);
        org.junit.Assert.assertNotNull(segment18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = state1.getEntityCollection();
        java.awt.geom.Line2D line2D3 = state1.workingLine;
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        java.util.TimeZone timeZone5 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4, timeZone5);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6, true);
        org.jfree.data.general.DatasetGroup datasetGroup10 = timeSeriesCollection6.getGroup();
        timeSeriesCollection6.removeAllSeries();
        state1.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection6);
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertNotNull(line2D3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(datasetGroup10);
    }
}

