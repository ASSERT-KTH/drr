import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) 10, (java.lang.Number) 2, (java.lang.Number) 1.0E-8d, (java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 10L, (java.lang.Number) (short) 100, (java.lang.Number) 15, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getQ3();
        java.lang.Number number11 = boxAndWhiskerItem9.getMean();
        java.lang.Number number12 = boxAndWhiskerItem9.getMaxOutlier();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0d + "'", number10.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 10 + "'", number11.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 15 + "'", number12.equals(15));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D((double) 10L, (-1.0d));
        size2D4.setHeight((double) 10L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, 0.0d, (double) (-1L), rectangleAnchor9);
        java.awt.geom.Point2D point2D11 = null;
        org.jfree.chart.plot.PlotState plotState12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            multiplePiePlot0.draw(graphics2D1, rectangle2D10, point2D11, plotState12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "First" + "'", str1.equals("First"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("CategoryAnchor.MIDDLE");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str5 = dateAxis4.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis4.setTickMarkPosition(dateTickMarkPosition6);
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat12);
        java.util.Date date14 = dateAxis4.calculateHighestVisibleTickValue(dateTickUnit13);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis17.setAutoRangeStickyZero(false);
        java.awt.Paint paint20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis17.setTickMarkPaint(paint20);
        java.lang.Class<?> wildcardClass22 = paint20.getClass();
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass22);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline24 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int25 = segmentedTimeline24.getSegmentsExcluded();
        long long26 = segmentedTimeline24.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str30 = dateRange29.toString();
        java.util.Date date31 = dateRange29.getLowerDate();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str35 = dateRange34.toString();
        java.util.Date date36 = dateRange34.getLowerDate();
        boolean boolean37 = segmentedTimeline24.containsDomainRange(date31, date36);
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date31, timeZone38);
        org.jfree.data.gantt.Task task40 = new org.jfree.data.gantt.Task("({0}, {1}) = {2}", date14, date31);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) (-1));
        task40.setDuration((org.jfree.data.time.TimePeriod) simpleTimePeriod43);
        taskSeries1.add(task40);
        try {
            org.jfree.data.gantt.Task task47 = task40.getSubtask((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNotNull(segmentedTimeline24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 68 + "'", int25 == 68);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 86400000L + "'", long26 == 86400000L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str30.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str35.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(regularTimePeriod39);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = intervalBarRenderer0.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = intervalBarRenderer0.getItemLabelGenerator(4, 0);
        double double7 = intervalBarRenderer0.getBase();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) (short) -1);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 255);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 100);
        defaultKeyedValues2D1.clear();
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot24.getOrientation();
        categoryPlot24.zoom((double) 100);
        float float33 = categoryPlot24.getBackgroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot24.getDomainAxisLocation(35);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("hi!", font1, paint7, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean14 = intervalBarRenderer11.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font16 = null;
        intervalBarRenderer11.setSeriesItemLabelFont((int) '4', font16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener22 = null;
        numberAxis21.addChangeListener(axisChangeListener22);
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        intervalBarRenderer11.drawRangeMarker(graphics2D18, categoryPlot19, (org.jfree.chart.axis.ValueAxis) numberAxis21, marker24, rectangle2D25);
        boolean boolean27 = textFragment10.equals((java.lang.Object) graphics2D18);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer35 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint38 = intervalBarRenderer35.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.block.BlockBorder blockBorder39 = new org.jfree.chart.block.BlockBorder((double) (short) 1, (double) 1, (double) 10, (double) 0, paint38);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str42 = dateAxis41.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition43 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis41.setTickMarkPosition(dateTickMarkPosition43);
        java.text.DateFormat dateFormat49 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit50 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat49);
        java.util.Date date51 = dateAxis41.calculateHighestVisibleTickValue(dateTickUnit50);
        org.jfree.chart.text.TextAnchor textAnchor55 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor56 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick58 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0, "hi!", textAnchor55, textAnchor56, (double) 4);
        org.jfree.chart.text.TextAnchor textAnchor59 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.DateTick dateTick61 = new org.jfree.chart.axis.DateTick(date51, "hi!", textAnchor56, textAnchor59, (double) 2958465);
        boolean boolean62 = blockBorder39.equals((java.lang.Object) textAnchor59);
        try {
            textFragment10.draw(graphics2D28, 0.0f, (float) 10, textAnchor59, (float) 900000L, (float) 86400000L, 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(dateTickMarkPosition43);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(textAnchor55);
        org.junit.Assert.assertNotNull(textAnchor56);
        org.junit.Assert.assertNotNull(textAnchor59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat7 = numberAxis2.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis2.getTickLabelInsets();
        waferMapPlot0.setInsets(rectangleInsets8);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer10 = null;
        waferMapPlot0.setRenderer(waferMapRenderer10);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (-1), 12.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "", font2);
        double double4 = categoryAxis0.getFixedDimension();
        java.lang.Object obj5 = null;
        boolean boolean6 = categoryAxis0.equals(obj5);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
        java.lang.String str10 = projectInfo7.getInfo();
        org.jfree.chart.ui.Library[] libraryArray11 = projectInfo7.getOptionalLibraries();
        java.lang.String str12 = projectInfo7.getLicenceName();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(libraryArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("pink", font1, (java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        boolean boolean25 = intervalBarRenderer8.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape28 = intervalBarRenderer8.getItemShape((int) (byte) 0, (int) ' ');
        intervalBarRenderer8.setSeriesItemLabelsVisible(0, true);
        intervalBarRenderer8.setBaseSeriesVisibleInLegend(false, true);
        intervalBarRenderer8.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false, false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(shape28);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 255, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        xYPlot9.setDomainAxisLocation((int) '#', axisLocation21);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis24.setAutoRangeStickyZero(false);
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis24);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot9.getRangeAxisForDataset(68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke1 = intervalBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = intervalBarRenderer0.getSeriesItemLabelGenerator((int) (short) 10);
        intervalBarRenderer0.setMaximumBarWidth((double) 2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = intervalBarRenderer0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        try {
            java.awt.Color color1 = java.awt.Color.decode("TextAnchor.BASELINE_CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"TextAnchor.BASELINE_CENTER\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        numberAxis1.setTickLabelPaint(paint7);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis16.setAutoRangeStickyZero(false);
        numberAxis16.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean24 = intervalBarRenderer21.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font26 = null;
        intervalBarRenderer21.setSeriesItemLabelFont((int) '4', font26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener32 = null;
        numberAxis31.addChangeListener(axisChangeListener32);
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        intervalBarRenderer21.drawRangeMarker(graphics2D28, categoryPlot29, (org.jfree.chart.axis.ValueAxis) numberAxis31, marker34, rectangle2D35);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer21);
        categoryPlot37.configureRangeAxes();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        org.jfree.chart.axis.AxisSpace axisSpace42 = numberAxis1.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) categoryPlot37, rectangle2D39, rectangleEdge40, axisSpace41);
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis46.setAutoRangeStickyZero(false);
        numberAxis46.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer51 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean54 = intervalBarRenderer51.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font56 = null;
        intervalBarRenderer51.setSeriesItemLabelFont((int) '4', font56);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = null;
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener62 = null;
        numberAxis61.addChangeListener(axisChangeListener62);
        org.jfree.chart.plot.Marker marker64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        intervalBarRenderer51.drawRangeMarker(graphics2D58, categoryPlot59, (org.jfree.chart.axis.ValueAxis) numberAxis61, marker64, rectangle2D65);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) numberAxis46, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer51);
        double double68 = categoryPlot67.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation69 = categoryPlot67.getDomainAxisLocation();
        java.awt.Paint paint70 = categoryPlot67.getNoDataMessagePaint();
        categoryPlot67.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation73 = categoryPlot67.getOrientation();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer74 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke76 = intervalBarRenderer74.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition78 = intervalBarRenderer74.getSeriesPositiveItemLabelPosition((int) '#');
        categoryPlot67.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer74);
        java.awt.Image image80 = categoryPlot67.getBackgroundImage();
        boolean boolean81 = axisSpace42.equals((java.lang.Object) image80);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(axisSpace42);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation69);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(plotOrientation73);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(itemLabelPosition78);
        org.junit.Assert.assertNull(image80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot24.rendererChanged(rendererChangeEvent30);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot24);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer34.setBaseItemLabelPaint(paint35);
        boolean boolean38 = intervalBarRenderer34.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer34.setBaseItemLabelFont(font39, false);
        categoryPlot24.setRenderer((int) (short) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer34, true);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator44 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str45 = standardCategoryToolTipGenerator44.getLabelFormat();
        java.text.NumberFormat numberFormat46 = standardCategoryToolTipGenerator44.getNumberFormat();
        java.awt.Color color47 = java.awt.Color.WHITE;
        boolean boolean48 = standardCategoryToolTipGenerator44.equals((java.lang.Object) color47);
        intervalBarRenderer34.setBaseItemLabelPaint((java.awt.Paint) color47);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "({0}, {1}) = {2}" + "'", str45.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertNotNull(numberFormat46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", "hi!", shape4, (java.awt.Paint) color5);
        boolean boolean7 = legendItem6.isShapeOutlineVisible();
        int int8 = legendItem6.getDatasetIndex();
        java.awt.Paint paint9 = legendItem6.getLinePaint();
        boolean boolean10 = legendItem6.isShapeFilled();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = legendItem6.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer11);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font5 = null;
        intervalBarRenderer0.setSeriesItemLabelFont((int) '4', font5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener11 = null;
        numberAxis10.addChangeListener(axisChangeListener11);
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        intervalBarRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis10, marker13, rectangle2D14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis20.setAutoRangeStickyZero(false);
        numberAxis20.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer25 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean28 = intervalBarRenderer25.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font30 = null;
        intervalBarRenderer25.setSeriesItemLabelFont((int) '4', font30);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener36 = null;
        numberAxis35.addChangeListener(axisChangeListener36);
        org.jfree.chart.plot.Marker marker38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        intervalBarRenderer25.drawRangeMarker(graphics2D32, categoryPlot33, (org.jfree.chart.axis.ValueAxis) numberAxis35, marker38, rectangle2D39);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer25);
        double double42 = categoryPlot41.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation43 = categoryPlot41.getDomainAxisLocation();
        categoryPlot41.configureDomainAxes();
        int int45 = categoryPlot41.getWeight();
        java.awt.Stroke stroke46 = categoryPlot41.getRangeGridlineStroke();
        org.jfree.chart.util.Size2D size2D49 = new org.jfree.chart.util.Size2D((double) 10L, (-1.0d));
        size2D49.setHeight((double) 10L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D55 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D49, 0.0d, (double) (-1L), rectangleAnchor54);
        try {
            intervalBarRenderer0.drawOutline(graphics2D16, categoryPlot41, rectangle2D55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", "hi!", shape4, (java.awt.Paint) color5);
        boolean boolean7 = legendItem6.isShapeOutlineVisible();
        int int8 = legendItem6.getDatasetIndex();
        java.awt.Paint paint9 = legendItem6.getOutlinePaint();
        legendItem6.setSeriesKey((java.lang.Comparable) 'a');
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("magenta");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 900000L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        double double18 = dateAxis16.getLabelAngle();
        dateAxis16.setVisible(false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 255);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        int int5 = chartProgressEvent4.getPercent();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint14 = intervalBarRenderer11.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, paint14);
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("hi!", font8, paint14, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean21 = intervalBarRenderer18.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font23 = null;
        intervalBarRenderer18.setSeriesItemLabelFont((int) '4', font23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener29 = null;
        numberAxis28.addChangeListener(axisChangeListener29);
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        intervalBarRenderer18.drawRangeMarker(graphics2D25, categoryPlot26, (org.jfree.chart.axis.ValueAxis) numberAxis28, marker31, rectangle2D32);
        boolean boolean34 = textFragment17.equals((java.lang.Object) graphics2D25);
        java.awt.Font font35 = textFragment17.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis39.setAutoRangeStickyZero(false);
        numberAxis39.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean47 = intervalBarRenderer44.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font49 = null;
        intervalBarRenderer44.setSeriesItemLabelFont((int) '4', font49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener55 = null;
        numberAxis54.addChangeListener(axisChangeListener55);
        org.jfree.chart.plot.Marker marker57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        intervalBarRenderer44.drawRangeMarker(graphics2D51, categoryPlot52, (org.jfree.chart.axis.ValueAxis) numberAxis54, marker57, rectangle2D58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer44);
        org.jfree.chart.JFreeChart jFreeChart62 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", font35, (org.jfree.chart.plot.Plot) categoryPlot60, false);
        chartProgressEvent4.setChart(jFreeChart62);
        boolean boolean64 = jFreeChart62.isBorderVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo67 = null;
        try {
            jFreeChart62.handleClick(68, 0, chartRenderingInfo67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.LegendItem legendItem3 = lineRenderer3D0.getLegendItem((int) (short) 10, (int) (byte) 100);
        java.lang.Object obj4 = lineRenderer3D0.clone();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        java.text.DateFormat dateFormat7 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat7);
        boolean boolean10 = dateTickUnit8.equals((java.lang.Object) (short) -1);
        int int11 = dateTickUnit8.getUnit();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(35);
        try {
            java.lang.Number number14 = defaultKeyedValues2D1.getValue((java.lang.Comparable) dateTickUnit8, (java.lang.Comparable) 35);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 35");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer3.setBaseItemLabelPaint(paint4);
        boolean boolean7 = intervalBarRenderer3.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer3.setBaseItemLabelFont(font8, false);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font8, (java.awt.Paint) color11);
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("", font8);
        labelBlock13.setID("Category Plot");
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint22 = intervalBarRenderer19.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("", font18, paint22);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer24 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer24.setBaseItemLabelPaint(paint25);
        org.jfree.chart.text.TextLine textLine27 = new org.jfree.chart.text.TextLine("", font18, paint25);
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock13, (java.lang.Object) "");
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = null;
        try {
            labelBlock13.setPadding(rectangleInsets29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean6 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) paintArray5);
        try {
            java.lang.Number number9 = defaultBoxAndWhiskerCategoryDataset0.getQ3Value((int) (byte) 1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer7.setBaseItemLabelPaint(paint8);
        boolean boolean11 = intervalBarRenderer7.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer7.setBaseItemLabelFont(font12, false);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font12, (java.awt.Paint) color15);
        int int17 = color15.getAlpha();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryAxis18.setTickMarkStroke(stroke19);
        java.awt.Color color21 = java.awt.Color.darkGray;
        try {
            org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem(attributedString0, "LengthConstraintType.NONE", "TextAnchor.BASELINE_CENTER", "hi!", shape5, (java.awt.Paint) color15, stroke19, (java.awt.Paint) color21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        piePlot1.setExplodePercent((java.lang.Comparable) 0.4d, (double) 100L);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = piePlot1.getLabelDistributor();
        java.lang.String str7 = piePlot1.getPlotType();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis4.setAutoRangeStickyZero(false);
        numberAxis4.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis9, xYItemRenderer10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke14 = intervalBarRenderer12.lookupSeriesStroke(3);
        xYPlot11.setDomainGridlineStroke(stroke14);
        lineRenderer3D0.setSeriesOutlineStroke(3, stroke14, true);
        double double18 = lineRenderer3D0.getXOffset();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 12.0d + "'", double18 == 12.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        double double1 = boxAndWhiskerRenderer0.getItemMargin();
        boxAndWhiskerRenderer0.setItemMargin((double) (-1L));
        boolean boolean4 = boxAndWhiskerRenderer0.getFillBox();
        boolean boolean5 = boxAndWhiskerRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot24.setRangeAxisLocation(axisLocation26, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis31.setAutoRangeStickyZero(false);
        numberAxis31.setAutoRangeStickyZero(false);
        categoryPlot24.setRangeAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) numberAxis31, true);
        float float38 = numberAxis31.getTickMarkOutsideLength();
        java.awt.Shape shape39 = numberAxis31.getUpArrow();
        java.io.ObjectOutputStream objectOutputStream40 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape39, objectOutputStream40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 2.0f + "'", float38 == 2.0f);
        org.junit.Assert.assertNotNull(shape39);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(35);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getPreviousDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 10L, (-1.0d));
        double double3 = size2D2.width;
        size2D2.setWidth((double) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setWeight(10);
        xYPlot9.setRangeCrosshairValue((double) 4, true);
        float float23 = xYPlot9.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot9.getRangeAxisEdge((int) (short) 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        java.awt.Paint paint30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot24.setRangeGridlinePaint(paint30);
        categoryPlot24.setWeight((int) (byte) -1);
        org.jfree.chart.util.SortOrder sortOrder34 = categoryPlot24.getColumnRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(sortOrder34);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot24.rendererChanged(rendererChangeEvent30);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot24);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer34.setBaseItemLabelPaint(paint35);
        boolean boolean38 = intervalBarRenderer34.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer34.setBaseItemLabelFont(font39, false);
        categoryPlot24.setRenderer((int) (short) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer34, true);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str47 = dateAxis46.getLabelToolTip();
        java.awt.Shape shape48 = dateAxis46.getDownArrow();
        boolean boolean50 = dateAxis46.isHiddenValue((long) (byte) -1);
        categoryPlot24.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) dateAxis46);
        org.jfree.data.Range range52 = dateAxis46.getDefaultAutoRange();
        java.lang.String str53 = range52.toString();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Range[0.0,1.0]" + "'", str53.equals("Range[0.0,1.0]"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        categoryPlot24.configureDomainAxes();
        int int28 = categoryPlot24.getWeight();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot24.zoomDomainAxes((double) 100, (double) (-1L), plotRenderingInfo31, point2D32);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation34 = null;
        try {
            categoryPlot24.addAnnotation(categoryAnnotation34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        boolean boolean3 = lineBorder0.equals((java.lang.Object) (byte) 1);
        java.awt.Paint paint4 = lineBorder0.getPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtRight();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) 0);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Shape shape3 = piePlot2.getLegendItemShape();
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape3, (double) '#', 10.0f, (float) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = polarPlot0.getRenderer();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = polarPlot0.getOrientation();
        org.junit.Assert.assertNull(polarItemRenderer1);
        org.junit.Assert.assertNotNull(plotOrientation2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        segmentedTimeline0.addException(0L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int5 = segmentedTimeline4.getSegmentsExcluded();
        segmentedTimeline0.setBaseTimeline(segmentedTimeline4);
        long long7 = segmentedTimeline0.getSegmentsGroupSize();
        segmentedTimeline0.setAdjustForDaylightSaving(false);
        segmentedTimeline0.addException((long) (short) 0);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 68 + "'", int5 == 68);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = statisticalBarRenderer0.getSeriesPositiveItemLabelPosition(1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = itemLabelPosition2.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint5 = intervalBarRenderer2.getItemFillPaint(100, (int) 'a');
        stackedBarRenderer3D1.setWallPaint(paint5);
        java.awt.Stroke stroke8 = stackedBarRenderer3D1.getSeriesStroke(2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = stackedBarRenderer3D1.getURLGenerator(255, 1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(categoryURLGenerator11);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot24.getOrientation();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer31 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke33 = intervalBarRenderer31.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = intervalBarRenderer31.getSeriesPositiveItemLabelPosition((int) '#');
        categoryPlot24.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer31);
        float float37 = categoryPlot24.getBackgroundAlpha();
        java.util.List list38 = categoryPlot24.getAnnotations();
        java.awt.Stroke stroke39 = categoryPlot24.getDomainGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis42.setAutoRangeStickyZero(false);
        double double45 = numberAxis42.getUpperBound();
        numberAxis42.setLabelURL("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) numberAxis42, valueAxis48, xYItemRenderer49);
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis54.setAutoRangeStickyZero(false);
        numberAxis54.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer59 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean62 = intervalBarRenderer59.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font64 = null;
        intervalBarRenderer59.setSeriesItemLabelFont((int) '4', font64);
        java.awt.Graphics2D graphics2D66 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = null;
        org.jfree.chart.axis.NumberAxis numberAxis69 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener70 = null;
        numberAxis69.addChangeListener(axisChangeListener70);
        org.jfree.chart.plot.Marker marker72 = null;
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        intervalBarRenderer59.drawRangeMarker(graphics2D66, categoryPlot67, (org.jfree.chart.axis.ValueAxis) numberAxis69, marker72, rectangle2D73);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, (org.jfree.chart.axis.ValueAxis) numberAxis54, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer59);
        double double76 = categoryPlot75.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation77 = categoryPlot75.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent78 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot75);
        org.jfree.chart.util.Layer layer80 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection81 = categoryPlot75.getDomainMarkers((int) ' ', layer80);
        java.util.Collection collection82 = xYPlot50.getRangeMarkers(layer80);
        java.awt.Graphics2D graphics2D83 = null;
        java.awt.geom.Rectangle2D rectangle2D84 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo85 = null;
        xYPlot50.drawAnnotations(graphics2D83, rectangle2D84, plotRenderingInfo85);
        boolean boolean87 = xYPlot50.isRangeZeroBaselineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge88 = xYPlot50.getDomainAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation89 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot50.setOrientation(plotOrientation89);
        categoryPlot24.setOrientation(plotOrientation89);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 1.0f + "'", float37 == 1.0f);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(layer80);
        org.junit.Assert.assertNull(collection81);
        org.junit.Assert.assertNull(collection82);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(rectangleEdge88);
        org.junit.Assert.assertNotNull(plotOrientation89);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        java.awt.Font font3 = intervalMarker2.getLabelFont();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis6.setAutoRangeStickyZero(false);
        numberAxis6.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis6, valueAxis11, xYItemRenderer12);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke16 = intervalBarRenderer14.lookupSeriesStroke(3);
        xYPlot13.setDomainGridlineStroke(stroke16);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot13.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis20);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis26.setAutoRangeStickyZero(false);
        double double29 = numberAxis26.getUpperBound();
        xYPlot13.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis26, false);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot32 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis34.setAutoRangeStickyZero(false);
        numberAxis34.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat39 = numberAxis34.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = numberAxis34.getTickLabelInsets();
        waferMapPlot32.setInsets(rectangleInsets40);
        xYPlot13.setAxisOffset(rectangleInsets40);
        intervalMarker2.setLabelOffset(rectangleInsets40);
        double double44 = rectangleInsets40.getLeft();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNull(numberFormat39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 4.0d + "'", double44 == 4.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double2 = defaultBoxAndWhiskerCategoryDataset0.getRangeUpperBound(true);
        int int4 = defaultBoxAndWhiskerCategoryDataset0.getRowIndex((java.lang.Comparable) (short) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        int int8 = numberTickUnit6.compareTo((java.lang.Object) categoryLabelPositions7);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer9 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean12 = intervalBarRenderer9.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font14 = null;
        intervalBarRenderer9.setSeriesItemLabelFont((int) '4', font14);
        int int16 = numberTickUnit6.compareTo((java.lang.Object) '4');
        int int17 = defaultBoxAndWhiskerCategoryDataset0.getRowIndex((java.lang.Comparable) '4');
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        java.awt.Paint paint25 = intervalBarRenderer8.getBasePaint();
        intervalBarRenderer8.setItemMargin(2.0d);
        intervalBarRenderer8.setBaseItemLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis4.setAutoRangeStickyZero(false);
        numberAxis4.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis9, xYItemRenderer10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke14 = intervalBarRenderer12.lookupSeriesStroke(3);
        xYPlot11.setDomainGridlineStroke(stroke14);
        java.awt.Stroke stroke16 = xYPlot11.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot11.getDomainMarkers(2, layer18);
        xYPlot11.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        xYPlot11.setDomainAxisLocation((int) '#', axisLocation23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis26.setAutoRangeStickyZero(false);
        xYPlot11.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis26);
        boolean boolean30 = lineBorder0.equals((java.lang.Object) xYPlot11);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        double double4 = numberAxis1.getUpperBound();
        org.jfree.data.Range range5 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = numberAxis1.getTickUnit();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(numberTickUnit6);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(35, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        double double5 = numberAxis2.getUpperBound();
        numberAxis2.setLabelURL("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis8, xYItemRenderer9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis14.setAutoRangeStickyZero(false);
        numberAxis14.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean22 = intervalBarRenderer19.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font24 = null;
        intervalBarRenderer19.setSeriesItemLabelFont((int) '4', font24);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener30 = null;
        numberAxis29.addChangeListener(axisChangeListener30);
        org.jfree.chart.plot.Marker marker32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        intervalBarRenderer19.drawRangeMarker(graphics2D26, categoryPlot27, (org.jfree.chart.axis.ValueAxis) numberAxis29, marker32, rectangle2D33);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer19);
        double double36 = categoryPlot35.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot35.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent38 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection41 = categoryPlot35.getDomainMarkers((int) ' ', layer40);
        java.util.Collection collection42 = xYPlot10.getRangeMarkers(layer40);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        xYPlot10.drawAnnotations(graphics2D43, rectangle2D44, plotRenderingInfo45);
        boolean boolean47 = xYPlot10.isRangeZeroBaselineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = xYPlot10.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation49 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot10.setDomainAxisLocation(axisLocation49);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertNotNull(axisLocation49);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Number number2 = null;
        defaultKeyedValues0.addValue((java.lang.Comparable) 8.0d, number2);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer4 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean5 = defaultKeyedValues0.equals((java.lang.Object) boxAndWhiskerRenderer4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis9.setAutoRangeStickyZero(false);
        numberAxis9.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean17 = intervalBarRenderer14.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font19 = null;
        intervalBarRenderer14.setSeriesItemLabelFont((int) '4', font19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener25 = null;
        numberAxis24.addChangeListener(axisChangeListener25);
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        intervalBarRenderer14.drawRangeMarker(graphics2D21, categoryPlot22, (org.jfree.chart.axis.ValueAxis) numberAxis24, marker27, rectangle2D28);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer14);
        double double31 = categoryPlot30.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot30.getDomainAxisLocation();
        java.awt.Paint paint33 = categoryPlot30.getNoDataMessagePaint();
        categoryPlot30.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = categoryPlot30.getOrientation();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer37 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke39 = intervalBarRenderer37.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = intervalBarRenderer37.getSeriesPositiveItemLabelPosition((int) '#');
        categoryPlot30.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer37);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor43 = categoryPlot30.getDomainGridlinePosition();
        boxAndWhiskerRenderer4.setPlot(categoryPlot30);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis49.setAutoRangeStickyZero(false);
        numberAxis49.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer54 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean57 = intervalBarRenderer54.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font59 = null;
        intervalBarRenderer54.setSeriesItemLabelFont((int) '4', font59);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = null;
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener65 = null;
        numberAxis64.addChangeListener(axisChangeListener65);
        org.jfree.chart.plot.Marker marker67 = null;
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        intervalBarRenderer54.drawRangeMarker(graphics2D61, categoryPlot62, (org.jfree.chart.axis.ValueAxis) numberAxis64, marker67, rectangle2D68);
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, (org.jfree.chart.axis.ValueAxis) numberAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer54);
        double double71 = categoryPlot70.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation72 = categoryPlot70.getDomainAxisLocation();
        java.awt.Paint paint73 = categoryPlot70.getNoDataMessagePaint();
        categoryPlot70.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent76 = null;
        categoryPlot70.rendererChanged(rendererChangeEvent76);
        org.jfree.chart.util.Size2D size2D80 = new org.jfree.chart.util.Size2D((double) 10L, (-1.0d));
        size2D80.setHeight((double) 10L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor85 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D86 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D80, 0.0d, (double) (-1L), rectangleAnchor85);
        try {
            boxAndWhiskerRenderer4.drawDomainGridline(graphics2D45, categoryPlot70, rectangle2D86, 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(plotOrientation36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(itemLabelPosition41);
        org.junit.Assert.assertNotNull(categoryAnchor43);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation72);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(rectangleAnchor85);
        org.junit.Assert.assertNotNull(rectangle2D86);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(8.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        double double18 = dateAxis16.getLabelAngle();
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str22 = dateRange21.toString();
        java.util.Date date23 = dateRange21.getLowerDate();
        java.util.Date date24 = null;
        try {
            dateAxis16.setRange(date23, date24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str22.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis29.setAutoRangeStickyZero(false);
        numberAxis29.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean37 = intervalBarRenderer34.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font39 = null;
        intervalBarRenderer34.setSeriesItemLabelFont((int) '4', font39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener45 = null;
        numberAxis44.addChangeListener(axisChangeListener45);
        org.jfree.chart.plot.Marker marker47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        intervalBarRenderer34.drawRangeMarker(graphics2D41, categoryPlot42, (org.jfree.chart.axis.ValueAxis) numberAxis44, marker47, rectangle2D48);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer34);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder51 = categoryPlot50.getDatasetRenderingOrder();
        categoryPlot24.setDatasetRenderingOrder(datasetRenderingOrder51);
        org.jfree.chart.axis.AxisLocation axisLocation54 = categoryPlot24.getRangeAxisLocation((int) '4');
        java.util.List list55 = categoryPlot24.getAnnotations();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder51);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertNotNull(list55);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer2.setBaseItemLabelPaint(paint3);
        boolean boolean6 = intervalBarRenderer2.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer2.setBaseItemLabelFont(font7, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font7, (java.awt.Paint) color10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer13 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer13.setBaseItemLabelPaint(paint14);
        boolean boolean17 = intervalBarRenderer13.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer13.setBaseItemLabelFont(font18, false);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font18, (java.awt.Paint) color21);
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("CategoryAnchor.MIDDLE", font7, (java.awt.Paint) color21);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer26 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer26.setBaseItemLabelPaint(paint27);
        boolean boolean30 = intervalBarRenderer26.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer26.setBaseItemLabelFont(font31, false);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock35 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font31, (java.awt.Paint) color34);
        org.jfree.chart.block.LabelBlock labelBlock36 = new org.jfree.chart.block.LabelBlock("", font31);
        labelBlock36.setID("Category Plot");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        java.awt.Paint paint41 = stackedBarRenderer3D40.getWallPaint();
        labelBlock36.setPaint(paint41);
        labelBlock23.setPaint(paint41);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock22);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(textBlock35);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getShadowPaint();
        double double2 = piePlot0.getShadowXOffset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) (short) -1);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 255);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 100);
        try {
            java.lang.Comparable comparable9 = defaultKeyedValues2D1.getRowKey((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis4.setAutoRangeStickyZero(false);
        numberAxis4.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer9 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean12 = intervalBarRenderer9.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font14 = null;
        intervalBarRenderer9.setSeriesItemLabelFont((int) '4', font14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener20 = null;
        numberAxis19.addChangeListener(axisChangeListener20);
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        intervalBarRenderer9.drawRangeMarker(graphics2D16, categoryPlot17, (org.jfree.chart.axis.ValueAxis) numberAxis19, marker22, rectangle2D23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer9);
        double double26 = categoryPlot25.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getDomainAxisLocation();
        java.awt.Paint paint28 = categoryPlot25.getNoDataMessagePaint();
        categoryPlot25.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = categoryPlot25.getOrientation();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke34 = intervalBarRenderer32.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = intervalBarRenderer32.getSeriesPositiveItemLabelPosition((int) '#');
        categoryPlot25.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer32);
        java.awt.Font font40 = intervalBarRenderer32.getItemLabelFont((int) (short) 0, 68);
        java.awt.Paint paint41 = null;
        try {
            org.jfree.chart.text.TextLine textLine42 = new org.jfree.chart.text.TextLine("hi!", font40, paint41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertNotNull(font40);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke4 = intervalBarRenderer3.getBaseOutlineStroke();
        stackedBarRenderer3D1.setSeriesOutlineStroke((int) (short) 10, stroke4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedBarRenderer3D1.setSeriesPaint((int) '#', (java.awt.Paint) color7);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint17 = intervalBarRenderer14.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint17);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer19.setBaseItemLabelPaint(paint20);
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("", font13, paint20);
        java.awt.Color color26 = java.awt.Color.getHSBColor((float) (short) 1, (float) 10L, 10.0f);
        java.awt.Color color27 = color26.darker();
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font13, (java.awt.Paint) color27, (float) (-2208960000000L));
        stackedBarRenderer3D1.setSeriesPaint((int) ' ', (java.awt.Paint) color27, true);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis33.setAutoRangeStickyZero(false);
        java.awt.Paint paint36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis33.setTickMarkPaint(paint36);
        boolean boolean38 = stackedBarRenderer3D1.equals((java.lang.Object) numberAxis33);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("First", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        numberAxis1.addChangeListener(axisChangeListener2);
        double double4 = numberAxis1.getLabelAngle();
        numberAxis1.setLowerMargin((double) 10L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot24.getOrientation();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer31 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke33 = intervalBarRenderer31.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = intervalBarRenderer31.getSeriesPositiveItemLabelPosition((int) '#');
        categoryPlot24.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer31);
        java.awt.Image image37 = categoryPlot24.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.PiePlot piePlot39 = new org.jfree.chart.plot.PiePlot(pieDataset38);
        java.awt.Shape shape40 = piePlot39.getLegendItemShape();
        org.jfree.chart.LegendItemCollection legendItemCollection41 = piePlot39.getLegendItems();
        categoryPlot24.setFixedLegendItems(legendItemCollection41);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertNull(image37);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(legendItemCollection41);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        xYPlot9.setDomainAxisLocation((int) '#', axisLocation21);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis24.setAutoRangeStickyZero(false);
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis24);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint35 = intervalBarRenderer32.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock36 = org.jfree.chart.text.TextUtilities.createTextBlock("", font31, paint35);
        numberAxis29.setTickLabelPaint(paint35);
        numberAxis29.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis44.setAutoRangeStickyZero(false);
        numberAxis44.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer49 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean52 = intervalBarRenderer49.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font54 = null;
        intervalBarRenderer49.setSeriesItemLabelFont((int) '4', font54);
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = null;
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener60 = null;
        numberAxis59.addChangeListener(axisChangeListener60);
        org.jfree.chart.plot.Marker marker62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        intervalBarRenderer49.drawRangeMarker(graphics2D56, categoryPlot57, (org.jfree.chart.axis.ValueAxis) numberAxis59, marker62, rectangle2D63);
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) numberAxis44, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer49);
        categoryPlot65.configureRangeAxes();
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
        org.jfree.chart.axis.AxisSpace axisSpace69 = null;
        org.jfree.chart.axis.AxisSpace axisSpace70 = numberAxis29.reserveSpace(graphics2D40, (org.jfree.chart.plot.Plot) categoryPlot65, rectangle2D67, rectangleEdge68, axisSpace69);
        double double71 = axisSpace70.getTop();
        axisSpace70.setLeft((double) '#');
        axisSpace70.setTop((double) 2958465);
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge77);
        axisSpace70.ensureAtLeast((double) (-2208960000000L), rectangleEdge78);
        xYPlot9.setFixedDomainAxisSpace(axisSpace70);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(textBlock36);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(axisSpace70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge77);
        org.junit.Assert.assertNotNull(rectangleEdge78);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Number number2 = null;
        defaultKeyedValues0.addValue((java.lang.Comparable) 8.0d, number2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis7.setAutoRangeStickyZero(false);
        numberAxis7.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean15 = intervalBarRenderer12.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font17 = null;
        intervalBarRenderer12.setSeriesItemLabelFont((int) '4', font17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener23 = null;
        numberAxis22.addChangeListener(axisChangeListener23);
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        intervalBarRenderer12.drawRangeMarker(graphics2D19, categoryPlot20, (org.jfree.chart.axis.ValueAxis) numberAxis22, marker25, rectangle2D26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer12);
        double double29 = categoryPlot28.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot28.zoomRangeAxes(0.0d, (double) 4, plotRenderingInfo32, point2D33);
        int int35 = categoryPlot28.getWeight();
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot28.getRowRenderingOrder();
        defaultKeyedValues0.sortByValues(sortOrder36);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(sortOrder36);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        segmentedTimeline0.addException(0L);
        long long5 = segmentedTimeline0.toTimelineValue((-2208960000000L));
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-32400000L) + "'", long5 == (-32400000L));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setAutoRangeStickyZero(false);
        java.awt.Font font6 = numberAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Comparable comparable3 = null;
        try {
            defaultCategoryDataset0.addValue((java.lang.Number) 68, (java.lang.Comparable) 25200000L, comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Number number2 = null;
        defaultKeyedValues0.addValue((java.lang.Comparable) 8.0d, number2);
        defaultKeyedValues0.addValue((java.lang.Comparable) 2, (double) (byte) 10);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str9 = dateAxis8.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis8.setTickMarkPosition(dateTickMarkPosition10);
        java.text.DateFormat dateFormat16 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat16);
        java.util.Date date18 = dateAxis8.calculateHighestVisibleTickValue(dateTickUnit17);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick25 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0, "hi!", textAnchor22, textAnchor23, (double) 4);
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.DateTick dateTick28 = new org.jfree.chart.axis.DateTick(date18, "hi!", textAnchor23, textAnchor26, (double) 2958465);
        int int29 = defaultKeyedValues0.getIndex((java.lang.Comparable) date18);
        try {
            defaultKeyedValues0.removeValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) "PlotOrientation.VERTICAL");
        int int3 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        categoryPlot24.configureDomainAxes();
        categoryPlot24.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection1 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean2 = outlierListCollection1.isHighFarOut();
        boolean boolean3 = outlierListCollection1.isHighFarOut();
        boolean boolean4 = horizontalAlignment0.equals((java.lang.Object) outlierListCollection1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment5, (double) 25200000L, (double) '#');
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(verticalAlignment5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font5 = null;
        intervalBarRenderer0.setSeriesItemLabelFont((int) '4', font5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener11 = null;
        numberAxis10.addChangeListener(axisChangeListener11);
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        intervalBarRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis10, marker13, rectangle2D14);
        double double16 = numberAxis10.getAutoRangeMinimumSize();
        boolean boolean17 = numberAxis10.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-8d + "'", double16 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        numberAxis1.setTickLabelPaint(paint7);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis16.setAutoRangeStickyZero(false);
        numberAxis16.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean24 = intervalBarRenderer21.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font26 = null;
        intervalBarRenderer21.setSeriesItemLabelFont((int) '4', font26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener32 = null;
        numberAxis31.addChangeListener(axisChangeListener32);
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        intervalBarRenderer21.drawRangeMarker(graphics2D28, categoryPlot29, (org.jfree.chart.axis.ValueAxis) numberAxis31, marker34, rectangle2D35);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer21);
        categoryPlot37.configureRangeAxes();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        org.jfree.chart.axis.AxisSpace axisSpace42 = numberAxis1.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) categoryPlot37, rectangle2D39, rectangleEdge40, axisSpace41);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke45 = intervalBarRenderer44.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator47 = intervalBarRenderer44.getSeriesItemLabelGenerator((int) (short) 10);
        categoryPlot37.setRenderer(6, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer44, false);
        java.awt.Paint paint50 = categoryPlot37.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(axisSpace42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNull(categoryItemLabelGenerator47);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis6.setAutoRangeStickyZero(false);
        numberAxis6.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean14 = intervalBarRenderer11.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font16 = null;
        intervalBarRenderer11.setSeriesItemLabelFont((int) '4', font16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener22 = null;
        numberAxis21.addChangeListener(axisChangeListener22);
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        intervalBarRenderer11.drawRangeMarker(graphics2D18, categoryPlot19, (org.jfree.chart.axis.ValueAxis) numberAxis21, marker24, rectangle2D25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer11);
        double double28 = categoryPlot27.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot27.getDomainAxisLocation();
        java.awt.Paint paint30 = categoryPlot27.getNoDataMessagePaint();
        categoryPlot27.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = categoryPlot27.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState36 = boxAndWhiskerRenderer0.initialise(graphics2D1, rectangle2D2, categoryPlot27, (int) (short) -1, plotRenderingInfo35);
        java.awt.Font font38 = boxAndWhiskerRenderer0.getSeriesItemLabelFont(3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertNotNull(categoryItemRendererState36);
        org.junit.Assert.assertNull(font38);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot9.getRenderer(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot9.zoomRangeAxes(68.0d, plotRenderingInfo17, point2D18);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Number number2 = null;
        defaultKeyedValues0.addValue((java.lang.Comparable) 8.0d, number2);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer4 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean5 = defaultKeyedValues0.equals((java.lang.Object) boxAndWhiskerRenderer4);
        org.jfree.chart.util.SortOrder sortOrder6 = org.jfree.chart.util.SortOrder.DESCENDING;
        defaultKeyedValues0.sortByValues(sortOrder6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis10.setAutoRangeStickyZero(false);
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis10.setTickMarkPaint(paint13);
        java.lang.Class<?> wildcardClass15 = paint13.getClass();
        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass15);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int18 = segmentedTimeline17.getSegmentsExcluded();
        long long19 = segmentedTimeline17.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str23 = dateRange22.toString();
        java.util.Date date24 = dateRange22.getLowerDate();
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str28 = dateRange27.toString();
        java.util.Date date29 = dateRange27.getLowerDate();
        boolean boolean30 = segmentedTimeline17.containsDomainRange(date24, date29);
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date24, timeZone31);
        try {
            defaultKeyedValues0.setValue((java.lang.Comparable) regularTimePeriod32, (java.lang.Number) 68.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 68 + "'", int18 == 68);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 86400000L + "'", long19 == 86400000L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str23.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str28.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(regularTimePeriod32);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 4);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis5.setAutoRangeStickyZero(false);
        numberAxis5.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean13 = intervalBarRenderer10.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font15 = null;
        intervalBarRenderer10.setSeriesItemLabelFont((int) '4', font15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener21 = null;
        numberAxis20.addChangeListener(axisChangeListener21);
        org.jfree.chart.plot.Marker marker23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        intervalBarRenderer10.drawRangeMarker(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis20, marker23, rectangle2D24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer10);
        double double27 = categoryPlot26.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot26.zoomRangeAxes(0.0d, (double) 4, plotRenderingInfo30, point2D31);
        int int33 = categoryPlot26.getWeight();
        java.util.List list34 = categoryPlot26.getAnnotations();
        axisState1.setTicks(list34);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(list34);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("XY Plot");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setSectionDepth((double) 'a');
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) 60000L, (float) 86400000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-65536) + "'", int3 == (-65536));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        segmentedTimeline0.addException(0L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int5 = segmentedTimeline4.getSegmentsExcluded();
        segmentedTimeline0.setBaseTimeline(segmentedTimeline4);
        long long7 = segmentedTimeline0.getSegmentsIncludedSize();
        segmentedTimeline0.addBaseTimelineExclusions((long) 10, (long) (short) 10);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 68 + "'", int5 == 68);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25200000L + "'", long7 == 25200000L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        boolean boolean8 = numberAxis2.equals((java.lang.Object) (byte) 10);
        double double9 = numberAxis2.getUpperBound();
        java.lang.Comparable comparable11 = null;
        keyedObjects2D0.setObject((java.lang.Object) numberAxis2, (java.lang.Comparable) 0.25d, comparable11);
        try {
            java.lang.Comparable comparable14 = keyedObjects2D0.getRowKey((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        boolean boolean3 = dateAxis1.equals((java.lang.Object) itemLabelAnchor2);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis1.setTimeline(timeline4);
        java.lang.Object obj6 = dateAxis1.clone();
        java.util.Date date7 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str11 = dateAxis10.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis10.setTickMarkPosition(dateTickMarkPosition12);
        java.text.DateFormat dateFormat18 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat18);
        java.util.Date date20 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit19);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis23.setAutoRangeStickyZero(false);
        java.awt.Paint paint26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis23.setTickMarkPaint(paint26);
        java.lang.Class<?> wildcardClass28 = paint26.getClass();
        java.lang.Object obj29 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass28);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline30 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int31 = segmentedTimeline30.getSegmentsExcluded();
        long long32 = segmentedTimeline30.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange35 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str36 = dateRange35.toString();
        java.util.Date date37 = dateRange35.getLowerDate();
        org.jfree.data.time.DateRange dateRange40 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str41 = dateRange40.toString();
        java.util.Date date42 = dateRange40.getLowerDate();
        boolean boolean43 = segmentedTimeline30.containsDomainRange(date37, date42);
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date37, timeZone44);
        org.jfree.data.gantt.Task task46 = new org.jfree.data.gantt.Task("({0}, {1}) = {2}", date20, date37);
        try {
            dateAxis1.setRange(date7, date37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertNotNull(segmentedTimeline30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 68 + "'", int31 == 68);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 86400000L + "'", long32 == 86400000L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str36.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str41.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(regularTimePeriod45);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment(0L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = segmentedTimeline0.getBaseTimeline();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
        java.lang.String str10 = projectInfo7.getInfo();
        org.jfree.chart.ui.Library[] libraryArray11 = projectInfo7.getOptionalLibraries();
        java.awt.Image image15 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo19 = new org.jfree.chart.ui.ProjectInfo("", "", "", image15, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image20 = null;
        projectInfo19.setLogo(image20);
        java.lang.String str22 = projectInfo19.getInfo();
        org.jfree.chart.ui.Library[] libraryArray23 = projectInfo19.getOptionalLibraries();
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo19);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline25 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int26 = segmentedTimeline25.getSegmentsExcluded();
        segmentedTimeline25.addException(0L);
        java.util.List list29 = segmentedTimeline25.getExceptionSegments();
        projectInfo7.setContributors(list29);
        java.awt.Image image34 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo38 = new org.jfree.chart.ui.ProjectInfo("", "", "", image34, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image39 = null;
        projectInfo38.setLogo(image39);
        java.lang.String str41 = projectInfo38.getInfo();
        org.jfree.chart.ui.Library[] libraryArray42 = projectInfo38.getOptionalLibraries();
        java.awt.Image image46 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo50 = new org.jfree.chart.ui.ProjectInfo("", "", "", image46, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image51 = null;
        projectInfo50.setLogo(image51);
        java.lang.String str53 = projectInfo50.getInfo();
        org.jfree.chart.ui.Library[] libraryArray54 = projectInfo50.getOptionalLibraries();
        projectInfo38.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo50);
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo50);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(libraryArray11);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(libraryArray23);
        org.junit.Assert.assertNotNull(segmentedTimeline25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 68 + "'", int26 == 68);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertNotNull(libraryArray42);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
        org.junit.Assert.assertNotNull(libraryArray54);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        double double18 = dateAxis16.getLabelAngle();
        dateAxis16.setNegativeArrowVisible(true);
        dateAxis16.setLowerBound((double) '#');
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) (short) -1);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 255);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 100);
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat12);
        boolean boolean15 = dateTickUnit13.equals((java.lang.Object) (short) -1);
        int int16 = dateTickUnit13.getUnit();
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) int16);
        java.util.List list18 = defaultKeyedValues2D1.getColumnKeys();
        try {
            defaultKeyedValues2D1.removeRow((-2));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot9.setInsets(rectangleInsets10, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = xYPlot9.getAxisOffset();
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "", font2);
        double double4 = categoryAxis0.getFixedDimension();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState7 = new org.jfree.chart.axis.AxisState((double) 4);
        axisState7.cursorLeft((double) 0);
        double double10 = axisState7.getMax();
        org.jfree.chart.util.Size2D size2D13 = new org.jfree.chart.util.Size2D((double) 10L, (-1.0d));
        size2D13.setHeight((double) 10L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, 0.0d, (double) (-1L), rectangleAnchor18);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition24 = categoryLabelPositions21.getLabelPosition(rectangleEdge22);
        try {
            java.util.List list25 = categoryAxis0.refreshTicks(graphics2D5, axisState7, rectangle2D19, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(categoryLabelPositions21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(categoryLabelPosition24);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("hi!", font1, paint7, 100.0f);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis14.setAutoRangeStickyZero(false);
        numberAxis14.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean22 = intervalBarRenderer19.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font24 = null;
        intervalBarRenderer19.setSeriesItemLabelFont((int) '4', font24);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener30 = null;
        numberAxis29.addChangeListener(axisChangeListener30);
        org.jfree.chart.plot.Marker marker32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        intervalBarRenderer19.drawRangeMarker(graphics2D26, categoryPlot27, (org.jfree.chart.axis.ValueAxis) numberAxis29, marker32, rectangle2D33);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer19);
        double double36 = categoryPlot35.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot35.setRangeAxisLocation(axisLocation37, true);
        java.awt.Paint paint40 = categoryPlot35.getNoDataMessagePaint();
        boolean boolean41 = org.jfree.chart.util.PaintUtilities.equal(paint7, paint40);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        long long2 = segmentedTimeline0.getSegmentSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 900000L + "'", long2 == 900000L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.awt.Color color0 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getHSBColor((float) (short) 1, (float) 10L, 10.0f);
        java.awt.Color color5 = color4.darker();
        float[] floatArray11 = new float[] { (short) -1, (short) 100, 100, 6, (byte) 100 };
        float[] floatArray12 = color5.getRGBColorComponents(floatArray11);
        float[] floatArray13 = color0.getRGBColorComponents(floatArray12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("pink", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        stackedBarRenderer3D1.setRenderAsPercentages(false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setDomainCrosshairVisible(false);
        java.awt.Stroke stroke20 = xYPlot9.getOutlineStroke();
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot9.setDomainCrosshairStroke(stroke21);
        double double23 = xYPlot9.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        strokeList0.clear();
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        strokeList0.setStroke(0, stroke5);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer0.setBaseItemLabelPaint(paint1);
        boolean boolean4 = intervalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke8 = intervalBarRenderer6.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = intervalBarRenderer6.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer0.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition10);
        java.awt.Shape shape12 = intervalBarRenderer0.getBaseShape();
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray20, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray25);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset26);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity30 = new org.jfree.chart.entity.CategoryItemEntity(shape12, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset26, (java.lang.Comparable) 8.0d, (java.lang.Comparable) 0.0f);
        java.lang.String str31 = categoryItemEntity30.getToolTipText();
        categoryItemEntity30.setColumnKey((java.lang.Comparable) (short) 0);
        java.awt.Shape shape42 = null;
        java.awt.Color color43 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", "hi!", shape42, (java.awt.Paint) color43);
        legendItem44.setSeriesIndex((int) (short) -1);
        java.awt.Shape shape47 = legendItem44.getLine();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer49 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint50 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer49.setBaseItemLabelPaint(paint50);
        boolean boolean53 = intervalBarRenderer49.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font54 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer49.setBaseItemLabelFont(font54, false);
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock58 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font54, (java.awt.Paint) color57);
        org.jfree.chart.LegendItem legendItem59 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "TextAnchor.BASELINE_CENTER", "Category Plot", "hi!", shape47, (java.awt.Paint) color57);
        categoryItemEntity30.setArea(shape47);
        org.jfree.data.xy.XYDataset xYDataset61 = null;
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis63.setAutoRangeStickyZero(false);
        numberAxis63.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer69 = null;
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot(xYDataset61, (org.jfree.chart.axis.ValueAxis) numberAxis63, valueAxis68, xYItemRenderer69);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer71 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke73 = intervalBarRenderer71.lookupSeriesStroke(3);
        xYPlot70.setDomainGridlineStroke(stroke73);
        java.awt.Stroke stroke75 = xYPlot70.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer77 = null;
        java.util.Collection collection78 = xYPlot70.getDomainMarkers(2, layer77);
        xYPlot70.setWeight(10);
        xYPlot70.setRangeCrosshairValue((double) 4, true);
        xYPlot70.setDomainCrosshairValue((double) '4', true);
        boolean boolean87 = categoryItemEntity30.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(textBlock58);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNull(collection78);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) -1, (float) (-2208927599990L));
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        boolean boolean8 = numberAxis2.equals((java.lang.Object) (byte) 10);
        double double9 = numberAxis2.getUpperBound();
        java.lang.Comparable comparable11 = null;
        keyedObjects2D0.setObject((java.lang.Object) numberAxis2, (java.lang.Comparable) 0.25d, comparable11);
        java.awt.Shape shape13 = numberAxis2.getRightArrow();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setAutoRangeStickyZero(false);
        boolean boolean7 = numberAxis1.equals((java.lang.Object) (byte) 10);
        double double8 = numberAxis1.getUpperBound();
        boolean boolean9 = numberAxis1.isPositiveArrowVisible();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer10 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        double double11 = boxAndWhiskerRenderer10.getItemMargin();
        boxAndWhiskerRenderer10.setItemMargin((double) (-1L));
        boolean boolean14 = boxAndWhiskerRenderer10.getFillBox();
        java.lang.Object obj15 = boxAndWhiskerRenderer10.clone();
        java.awt.Stroke stroke18 = boxAndWhiskerRenderer10.getItemOutlineStroke(0, 68);
        numberAxis1.setTickMarkStroke(stroke18);
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = numberAxis1.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(tickUnitSource20);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        numberAxis1.setTickLabelPaint(paint7);
        numberAxis1.setLowerMargin((double) (short) 10);
        org.jfree.data.RangeType rangeType12 = numberAxis1.getRangeType();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(rangeType12);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.data.general.DatasetGroup datasetGroup2 = multiplePiePlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(datasetGroup2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font5 = null;
        intervalBarRenderer0.setSeriesItemLabelFont((int) '4', font5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = intervalBarRenderer0.getPositiveItemLabelPosition(15, (int) (short) 10);
        intervalBarRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.awt.Shape shape14 = piePlot13.getLegendItemShape();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = piePlot13.getLegendItems();
        java.awt.Paint paint16 = piePlot13.getLabelOutlinePaint();
        intervalBarRenderer0.setBasePaint(paint16, true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer20.setBaseItemLabelPaint(paint21);
        boolean boolean24 = intervalBarRenderer20.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer20.setBaseItemLabelFont(font25, false);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock29 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font25, (java.awt.Paint) color28);
        intervalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color28);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(textBlock29);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0, "hi!", textAnchor2, textAnchor3, (double) 4);
        double double6 = numberTick5.getAngle();
        double double7 = numberTick5.getAngle();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        boolean boolean25 = intervalBarRenderer8.getBaseSeriesVisibleInLegend();
        boolean boolean26 = intervalBarRenderer8.getAutoPopulateSeriesShape();
        java.awt.Shape shape29 = intervalBarRenderer8.getItemShape((int) (short) 100, 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset30 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent34 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset30, jFreeChart31, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean36 = defaultBoxAndWhiskerCategoryDataset30.equals((java.lang.Object) paintArray35);
        org.jfree.data.Range range37 = intervalBarRenderer8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30);
        double double39 = defaultBoxAndWhiskerCategoryDataset30.getRangeUpperBound(true);
        java.lang.Number number40 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30);
        org.jfree.data.general.PieDataset pieDataset42 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30, (java.lang.Comparable) true);
        double double43 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset42);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 0.0d + "'", number40.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(3, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "March" + "'", str2.equals("March"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        double double1 = boxAndWhiskerRenderer0.getItemMargin();
        boxAndWhiskerRenderer0.setItemMargin((double) (-1L));
        boxAndWhiskerRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        boxAndWhiskerRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setIgnoreZeroValues(true);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot1.getLabelDistributor();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot24.setRangeAxisLocation(axisLocation26, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis31.setAutoRangeStickyZero(false);
        numberAxis31.setAutoRangeStickyZero(false);
        categoryPlot24.setRangeAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) numberAxis31, true);
        float float38 = numberAxis31.getTickMarkOutsideLength();
        boolean boolean39 = numberAxis31.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 2.0f + "'", float38 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        int int5 = chartProgressEvent4.getPercent();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint14 = intervalBarRenderer11.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, paint14);
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("hi!", font8, paint14, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean21 = intervalBarRenderer18.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font23 = null;
        intervalBarRenderer18.setSeriesItemLabelFont((int) '4', font23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener29 = null;
        numberAxis28.addChangeListener(axisChangeListener29);
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        intervalBarRenderer18.drawRangeMarker(graphics2D25, categoryPlot26, (org.jfree.chart.axis.ValueAxis) numberAxis28, marker31, rectangle2D32);
        boolean boolean34 = textFragment17.equals((java.lang.Object) graphics2D25);
        java.awt.Font font35 = textFragment17.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis39.setAutoRangeStickyZero(false);
        numberAxis39.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean47 = intervalBarRenderer44.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font49 = null;
        intervalBarRenderer44.setSeriesItemLabelFont((int) '4', font49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener55 = null;
        numberAxis54.addChangeListener(axisChangeListener55);
        org.jfree.chart.plot.Marker marker57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        intervalBarRenderer44.drawRangeMarker(graphics2D51, categoryPlot52, (org.jfree.chart.axis.ValueAxis) numberAxis54, marker57, rectangle2D58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer44);
        org.jfree.chart.JFreeChart jFreeChart62 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", font35, (org.jfree.chart.plot.Plot) categoryPlot60, false);
        chartProgressEvent4.setChart(jFreeChart62);
        org.jfree.chart.title.TextTitle textTitle64 = null;
        jFreeChart62.setTitle(textTitle64);
        boolean boolean66 = jFreeChart62.isNotify();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 1, (double) (-2208960000000L));
        double double3 = size2D2.height;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.20896E12d) + "'", double3 == (-2.20896E12d));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) (-1));
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset3 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent7 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset3, jFreeChart4, 0, (int) (byte) 100);
        java.lang.Comparable comparable8 = null;
        java.lang.Comparable comparable9 = null;
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset3.getMeanValue(comparable8, comparable9);
        org.jfree.data.KeyedObject keyedObject11 = new org.jfree.data.KeyedObject((java.lang.Comparable) (short) -1, (java.lang.Object) comparable9);
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        intervalMarker2.setLabel("hi!");
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder();
        boolean boolean6 = intervalMarker2.equals((java.lang.Object) lineBorder5);
        java.awt.Paint paint7 = intervalMarker2.getLabelPaint();
        java.lang.Object obj8 = intervalMarker2.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        int int5 = chartProgressEvent4.getPercent();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint14 = intervalBarRenderer11.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, paint14);
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("hi!", font8, paint14, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean21 = intervalBarRenderer18.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font23 = null;
        intervalBarRenderer18.setSeriesItemLabelFont((int) '4', font23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener29 = null;
        numberAxis28.addChangeListener(axisChangeListener29);
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        intervalBarRenderer18.drawRangeMarker(graphics2D25, categoryPlot26, (org.jfree.chart.axis.ValueAxis) numberAxis28, marker31, rectangle2D32);
        boolean boolean34 = textFragment17.equals((java.lang.Object) graphics2D25);
        java.awt.Font font35 = textFragment17.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis39.setAutoRangeStickyZero(false);
        numberAxis39.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean47 = intervalBarRenderer44.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font49 = null;
        intervalBarRenderer44.setSeriesItemLabelFont((int) '4', font49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener55 = null;
        numberAxis54.addChangeListener(axisChangeListener55);
        org.jfree.chart.plot.Marker marker57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        intervalBarRenderer44.drawRangeMarker(graphics2D51, categoryPlot52, (org.jfree.chart.axis.ValueAxis) numberAxis54, marker57, rectangle2D58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer44);
        org.jfree.chart.JFreeChart jFreeChart62 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", font35, (org.jfree.chart.plot.Plot) categoryPlot60, false);
        chartProgressEvent4.setChart(jFreeChart62);
        org.jfree.chart.title.TextTitle textTitle64 = null;
        jFreeChart62.setTitle(textTitle64);
        try {
            org.jfree.chart.plot.XYPlot xYPlot66 = jFreeChart62.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer1.setBaseItemLabelPaint(paint2);
        java.awt.Shape shape4 = intervalBarRenderer1.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = intervalBarRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        intervalBarRenderer1.setSeriesItemLabelPaint((int) (byte) 10, paint8, true);
        boolean boolean11 = piePlot3D0.equals((java.lang.Object) true);
        java.lang.String str12 = piePlot3D0.getPlotType();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pie 3D Plot" + "'", str12.equals("Pie 3D Plot"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        double double4 = numberAxis1.getUpperBound();
        numberAxis1.centerRange(68.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke1 = intervalBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke4 = intervalBarRenderer2.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = intervalBarRenderer2.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str2 = dateAxis1.getLabelToolTip();
        java.awt.Shape shape3 = dateAxis1.getDownArrow();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState9 = new org.jfree.chart.axis.AxisState((double) 4);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer12.setBaseItemLabelPaint(paint13);
        boolean boolean16 = intervalBarRenderer12.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer12.setBaseItemLabelFont(font17, false);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font17, (java.awt.Paint) color20);
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("", font17);
        labelBlock22.setID("Category Plot");
        java.awt.Paint paint25 = labelBlock22.getPaint();
        java.awt.geom.Rectangle2D rectangle2D26 = labelBlock22.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        java.util.List list28 = categoryAxis6.refreshTicks(graphics2D7, axisState9, rectangle2D26, rectangleEdge27);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis31.setAutoRangeStickyZero(false);
        numberAxis31.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis31, valueAxis36, xYItemRenderer37);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer39 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke41 = intervalBarRenderer39.lookupSeriesStroke(3);
        xYPlot38.setDomainGridlineStroke(stroke41);
        java.awt.Stroke stroke43 = xYPlot38.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = xYPlot38.getDomainMarkers(2, layer45);
        xYPlot38.setDomainCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = xYPlot38.getDomainAxisEdge();
        try {
            java.util.List list50 = dateAxis1.refreshTicks(graphics2D4, axisState5, rectangle2D26, rectangleEdge49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertNotNull(rectangleEdge49);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer1.setBaseItemLabelPaint(paint2);
        java.awt.Shape shape4 = intervalBarRenderer1.getBaseShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = intervalBarRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        intervalBarRenderer1.setSeriesItemLabelPaint((int) (byte) 10, paint8, true);
        boolean boolean11 = piePlot3D0.equals((java.lang.Object) true);
        double double12 = piePlot3D0.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint6 = intervalBarRenderer3.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint6);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer8.setBaseItemLabelPaint(paint9);
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("", font2, paint9);
        org.jfree.chart.text.TextFragment textFragment12 = textLine11.getFirstTextFragment();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            textLine11.draw(graphics2D13, (float) (byte) 1, (float) (-1), textAnchor16, (float) 2, (float) 100, (double) 25200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textFragment12);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator1 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str2 = standardCategoryToolTipGenerator1.getLabelFormat();
        java.text.NumberFormat numberFormat3 = standardCategoryToolTipGenerator1.getNumberFormat();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator4 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("magenta", numberFormat3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "({0}, {1}) = {2}" + "'", str2.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font5 = null;
        intervalBarRenderer0.setSeriesItemLabelFont((int) '4', font5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = intervalBarRenderer0.getPositiveItemLabelPosition(15, (int) (short) 10);
        boolean boolean10 = intervalBarRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        layeredBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition1);
        double double4 = layeredBarRenderer0.getSeriesBarWidth((int) (byte) 10);
        boolean boolean5 = layeredBarRenderer0.isDrawBarOutline();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        xYPlot9.setRangeGridlinesVisible(false);
        xYPlot9.setDomainCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis24.setAutoRangeStickyZero(false);
        numberAxis24.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, valueAxis29, xYItemRenderer30);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke34 = intervalBarRenderer32.lookupSeriesStroke(3);
        xYPlot31.setDomainGridlineStroke(stroke34);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot31.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis38);
        xYPlot31.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis44.setAutoRangeStickyZero(false);
        double double47 = numberAxis44.getUpperBound();
        xYPlot31.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis44, false);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot50 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis52.setAutoRangeStickyZero(false);
        numberAxis52.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat57 = numberAxis52.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = numberAxis52.getTickLabelInsets();
        waferMapPlot50.setInsets(rectangleInsets58);
        xYPlot31.setAxisOffset(rectangleInsets58);
        int int61 = xYPlot31.getSeriesCount();
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis64.setAutoRangeStickyZero(false);
        numberAxis64.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer70 = null;
        org.jfree.chart.plot.XYPlot xYPlot71 = new org.jfree.chart.plot.XYPlot(xYDataset62, (org.jfree.chart.axis.ValueAxis) numberAxis64, valueAxis69, xYItemRenderer70);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer72 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke74 = intervalBarRenderer72.lookupSeriesStroke(3);
        xYPlot71.setDomainGridlineStroke(stroke74);
        org.jfree.chart.axis.DateAxis dateAxis78 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot71.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis78);
        double double80 = dateAxis78.getLabelAngle();
        dateAxis78.setLabelAngle((double) (-1));
        org.jfree.chart.axis.NumberAxis numberAxis84 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font86 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer87 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint90 = intervalBarRenderer87.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock91 = org.jfree.chart.text.TextUtilities.createTextBlock("", font86, paint90);
        numberAxis84.setTickLabelPaint(paint90);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray93 = new org.jfree.chart.axis.ValueAxis[] { dateAxis78, numberAxis84 };
        xYPlot31.setRangeAxes(valueAxisArray93);
        xYPlot9.setRangeAxes(valueAxisArray93);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertNull(numberFormat57);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(font86);
        org.junit.Assert.assertNotNull(paint90);
        org.junit.Assert.assertNotNull(textBlock91);
        org.junit.Assert.assertNotNull(valueAxisArray93);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("CategoryAnchor.MIDDLE");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str5 = dateAxis4.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis4.setTickMarkPosition(dateTickMarkPosition6);
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat12);
        java.util.Date date14 = dateAxis4.calculateHighestVisibleTickValue(dateTickUnit13);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis17.setAutoRangeStickyZero(false);
        java.awt.Paint paint20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis17.setTickMarkPaint(paint20);
        java.lang.Class<?> wildcardClass22 = paint20.getClass();
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass22);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline24 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int25 = segmentedTimeline24.getSegmentsExcluded();
        long long26 = segmentedTimeline24.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str30 = dateRange29.toString();
        java.util.Date date31 = dateRange29.getLowerDate();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str35 = dateRange34.toString();
        java.util.Date date36 = dateRange34.getLowerDate();
        boolean boolean37 = segmentedTimeline24.containsDomainRange(date31, date36);
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date31, timeZone38);
        org.jfree.data.gantt.Task task40 = new org.jfree.data.gantt.Task("({0}, {1}) = {2}", date14, date31);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) (-1));
        task40.setDuration((org.jfree.data.time.TimePeriod) simpleTimePeriod43);
        taskSeries1.add(task40);
        java.lang.String str46 = taskSeries1.getDescription();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str50 = dateAxis49.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition51 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis49.setTickMarkPosition(dateTickMarkPosition51);
        java.text.DateFormat dateFormat57 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit58 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat57);
        java.util.Date date59 = dateAxis49.calculateHighestVisibleTickValue(dateTickUnit58);
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis62.setAutoRangeStickyZero(false);
        java.awt.Paint paint65 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis62.setTickMarkPaint(paint65);
        java.lang.Class<?> wildcardClass67 = paint65.getClass();
        java.lang.Object obj68 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass67);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline69 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int70 = segmentedTimeline69.getSegmentsExcluded();
        long long71 = segmentedTimeline69.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange74 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str75 = dateRange74.toString();
        java.util.Date date76 = dateRange74.getLowerDate();
        org.jfree.data.time.DateRange dateRange79 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str80 = dateRange79.toString();
        java.util.Date date81 = dateRange79.getLowerDate();
        boolean boolean82 = segmentedTimeline69.containsDomainRange(date76, date81);
        java.util.TimeZone timeZone83 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date76, timeZone83);
        org.jfree.data.gantt.Task task85 = new org.jfree.data.gantt.Task("({0}, {1}) = {2}", date59, date76);
        taskSeries1.remove(task85);
        try {
            org.jfree.data.gantt.Task task88 = task85.getSubtask((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNotNull(segmentedTimeline24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 68 + "'", int25 == 68);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 86400000L + "'", long26 == 86400000L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str30.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str35.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(dateTickMarkPosition51);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNull(obj68);
        org.junit.Assert.assertNotNull(segmentedTimeline69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 68 + "'", int70 == 68);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 86400000L + "'", long71 == 86400000L);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str75.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str80.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNull(regularTimePeriod84);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke4 = intervalBarRenderer3.getBaseOutlineStroke();
        stackedBarRenderer3D1.setSeriesOutlineStroke((int) (short) 10, stroke4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedBarRenderer3D1.setSeriesPaint((int) '#', (java.awt.Paint) color7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener13 = null;
        numberAxis12.addChangeListener(axisChangeListener13);
        numberAxis12.setRangeWithMargins((double) (short) -1, (double) (byte) 0);
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        intervalMarker20.setLabel("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.plot.Marker) intervalMarker20, rectangle2D23);
        java.lang.Object obj25 = intervalMarker20.clone();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer0.setBaseItemLabelPaint(paint1);
        boolean boolean4 = intervalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke8 = intervalBarRenderer6.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = intervalBarRenderer6.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer0.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition10);
        java.awt.Shape shape12 = intervalBarRenderer0.getBaseShape();
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray20, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray25);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset26);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity30 = new org.jfree.chart.entity.CategoryItemEntity(shape12, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset26, (java.lang.Comparable) 8.0d, (java.lang.Comparable) 0.0f);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset26);
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str35 = dateRange34.toString();
        double double36 = dateRange34.getLowerBound();
        boolean boolean38 = dateRange34.contains((double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint(range31, (org.jfree.data.Range) dateRange34);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = rectangleConstraint39.toFixedWidth((double) 0.0f);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str35.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint41);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        int int5 = chartProgressEvent4.getPercent();
        java.lang.String str6 = chartProgressEvent4.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues1 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Number number3 = null;
        defaultKeyedValues1.addValue((java.lang.Comparable) 8.0d, number3);
        defaultKeyedValues1.addValue((java.lang.Comparable) 2, (double) (byte) 10);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str10 = dateAxis9.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition11 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis9.setTickMarkPosition(dateTickMarkPosition11);
        java.text.DateFormat dateFormat17 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat17);
        java.util.Date date19 = dateAxis9.calculateHighestVisibleTickValue(dateTickUnit18);
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick26 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0, "hi!", textAnchor23, textAnchor24, (double) 4);
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.DateTick dateTick29 = new org.jfree.chart.axis.DateTick(date19, "hi!", textAnchor24, textAnchor27, (double) 2958465);
        int int30 = defaultKeyedValues1.getIndex((java.lang.Comparable) date19);
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "EXPAND", (org.jfree.data.KeyedValues) defaultKeyedValues1);
        boolean boolean32 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset31);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(dateTickMarkPosition11);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        polarPlot0.setDataset(xYDataset1);
        boolean boolean3 = polarPlot0.isRadiusGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint5 = intervalBarRenderer2.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textBlock6.calculateDimensions(graphics2D7);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font10);
        textBlock6.addLine(textLine11);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint18 = intervalBarRenderer15.getItemFillPaint(100, (int) 'a');
        stackedBarRenderer3D14.setWallPaint(paint18);
        java.awt.Stroke stroke21 = stackedBarRenderer3D14.getSeriesStroke(2);
        boolean boolean22 = textBlock6.equals((java.lang.Object) stackedBarRenderer3D14);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("First", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, valueAxis8, xYItemRenderer9);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke13 = intervalBarRenderer11.lookupSeriesStroke(3);
        xYPlot10.setDomainGridlineStroke(stroke13);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot10.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis17);
        xYPlot10.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis23.setAutoRangeStickyZero(false);
        double double26 = numberAxis23.getUpperBound();
        xYPlot10.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis23, false);
        boolean boolean29 = dateTickMarkPosition0.equals((java.lang.Object) xYPlot10);
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (short) 1, (float) 10L, 10.0f);
        java.awt.Color color6 = color5.darker();
        float[] floatArray12 = new float[] { (short) -1, (short) 100, 100, 6, (byte) 100 };
        float[] floatArray13 = color6.getRGBColorComponents(floatArray12);
        float[] floatArray14 = color1.getColorComponents(floatArray12);
        float[] floatArray15 = color0.getRGBComponents(floatArray12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot24.rendererChanged(rendererChangeEvent30);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot24);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer34.setBaseItemLabelPaint(paint35);
        boolean boolean38 = intervalBarRenderer34.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer34.setBaseItemLabelFont(font39, false);
        categoryPlot24.setRenderer((int) (short) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer34, true);
        org.jfree.chart.util.StrokeList strokeList44 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer46 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke47 = intervalBarRenderer46.getBaseOutlineStroke();
        strokeList44.setStroke((int) (short) 1, stroke47);
        categoryPlot24.setRangeGridlineStroke(stroke47);
        categoryPlot24.setRangeCrosshairVisible(true);
        categoryPlot24.setRangeGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        numberAxis1.setTickLabelPaint(paint7);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis16.setAutoRangeStickyZero(false);
        numberAxis16.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean24 = intervalBarRenderer21.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font26 = null;
        intervalBarRenderer21.setSeriesItemLabelFont((int) '4', font26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener32 = null;
        numberAxis31.addChangeListener(axisChangeListener32);
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        intervalBarRenderer21.drawRangeMarker(graphics2D28, categoryPlot29, (org.jfree.chart.axis.ValueAxis) numberAxis31, marker34, rectangle2D35);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer21);
        categoryPlot37.configureRangeAxes();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        org.jfree.chart.axis.AxisSpace axisSpace42 = numberAxis1.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) categoryPlot37, rectangle2D39, rectangleEdge40, axisSpace41);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke45 = intervalBarRenderer44.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator47 = intervalBarRenderer44.getSeriesItemLabelGenerator((int) (short) 10);
        categoryPlot37.setRenderer(6, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer44, false);
        double double50 = intervalBarRenderer44.getUpperClip();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(axisSpace42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNull(categoryItemLabelGenerator47);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer2.setBaseItemLabelPaint(paint3);
        boolean boolean6 = intervalBarRenderer2.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer2.setBaseItemLabelFont(font7, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font7, (java.awt.Paint) color10);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font7);
        double double13 = labelBlock12.getHeight();
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        labelBlock12.setPaint(paint14);
        java.lang.Object obj16 = labelBlock12.clone();
        double double17 = labelBlock12.getContentYOffset();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        java.lang.String str2 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BASELINE_CENTER" + "'", str1.equals("TextAnchor.BASELINE_CENTER"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BASELINE_CENTER" + "'", str2.equals("TextAnchor.BASELINE_CENTER"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setIgnoreZeroValues(true);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int5 = segmentedTimeline4.getSegmentsExcluded();
        long long6 = segmentedTimeline4.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str10 = dateRange9.toString();
        java.util.Date date11 = dateRange9.getLowerDate();
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str15 = dateRange14.toString();
        java.util.Date date16 = dateRange14.getLowerDate();
        boolean boolean17 = segmentedTimeline4.containsDomainRange(date11, date16);
        double double18 = piePlot1.getExplodePercent((java.lang.Comparable) date16);
        piePlot1.setLabelGap((double) 10L);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 68 + "'", int5 == 68);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 86400000L + "'", long6 == 86400000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str10.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str15.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment(0L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline3.getSegment(0L);
        boolean boolean6 = segment2.after(segment5);
        segment2.inc();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        xYPlot9.clearDomainMarkers();
        xYPlot9.setRangeCrosshairValue((double) 1.0f);
        org.jfree.chart.plot.Plot plot18 = xYPlot9.getRootPlot();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis22.setAutoRangeStickyZero(false);
        numberAxis22.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer27 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean30 = intervalBarRenderer27.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font32 = null;
        intervalBarRenderer27.setSeriesItemLabelFont((int) '4', font32);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener38 = null;
        numberAxis37.addChangeListener(axisChangeListener38);
        org.jfree.chart.plot.Marker marker40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        intervalBarRenderer27.drawRangeMarker(graphics2D34, categoryPlot35, (org.jfree.chart.axis.ValueAxis) numberAxis37, marker40, rectangle2D41);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer27);
        double double44 = categoryPlot43.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation45 = categoryPlot43.getDomainAxisLocation();
        java.awt.Paint paint46 = categoryPlot43.getNoDataMessagePaint();
        categoryPlot43.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent49 = null;
        categoryPlot43.rendererChanged(rendererChangeEvent49);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent51 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot43);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer53 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint54 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer53.setBaseItemLabelPaint(paint54);
        boolean boolean57 = intervalBarRenderer53.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font58 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer53.setBaseItemLabelFont(font58, false);
        categoryPlot43.setRenderer((int) (short) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer53, true);
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str66 = dateAxis65.getLabelToolTip();
        java.awt.Shape shape67 = dateAxis65.getDownArrow();
        boolean boolean69 = dateAxis65.isHiddenValue((long) (byte) -1);
        categoryPlot43.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) dateAxis65);
        org.jfree.data.Range range71 = dateAxis65.getDefaultAutoRange();
        org.jfree.data.Range range72 = xYPlot9.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis65);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(plot18);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(range71);
        org.junit.Assert.assertNull(range72);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        double double4 = numberAxis1.getUpperBound();
        java.awt.Paint paint5 = numberAxis1.getAxisLinePaint();
        float float6 = numberAxis1.getTickMarkInsideLength();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.awt.Shape shape9 = piePlot8.getLegendItemShape();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = piePlot8.getLegendItems();
        piePlot8.setShadowYOffset((double) 100.0f);
        piePlot8.setShadowYOffset(0.0d);
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot8);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint((int) (short) 1);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double0 = org.jfree.chart.renderer.category.LevelRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        boolean boolean3 = lineBorder0.equals((java.lang.Object) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        piePlot1.setExplodePercent((java.lang.Comparable) "CategoryAnchor.MIDDLE", 1.0E-8d);
        java.awt.Paint paint7 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) "GradientPaintTransformType.CENTER_VERTICAL");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer2.setBaseItemLabelPaint(paint3);
        boolean boolean6 = intervalBarRenderer2.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer2.setBaseItemLabelFont(font7, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font7, (java.awt.Paint) color10);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font7);
        double double13 = labelBlock12.getHeight();
        labelBlock12.setMargin(2.0d, (double) 96, 1.0d, (double) 5);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint8 = intervalBarRenderer5.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, paint8);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!", font2, paint8, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean15 = intervalBarRenderer12.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font17 = null;
        intervalBarRenderer12.setSeriesItemLabelFont((int) '4', font17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener23 = null;
        numberAxis22.addChangeListener(axisChangeListener23);
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        intervalBarRenderer12.drawRangeMarker(graphics2D19, categoryPlot20, (org.jfree.chart.axis.ValueAxis) numberAxis22, marker25, rectangle2D26);
        boolean boolean28 = textFragment11.equals((java.lang.Object) graphics2D19);
        java.awt.Font font29 = textFragment11.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis33.setAutoRangeStickyZero(false);
        numberAxis33.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer38 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean41 = intervalBarRenderer38.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font43 = null;
        intervalBarRenderer38.setSeriesItemLabelFont((int) '4', font43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener49 = null;
        numberAxis48.addChangeListener(axisChangeListener49);
        org.jfree.chart.plot.Marker marker51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        intervalBarRenderer38.drawRangeMarker(graphics2D45, categoryPlot46, (org.jfree.chart.axis.ValueAxis) numberAxis48, marker51, rectangle2D52);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer38);
        org.jfree.chart.JFreeChart jFreeChart56 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", font29, (org.jfree.chart.plot.Plot) categoryPlot54, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = categoryPlot54.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge57);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textBlock9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis13.setAutoRangeStickyZero(false);
        numberAxis13.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean21 = intervalBarRenderer18.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font23 = null;
        intervalBarRenderer18.setSeriesItemLabelFont((int) '4', font23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener29 = null;
        numberAxis28.addChangeListener(axisChangeListener29);
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        intervalBarRenderer18.drawRangeMarker(graphics2D25, categoryPlot26, (org.jfree.chart.axis.ValueAxis) numberAxis28, marker31, rectangle2D32);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer18);
        double double35 = categoryPlot34.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation36 = categoryPlot34.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent37 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot34);
        xYPlot9.notifyListeners(plotChangeEvent37);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot9.setDataset(xYDataset39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Point2D point2D44 = null;
        xYPlot9.zoomRangeAxes((double) (byte) 100, (double) '#', plotRenderingInfo43, point2D44);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation36);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("{0}");
        java.lang.Object obj4 = jFreeChartResources0.handleGetObject("CategoryAnchor.MIDDLE");
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setAutoRangeStickyZero(false);
        boolean boolean7 = numberAxis1.equals((java.lang.Object) (byte) 10);
        double double8 = numberAxis1.getUpperBound();
        boolean boolean9 = numberAxis1.isPositiveArrowVisible();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis12.setAutoRangeStickyZero(false);
        numberAxis12.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis12, valueAxis17, xYItemRenderer18);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke22 = intervalBarRenderer20.lookupSeriesStroke(3);
        xYPlot19.setDomainGridlineStroke(stroke22);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot19.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot19.getRangeAxisEdge();
        boolean boolean29 = numberAxis1.hasListener((java.util.EventListener) xYPlot19);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(15);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        numberAxis2.setUpperBound((double) 68);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        layeredBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = layeredBarRenderer0.getSeriesToolTipGenerator(3);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat4);
        boolean boolean7 = dateTickUnit5.equals((java.lang.Object) (short) -1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer8.setBaseItemLabelPaint(paint9);
        boolean boolean12 = intervalBarRenderer8.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke16 = intervalBarRenderer14.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = intervalBarRenderer14.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer8.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition18);
        java.awt.Shape shape20 = intervalBarRenderer8.getBaseShape();
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray28, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset34);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity38 = new org.jfree.chart.entity.CategoryItemEntity(shape20, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset34, (java.lang.Comparable) 8.0d, (java.lang.Comparable) 0.0f);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity41 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) boolean7, shape20, "", "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity42 = new org.jfree.chart.entity.ChartEntity(shape20);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range35);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.LegendItem legendItem3 = lineRenderer3D0.getLegendItem((int) (short) 10, (int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = lineRenderer3D0.getDrawingSupplier();
        lineRenderer3D0.setDrawOutlines(false);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNull(drawingSupplier4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        java.awt.Font font3 = intervalMarker2.getLabelFont();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis6.setAutoRangeStickyZero(false);
        numberAxis6.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis6, valueAxis11, xYItemRenderer12);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke16 = intervalBarRenderer14.lookupSeriesStroke(3);
        xYPlot13.setDomainGridlineStroke(stroke16);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot13.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis20);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis26.setAutoRangeStickyZero(false);
        double double29 = numberAxis26.getUpperBound();
        xYPlot13.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis26, false);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot32 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis34.setAutoRangeStickyZero(false);
        numberAxis34.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat39 = numberAxis34.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = numberAxis34.getTickLabelInsets();
        waferMapPlot32.setInsets(rectangleInsets40);
        xYPlot13.setAxisOffset(rectangleInsets40);
        intervalMarker2.setLabelOffset(rectangleInsets40);
        double double45 = rectangleInsets40.calculateBottomInset(0.0d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNull(numberFormat39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 2.0d + "'", double45 == 2.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) "PlotOrientation.VERTICAL");
        int int2 = keyToGroupMap1.getGroupCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        intervalMarker2.setLabel("hi!");
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder();
        boolean boolean6 = intervalMarker2.equals((java.lang.Object) lineBorder5);
        java.awt.Paint paint7 = intervalMarker2.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis9.setAutoRangeStickyZero(false);
        java.awt.Paint paint12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis9.setTickMarkPaint(paint12);
        java.lang.Class<?> wildcardClass14 = paint12.getClass();
        intervalMarker2.setOutlinePaint(paint12);
        java.lang.Object obj16 = intervalMarker2.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        int int30 = categoryPlot24.getBackgroundImageAlignment();
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = null;
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis36.setAutoRangeStickyZero(false);
        numberAxis36.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer41 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean44 = intervalBarRenderer41.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font46 = null;
        intervalBarRenderer41.setSeriesItemLabelFont((int) '4', font46);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = null;
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener52 = null;
        numberAxis51.addChangeListener(axisChangeListener52);
        org.jfree.chart.plot.Marker marker54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        intervalBarRenderer41.drawRangeMarker(graphics2D48, categoryPlot49, (org.jfree.chart.axis.ValueAxis) numberAxis51, marker54, rectangle2D55);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis36, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer41);
        double double58 = categoryPlot57.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation59 = categoryPlot57.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent60 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot57);
        org.jfree.chart.util.Layer layer62 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection63 = categoryPlot57.getDomainMarkers((int) ' ', layer62);
        try {
            categoryPlot24.addDomainMarker((int) (byte) 10, categoryMarker32, layer62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(layer62);
        org.junit.Assert.assertNull(collection63);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot24.rendererChanged(rendererChangeEvent30);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot24);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier33 = null;
        categoryPlot24.setDrawingSupplier(drawingSupplier33);
        categoryPlot24.setWeight(10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "", font2);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) 0);
        categoryAxis0.setMaximumCategoryLabelLines((int) (byte) 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset8 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset8, jFreeChart9, 0, (int) (byte) 100);
        int int13 = chartProgressEvent12.getPercent();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint22 = intervalBarRenderer19.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("", font18, paint22);
        org.jfree.chart.text.TextFragment textFragment25 = new org.jfree.chart.text.TextFragment("hi!", font16, paint22, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer26 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean29 = intervalBarRenderer26.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font31 = null;
        intervalBarRenderer26.setSeriesItemLabelFont((int) '4', font31);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = null;
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener37 = null;
        numberAxis36.addChangeListener(axisChangeListener37);
        org.jfree.chart.plot.Marker marker39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        intervalBarRenderer26.drawRangeMarker(graphics2D33, categoryPlot34, (org.jfree.chart.axis.ValueAxis) numberAxis36, marker39, rectangle2D40);
        boolean boolean42 = textFragment25.equals((java.lang.Object) graphics2D33);
        java.awt.Font font43 = textFragment25.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis47.setAutoRangeStickyZero(false);
        numberAxis47.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer52 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean55 = intervalBarRenderer52.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font57 = null;
        intervalBarRenderer52.setSeriesItemLabelFont((int) '4', font57);
        java.awt.Graphics2D graphics2D59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = null;
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener63 = null;
        numberAxis62.addChangeListener(axisChangeListener63);
        org.jfree.chart.plot.Marker marker65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        intervalBarRenderer52.drawRangeMarker(graphics2D59, categoryPlot60, (org.jfree.chart.axis.ValueAxis) numberAxis62, marker65, rectangle2D66);
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) numberAxis47, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer52);
        org.jfree.chart.JFreeChart jFreeChart70 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", font43, (org.jfree.chart.plot.Plot) categoryPlot68, false);
        chartProgressEvent12.setChart(jFreeChart70);
        jFreeChart70.setTitle("");
        org.jfree.chart.title.LegendTitle legendTitle75 = jFreeChart70.getLegend(10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType76 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent77 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis0, jFreeChart70, chartChangeEventType76);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNull(legendTitle75);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        int int5 = chartProgressEvent4.getPercent();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint14 = intervalBarRenderer11.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, paint14);
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("hi!", font8, paint14, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean21 = intervalBarRenderer18.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font23 = null;
        intervalBarRenderer18.setSeriesItemLabelFont((int) '4', font23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener29 = null;
        numberAxis28.addChangeListener(axisChangeListener29);
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        intervalBarRenderer18.drawRangeMarker(graphics2D25, categoryPlot26, (org.jfree.chart.axis.ValueAxis) numberAxis28, marker31, rectangle2D32);
        boolean boolean34 = textFragment17.equals((java.lang.Object) graphics2D25);
        java.awt.Font font35 = textFragment17.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis39.setAutoRangeStickyZero(false);
        numberAxis39.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean47 = intervalBarRenderer44.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font49 = null;
        intervalBarRenderer44.setSeriesItemLabelFont((int) '4', font49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener55 = null;
        numberAxis54.addChangeListener(axisChangeListener55);
        org.jfree.chart.plot.Marker marker57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        intervalBarRenderer44.drawRangeMarker(graphics2D51, categoryPlot52, (org.jfree.chart.axis.ValueAxis) numberAxis54, marker57, rectangle2D58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer44);
        org.jfree.chart.JFreeChart jFreeChart62 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", font35, (org.jfree.chart.plot.Plot) categoryPlot60, false);
        chartProgressEvent4.setChart(jFreeChart62);
        jFreeChart62.setTitle("");
        org.jfree.chart.title.LegendTitle legendTitle67 = jFreeChart62.getLegend(10);
        jFreeChart62.setBackgroundImageAlignment((int) (byte) -1);
        java.awt.Color color73 = java.awt.Color.getHSBColor((float) (short) 1, (float) 10L, 10.0f);
        jFreeChart62.setBackgroundPaint((java.awt.Paint) color73);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNull(legendTitle67);
        org.junit.Assert.assertNotNull(color73);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) (short) -1);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 255);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 100);
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat12);
        boolean boolean15 = dateTickUnit13.equals((java.lang.Object) (short) -1);
        int int16 = dateTickUnit13.getUnit();
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) int16);
        java.util.List list18 = defaultKeyedValues2D1.getColumnKeys();
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) "", (java.lang.Comparable) 900000L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 1, 255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick8 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0, "hi!", textAnchor5, textAnchor6, (double) 4);
        org.jfree.chart.axis.NumberTick numberTick10 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 6, "({0}, {1}) = {2}", textAnchor2, textAnchor6, 2.0d);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Shape shape5 = null;
        java.awt.Color color6 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", "hi!", shape5, (java.awt.Paint) color6);
        boolean boolean8 = legendItem7.isShapeOutlineVisible();
        int int9 = legendItem7.getDatasetIndex();
        java.awt.Paint paint10 = legendItem7.getLinePaint();
        lineRenderer3D0.setWallPaint(paint10);
        lineRenderer3D0.setYOffset((double) (short) 100);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        strokeList0.clear();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge3);
        boolean boolean5 = strokeList0.equals((java.lang.Object) rectangleEdge4);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot9.getRangeAxisLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = xYPlot9.getInsets();
        double double18 = rectangleInsets16.calculateBottomInset(0.0d);
        org.jfree.chart.util.UnitType unitType19 = rectangleInsets16.getUnitType();
        java.lang.String str20 = unitType19.toString();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertNotNull(unitType19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UnitType.ABSOLUTE" + "'", str20.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setIgnoreZeroValues(true);
        double double5 = piePlot1.getExplodePercent((java.lang.Comparable) 0L);
        piePlot1.setLabelGap((double) 68);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Number number2 = null;
        defaultKeyedValues0.addValue((java.lang.Comparable) 8.0d, number2);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer4 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean5 = defaultKeyedValues0.equals((java.lang.Object) boxAndWhiskerRenderer4);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str8 = dateAxis7.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis7.setTickMarkPosition(dateTickMarkPosition9);
        java.text.DateFormat dateFormat15 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat15);
        java.util.Date date17 = dateAxis7.calculateHighestVisibleTickValue(dateTickUnit16);
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick24 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0, "hi!", textAnchor21, textAnchor22, (double) 4);
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.DateTick dateTick27 = new org.jfree.chart.axis.DateTick(date17, "hi!", textAnchor22, textAnchor25, (double) 2958465);
        boolean boolean28 = defaultKeyedValues0.equals((java.lang.Object) dateTick27);
        org.jfree.chart.text.TextAnchor textAnchor29 = dateTick27.getTextAnchor();
        double double30 = dateTick27.getValue();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot9.getRangeAxisEdge();
        xYPlot9.clearDomainMarkers((int) '4');
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot9);
        jFreeChart21.setBackgroundImageAlpha((float) '4');
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = xYPlot9.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot9.setRangeAxisLocation(axisLocation19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot9.getRangeAxisLocation((int) (byte) -1);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        centerArrangement0.clear();
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "", font2);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) 0);
        categoryAxis0.setMaximumCategoryLabelLines((int) (byte) 10);
        categoryAxis0.setUpperMargin((double) 0);
        float float10 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("CategoryAnchor.MIDDLE");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        taskSeries1.removeChangeListener(seriesChangeListener4);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        double double4 = numberAxis1.getUpperBound();
        numberAxis1.setLabelURL("hi!");
        numberAxis1.setTickLabelsVisible(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        numberAxis1.setTickUnit(numberTickUnit10, false, false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.extendHeight(Double.NaN);
        java.lang.String str3 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(12.0d, (double) (-1));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) categoryLabelPosition3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = categoryLabelPositions6.getLabelPosition(rectangleEdge7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge12);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = categoryLabelPositions11.getLabelPosition(rectangleEdge12);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition3, categoryLabelPosition9, categoryLabelPosition14, categoryLabelPosition15);
        double double17 = categoryLabelPosition14.getAngle();
        float float18 = categoryLabelPosition14.getWidthRatio();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(categoryLabelPosition9);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(categoryLabelPosition14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 97.0d + "'", double17 == 97.0d);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font5 = null;
        intervalBarRenderer0.setSeriesItemLabelFont((int) '4', font5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = intervalBarRenderer0.getPositiveItemLabelPosition(15, (int) (short) 10);
        intervalBarRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.awt.Shape shape14 = piePlot13.getLegendItemShape();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = piePlot13.getLegendItems();
        java.awt.Paint paint16 = piePlot13.getLabelOutlinePaint();
        intervalBarRenderer0.setBasePaint(paint16, true);
        double double19 = intervalBarRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.awt.Color color1 = java.awt.Color.getColor("Category Plot");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", "hi!", shape4, (java.awt.Paint) color5);
        boolean boolean7 = legendItem6.isShapeOutlineVisible();
        int int8 = legendItem6.getDatasetIndex();
        legendItem6.setSeriesIndex((int) (byte) 1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot24.rendererChanged(rendererChangeEvent30);
        categoryPlot24.mapDatasetToDomainAxis((int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        long long2 = segmentedTimeline0.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str6 = dateRange5.toString();
        java.util.Date date7 = dateRange5.getLowerDate();
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str11 = dateRange10.toString();
        java.util.Date date12 = dateRange10.getLowerDate();
        boolean boolean13 = segmentedTimeline0.containsDomainRange(date7, date12);
        java.util.Date date14 = null;
        try {
            org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(date12, date14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 86400000L + "'", long2 == 86400000L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str6.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str11.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot24.zoomRangeAxes(0.0d, (double) 4, plotRenderingInfo28, point2D29);
        int int31 = categoryPlot24.getWeight();
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot24.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot24.setRangeAxisLocation((int) (byte) 0, axisLocation34, true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        boolean boolean3 = dateAxis1.equals((java.lang.Object) itemLabelAnchor2);
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray9, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset15);
        java.lang.String str17 = range16.toString();
        dateAxis1.setRange(range16);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Range[-1.0,1.0]" + "'", str17.equals("Range[-1.0,1.0]"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot1.setURLGenerator(pieURLGenerator3);
        java.awt.Paint paint5 = piePlot1.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        double double18 = dateAxis16.getLabelAngle();
        dateAxis16.setNegativeArrowVisible(true);
        java.awt.Paint paint21 = dateAxis16.getTickMarkPaint();
        double double22 = dateAxis16.getUpperBound();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", "hi!", shape4, (java.awt.Paint) color5);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = legendItem6.getFillPaintTransformer();
        java.awt.Shape shape12 = null;
        java.awt.Color color13 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", "hi!", shape12, (java.awt.Paint) color13);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = legendItem14.getFillPaintTransformer();
        legendItem6.setFillPaintTransformer(gradientPaintTransformer15);
        legendItem6.setSeriesKey((java.lang.Comparable) 100);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setDomainCrosshairVisible(false);
        int int20 = xYPlot9.getBackgroundImageAlignment();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis23.setAutoRangeStickyZero(false);
        numberAxis23.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) numberAxis23, valueAxis28, xYItemRenderer29);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer31 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke33 = intervalBarRenderer31.lookupSeriesStroke(3);
        xYPlot30.setDomainGridlineStroke(stroke33);
        java.awt.Stroke stroke35 = xYPlot30.getRangeZeroBaselineStroke();
        xYPlot30.clearDomainMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot30.setRangeAxisLocation(axisLocation37);
        xYPlot9.setRangeAxisLocation(axisLocation37, true);
        org.jfree.data.general.DatasetGroup datasetGroup41 = xYPlot9.getDatasetGroup();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(datasetGroup41);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.text.DateFormat dateFormat8 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat8);
        boolean boolean11 = dateTickUnit9.equals((java.lang.Object) (short) -1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer12.setBaseItemLabelPaint(paint13);
        boolean boolean16 = intervalBarRenderer12.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke20 = intervalBarRenderer18.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = intervalBarRenderer18.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer12.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition22);
        java.awt.Shape shape24 = intervalBarRenderer12.getBaseShape();
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray32, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray37);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset38);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity42 = new org.jfree.chart.entity.CategoryItemEntity(shape24, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset38, (java.lang.Comparable) 8.0d, (java.lang.Comparable) 0.0f);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity45 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) boolean11, shape24, "", "hi!");
        java.lang.Number[] numberArray55 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray59 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray60 = new java.lang.Number[][] { numberArray55, numberArray59 };
        org.jfree.data.category.CategoryDataset categoryDataset61 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray60);
        org.jfree.data.category.CategoryDataset categoryDataset62 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", numberArray60);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity65 = new org.jfree.chart.entity.CategoryItemEntity(shape24, "Range[-1.0,1.0]", "magenta", categoryDataset62, (java.lang.Comparable) 10.0f, (java.lang.Comparable) 8.0d);
        java.awt.Paint paint67 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        java.awt.Stroke stroke68 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker69 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1, paint67, stroke68);
        java.awt.Paint paint70 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem71 = new org.jfree.chart.LegendItem("TextAnchor.BASELINE_CENTER", "", "March", "CategoryLabelEntity: category=false, tooltip=, url=hi!", shape24, stroke68, paint70);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(categoryDataset61);
        org.junit.Assert.assertNotNull(categoryDataset62);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(paint70);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot24.setRangeAxisLocation(axisLocation26, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis31.setAutoRangeStickyZero(false);
        numberAxis31.setAutoRangeStickyZero(false);
        categoryPlot24.setRangeAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) numberAxis31, true);
        float float38 = numberAxis31.getTickMarkOutsideLength();
        numberAxis31.setUpperBound((double) 86400000L);
        double double41 = numberAxis31.getLabelAngle();
        boolean boolean42 = numberAxis31.isInverted();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 2.0f + "'", float38 == 2.0f);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke4 = intervalBarRenderer3.getBaseOutlineStroke();
        stackedBarRenderer3D1.setSeriesOutlineStroke((int) (short) 10, stroke4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedBarRenderer3D1.setSeriesPaint((int) '#', (java.awt.Paint) color7);
        java.lang.Boolean boolean10 = stackedBarRenderer3D1.getSeriesVisible((int) 'a');
        java.awt.Paint paint13 = stackedBarRenderer3D1.getItemOutlinePaint((int) '4', (-1));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = stackedBarRenderer3D1.getNegativeItemLabelPosition(2958465, 5);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        int int5 = chartProgressEvent4.getPercent();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint14 = intervalBarRenderer11.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, paint14);
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("hi!", font8, paint14, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean21 = intervalBarRenderer18.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font23 = null;
        intervalBarRenderer18.setSeriesItemLabelFont((int) '4', font23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener29 = null;
        numberAxis28.addChangeListener(axisChangeListener29);
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        intervalBarRenderer18.drawRangeMarker(graphics2D25, categoryPlot26, (org.jfree.chart.axis.ValueAxis) numberAxis28, marker31, rectangle2D32);
        boolean boolean34 = textFragment17.equals((java.lang.Object) graphics2D25);
        java.awt.Font font35 = textFragment17.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis39.setAutoRangeStickyZero(false);
        numberAxis39.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean47 = intervalBarRenderer44.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font49 = null;
        intervalBarRenderer44.setSeriesItemLabelFont((int) '4', font49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener55 = null;
        numberAxis54.addChangeListener(axisChangeListener55);
        org.jfree.chart.plot.Marker marker57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        intervalBarRenderer44.drawRangeMarker(graphics2D51, categoryPlot52, (org.jfree.chart.axis.ValueAxis) numberAxis54, marker57, rectangle2D58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer44);
        org.jfree.chart.JFreeChart jFreeChart62 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", font35, (org.jfree.chart.plot.Plot) categoryPlot60, false);
        chartProgressEvent4.setChart(jFreeChart62);
        jFreeChart62.setTitle("");
        org.jfree.chart.title.LegendTitle legendTitle67 = jFreeChart62.getLegend(10);
        try {
            org.jfree.chart.title.Title title69 = jFreeChart62.getSubtitle(178);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNull(legendTitle67);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
        java.lang.String str10 = projectInfo7.getInfo();
        org.jfree.chart.ui.Library[] libraryArray11 = projectInfo7.getOptionalLibraries();
        java.awt.Image image15 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo19 = new org.jfree.chart.ui.ProjectInfo("", "", "", image15, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image20 = null;
        projectInfo19.setLogo(image20);
        java.lang.String str22 = projectInfo19.getInfo();
        org.jfree.chart.ui.Library[] libraryArray23 = projectInfo19.getOptionalLibraries();
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo19);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis26.setAutoRangeStickyZero(false);
        boolean boolean29 = projectInfo7.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(libraryArray11);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(libraryArray23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", "hi!", shape4, (java.awt.Paint) color5);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = legendItem6.getFillPaintTransformer();
        java.lang.Comparable comparable8 = legendItem6.getSeriesKey();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
        org.junit.Assert.assertNull(comparable8);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        int int5 = chartProgressEvent4.getPercent();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint14 = intervalBarRenderer11.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, paint14);
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("hi!", font8, paint14, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean21 = intervalBarRenderer18.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font23 = null;
        intervalBarRenderer18.setSeriesItemLabelFont((int) '4', font23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener29 = null;
        numberAxis28.addChangeListener(axisChangeListener29);
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        intervalBarRenderer18.drawRangeMarker(graphics2D25, categoryPlot26, (org.jfree.chart.axis.ValueAxis) numberAxis28, marker31, rectangle2D32);
        boolean boolean34 = textFragment17.equals((java.lang.Object) graphics2D25);
        java.awt.Font font35 = textFragment17.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis39.setAutoRangeStickyZero(false);
        numberAxis39.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean47 = intervalBarRenderer44.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font49 = null;
        intervalBarRenderer44.setSeriesItemLabelFont((int) '4', font49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener55 = null;
        numberAxis54.addChangeListener(axisChangeListener55);
        org.jfree.chart.plot.Marker marker57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        intervalBarRenderer44.drawRangeMarker(graphics2D51, categoryPlot52, (org.jfree.chart.axis.ValueAxis) numberAxis54, marker57, rectangle2D58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer44);
        org.jfree.chart.JFreeChart jFreeChart62 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", font35, (org.jfree.chart.plot.Plot) categoryPlot60, false);
        chartProgressEvent4.setChart(jFreeChart62);
        int int64 = chartProgressEvent4.getPercent();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font5 = null;
        intervalBarRenderer0.setSeriesItemLabelFont((int) '4', font5);
        java.lang.Object obj7 = intervalBarRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) (short) -1);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 255);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 100);
        java.text.DateFormat dateFormat13 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat13);
        int int15 = dateTickUnit14.getRollUnit();
        java.lang.String str17 = dateTickUnit14.valueToString((double) 1);
        int int19 = dateTickUnit14.compareTo((java.lang.Object) (-65536));
        try {
            java.lang.Number number20 = defaultKeyedValues2D1.getValue((java.lang.Comparable) "Range[-1.0,1.0]", (java.lang.Comparable) dateTickUnit14);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: DateTickUnit[MILLISECOND, 1]");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "12/31/69" + "'", str17.equals("12/31/69"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot9.getRangeAxisLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = xYPlot9.getInsets();
        double double18 = rectangleInsets16.calculateLeftInset((double) 0.0f);
        double double20 = rectangleInsets16.calculateRightInset((double) 4);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8.0d + "'", double20 == 8.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        java.awt.Paint paint25 = intervalBarRenderer8.getBasePaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = null;
        intervalBarRenderer8.setLegendItemToolTipGenerator(categorySeriesLabelGenerator26);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator28 = intervalBarRenderer8.getBaseURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryURLGenerator28);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getShadowPaint();
        boolean boolean2 = piePlot0.getIgnoreZeroValues();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = piePlot0.getURLGenerator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieURLGenerator3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        numberAxis1.setTickLabelPaint(paint7);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis16.setAutoRangeStickyZero(false);
        numberAxis16.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean24 = intervalBarRenderer21.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font26 = null;
        intervalBarRenderer21.setSeriesItemLabelFont((int) '4', font26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener32 = null;
        numberAxis31.addChangeListener(axisChangeListener32);
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        intervalBarRenderer21.drawRangeMarker(graphics2D28, categoryPlot29, (org.jfree.chart.axis.ValueAxis) numberAxis31, marker34, rectangle2D35);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer21);
        categoryPlot37.configureRangeAxes();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        org.jfree.chart.axis.AxisSpace axisSpace42 = numberAxis1.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) categoryPlot37, rectangle2D39, rectangleEdge40, axisSpace41);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke45 = intervalBarRenderer44.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator47 = intervalBarRenderer44.getSeriesItemLabelGenerator((int) (short) 10);
        categoryPlot37.setRenderer(6, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer44, false);
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis("PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline54 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline55 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int56 = segmentedTimeline55.getSegmentsExcluded();
        long long57 = segmentedTimeline55.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange60 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str61 = dateRange60.toString();
        java.util.Date date62 = dateRange60.getLowerDate();
        org.jfree.data.time.DateRange dateRange65 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str66 = dateRange65.toString();
        java.util.Date date67 = dateRange65.getLowerDate();
        boolean boolean68 = segmentedTimeline55.containsDomainRange(date62, date67);
        java.util.Date date70 = segmentedTimeline55.getDate((long) 10);
        segmentedTimeline54.addException(date70);
        java.awt.Paint paint72 = categoryAxis53.getTickLabelPaint((java.lang.Comparable) date70);
        org.jfree.chart.plot.CategoryMarker categoryMarker73 = null;
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        try {
            intervalBarRenderer44.drawDomainMarker(graphics2D50, categoryPlot51, categoryAxis53, categoryMarker73, rectangle2D74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(axisSpace42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNull(categoryItemLabelGenerator47);
        org.junit.Assert.assertNotNull(segmentedTimeline54);
        org.junit.Assert.assertNotNull(segmentedTimeline55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 68 + "'", int56 == 68);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 86400000L + "'", long57 == 86400000L);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str61.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str66.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(paint72);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke1 = intervalBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = intervalBarRenderer0.getSeriesItemLabelGenerator((int) (short) 10);
        intervalBarRenderer0.setMaximumBarWidth((double) 2);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryAxis7.setTickMarkStroke(stroke8);
        try {
            intervalBarRenderer0.setSeriesStroke((-65536), stroke8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        segmentedTimeline0.addException(0L);
        java.util.List list4 = segmentedTimeline0.getExceptionSegments();
        long long6 = segmentedTimeline0.toMillisecond((long) (short) 10);
        segmentedTimeline0.setAdjustForDaylightSaving(false);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2208927599990L) + "'", long6 == (-2208927599990L));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(12.0d, (double) (-1));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean5 = stackedBarRenderer3D3.equals((java.lang.Object) categoryLabelPosition4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge8);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = categoryLabelPositions7.getLabelPosition(rectangleEdge8);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge13);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = categoryLabelPositions12.getLabelPosition(rectangleEdge13);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition16 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition4, categoryLabelPosition10, categoryLabelPosition15, categoryLabelPosition16);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType18 = categoryLabelPosition16.getWidthType();
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(categoryLabelPosition10);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(categoryLabelPosition15);
        org.junit.Assert.assertNotNull(categoryLabelWidthType18);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double2 = defaultBoxAndWhiskerCategoryDataset0.getRangeUpperBound(true);
        defaultBoxAndWhiskerCategoryDataset0.validateObject();
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) "WMAP_Plot");
        int int2 = keyToGroupMap1.getGroupCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.DESCENDING" + "'", str1.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        multiplePiePlot0.setAggregatedItemsPaint(paint1);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        xYPlot9.setRangeAxis(valueAxis14);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = categoryPlot24.getDatasetRenderingOrder();
        categoryPlot24.configureRangeAxes();
        java.lang.String str27 = categoryPlot24.getPlotType();
        org.jfree.chart.axis.AxisSpace axisSpace28 = categoryPlot24.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Category Plot" + "'", str27.equals("Category Plot"));
        org.junit.Assert.assertNull(axisSpace28);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis2.setTickMarkPaint(paint5);
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape0, paint5);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = legendGraphic7.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer8);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        chartRenderingInfo1.clear();
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer3.setBaseItemLabelPaint(paint4);
        boolean boolean7 = intervalBarRenderer3.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer3.setBaseItemLabelFont(font8, false);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font8, (java.awt.Paint) color11);
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("", font8);
        labelBlock13.setID("Category Plot");
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint22 = intervalBarRenderer19.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("", font18, paint22);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer24 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer24.setBaseItemLabelPaint(paint25);
        org.jfree.chart.text.TextLine textLine27 = new org.jfree.chart.text.TextLine("", font18, paint25);
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock13, (java.lang.Object) "");
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis31.setAutoRangeStickyZero(false);
        numberAxis31.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis31, valueAxis36, xYItemRenderer37);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer39 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke41 = intervalBarRenderer39.lookupSeriesStroke(3);
        xYPlot38.setDomainGridlineStroke(stroke41);
        java.awt.Stroke stroke43 = xYPlot38.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = xYPlot38.getDomainMarkers(2, layer45);
        xYPlot38.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation50 = null;
        xYPlot38.setDomainAxisLocation((int) '#', axisLocation50);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis53.setAutoRangeStickyZero(false);
        xYPlot38.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis53);
        boolean boolean57 = centerArrangement0.equals((java.lang.Object) xYPlot38);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener61 = null;
        numberAxis60.addChangeListener(axisChangeListener61);
        double double63 = numberAxis60.getLabelAngle();
        org.jfree.chart.util.Size2D size2D67 = new org.jfree.chart.util.Size2D((double) 10L, (-1.0d));
        size2D67.setHeight((double) 10L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor72 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D73 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D67, 0.0d, (double) (-1L), rectangleAnchor72);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge74);
        double double76 = numberAxis60.java2DToValue((double) 0.95f, rectangle2D73, rectangleEdge75);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D78 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list79 = defaultKeyedValues2D78.getColumnKeys();
        xYPlot38.drawRangeTickBands(graphics2D58, rectangle2D73, list79);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.5949999988079071d + "'", double76 == 0.5949999988079071d);
        org.junit.Assert.assertNotNull(list79);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean6 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) paintArray5);
        org.jfree.data.general.DatasetGroup datasetGroup8 = new org.jfree.data.general.DatasetGroup("hi!");
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup8);
        org.jfree.data.KeyToGroupMap keyToGroupMap11 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) "PlotOrientation.VERTICAL");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator12 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str13 = standardCategoryToolTipGenerator12.getLabelFormat();
        boolean boolean14 = keyToGroupMap11.equals((java.lang.Object) str13);
        int int15 = keyToGroupMap11.getGroupCount();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, keyToGroupMap11);
        int int17 = defaultBoxAndWhiskerCategoryDataset0.getColumnCount();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Shape shape20 = null;
        intervalBarRenderer18.setSeriesShape(4, shape20, false);
        boolean boolean23 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "({0}, {1}) = {2}" + "'", str13.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        boolean boolean25 = intervalBarRenderer8.getBaseSeriesVisibleInLegend();
        boolean boolean26 = intervalBarRenderer8.getAutoPopulateSeriesShape();
        java.awt.Shape shape29 = intervalBarRenderer8.getItemShape((int) (short) 100, 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset30 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent34 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset30, jFreeChart31, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean36 = defaultBoxAndWhiskerCategoryDataset30.equals((java.lang.Object) paintArray35);
        org.jfree.data.Range range37 = intervalBarRenderer8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30);
        int int39 = defaultBoxAndWhiskerCategoryDataset30.getColumnIndex((java.lang.Comparable) Double.NaN);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30, true);
        boolean boolean42 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot9.getRangeAxisLocation();
        java.util.List list16 = xYPlot9.getAnnotations();
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection18 = xYPlot9.getRangeMarkers(layer17);
        xYPlot9.setNoDataMessage("TextAnchor.BASELINE_CENTER");
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis23.setAutoRangeStickyZero(false);
        numberAxis23.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) numberAxis23, valueAxis28, xYItemRenderer29);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer31 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke33 = intervalBarRenderer31.lookupSeriesStroke(3);
        xYPlot30.setDomainGridlineStroke(stroke33);
        java.awt.Stroke stroke35 = xYPlot30.getRangeZeroBaselineStroke();
        xYPlot30.setRangeGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis41.setAutoRangeStickyZero(false);
        numberAxis41.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset39, (org.jfree.chart.axis.ValueAxis) numberAxis41, valueAxis46, xYItemRenderer47);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer49 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke51 = intervalBarRenderer49.lookupSeriesStroke(3);
        xYPlot48.setDomainGridlineStroke(stroke51);
        java.awt.Stroke stroke53 = xYPlot48.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation54 = xYPlot48.getRangeAxisLocation();
        java.util.List list55 = xYPlot48.getAnnotations();
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection57 = xYPlot48.getRangeMarkers(layer56);
        java.util.Collection collection58 = xYPlot30.getDomainMarkers(6, layer56);
        java.util.Collection collection59 = xYPlot9.getDomainMarkers(layer56);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertNull(collection57);
        org.junit.Assert.assertNull(collection58);
        org.junit.Assert.assertNull(collection59);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str1 = standardCategoryToolTipGenerator0.getLabelFormat();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        boolean boolean3 = standardCategoryToolTipGenerator0.equals((java.lang.Object) itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "({0}, {1}) = {2}" + "'", str1.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = null;
        keyedObjects2D0.setObject(obj1, (java.lang.Comparable) "12/31/69", (java.lang.Comparable) "PlotOrientation.VERTICAL");
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis7.setAutoRangeStickyZero(false);
        numberAxis7.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, valueAxis12, xYItemRenderer13);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke17 = intervalBarRenderer15.lookupSeriesStroke(3);
        xYPlot14.setDomainGridlineStroke(stroke17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str21 = dateAxis20.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis20.setTickMarkPosition(dateTickMarkPosition22);
        java.text.DateFormat dateFormat28 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat28);
        java.util.Date date30 = dateAxis20.calculateHighestVisibleTickValue(dateTickUnit29);
        keyedObjects2D0.setObject((java.lang.Object) xYPlot14, (java.lang.Comparable) dateTickUnit29, (java.lang.Comparable) 0.2d);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        xYPlot14.setDataset(0, xYDataset34);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer3.setBaseItemLabelPaint(paint4);
        boolean boolean7 = intervalBarRenderer3.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer3.setBaseItemLabelFont(font8, false);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font8, (java.awt.Paint) color11);
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("", font8);
        labelBlock13.setID("Category Plot");
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint22 = intervalBarRenderer19.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("", font18, paint22);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer24 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer24.setBaseItemLabelPaint(paint25);
        org.jfree.chart.text.TextLine textLine27 = new org.jfree.chart.text.TextLine("", font18, paint25);
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock13, (java.lang.Object) "");
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis31.setAutoRangeStickyZero(false);
        numberAxis31.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis31, valueAxis36, xYItemRenderer37);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer39 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke41 = intervalBarRenderer39.lookupSeriesStroke(3);
        xYPlot38.setDomainGridlineStroke(stroke41);
        java.awt.Stroke stroke43 = xYPlot38.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = xYPlot38.getDomainMarkers(2, layer45);
        xYPlot38.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation50 = null;
        xYPlot38.setDomainAxisLocation((int) '#', axisLocation50);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis53.setAutoRangeStickyZero(false);
        xYPlot38.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis53);
        boolean boolean57 = centerArrangement0.equals((java.lang.Object) xYPlot38);
        org.jfree.chart.plot.IntervalMarker intervalMarker60 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        java.lang.Object obj61 = intervalMarker60.clone();
        java.lang.String str62 = intervalMarker60.getLabel();
        java.lang.String str63 = intervalMarker60.getLabel();
        org.jfree.data.category.CategoryDataset categoryDataset64 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = null;
        org.jfree.chart.axis.NumberAxis numberAxis67 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis67.setAutoRangeStickyZero(false);
        numberAxis67.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer72 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean75 = intervalBarRenderer72.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font77 = null;
        intervalBarRenderer72.setSeriesItemLabelFont((int) '4', font77);
        java.awt.Graphics2D graphics2D79 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot80 = null;
        org.jfree.chart.axis.NumberAxis numberAxis82 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener83 = null;
        numberAxis82.addChangeListener(axisChangeListener83);
        org.jfree.chart.plot.Marker marker85 = null;
        java.awt.geom.Rectangle2D rectangle2D86 = null;
        intervalBarRenderer72.drawRangeMarker(graphics2D79, categoryPlot80, (org.jfree.chart.axis.ValueAxis) numberAxis82, marker85, rectangle2D86);
        org.jfree.chart.plot.CategoryPlot categoryPlot88 = new org.jfree.chart.plot.CategoryPlot(categoryDataset64, categoryAxis65, (org.jfree.chart.axis.ValueAxis) numberAxis67, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer72);
        double double89 = categoryPlot88.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation90 = categoryPlot88.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent91 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot88);
        org.jfree.chart.util.Layer layer93 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection94 = categoryPlot88.getDomainMarkers((int) ' ', layer93);
        xYPlot38.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker60, layer93);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(obj61);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation90);
        org.junit.Assert.assertNotNull(layer93);
        org.junit.Assert.assertNull(collection94);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.Object obj1 = null;
        boolean boolean2 = datasetRenderingOrder0.equals(obj1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str2 = dateAxis1.getLabelToolTip();
        java.awt.Shape shape3 = dateAxis1.getDownArrow();
        java.text.DateFormat dateFormat4 = null;
        dateAxis1.setDateFormatOverride(dateFormat4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState10 = new org.jfree.chart.axis.AxisState((double) 4);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer13 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer13.setBaseItemLabelPaint(paint14);
        boolean boolean17 = intervalBarRenderer13.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer13.setBaseItemLabelFont(font18, false);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font18, (java.awt.Paint) color21);
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("", font18);
        labelBlock23.setID("Category Plot");
        java.awt.Paint paint26 = labelBlock23.getPaint();
        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        java.util.List list29 = categoryAxis7.refreshTicks(graphics2D8, axisState10, rectangle2D27, rectangleEdge28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint37 = intervalBarRenderer34.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font33, paint37);
        numberAxis31.setTickLabelPaint(paint37);
        numberAxis31.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis46.setAutoRangeStickyZero(false);
        numberAxis46.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer51 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean54 = intervalBarRenderer51.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font56 = null;
        intervalBarRenderer51.setSeriesItemLabelFont((int) '4', font56);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = null;
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener62 = null;
        numberAxis61.addChangeListener(axisChangeListener62);
        org.jfree.chart.plot.Marker marker64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        intervalBarRenderer51.drawRangeMarker(graphics2D58, categoryPlot59, (org.jfree.chart.axis.ValueAxis) numberAxis61, marker64, rectangle2D65);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) numberAxis46, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer51);
        categoryPlot67.configureRangeAxes();
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = null;
        org.jfree.chart.axis.AxisSpace axisSpace71 = null;
        org.jfree.chart.axis.AxisSpace axisSpace72 = numberAxis31.reserveSpace(graphics2D42, (org.jfree.chart.plot.Plot) categoryPlot67, rectangle2D69, rectangleEdge70, axisSpace71);
        double double73 = axisSpace72.getTop();
        axisSpace72.setLeft((double) '#');
        axisSpace72.setTop((double) 2958465);
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge79);
        axisSpace72.ensureAtLeast((double) (-2208960000000L), rectangleEdge80);
        double double82 = dateAxis1.valueToJava2D(68.0d, rectangle2D27, rectangleEdge80);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(axisSpace72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge79);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str7 = dateAxis6.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition8 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis6.setTickMarkPosition(dateTickMarkPosition8);
        java.text.DateFormat dateFormat14 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat14);
        java.util.Date date16 = dateAxis6.calculateHighestVisibleTickValue(dateTickUnit15);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis19.setAutoRangeStickyZero(false);
        java.awt.Paint paint22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis19.setTickMarkPaint(paint22);
        java.lang.Class<?> wildcardClass24 = paint22.getClass();
        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass24);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline26 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int27 = segmentedTimeline26.getSegmentsExcluded();
        long long28 = segmentedTimeline26.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange31 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str32 = dateRange31.toString();
        java.util.Date date33 = dateRange31.getLowerDate();
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str37 = dateRange36.toString();
        java.util.Date date38 = dateRange36.getLowerDate();
        boolean boolean39 = segmentedTimeline26.containsDomainRange(date33, date38);
        java.util.TimeZone timeZone40 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date33, timeZone40);
        org.jfree.data.gantt.Task task42 = new org.jfree.data.gantt.Task("({0}, {1}) = {2}", date16, date33);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str46 = dateAxis45.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition47 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis45.setTickMarkPosition(dateTickMarkPosition47);
        java.text.DateFormat dateFormat53 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat53);
        java.util.Date date55 = dateAxis45.calculateHighestVisibleTickValue(dateTickUnit54);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis58.setAutoRangeStickyZero(false);
        java.awt.Paint paint61 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis58.setTickMarkPaint(paint61);
        java.lang.Class<?> wildcardClass63 = paint61.getClass();
        java.lang.Object obj64 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass63);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline65 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int66 = segmentedTimeline65.getSegmentsExcluded();
        long long67 = segmentedTimeline65.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange70 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str71 = dateRange70.toString();
        java.util.Date date72 = dateRange70.getLowerDate();
        org.jfree.data.time.DateRange dateRange75 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str76 = dateRange75.toString();
        java.util.Date date77 = dateRange75.getLowerDate();
        boolean boolean78 = segmentedTimeline65.containsDomainRange(date72, date77);
        java.util.TimeZone timeZone79 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date72, timeZone79);
        org.jfree.data.gantt.Task task81 = new org.jfree.data.gantt.Task("({0}, {1}) = {2}", date55, date72);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) (-1));
        task81.setDuration((org.jfree.data.time.TimePeriod) simpleTimePeriod84);
        defaultCategoryDataset2.setValue((double) 255, (java.lang.Comparable) date16, (java.lang.Comparable) simpleTimePeriod84);
        try {
            java.lang.Number number87 = defaultCategoryDataset0.getValue((java.lang.Comparable) '4', (java.lang.Comparable) 255);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 255");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(dateTickMarkPosition8);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNotNull(segmentedTimeline26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 68 + "'", int27 == 68);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 86400000L + "'", long28 == 86400000L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str32.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str37.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(dateTickMarkPosition47);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNull(obj64);
        org.junit.Assert.assertNotNull(segmentedTimeline65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 68 + "'", int66 == 68);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 86400000L + "'", long67 == 86400000L);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str71.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str76.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(regularTimePeriod80);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        boolean boolean25 = intervalBarRenderer8.getBaseSeriesVisibleInLegend();
        boolean boolean26 = intervalBarRenderer8.getAutoPopulateSeriesShape();
        java.awt.Shape shape29 = intervalBarRenderer8.getItemShape((int) (short) 100, 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset30 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent34 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset30, jFreeChart31, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean36 = defaultBoxAndWhiskerCategoryDataset30.equals((java.lang.Object) paintArray35);
        org.jfree.data.Range range37 = intervalBarRenderer8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30);
        org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30, (java.lang.Comparable) 10);
        org.jfree.chart.plot.PiePlot3D piePlot3D40 = new org.jfree.chart.plot.PiePlot3D(pieDataset39);
        double double41 = piePlot3D40.getStartAngle();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(pieDataset39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 90.0d + "'", double41 == 90.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.geom.Point2D point2D3 = null;
        org.jfree.chart.plot.PlotState plotState4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            multiplePiePlot0.draw(graphics2D1, rectangle2D2, point2D3, plotState4, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        blockParams0.setGenerateEntities(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Shape shape2 = null;
        intervalBarRenderer0.setSeriesShape(4, shape2, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 4);
        java.lang.Object obj6 = rendererChangeEvent5.getRenderer();
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + 4 + "'", obj6.equals(4));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) 10, (java.lang.Number) 2, (java.lang.Number) 1.0E-8d, (java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 10L, (java.lang.Number) (short) 100, (java.lang.Number) 15, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getQ3();
        java.lang.String str11 = boxAndWhiskerItem9.toString();
        java.lang.String str12 = boxAndWhiskerItem9.toString();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0d + "'", number10.equals(100.0d));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis3.setTickMarkPaint(paint6);
        java.lang.Class<?> wildcardClass8 = paint6.getClass();
        java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass8);
        java.util.Date date10 = null;
        java.text.DateFormat dateFormat15 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat15);
        int int17 = dateTickUnit16.getRollUnit();
        java.lang.String str19 = dateTickUnit16.valueToString((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis23.setAutoRangeStickyZero(false);
        numberAxis23.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer28 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean31 = intervalBarRenderer28.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font33 = null;
        intervalBarRenderer28.setSeriesItemLabelFont((int) '4', font33);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener39 = null;
        numberAxis38.addChangeListener(axisChangeListener39);
        org.jfree.chart.plot.Marker marker41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        intervalBarRenderer28.drawRangeMarker(graphics2D35, categoryPlot36, (org.jfree.chart.axis.ValueAxis) numberAxis38, marker41, rectangle2D42);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis23, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer28);
        double double45 = categoryPlot44.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation46 = categoryPlot44.getDomainAxisLocation();
        java.awt.Paint paint47 = categoryPlot44.getNoDataMessagePaint();
        categoryPlot44.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent50 = null;
        categoryPlot44.rendererChanged(rendererChangeEvent50);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent52 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot44);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer54 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint55 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer54.setBaseItemLabelPaint(paint55);
        boolean boolean58 = intervalBarRenderer54.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font59 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer54.setBaseItemLabelFont(font59, false);
        categoryPlot44.setRenderer((int) (short) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer54, true);
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str67 = dateAxis66.getLabelToolTip();
        java.awt.Shape shape68 = dateAxis66.getDownArrow();
        boolean boolean70 = dateAxis66.isHiddenValue((long) (byte) -1);
        categoryPlot44.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) dateAxis66);
        java.util.Date date72 = dateAxis66.getMinimumDate();
        java.util.TimeZone timeZone73 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Date date74 = dateTickUnit16.rollDate(date72, timeZone73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date10, timeZone73);
        java.net.URL uRL76 = org.jfree.chart.util.ObjectUtilities.getResource("XY Plot", (java.lang.Class) wildcardClass8);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 35 + "'", int17 == 35);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "12/31/69" + "'", str19.equals("12/31/69"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertNull(uRL76);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis5.setAutoRangeStickyZero(false);
        numberAxis5.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean13 = intervalBarRenderer10.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font15 = null;
        intervalBarRenderer10.setSeriesItemLabelFont((int) '4', font15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener21 = null;
        numberAxis20.addChangeListener(axisChangeListener21);
        org.jfree.chart.plot.Marker marker23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        intervalBarRenderer10.drawRangeMarker(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis20, marker23, rectangle2D24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer10);
        double double27 = categoryPlot26.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot26.getDomainAxisLocation();
        java.awt.Paint paint29 = categoryPlot26.getNoDataMessagePaint();
        categoryPlot26.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        categoryPlot26.rendererChanged(rendererChangeEvent32);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent34 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot26);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit38 = new org.jfree.chart.axis.NumberTickUnit((double) ' ');
        numberAxis36.setTickUnit(numberTickUnit38, true, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker44 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer47 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer47.setBaseItemLabelPaint(paint48);
        boolean boolean51 = intervalBarRenderer47.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer47.setBaseItemLabelFont(font52, false);
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock56 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font52, (java.awt.Paint) color55);
        org.jfree.chart.block.LabelBlock labelBlock57 = new org.jfree.chart.block.LabelBlock("", font52);
        labelBlock57.setID("Category Plot");
        java.awt.Paint paint60 = labelBlock57.getPaint();
        java.awt.geom.Rectangle2D rectangle2D61 = labelBlock57.getBounds();
        lineRenderer3D0.drawRangeMarker(graphics2D1, categoryPlot26, (org.jfree.chart.axis.ValueAxis) numberAxis36, (org.jfree.chart.plot.Marker) intervalMarker44, rectangle2D61);
        double double63 = lineRenderer3D0.getYOffset();
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(textBlock56);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 8.0d + "'", double63 == 8.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("({0}, {1}) = {2}");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', 0, (int) (byte) 10);
        java.util.List list6 = segmentedTimeline5.getExceptionSegments();
        boolean boolean7 = standardCategoryURLGenerator1.equals((java.lang.Object) segmentedTimeline5);
        try {
            long long9 = segmentedTimeline5.toMillisecond(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment(0L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline3.getSegment(0L);
        boolean boolean6 = segment2.after(segment5);
        long long7 = segment2.getSegmentNumber();
        segment2.dec((long) 0);
        boolean boolean10 = segment2.inExcludeSegments();
        segment2.inc();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2454364L + "'", long7 == 2454364L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        int int3 = numberTickUnit1.compareTo((java.lang.Object) categoryLabelPositions2);
        java.lang.String str5 = numberTickUnit1.valueToString((double) '#');
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "35" + "'", str5.equals("35"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer23 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint26 = intervalBarRenderer23.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("", font22, paint26);
        numberAxis20.setTickLabelPaint(paint26);
        boolean boolean29 = numberAxis20.isAutoTickUnitSelection();
        numberAxis20.setLabelToolTip("Category Plot");
        numberAxis20.setRangeAboutValue((double) (byte) -1, 0.25d);
        xYPlot9.setDomainAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) numberAxis20, true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(textBlock27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.function.Function2D function2D0 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int5 = segmentedTimeline4.getSegmentsExcluded();
        segmentedTimeline4.addException(0L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int9 = segmentedTimeline8.getSegmentsExcluded();
        segmentedTimeline4.setBaseTimeline(segmentedTimeline8);
        int int11 = segmentedTimeline4.getGroupSegmentCount();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int13 = segmentedTimeline12.getSegmentsExcluded();
        long long14 = segmentedTimeline12.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str18 = dateRange17.toString();
        java.util.Date date19 = dateRange17.getLowerDate();
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str23 = dateRange22.toString();
        java.util.Date date24 = dateRange22.getLowerDate();
        boolean boolean25 = segmentedTimeline12.containsDomainRange(date19, date24);
        segmentedTimeline4.addException(date19);
        try {
            org.jfree.data.xy.XYDataset xYDataset27 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.4d, 8.0d, (-65536), (java.lang.Comparable) date19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 68 + "'", int5 == 68);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 68 + "'", int9 == 68);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 96 + "'", int11 == 96);
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 68 + "'", int13 == 68);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 86400000L + "'", long14 == 86400000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str18.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str23.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = categoryPlot24.getDatasetRenderingOrder();
        categoryPlot24.configureRangeAxes();
        categoryPlot24.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot24.getDomainAxis(255);
        categoryPlot24.setAnchorValue(3.0d, false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertNull(categoryAxis30);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke4 = intervalBarRenderer3.getBaseOutlineStroke();
        stackedBarRenderer3D1.setSeriesOutlineStroke((int) (short) 10, stroke4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedBarRenderer3D1.setSeriesPaint((int) '#', (java.awt.Paint) color7);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint17 = intervalBarRenderer14.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint17);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer19.setBaseItemLabelPaint(paint20);
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("", font13, paint20);
        java.awt.Color color26 = java.awt.Color.getHSBColor((float) (short) 1, (float) 10L, 10.0f);
        java.awt.Color color27 = color26.darker();
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font13, (java.awt.Paint) color27, (float) (-2208960000000L));
        stackedBarRenderer3D1.setSeriesPaint((int) ' ', (java.awt.Paint) color27, true);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator34 = new org.jfree.chart.urls.StandardCategoryURLGenerator("({0}, {1}) = {2}");
        try {
            stackedBarRenderer3D1.setSeriesURLGenerator((-2), (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        boolean boolean8 = numberAxis2.equals((java.lang.Object) (byte) 10);
        double double9 = numberAxis2.getUpperBound();
        java.lang.Comparable comparable11 = null;
        keyedObjects2D0.setObject((java.lang.Object) numberAxis2, (java.lang.Comparable) 0.25d, comparable11);
        org.jfree.data.KeyedObjects keyedObjects13 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean18 = intervalBarRenderer15.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font20 = null;
        intervalBarRenderer15.setSeriesItemLabelFont((int) '4', font20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener26 = null;
        numberAxis25.addChangeListener(axisChangeListener26);
        org.jfree.chart.plot.Marker marker28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        intervalBarRenderer15.drawRangeMarker(graphics2D22, categoryPlot23, (org.jfree.chart.axis.ValueAxis) numberAxis25, marker28, rectangle2D29);
        double double31 = intervalBarRenderer15.getItemMargin();
        keyedObjects13.addObject((java.lang.Comparable) 0, (java.lang.Object) double31);
        java.util.List list33 = keyedObjects13.getKeys();
        boolean boolean34 = keyedObjects2D0.equals((java.lang.Object) list33);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "", font2);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) 0);
        categoryAxis0.setMaximumCategoryLabelLines((int) (byte) 10);
        categoryAxis0.setUpperMargin((double) 0);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis12.setAutoRangeStickyZero(false);
        numberAxis12.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis12, valueAxis17, xYItemRenderer18);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke22 = intervalBarRenderer20.lookupSeriesStroke(3);
        xYPlot19.setDomainGridlineStroke(stroke22);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot19.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis26);
        float float28 = xYPlot19.getForegroundAlpha();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot19);
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot19.getDomainAxis();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
        org.junit.Assert.assertNotNull(valueAxis30);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey(100);
        int int4 = keyedObjects0.getIndex((java.lang.Comparable) (short) 0);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int6 = dateTickUnit5.getRollCount();
        int int7 = keyedObjects0.getIndex((java.lang.Comparable) dateTickUnit5);
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        categoryPlot24.configureDomainAxes();
        int int28 = categoryPlot24.getWeight();
        categoryPlot24.setRangeCrosshairValue(0.0d, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot24.zoomDomainAxes(0.25d, (double) (short) 100, plotRenderingInfo34, point2D35);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        java.awt.Color color2 = java.awt.Color.darkGray;
        boolean boolean3 = categoryLabelPositions1.equals((java.lang.Object) color2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener6 = null;
        numberAxis5.addChangeListener(axisChangeListener6);
        double double8 = numberAxis5.getLabelAngle();
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D((double) 10L, (-1.0d));
        size2D12.setHeight((double) 10L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, 0.0d, (double) (-1L), rectangleAnchor17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge19);
        double double21 = numberAxis5.java2DToValue((double) 0.95f, rectangle2D18, rectangleEdge20);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition22 = categoryLabelPositions1.getLabelPosition(rectangleEdge20);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.5949999988079071d + "'", double21 == 0.5949999988079071d);
        org.junit.Assert.assertNotNull(categoryLabelPosition22);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = piePlot1.getLegendItems();
        java.awt.Paint paint4 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        intervalMarker7.setLabel("hi!");
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder();
        boolean boolean11 = intervalMarker7.equals((java.lang.Object) lineBorder10);
        java.awt.Paint paint12 = intervalMarker7.getLabelPaint();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        intervalMarker7.setOutlinePaint((java.awt.Paint) color13);
        piePlot1.setShadowPaint((java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("CategoryAnchor.MIDDLE");
        java.lang.String str2 = taskSeries1.getDescription();
        taskSeries1.fireSeriesChanged();
        java.lang.Object obj4 = taskSeries1.clone();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        double double5 = numberAxis2.getUpperBound();
        numberAxis2.setLabelURL("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis8, xYItemRenderer9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis14.setAutoRangeStickyZero(false);
        numberAxis14.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean22 = intervalBarRenderer19.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font24 = null;
        intervalBarRenderer19.setSeriesItemLabelFont((int) '4', font24);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener30 = null;
        numberAxis29.addChangeListener(axisChangeListener30);
        org.jfree.chart.plot.Marker marker32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        intervalBarRenderer19.drawRangeMarker(graphics2D26, categoryPlot27, (org.jfree.chart.axis.ValueAxis) numberAxis29, marker32, rectangle2D33);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer19);
        double double36 = categoryPlot35.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot35.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent38 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection41 = categoryPlot35.getDomainMarkers((int) ' ', layer40);
        java.util.Collection collection42 = xYPlot10.getRangeMarkers(layer40);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        xYPlot10.drawAnnotations(graphics2D43, rectangle2D44, plotRenderingInfo45);
        boolean boolean47 = xYPlot10.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        xYPlot10.zoomDomainAxes((double) 60000L, plotRenderingInfo49, point2D50);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer1.setBaseItemLabelPaint(paint2);
        boolean boolean5 = intervalBarRenderer1.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke9 = intervalBarRenderer7.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = intervalBarRenderer7.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer1.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition11);
        java.awt.Shape shape13 = intervalBarRenderer1.getBaseShape();
        boolean boolean14 = verticalAlignment0.equals((java.lang.Object) shape13);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double[] doubleArray2 = new double[] { 90.0d, 100.0f };
        double[] doubleArray5 = new double[] { 90.0d, 100.0f };
        double[] doubleArray8 = new double[] { 90.0d, 100.0f };
        double[] doubleArray11 = new double[] { 90.0d, 100.0f };
        double[] doubleArray14 = new double[] { 90.0d, 100.0f };
        double[] doubleArray17 = new double[] { 90.0d, 100.0f };
        double[][] doubleArray18 = new double[][] { doubleArray2, doubleArray5, doubleArray8, doubleArray11, doubleArray14, doubleArray17 };
        double[] doubleArray25 = new double[] { 10, (short) 10, '4', 2.0d, 60000L, 2958465 };
        double[] doubleArray32 = new double[] { 10, (short) 10, '4', 2.0d, 60000L, 2958465 };
        double[] doubleArray39 = new double[] { 10, (short) 10, '4', 2.0d, 60000L, 2958465 };
        double[] doubleArray46 = new double[] { 10, (short) 10, '4', 2.0d, 60000L, 2958465 };
        double[] doubleArray53 = new double[] { 10, (short) 10, '4', 2.0d, 60000L, 2958465 };
        double[] doubleArray60 = new double[] { 10, (short) 10, '4', 2.0d, 60000L, 2958465 };
        double[][] doubleArray61 = new double[][] { doubleArray25, doubleArray32, doubleArray39, doubleArray46, doubleArray53, doubleArray60 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset62 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray18, doubleArray61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of categories in the start value dataset does not match the number of categories in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(12.0d, (double) (-1));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) categoryLabelPosition3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = categoryLabelPositions6.getLabelPosition(rectangleEdge7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge12);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = categoryLabelPositions11.getLabelPosition(rectangleEdge12);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition3, categoryLabelPosition9, categoryLabelPosition14, categoryLabelPosition15);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType17 = categoryLabelPosition15.getWidthType();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis20.setAutoRangeStickyZero(false);
        numberAxis20.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis20, valueAxis25, xYItemRenderer26);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer28 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke30 = intervalBarRenderer28.lookupSeriesStroke(3);
        xYPlot27.setDomainGridlineStroke(stroke30);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot27.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis34);
        float float36 = xYPlot27.getForegroundAlpha();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer42 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint45 = intervalBarRenderer42.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock46 = org.jfree.chart.text.TextUtilities.createTextBlock("", font41, paint45);
        numberAxis39.setTickLabelPaint(paint45);
        boolean boolean48 = numberAxis39.isAutoTickUnitSelection();
        numberAxis39.setLabelToolTip("Category Plot");
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis54.setAutoRangeStickyZero(false);
        numberAxis54.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer59 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean62 = intervalBarRenderer59.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font64 = null;
        intervalBarRenderer59.setSeriesItemLabelFont((int) '4', font64);
        java.awt.Graphics2D graphics2D66 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = null;
        org.jfree.chart.axis.NumberAxis numberAxis69 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener70 = null;
        numberAxis69.addChangeListener(axisChangeListener70);
        org.jfree.chart.plot.Marker marker72 = null;
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        intervalBarRenderer59.drawRangeMarker(graphics2D66, categoryPlot67, (org.jfree.chart.axis.ValueAxis) numberAxis69, marker72, rectangle2D73);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, (org.jfree.chart.axis.ValueAxis) numberAxis54, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer59);
        double double76 = categoryPlot75.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation77 = categoryPlot75.getDomainAxisLocation();
        java.awt.Paint paint78 = categoryPlot75.getNoDataMessagePaint();
        categoryPlot75.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation81 = categoryPlot75.getOrientation();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer82 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke84 = intervalBarRenderer82.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition86 = intervalBarRenderer82.getSeriesPositiveItemLabelPosition((int) '#');
        categoryPlot75.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer82);
        java.awt.Image image88 = categoryPlot75.getBackgroundImage();
        numberAxis39.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot75);
        xYPlot27.setRangeAxis(3, (org.jfree.chart.axis.ValueAxis) numberAxis39, false);
        boolean boolean92 = categoryLabelWidthType17.equals((java.lang.Object) xYPlot27);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(categoryLabelPosition9);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(categoryLabelPosition14);
        org.junit.Assert.assertNotNull(categoryLabelWidthType17);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 1.0f + "'", float36 == 1.0f);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(textBlock46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(plotOrientation81);
        org.junit.Assert.assertNotNull(stroke84);
        org.junit.Assert.assertNotNull(itemLabelPosition86);
        org.junit.Assert.assertNull(image88);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.clear();
        int int3 = defaultKeyedValues2D1.getRowCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        multiplePiePlot1.setAggregatedItemsKey((java.lang.Comparable) 1.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int3 = segmentedTimeline2.getSegmentsExcluded();
        long long4 = segmentedTimeline2.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str8 = dateRange7.toString();
        java.util.Date date9 = dateRange7.getLowerDate();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str13 = dateRange12.toString();
        java.util.Date date14 = dateRange12.getLowerDate();
        boolean boolean15 = segmentedTimeline2.containsDomainRange(date9, date14);
        java.util.Date date17 = segmentedTimeline2.getDate((long) 10);
        segmentedTimeline1.addException(date17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths(128, serialDate19);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 68 + "'", int3 == 68);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 86400000L + "'", long4 == 86400000L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str8.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str13.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        float float18 = xYPlot9.getForegroundAlpha();
        java.awt.Paint paint19 = xYPlot9.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        long long2 = segmentedTimeline0.getSegmentsGroupSize();
        long long3 = segmentedTimeline0.getSegmentSize();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str7 = dateAxis6.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition8 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis6.setTickMarkPosition(dateTickMarkPosition8);
        java.text.DateFormat dateFormat14 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat14);
        java.util.Date date16 = dateAxis6.calculateHighestVisibleTickValue(dateTickUnit15);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis19.setAutoRangeStickyZero(false);
        java.awt.Paint paint22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis19.setTickMarkPaint(paint22);
        java.lang.Class<?> wildcardClass24 = paint22.getClass();
        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass24);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline26 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int27 = segmentedTimeline26.getSegmentsExcluded();
        long long28 = segmentedTimeline26.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange31 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str32 = dateRange31.toString();
        java.util.Date date33 = dateRange31.getLowerDate();
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str37 = dateRange36.toString();
        java.util.Date date38 = dateRange36.getLowerDate();
        boolean boolean39 = segmentedTimeline26.containsDomainRange(date33, date38);
        java.util.TimeZone timeZone40 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date33, timeZone40);
        org.jfree.data.gantt.Task task42 = new org.jfree.data.gantt.Task("({0}, {1}) = {2}", date16, date33);
        boolean boolean43 = segmentedTimeline0.containsDomainValue(date16);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 86400000L + "'", long2 == 86400000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 900000L + "'", long3 == 900000L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(dateTickMarkPosition8);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNotNull(segmentedTimeline26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 68 + "'", int27 == 68);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 86400000L + "'", long28 == 86400000L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str32.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str37.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        double double6 = numberAxis3.getUpperBound();
        numberAxis3.setLabelURL("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, valueAxis9, xYItemRenderer10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.setAutoRangeStickyZero(false);
        numberAxis15.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean23 = intervalBarRenderer20.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font25 = null;
        intervalBarRenderer20.setSeriesItemLabelFont((int) '4', font25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener31 = null;
        numberAxis30.addChangeListener(axisChangeListener31);
        org.jfree.chart.plot.Marker marker33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        intervalBarRenderer20.drawRangeMarker(graphics2D27, categoryPlot28, (org.jfree.chart.axis.ValueAxis) numberAxis30, marker33, rectangle2D34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer20);
        double double37 = categoryPlot36.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation38 = categoryPlot36.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent39 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot36);
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection42 = categoryPlot36.getDomainMarkers((int) ' ', layer41);
        java.util.Collection collection43 = xYPlot11.getRangeMarkers(layer41);
        org.jfree.chart.axis.AxisCollection axisCollection44 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list45 = axisCollection44.getAxesAtBottom();
        boolean boolean46 = layer41.equals((java.lang.Object) list45);
        segmentedTimeline0.setExceptionSegments(list45);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis5.setAutoRangeStickyZero(false);
        numberAxis5.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean13 = intervalBarRenderer10.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font15 = null;
        intervalBarRenderer10.setSeriesItemLabelFont((int) '4', font15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener21 = null;
        numberAxis20.addChangeListener(axisChangeListener21);
        org.jfree.chart.plot.Marker marker23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        intervalBarRenderer10.drawRangeMarker(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis20, marker23, rectangle2D24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer10);
        double double27 = categoryPlot26.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot26.getDomainAxisLocation();
        java.awt.Paint paint29 = categoryPlot26.getNoDataMessagePaint();
        categoryPlot26.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        categoryPlot26.rendererChanged(rendererChangeEvent32);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent34 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot26);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit38 = new org.jfree.chart.axis.NumberTickUnit((double) ' ');
        numberAxis36.setTickUnit(numberTickUnit38, true, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker44 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer47 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer47.setBaseItemLabelPaint(paint48);
        boolean boolean51 = intervalBarRenderer47.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer47.setBaseItemLabelFont(font52, false);
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock56 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font52, (java.awt.Paint) color55);
        org.jfree.chart.block.LabelBlock labelBlock57 = new org.jfree.chart.block.LabelBlock("", font52);
        labelBlock57.setID("Category Plot");
        java.awt.Paint paint60 = labelBlock57.getPaint();
        java.awt.geom.Rectangle2D rectangle2D61 = labelBlock57.getBounds();
        lineRenderer3D0.drawRangeMarker(graphics2D1, categoryPlot26, (org.jfree.chart.axis.ValueAxis) numberAxis36, (org.jfree.chart.plot.Marker) intervalMarker44, rectangle2D61);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer63 = null;
        intervalMarker44.setGradientPaintTransformer(gradientPaintTransformer63);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(textBlock56);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(rectangle2D61);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RangeType.POSITIVE");
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        xYPlot9.setRangeGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis20.setAutoRangeStickyZero(false);
        numberAxis20.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer25 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean28 = intervalBarRenderer25.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font30 = null;
        intervalBarRenderer25.setSeriesItemLabelFont((int) '4', font30);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener36 = null;
        numberAxis35.addChangeListener(axisChangeListener36);
        org.jfree.chart.plot.Marker marker38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        intervalBarRenderer25.drawRangeMarker(graphics2D32, categoryPlot33, (org.jfree.chart.axis.ValueAxis) numberAxis35, marker38, rectangle2D39);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer25);
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis20);
        xYPlot9.setDomainCrosshairValue((double) (byte) 0, false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        layeredBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = layeredBarRenderer0.getLegendItemURLGenerator();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator5 = new org.jfree.chart.urls.StandardCategoryURLGenerator("({0}, {1}) = {2}");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', 0, (int) (byte) 10);
        java.util.List list10 = segmentedTimeline9.getExceptionSegments();
        boolean boolean11 = standardCategoryURLGenerator5.equals((java.lang.Object) segmentedTimeline9);
        layeredBarRenderer0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator5, false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer2.setBaseItemLabelPaint(paint3);
        boolean boolean6 = intervalBarRenderer2.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer2.setBaseItemLabelFont(font7, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font7, (java.awt.Paint) color10);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font7);
        labelBlock12.setID("Category Plot");
        java.awt.Paint paint15 = labelBlock12.getPaint();
        java.awt.geom.Rectangle2D rectangle2D16 = labelBlock12.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = labelBlock12.getPadding();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer0.setBaseItemLabelPaint(paint1);
        boolean boolean4 = intervalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        boolean boolean7 = intervalBarRenderer0.getItemVisible(4, 68);
        boolean boolean8 = intervalBarRenderer0.isDrawBarOutline();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Shape shape7 = null;
        java.awt.Color color8 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", "hi!", shape7, (java.awt.Paint) color8);
        boolean boolean10 = legendItem9.isShapeOutlineVisible();
        int int11 = legendItem9.getDatasetIndex();
        java.awt.Paint paint12 = legendItem9.getLinePaint();
        lineRenderer3D2.setWallPaint(paint12);
        ringPlot1.setShadowPaint(paint12);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 4);
        java.util.List list2 = axisState1.getTicks();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, valueAxis8, xYItemRenderer9);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke13 = intervalBarRenderer11.lookupSeriesStroke(3);
        xYPlot10.setDomainGridlineStroke(stroke13);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot10.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis17);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = xYPlot10.getDatasetRenderingOrder();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis22.setAutoRangeStickyZero(false);
        numberAxis22.setAutoRangeStickyZero(false);
        boolean boolean28 = numberAxis22.equals((java.lang.Object) (byte) 10);
        double double29 = numberAxis22.getUpperBound();
        xYPlot10.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis22, valueAxis31, xYItemRenderer32);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getRadiusGridlinePaint();
        polarPlot0.setAngleLabelsVisible(false);
        polarPlot0.removeCornerTextItem("TextAnchor.BASELINE_CENTER");
        java.awt.Stroke stroke6 = polarPlot0.getRadiusGridlineStroke();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        polarPlot0.setRenderer(polarItemRenderer7);
        java.awt.Paint paint9 = polarPlot0.getRadiusGridlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment(0L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline3.getSegment(0L);
        boolean boolean6 = segment2.after(segment5);
        long long8 = segment5.calculateSegmentNumber((long) 2);
        boolean boolean10 = segment5.contains((long) (byte) 100);
        boolean boolean11 = segment5.inExcludeSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2454364L + "'", long8 == 2454364L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        layeredBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition1);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator7 = new org.jfree.chart.urls.StandardCategoryURLGenerator("TextAnchor.BASELINE_CENTER", "TextAnchor.BASELINE_CENTER", "TextAnchor.BASELINE_CENTER");
        layeredBarRenderer0.setSeriesURLGenerator(2, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator7);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setDepthFactor(4.0d);
        java.lang.String str3 = piePlot3D0.getPlotType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie 3D Plot" + "'", str3.equals("Pie 3D Plot"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis4.setAutoRangeStickyZero(false);
        numberAxis4.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis9, xYItemRenderer10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke14 = intervalBarRenderer12.lookupSeriesStroke(3);
        xYPlot11.setDomainGridlineStroke(stroke14);
        lineRenderer3D0.setSeriesOutlineStroke(3, stroke14, true);
        java.awt.Paint paint20 = lineRenderer3D0.getItemPaint((int) ' ', (int) '#');
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 60000L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection1 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean2 = outlierListCollection1.isHighFarOut();
        boolean boolean3 = outlierListCollection1.isHighFarOut();
        boolean boolean4 = horizontalAlignment0.equals((java.lang.Object) outlierListCollection1);
        outlierListCollection1.setHighFarOut(true);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getRadiusGridlinePaint();
        boolean boolean2 = polarPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "", font2);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) 0);
        categoryAxis0.setMaximumCategoryLabelLines((int) (byte) 10);
        categoryAxis0.setUpperMargin((double) 0);
        categoryAxis0.configure();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.LegendItem legendItem3 = lineRenderer3D0.getLegendItem((int) (short) 10, (int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = lineRenderer3D0.getDrawingSupplier();
        java.awt.Paint paint5 = lineRenderer3D0.getWallPaint();
        try {
            lineRenderer3D0.setSeriesItemLabelsVisible((-65536), (java.lang.Boolean) false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis4.setAutoRangeStickyZero(false);
        numberAxis4.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis9, xYItemRenderer10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke14 = intervalBarRenderer12.lookupSeriesStroke(3);
        xYPlot11.setDomainGridlineStroke(stroke14);
        lineRenderer3D0.setSeriesOutlineStroke(3, stroke14, true);
        java.lang.Boolean boolean19 = lineRenderer3D0.getSeriesShapesFilled((int) (byte) 10);
        boolean boolean22 = lineRenderer3D0.getItemLineVisible(0, 0);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis6.setAutoRangeStickyZero(false);
        numberAxis6.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean14 = intervalBarRenderer11.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font16 = null;
        intervalBarRenderer11.setSeriesItemLabelFont((int) '4', font16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener22 = null;
        numberAxis21.addChangeListener(axisChangeListener22);
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        intervalBarRenderer11.drawRangeMarker(graphics2D18, categoryPlot19, (org.jfree.chart.axis.ValueAxis) numberAxis21, marker24, rectangle2D25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer11);
        double double28 = categoryPlot27.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot27.getDomainAxisLocation();
        java.awt.Paint paint30 = categoryPlot27.getNoDataMessagePaint();
        categoryPlot27.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = categoryPlot27.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState36 = boxAndWhiskerRenderer0.initialise(graphics2D1, rectangle2D2, categoryPlot27, (int) (short) -1, plotRenderingInfo35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        boxAndWhiskerRenderer0.setBasePaint((java.awt.Paint) color37, false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertNotNull(categoryItemRendererState36);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        layeredBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = layeredBarRenderer0.getLegendItemURLGenerator();
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) categorySeriesLabelGenerator3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke2);
        java.lang.Object obj4 = null;
        boolean boolean5 = valueMarker3.equals(obj4);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font5 = null;
        intervalBarRenderer0.setSeriesItemLabelFont((int) '4', font5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = intervalBarRenderer0.getSeriesToolTipGenerator((int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str3 = dateRange2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (double) 0);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer6.setBaseItemLabelPaint(paint7);
        boolean boolean10 = intervalBarRenderer6.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke14 = intervalBarRenderer12.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = intervalBarRenderer12.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer6.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition16);
        java.awt.Shape shape18 = intervalBarRenderer6.getBaseShape();
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] { numberArray26, numberArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray31);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset32);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity36 = new org.jfree.chart.entity.CategoryItemEntity(shape18, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset32, (java.lang.Comparable) 8.0d, (java.lang.Comparable) 0.0f);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset32);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, range37);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint38.toFixedHeight(1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str3.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint5 = intervalBarRenderer2.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textBlock6.calculateDimensions(graphics2D7);
        double double9 = size2D8.getWidth();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis12.setAutoRangeStickyZero(false);
        numberAxis12.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis12, valueAxis17, xYItemRenderer18);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke22 = intervalBarRenderer20.lookupSeriesStroke(3);
        xYPlot19.setDomainGridlineStroke(stroke22);
        java.awt.Stroke stroke24 = xYPlot19.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = xYPlot19.getDomainMarkers(2, layer26);
        xYPlot19.setWeight(10);
        xYPlot19.setRangeCrosshairValue((double) 4, true);
        float float33 = xYPlot19.getBackgroundAlpha();
        boolean boolean34 = size2D8.equals((java.lang.Object) xYPlot19);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis13.setAutoRangeStickyZero(false);
        numberAxis13.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean21 = intervalBarRenderer18.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font23 = null;
        intervalBarRenderer18.setSeriesItemLabelFont((int) '4', font23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener29 = null;
        numberAxis28.addChangeListener(axisChangeListener29);
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        intervalBarRenderer18.drawRangeMarker(graphics2D25, categoryPlot26, (org.jfree.chart.axis.ValueAxis) numberAxis28, marker31, rectangle2D32);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer18);
        double double35 = categoryPlot34.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation36 = categoryPlot34.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent37 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot34);
        xYPlot9.notifyListeners(plotChangeEvent37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot9.getRangeAxisEdge();
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis42.setAutoRangeStickyZero(false);
        numberAxis42.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) numberAxis42, valueAxis47, xYItemRenderer48);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer50 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke52 = intervalBarRenderer50.lookupSeriesStroke(3);
        xYPlot49.setDomainGridlineStroke(stroke52);
        java.awt.Stroke stroke54 = xYPlot49.getRangeZeroBaselineStroke();
        xYPlot9.setRangeGridlineStroke(stroke54);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.LegendItem legendItem3 = lineRenderer3D0.getLegendItem((int) (short) 10, (int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineRenderer3D0.getPositiveItemLabelPosition(4, (int) '4');
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment(0L);
        boolean boolean3 = segment2.inIncludeSegments();
        long long4 = segment2.getMillisecond();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segmentedTimeline5.getSegment(0L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline8.getSegment(0L);
        boolean boolean11 = segment7.after(segment10);
        long long13 = segment10.calculateSegmentNumber((long) 2);
        boolean boolean14 = segment2.contains(segment10);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(segment7);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2454364L + "'", long13 == 2454364L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean6 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) paintArray5);
        org.jfree.data.general.DatasetGroup datasetGroup8 = new org.jfree.data.general.DatasetGroup("hi!");
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup8);
        java.util.List list18 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem19 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) 10, (java.lang.Number) 2, (java.lang.Number) 1.0E-8d, (java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 10L, (java.lang.Number) (short) 100, (java.lang.Number) 15, list18);
        java.lang.Number number20 = boxAndWhiskerItem19.getQ3();
        java.lang.Number number21 = boxAndWhiskerItem19.getMean();
        java.lang.Number number22 = boxAndWhiskerItem19.getMean();
        java.lang.Number number23 = boxAndWhiskerItem19.getMedian();
        java.text.DateFormat dateFormat28 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat28);
        boolean boolean31 = dateTickUnit29.equals((java.lang.Object) (short) -1);
        int int32 = dateTickUnit29.getUnit();
        int int33 = dateTickUnit29.getRollUnit();
        java.lang.Comparable comparable34 = null;
        try {
            defaultBoxAndWhiskerCategoryDataset0.add(boxAndWhiskerItem19, (java.lang.Comparable) int33, comparable34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (15.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 100.0d + "'", number20.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (byte) 10 + "'", number21.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (byte) 10 + "'", number22.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 2 + "'", number23.equals(2));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 35 + "'", int33 == 35);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot9.getRangeAxisEdge();
        java.lang.String str19 = xYPlot9.getPlotType();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "XY Plot" + "'", str19.equals("XY Plot"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot24.zoomRangeAxes(0.0d, (double) 4, plotRenderingInfo28, point2D29);
        int int31 = categoryPlot24.getWeight();
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot24.getRowRenderingOrder();
        boolean boolean33 = categoryPlot24.isRangeCrosshairLockedOnData();
        java.awt.Stroke stroke34 = categoryPlot24.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot24.setRangeAxisLocation(axisLocation26, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis31.setAutoRangeStickyZero(false);
        numberAxis31.setAutoRangeStickyZero(false);
        categoryPlot24.setRangeAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) numberAxis31, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot24.getDomainAxis();
        org.jfree.chart.axis.ValueAxis valueAxis40 = categoryPlot24.getRangeAxis((int) (short) 0);
        boolean boolean41 = valueAxis40.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryAxis38);
        org.junit.Assert.assertNotNull(valueAxis40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        dateAxis16.resizeRange((double) 6);
        boolean boolean21 = dateAxis16.isHiddenValue((-2208960000000L));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer2.setBaseItemLabelPaint(paint3);
        boolean boolean6 = intervalBarRenderer2.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer2.setBaseItemLabelFont(font7, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font7, (java.awt.Paint) color10);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font7);
        labelBlock12.setID("Category Plot");
        java.awt.Paint paint15 = labelBlock12.getPaint();
        java.awt.geom.Rectangle2D rectangle2D16 = labelBlock12.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((-1.0d), 0.0d, (double) 68, (double) 100.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.axis.AxisState axisState25 = new org.jfree.chart.axis.AxisState((double) 4);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer28 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer28.setBaseItemLabelPaint(paint29);
        boolean boolean32 = intervalBarRenderer28.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer28.setBaseItemLabelFont(font33, false);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock37 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font33, (java.awt.Paint) color36);
        org.jfree.chart.block.LabelBlock labelBlock38 = new org.jfree.chart.block.LabelBlock("", font33);
        labelBlock38.setID("Category Plot");
        java.awt.Paint paint41 = labelBlock38.getPaint();
        java.awt.geom.Rectangle2D rectangle2D42 = labelBlock38.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        java.util.List list44 = categoryAxis22.refreshTicks(graphics2D23, axisState25, rectangle2D42, rectangleEdge43);
        rectangleInsets21.trim(rectangle2D42);
        boolean boolean46 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D16, rectangle2D42);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(textBlock37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setAngleGridlinesVisible(false);
        boolean boolean3 = polarPlot0.isAngleLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("CategoryAnchor.MIDDLE");
        textTitle1.setToolTipText("Category Plot");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer7 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke8 = intervalBarRenderer7.getBaseOutlineStroke();
        stackedBarRenderer3D5.setSeriesOutlineStroke((int) (short) 10, stroke8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedBarRenderer3D5.setSeriesPaint((int) '#', (java.awt.Paint) color11);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint21 = intervalBarRenderer18.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, paint21);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer23 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer23.setBaseItemLabelPaint(paint24);
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine("", font17, paint24);
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 1, (float) 10L, 10.0f);
        java.awt.Color color31 = color30.darker();
        org.jfree.chart.text.TextFragment textFragment33 = new org.jfree.chart.text.TextFragment("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font17, (java.awt.Paint) color31, (float) (-2208960000000L));
        stackedBarRenderer3D5.setSeriesPaint((int) ' ', (java.awt.Paint) color31, true);
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        stackedBarRenderer3D5.setBaseItemLabelFont(font36, true);
        textTitle1.setFont(font36);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(textBlock22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(font36);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getRadiusGridlinePaint();
        polarPlot0.setAngleLabelsVisible(false);
        polarPlot0.removeCornerTextItem("TextAnchor.BASELINE_CENTER");
        boolean boolean6 = polarPlot0.isRangeZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        try {
            polarPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo8, point2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str5 = dateAxis4.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis4.setTickMarkPosition(dateTickMarkPosition6);
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat12);
        java.util.Date date14 = dateAxis4.calculateHighestVisibleTickValue(dateTickUnit13);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis17.setAutoRangeStickyZero(false);
        java.awt.Paint paint20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis17.setTickMarkPaint(paint20);
        java.lang.Class<?> wildcardClass22 = paint20.getClass();
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass22);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline24 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int25 = segmentedTimeline24.getSegmentsExcluded();
        long long26 = segmentedTimeline24.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str30 = dateRange29.toString();
        java.util.Date date31 = dateRange29.getLowerDate();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str35 = dateRange34.toString();
        java.util.Date date36 = dateRange34.getLowerDate();
        boolean boolean37 = segmentedTimeline24.containsDomainRange(date31, date36);
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date31, timeZone38);
        org.jfree.data.gantt.Task task40 = new org.jfree.data.gantt.Task("({0}, {1}) = {2}", date14, date31);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str44 = dateAxis43.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition45 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis43.setTickMarkPosition(dateTickMarkPosition45);
        java.text.DateFormat dateFormat51 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat51);
        java.util.Date date53 = dateAxis43.calculateHighestVisibleTickValue(dateTickUnit52);
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis56.setAutoRangeStickyZero(false);
        java.awt.Paint paint59 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis56.setTickMarkPaint(paint59);
        java.lang.Class<?> wildcardClass61 = paint59.getClass();
        java.lang.Object obj62 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass61);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline63 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int64 = segmentedTimeline63.getSegmentsExcluded();
        long long65 = segmentedTimeline63.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange68 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str69 = dateRange68.toString();
        java.util.Date date70 = dateRange68.getLowerDate();
        org.jfree.data.time.DateRange dateRange73 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str74 = dateRange73.toString();
        java.util.Date date75 = dateRange73.getLowerDate();
        boolean boolean76 = segmentedTimeline63.containsDomainRange(date70, date75);
        java.util.TimeZone timeZone77 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date70, timeZone77);
        org.jfree.data.gantt.Task task79 = new org.jfree.data.gantt.Task("({0}, {1}) = {2}", date53, date70);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod82 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) (-1));
        task79.setDuration((org.jfree.data.time.TimePeriod) simpleTimePeriod82);
        defaultCategoryDataset0.setValue((double) 255, (java.lang.Comparable) date14, (java.lang.Comparable) simpleTimePeriod82);
        try {
            defaultCategoryDataset0.removeColumn(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNotNull(segmentedTimeline24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 68 + "'", int25 == 68);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 86400000L + "'", long26 == 86400000L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str30.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str35.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(dateTickMarkPosition45);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNull(obj62);
        org.junit.Assert.assertNotNull(segmentedTimeline63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 68 + "'", int64 == 68);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 86400000L + "'", long65 == 86400000L);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str69.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str74.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(regularTimePeriod78);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("", "", "", image4, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image9 = null;
        projectInfo8.setLogo(image9);
        org.jfree.chart.ui.Library[] libraryArray11 = projectInfo8.getOptionalLibraries();
        java.awt.Image image15 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo19 = new org.jfree.chart.ui.ProjectInfo("", "", "", image15, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image20 = null;
        projectInfo19.setLogo(image20);
        java.lang.String str22 = projectInfo19.getInfo();
        org.jfree.chart.ui.Library[] libraryArray23 = projectInfo19.getOptionalLibraries();
        java.awt.Image image27 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo31 = new org.jfree.chart.ui.ProjectInfo("", "", "", image27, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image32 = null;
        projectInfo31.setLogo(image32);
        java.lang.String str34 = projectInfo31.getInfo();
        org.jfree.chart.ui.Library[] libraryArray35 = projectInfo31.getOptionalLibraries();
        projectInfo19.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo31);
        projectInfo19.setInfo("");
        projectInfo8.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo19);
        java.lang.String str40 = projectInfo8.getLicenceName();
        boolean boolean41 = lengthConstraintType0.equals((java.lang.Object) str40);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNotNull(libraryArray11);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(libraryArray23);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(libraryArray35);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke2);
        java.awt.Paint paint4 = valueMarker3.getPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat4);
        boolean boolean7 = dateTickUnit5.equals((java.lang.Object) (short) -1);
        int int8 = dateTickUnit5.getUnit();
        int int9 = dateTickUnit5.getRollUnit();
        org.jfree.data.DefaultKeyedValues defaultKeyedValues10 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Number number12 = null;
        defaultKeyedValues10.addValue((java.lang.Comparable) 8.0d, number12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) dateTickUnit5, (org.jfree.data.KeyedValues) defaultKeyedValues10);
        int int15 = dateTickUnit5.getRollCount();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer2.setBaseItemLabelPaint(paint3);
        boolean boolean6 = intervalBarRenderer2.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer2.setBaseItemLabelFont(font7, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font7, (java.awt.Paint) color10);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font7);
        double double13 = labelBlock12.getHeight();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer16.setBaseItemLabelPaint(paint17);
        boolean boolean20 = intervalBarRenderer16.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer16.setBaseItemLabelFont(font21, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font21, (java.awt.Paint) color24);
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("", font21);
        labelBlock12.setFont(font21);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlock25);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        java.awt.Image image2 = jFreeChart1.getBackgroundImage();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        boolean boolean25 = intervalBarRenderer8.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape28 = intervalBarRenderer8.getItemShape((int) (byte) 0, (int) ' ');
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape28, (double) 178, (float) '#', (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        boolean boolean1 = piePlot0.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis4.setAutoRangeStickyZero(false);
        numberAxis4.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer9 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean12 = intervalBarRenderer9.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font14 = null;
        intervalBarRenderer9.setSeriesItemLabelFont((int) '4', font14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener20 = null;
        numberAxis19.addChangeListener(axisChangeListener20);
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        intervalBarRenderer9.drawRangeMarker(graphics2D16, categoryPlot17, (org.jfree.chart.axis.ValueAxis) numberAxis19, marker22, rectangle2D23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer9);
        double double26 = categoryPlot25.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis30.setAutoRangeStickyZero(false);
        numberAxis30.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer35 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean38 = intervalBarRenderer35.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font40 = null;
        intervalBarRenderer35.setSeriesItemLabelFont((int) '4', font40);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = null;
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener46 = null;
        numberAxis45.addChangeListener(axisChangeListener46);
        org.jfree.chart.plot.Marker marker48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        intervalBarRenderer35.drawRangeMarker(graphics2D42, categoryPlot43, (org.jfree.chart.axis.ValueAxis) numberAxis45, marker48, rectangle2D49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer35);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder52 = categoryPlot51.getDatasetRenderingOrder();
        categoryPlot25.setDatasetRenderingOrder(datasetRenderingOrder52);
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot25);
        categoryPlot25.clearRangeMarkers(0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder52);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart6 = multiplePiePlot5.getPieChart();
        chartProgressEvent4.setChart(jFreeChart6);
        org.junit.Assert.assertNotNull(jFreeChart6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.KeyToGroupMap keyToGroupMap0 = new org.jfree.data.KeyToGroupMap();
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = xYPlot9.getDatasetRenderingOrder();
        boolean boolean19 = xYPlot9.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean6 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) paintArray5);
        org.jfree.data.general.DatasetGroup datasetGroup8 = new org.jfree.data.general.DatasetGroup("hi!");
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup8);
        java.lang.Number number12 = defaultBoxAndWhiskerCategoryDataset0.getValue((java.lang.Comparable) Double.NaN, (java.lang.Comparable) 1.0f);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        defaultBoxAndWhiskerCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) multiplePiePlot13);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        int int5 = chartProgressEvent4.getPercent();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint14 = intervalBarRenderer11.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, paint14);
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("hi!", font8, paint14, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean21 = intervalBarRenderer18.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font23 = null;
        intervalBarRenderer18.setSeriesItemLabelFont((int) '4', font23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener29 = null;
        numberAxis28.addChangeListener(axisChangeListener29);
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        intervalBarRenderer18.drawRangeMarker(graphics2D25, categoryPlot26, (org.jfree.chart.axis.ValueAxis) numberAxis28, marker31, rectangle2D32);
        boolean boolean34 = textFragment17.equals((java.lang.Object) graphics2D25);
        java.awt.Font font35 = textFragment17.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis39.setAutoRangeStickyZero(false);
        numberAxis39.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean47 = intervalBarRenderer44.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font49 = null;
        intervalBarRenderer44.setSeriesItemLabelFont((int) '4', font49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener55 = null;
        numberAxis54.addChangeListener(axisChangeListener55);
        org.jfree.chart.plot.Marker marker57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        intervalBarRenderer44.drawRangeMarker(graphics2D51, categoryPlot52, (org.jfree.chart.axis.ValueAxis) numberAxis54, marker57, rectangle2D58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer44);
        org.jfree.chart.JFreeChart jFreeChart62 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", font35, (org.jfree.chart.plot.Plot) categoryPlot60, false);
        chartProgressEvent4.setChart(jFreeChart62);
        boolean boolean64 = jFreeChart62.isBorderVisible();
        jFreeChart62.setNotify(false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot9.getRangeAxisLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = xYPlot9.getInsets();
        double double18 = rectangleInsets16.calculateBottomInset(0.0d);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D((double) 10L, (-1.0d));
        size2D21.setHeight((double) 10L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, 0.0d, (double) (-1L), rectangleAnchor26);
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets16.createInsetRectangle(rectangle2D27);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D28);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str5 = dateAxis4.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis4.setTickMarkPosition(dateTickMarkPosition6);
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat12);
        java.util.Date date14 = dateAxis4.calculateHighestVisibleTickValue(dateTickUnit13);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis17.setAutoRangeStickyZero(false);
        java.awt.Paint paint20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis17.setTickMarkPaint(paint20);
        java.lang.Class<?> wildcardClass22 = paint20.getClass();
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass22);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline24 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int25 = segmentedTimeline24.getSegmentsExcluded();
        long long26 = segmentedTimeline24.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str30 = dateRange29.toString();
        java.util.Date date31 = dateRange29.getLowerDate();
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str35 = dateRange34.toString();
        java.util.Date date36 = dateRange34.getLowerDate();
        boolean boolean37 = segmentedTimeline24.containsDomainRange(date31, date36);
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date31, timeZone38);
        org.jfree.data.gantt.Task task40 = new org.jfree.data.gantt.Task("({0}, {1}) = {2}", date14, date31);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str44 = dateAxis43.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition45 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis43.setTickMarkPosition(dateTickMarkPosition45);
        java.text.DateFormat dateFormat51 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat51);
        java.util.Date date53 = dateAxis43.calculateHighestVisibleTickValue(dateTickUnit52);
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis56.setAutoRangeStickyZero(false);
        java.awt.Paint paint59 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis56.setTickMarkPaint(paint59);
        java.lang.Class<?> wildcardClass61 = paint59.getClass();
        java.lang.Object obj62 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass61);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline63 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int64 = segmentedTimeline63.getSegmentsExcluded();
        long long65 = segmentedTimeline63.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange68 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str69 = dateRange68.toString();
        java.util.Date date70 = dateRange68.getLowerDate();
        org.jfree.data.time.DateRange dateRange73 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str74 = dateRange73.toString();
        java.util.Date date75 = dateRange73.getLowerDate();
        boolean boolean76 = segmentedTimeline63.containsDomainRange(date70, date75);
        java.util.TimeZone timeZone77 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date70, timeZone77);
        org.jfree.data.gantt.Task task79 = new org.jfree.data.gantt.Task("({0}, {1}) = {2}", date53, date70);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod82 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) (-1));
        task79.setDuration((org.jfree.data.time.TimePeriod) simpleTimePeriod82);
        defaultCategoryDataset0.setValue((double) 255, (java.lang.Comparable) date14, (java.lang.Comparable) simpleTimePeriod82);
        java.lang.Object obj85 = null;
        boolean boolean86 = defaultCategoryDataset0.equals(obj85);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNotNull(segmentedTimeline24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 68 + "'", int25 == 68);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 86400000L + "'", long26 == 86400000L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str30.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str35.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(dateTickMarkPosition45);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNull(obj62);
        org.junit.Assert.assertNotNull(segmentedTimeline63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 68 + "'", int64 == 68);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 86400000L + "'", long65 == 86400000L);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str69.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str74.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font5 = null;
        intervalBarRenderer0.setSeriesItemLabelFont((int) '4', font5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener11 = null;
        numberAxis10.addChangeListener(axisChangeListener11);
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        intervalBarRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis10, marker13, rectangle2D14);
        double double16 = intervalBarRenderer0.getItemMargin();
        java.awt.Paint paint17 = intervalBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = intervalBarRenderer0.getLegendItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator18);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis2.setTickMarkPaint(paint5);
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape0, paint5);
        boolean boolean8 = legendGraphic7.isLineVisible();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot24.setRangeAxisLocation(axisLocation26, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis31.setAutoRangeStickyZero(false);
        numberAxis31.setAutoRangeStickyZero(false);
        categoryPlot24.setRangeAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) numberAxis31, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot24.getDomainAxis();
        org.jfree.chart.axis.ValueAxis valueAxis40 = categoryPlot24.getRangeAxis((int) (short) 0);
        categoryPlot24.mapDatasetToDomainAxis(4, 15);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryAxis38);
        org.junit.Assert.assertNotNull(valueAxis40);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("CategoryAnchor.MIDDLE");
        textTitle1.setToolTipText("Category Plot");
        java.awt.Paint paint4 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (byte) -1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str7 = dateRange6.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) 0);
        java.util.Date date10 = dateRange6.getUpperDate();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint2.toRangeHeight((org.jfree.data.Range) dateRange6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint11.toFixedHeight(Double.NaN);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        java.lang.Object obj5 = chartProgressEvent4.getSource();
        chartProgressEvent4.setPercent((int) ' ');
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setWeight(10);
        xYPlot9.setRangeCrosshairValue((double) 4, true);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.CrosshairState crosshairState27 = null;
        boolean boolean28 = xYPlot9.render(graphics2D23, rectangle2D24, 0, plotRenderingInfo26, crosshairState27);
        java.lang.String str29 = xYPlot9.getPlotType();
        java.awt.Paint paint30 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYPlot9.setDomainTickBandPaint(paint30);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "XY Plot" + "'", str29.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot9.getRenderer(0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        xYPlot9.datasetChanged(datasetChangeEvent16);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = intervalBarRenderer0.getItemFillPaint(100, (int) 'a');
        int int4 = intervalBarRenderer0.getColumnCount();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("CategoryAnchor.MIDDLE");
        java.lang.String str2 = taskSeries1.getDescription();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str6 = dateAxis5.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis5.setTickMarkPosition(dateTickMarkPosition7);
        java.text.DateFormat dateFormat13 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat13);
        java.util.Date date15 = dateAxis5.calculateHighestVisibleTickValue(dateTickUnit14);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis18.setAutoRangeStickyZero(false);
        java.awt.Paint paint21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis18.setTickMarkPaint(paint21);
        java.lang.Class<?> wildcardClass23 = paint21.getClass();
        java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass23);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline25 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int26 = segmentedTimeline25.getSegmentsExcluded();
        long long27 = segmentedTimeline25.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange30 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str31 = dateRange30.toString();
        java.util.Date date32 = dateRange30.getLowerDate();
        org.jfree.data.time.DateRange dateRange35 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str36 = dateRange35.toString();
        java.util.Date date37 = dateRange35.getLowerDate();
        boolean boolean38 = segmentedTimeline25.containsDomainRange(date32, date37);
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date32, timeZone39);
        org.jfree.data.gantt.Task task41 = new org.jfree.data.gantt.Task("({0}, {1}) = {2}", date15, date32);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) (-1));
        task41.setDuration((org.jfree.data.time.TimePeriod) simpleTimePeriod44);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod((long) (short) -1, (long) (-1));
        task41.setDuration((org.jfree.data.time.TimePeriod) simpleTimePeriod48);
        taskSeries1.remove(task41);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNotNull(segmentedTimeline25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 68 + "'", int26 == 68);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 86400000L + "'", long27 == 86400000L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str31.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str36.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(regularTimePeriod40);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer0.setBaseItemLabelPaint(paint1);
        boolean boolean4 = intervalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke8 = intervalBarRenderer6.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = intervalBarRenderer6.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer0.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition10);
        java.awt.Shape shape12 = intervalBarRenderer0.getBaseShape();
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray20, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray25);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset26);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity30 = new org.jfree.chart.entity.CategoryItemEntity(shape12, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset26, (java.lang.Comparable) 8.0d, (java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable31 = categoryItemEntity30.getColumnKey();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis34.setAutoRangeStickyZero(false);
        java.awt.Paint paint37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis34.setTickMarkPaint(paint37);
        java.lang.Class<?> wildcardClass39 = paint37.getClass();
        java.lang.Object obj40 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass39);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline41 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int42 = segmentedTimeline41.getSegmentsExcluded();
        long long43 = segmentedTimeline41.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange46 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str47 = dateRange46.toString();
        java.util.Date date48 = dateRange46.getLowerDate();
        org.jfree.data.time.DateRange dateRange51 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str52 = dateRange51.toString();
        java.util.Date date53 = dateRange51.getLowerDate();
        boolean boolean54 = segmentedTimeline41.containsDomainRange(date48, date53);
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date48, timeZone55);
        categoryItemEntity30.setRowKey((java.lang.Comparable) date48);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + 0.0f + "'", comparable31.equals(0.0f));
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNull(obj40);
        org.junit.Assert.assertNotNull(segmentedTimeline41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 68 + "'", int42 == 68);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 86400000L + "'", long43 == 86400000L);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str47.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str52.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(regularTimePeriod56);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "({0}, {1}) = {2}", "", "hi!");
        projectInfo7.setCopyright("pink");
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(12.0d, (double) (-1));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) categoryLabelPosition3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = categoryLabelPositions6.getLabelPosition(rectangleEdge7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge12);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = categoryLabelPositions11.getLabelPosition(rectangleEdge12);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition3, categoryLabelPosition9, categoryLabelPosition14, categoryLabelPosition15);
        float float17 = categoryLabelPosition9.getWidthRatio();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(categoryLabelPosition9);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(categoryLabelPosition14);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis2.setTickMarkPaint(paint5);
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape0, paint5);
        java.awt.Paint paint8 = legendGraphic7.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean4 = intervalBarRenderer1.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font6 = null;
        intervalBarRenderer1.setSeriesItemLabelFont((int) '4', font6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener12 = null;
        numberAxis11.addChangeListener(axisChangeListener12);
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        intervalBarRenderer1.drawRangeMarker(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis11, marker14, rectangle2D15);
        double double17 = numberAxis11.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis11, polarItemRenderer18);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0E-8d + "'", double17 == 1.0E-8d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot1.setURLGenerator(pieURLGenerator3);
        java.text.DateFormat dateFormat9 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat9);
        java.awt.Color color11 = java.awt.Color.BLACK;
        piePlot1.setSectionPaint((java.lang.Comparable) dateTickUnit10, (java.awt.Paint) color11);
        int int13 = dateTickUnit10.getRollUnit();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setAutoRangeStickyZero(false);
        boolean boolean7 = numberAxis1.equals((java.lang.Object) (byte) 10);
        double double8 = numberAxis1.getUpperBound();
        numberAxis1.setRangeAboutValue(0.0d, (double) 3600000L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Number number2 = null;
        defaultKeyedValues0.addValue((java.lang.Comparable) 8.0d, number2);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer4 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean5 = defaultKeyedValues0.equals((java.lang.Object) boxAndWhiskerRenderer4);
        java.awt.Shape shape7 = boxAndWhiskerRenderer4.lookupSeriesShape((int) (short) 1);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint10 = polarPlot9.getRadiusGridlinePaint();
        polarPlot9.setAngleLabelsVisible(false);
        java.awt.Paint paint13 = polarPlot9.getOutlinePaint();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer17 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer17.setBaseItemLabelPaint(paint18);
        boolean boolean21 = intervalBarRenderer17.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer17.setBaseItemLabelFont(font22, false);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font22, (java.awt.Paint) color25);
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("", font22);
        labelBlock27.setID("Category Plot");
        java.awt.Paint paint30 = labelBlock27.getPaint();
        java.awt.geom.Rectangle2D rectangle2D31 = labelBlock27.getBounds();
        java.awt.geom.Point2D point2D32 = null;
        org.jfree.chart.plot.PlotState plotState33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        polarPlot9.draw(graphics2D14, rectangle2D31, point2D32, plotState33, plotRenderingInfo34);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis39.setAutoRangeStickyZero(false);
        numberAxis39.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean47 = intervalBarRenderer44.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font49 = null;
        intervalBarRenderer44.setSeriesItemLabelFont((int) '4', font49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener55 = null;
        numberAxis54.addChangeListener(axisChangeListener55);
        org.jfree.chart.plot.Marker marker57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        intervalBarRenderer44.drawRangeMarker(graphics2D51, categoryPlot52, (org.jfree.chart.axis.ValueAxis) numberAxis54, marker57, rectangle2D58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer44);
        double double61 = categoryPlot60.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation62 = categoryPlot60.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent63 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState66 = boxAndWhiskerRenderer4.initialise(graphics2D8, rectangle2D31, categoryPlot60, 68, plotRenderingInfo65);
        double double67 = categoryItemRendererState66.getSeriesRunningTotal();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertNotNull(categoryItemRendererState66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = null;
        try {
            multiplePiePlot0.setDataExtractOrder(tableOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 35);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot24.setRangeAxisLocation(axisLocation26, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis31.setAutoRangeStickyZero(false);
        numberAxis31.setAutoRangeStickyZero(false);
        categoryPlot24.setRangeAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) numberAxis31, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot24.getDomainAxis();
        org.jfree.chart.axis.ValueAxis valueAxis40 = categoryPlot24.getRangeAxis((int) (short) 0);
        org.jfree.data.DefaultKeyedValues defaultKeyedValues41 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Number number43 = null;
        defaultKeyedValues41.addValue((java.lang.Comparable) 8.0d, number43);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer45 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean46 = defaultKeyedValues41.equals((java.lang.Object) boxAndWhiskerRenderer45);
        org.jfree.chart.util.SortOrder sortOrder47 = org.jfree.chart.util.SortOrder.DESCENDING;
        defaultKeyedValues41.sortByValues(sortOrder47);
        categoryPlot24.setRowRenderingOrder(sortOrder47);
        org.jfree.data.general.PieDataset pieDataset50 = null;
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot(pieDataset50);
        java.awt.Shape shape52 = piePlot51.getLegendItemShape();
        org.jfree.chart.LegendItemCollection legendItemCollection53 = piePlot51.getLegendItems();
        piePlot51.setShadowYOffset((double) 100.0f);
        java.awt.Paint paint56 = piePlot51.getLabelBackgroundPaint();
        categoryPlot24.setDomainGridlinePaint(paint56);
        java.awt.Stroke stroke58 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot24.setRangeCrosshairStroke(stroke58);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryAxis38);
        org.junit.Assert.assertNotNull(valueAxis40);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(sortOrder47);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(legendItemCollection53);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.awt.Shape shape8 = null;
        java.awt.Color color9 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", "hi!", shape8, (java.awt.Paint) color9);
        legendItem10.setSeriesIndex((int) (short) -1);
        java.awt.Shape shape13 = legendItem10.getLine();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer15.setBaseItemLabelPaint(paint16);
        boolean boolean19 = intervalBarRenderer15.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer15.setBaseItemLabelFont(font20, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font20, (java.awt.Paint) color23);
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "TextAnchor.BASELINE_CENTER", "Category Plot", "hi!", shape13, (java.awt.Paint) color23);
        java.awt.Paint paint26 = legendItem25.getOutlinePaint();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(textBlock24);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean6 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) paintArray5);
        org.jfree.data.general.DatasetGroup datasetGroup8 = new org.jfree.data.general.DatasetGroup("hi!");
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup8);
        org.jfree.data.KeyToGroupMap keyToGroupMap11 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) "PlotOrientation.VERTICAL");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator12 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str13 = standardCategoryToolTipGenerator12.getLabelFormat();
        boolean boolean14 = keyToGroupMap11.equals((java.lang.Object) str13);
        int int15 = keyToGroupMap11.getGroupCount();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, keyToGroupMap11);
        org.jfree.data.general.PieDataset pieDataset18 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "({0}, {1}) = {2}" + "'", str13.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(pieDataset18);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = xYPlot9.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot9.setRangeAxisLocation(axisLocation19);
        boolean boolean21 = xYPlot9.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        intervalMarker2.setLabel("hi!");
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder();
        boolean boolean6 = intervalMarker2.equals((java.lang.Object) lineBorder5);
        java.awt.Paint paint7 = intervalMarker2.getLabelPaint();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis12.setAutoRangeStickyZero(false);
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis12.setTickMarkPaint(paint15);
        java.lang.Class<?> wildcardClass17 = paint15.getClass();
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass17);
        try {
            java.util.EventListener[] eventListenerArray19 = intervalMarker2.getListeners((java.lang.Class) wildcardClass17);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Ljava.awt.Color; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(uRL18);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke5 = intervalBarRenderer4.getBaseOutlineStroke();
        stackedBarRenderer3D2.setSeriesOutlineStroke((int) (short) 10, stroke5);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedBarRenderer3D2.setSeriesPaint((int) '#', (java.awt.Paint) color8);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint18 = intervalBarRenderer15.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font14, paint18);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer20.setBaseItemLabelPaint(paint21);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("", font14, paint21);
        java.awt.Color color27 = java.awt.Color.getHSBColor((float) (short) 1, (float) 10L, 10.0f);
        java.awt.Color color28 = color27.darker();
        org.jfree.chart.text.TextFragment textFragment30 = new org.jfree.chart.text.TextFragment("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font14, (java.awt.Paint) color28, (float) (-2208960000000L));
        stackedBarRenderer3D2.setSeriesPaint((int) ' ', (java.awt.Paint) color28, true);
        int int33 = color28.getRed();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis37.setAutoRangeStickyZero(false);
        numberAxis37.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer42 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean45 = intervalBarRenderer42.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font47 = null;
        intervalBarRenderer42.setSeriesItemLabelFont((int) '4', font47);
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = null;
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener53 = null;
        numberAxis52.addChangeListener(axisChangeListener53);
        org.jfree.chart.plot.Marker marker55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        intervalBarRenderer42.drawRangeMarker(graphics2D49, categoryPlot50, (org.jfree.chart.axis.ValueAxis) numberAxis52, marker55, rectangle2D56);
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis37, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer42);
        double double59 = categoryPlot58.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation60 = categoryPlot58.getDomainAxisLocation();
        categoryPlot58.configureDomainAxes();
        int int62 = categoryPlot58.getWeight();
        java.awt.Stroke stroke63 = categoryPlot58.getRangeGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker64 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color28, stroke63);
        java.lang.Object obj65 = valueMarker64.clone();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(textBlock19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 178 + "'", int33 == 178);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(obj65);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke2);
        valueMarker3.setValue((double) 15);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint6 = intervalBarRenderer3.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint6);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer8.setBaseItemLabelPaint(paint9);
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("", font2, paint9);
        org.jfree.chart.text.TextFragment textFragment12 = textLine11.getFirstTextFragment();
        java.awt.Font font13 = textFragment12.getFont();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textFragment12);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        numberAxis1.addChangeListener(axisChangeListener2);
        double double4 = numberAxis1.getLabelAngle();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint13 = intervalBarRenderer10.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint13);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("hi!", font7, paint13, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer25 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint28 = intervalBarRenderer25.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.block.BlockBorder blockBorder29 = new org.jfree.chart.block.BlockBorder((double) (short) 1, (double) 1, (double) 10, (double) 0, paint28);
        java.awt.Paint paint30 = blockBorder29.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder(1.0d, 0.2d, Double.NaN, (double) 100.0f, paint30);
        org.jfree.chart.text.TextMeasurer textMeasurer33 = null;
        org.jfree.chart.text.TextBlock textBlock34 = org.jfree.chart.text.TextUtilities.createTextBlock("", font7, paint30, 0.0f, textMeasurer33);
        numberAxis1.setTickLabelFont(font7);
        org.jfree.data.time.DateRange dateRange38 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str39 = dateRange38.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange38, (double) 0);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer42 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer42.setBaseItemLabelPaint(paint43);
        boolean boolean46 = intervalBarRenderer42.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer48 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke50 = intervalBarRenderer48.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = intervalBarRenderer48.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer42.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition52);
        java.awt.Shape shape54 = intervalBarRenderer42.getBaseShape();
        java.lang.Number[] numberArray62 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray66 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray67 = new java.lang.Number[][] { numberArray62, numberArray66 };
        org.jfree.data.category.CategoryDataset categoryDataset68 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray67);
        org.jfree.data.Range range69 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset68);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity72 = new org.jfree.chart.entity.CategoryItemEntity(shape54, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset68, (java.lang.Comparable) 8.0d, (java.lang.Comparable) 0.0f);
        org.jfree.data.Range range73 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset68);
        org.jfree.data.time.DateRange dateRange76 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str77 = dateRange76.toString();
        double double78 = dateRange76.getLowerBound();
        boolean boolean80 = dateRange76.contains((double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint81 = new org.jfree.chart.block.RectangleConstraint(range73, (org.jfree.data.Range) dateRange76);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint82 = rectangleConstraint41.toRangeWidth((org.jfree.data.Range) dateRange76);
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange76, false, true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(textBlock34);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str39.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(itemLabelPosition52);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(categoryDataset68);
        org.junit.Assert.assertNotNull(range69);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str77.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint82);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = intervalBarRenderer0.getToolTipGenerator(255, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryAxis0.setTickMarkStroke(stroke1);
        float float3 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        categoryAxis0.setTickMarkInsideLength((float) 1L);
        java.lang.String str7 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 0.2d);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        double double5 = numberAxis2.getUpperBound();
        numberAxis2.setLabelURL("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis8, xYItemRenderer9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        xYPlot10.setRenderer(100, xYItemRenderer12);
        int int14 = xYPlot10.getSeriesCount();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat4);
        boolean boolean7 = dateTickUnit5.equals((java.lang.Object) (short) -1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer8.setBaseItemLabelPaint(paint9);
        boolean boolean12 = intervalBarRenderer8.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke16 = intervalBarRenderer14.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = intervalBarRenderer14.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer8.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition18);
        java.awt.Shape shape20 = intervalBarRenderer8.getBaseShape();
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray28, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset34);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity38 = new org.jfree.chart.entity.CategoryItemEntity(shape20, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset34, (java.lang.Comparable) 8.0d, (java.lang.Comparable) 0.0f);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity41 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) boolean7, shape20, "", "hi!");
        java.lang.Number[] numberArray51 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray51, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray56);
        org.jfree.data.category.CategoryDataset categoryDataset58 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", numberArray56);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity61 = new org.jfree.chart.entity.CategoryItemEntity(shape20, "Range[-1.0,1.0]", "magenta", categoryDataset58, (java.lang.Comparable) 10.0f, (java.lang.Comparable) 8.0d);
        java.lang.String str62 = categoryItemEntity61.toString();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertNotNull(categoryDataset58);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint8 = intervalBarRenderer5.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, paint8);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!", font2, paint8, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean15 = intervalBarRenderer12.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font17 = null;
        intervalBarRenderer12.setSeriesItemLabelFont((int) '4', font17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener23 = null;
        numberAxis22.addChangeListener(axisChangeListener23);
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        intervalBarRenderer12.drawRangeMarker(graphics2D19, categoryPlot20, (org.jfree.chart.axis.ValueAxis) numberAxis22, marker25, rectangle2D26);
        boolean boolean28 = textFragment11.equals((java.lang.Object) graphics2D19);
        java.awt.Font font29 = textFragment11.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis33.setAutoRangeStickyZero(false);
        numberAxis33.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer38 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean41 = intervalBarRenderer38.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font43 = null;
        intervalBarRenderer38.setSeriesItemLabelFont((int) '4', font43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener49 = null;
        numberAxis48.addChangeListener(axisChangeListener49);
        org.jfree.chart.plot.Marker marker51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        intervalBarRenderer38.drawRangeMarker(graphics2D45, categoryPlot46, (org.jfree.chart.axis.ValueAxis) numberAxis48, marker51, rectangle2D52);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer38);
        org.jfree.chart.JFreeChart jFreeChart56 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", font29, (org.jfree.chart.plot.Plot) categoryPlot54, false);
        java.awt.Paint paint57 = jFreeChart56.getBorderPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textBlock9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(paint57);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        xYPlot9.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis22.setAutoRangeStickyZero(false);
        double double25 = numberAxis22.getUpperBound();
        xYPlot9.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis22, false);
        java.awt.Font font32 = null;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis22, (double) 900000L, 0.0d, (double) 4, (double) (short) 1, font32);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat6 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis1.getTickLabelInsets();
        java.awt.Paint[] paintArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean9 = rectangleInsets7.equals((java.lang.Object) paintArray8);
        double double11 = rectangleInsets7.calculateLeftInset((double) 10);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        double double5 = numberAxis2.getUpperBound();
        numberAxis2.setLabelURL("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis8, xYItemRenderer9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis14.setAutoRangeStickyZero(false);
        numberAxis14.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean22 = intervalBarRenderer19.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font24 = null;
        intervalBarRenderer19.setSeriesItemLabelFont((int) '4', font24);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener30 = null;
        numberAxis29.addChangeListener(axisChangeListener30);
        org.jfree.chart.plot.Marker marker32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        intervalBarRenderer19.drawRangeMarker(graphics2D26, categoryPlot27, (org.jfree.chart.axis.ValueAxis) numberAxis29, marker32, rectangle2D33);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer19);
        double double36 = categoryPlot35.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot35.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent38 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection41 = categoryPlot35.getDomainMarkers((int) ' ', layer40);
        java.util.Collection collection42 = xYPlot10.getRangeMarkers(layer40);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        xYPlot10.drawAnnotations(graphics2D43, rectangle2D44, plotRenderingInfo45);
        boolean boolean47 = xYPlot10.isRangeZeroBaselineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = xYPlot10.getDomainAxisEdge();
        java.awt.Font font49 = xYPlot10.getNoDataMessageFont();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertNotNull(font49);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) 10, (java.lang.Number) 2, (java.lang.Number) 1.0E-8d, (java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 10L, (java.lang.Number) (short) 100, (java.lang.Number) 15, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getQ3();
        java.lang.String str11 = boxAndWhiskerItem9.toString();
        java.util.List list12 = boxAndWhiskerItem9.getOutliers();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0d + "'", number10.equals(100.0d));
        org.junit.Assert.assertNull(list12);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("TextAnchor.BASELINE_CENTER", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot24.rendererChanged(rendererChangeEvent30);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot24);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer34.setBaseItemLabelPaint(paint35);
        boolean boolean38 = intervalBarRenderer34.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer34.setBaseItemLabelFont(font39, false);
        categoryPlot24.setRenderer((int) (short) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer34, true);
        org.jfree.chart.util.StrokeList strokeList44 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer46 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke47 = intervalBarRenderer46.getBaseOutlineStroke();
        strokeList44.setStroke((int) (short) 1, stroke47);
        categoryPlot24.setRangeGridlineStroke(stroke47);
        categoryPlot24.setRangeCrosshairVisible(true);
        java.awt.Paint paint52 = categoryPlot24.getOutlinePaint();
        categoryPlot24.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = categoryPlot24.getDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNull(categoryAxis54);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.Size2D size2D10 = textBlock8.calculateDimensions(graphics2D9);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("hi!", font12);
        textBlock8.addLine(textLine13);
        org.jfree.chart.text.TextLine textLine15 = textBlock8.getLastLine();
        boolean boolean16 = categoryAnchor0.equals((java.lang.Object) textLine15);
        org.jfree.chart.axis.AxisState axisState18 = new org.jfree.chart.axis.AxisState((double) 4);
        axisState18.cursorLeft((double) 0);
        boolean boolean21 = textLine15.equals((java.lang.Object) axisState18);
        org.jfree.chart.text.TextFragment textFragment22 = textLine15.getLastTextFragment();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(textLine15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(textFragment22);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        int int3 = java.awt.Color.HSBtoRGB((float) 60000L, 0.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-100) + "'", int3 == (-100));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        java.awt.Font font5 = intervalMarker4.getLabelFont();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis8.setAutoRangeStickyZero(false);
        numberAxis8.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis13, xYItemRenderer14);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke18 = intervalBarRenderer16.lookupSeriesStroke(3);
        xYPlot15.setDomainGridlineStroke(stroke18);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot15.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis22);
        xYPlot15.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis28.setAutoRangeStickyZero(false);
        double double31 = numberAxis28.getUpperBound();
        xYPlot15.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis28, false);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot34 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis36.setAutoRangeStickyZero(false);
        numberAxis36.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat41 = numberAxis36.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = numberAxis36.getTickLabelInsets();
        waferMapPlot34.setInsets(rectangleInsets42);
        xYPlot15.setAxisOffset(rectangleInsets42);
        intervalMarker4.setLabelOffset(rectangleInsets42);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        java.lang.String str47 = textAnchor46.toString();
        intervalMarker4.setLabelTextAnchor(textAnchor46);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(12.0d, (double) (-1));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition53 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean54 = stackedBarRenderer3D52.equals((java.lang.Object) categoryLabelPosition53);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions56 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge57);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition59 = categoryLabelPositions56.getLabelPosition(rectangleEdge57);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions61 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge62);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition64 = categoryLabelPositions61.getLabelPosition(rectangleEdge62);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition65 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions66 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition53, categoryLabelPosition59, categoryLabelPosition64, categoryLabelPosition65);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType67 = categoryLabelPosition65.getWidthType();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition69 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor46, (double) (-1.0f), categoryLabelWidthType67, (float) 10L);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNull(numberFormat41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "TextAnchor.BASELINE_CENTER" + "'", str47.equals("TextAnchor.BASELINE_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions56);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(categoryLabelPosition59);
        org.junit.Assert.assertNotNull(categoryLabelPositions61);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertNotNull(categoryLabelPosition64);
        org.junit.Assert.assertNotNull(categoryLabelWidthType67);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        xYPlot9.setRangeGridlinesVisible(false);
        boolean boolean20 = xYPlot9.isRangeCrosshairVisible();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        xYPlot9.setDomainTickBandPaint((java.awt.Paint) color21);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getRadiusGridlinePaint();
        polarPlot0.setAngleLabelsVisible(false);
        polarPlot0.removeCornerTextItem("TextAnchor.BASELINE_CENTER");
        boolean boolean6 = polarPlot0.isRangeZoomable();
        polarPlot0.setAngleGridlinesVisible(true);
        java.awt.Paint paint9 = polarPlot0.getAngleLabelPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        xYPlot9.clearDomainMarkers();
        xYPlot9.setRangeCrosshairValue((double) 1.0f);
        org.jfree.chart.plot.Plot plot18 = xYPlot9.getRootPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot9.setRenderer(255, xYItemRenderer20, false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(plot18);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str1 = standardCategoryToolTipGenerator0.getLabelFormat();
        java.text.NumberFormat numberFormat2 = standardCategoryToolTipGenerator0.getNumberFormat();
        java.text.DateFormat dateFormat3 = standardCategoryToolTipGenerator0.getDateFormat();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "({0}, {1}) = {2}" + "'", str1.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNull(dateFormat3);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis6.setAutoRangeStickyZero(false);
        numberAxis6.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean14 = intervalBarRenderer11.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font16 = null;
        intervalBarRenderer11.setSeriesItemLabelFont((int) '4', font16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener22 = null;
        numberAxis21.addChangeListener(axisChangeListener22);
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        intervalBarRenderer11.drawRangeMarker(graphics2D18, categoryPlot19, (org.jfree.chart.axis.ValueAxis) numberAxis21, marker24, rectangle2D25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer11);
        double double28 = categoryPlot27.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot27.getDomainAxisLocation();
        java.awt.Paint paint30 = categoryPlot27.getNoDataMessagePaint();
        categoryPlot27.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = categoryPlot27.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState36 = boxAndWhiskerRenderer0.initialise(graphics2D1, rectangle2D2, categoryPlot27, (int) (short) -1, plotRenderingInfo35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis40.setAutoRangeStickyZero(false);
        numberAxis40.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer45 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean48 = intervalBarRenderer45.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font50 = null;
        intervalBarRenderer45.setSeriesItemLabelFont((int) '4', font50);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = null;
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener56 = null;
        numberAxis55.addChangeListener(axisChangeListener56);
        org.jfree.chart.plot.Marker marker58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        intervalBarRenderer45.drawRangeMarker(graphics2D52, categoryPlot53, (org.jfree.chart.axis.ValueAxis) numberAxis55, marker58, rectangle2D59);
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, (org.jfree.chart.axis.ValueAxis) numberAxis40, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer45);
        double double62 = categoryPlot61.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation63 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot61.setRangeAxisLocation(axisLocation63, true);
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis68.setAutoRangeStickyZero(false);
        numberAxis68.setAutoRangeStickyZero(false);
        categoryPlot61.setRangeAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) numberAxis68, true);
        float float75 = numberAxis68.getTickMarkOutsideLength();
        java.awt.Shape shape76 = numberAxis68.getUpArrow();
        org.jfree.data.Range range77 = categoryPlot27.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis68);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertNotNull(categoryItemRendererState36);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertTrue("'" + float75 + "' != '" + 2.0f + "'", float75 == 2.0f);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNull(range77);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        int int2 = tickUnits0.size();
        java.awt.Shape shape7 = null;
        java.awt.Color color8 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", "hi!", shape7, (java.awt.Paint) color8);
        boolean boolean10 = legendItem9.isShapeOutlineVisible();
        int int11 = legendItem9.getDatasetIndex();
        java.awt.Paint paint12 = legendItem9.getLinePaint();
        boolean boolean13 = legendItem9.isShapeFilled();
        boolean boolean14 = tickUnits0.equals((java.lang.Object) legendItem9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("({0}, {1}) = {2}");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', 0, (int) (byte) 10);
        java.util.List list6 = segmentedTimeline5.getExceptionSegments();
        boolean boolean7 = standardCategoryURLGenerator1.equals((java.lang.Object) segmentedTimeline5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis11.setAutoRangeStickyZero(false);
        numberAxis11.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean19 = intervalBarRenderer16.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font21 = null;
        intervalBarRenderer16.setSeriesItemLabelFont((int) '4', font21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener27 = null;
        numberAxis26.addChangeListener(axisChangeListener27);
        org.jfree.chart.plot.Marker marker29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        intervalBarRenderer16.drawRangeMarker(graphics2D23, categoryPlot24, (org.jfree.chart.axis.ValueAxis) numberAxis26, marker29, rectangle2D30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer16);
        boolean boolean33 = intervalBarRenderer16.getBaseSeriesVisibleInLegend();
        boolean boolean34 = intervalBarRenderer16.getAutoPopulateSeriesShape();
        java.awt.Shape shape37 = intervalBarRenderer16.getItemShape((int) (short) 100, 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset38 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart39 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent42 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset38, jFreeChart39, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray43 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean44 = defaultBoxAndWhiskerCategoryDataset38.equals((java.lang.Object) paintArray43);
        org.jfree.data.Range range45 = intervalBarRenderer16.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset38);
        double double47 = defaultBoxAndWhiskerCategoryDataset38.getRangeUpperBound(true);
        java.lang.Number number48 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset38);
        org.jfree.data.general.PieDataset pieDataset50 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset38, (java.lang.Comparable) true);
        boolean boolean51 = standardCategoryURLGenerator1.equals((java.lang.Object) pieDataset50);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(paintArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 0.0d + "'", number48.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("pink");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("pink");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
        java.lang.Throwable[] throwableArray5 = unknownKeyException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint5 = intervalBarRenderer2.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textBlock6.calculateDimensions(graphics2D7);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font10);
        textBlock6.addLine(textLine11);
        org.jfree.chart.text.TextLine textLine13 = textBlock6.getLastLine();
        java.awt.Image image17 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo21 = new org.jfree.chart.ui.ProjectInfo("", "", "", image17, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image22 = null;
        projectInfo21.setLogo(image22);
        org.jfree.chart.ui.Library[] libraryArray24 = projectInfo21.getOptionalLibraries();
        java.awt.Image image28 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo32 = new org.jfree.chart.ui.ProjectInfo("", "", "", image28, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image33 = null;
        projectInfo32.setLogo(image33);
        java.lang.String str35 = projectInfo32.getInfo();
        org.jfree.chart.ui.Library[] libraryArray36 = projectInfo32.getOptionalLibraries();
        java.awt.Image image40 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo44 = new org.jfree.chart.ui.ProjectInfo("", "", "", image40, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image45 = null;
        projectInfo44.setLogo(image45);
        java.lang.String str47 = projectInfo44.getInfo();
        org.jfree.chart.ui.Library[] libraryArray48 = projectInfo44.getOptionalLibraries();
        projectInfo32.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo44);
        projectInfo32.setInfo("");
        projectInfo21.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo32);
        boolean boolean53 = textBlock6.equals((java.lang.Object) projectInfo21);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(textLine13);
        org.junit.Assert.assertNotNull(libraryArray24);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(libraryArray36);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertNotNull(libraryArray48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        piePlot3D0.setShadowPaint((java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke4 = intervalBarRenderer3.getBaseOutlineStroke();
        stackedBarRenderer3D1.setSeriesOutlineStroke((int) (short) 10, stroke4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedBarRenderer3D1.setSeriesPaint((int) '#', (java.awt.Paint) color7);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color16 = java.awt.Color.getHSBColor((float) (short) 1, (float) 10L, 10.0f);
        java.awt.Color color17 = color16.darker();
        float[] floatArray23 = new float[] { (short) -1, (short) 100, 100, 6, (byte) 100 };
        float[] floatArray24 = color17.getRGBColorComponents(floatArray23);
        float[] floatArray25 = color12.getColorComponents(floatArray23);
        float[] floatArray26 = java.awt.Color.RGBtoHSB((int) '4', (int) (byte) 0, 0, floatArray23);
        float[] floatArray27 = color7.getRGBColorComponents(floatArray26);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        piePlot1.setExplodePercent((java.lang.Comparable) "CategoryAnchor.MIDDLE", 1.0E-8d);
        java.awt.Stroke stroke6 = piePlot1.getLabelOutlineStroke();
        piePlot1.setLabelLinksVisible(true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("CategoryAnchor.MIDDLE");
        java.lang.String str2 = taskSeries1.getDescription();
        boolean boolean3 = taskSeries1.getNotify();
        taskSeries1.setDescription("CategoryLabelEntity: category=false, tooltip=, url=hi!");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) (short) 1, (double) 1, (double) 10, (double) 0, paint7);
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        boolean boolean10 = blockBorder8.equals((java.lang.Object) color9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D((double) 10L, (-1.0d));
        size2D14.setHeight((double) 10L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D20 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, 0.0d, (double) (-1L), rectangleAnchor19);
        try {
            blockBorder8.draw(graphics2D11, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("CategoryAnchor.MIDDLE");
        textTitle1.setToolTipText("Category Plot");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Shape shape6 = piePlot5.getLegendItemShape();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = piePlot5.getLegendItems();
        piePlot5.setMinimumArcAngleToDraw((double) 1.0f);
        java.awt.Paint paint10 = piePlot5.getLabelBackgroundPaint();
        boolean boolean11 = textTitle1.equals((java.lang.Object) piePlot5);
        org.jfree.chart.block.BlockFrame blockFrame12 = textTitle1.getFrame();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(blockFrame12);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("CategoryAnchor.MIDDLE");
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener2);
        taskSeries1.setNotify(true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setName("XY Plot");
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getRadiusGridlinePaint();
        polarPlot0.setAngleLabelsVisible(false);
        polarPlot0.removeCornerTextItem("TextAnchor.BASELINE_CENTER");
        java.awt.Paint paint6 = polarPlot0.getAngleGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis7 = polarPlot0.getAxis();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        intervalMarker2.setLabel("hi!");
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder();
        boolean boolean6 = intervalMarker2.equals((java.lang.Object) lineBorder5);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((-1.0d), 0.0d, (double) 68, (double) 100.0f);
        double double13 = rectangleInsets11.calculateBottomOutset((double) 128);
        intervalMarker2.setLabelOffset(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 68.0d + "'", double13 == 68.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        xYPlot9.clearDomainMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot9.setRangeAxisLocation(axisLocation16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot9.getRangeAxisEdge(128);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getOuterSeparatorExtension();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setAutoRangeStickyZero(false);
        boolean boolean7 = numberAxis1.equals((java.lang.Object) (byte) 10);
        numberAxis1.setAutoTickUnitSelection(true, false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot24.rendererChanged(rendererChangeEvent30);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot24);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer34.setBaseItemLabelPaint(paint35);
        boolean boolean38 = intervalBarRenderer34.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer34.setBaseItemLabelFont(font39, false);
        categoryPlot24.setRenderer((int) (short) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer34, true);
        org.jfree.chart.util.StrokeList strokeList44 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer46 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke47 = intervalBarRenderer46.getBaseOutlineStroke();
        strokeList44.setStroke((int) (short) 1, stroke47);
        categoryPlot24.setRangeGridlineStroke(stroke47);
        categoryPlot24.setRangeCrosshairVisible(true);
        boolean boolean52 = categoryPlot24.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat4);
        boolean boolean7 = dateTickUnit5.equals((java.lang.Object) (short) -1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer8.setBaseItemLabelPaint(paint9);
        boolean boolean12 = intervalBarRenderer8.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke16 = intervalBarRenderer14.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = intervalBarRenderer14.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer8.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition18);
        java.awt.Shape shape20 = intervalBarRenderer8.getBaseShape();
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray28, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset34);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity38 = new org.jfree.chart.entity.CategoryItemEntity(shape20, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset34, (java.lang.Comparable) 8.0d, (java.lang.Comparable) 0.0f);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity41 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) boolean7, shape20, "", "hi!");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity42 = new org.jfree.chart.entity.LegendItemEntity(shape20);
        java.lang.String str43 = legendItemEntity42.toString();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str43.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer0.setBaseItemLabelPaint(paint1);
        boolean boolean4 = intervalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke8 = intervalBarRenderer6.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = intervalBarRenderer6.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer0.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition10);
        java.awt.Shape shape12 = intervalBarRenderer0.getBaseShape();
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray20, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray25);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset26);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity30 = new org.jfree.chart.entity.CategoryItemEntity(shape12, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset26, (java.lang.Comparable) 8.0d, (java.lang.Comparable) 0.0f);
        java.lang.String str31 = categoryItemEntity30.getToolTipText();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset32 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double34 = defaultBoxAndWhiskerCategoryDataset32.getRangeUpperBound(true);
        categoryItemEntity30.setDataset((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset32);
        java.lang.Number number38 = defaultBoxAndWhiskerCategoryDataset32.getMinRegularValue((java.lang.Comparable) 96, (java.lang.Comparable) 10.0f);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNull(number38);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setWeight(10);
        xYPlot9.setRangeCrosshairValue((double) 4, true);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer27 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint30 = intervalBarRenderer27.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock31 = org.jfree.chart.text.TextUtilities.createTextBlock("", font26, paint30);
        numberAxis24.setTickLabelPaint(paint30);
        numberAxis24.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis39.setAutoRangeStickyZero(false);
        numberAxis39.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean47 = intervalBarRenderer44.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font49 = null;
        intervalBarRenderer44.setSeriesItemLabelFont((int) '4', font49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener55 = null;
        numberAxis54.addChangeListener(axisChangeListener55);
        org.jfree.chart.plot.Marker marker57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        intervalBarRenderer44.drawRangeMarker(graphics2D51, categoryPlot52, (org.jfree.chart.axis.ValueAxis) numberAxis54, marker57, rectangle2D58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer44);
        categoryPlot60.configureRangeAxes();
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = null;
        org.jfree.chart.axis.AxisSpace axisSpace64 = null;
        org.jfree.chart.axis.AxisSpace axisSpace65 = numberAxis24.reserveSpace(graphics2D35, (org.jfree.chart.plot.Plot) categoryPlot60, rectangle2D62, rectangleEdge63, axisSpace64);
        double double66 = axisSpace65.getTop();
        xYPlot9.setFixedRangeAxisSpace(axisSpace65);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(textBlock31);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(axisSpace65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        double double5 = numberAxis2.getUpperBound();
        numberAxis2.setLabelURL("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis8, xYItemRenderer9);
        xYPlot10.setRangeCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.LegendItem legendItem3 = lineRenderer3D0.getLegendItem((int) (short) 10, (int) (byte) 100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = lineRenderer3D0.getDrawingSupplier();
        boolean boolean5 = lineRenderer3D0.getUseFillPaint();
        java.lang.Object obj6 = lineRenderer3D0.clone();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNull(drawingSupplier4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        double double4 = numberAxis1.getUpperBound();
        java.awt.Paint paint5 = numberAxis1.getAxisLinePaint();
        float float6 = numberAxis1.getTickMarkInsideLength();
        boolean boolean7 = numberAxis1.isVisible();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        boolean boolean25 = intervalBarRenderer8.getBaseSeriesVisibleInLegend();
        boolean boolean26 = intervalBarRenderer8.getAutoPopulateSeriesShape();
        java.awt.Shape shape29 = intervalBarRenderer8.getItemShape((int) (short) 100, 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset30 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent34 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset30, jFreeChart31, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean36 = defaultBoxAndWhiskerCategoryDataset30.equals((java.lang.Object) paintArray35);
        org.jfree.data.Range range37 = intervalBarRenderer8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30);
        int int39 = defaultBoxAndWhiskerCategoryDataset30.getColumnIndex((java.lang.Comparable) Double.NaN);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener40 = null;
        defaultBoxAndWhiskerCategoryDataset30.removeChangeListener(datasetChangeListener40);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        numberAxis1.addChangeListener(axisChangeListener2);
        java.lang.Class<?> wildcardClass4 = numberAxis1.getClass();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = polarPlot5.getRenderer();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot5);
        boolean boolean8 = polarPlot5.isAngleGridlinesVisible();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(polarItemRenderer6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean5 = intervalBarRenderer2.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font7 = null;
        intervalBarRenderer2.setSeriesItemLabelFont((int) '4', font7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener13 = null;
        numberAxis12.addChangeListener(axisChangeListener13);
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        intervalBarRenderer2.drawRangeMarker(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) numberAxis12, marker15, rectangle2D16);
        double double18 = intervalBarRenderer2.getItemMargin();
        keyedObjects0.addObject((java.lang.Comparable) 0, (java.lang.Object) double18);
        java.util.List list20 = keyedObjects0.getKeys();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis24.setAutoRangeStickyZero(false);
        numberAxis24.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer29 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean32 = intervalBarRenderer29.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font34 = null;
        intervalBarRenderer29.setSeriesItemLabelFont((int) '4', font34);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener40 = null;
        numberAxis39.addChangeListener(axisChangeListener40);
        org.jfree.chart.plot.Marker marker42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        intervalBarRenderer29.drawRangeMarker(graphics2D36, categoryPlot37, (org.jfree.chart.axis.ValueAxis) numberAxis39, marker42, rectangle2D43);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer29);
        double double46 = categoryPlot45.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation47 = categoryPlot45.getDomainAxisLocation();
        java.awt.Paint paint48 = categoryPlot45.getNoDataMessagePaint();
        categoryPlot45.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent51 = null;
        categoryPlot45.rendererChanged(rendererChangeEvent51);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent53 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot45);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer55 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint56 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer55.setBaseItemLabelPaint(paint56);
        boolean boolean59 = intervalBarRenderer55.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font60 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer55.setBaseItemLabelFont(font60, false);
        categoryPlot45.setRenderer((int) (short) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer55, true);
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str68 = dateAxis67.getLabelToolTip();
        java.awt.Shape shape69 = dateAxis67.getDownArrow();
        boolean boolean71 = dateAxis67.isHiddenValue((long) (byte) -1);
        categoryPlot45.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) dateAxis67);
        java.util.Date date73 = dateAxis67.getMinimumDate();
        int int74 = keyedObjects0.getIndex((java.lang.Comparable) date73);
        java.lang.Object obj76 = keyedObjects0.getObject(0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + obj76 + "' != '" + 0.2d + "'", obj76.equals(0.2d));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.data.DefaultKeyedValues defaultKeyedValues6 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Number number8 = null;
        defaultKeyedValues6.addValue((java.lang.Comparable) 8.0d, number8);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer10 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean11 = defaultKeyedValues6.equals((java.lang.Object) boxAndWhiskerRenderer10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str14 = dateAxis13.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition15 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis13.setTickMarkPosition(dateTickMarkPosition15);
        java.text.DateFormat dateFormat21 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat21);
        java.util.Date date23 = dateAxis13.calculateHighestVisibleTickValue(dateTickUnit22);
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick30 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0, "hi!", textAnchor27, textAnchor28, (double) 4);
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.DateTick dateTick33 = new org.jfree.chart.axis.DateTick(date23, "hi!", textAnchor28, textAnchor31, (double) 2958465);
        boolean boolean34 = defaultKeyedValues6.equals((java.lang.Object) dateTick33);
        org.jfree.chart.text.TextAnchor textAnchor35 = dateTick33.getTextAnchor();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Range[0.0,1.0]", graphics2D1, (float) 255, 100.0f, textAnchor4, (double) 0L, textAnchor35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition15);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(textAnchor35);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        piePlot1.setExplodePercent((java.lang.Comparable) "CategoryAnchor.MIDDLE", 1.0E-8d);
        java.awt.Stroke stroke6 = piePlot1.getLabelOutlineStroke();
        piePlot1.setIgnoreNullValues(false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = null;
        piePlot1.setLabelGenerator(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.Object obj1 = null;
        boolean boolean2 = dateTickUnit0.equals(obj1);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        boolean boolean3 = dateAxis1.isHiddenValue(0L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("CategoryAnchor.MIDDLE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double4 = rectangleInsets2.extendHeight(Double.NaN);
        textTitle1.setMargin(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 0.95f, (double) (-1L));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setDepthFactor(4.0d);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis6.setAutoRangeStickyZero(false);
        numberAxis6.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean14 = intervalBarRenderer11.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font16 = null;
        intervalBarRenderer11.setSeriesItemLabelFont((int) '4', font16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener22 = null;
        numberAxis21.addChangeListener(axisChangeListener22);
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        intervalBarRenderer11.drawRangeMarker(graphics2D18, categoryPlot19, (org.jfree.chart.axis.ValueAxis) numberAxis21, marker24, rectangle2D25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer11);
        double double28 = categoryPlot27.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot27.getDomainAxisLocation();
        categoryPlot27.configureDomainAxes();
        boolean boolean31 = piePlot3D0.equals((java.lang.Object) categoryPlot27);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor32 = piePlot3D0.getLabelDistributor();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor32);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot9.getRangeAxisLocation();
        java.util.List list16 = xYPlot9.getAnnotations();
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection18 = xYPlot9.getRangeMarkers(layer17);
        xYPlot9.setNoDataMessage("TextAnchor.BASELINE_CENTER");
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot9.getRendererForDataset(xYDataset21);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(xYItemRenderer22);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Number number2 = null;
        defaultKeyedValues0.addValue((java.lang.Comparable) 8.0d, number2);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer4 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean5 = defaultKeyedValues0.equals((java.lang.Object) boxAndWhiskerRenderer4);
        java.awt.Shape shape7 = boxAndWhiskerRenderer4.lookupSeriesShape((int) (short) 1);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint10 = polarPlot9.getRadiusGridlinePaint();
        polarPlot9.setAngleLabelsVisible(false);
        java.awt.Paint paint13 = polarPlot9.getOutlinePaint();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer17 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer17.setBaseItemLabelPaint(paint18);
        boolean boolean21 = intervalBarRenderer17.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer17.setBaseItemLabelFont(font22, false);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font22, (java.awt.Paint) color25);
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("", font22);
        labelBlock27.setID("Category Plot");
        java.awt.Paint paint30 = labelBlock27.getPaint();
        java.awt.geom.Rectangle2D rectangle2D31 = labelBlock27.getBounds();
        java.awt.geom.Point2D point2D32 = null;
        org.jfree.chart.plot.PlotState plotState33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        polarPlot9.draw(graphics2D14, rectangle2D31, point2D32, plotState33, plotRenderingInfo34);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis39.setAutoRangeStickyZero(false);
        numberAxis39.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean47 = intervalBarRenderer44.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font49 = null;
        intervalBarRenderer44.setSeriesItemLabelFont((int) '4', font49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener55 = null;
        numberAxis54.addChangeListener(axisChangeListener55);
        org.jfree.chart.plot.Marker marker57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        intervalBarRenderer44.drawRangeMarker(graphics2D51, categoryPlot52, (org.jfree.chart.axis.ValueAxis) numberAxis54, marker57, rectangle2D58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer44);
        double double61 = categoryPlot60.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation62 = categoryPlot60.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent63 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState66 = boxAndWhiskerRenderer4.initialise(graphics2D8, rectangle2D31, categoryPlot60, 68, plotRenderingInfo65);
        categoryPlot60.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertNotNull(categoryItemRendererState66);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str1 = standardCategoryToolTipGenerator0.getLabelFormat();
        java.text.NumberFormat numberFormat2 = standardCategoryToolTipGenerator0.getNumberFormat();
        java.awt.Color color3 = java.awt.Color.WHITE;
        boolean boolean4 = standardCategoryToolTipGenerator0.equals((java.lang.Object) color3);
        java.lang.String str5 = standardCategoryToolTipGenerator0.getLabelFormat();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "({0}, {1}) = {2}" + "'", str1.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "({0}, {1}) = {2}" + "'", str5.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint5 = intervalBarRenderer2.getItemFillPaint(100, (int) 'a');
        stackedBarRenderer3D1.setWallPaint(paint5);
        java.awt.Stroke stroke8 = stackedBarRenderer3D1.getSeriesStroke(2);
        boolean boolean9 = stackedBarRenderer3D1.getBaseSeriesVisibleInLegend();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis14.setAutoRangeStickyZero(false);
        numberAxis14.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean22 = intervalBarRenderer19.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font24 = null;
        intervalBarRenderer19.setSeriesItemLabelFont((int) '4', font24);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener30 = null;
        numberAxis29.addChangeListener(axisChangeListener30);
        org.jfree.chart.plot.Marker marker32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        intervalBarRenderer19.drawRangeMarker(graphics2D26, categoryPlot27, (org.jfree.chart.axis.ValueAxis) numberAxis29, marker32, rectangle2D33);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer19);
        double double36 = categoryPlot35.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot35.getDomainAxisLocation();
        categoryPlot35.configureDomainAxes();
        int int39 = categoryPlot35.getWeight();
        int int40 = categoryPlot35.getWeight();
        categoryPlot35.setDomainGridlinesVisible(false);
        int int43 = categoryPlot35.getDomainAxisCount();
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis46.setAutoRangeStickyZero(false);
        numberAxis46.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) numberAxis46, valueAxis51, xYItemRenderer52);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer54 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke56 = intervalBarRenderer54.lookupSeriesStroke(3);
        xYPlot53.setDomainGridlineStroke(stroke56);
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot53.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis60);
        double double62 = dateAxis60.getLabelAngle();
        dateAxis60.setNegativeArrowVisible(true);
        java.awt.Paint paint65 = dateAxis60.getTickMarkPaint();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer68 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint69 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer68.setBaseItemLabelPaint(paint69);
        boolean boolean72 = intervalBarRenderer68.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font73 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer68.setBaseItemLabelFont(font73, false);
        java.awt.Color color76 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock77 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font73, (java.awt.Paint) color76);
        org.jfree.chart.block.LabelBlock labelBlock78 = new org.jfree.chart.block.LabelBlock("", font73);
        labelBlock78.setID("Category Plot");
        java.awt.Paint paint81 = labelBlock78.getPaint();
        java.awt.geom.Rectangle2D rectangle2D82 = labelBlock78.getBounds();
        stackedBarRenderer3D1.drawRangeGridline(graphics2D10, categoryPlot35, (org.jfree.chart.axis.ValueAxis) dateAxis60, rectangle2D82, (double) 10.0f);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertNotNull(color76);
        org.junit.Assert.assertNotNull(textBlock77);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNotNull(rectangle2D82);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.awt.Shape shape8 = null;
        java.awt.Color color9 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", "hi!", shape8, (java.awt.Paint) color9);
        legendItem10.setSeriesIndex((int) (short) -1);
        java.awt.Shape shape13 = legendItem10.getLine();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer15 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer15.setBaseItemLabelPaint(paint16);
        boolean boolean19 = intervalBarRenderer15.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer15.setBaseItemLabelFont(font20, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font20, (java.awt.Paint) color23);
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "TextAnchor.BASELINE_CENTER", "Category Plot", "hi!", shape13, (java.awt.Paint) color23);
        boolean boolean26 = legendItem25.isLineVisible();
        legendItem25.setSeriesIndex(0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(textBlock24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot9.getRenderer(0);
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        try {
            xYPlot9.setDomainAxisLocation(axisLocation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot24);
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot24.getOrientation();
        categoryPlot24.zoom((double) 100);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str35 = dateAxis34.getLabelToolTip();
        java.awt.Shape shape36 = dateAxis34.getDownArrow();
        boolean boolean38 = dateAxis34.isHiddenValue((long) (byte) -1);
        categoryPlot24.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis34);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer40 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Shape shape42 = null;
        intervalBarRenderer40.setSeriesShape(4, shape42, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent45 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 4);
        categoryPlot24.rendererChanged(rendererChangeEvent45);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "", font2);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) 0);
        categoryAxis0.setMaximumCategoryLabelLines((int) (byte) 10);
        categoryAxis0.setUpperMargin((double) 0);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis12.setAutoRangeStickyZero(false);
        numberAxis12.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis12, valueAxis17, xYItemRenderer18);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer20 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke22 = intervalBarRenderer20.lookupSeriesStroke(3);
        xYPlot19.setDomainGridlineStroke(stroke22);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot19.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis26);
        float float28 = xYPlot19.getForegroundAlpha();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot19);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint37 = intervalBarRenderer34.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font33, paint37);
        numberAxis31.setTickLabelPaint(paint37);
        numberAxis31.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis46.setAutoRangeStickyZero(false);
        numberAxis46.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer51 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean54 = intervalBarRenderer51.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font56 = null;
        intervalBarRenderer51.setSeriesItemLabelFont((int) '4', font56);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = null;
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener62 = null;
        numberAxis61.addChangeListener(axisChangeListener62);
        org.jfree.chart.plot.Marker marker64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        intervalBarRenderer51.drawRangeMarker(graphics2D58, categoryPlot59, (org.jfree.chart.axis.ValueAxis) numberAxis61, marker64, rectangle2D65);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) numberAxis46, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer51);
        categoryPlot67.configureRangeAxes();
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = null;
        org.jfree.chart.axis.AxisSpace axisSpace71 = null;
        org.jfree.chart.axis.AxisSpace axisSpace72 = numberAxis31.reserveSpace(graphics2D42, (org.jfree.chart.plot.Plot) categoryPlot67, rectangle2D69, rectangleEdge70, axisSpace71);
        axisSpace72.setTop((double) '#');
        xYPlot19.setFixedDomainAxisSpace(axisSpace72);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(axisSpace72);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        double double1 = boxAndWhiskerRenderer0.getItemMargin();
        boxAndWhiskerRenderer0.setItemMargin((double) (-1L));
        boxAndWhiskerRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer7 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 10);
        java.awt.Stroke stroke12 = intervalMarker11.getOutlineStroke();
        layeredBarRenderer7.setSeriesStroke((int) '4', stroke12, false);
        boxAndWhiskerRenderer0.setSeriesStroke(68, stroke12);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.lang.String[] strArray0 = null;
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray6, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray11);
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray20, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", numberArray25);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset28 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray11, numberArray25);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(categoryDataset27);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        categoryPlot24.configureDomainAxes();
        int int28 = categoryPlot24.getWeight();
        int int29 = categoryPlot24.getWeight();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis32.setAutoRangeStickyZero(false);
        double double35 = numberAxis32.getUpperBound();
        numberAxis32.setLabelURL("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis32, valueAxis38, xYItemRenderer39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis44.setAutoRangeStickyZero(false);
        numberAxis44.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer49 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean52 = intervalBarRenderer49.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font54 = null;
        intervalBarRenderer49.setSeriesItemLabelFont((int) '4', font54);
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = null;
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener60 = null;
        numberAxis59.addChangeListener(axisChangeListener60);
        org.jfree.chart.plot.Marker marker62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        intervalBarRenderer49.drawRangeMarker(graphics2D56, categoryPlot57, (org.jfree.chart.axis.ValueAxis) numberAxis59, marker62, rectangle2D63);
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) numberAxis44, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer49);
        double double66 = categoryPlot65.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation67 = categoryPlot65.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent68 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot65);
        org.jfree.chart.util.Layer layer70 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection71 = categoryPlot65.getDomainMarkers((int) ' ', layer70);
        java.util.Collection collection72 = xYPlot40.getRangeMarkers(layer70);
        java.awt.Graphics2D graphics2D73 = null;
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = null;
        xYPlot40.drawAnnotations(graphics2D73, rectangle2D74, plotRenderingInfo75);
        boolean boolean77 = xYPlot40.isRangeZeroBaselineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = xYPlot40.getDomainAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation79 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot40.setOrientation(plotOrientation79);
        categoryPlot24.setOrientation(plotOrientation79);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation67);
        org.junit.Assert.assertNotNull(layer70);
        org.junit.Assert.assertNull(collection71);
        org.junit.Assert.assertNull(collection72);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(rectangleEdge78);
        org.junit.Assert.assertNotNull(plotOrientation79);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean6 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) paintArray5);
        org.jfree.data.general.DatasetGroup datasetGroup8 = new org.jfree.data.general.DatasetGroup("hi!");
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup8);
        org.jfree.data.KeyToGroupMap keyToGroupMap11 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) "PlotOrientation.VERTICAL");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator12 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str13 = standardCategoryToolTipGenerator12.getLabelFormat();
        boolean boolean14 = keyToGroupMap11.equals((java.lang.Object) str13);
        int int15 = keyToGroupMap11.getGroupCount();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, keyToGroupMap11);
        java.lang.String str17 = range16.toString();
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "({0}, {1}) = {2}" + "'", str13.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Range[0.0,0.0]" + "'", str17.equals("Range[0.0,0.0]"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", "hi!", shape4, (java.awt.Paint) color5);
        boolean boolean7 = legendItem6.isShapeOutlineVisible();
        int int8 = legendItem6.getDatasetIndex();
        java.awt.Paint paint9 = legendItem6.getOutlinePaint();
        int int10 = legendItem6.getDatasetIndex();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean6 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) paintArray5);
        org.jfree.data.general.DatasetGroup datasetGroup8 = new org.jfree.data.general.DatasetGroup("hi!");
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup8);
        org.jfree.data.KeyToGroupMap keyToGroupMap11 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) "PlotOrientation.VERTICAL");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator12 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str13 = standardCategoryToolTipGenerator12.getLabelFormat();
        boolean boolean14 = keyToGroupMap11.equals((java.lang.Object) str13);
        int int15 = keyToGroupMap11.getGroupCount();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, keyToGroupMap11);
        try {
            java.util.List list19 = defaultBoxAndWhiskerCategoryDataset0.getOutliers((-65536), 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "({0}, {1}) = {2}" + "'", str13.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(12.0d, (double) (-1));
        java.lang.Boolean boolean4 = stackedBarRenderer3D2.getSeriesVisibleInLegend(68);
        java.awt.Paint paint6 = stackedBarRenderer3D2.getSeriesOutlinePaint((int) (byte) 1);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false);
        stackedBarRenderer3D2.setMaximumBarWidth((double) (short) 100);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis6.setAutoRangeStickyZero(false);
        numberAxis6.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean14 = intervalBarRenderer11.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font16 = null;
        intervalBarRenderer11.setSeriesItemLabelFont((int) '4', font16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener22 = null;
        numberAxis21.addChangeListener(axisChangeListener22);
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        intervalBarRenderer11.drawRangeMarker(graphics2D18, categoryPlot19, (org.jfree.chart.axis.ValueAxis) numberAxis21, marker24, rectangle2D25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer11);
        double double28 = categoryPlot27.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot27.getDomainAxisLocation();
        java.awt.Paint paint30 = categoryPlot27.getNoDataMessagePaint();
        categoryPlot27.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = categoryPlot27.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState36 = boxAndWhiskerRenderer0.initialise(graphics2D1, rectangle2D2, categoryPlot27, (int) (short) -1, plotRenderingInfo35);
        org.jfree.chart.util.SortOrder sortOrder37 = categoryPlot27.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertNotNull(categoryItemRendererState36);
        org.junit.Assert.assertNotNull(sortOrder37);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        piePlot1.setExplodePercent((java.lang.Comparable) 0.4d, (double) 100L);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = piePlot1.getLabelDistributor();
        boolean boolean7 = piePlot1.getIgnoreNullValues();
        java.lang.String str8 = piePlot1.getNoDataMessage();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setYOffset(0.25d);
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        lineRenderer3D0.setWallPaint(paint3);
        java.lang.Boolean boolean6 = lineRenderer3D0.getSeriesVisibleInLegend(35);
        java.awt.Paint paint9 = lineRenderer3D0.getItemLabelPaint((int) (byte) -1, (int) (byte) 10);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        double double6 = numberAxis3.getUpperBound();
        numberAxis3.setLabelURL("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, valueAxis9, xYItemRenderer10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot11.setRenderer(100, xYItemRenderer13);
        java.awt.Stroke stroke15 = xYPlot11.getRangeZeroBaselineStroke();
        categoryAxis0.setAxisLineStroke(stroke15);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        numberAxis1.addChangeListener(axisChangeListener2);
        java.lang.Class<?> wildcardClass4 = numberAxis1.getClass();
        boolean boolean5 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass4);
        java.lang.ClassLoader classLoader6 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader6);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(classLoader6);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot1.setURLGenerator(pieURLGenerator3);
        java.text.DateFormat dateFormat9 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat9);
        java.awt.Color color11 = java.awt.Color.BLACK;
        piePlot1.setSectionPaint((java.lang.Comparable) dateTickUnit10, (java.awt.Paint) color11);
        piePlot1.setCircular(false, false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(0, 192, 7, (int) (byte) 100, dateFormat4);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "", font2);
        float float4 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Shape shape4 = piePlot3.getLegendItemShape();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = piePlot3.getLegendItems();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer9 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke10 = intervalBarRenderer9.getBaseOutlineStroke();
        stackedBarRenderer3D7.setSeriesOutlineStroke((int) (short) 10, stroke10);
        piePlot3.setLabelLinkStroke(stroke10);
        ringPlot1.setSeparatorStroke(stroke10);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 1, (double) (-2208960000000L));
        double double3 = size2D2.width;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getShadowPaint();
        java.awt.Shape shape3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis5.setAutoRangeStickyZero(false);
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        numberAxis5.setTickMarkPaint(paint8);
        org.jfree.chart.title.LegendGraphic legendGraphic10 = new org.jfree.chart.title.LegendGraphic(shape3, paint8);
        piePlot0.setSectionPaint((java.lang.Comparable) "Category Plot", paint8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = rendererState1.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        float float18 = xYPlot9.getForegroundAlpha();
        xYPlot9.clearRangeMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot9.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        numberAxis1.setTickLabelPaint(paint7);
        boolean boolean10 = numberAxis1.isAutoTickUnitSelection();
        numberAxis1.resizeRange(0.25d, (double) 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }
}

