import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.data.Range range4 = null;
        try {
            numberAxis1.setRange(range4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = intervalBarRenderer0.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        try {
            intervalBarRenderer0.setSeriesPositiveItemLabelPosition((-1), itemLabelPosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double5 = numberAxis1.lengthToJava2D(0.0d, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit((int) (short) 10, (int) (byte) 100, (int) (byte) 0, (int) (short) 100, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100, (int) (short) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.0d, (double) 4, (int) (byte) 10, (java.lang.Comparable) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = intervalBarRenderer0.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        try {
            intervalBarRenderer0.setSeriesToolTipGenerator((int) (byte) -1, categoryToolTipGenerator5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, paint2, 10.0f, 10, textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Shape shape0 = null;
        try {
            java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, (double) 0, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        float[] floatArray2 = new float[] { '#' };
        try {
            float[] floatArray3 = color0.getColorComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        try {
            intervalMarker2.setAlpha((float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test022");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font5 = null;
        intervalBarRenderer0.setSeriesItemLabelFont((int) '4', font5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener11 = null;
        numberAxis10.addChangeListener(axisChangeListener11);
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        intervalBarRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis10, marker13, rectangle2D14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        try {
            org.jfree.data.Range range17 = intervalBarRenderer0.findRangeBounds(categoryDataset16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        try {
            categoryPlot24.handleClick(4, (int) 'a', plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = null;
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint14 = intervalBarRenderer11.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, paint14);
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("hi!", font8, paint14, 100.0f);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer23 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint26 = intervalBarRenderer23.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("", font22, paint26);
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("hi!", font20, paint26, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer30 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke31 = intervalBarRenderer30.getBaseOutlineStroke();
        java.awt.Shape shape33 = null;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke35 = intervalBarRenderer34.getBaseOutlineStroke();
        java.awt.Font font37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer38 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint41 = intervalBarRenderer38.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock42 = org.jfree.chart.text.TextUtilities.createTextBlock("", font37, paint41);
        try {
            org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem(attributedString0, "", "", "", false, shape5, false, paint14, true, paint26, stroke31, true, shape33, stroke35, paint41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(textBlock27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(textBlock42);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = categoryPlot24.getDatasetRenderingOrder();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.Point2D point2D28 = null;
        org.jfree.chart.plot.PlotState plotState29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            categoryPlot24.draw(graphics2D26, rectangle2D27, point2D28, plotState29, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Shape shape0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        try {
            java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, (double) (byte) 10, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis6.setAutoRangeStickyZero(false);
        numberAxis6.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean14 = intervalBarRenderer11.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font16 = null;
        intervalBarRenderer11.setSeriesItemLabelFont((int) '4', font16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener22 = null;
        numberAxis21.addChangeListener(axisChangeListener22);
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        intervalBarRenderer11.drawRangeMarker(graphics2D18, categoryPlot19, (org.jfree.chart.axis.ValueAxis) numberAxis21, marker24, rectangle2D25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer11);
        double double28 = categoryPlot27.getRangeCrosshairValue();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        try {
            stackedBarRenderer3D1.drawBackground(graphics2D2, categoryPlot27, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        java.awt.Paint paint25 = categoryPlot24.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(4, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Shape shape18 = null;
        try {
            dateAxis16.setDownArrow(shape18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = null;
        try {
            categoryPlot24.addDomainMarker(categoryMarker28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit((int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 0.0d, (java.lang.Object) false);
        java.lang.Object obj3 = keyedObject2.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.util.Date date1 = null;
        java.util.Date date2 = null;
        try {
            org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("hi!", date1, date2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("hi!", font1, paint7, 100.0f);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            float float13 = textFragment10.calculateBaselineOffset(graphics2D11, textAnchor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Shape shape2 = null;
        intervalBarRenderer0.setSeriesShape(4, shape2, false);
        intervalBarRenderer0.setBaseCreateEntities(false, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = null;
        intervalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator8);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        numberAxis2.setLabelAngle((double) 1L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("hi!", font1, paint7, 100.0f);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick19 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0, "hi!", textAnchor16, textAnchor17, (double) 4);
        try {
            textFragment10.draw(graphics2D11, (float) (-2208960000000L), (float) (short) 100, textAnchor17, (float) (short) 10, 10.0f, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(textAnchor17);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.Date date1 = null;
        java.util.Date date2 = null;
        try {
            org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", date1, date2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = categoryPlot24.getDatasetRenderingOrder();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation26 = null;
        try {
            categoryPlot24.addAnnotation(categoryAnnotation26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke6 = lineBorder5.getStroke();
        java.awt.Color color10 = java.awt.Color.getHSBColor((float) (short) 1, (float) 10L, 10.0f);
        java.awt.Color color11 = color10.darker();
        try {
            org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem(attributedString0, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "", "", shape4, stroke6, (java.awt.Paint) color11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) 4, (float) (short) 0, textAnchor4, (double) (byte) 10, (float) ' ', 0.0f);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.util.TimeZone timeZone2 = null;
        try {
            dateAxis1.setTimeZone(timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        xYPlot9.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis22.setAutoRangeStickyZero(false);
        double double25 = numberAxis22.getUpperBound();
        xYPlot9.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis22, false);
        java.awt.Shape shape28 = null;
        try {
            numberAxis22.setLeftArrow(shape28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100L, (float) (byte) 100);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray5, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray10);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset11);
        double double14 = range12.constrain(0.05d);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list1 = defaultKeyedValues0.getKeys();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer0.setBaseItemLabelPaint(paint1);
        boolean boolean4 = intervalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        intervalBarRenderer0.setBaseURLGenerator(categoryURLGenerator5, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge1);
        try {
            double double3 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0L, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.JFreeChart jFreeChart4 = chartChangeEvent3.getChart();
        org.junit.Assert.assertNull(jFreeChart4);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.setValue((java.lang.Comparable) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", (java.lang.Number) (short) 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        double double6 = numberAxis3.getUpperBound();
        numberAxis3.setLabelURL("hi!");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer9 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer9.setBaseItemLabelPaint(paint10);
        boolean boolean13 = intervalBarRenderer9.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer9);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Color color6 = java.awt.Color.getHSBColor((float) (short) 1, (float) 10L, 10.0f);
        java.awt.Color color7 = color6.darker();
        float[] floatArray13 = new float[] { (short) -1, (short) 100, 100, 6, (byte) 100 };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        float[] floatArray15 = java.awt.Color.RGBtoHSB((int) (byte) 0, 0, (int) (byte) 0, floatArray13);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray30 = null;
        try {
            categoryPlot24.setRenderers(categoryItemRendererArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double2 = defaultBoxAndWhiskerCategoryDataset0.getRangeUpperBound(true);
        try {
            java.lang.Comparable comparable4 = defaultBoxAndWhiskerCategoryDataset0.getColumnKey((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("hi!");
        java.awt.Color color2 = java.awt.Color.GREEN;
        boolean boolean3 = datasetGroup1.equals((java.lang.Object) color2);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke1 = intervalBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = intervalBarRenderer0.getSeriesURLGenerator(0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryURLGenerator3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(12.0d, (double) (-1));
        try {
            stackedBarRenderer3D2.setSeriesCreateEntities((int) (byte) -1, (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) (byte) -1);
        try {
            org.jfree.chart.util.Size2D size2D6 = columnArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick7 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0, "hi!", textAnchor4, textAnchor5, (double) 4);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType9 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor5, (double) (short) -1, categoryLabelWidthType9, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setDomainCrosshairVisible(false);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.Point2D point2D22 = null;
        org.jfree.chart.plot.PlotState plotState23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            xYPlot9.draw(graphics2D20, rectangle2D21, point2D22, plotState23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double2 = defaultBoxAndWhiskerCategoryDataset0.getRangeUpperBound(true);
        try {
            java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(3, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 10L, (-1.0d));
        size2D2.setHeight((double) 10L);
        double double5 = size2D2.height;
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem3 = defaultBoxAndWhiskerCategoryDataset0.getItem((int) (short) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double2 = defaultBoxAndWhiskerCategoryDataset0.getRangeUpperBound(true);
        try {
            java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getValue((int) (short) 0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 10L, (-1.0d));
        double double3 = size2D2.width;
        size2D2.width = 1.0f;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer0.setAutoPopulateSeriesShape(true);
        java.lang.Boolean boolean4 = intervalBarRenderer0.getSeriesItemLabelsVisible(6);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 6, (float) 10L);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        intervalMarker2.setLabel("hi!");
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder();
        boolean boolean6 = intervalMarker2.equals((java.lang.Object) lineBorder5);
        intervalMarker2.setEndValue((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str2 = categoryAnchor1.toString();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge8);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = categoryLabelPositions7.getLabelPosition(rectangleEdge8);
        try {
            double double11 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor1, (int) (byte) 100, (int) (byte) 0, rectangle2D5, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str2.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(categoryLabelPosition10);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.junit.Assert.assertNull(timeZone0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = null;
        try {
            categoryPlot24.setInsets(rectangleInsets28, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        org.jfree.chart.util.StrokeList strokeList26 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer28 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke29 = intervalBarRenderer28.getBaseOutlineStroke();
        strokeList26.setStroke((int) (short) 1, stroke29);
        intervalBarRenderer8.setSeriesOutlineStroke(68, stroke29);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        java.awt.Paint paint4 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("Category Plot", font2, paint4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str2 = dateAxis1.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            dateAxis1.setLabelInsets(rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.util.TimeZone timeZone18 = null;
        try {
            dateAxis16.setTimeZone(timeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("CategoryAnchor.MIDDLE", "Category Plot", "");
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        double double4 = numberAxis1.getUpperBound();
        numberAxis1.setUpperMargin((double) (-1L));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) '4');
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        java.lang.Object obj3 = intervalMarker2.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            intervalMarker2.setLabelOffset(rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("hi!", font1, paint7, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean14 = intervalBarRenderer11.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font16 = null;
        intervalBarRenderer11.setSeriesItemLabelFont((int) '4', font16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener22 = null;
        numberAxis21.addChangeListener(axisChangeListener22);
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        intervalBarRenderer11.drawRangeMarker(graphics2D18, categoryPlot19, (org.jfree.chart.axis.ValueAxis) numberAxis21, marker24, rectangle2D25);
        boolean boolean27 = textFragment10.equals((java.lang.Object) graphics2D18);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            float float30 = textFragment10.calculateBaselineOffset(graphics2D28, textAnchor29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(textAnchor29);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer0.setBaseItemLabelPaint(paint1);
        java.awt.Shape shape3 = intervalBarRenderer0.getBaseShape();
        java.lang.Boolean boolean5 = intervalBarRenderer0.getSeriesVisible(0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int0 = org.jfree.chart.axis.DateTickUnit.MINUTE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "", "CategoryAnchor.MIDDLE");
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str3 = dateRange2.toString();
        java.util.Date date4 = dateRange2.getLowerDate();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str3.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = intervalBarRenderer0.getItemFillPaint(100, (int) 'a');
        intervalBarRenderer0.setBaseItemLabelsVisible(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = intervalBarRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke4 = intervalBarRenderer3.getBaseOutlineStroke();
        stackedBarRenderer3D1.setSeriesOutlineStroke((int) (short) 10, stroke4);
        java.awt.Shape shape6 = stackedBarRenderer3D1.getBaseShape();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double[] doubleArray3 = new double[] { (short) -1, 12.0d, (byte) 100 };
        double[] doubleArray7 = new double[] { (short) -1, 12.0d, (byte) 100 };
        double[][] doubleArray8 = new double[][] { doubleArray3, doubleArray7 };
        double[] doubleArray13 = new double[] { 10, (short) 0, (byte) 0, 100L };
        double[] doubleArray18 = new double[] { 10, (short) 0, (byte) 0, 100L };
        double[] doubleArray23 = new double[] { 10, (short) 0, (byte) 0, 100L };
        double[] doubleArray28 = new double[] { 10, (short) 0, (byte) 0, 100L };
        double[][] doubleArray29 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset30 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray8, doubleArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = intervalBarRenderer0.getSeriesURLGenerator((int) '#');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = intervalBarRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNull(categoryURLGenerator6);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke4 = intervalBarRenderer3.getBaseOutlineStroke();
        stackedBarRenderer3D1.setSeriesOutlineStroke((int) (short) 10, stroke4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedBarRenderer3D1.setSeriesPaint((int) '#', (java.awt.Paint) color7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener13 = null;
        numberAxis12.addChangeListener(axisChangeListener13);
        numberAxis12.setRangeWithMargins((double) (short) -1, (double) (byte) 0);
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        intervalMarker20.setLabel("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.plot.Marker) intervalMarker20, rectangle2D23);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker20.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(gradientPaintTransformer25);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        xYPlot9.clearDomainMarkers();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot9.getDomainAxisForDataset((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font5 = null;
        intervalBarRenderer0.setSeriesItemLabelFont((int) '4', font5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = intervalBarRenderer0.getPositiveItemLabelPosition(15, (int) (short) 10);
        intervalBarRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Stroke stroke13 = intervalBarRenderer0.getSeriesStroke((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(stroke13);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 4.0d, (double) (short) 0, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean4 = intervalBarRenderer1.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font6 = null;
        intervalBarRenderer1.setSeriesItemLabelFont((int) '4', font6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener12 = null;
        numberAxis11.addChangeListener(axisChangeListener12);
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        intervalBarRenderer1.drawRangeMarker(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis11, marker14, rectangle2D15);
        double double17 = intervalBarRenderer1.getItemMargin();
        java.awt.Paint paint18 = intervalBarRenderer1.getBaseItemLabelPaint();
        boolean boolean19 = textBlock0.equals((java.lang.Object) intervalBarRenderer1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int0 = org.jfree.chart.axis.DateTickUnit.HOUR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray7, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray12);
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 0L, 10.0f, 8.0d, 1.0E-8d, 1.0d, (short) -1 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0L, 10.0f, 8.0d, 1.0E-8d, 1.0d, (short) -1 };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 0L, 10.0f, 8.0d, 1.0E-8d, 1.0d, (short) -1 };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 0L, 10.0f, 8.0d, 1.0E-8d, 1.0d, (short) -1 };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 0L, 10.0f, 8.0d, 1.0E-8d, 1.0d, (short) -1 };
        java.lang.Number[][] numberArray49 = new java.lang.Number[][] { numberArray20, numberArray27, numberArray34, numberArray41, numberArray48 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset50 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[]) strArray0, (java.lang.Comparable[]) strArray1, numberArray12, numberArray49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray49);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        dateAxis16.resizeRange((double) 6);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis24.setAutoRangeStickyZero(false);
        numberAxis24.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, valueAxis29, xYItemRenderer30);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke34 = intervalBarRenderer32.lookupSeriesStroke(3);
        xYPlot31.setDomainGridlineStroke(stroke34);
        java.awt.Stroke stroke36 = xYPlot31.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = xYPlot31.getDomainMarkers(2, layer38);
        xYPlot31.setDomainCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = xYPlot31.getDomainAxisEdge();
        try {
            double double43 = dateAxis16.valueToJava2D((double) (-1.0f), rectangle2D21, rectangleEdge42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0, "hi!", textAnchor2, textAnchor3, (double) 4);
        double double6 = numberTick5.getAngle();
        java.lang.String str7 = numberTick5.getText();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer0.setBaseItemLabelPaint(paint1);
        boolean boolean4 = intervalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean9 = intervalBarRenderer6.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font11 = null;
        intervalBarRenderer6.setSeriesItemLabelFont((int) '4', font11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = intervalBarRenderer6.getPositiveItemLabelPosition(15, (int) (short) 10);
        intervalBarRenderer0.setSeriesNegativeItemLabelPosition(0, itemLabelPosition15);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis4.setAutoRangeStickyZero(false);
        numberAxis4.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer9 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean12 = intervalBarRenderer9.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font14 = null;
        intervalBarRenderer9.setSeriesItemLabelFont((int) '4', font14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener20 = null;
        numberAxis19.addChangeListener(axisChangeListener20);
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        intervalBarRenderer9.drawRangeMarker(graphics2D16, categoryPlot17, (org.jfree.chart.axis.ValueAxis) numberAxis19, marker22, rectangle2D23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer9);
        double double26 = categoryPlot25.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis30.setAutoRangeStickyZero(false);
        numberAxis30.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer35 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean38 = intervalBarRenderer35.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font40 = null;
        intervalBarRenderer35.setSeriesItemLabelFont((int) '4', font40);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = null;
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener46 = null;
        numberAxis45.addChangeListener(axisChangeListener46);
        org.jfree.chart.plot.Marker marker48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        intervalBarRenderer35.drawRangeMarker(graphics2D42, categoryPlot43, (org.jfree.chart.axis.ValueAxis) numberAxis45, marker48, rectangle2D49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer35);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder52 = categoryPlot51.getDatasetRenderingOrder();
        categoryPlot25.setDatasetRenderingOrder(datasetRenderingOrder52);
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot25);
        try {
            org.jfree.chart.title.Title title56 = jFreeChart54.getSubtitle((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder52);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.25d + "'", double0 == 0.25d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        boolean boolean10 = numberAxis2.isAutoTickUnitSelection();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double14 = numberAxis2.java2DToValue(0.0d, rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        double double2 = blockParams0.getTranslateX();
        double double3 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot24);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection30 = categoryPlot24.getDomainMarkers((int) ' ', layer29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryPlot24.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNull(axisSpace31);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot9.getRangeAxisLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = xYPlot9.getInsets();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets16.createOutsetRectangle(rectangle2D17, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        numberAxis1.setTickLabelPaint(paint7);
        numberAxis1.setTickLabelsVisible(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis1.getTickUnit();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(numberTickUnit12);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("({0}, {1}) = {2}", "({0}, {1}) = {2}");
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = rendererState1.getInfo();
        org.junit.Assert.assertNull(plotRenderingInfo2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer0.setBaseItemLabelPaint(paint1);
        boolean boolean4 = intervalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke8 = intervalBarRenderer6.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = intervalBarRenderer6.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer0.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition10);
        java.awt.Shape shape12 = intervalBarRenderer0.getBaseShape();
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray20, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray25);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset26);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity30 = new org.jfree.chart.entity.CategoryItemEntity(shape12, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset26, (java.lang.Comparable) 8.0d, (java.lang.Comparable) 0.0f);
        java.lang.String str31 = categoryItemEntity30.getToolTipText();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        try {
            categoryItemEntity30.setDataset(categoryDataset32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        intervalBarRenderer0.setSeriesItemLabelsVisible((int) (short) 0, false);
        intervalBarRenderer0.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        xYPlot9.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis22.setAutoRangeStickyZero(false);
        double double25 = numberAxis22.getUpperBound();
        xYPlot9.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis22, false);
        java.awt.Paint paint28 = xYPlot9.getRangeZeroBaselinePaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        xYPlot9.setRenderer(35, xYItemRenderer30);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer0.setBaseItemLabelPaint(paint1);
        boolean boolean4 = intervalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        double double5 = intervalBarRenderer0.getLowerClip();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        boolean boolean4 = dateAxis2.equals((java.lang.Object) itemLabelAnchor3);
        org.jfree.chart.axis.Timeline timeline5 = null;
        dateAxis2.setTimeline(timeline5);
        try {
            polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        double double5 = numberAxis2.getUpperBound();
        numberAxis2.setLabelURL("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis8, xYItemRenderer9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis14.setAutoRangeStickyZero(false);
        numberAxis14.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean22 = intervalBarRenderer19.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font24 = null;
        intervalBarRenderer19.setSeriesItemLabelFont((int) '4', font24);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener30 = null;
        numberAxis29.addChangeListener(axisChangeListener30);
        org.jfree.chart.plot.Marker marker32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        intervalBarRenderer19.drawRangeMarker(graphics2D26, categoryPlot27, (org.jfree.chart.axis.ValueAxis) numberAxis29, marker32, rectangle2D33);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer19);
        double double36 = categoryPlot35.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot35.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent38 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection41 = categoryPlot35.getDomainMarkers((int) ' ', layer40);
        java.util.Collection collection42 = xYPlot10.getRangeMarkers(layer40);
        xYPlot10.setDomainGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNull(collection42);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint6 = intervalBarRenderer3.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock7.calculateDimensions(graphics2D8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.awt.Shape shape17 = textBlock7.calculateBounds(graphics2D10, 0.0f, (float) (-1), textBlockAnchor13, (float) (byte) -1, 2.0f, (double) (short) 0);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick23 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0, "hi!", textAnchor20, textAnchor21, (double) 4);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType25 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition27 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor13, textAnchor21, (double) '#', categoryLabelWidthType25, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor21);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX((double) 4);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot24.getOrientation();
        java.lang.String str31 = plotOrientation30.toString();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "PlotOrientation.VERTICAL" + "'", str31.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        boolean boolean25 = intervalBarRenderer8.getBaseSeriesVisibleInLegend();
        boolean boolean26 = intervalBarRenderer8.getAutoPopulateSeriesShape();
        java.awt.Shape shape29 = intervalBarRenderer8.getItemShape((int) (short) 100, 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset30 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent34 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset30, jFreeChart31, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean36 = defaultBoxAndWhiskerCategoryDataset30.equals((java.lang.Object) paintArray35);
        org.jfree.data.Range range37 = intervalBarRenderer8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30);
        int int38 = intervalBarRenderer8.getColumnCount();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double[] doubleArray2 = new double[] { 96, 10 };
        double[] doubleArray5 = new double[] { 96, 10 };
        double[][] doubleArray6 = new double[][] { doubleArray2, doubleArray5 };
        double[] doubleArray8 = new double[] { 100L };
        double[] doubleArray10 = new double[] { 100L };
        double[][] doubleArray11 = new double[][] { doubleArray8, doubleArray10 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset12 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray6, doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of categories in the start value dataset does not match the number of categories in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        xYPlot9.setRangeGridlinesVisible(false);
        boolean boolean20 = xYPlot9.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        try {
            xYPlot9.setDomainAxisLocation(axisLocation21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer25 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        double double26 = boxAndWhiskerRenderer25.getItemMargin();
        java.awt.Stroke stroke28 = boxAndWhiskerRenderer25.lookupSeriesStroke((int) ' ');
        boolean boolean29 = intervalBarRenderer8.equals((java.lang.Object) stroke28);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.2d + "'", double26 == 0.2d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        boolean boolean25 = intervalBarRenderer8.getBaseSeriesVisibleInLegend();
        boolean boolean26 = intervalBarRenderer8.getAutoPopulateSeriesShape();
        java.awt.Shape shape29 = intervalBarRenderer8.getItemShape((int) (short) 100, 10);
        intervalBarRenderer8.setMinimumBarLength((double) 0.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("TextAnchor.BASELINE_CENTER");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "({0}, {1}) = {2}", "", "hi!");
        java.lang.String str8 = projectInfo7.getInfo();
        projectInfo7.setVersion("Category Plot");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) 100);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        java.awt.Paint paint30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot24.setRangeGridlinePaint(paint30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis35.setAutoRangeStickyZero(false);
        numberAxis35.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer40 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean43 = intervalBarRenderer40.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font45 = null;
        intervalBarRenderer40.setSeriesItemLabelFont((int) '4', font45);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = null;
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener51 = null;
        numberAxis50.addChangeListener(axisChangeListener51);
        org.jfree.chart.plot.Marker marker53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        intervalBarRenderer40.drawRangeMarker(graphics2D47, categoryPlot48, (org.jfree.chart.axis.ValueAxis) numberAxis50, marker53, rectangle2D54);
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis35, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer40);
        double double57 = categoryPlot56.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation58 = categoryPlot56.getDomainAxisLocation();
        org.jfree.data.Range range59 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint61 = new org.jfree.chart.block.RectangleConstraint(range59, (double) (byte) -1);
        boolean boolean62 = axisLocation58.equals((java.lang.Object) range59);
        categoryPlot24.setRangeAxisLocation(axisLocation58);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = categoryPlot24.getRenderer(100);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(categoryItemRenderer65);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) 10, (java.lang.Number) 2, (java.lang.Number) 1.0E-8d, (java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 10L, (java.lang.Number) (short) 100, (java.lang.Number) 15, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMedian();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2 + "'", number10.equals(2));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 96);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setWeight(10);
        xYPlot9.setRangeCrosshairValue((double) 4, true);
        java.awt.geom.Point2D point2D23 = null;
        try {
            xYPlot9.setQuadrantOrigin(point2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setDomainCrosshairVisible(false);
        xYPlot9.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot9.getRangeAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = null;
        try {
            xYPlot9.setOrientation(plotOrientation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNull(valueAxis22);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.awt.Paint paint0 = null;
        java.awt.Stroke stroke1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat8 = numberAxis3.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis3.getTickLabelInsets();
        try {
            org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder(paint0, stroke1, rectangleInsets9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer2.setBaseItemLabelPaint(paint3);
        boolean boolean6 = intervalBarRenderer2.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer2.setBaseItemLabelFont(font7, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font7, (java.awt.Paint) color10);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font7);
        labelBlock12.setID("Category Plot");
        java.awt.Paint paint15 = labelBlock12.getPaint();
        java.lang.String str16 = labelBlock12.getToolTipText();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = piePlot1.getLegendItems();
        int int4 = legendItemCollection3.getItemCount();
        try {
            org.jfree.chart.LegendItem legendItem6 = legendItemCollection3.get(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke(6);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) "PlotOrientation.VERTICAL");
        java.util.List list2 = keyToGroupMap1.getGroups();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat6 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis1.getTickLabelInsets();
        double double9 = rectangleInsets7.calculateBottomOutset((double) (short) 100);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = xYPlot9.getDatasetRenderingOrder();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis20.setAutoRangeStickyZero(false);
        numberAxis20.setAutoRangeStickyZero(false);
        boolean boolean26 = numberAxis20.equals((java.lang.Object) (byte) 10);
        boolean boolean27 = datasetRenderingOrder18.equals((java.lang.Object) boolean26);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) 10, (java.lang.Number) 2, (java.lang.Number) 1.0E-8d, (java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 10L, (java.lang.Number) (short) 100, (java.lang.Number) 15, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMaxRegularValue();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10L + "'", number10.equals(10L));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        boolean boolean25 = intervalBarRenderer8.getBaseSeriesVisibleInLegend();
        boolean boolean26 = intervalBarRenderer8.getAutoPopulateSeriesShape();
        java.awt.Shape shape29 = intervalBarRenderer8.getItemShape((int) (short) 100, 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset30 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent34 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset30, jFreeChart31, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean36 = defaultBoxAndWhiskerCategoryDataset30.equals((java.lang.Object) paintArray35);
        org.jfree.data.Range range37 = intervalBarRenderer8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30);
        try {
            java.util.List list40 = defaultBoxAndWhiskerCategoryDataset30.getOutliers(255, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 1L);
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        boolean boolean3 = keyToGroupMap1.equals((java.lang.Object) font2);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        int int0 = org.jfree.chart.axis.DateTickUnit.MILLISECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer1.setBaseItemLabelPaint(paint2);
        boolean boolean5 = intervalBarRenderer1.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer1.setBaseItemLabelFont(font6, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font6, (java.awt.Paint) color9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint19 = intervalBarRenderer16.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, paint19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.util.Size2D size2D22 = textBlock20.calculateDimensions(graphics2D21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor26 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.awt.Shape shape30 = textBlock20.calculateBounds(graphics2D23, 0.0f, (float) (-1), textBlockAnchor26, (float) (byte) -1, 2.0f, (double) (short) 0);
        try {
            textBlock10.draw(graphics2D11, (float) '4', 0.0f, textBlockAnchor26, (float) ' ', (float) (-1), (double) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertNotNull(textBlockAnchor26);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean1 = outlierListCollection0.isLowFarOut();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Number number2 = null;
        defaultKeyedValues0.addValue((java.lang.Comparable) 8.0d, number2);
        defaultKeyedValues0.clear();
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke1 = intervalBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = intervalBarRenderer0.getSeriesItemLabelGenerator((int) (short) 10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = intervalBarRenderer0.getSeriesURLGenerator(1);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNull(categoryURLGenerator5);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer2.setBaseItemLabelPaint(paint3);
        boolean boolean6 = intervalBarRenderer2.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer2.setBaseItemLabelFont(font7, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font7, (java.awt.Paint) color10);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font7);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            labelBlock12.setBounds(rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textBlock11);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint5 = intervalBarRenderer2.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textBlock6.calculateDimensions(graphics2D7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.awt.Shape shape16 = textBlock6.calculateBounds(graphics2D9, 0.0f, (float) (-1), textBlockAnchor12, (float) (byte) -1, 2.0f, (double) (short) 0);
        java.util.List list17 = textBlock6.getLines();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
        java.lang.String str10 = projectInfo7.getInfo();
        org.jfree.chart.ui.Library[] libraryArray11 = projectInfo7.getOptionalLibraries();
        java.awt.Image image15 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo19 = new org.jfree.chart.ui.ProjectInfo("", "", "", image15, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image20 = null;
        projectInfo19.setLogo(image20);
        java.lang.String str22 = projectInfo19.getInfo();
        org.jfree.chart.ui.Library[] libraryArray23 = projectInfo19.getOptionalLibraries();
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo19);
        org.jfree.chart.ui.Library library29 = new org.jfree.chart.ui.Library("hi!", "hi!", "", "Category Plot");
        projectInfo19.addLibrary(library29);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(libraryArray11);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(libraryArray23);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        double double4 = numberAxis1.getUpperBound();
        org.jfree.data.Range range5 = numberAxis1.getDefaultAutoRange();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis8.setAutoRangeStickyZero(false);
        numberAxis8.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis8, valueAxis13, xYItemRenderer14);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke18 = intervalBarRenderer16.lookupSeriesStroke(3);
        xYPlot15.setDomainGridlineStroke(stroke18);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot15.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot15.getRangeAxisEdge();
        boolean boolean25 = numberAxis1.equals((java.lang.Object) xYPlot15);
        numberAxis1.setPositiveArrowVisible(true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(12.0d, (double) (-1));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) categoryLabelPosition3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = categoryLabelPositions6.getLabelPosition(rectangleEdge7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge12);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = categoryLabelPositions11.getLabelPosition(rectangleEdge12);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition3, categoryLabelPosition9, categoryLabelPosition14, categoryLabelPosition15);
        float float17 = categoryLabelPosition3.getWidthRatio();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(categoryLabelPosition9);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(categoryLabelPosition14);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.95f + "'", float17 == 0.95f);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 1, (double) (-2208960000000L));
        size2D2.setWidth((double) (short) -1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer2.setBaseItemLabelPaint(paint3);
        boolean boolean6 = intervalBarRenderer2.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer2.setBaseItemLabelFont(font7, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font7, (java.awt.Paint) color10);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font7);
        labelBlock12.setID("Category Plot");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        java.awt.Paint paint17 = stackedBarRenderer3D16.getWallPaint();
        labelBlock12.setPaint(paint17);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer24 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint27 = intervalBarRenderer24.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("", font23, paint27);
        org.jfree.chart.text.TextFragment textFragment30 = new org.jfree.chart.text.TextFragment("hi!", font21, paint27, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer39 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint42 = intervalBarRenderer39.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.block.BlockBorder blockBorder43 = new org.jfree.chart.block.BlockBorder((double) (short) 1, (double) 1, (double) 10, (double) 0, paint42);
        java.awt.Paint paint44 = blockBorder43.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder45 = new org.jfree.chart.block.BlockBorder(1.0d, 0.2d, Double.NaN, (double) 100.0f, paint44);
        org.jfree.chart.text.TextMeasurer textMeasurer47 = null;
        org.jfree.chart.text.TextBlock textBlock48 = org.jfree.chart.text.TextUtilities.createTextBlock("", font21, paint44, 0.0f, textMeasurer47);
        labelBlock12.setPaint(paint44);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(textBlock28);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(textBlock48);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        boolean boolean4 = intervalBarRenderer0.getBaseSeriesVisibleInLegend();
        double double5 = intervalBarRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setAutoRangeStickyZero(false);
        boolean boolean7 = numberAxis1.equals((java.lang.Object) (byte) 10);
        double double8 = numberAxis1.getUpperBound();
        boolean boolean9 = numberAxis1.isPositiveArrowVisible();
        boolean boolean10 = numberAxis1.isAutoRange();
        double double11 = numberAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.text.AttributedString attributedString0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis7.setAutoRangeStickyZero(false);
        numberAxis7.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean15 = intervalBarRenderer12.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font17 = null;
        intervalBarRenderer12.setSeriesItemLabelFont((int) '4', font17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener23 = null;
        numberAxis22.addChangeListener(axisChangeListener23);
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        intervalBarRenderer12.drawRangeMarker(graphics2D19, categoryPlot20, (org.jfree.chart.axis.ValueAxis) numberAxis22, marker25, rectangle2D26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer12);
        boolean boolean29 = intervalBarRenderer12.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape32 = intervalBarRenderer12.getItemShape((int) (byte) 0, (int) ' ');
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape32, 0.0d, 0.0d);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer36 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke38 = intervalBarRenderer36.lookupSeriesStroke(3);
        java.awt.Paint paint39 = null;
        try {
            org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem(attributedString0, "", "", "hi!", shape32, stroke38, paint39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        boolean boolean25 = intervalBarRenderer8.getBaseSeriesVisibleInLegend();
        boolean boolean26 = intervalBarRenderer8.getAutoPopulateSeriesShape();
        java.awt.Shape shape29 = intervalBarRenderer8.getItemShape((int) (short) 100, 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset30 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent34 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset30, jFreeChart31, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean36 = defaultBoxAndWhiskerCategoryDataset30.equals((java.lang.Object) paintArray35);
        org.jfree.data.Range range37 = intervalBarRenderer8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30);
        org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30, (java.lang.Comparable) 10);
        try {
            java.util.List list42 = defaultBoxAndWhiskerCategoryDataset30.getOutliers(96, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 96, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(pieDataset39);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat7 = numberAxis2.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis2.getTickLabelInsets();
        waferMapPlot0.setInsets(rectangleInsets8);
        java.lang.String str10 = waferMapPlot0.getPlotType();
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "WMAP_Plot" + "'", str10.equals("WMAP_Plot"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer1 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer1.setBaseItemLabelPaint(paint2);
        boolean boolean5 = intervalBarRenderer1.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer1.setBaseItemLabelFont(font6, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font6, (java.awt.Paint) color9);
        int int11 = color9.getAlpha();
        int int12 = color9.getGreen();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 128 + "'", int12 == 128);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke4 = intervalBarRenderer3.getBaseOutlineStroke();
        stackedBarRenderer3D1.setSeriesOutlineStroke((int) (short) 10, stroke4);
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setDomainCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot9.getDomainAxisEdge();
        java.lang.Object obj21 = xYPlot9.clone();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot24.zoomRangeAxes(0.0d, (double) 4, plotRenderingInfo28, point2D29);
        categoryPlot24.mapDatasetToRangeAxis((int) '4', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 10.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        boolean boolean25 = intervalBarRenderer8.getBaseSeriesVisibleInLegend();
        boolean boolean26 = intervalBarRenderer8.getAutoPopulateSeriesShape();
        java.awt.Shape shape29 = intervalBarRenderer8.getItemShape((int) (short) 100, 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset30 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent34 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset30, jFreeChart31, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean36 = defaultBoxAndWhiskerCategoryDataset30.equals((java.lang.Object) paintArray35);
        org.jfree.data.Range range37 = intervalBarRenderer8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30);
        org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30, (java.lang.Comparable) 10);
        org.jfree.data.general.PieDataset pieDataset42 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset39, (java.lang.Comparable) 0.05d, 0.25d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(pieDataset39);
        org.junit.Assert.assertNotNull(pieDataset42);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        layeredBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = layeredBarRenderer0.getLegendItemURLGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer5 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis11.setAutoRangeStickyZero(false);
        numberAxis11.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean19 = intervalBarRenderer16.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font21 = null;
        intervalBarRenderer16.setSeriesItemLabelFont((int) '4', font21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener27 = null;
        numberAxis26.addChangeListener(axisChangeListener27);
        org.jfree.chart.plot.Marker marker29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        intervalBarRenderer16.drawRangeMarker(graphics2D23, categoryPlot24, (org.jfree.chart.axis.ValueAxis) numberAxis26, marker29, rectangle2D30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer16);
        double double33 = categoryPlot32.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getDomainAxisLocation();
        java.awt.Paint paint35 = categoryPlot32.getNoDataMessagePaint();
        categoryPlot32.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation38 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState41 = boxAndWhiskerRenderer5.initialise(graphics2D6, rectangle2D7, categoryPlot32, (int) (short) -1, plotRenderingInfo40);
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis46.setAutoRangeStickyZero(false);
        numberAxis46.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer51 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean54 = intervalBarRenderer51.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font56 = null;
        intervalBarRenderer51.setSeriesItemLabelFont((int) '4', font56);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = null;
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener62 = null;
        numberAxis61.addChangeListener(axisChangeListener62);
        org.jfree.chart.plot.Marker marker64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        intervalBarRenderer51.drawRangeMarker(graphics2D58, categoryPlot59, (org.jfree.chart.axis.ValueAxis) numberAxis61, marker64, rectangle2D65);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) numberAxis46, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer51);
        double double68 = categoryPlot67.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation69 = categoryPlot67.getDomainAxisLocation();
        java.awt.Paint paint70 = categoryPlot67.getNoDataMessagePaint();
        categoryPlot67.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation73 = categoryPlot67.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit78 = new org.jfree.chart.axis.NumberTickUnit((double) ' ');
        numberAxis76.setTickUnit(numberTickUnit78, true, true);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset82 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            layeredBarRenderer0.drawItem(graphics2D4, categoryItemRendererState41, rectangle2D42, categoryPlot67, categoryAxis74, (org.jfree.chart.axis.ValueAxis) numberAxis76, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset82, (-1), 15, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(plotOrientation38);
        org.junit.Assert.assertNotNull(categoryItemRendererState41);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation69);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(plotOrientation73);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        java.awt.Paint paint30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot24.setRangeGridlinePaint(paint30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis34.setAutoRangeStickyZero(false);
        numberAxis34.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) numberAxis34, valueAxis39, xYItemRenderer40);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer42 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke44 = intervalBarRenderer42.lookupSeriesStroke(3);
        xYPlot41.setDomainGridlineStroke(stroke44);
        java.awt.Stroke stroke46 = xYPlot41.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation47 = xYPlot41.getRangeAxisLocation();
        categoryPlot24.setDomainAxisLocation(axisLocation47, true);
        categoryPlot24.setRangeGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(axisLocation47);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setWeight(10);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot9.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(12.0d, (double) (-1));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) categoryLabelPosition3);
        java.awt.Paint paint5 = stackedBarRenderer3D2.getWallPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot24.setRangeAxisLocation(axisLocation26, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis31.setAutoRangeStickyZero(false);
        numberAxis31.setAutoRangeStickyZero(false);
        categoryPlot24.setRangeAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) numberAxis31, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot24.getDomainAxis();
        org.jfree.data.category.CategoryDataset categoryDataset39 = categoryPlot24.getDataset();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryAxis38);
        org.junit.Assert.assertNull(categoryDataset39);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot24.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNull(legendItemCollection26);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = piePlot1.getLegendItems();
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        java.lang.Object obj7 = intervalMarker6.clone();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis11.setAutoRangeStickyZero(false);
        numberAxis11.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean19 = intervalBarRenderer16.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font21 = null;
        intervalBarRenderer16.setSeriesItemLabelFont((int) '4', font21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener27 = null;
        numberAxis26.addChangeListener(axisChangeListener27);
        org.jfree.chart.plot.Marker marker29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        intervalBarRenderer16.drawRangeMarker(graphics2D23, categoryPlot24, (org.jfree.chart.axis.ValueAxis) numberAxis26, marker29, rectangle2D30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer16);
        intervalMarker6.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot32);
        java.awt.Paint paint34 = intervalMarker6.getOutlinePaint();
        java.awt.Paint paint35 = intervalMarker6.getPaint();
        boolean boolean36 = piePlot1.equals((java.lang.Object) intervalMarker6);
        try {
            double double37 = piePlot1.getMaximumExplodePercent();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 100, (float) (short) 100, (float) (byte) 0);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            piePlot1.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        boolean boolean25 = intervalBarRenderer8.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape28 = intervalBarRenderer8.getItemShape((int) (byte) 0, (int) ' ');
        double double29 = intervalBarRenderer8.getBase();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean6 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) paintArray5);
        org.jfree.data.general.DatasetGroup datasetGroup8 = new org.jfree.data.general.DatasetGroup("hi!");
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup8);
        try {
            java.util.List list12 = defaultBoxAndWhiskerCategoryDataset0.getOutliers(4, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        java.awt.Color color1 = java.awt.Color.PINK;
        layeredBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color1);
        java.lang.String str3 = org.jfree.chart.util.PaintUtilities.colorToString(color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "pink" + "'", str3.equals("pink"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        segmentedTimeline0.addException(0L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int5 = segmentedTimeline4.getSegmentsExcluded();
        segmentedTimeline0.setBaseTimeline(segmentedTimeline4);
        int int7 = segmentedTimeline0.getSegmentsExcluded();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 68 + "'", int5 == 68);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 68 + "'", int7 == 68);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.95f, (float) 900000L, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = intervalBarRenderer0.getItemFillPaint(100, (int) 'a');
        intervalBarRenderer0.setMaximumBarWidth((double) 1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.Color color0 = java.awt.Color.magenta;
        java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "magenta" + "'", str1.equals("magenta"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "", font2);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (byte) 0);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            org.jfree.chart.axis.AxisState axisState12 = categoryAxis0.draw(graphics2D6, 0.0d, rectangle2D8, rectangle2D9, rectangleEdge10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        double double18 = dateAxis16.getLabelAngle();
        dateAxis16.setLabelAngle((double) (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Number number2 = null;
        defaultKeyedValues0.addValue((java.lang.Comparable) 8.0d, number2);
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer4 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boolean boolean5 = defaultKeyedValues0.equals((java.lang.Object) boxAndWhiskerRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer7 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis13.setAutoRangeStickyZero(false);
        numberAxis13.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean21 = intervalBarRenderer18.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font23 = null;
        intervalBarRenderer18.setSeriesItemLabelFont((int) '4', font23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener29 = null;
        numberAxis28.addChangeListener(axisChangeListener29);
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        intervalBarRenderer18.drawRangeMarker(graphics2D25, categoryPlot26, (org.jfree.chart.axis.ValueAxis) numberAxis28, marker31, rectangle2D32);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer18);
        double double35 = categoryPlot34.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation36 = categoryPlot34.getDomainAxisLocation();
        java.awt.Paint paint37 = categoryPlot34.getNoDataMessagePaint();
        categoryPlot34.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = categoryPlot34.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState43 = boxAndWhiskerRenderer7.initialise(graphics2D8, rectangle2D9, categoryPlot34, (int) (short) -1, plotRenderingInfo42);
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener49 = null;
        numberAxis48.addChangeListener(axisChangeListener49);
        double double51 = numberAxis48.getLabelAngle();
        numberAxis48.setUpperMargin((double) (byte) 10);
        java.lang.Number[] numberArray59 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray63 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray64 = new java.lang.Number[][] { numberArray59, numberArray63 };
        org.jfree.data.category.CategoryDataset categoryDataset65 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray64);
        org.jfree.data.Range range66 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset65);
        try {
            boxAndWhiskerRenderer4.drawHorizontalItem(graphics2D6, categoryItemRendererState43, rectangle2D44, categoryPlot45, categoryAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis48, categoryDataset65, (int) (byte) -1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.category.DefaultCategoryDataset cannot be cast to org.jfree.data.statistics.BoxAndWhiskerCategoryDataset");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertNotNull(categoryItemRendererState43);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(numberArray64);
        org.junit.Assert.assertNotNull(categoryDataset65);
        org.junit.Assert.assertNotNull(range66);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        numberAxis1.addChangeListener(axisChangeListener2);
        java.lang.Class<?> wildcardClass4 = numberAxis1.getClass();
        boolean boolean5 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass4);
        java.lang.ClassLoader classLoader6 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        java.util.ResourceBundle.clearCache(classLoader6);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(classLoader6);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        java.lang.Comparable comparable5 = null;
        java.lang.Comparable comparable6 = null;
        java.lang.Number number7 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(comparable5, comparable6);
        try {
            java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(2958465, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean6 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) paintArray5);
        java.text.DateFormat dateFormat11 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat11);
        boolean boolean14 = dateTickUnit12.equals((java.lang.Object) (short) -1);
        int int15 = defaultBoxAndWhiskerCategoryDataset0.getColumnIndex((java.lang.Comparable) boolean14);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer2.setBaseItemLabelPaint(paint3);
        boolean boolean6 = intervalBarRenderer2.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer2.setBaseItemLabelFont(font7, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font7, (java.awt.Paint) color10);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font7);
        labelBlock12.setID("Category Plot");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        java.awt.Paint paint17 = stackedBarRenderer3D16.getWallPaint();
        labelBlock12.setPaint(paint17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.data.Range range20 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint(range20, (double) (byte) -1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType23 = rectangleConstraint22.getHeightConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D24 = labelBlock12.arrange(graphics2D19, rectangleConstraint22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(lengthConstraintType23);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot9.getRangeAxisLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = xYPlot9.getInsets();
        java.awt.Paint paint17 = null;
        try {
            xYPlot9.setDomainZeroBaselinePaint(paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer0.setBaseItemLabelPaint(paint1);
        boolean boolean4 = intervalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke8 = intervalBarRenderer6.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = intervalBarRenderer6.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer0.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition10);
        java.awt.Shape shape12 = intervalBarRenderer0.getBaseShape();
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray20, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray25);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset26);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity30 = new org.jfree.chart.entity.CategoryItemEntity(shape12, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset26, (java.lang.Comparable) 8.0d, (java.lang.Comparable) 0.0f);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset26);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis4.setAutoRangeStickyZero(false);
        numberAxis4.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer9 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean12 = intervalBarRenderer9.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font14 = null;
        intervalBarRenderer9.setSeriesItemLabelFont((int) '4', font14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener20 = null;
        numberAxis19.addChangeListener(axisChangeListener20);
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        intervalBarRenderer9.drawRangeMarker(graphics2D16, categoryPlot17, (org.jfree.chart.axis.ValueAxis) numberAxis19, marker22, rectangle2D23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer9);
        double double26 = categoryPlot25.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis30.setAutoRangeStickyZero(false);
        numberAxis30.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer35 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean38 = intervalBarRenderer35.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font40 = null;
        intervalBarRenderer35.setSeriesItemLabelFont((int) '4', font40);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = null;
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener46 = null;
        numberAxis45.addChangeListener(axisChangeListener46);
        org.jfree.chart.plot.Marker marker48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        intervalBarRenderer35.drawRangeMarker(graphics2D42, categoryPlot43, (org.jfree.chart.axis.ValueAxis) numberAxis45, marker48, rectangle2D49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer35);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder52 = categoryPlot51.getDatasetRenderingOrder();
        categoryPlot25.setDatasetRenderingOrder(datasetRenderingOrder52);
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot25);
        org.jfree.chart.title.Title title55 = null;
        try {
            jFreeChart54.addSubtitle(title55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder52);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        java.lang.Object obj3 = defaultKeyedValues2D1.clone();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = intervalBarRenderer0.getSeriesURLGenerator((int) '#');
        java.lang.Boolean boolean7 = intervalBarRenderer0.getSeriesVisible(96);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.plot.Plot plot1 = waferMapPlot0.getRootPlot();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            waferMapPlot0.drawBackground(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plot1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setIgnoreZeroValues(true);
        double double5 = piePlot1.getExplodePercent((java.lang.Comparable) 0L);
        java.awt.Stroke stroke7 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(stroke7);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setDomainCrosshairVisible(false);
        xYPlot9.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot9.getRangeAxis();
        xYPlot9.setNoDataMessage("");
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNull(valueAxis22);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint8 = intervalBarRenderer5.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, paint8);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!", font2, paint8, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean15 = intervalBarRenderer12.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font17 = null;
        intervalBarRenderer12.setSeriesItemLabelFont((int) '4', font17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener23 = null;
        numberAxis22.addChangeListener(axisChangeListener23);
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        intervalBarRenderer12.drawRangeMarker(graphics2D19, categoryPlot20, (org.jfree.chart.axis.ValueAxis) numberAxis22, marker25, rectangle2D26);
        boolean boolean28 = textFragment11.equals((java.lang.Object) graphics2D19);
        java.awt.Font font29 = textFragment11.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis33.setAutoRangeStickyZero(false);
        numberAxis33.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer38 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean41 = intervalBarRenderer38.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font43 = null;
        intervalBarRenderer38.setSeriesItemLabelFont((int) '4', font43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener49 = null;
        numberAxis48.addChangeListener(axisChangeListener49);
        org.jfree.chart.plot.Marker marker51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        intervalBarRenderer38.drawRangeMarker(graphics2D45, categoryPlot46, (org.jfree.chart.axis.ValueAxis) numberAxis48, marker51, rectangle2D52);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer38);
        org.jfree.chart.JFreeChart jFreeChart56 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", font29, (org.jfree.chart.plot.Plot) categoryPlot54, false);
        org.jfree.chart.title.Title title57 = null;
        try {
            jFreeChart56.addSubtitle(title57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textBlock9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean6 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) paintArray5);
        org.jfree.data.general.DatasetGroup datasetGroup8 = new org.jfree.data.general.DatasetGroup("hi!");
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup8);
        boolean boolean11 = datasetGroup8.equals((java.lang.Object) 1.0d);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot24.rendererChanged(rendererChangeEvent30);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot24);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer34.setBaseItemLabelPaint(paint35);
        boolean boolean38 = intervalBarRenderer34.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer34.setBaseItemLabelFont(font39, false);
        categoryPlot24.setRenderer((int) (short) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer34, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot24.getDomainAxisEdge(35);
        org.jfree.chart.plot.IntervalMarker intervalMarker49 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        java.lang.Object obj50 = intervalMarker49.clone();
        java.lang.String str51 = intervalMarker49.getLabel();
        org.jfree.data.category.CategoryDataset categoryDataset52 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis55.setAutoRangeStickyZero(false);
        numberAxis55.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer60 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean63 = intervalBarRenderer60.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font65 = null;
        intervalBarRenderer60.setSeriesItemLabelFont((int) '4', font65);
        java.awt.Graphics2D graphics2D67 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = null;
        org.jfree.chart.axis.NumberAxis numberAxis70 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener71 = null;
        numberAxis70.addChangeListener(axisChangeListener71);
        org.jfree.chart.plot.Marker marker73 = null;
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        intervalBarRenderer60.drawRangeMarker(graphics2D67, categoryPlot68, (org.jfree.chart.axis.ValueAxis) numberAxis70, marker73, rectangle2D74);
        org.jfree.chart.plot.CategoryPlot categoryPlot76 = new org.jfree.chart.plot.CategoryPlot(categoryDataset52, categoryAxis53, (org.jfree.chart.axis.ValueAxis) numberAxis55, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer60);
        double double77 = categoryPlot76.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation78 = categoryPlot76.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent79 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot76);
        org.jfree.chart.util.Layer layer81 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection82 = categoryPlot76.getDomainMarkers((int) ' ', layer81);
        categoryPlot24.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) intervalMarker49, layer81);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation78);
        org.junit.Assert.assertNotNull(layer81);
        org.junit.Assert.assertNull(collection82);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke4 = intervalBarRenderer3.getBaseOutlineStroke();
        stackedBarRenderer3D1.setSeriesOutlineStroke((int) (short) 10, stroke4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedBarRenderer3D1.setSeriesPaint((int) '#', (java.awt.Paint) color7);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D10 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D10.removeColumn((java.lang.Comparable) (short) -1);
        defaultKeyedValues2D10.removeColumn((java.lang.Comparable) 255);
        boolean boolean15 = stackedBarRenderer3D1.equals((java.lang.Object) 255);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        xYPlot9.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis22.setAutoRangeStickyZero(false);
        double double25 = numberAxis22.getUpperBound();
        xYPlot9.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis22, false);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot28 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis30.setAutoRangeStickyZero(false);
        numberAxis30.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat35 = numberAxis30.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = numberAxis30.getTickLabelInsets();
        waferMapPlot28.setInsets(rectangleInsets36);
        xYPlot9.setAxisOffset(rectangleInsets36);
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        java.lang.Object obj43 = intervalMarker42.clone();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = intervalMarker42.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType45 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets36.createAdjustedRectangle(rectangle2D39, lengthAdjustmentType44, lengthAdjustmentType45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNull(numberFormat35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNotNull(lengthAdjustmentType44);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str3 = dateRange2.toString();
        java.util.Date date4 = dateRange2.getLowerDate();
        java.util.Date date5 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod(date4, date5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str3.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj1 = standardCategorySeriesLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        numberAxis1.setTickLabelPaint(paint7);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis16.setAutoRangeStickyZero(false);
        numberAxis16.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean24 = intervalBarRenderer21.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font26 = null;
        intervalBarRenderer21.setSeriesItemLabelFont((int) '4', font26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener32 = null;
        numberAxis31.addChangeListener(axisChangeListener32);
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        intervalBarRenderer21.drawRangeMarker(graphics2D28, categoryPlot29, (org.jfree.chart.axis.ValueAxis) numberAxis31, marker34, rectangle2D35);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer21);
        categoryPlot37.configureRangeAxes();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        org.jfree.chart.axis.AxisSpace axisSpace42 = numberAxis1.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) categoryPlot37, rectangle2D39, rectangleEdge40, axisSpace41);
        categoryPlot37.clearAnnotations();
        int int44 = categoryPlot37.getDomainAxisCount();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(axisSpace42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 1L);
        int int2 = keyToGroupMap1.getGroupCount();
        java.lang.Object obj3 = keyToGroupMap1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) 10, (java.lang.Number) 2, (java.lang.Number) 1.0E-8d, (java.lang.Number) 100.0d, (java.lang.Number) (byte) 10, (java.lang.Number) 10L, (java.lang.Number) (short) 100, (java.lang.Number) 15, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getQ3();
        java.lang.Number number11 = boxAndWhiskerItem9.getMean();
        java.util.List list12 = boxAndWhiskerItem9.getOutliers();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0d + "'", number10.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 10 + "'", number11.equals((byte) 10));
        org.junit.Assert.assertNull(list12);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = categoryPlot24.getDatasetRenderingOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot24.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertNotNull(legendItemCollection26);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        xYPlot9.setDomainAxisLocation((int) '#', axisLocation21);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis24.setAutoRangeStickyZero(false);
        xYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis24);
        org.jfree.chart.axis.TickUnitSource tickUnitSource28 = numberAxis24.getStandardTickUnits();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(tickUnitSource28);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(255, (int) '4', 10, 10, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.Point2D point2D27 = null;
        org.jfree.chart.plot.PlotState plotState28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        try {
            categoryPlot24.draw(graphics2D25, rectangle2D26, point2D27, plotState28, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Comparable[] comparableArray1 = null;
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[]) strArray0, comparableArray1, doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        segmentedTimeline0.setAdjustForDaylightSaving(true);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint5 = intervalBarRenderer2.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textBlock6.calculateDimensions(graphics2D7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.awt.Shape shape16 = textBlock6.calculateBounds(graphics2D9, 0.0f, (float) 10, textBlockAnchor12, (float) (byte) 100, (float) 25200000L, 0.0d);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = xYPlot9.getRenderer();
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        int int20 = xYPlot9.indexOf(xYDataset19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot9.zoomRangeAxes((double) (-2208960000000L), (double) 'a', plotRenderingInfo23, point2D24);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = null;
        try {
            piePlot1.setDirection(rotation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.NONE" + "'", str1.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Shape shape2 = null;
        intervalBarRenderer0.setSeriesShape(4, shape2, false);
        java.lang.Object obj5 = null;
        boolean boolean6 = intervalBarRenderer0.equals(obj5);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator8 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str9 = standardCategoryToolTipGenerator8.getLabelFormat();
        java.text.DateFormat dateFormat10 = standardCategoryToolTipGenerator8.getDateFormat();
        intervalBarRenderer0.setSeriesToolTipGenerator(178, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator8, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "({0}, {1}) = {2}" + "'", str9.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertNull(dateFormat10);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge2);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = categoryLabelPositions1.getLabelPosition(rectangleEdge2);
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge2);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(categoryLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setAnchorValue((double) 86400000L, false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font5 = null;
        intervalBarRenderer0.setSeriesItemLabelFont((int) '4', font5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener11 = null;
        numberAxis10.addChangeListener(axisChangeListener11);
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        intervalBarRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis10, marker13, rectangle2D14);
        double double16 = numberAxis10.getAutoRangeMinimumSize();
        numberAxis10.setAutoRangeMinimumSize(1.0d, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-8d + "'", double16 == 1.0E-8d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        boolean boolean25 = intervalBarRenderer8.getBaseSeriesVisibleInLegend();
        boolean boolean26 = intervalBarRenderer8.getAutoPopulateSeriesShape();
        java.awt.Shape shape29 = intervalBarRenderer8.getItemShape((int) (short) 100, 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset30 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent34 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset30, jFreeChart31, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean36 = defaultBoxAndWhiskerCategoryDataset30.equals((java.lang.Object) paintArray35);
        org.jfree.data.Range range37 = intervalBarRenderer8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30);
        double double39 = defaultBoxAndWhiskerCategoryDataset30.getRangeUpperBound(true);
        java.lang.Number number42 = defaultBoxAndWhiskerCategoryDataset30.getMinOutlier((java.lang.Comparable) 90.0d, (java.lang.Comparable) 2958465);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNull(number42);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer0.setBaseItemLabelPaint(paint1);
        boolean boolean4 = intervalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke8 = intervalBarRenderer6.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = intervalBarRenderer6.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer0.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition10);
        java.awt.Shape shape12 = intervalBarRenderer0.getBaseShape();
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray20, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray25);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset26);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity30 = new org.jfree.chart.entity.CategoryItemEntity(shape12, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset26, (java.lang.Comparable) 8.0d, (java.lang.Comparable) 0.0f);
        java.lang.String str31 = categoryItemEntity30.toString();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint8 = intervalBarRenderer5.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, paint8);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!", font2, paint8, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean15 = intervalBarRenderer12.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font17 = null;
        intervalBarRenderer12.setSeriesItemLabelFont((int) '4', font17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener23 = null;
        numberAxis22.addChangeListener(axisChangeListener23);
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        intervalBarRenderer12.drawRangeMarker(graphics2D19, categoryPlot20, (org.jfree.chart.axis.ValueAxis) numberAxis22, marker25, rectangle2D26);
        boolean boolean28 = textFragment11.equals((java.lang.Object) graphics2D19);
        java.awt.Font font29 = textFragment11.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis33.setAutoRangeStickyZero(false);
        numberAxis33.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer38 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean41 = intervalBarRenderer38.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font43 = null;
        intervalBarRenderer38.setSeriesItemLabelFont((int) '4', font43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener49 = null;
        numberAxis48.addChangeListener(axisChangeListener49);
        org.jfree.chart.plot.Marker marker51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        intervalBarRenderer38.drawRangeMarker(graphics2D45, categoryPlot46, (org.jfree.chart.axis.ValueAxis) numberAxis48, marker51, rectangle2D52);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer38);
        org.jfree.chart.JFreeChart jFreeChart56 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", font29, (org.jfree.chart.plot.Plot) categoryPlot54, false);
        categoryPlot54.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textBlock9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot24.zoomRangeAxes(0.0d, (double) 4, plotRenderingInfo28, point2D29);
        int int31 = categoryPlot24.getWeight();
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot24.getRowRenderingOrder();
        boolean boolean33 = categoryPlot24.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer37 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke38 = intervalBarRenderer37.getBaseOutlineStroke();
        stackedBarRenderer3D35.setSeriesOutlineStroke((int) (short) 10, stroke38);
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedBarRenderer3D35.setSeriesPaint((int) '#', (java.awt.Paint) color41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = null;
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener47 = null;
        numberAxis46.addChangeListener(axisChangeListener47);
        numberAxis46.setRangeWithMargins((double) (short) -1, (double) (byte) 0);
        org.jfree.chart.plot.IntervalMarker intervalMarker54 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        intervalMarker54.setLabel("hi!");
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        stackedBarRenderer3D35.drawRangeMarker(graphics2D43, categoryPlot44, (org.jfree.chart.axis.ValueAxis) numberAxis46, (org.jfree.chart.plot.Marker) intervalMarker54, rectangle2D57);
        categoryPlot24.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker54);
        double double60 = intervalMarker54.getEndValue();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 97.0d + "'", double60 == 97.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getRadiusGridlinePaint();
        polarPlot0.setAngleLabelsVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) 0, plotRenderingInfo5, point2D6);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0, "hi!", textAnchor8, textAnchor9, (double) 4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5, textAnchor8, (double) (short) -1);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("LengthConstraintType.NONE", graphics2D1, (float) 128, (float) 86400000L, textAnchor8, (double) 2.0f, (float) (-2208960000000L), (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot24.getOrientation();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer31 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke33 = intervalBarRenderer31.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = intervalBarRenderer31.getSeriesPositiveItemLabelPosition((int) '#');
        categoryPlot24.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer31);
        float float37 = categoryPlot24.getBackgroundAlpha();
        java.util.List list38 = categoryPlot24.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot24.getDomainAxisLocation(96);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 1.0f + "'", float37 == 1.0f);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNotNull(axisLocation40);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke1 = intervalBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = intervalBarRenderer0.getSeriesItemLabelGenerator((int) (short) 10);
        intervalBarRenderer0.setBaseSeriesVisible(true);
        java.awt.Color color9 = java.awt.Color.getHSBColor((float) (short) 1, (float) 10L, 10.0f);
        intervalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color9, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke1 = intervalBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        double double6 = numberAxis3.getUpperBound();
        java.awt.Paint paint7 = numberAxis3.getAxisLinePaint();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        boolean boolean10 = numberAxis3.equals((java.lang.Object) 'a');
        boolean boolean11 = intervalBarRenderer0.equals((java.lang.Object) boolean10);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setWeight(10);
        xYPlot9.setRangeCrosshairValue((double) 4, true);
        xYPlot9.setDomainCrosshairValue((double) '4', true);
        xYPlot9.clearRangeMarkers(15);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        boolean boolean25 = intervalBarRenderer8.getBaseSeriesVisibleInLegend();
        boolean boolean26 = intervalBarRenderer8.getAutoPopulateSeriesShape();
        java.awt.Shape shape29 = intervalBarRenderer8.getItemShape((int) (short) 100, 10);
        boolean boolean30 = intervalBarRenderer8.getBaseSeriesVisible();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        boolean boolean25 = intervalBarRenderer8.getBaseSeriesVisibleInLegend();
        boolean boolean26 = intervalBarRenderer8.getAutoPopulateSeriesShape();
        java.awt.Shape shape29 = intervalBarRenderer8.getItemShape((int) (short) 100, 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset30 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent34 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset30, jFreeChart31, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean36 = defaultBoxAndWhiskerCategoryDataset30.equals((java.lang.Object) paintArray35);
        org.jfree.data.Range range37 = intervalBarRenderer8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30);
        double double39 = defaultBoxAndWhiskerCategoryDataset30.getRangeUpperBound(true);
        java.util.List list40 = defaultBoxAndWhiskerCategoryDataset30.getColumnKeys();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list40);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean6 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) paintArray5);
        org.jfree.data.general.DatasetGroup datasetGroup8 = new org.jfree.data.general.DatasetGroup("hi!");
        defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup8);
        double double11 = defaultBoxAndWhiskerCategoryDataset0.getRangeLowerBound(true);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(255);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        categoryPlot24.configureDomainAxes();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        try {
            categoryPlot24.drawBackground(graphics2D28, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        segmentedTimeline0.addException(0L);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0L);
        java.lang.Object obj5 = chartChangeEvent4.getSource();
        java.lang.Object obj6 = chartChangeEvent4.getSource();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 0L + "'", obj5.equals(0L));
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + 0L + "'", obj6.equals(0L));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = categoryPlot24.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis30.setAutoRangeStickyZero(false);
        numberAxis30.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer35 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean38 = intervalBarRenderer35.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font40 = null;
        intervalBarRenderer35.setSeriesItemLabelFont((int) '4', font40);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = null;
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener46 = null;
        numberAxis45.addChangeListener(axisChangeListener46);
        org.jfree.chart.plot.Marker marker48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        intervalBarRenderer35.drawRangeMarker(graphics2D42, categoryPlot43, (org.jfree.chart.axis.ValueAxis) numberAxis45, marker48, rectangle2D49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer35);
        double double52 = categoryPlot51.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation53 = categoryPlot51.getDomainAxisLocation();
        java.awt.Paint paint54 = categoryPlot51.getNoDataMessagePaint();
        categoryPlot51.setRangeCrosshairLockedOnData(false);
        java.awt.Paint paint57 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot51.setRangeGridlinePaint(paint57);
        org.jfree.data.category.CategoryDataset categoryDataset59 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis62.setAutoRangeStickyZero(false);
        numberAxis62.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer67 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean70 = intervalBarRenderer67.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font72 = null;
        intervalBarRenderer67.setSeriesItemLabelFont((int) '4', font72);
        java.awt.Graphics2D graphics2D74 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = null;
        org.jfree.chart.axis.NumberAxis numberAxis77 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener78 = null;
        numberAxis77.addChangeListener(axisChangeListener78);
        org.jfree.chart.plot.Marker marker80 = null;
        java.awt.geom.Rectangle2D rectangle2D81 = null;
        intervalBarRenderer67.drawRangeMarker(graphics2D74, categoryPlot75, (org.jfree.chart.axis.ValueAxis) numberAxis77, marker80, rectangle2D81);
        org.jfree.chart.plot.CategoryPlot categoryPlot83 = new org.jfree.chart.plot.CategoryPlot(categoryDataset59, categoryAxis60, (org.jfree.chart.axis.ValueAxis) numberAxis62, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer67);
        double double84 = categoryPlot83.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation85 = categoryPlot83.getDomainAxisLocation();
        org.jfree.data.Range range86 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint88 = new org.jfree.chart.block.RectangleConstraint(range86, (double) (byte) -1);
        boolean boolean89 = axisLocation85.equals((java.lang.Object) range86);
        categoryPlot51.setRangeAxisLocation(axisLocation85);
        categoryPlot24.setRangeAxisLocation(68, axisLocation85, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker95 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 10);
        java.awt.Stroke stroke96 = intervalMarker95.getOutlineStroke();
        org.jfree.chart.util.Layer layer97 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot24.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker95, layer97);
        java.awt.Paint paint99 = categoryPlot24.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation85);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(stroke96);
        org.junit.Assert.assertNotNull(layer97);
        org.junit.Assert.assertNotNull(paint99);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint5 = intervalBarRenderer2.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textBlock6.calculateDimensions(graphics2D7);
        double double9 = size2D8.getWidth();
        double double10 = size2D8.getHeight();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat4);
        boolean boolean7 = dateTickUnit5.equals((java.lang.Object) (short) -1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int9 = segmentedTimeline8.getSegmentsExcluded();
        long long10 = segmentedTimeline8.getSegmentsGroupSize();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str14 = dateRange13.toString();
        java.util.Date date15 = dateRange13.getLowerDate();
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str19 = dateRange18.toString();
        java.util.Date date20 = dateRange18.getLowerDate();
        boolean boolean21 = segmentedTimeline8.containsDomainRange(date15, date20);
        java.util.TimeZone timeZone22 = null;
        try {
            java.util.Date date23 = dateTickUnit5.rollDate(date20, timeZone22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 68 + "'", int9 == 68);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 86400000L + "'", long10 == 86400000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str14.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str19.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        numberAxis1.addChangeListener(axisChangeListener2);
        java.lang.Class<?> wildcardClass4 = numberAxis1.getClass();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = polarPlot5.getRenderer();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot5);
        org.jfree.data.xy.XYDataset xYDataset8 = polarPlot5.getDataset();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(polarItemRenderer6);
        org.junit.Assert.assertNull(xYDataset8);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke4 = intervalBarRenderer3.getBaseOutlineStroke();
        stackedBarRenderer3D1.setSeriesOutlineStroke((int) (short) 10, stroke4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedBarRenderer3D1.setSeriesPaint((int) '#', (java.awt.Paint) color7);
        java.io.ObjectOutputStream objectOutputStream9 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color7, objectOutputStream9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        java.lang.Object obj1 = null;
        boolean boolean2 = categoryLabelPositions0.equals(obj1);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) '#', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis4.setAutoRangeStickyZero(false);
        numberAxis4.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis9, xYItemRenderer10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke14 = intervalBarRenderer12.lookupSeriesStroke(3);
        xYPlot11.setDomainGridlineStroke(stroke14);
        lineRenderer3D0.setSeriesOutlineStroke(3, stroke14, true);
        lineRenderer3D0.setBaseShapesFilled(false);
        java.lang.Boolean boolean21 = lineRenderer3D0.getSeriesItemLabelsVisible(10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        lineRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator22, false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(boolean21);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection0.setHighFarOut(true);
        boolean boolean3 = outlierListCollection0.isLowFarOut();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment(0L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline3.getSegment(0L);
        boolean boolean6 = segment2.after(segment5);
        boolean boolean9 = segment2.contains((long) (byte) -1, (long) '4');
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryAxis0.setTickMarkStroke(stroke1);
        categoryAxis0.setVisible(true);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint8 = intervalBarRenderer5.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, paint8);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!", font2, paint8, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean15 = intervalBarRenderer12.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font17 = null;
        intervalBarRenderer12.setSeriesItemLabelFont((int) '4', font17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener23 = null;
        numberAxis22.addChangeListener(axisChangeListener23);
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        intervalBarRenderer12.drawRangeMarker(graphics2D19, categoryPlot20, (org.jfree.chart.axis.ValueAxis) numberAxis22, marker25, rectangle2D26);
        boolean boolean28 = textFragment11.equals((java.lang.Object) graphics2D19);
        java.awt.Font font29 = textFragment11.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis33.setAutoRangeStickyZero(false);
        numberAxis33.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer38 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean41 = intervalBarRenderer38.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font43 = null;
        intervalBarRenderer38.setSeriesItemLabelFont((int) '4', font43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener49 = null;
        numberAxis48.addChangeListener(axisChangeListener49);
        org.jfree.chart.plot.Marker marker51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        intervalBarRenderer38.drawRangeMarker(graphics2D45, categoryPlot46, (org.jfree.chart.axis.ValueAxis) numberAxis48, marker51, rectangle2D52);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer38);
        org.jfree.chart.JFreeChart jFreeChart56 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", font29, (org.jfree.chart.plot.Plot) categoryPlot54, false);
        org.jfree.chart.title.LegendTitle legendTitle57 = null;
        try {
            jFreeChart56.addLegend(legendTitle57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textBlock9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) 'a');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot9.getRangeAxisLocation();
        java.util.List list16 = xYPlot9.getAnnotations();
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection18 = xYPlot9.getRangeMarkers(layer17);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation19 = null;
        try {
            xYPlot9.addAnnotation(xYAnnotation19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(collection18);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer5 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint8 = intervalBarRenderer5.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, paint8);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!", font2, paint8, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean15 = intervalBarRenderer12.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font17 = null;
        intervalBarRenderer12.setSeriesItemLabelFont((int) '4', font17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener23 = null;
        numberAxis22.addChangeListener(axisChangeListener23);
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        intervalBarRenderer12.drawRangeMarker(graphics2D19, categoryPlot20, (org.jfree.chart.axis.ValueAxis) numberAxis22, marker25, rectangle2D26);
        boolean boolean28 = textFragment11.equals((java.lang.Object) graphics2D19);
        java.awt.Font font29 = textFragment11.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis33.setAutoRangeStickyZero(false);
        numberAxis33.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer38 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean41 = intervalBarRenderer38.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font43 = null;
        intervalBarRenderer38.setSeriesItemLabelFont((int) '4', font43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener49 = null;
        numberAxis48.addChangeListener(axisChangeListener49);
        org.jfree.chart.plot.Marker marker51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        intervalBarRenderer38.drawRangeMarker(graphics2D45, categoryPlot46, (org.jfree.chart.axis.ValueAxis) numberAxis48, marker51, rectangle2D52);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer38);
        org.jfree.chart.JFreeChart jFreeChart56 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", font29, (org.jfree.chart.plot.Plot) categoryPlot54, false);
        org.jfree.chart.title.Title title58 = null;
        try {
            jFreeChart56.addSubtitle(255, title58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textBlock9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        double double4 = numberAxis1.getUpperBound();
        double double5 = numberAxis1.getUpperBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        intervalBarRenderer0.setSeriesItemLabelsVisible((int) (short) 0, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = intervalBarRenderer0.getNegativeItemLabelPosition((int) '#', 0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = itemLabelPosition9.getItemLabelAnchor();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) '4', (float) 1, 0.0d, (float) '#', (-1.0f));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        java.lang.Object obj3 = intervalMarker2.clone();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis7.setAutoRangeStickyZero(false);
        numberAxis7.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean15 = intervalBarRenderer12.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font17 = null;
        intervalBarRenderer12.setSeriesItemLabelFont((int) '4', font17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener23 = null;
        numberAxis22.addChangeListener(axisChangeListener23);
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        intervalBarRenderer12.drawRangeMarker(graphics2D19, categoryPlot20, (org.jfree.chart.axis.ValueAxis) numberAxis22, marker25, rectangle2D26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer12);
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot28);
        java.lang.Object obj30 = intervalMarker2.clone();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeColumn((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//        org.junit.Assert.assertNull(classLoader0);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer2.setBaseItemLabelPaint(paint3);
        boolean boolean6 = intervalBarRenderer2.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer2.setBaseItemLabelFont(font7, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font7, (java.awt.Paint) color10);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font7);
        labelBlock12.setID("TextAnchor.BASELINE_CENTER");
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textBlock11);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke4 = intervalBarRenderer3.getBaseOutlineStroke();
        stackedBarRenderer3D1.setSeriesOutlineStroke((int) (short) 10, stroke4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedBarRenderer3D1.setSeriesPaint((int) '#', (java.awt.Paint) color7);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint17 = intervalBarRenderer14.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint17);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer19.setBaseItemLabelPaint(paint20);
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("", font13, paint20);
        java.awt.Color color26 = java.awt.Color.getHSBColor((float) (short) 1, (float) 10L, 10.0f);
        java.awt.Color color27 = color26.darker();
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font13, (java.awt.Paint) color27, (float) (-2208960000000L));
        stackedBarRenderer3D1.setSeriesPaint((int) ' ', (java.awt.Paint) color27, true);
        stackedBarRenderer3D1.setBaseSeriesVisible(true, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Shape shape2 = null;
        intervalBarRenderer0.setSeriesShape(4, shape2, false);
        boolean boolean5 = intervalBarRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = intervalBarRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = piePlot1.getLegendItems();
        piePlot1.setShadowYOffset((double) 100.0f);
        java.awt.Paint paint7 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 100);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = categoryPlot24.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis30.setAutoRangeStickyZero(false);
        numberAxis30.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer35 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean38 = intervalBarRenderer35.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font40 = null;
        intervalBarRenderer35.setSeriesItemLabelFont((int) '4', font40);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = null;
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener46 = null;
        numberAxis45.addChangeListener(axisChangeListener46);
        org.jfree.chart.plot.Marker marker48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        intervalBarRenderer35.drawRangeMarker(graphics2D42, categoryPlot43, (org.jfree.chart.axis.ValueAxis) numberAxis45, marker48, rectangle2D49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer35);
        double double52 = categoryPlot51.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation53 = categoryPlot51.getDomainAxisLocation();
        java.awt.Paint paint54 = categoryPlot51.getNoDataMessagePaint();
        categoryPlot51.setRangeCrosshairLockedOnData(false);
        java.awt.Paint paint57 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot51.setRangeGridlinePaint(paint57);
        org.jfree.data.category.CategoryDataset categoryDataset59 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis62.setAutoRangeStickyZero(false);
        numberAxis62.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer67 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean70 = intervalBarRenderer67.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font72 = null;
        intervalBarRenderer67.setSeriesItemLabelFont((int) '4', font72);
        java.awt.Graphics2D graphics2D74 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = null;
        org.jfree.chart.axis.NumberAxis numberAxis77 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener78 = null;
        numberAxis77.addChangeListener(axisChangeListener78);
        org.jfree.chart.plot.Marker marker80 = null;
        java.awt.geom.Rectangle2D rectangle2D81 = null;
        intervalBarRenderer67.drawRangeMarker(graphics2D74, categoryPlot75, (org.jfree.chart.axis.ValueAxis) numberAxis77, marker80, rectangle2D81);
        org.jfree.chart.plot.CategoryPlot categoryPlot83 = new org.jfree.chart.plot.CategoryPlot(categoryDataset59, categoryAxis60, (org.jfree.chart.axis.ValueAxis) numberAxis62, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer67);
        double double84 = categoryPlot83.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation85 = categoryPlot83.getDomainAxisLocation();
        org.jfree.data.Range range86 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint88 = new org.jfree.chart.block.RectangleConstraint(range86, (double) (byte) -1);
        boolean boolean89 = axisLocation85.equals((java.lang.Object) range86);
        categoryPlot51.setRangeAxisLocation(axisLocation85);
        categoryPlot24.setRangeAxisLocation(68, axisLocation85, false);
        boolean boolean94 = categoryPlot24.equals((java.lang.Object) 0L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation85);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint5 = intervalBarRenderer2.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textBlock6.calculateDimensions(graphics2D7);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font10);
        textBlock6.addLine(textLine11);
        java.awt.Graphics2D graphics2D13 = null;
        try {
            org.jfree.chart.util.Size2D size2D14 = textLine11.calculateDimensions(graphics2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0L, jFreeChart1, chartChangeEventType2);
        java.lang.Object obj4 = chartChangeEvent3.getSource();
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 0L + "'", obj4.equals(0L));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        try {
            polarPlot0.zoomRangeAxes(0.0d, (double) 35, plotRenderingInfo3, point2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        xYPlot9.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis22.setAutoRangeStickyZero(false);
        double double25 = numberAxis22.getUpperBound();
        xYPlot9.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis22, false);
        java.awt.Paint paint28 = xYPlot9.getRangeZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        xYPlot9.setDataset(xYDataset29);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment(0L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline3.getSegment(0L);
        boolean boolean6 = segment2.after(segment5);
        segment5.inc();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertNotNull(segment5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Number number2 = null;
        defaultKeyedValues0.addValue((java.lang.Comparable) 8.0d, number2);
        defaultKeyedValues0.addValue((java.lang.Comparable) 2, (double) (byte) 10);
        int int7 = defaultKeyedValues0.getItemCount();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        java.lang.Object obj2 = null;
        boolean boolean3 = tickUnits0.equals(obj2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer3.setBaseItemLabelPaint(paint4);
        boolean boolean7 = intervalBarRenderer3.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer3.setBaseItemLabelFont(font8, false);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font8, (java.awt.Paint) color11);
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("", font8);
        labelBlock13.setID("Category Plot");
        java.awt.Paint paint16 = labelBlock13.getPaint();
        java.awt.Color color17 = java.awt.Color.gray;
        columnArrangement0.add((org.jfree.chart.block.Block) labelBlock13, (java.lang.Object) color17);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) ' ');
        numberAxis1.setTickUnit(numberTickUnit3, true, true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis1.getMarkerBand();
        numberAxis1.setRangeAboutValue((double) 100.0f, (double) 68);
        org.junit.Assert.assertNull(markerAxisBand7);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        int int0 = org.jfree.chart.axis.DateTickUnit.DAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setDomainCrosshairVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot9.getDomainAxisEdge();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(12.0d, (double) (-1));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition24 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean25 = stackedBarRenderer3D23.equals((java.lang.Object) categoryLabelPosition24);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions27 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge28);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition30 = categoryLabelPositions27.getLabelPosition(rectangleEdge28);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions32 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge33);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition35 = categoryLabelPositions32.getLabelPosition(rectangleEdge33);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition36 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions37 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition24, categoryLabelPosition30, categoryLabelPosition35, categoryLabelPosition36);
        boolean boolean38 = rectangleEdge20.equals((java.lang.Object) categoryLabelPosition24);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor39 = categoryLabelPosition24.getLabelAnchor();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(categoryLabelPosition30);
        org.junit.Assert.assertNotNull(categoryLabelPositions32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(categoryLabelPosition35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor39);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey(100);
        java.lang.Object obj4 = keyedObjects0.getObject(128);
        try {
            keyedObjects0.removeValue(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke1 = intervalBarRenderer0.getBaseOutlineStroke();
        java.awt.Paint paint2 = intervalBarRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setSeriesVisible(6, (java.lang.Boolean) true, false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("Category Plot");
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = null;
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis31.setAutoRangeStickyZero(false);
        numberAxis31.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis31, valueAxis36, xYItemRenderer37);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer39 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke41 = intervalBarRenderer39.lookupSeriesStroke(3);
        xYPlot38.setDomainGridlineStroke(stroke41);
        java.awt.Stroke stroke43 = xYPlot38.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot38.getRangeAxisLocation();
        java.util.List list45 = xYPlot38.getAnnotations();
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection47 = xYPlot38.getRangeMarkers(layer46);
        try {
            categoryPlot24.addDomainMarker(categoryMarker28, layer46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertNull(collection47);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer2.setBaseItemLabelPaint(paint3);
        boolean boolean6 = intervalBarRenderer2.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer2.setBaseItemLabelFont(font7, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font7, (java.awt.Paint) color10);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font7);
        labelBlock12.setWidth((double) 6);
        double double15 = labelBlock12.getContentYOffset();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.POSITIVE" + "'", str1.equals("RangeType.POSITIVE"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(12.0d, (double) (-1));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean4 = stackedBarRenderer3D2.equals((java.lang.Object) categoryLabelPosition3);
        java.lang.Object obj5 = null;
        boolean boolean6 = stackedBarRenderer3D2.equals(obj5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment(0L);
        long long5 = segmentedTimeline0.getExceptionSegmentCount(1L, (long) (byte) 100);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.clear();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 2958465);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat4);
        boolean boolean7 = dateTickUnit5.equals((java.lang.Object) (short) -1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer8.setBaseItemLabelPaint(paint9);
        boolean boolean12 = intervalBarRenderer8.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke16 = intervalBarRenderer14.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = intervalBarRenderer14.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer8.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition18);
        java.awt.Shape shape20 = intervalBarRenderer8.getBaseShape();
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray28, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset34);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity38 = new org.jfree.chart.entity.CategoryItemEntity(shape20, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset34, (java.lang.Comparable) 8.0d, (java.lang.Comparable) 0.0f);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity41 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) boolean7, shape20, "", "hi!");
        java.lang.Comparable comparable42 = categoryLabelEntity41.getKey();
        java.lang.String str43 = categoryLabelEntity41.toString();
        java.lang.String str44 = categoryLabelEntity41.toString();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + false + "'", comparable42.equals(false));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "CategoryLabelEntity: category=false, tooltip=, url=hi!" + "'", str43.equals("CategoryLabelEntity: category=false, tooltip=, url=hi!"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "CategoryLabelEntity: category=false, tooltip=, url=hi!" + "'", str44.equals("CategoryLabelEntity: category=false, tooltip=, url=hi!"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        java.awt.Paint paint25 = intervalBarRenderer8.getBasePaint();
        intervalBarRenderer8.setItemMargin(2.0d);
        intervalBarRenderer8.setSeriesItemLabelsVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) (short) -1);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 255);
        try {
            defaultKeyedValues2D1.removeRow((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "", font2);
        int int4 = categoryAxis0.getMaximumCategoryLabelLines();
        float float5 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultBoxAndWhiskerCategoryDataset0.getGroup();
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        categoryPlot24.configureDomainAxes();
        int int28 = categoryPlot24.getWeight();
        int int29 = categoryPlot24.getWeight();
        categoryPlot24.setDomainGridlinesVisible(false);
        int int32 = categoryPlot24.getDomainAxisCount();
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = null;
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis37.setAutoRangeStickyZero(false);
        numberAxis37.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) numberAxis37, valueAxis42, xYItemRenderer43);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer45 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke47 = intervalBarRenderer45.lookupSeriesStroke(3);
        xYPlot44.setDomainGridlineStroke(stroke47);
        java.awt.Stroke stroke49 = xYPlot44.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation50 = xYPlot44.getRangeAxisLocation();
        java.util.List list51 = xYPlot44.getAnnotations();
        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection53 = xYPlot44.getRangeMarkers(layer52);
        try {
            categoryPlot24.addDomainMarker(128, categoryMarker34, layer52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertNotNull(list51);
        org.junit.Assert.assertNotNull(layer52);
        org.junit.Assert.assertNull(collection53);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer0.setBaseItemLabelPaint(paint1);
        boolean boolean4 = intervalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer0.setBaseItemLabelFont(font5, false);
        intervalBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis4.setAutoRangeStickyZero(false);
        numberAxis4.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis9, xYItemRenderer10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke14 = intervalBarRenderer12.lookupSeriesStroke(3);
        xYPlot11.setDomainGridlineStroke(stroke14);
        lineRenderer3D0.setSeriesOutlineStroke(3, stroke14, true);
        lineRenderer3D0.setBaseShapesFilled(false);
        java.lang.Boolean boolean21 = lineRenderer3D0.getSeriesItemLabelsVisible(10);
        double double22 = lineRenderer3D0.getYOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = null;
        try {
            lineRenderer3D0.setBasePositiveItemLabelPosition(itemLabelPosition23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 8.0d + "'", double22 == 8.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        java.awt.Paint paint25 = intervalBarRenderer8.getBasePaint();
        intervalBarRenderer8.setItemMargin(2.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator28 = intervalBarRenderer8.getLegendItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator28);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        int int5 = chartProgressEvent4.getPercent();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint14 = intervalBarRenderer11.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, paint14);
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("hi!", font8, paint14, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean21 = intervalBarRenderer18.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font23 = null;
        intervalBarRenderer18.setSeriesItemLabelFont((int) '4', font23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener29 = null;
        numberAxis28.addChangeListener(axisChangeListener29);
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        intervalBarRenderer18.drawRangeMarker(graphics2D25, categoryPlot26, (org.jfree.chart.axis.ValueAxis) numberAxis28, marker31, rectangle2D32);
        boolean boolean34 = textFragment17.equals((java.lang.Object) graphics2D25);
        java.awt.Font font35 = textFragment17.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis39.setAutoRangeStickyZero(false);
        numberAxis39.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean47 = intervalBarRenderer44.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font49 = null;
        intervalBarRenderer44.setSeriesItemLabelFont((int) '4', font49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener55 = null;
        numberAxis54.addChangeListener(axisChangeListener55);
        org.jfree.chart.plot.Marker marker57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        intervalBarRenderer44.drawRangeMarker(graphics2D51, categoryPlot52, (org.jfree.chart.axis.ValueAxis) numberAxis54, marker57, rectangle2D58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer44);
        org.jfree.chart.JFreeChart jFreeChart62 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", font35, (org.jfree.chart.plot.Plot) categoryPlot60, false);
        chartProgressEvent4.setChart(jFreeChart62);
        jFreeChart62.setTitle("");
        org.jfree.chart.event.ChartChangeListener chartChangeListener66 = null;
        try {
            jFreeChart62.removeChangeListener(chartChangeListener66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.plot.Plot plot1 = waferMapPlot0.getRootPlot();
        java.lang.String str2 = waferMapPlot0.getPlotType();
        org.junit.Assert.assertNotNull(plot1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "WMAP_Plot" + "'", str2.equals("WMAP_Plot"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str3 = dateRange2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (double) 0);
        org.jfree.data.Range range6 = rectangleConstraint5.getWidthRange();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str3.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot9.getRangeAxisEdge();
        xYPlot9.clearDomainMarkers((int) '4');
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot9);
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer26 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint29 = intervalBarRenderer26.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock30 = org.jfree.chart.text.TextUtilities.createTextBlock("", font25, paint29);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer31 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer31.setBaseItemLabelPaint(paint32);
        org.jfree.chart.text.TextLine textLine34 = new org.jfree.chart.text.TextLine("", font25, paint32);
        java.awt.Color color38 = java.awt.Color.getHSBColor((float) (short) 1, (float) 10L, 10.0f);
        java.awt.Color color39 = color38.darker();
        org.jfree.chart.text.TextFragment textFragment41 = new org.jfree.chart.text.TextFragment("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font25, (java.awt.Paint) color39, (float) (-2208960000000L));
        xYPlot9.setRangeTickBandPaint((java.awt.Paint) color39);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(textBlock30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = piePlot1.getLegendItems();
        java.awt.Stroke stroke4 = piePlot1.getLabelLinkStroke();
        boolean boolean5 = piePlot1.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat4);
        boolean boolean7 = dateTickUnit5.equals((java.lang.Object) (short) -1);
        int int8 = dateTickUnit5.getUnit();
        int int9 = dateTickUnit5.getRollUnit();
        org.jfree.data.DefaultKeyedValues defaultKeyedValues10 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Number number12 = null;
        defaultKeyedValues10.addValue((java.lang.Comparable) 8.0d, number12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) dateTickUnit5, (org.jfree.data.KeyedValues) defaultKeyedValues10);
        try {
            java.lang.Number number16 = defaultKeyedValues10.getValue(128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
        org.junit.Assert.assertNotNull(categoryDataset14);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        categoryPlot24.configureDomainAxes();
        int int28 = categoryPlot24.getWeight();
        double double29 = categoryPlot24.getAnchorValue();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        piePlot1.setExplodePercent((java.lang.Comparable) "CategoryAnchor.MIDDLE", 1.0E-8d);
        double double6 = piePlot1.getShadowYOffset();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setIgnoreZeroValues(true);
        piePlot1.setMinimumArcAngleToDraw((double) (short) 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint9 = intervalBarRenderer6.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((double) (short) 1, (double) 1, (double) 10, (double) 0, paint9);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str13 = dateAxis12.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis12.setTickMarkPosition(dateTickMarkPosition14);
        java.text.DateFormat dateFormat20 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat20);
        java.util.Date date22 = dateAxis12.calculateHighestVisibleTickValue(dateTickUnit21);
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick29 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0, "hi!", textAnchor26, textAnchor27, (double) 4);
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.DateTick dateTick32 = new org.jfree.chart.axis.DateTick(date22, "hi!", textAnchor27, textAnchor30, (double) 2958465);
        boolean boolean33 = blockBorder10.equals((java.lang.Object) textAnchor30);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType35 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition37 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor30, (-1.0d), categoryLabelWidthType35, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset0, jFreeChart1, 0, (int) (byte) 100);
        int int5 = chartProgressEvent4.getPercent();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint14 = intervalBarRenderer11.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, paint14);
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("hi!", font8, paint14, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean21 = intervalBarRenderer18.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font23 = null;
        intervalBarRenderer18.setSeriesItemLabelFont((int) '4', font23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener29 = null;
        numberAxis28.addChangeListener(axisChangeListener29);
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        intervalBarRenderer18.drawRangeMarker(graphics2D25, categoryPlot26, (org.jfree.chart.axis.ValueAxis) numberAxis28, marker31, rectangle2D32);
        boolean boolean34 = textFragment17.equals((java.lang.Object) graphics2D25);
        java.awt.Font font35 = textFragment17.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis39.setAutoRangeStickyZero(false);
        numberAxis39.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean47 = intervalBarRenderer44.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font49 = null;
        intervalBarRenderer44.setSeriesItemLabelFont((int) '4', font49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener55 = null;
        numberAxis54.addChangeListener(axisChangeListener55);
        org.jfree.chart.plot.Marker marker57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        intervalBarRenderer44.drawRangeMarker(graphics2D51, categoryPlot52, (org.jfree.chart.axis.ValueAxis) numberAxis54, marker57, rectangle2D58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer44);
        org.jfree.chart.JFreeChart jFreeChart62 = new org.jfree.chart.JFreeChart("({0}, {1}) = {2}", font35, (org.jfree.chart.plot.Plot) categoryPlot60, false);
        chartProgressEvent4.setChart(jFreeChart62);
        jFreeChart62.setTitle("");
        java.awt.RenderingHints renderingHints66 = null;
        try {
            jFreeChart62.setRenderingHints(renderingHints66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, 0.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        intervalMarker7.setLabel("hi!");
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener12 = null;
        numberAxis11.addChangeListener(axisChangeListener12);
        numberAxis11.setRangeWithMargins((double) (short) -1, (double) (byte) 0);
        boolean boolean17 = intervalMarker7.equals((java.lang.Object) (short) -1);
        boolean boolean18 = flowArrangement4.equals((java.lang.Object) intervalMarker7);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = intervalMarker7.getGradientPaintTransformer();
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer19);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("hi!", font1, paint7, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean14 = intervalBarRenderer11.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font16 = null;
        intervalBarRenderer11.setSeriesItemLabelFont((int) '4', font16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener22 = null;
        numberAxis21.addChangeListener(axisChangeListener22);
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        intervalBarRenderer11.drawRangeMarker(graphics2D18, categoryPlot19, (org.jfree.chart.axis.ValueAxis) numberAxis21, marker24, rectangle2D25);
        boolean boolean27 = textFragment10.equals((java.lang.Object) graphics2D18);
        java.awt.Font font28 = textFragment10.getFont();
        java.lang.String str29 = textFragment10.getText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        java.awt.Color color28 = java.awt.Color.darkGray;
        categoryPlot24.setOutlinePaint((java.awt.Paint) color28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        try {
            categoryPlot24.drawBackground(graphics2D30, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        java.awt.Paint paint30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot24.setRangeGridlinePaint(paint30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis35.setAutoRangeStickyZero(false);
        numberAxis35.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer40 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean43 = intervalBarRenderer40.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font45 = null;
        intervalBarRenderer40.setSeriesItemLabelFont((int) '4', font45);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = null;
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener51 = null;
        numberAxis50.addChangeListener(axisChangeListener51);
        org.jfree.chart.plot.Marker marker53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        intervalBarRenderer40.drawRangeMarker(graphics2D47, categoryPlot48, (org.jfree.chart.axis.ValueAxis) numberAxis50, marker53, rectangle2D54);
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis35, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer40);
        double double57 = categoryPlot56.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation58 = categoryPlot56.getDomainAxisLocation();
        org.jfree.data.Range range59 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint61 = new org.jfree.chart.block.RectangleConstraint(range59, (double) (byte) -1);
        boolean boolean62 = axisLocation58.equals((java.lang.Object) range59);
        categoryPlot24.setRangeAxisLocation(axisLocation58);
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis65.setAutoRangeStickyZero(false);
        numberAxis65.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat70 = numberAxis65.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = numberAxis65.getTickLabelInsets();
        categoryPlot24.setAxisOffset(rectangleInsets71);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(numberFormat70);
        org.junit.Assert.assertNotNull(rectangleInsets71);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot24.rendererChanged(rendererChangeEvent30);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot24);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer34.setBaseItemLabelPaint(paint35);
        boolean boolean38 = intervalBarRenderer34.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer34.setBaseItemLabelFont(font39, false);
        categoryPlot24.setRenderer((int) (short) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer34, true);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str47 = dateAxis46.getLabelToolTip();
        java.awt.Shape shape48 = dateAxis46.getDownArrow();
        boolean boolean50 = dateAxis46.isHiddenValue((long) (byte) -1);
        categoryPlot24.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) dateAxis46);
        org.jfree.data.Range range52 = dateAxis46.getDefaultAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str55 = dateAxis54.getLabelToolTip();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition56 = org.jfree.chart.axis.DateTickMarkPosition.START;
        dateAxis54.setTickMarkPosition(dateTickMarkPosition56);
        java.text.DateFormat dateFormat62 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit63 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat62);
        java.util.Date date64 = dateAxis54.calculateHighestVisibleTickValue(dateTickUnit63);
        org.jfree.chart.text.TextAnchor textAnchor68 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor69 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick71 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0, "hi!", textAnchor68, textAnchor69, (double) 4);
        org.jfree.chart.text.TextAnchor textAnchor72 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.DateTick dateTick74 = new org.jfree.chart.axis.DateTick(date64, "hi!", textAnchor69, textAnchor72, (double) 2958465);
        java.awt.geom.Rectangle2D rectangle2D75 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge76);
        try {
            double double78 = dateAxis46.dateToJava2D(date64, rectangle2D75, rectangleEdge77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNotNull(dateTickMarkPosition56);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(textAnchor68);
        org.junit.Assert.assertNotNull(textAnchor69);
        org.junit.Assert.assertNotNull(textAnchor72);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertNotNull(rectangleEdge77);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        numberAxis1.setTickLabelPaint(paint7);
        numberAxis1.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis16.setAutoRangeStickyZero(false);
        numberAxis16.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer21 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean24 = intervalBarRenderer21.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font26 = null;
        intervalBarRenderer21.setSeriesItemLabelFont((int) '4', font26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener32 = null;
        numberAxis31.addChangeListener(axisChangeListener32);
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        intervalBarRenderer21.drawRangeMarker(graphics2D28, categoryPlot29, (org.jfree.chart.axis.ValueAxis) numberAxis31, marker34, rectangle2D35);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer21);
        categoryPlot37.configureRangeAxes();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        org.jfree.chart.axis.AxisSpace axisSpace42 = numberAxis1.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) categoryPlot37, rectangle2D39, rectangleEdge40, axisSpace41);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer44 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke45 = intervalBarRenderer44.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator47 = intervalBarRenderer44.getSeriesItemLabelGenerator((int) (short) 10);
        categoryPlot37.setRenderer(6, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer44, false);
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis54.setAutoRangeStickyZero(false);
        numberAxis54.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer59 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean62 = intervalBarRenderer59.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font64 = null;
        intervalBarRenderer59.setSeriesItemLabelFont((int) '4', font64);
        java.awt.Graphics2D graphics2D66 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = null;
        org.jfree.chart.axis.NumberAxis numberAxis69 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener70 = null;
        numberAxis69.addChangeListener(axisChangeListener70);
        org.jfree.chart.plot.Marker marker72 = null;
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        intervalBarRenderer59.drawRangeMarker(graphics2D66, categoryPlot67, (org.jfree.chart.axis.ValueAxis) numberAxis69, marker72, rectangle2D73);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, (org.jfree.chart.axis.ValueAxis) numberAxis54, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer59);
        double double76 = categoryPlot75.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation77 = categoryPlot75.getDomainAxisLocation();
        java.awt.Paint paint78 = categoryPlot75.getNoDataMessagePaint();
        java.awt.Color color79 = java.awt.Color.darkGray;
        categoryPlot75.setOutlinePaint((java.awt.Paint) color79);
        org.jfree.data.xy.XYDataset xYDataset81 = null;
        org.jfree.chart.axis.NumberAxis numberAxis83 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis83.setAutoRangeStickyZero(false);
        numberAxis83.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis88 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer89 = null;
        org.jfree.chart.plot.XYPlot xYPlot90 = new org.jfree.chart.plot.XYPlot(xYDataset81, (org.jfree.chart.axis.ValueAxis) numberAxis83, valueAxis88, xYItemRenderer89);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer91 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke93 = intervalBarRenderer91.lookupSeriesStroke(3);
        xYPlot90.setDomainGridlineStroke(stroke93);
        java.awt.Stroke stroke95 = xYPlot90.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation96 = xYPlot90.getRangeAxisLocation();
        categoryPlot75.setRangeAxisLocation(axisLocation96);
        categoryPlot37.setDomainAxisLocation((int) (byte) 1, axisLocation96);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(axisSpace42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNull(categoryItemLabelGenerator47);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertNotNull(stroke93);
        org.junit.Assert.assertNotNull(stroke95);
        org.junit.Assert.assertNotNull(axisLocation96);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setDomainCrosshairVisible(false);
        xYPlot9.setRangeGridlinesVisible(false);
        try {
            xYPlot9.setBackgroundImageAlpha(10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        int int3 = java.awt.Color.HSBtoRGB((float) 2, (float) (short) -1, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-2) + "'", int3 == (-2));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot24.getOrientation();
        categoryPlot24.zoom((double) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryAxis34.setTickMarkStroke(stroke35);
        try {
            categoryPlot24.setDomainAxis((-1), categoryAxis34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 0.0d, (java.lang.Object) false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        long long5 = segmentedTimeline3.getSegmentsGroupSize();
        boolean boolean6 = keyedObject2.equals((java.lang.Object) long5);
        java.lang.Object obj7 = keyedObject2.getObject();
        java.lang.Object obj8 = keyedObject2.clone();
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 68 + "'", int4 == 68);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 86400000L + "'", long5 == 86400000L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + false + "'", obj7.equals(false));
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer2.setBaseItemLabelPaint(paint3);
        boolean boolean6 = intervalBarRenderer2.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer2.setBaseItemLabelFont(font7, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font7, (java.awt.Paint) color10);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font7);
        double double13 = labelBlock12.getHeight();
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        labelBlock12.setPaint(paint14);
        java.lang.Object obj16 = labelBlock12.clone();
        double double17 = labelBlock12.getHeight();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "", font2);
        int int4 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 68);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        xYPlot9.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis22.setAutoRangeStickyZero(false);
        double double25 = numberAxis22.getUpperBound();
        xYPlot9.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis22, false);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot9.setRangeAxisLocation(axisLocation28);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        double double1 = boxAndWhiskerRenderer0.getItemMargin();
        boxAndWhiskerRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(4, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer4 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint7 = intervalBarRenderer4.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint7);
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("hi!", font1, paint7, 100.0f);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean14 = intervalBarRenderer11.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font16 = null;
        intervalBarRenderer11.setSeriesItemLabelFont((int) '4', font16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener22 = null;
        numberAxis21.addChangeListener(axisChangeListener22);
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        intervalBarRenderer11.drawRangeMarker(graphics2D18, categoryPlot19, (org.jfree.chart.axis.ValueAxis) numberAxis21, marker24, rectangle2D25);
        boolean boolean27 = textFragment10.equals((java.lang.Object) graphics2D18);
        java.awt.Font font28 = textFragment10.getFont();
        java.awt.Font font29 = textFragment10.getFont();
        java.awt.Font font30 = textFragment10.getFont();
        java.awt.Graphics2D graphics2D31 = null;
        try {
            org.jfree.chart.util.Size2D size2D32 = textFragment10.calculateDimensions(graphics2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(font30);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(6, (int) (byte) 1, (int) '#', (-1), dateFormat4);
        boolean boolean7 = dateTickUnit5.equals((java.lang.Object) (short) -1);
        int int8 = dateTickUnit5.getUnit();
        int int9 = dateTickUnit5.getRollUnit();
        java.lang.String str11 = dateTickUnit5.valueToString((double) ' ');
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "12/31/69" + "'", str11.equals("12/31/69"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean3 = intervalBarRenderer0.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font5 = null;
        intervalBarRenderer0.setSeriesItemLabelFont((int) '4', font5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener11 = null;
        numberAxis10.addChangeListener(axisChangeListener11);
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        intervalBarRenderer0.drawRangeMarker(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis10, marker13, rectangle2D14);
        int int16 = intervalBarRenderer0.getColumnCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        categoryPlot24.configureRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis29.setAutoRangeStickyZero(false);
        numberAxis29.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean37 = intervalBarRenderer34.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font39 = null;
        intervalBarRenderer34.setSeriesItemLabelFont((int) '4', font39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener45 = null;
        numberAxis44.addChangeListener(axisChangeListener45);
        org.jfree.chart.plot.Marker marker47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        intervalBarRenderer34.drawRangeMarker(graphics2D41, categoryPlot42, (org.jfree.chart.axis.ValueAxis) numberAxis44, marker47, rectangle2D48);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer34);
        double double51 = categoryPlot50.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation52 = categoryPlot50.getDomainAxisLocation();
        java.awt.Paint paint53 = categoryPlot50.getNoDataMessagePaint();
        categoryPlot50.setRangeCrosshairLockedOnData(false);
        java.awt.Paint paint56 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot50.setRangeGridlinePaint(paint56);
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis61.setAutoRangeStickyZero(false);
        numberAxis61.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer66 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean69 = intervalBarRenderer66.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font71 = null;
        intervalBarRenderer66.setSeriesItemLabelFont((int) '4', font71);
        java.awt.Graphics2D graphics2D73 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = null;
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener77 = null;
        numberAxis76.addChangeListener(axisChangeListener77);
        org.jfree.chart.plot.Marker marker79 = null;
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        intervalBarRenderer66.drawRangeMarker(graphics2D73, categoryPlot74, (org.jfree.chart.axis.ValueAxis) numberAxis76, marker79, rectangle2D80);
        org.jfree.chart.plot.CategoryPlot categoryPlot82 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, (org.jfree.chart.axis.ValueAxis) numberAxis61, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer66);
        double double83 = categoryPlot82.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation84 = categoryPlot82.getDomainAxisLocation();
        org.jfree.data.Range range85 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint87 = new org.jfree.chart.block.RectangleConstraint(range85, (double) (byte) -1);
        boolean boolean88 = axisLocation84.equals((java.lang.Object) range85);
        categoryPlot50.setRangeAxisLocation(axisLocation84);
        categoryPlot24.setDomainAxisLocation(axisLocation84, false);
        boolean boolean92 = categoryPlot24.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation84);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "", font2);
        double double4 = categoryAxis0.getFixedDimension();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState7 = new org.jfree.chart.axis.AxisState((double) 4);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge9);
        try {
            java.util.List list11 = categoryAxis0.refreshTicks(graphics2D5, axisState7, rectangle2D8, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getDomainAxisLocation();
        java.awt.Paint paint27 = categoryPlot24.getNoDataMessagePaint();
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot24.rendererChanged(rendererChangeEvent30);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot24);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer34 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer34.setBaseItemLabelPaint(paint35);
        boolean boolean38 = intervalBarRenderer34.isSeriesItemLabelsVisible((int) (byte) 1);
        java.awt.Font font39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        intervalBarRenderer34.setBaseItemLabelFont(font39, false);
        categoryPlot24.setRenderer((int) (short) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer34, true);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator45 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str46 = standardCategoryToolTipGenerator45.getLabelFormat();
        intervalBarRenderer34.setSeriesToolTipGenerator(4, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator45, false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "({0}, {1}) = {2}" + "'", str46.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis16.getTickUnit();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick9 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0, "hi!", textAnchor6, textAnchor7, (double) 4);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) '4', (float) 86400000L, textAnchor7, (double) 10L, 0.0f, (float) (-2208960000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot9.getRangeAxisLocation();
        java.util.List list16 = xYPlot9.getAnnotations();
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection18 = xYPlot9.getRangeMarkers(layer17);
        xYPlot9.setNoDataMessage("TextAnchor.BASELINE_CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis24.setAutoRangeStickyZero(false);
        numberAxis24.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer29 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean32 = intervalBarRenderer29.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font34 = null;
        intervalBarRenderer29.setSeriesItemLabelFont((int) '4', font34);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener40 = null;
        numberAxis39.addChangeListener(axisChangeListener40);
        org.jfree.chart.plot.Marker marker42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        intervalBarRenderer29.drawRangeMarker(graphics2D36, categoryPlot37, (org.jfree.chart.axis.ValueAxis) numberAxis39, marker42, rectangle2D43);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer29);
        double double46 = categoryPlot45.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation47 = categoryPlot45.getDomainAxisLocation();
        java.awt.Paint paint48 = categoryPlot45.getNoDataMessagePaint();
        categoryPlot45.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation51 = categoryPlot45.getOrientation();
        xYPlot9.setOrientation(plotOrientation51);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(plotOrientation51);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        boolean boolean3 = dateAxis1.equals((java.lang.Object) itemLabelAnchor2);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis1.setTimeline(timeline4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis1.getTickUnit();
        dateAxis1.configure();
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTickUnit6);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str1.equals("GradientPaintTransformType.CENTER_VERTICAL"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo7.getOptionalLibraries();
        projectInfo7.setLicenceName("WMAP_Plot");
        org.junit.Assert.assertNotNull(libraryArray10);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = categoryPlot24.getDatasetRenderingOrder();
        categoryPlot24.configureRangeAxes();
        java.lang.String str27 = categoryPlot24.getPlotType();
        categoryPlot24.setDrawSharedDomainAxis(false);
        java.lang.String str30 = categoryPlot24.getNoDataMessage();
        int int31 = categoryPlot24.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Category Plot" + "'", str27.equals("Category Plot"));
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("{0}", graphics2D1, (double) 128, 0.0f, 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 0, 0.0d);
        java.lang.String str3 = dateRange2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (double) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint5.toUnconstrainedHeight();
        double double7 = rectangleConstraint5.getHeight();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str3.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.awt.Shape shape5 = piePlot4.getLegendItemShape();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot4.getLegendItems();
        java.awt.Paint paint7 = piePlot4.getLabelOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState10 = piePlot3D0.initialise(graphics2D1, rectangle2D2, piePlot4, (java.lang.Integer) 3, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        boolean boolean25 = intervalBarRenderer8.getBaseSeriesVisibleInLegend();
        boolean boolean26 = intervalBarRenderer8.getAutoPopulateSeriesShape();
        java.awt.Shape shape29 = intervalBarRenderer8.getItemShape((int) (short) 100, 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset30 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent34 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultBoxAndWhiskerCategoryDataset30, jFreeChart31, 0, (int) (byte) 100);
        java.awt.Paint[] paintArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean36 = defaultBoxAndWhiskerCategoryDataset30.equals((java.lang.Object) paintArray35);
        org.jfree.data.Range range37 = intervalBarRenderer8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30);
        org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset30, (java.lang.Comparable) 10);
        org.jfree.chart.plot.PiePlot3D piePlot3D40 = new org.jfree.chart.plot.PiePlot3D(pieDataset39);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.awt.geom.Point2D point2D43 = null;
        org.jfree.chart.plot.PlotState plotState44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        try {
            piePlot3D40.draw(graphics2D41, rectangle2D42, point2D43, plotState44, plotRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(pieDataset39);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtLeft();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis3.setAutoRangeStickyZero(false);
        numberAxis3.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer8 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean11 = intervalBarRenderer8.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font13 = null;
        intervalBarRenderer8.setSeriesItemLabelFont((int) '4', font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis18.addChangeListener(axisChangeListener19);
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        intervalBarRenderer8.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker21, rectangle2D22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer8);
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot24.setRangeAxisLocation(axisLocation26, true);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis31.setAutoRangeStickyZero(false);
        numberAxis31.setAutoRangeStickyZero(false);
        categoryPlot24.setRangeAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) numberAxis31, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot24.getDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = categoryPlot24.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryAxis38);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis4.setAutoRangeStickyZero(false);
        numberAxis4.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis9, xYItemRenderer10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke14 = intervalBarRenderer12.lookupSeriesStroke(3);
        xYPlot11.setDomainGridlineStroke(stroke14);
        lineRenderer3D0.setSeriesOutlineStroke(3, stroke14, true);
        lineRenderer3D0.setBaseShapesFilled(false);
        double double20 = lineRenderer3D0.getXOffset();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 12.0d + "'", double20 == 12.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke4 = intervalBarRenderer3.getBaseOutlineStroke();
        stackedBarRenderer3D1.setSeriesOutlineStroke((int) (short) 10, stroke4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedBarRenderer3D1.setSeriesPaint((int) '#', (java.awt.Paint) color7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener13 = null;
        numberAxis12.addChangeListener(axisChangeListener13);
        numberAxis12.setRangeWithMargins((double) (short) -1, (double) (byte) 0);
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) 'a');
        intervalMarker20.setLabel("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.plot.Marker) intervalMarker20, rectangle2D23);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator25 = stackedBarRenderer3D1.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator25);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getGroupSegmentCount();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 96 + "'", int1 == 96);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis4.setAutoRangeStickyZero(false);
        numberAxis4.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer9 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean12 = intervalBarRenderer9.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font14 = null;
        intervalBarRenderer9.setSeriesItemLabelFont((int) '4', font14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener20 = null;
        numberAxis19.addChangeListener(axisChangeListener20);
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        intervalBarRenderer9.drawRangeMarker(graphics2D16, categoryPlot17, (org.jfree.chart.axis.ValueAxis) numberAxis19, marker22, rectangle2D23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer9);
        double double26 = categoryPlot25.getRangeCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis30.setAutoRangeStickyZero(false);
        numberAxis30.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer35 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean38 = intervalBarRenderer35.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font40 = null;
        intervalBarRenderer35.setSeriesItemLabelFont((int) '4', font40);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = null;
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener46 = null;
        numberAxis45.addChangeListener(axisChangeListener46);
        org.jfree.chart.plot.Marker marker48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        intervalBarRenderer35.drawRangeMarker(graphics2D42, categoryPlot43, (org.jfree.chart.axis.ValueAxis) numberAxis45, marker48, rectangle2D49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer35);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder52 = categoryPlot51.getDatasetRenderingOrder();
        categoryPlot25.setDatasetRenderingOrder(datasetRenderingOrder52);
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot25);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = categoryPlot25.getDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder52);
        org.junit.Assert.assertNull(categoryAxis55);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis4.setAutoRangeStickyZero(false);
        numberAxis4.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, valueAxis9, xYItemRenderer10);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer12 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke14 = intervalBarRenderer12.lookupSeriesStroke(3);
        xYPlot11.setDomainGridlineStroke(stroke14);
        java.awt.Stroke stroke16 = xYPlot11.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot11.getDomainMarkers(2, layer18);
        xYPlot11.setWeight(10);
        xYPlot11.setRangeCrosshairValue((double) 4, true);
        xYPlot11.setDomainCrosshairValue((double) '4', true);
        boolean boolean28 = lineBorder0.equals((java.lang.Object) '4');
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis7, xYItemRenderer8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke12 = intervalBarRenderer10.lookupSeriesStroke(3);
        xYPlot9.setDomainGridlineStroke(stroke12);
        java.awt.Stroke stroke14 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot9.getDomainMarkers(2, layer16);
        xYPlot9.setWeight(10);
        xYPlot9.setRangeCrosshairValue((double) 4, true);
        int int23 = xYPlot9.getRangeAxisCount();
        xYPlot9.configureDomainAxes();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo7.getOptionalLibraries();
        java.awt.Image image14 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo18 = new org.jfree.chart.ui.ProjectInfo("", "", "", image14, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image19 = null;
        projectInfo18.setLogo(image19);
        java.lang.String str21 = projectInfo18.getInfo();
        org.jfree.chart.ui.Library[] libraryArray22 = projectInfo18.getOptionalLibraries();
        java.awt.Image image26 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo30 = new org.jfree.chart.ui.ProjectInfo("", "", "", image26, "({0}, {1}) = {2}", "", "hi!");
        java.awt.Image image31 = null;
        projectInfo30.setLogo(image31);
        java.lang.String str33 = projectInfo30.getInfo();
        org.jfree.chart.ui.Library[] libraryArray34 = projectInfo30.getOptionalLibraries();
        projectInfo18.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo30);
        projectInfo18.setInfo("");
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo18);
        java.lang.String str39 = projectInfo18.toString();
        org.junit.Assert.assertNotNull(libraryArray10);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(libraryArray22);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(libraryArray34);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + " version .\n({0}, {1}) = {2}.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!" + "'", str39.equals(" version .\n({0}, {1}) = {2}.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer0.setBaseItemLabelPaint(paint1);
        boolean boolean4 = intervalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke8 = intervalBarRenderer6.lookupSeriesStroke(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = intervalBarRenderer6.getSeriesPositiveItemLabelPosition((int) '#');
        intervalBarRenderer0.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition10);
        java.awt.Shape shape12 = intervalBarRenderer0.getBaseShape();
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 2, (short) 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray20, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", numberArray25);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset26);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity30 = new org.jfree.chart.entity.CategoryItemEntity(shape12, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", categoryDataset26, (java.lang.Comparable) 8.0d, (java.lang.Comparable) 0.0f);
        java.lang.String str31 = categoryItemEntity30.getToolTipText();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer32 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Shape shape34 = null;
        intervalBarRenderer32.setSeriesShape(4, shape34, false);
        intervalBarRenderer32.setBaseCreateEntities(false, true);
        boolean boolean40 = categoryItemEntity30.equals((java.lang.Object) intervalBarRenderer32);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint5 = intervalBarRenderer2.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textBlock6.calculateDimensions(graphics2D7);
        double double9 = size2D8.height;
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        numberAxis1.addChangeListener(axisChangeListener2);
        double double4 = numberAxis1.getLabelAngle();
        numberAxis1.setUpperMargin((double) (byte) 10);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.plot.Plot plot8 = waferMapPlot7.getRootPlot();
        boolean boolean9 = numberAxis1.hasListener((java.util.EventListener) plot8);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        double double4 = numberAxis1.getUpperBound();
        numberAxis1.setLabelURL("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        boolean boolean3 = dateAxis1.equals((java.lang.Object) itemLabelAnchor2);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis1.setTimeline(timeline4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis1.getTickUnit();
        java.text.DateFormat dateFormat7 = dateAxis1.getDateFormatOverride();
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNull(dateFormat7);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis6.setAutoRangeStickyZero(false);
        numberAxis6.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer11 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        boolean boolean14 = intervalBarRenderer11.getItemVisible((int) (byte) 1, (int) (short) 100);
        java.awt.Font font16 = null;
        intervalBarRenderer11.setSeriesItemLabelFont((int) '4', font16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.event.AxisChangeListener axisChangeListener22 = null;
        numberAxis21.addChangeListener(axisChangeListener22);
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        intervalBarRenderer11.drawRangeMarker(graphics2D18, categoryPlot19, (org.jfree.chart.axis.ValueAxis) numberAxis21, marker24, rectangle2D25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) intervalBarRenderer11);
        double double28 = categoryPlot27.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot27.getDomainAxisLocation();
        java.awt.Paint paint30 = categoryPlot27.getNoDataMessagePaint();
        categoryPlot27.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = categoryPlot27.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState36 = boxAndWhiskerRenderer0.initialise(graphics2D1, rectangle2D2, categoryPlot27, (int) (short) -1, plotRenderingInfo35);
        double double37 = categoryItemRendererState36.getBarWidth();
        categoryItemRendererState36.setBarWidth((double) (-2));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertNotNull(categoryItemRendererState36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Shape shape3 = piePlot2.getLegendItemShape();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot2.getLegendItems();
        int int5 = legendItemCollection4.getItemCount();
        java.util.Iterator iterator6 = legendItemCollection4.iterator();
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", "hi!", shape11, (java.awt.Paint) color12);
        legendItemCollection4.add(legendItem13);
        boolean boolean15 = strokeList0.equals((java.lang.Object) legendItemCollection4);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(iterator6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer3 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Stroke stroke4 = intervalBarRenderer3.getBaseOutlineStroke();
        stackedBarRenderer3D1.setSeriesOutlineStroke((int) (short) 10, stroke4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedBarRenderer3D1.setSeriesPaint((int) '#', (java.awt.Paint) color7);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer14 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint17 = intervalBarRenderer14.getItemFillPaint(100, (int) 'a');
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, paint17);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer19 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        intervalBarRenderer19.setBaseItemLabelPaint(paint20);
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("", font13, paint20);
        java.awt.Color color26 = java.awt.Color.getHSBColor((float) (short) 1, (float) 10L, 10.0f);
        java.awt.Color color27 = color26.darker();
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font13, (java.awt.Paint) color27, (float) (-2208960000000L));
        stackedBarRenderer3D1.setSeriesPaint((int) ' ', (java.awt.Paint) color27, true);
        double double32 = stackedBarRenderer3D1.getXOffset();
        stackedBarRenderer3D1.setSeriesVisible(0, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 12.0d + "'", double32 == 12.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(68, (int) (short) -1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }
}

