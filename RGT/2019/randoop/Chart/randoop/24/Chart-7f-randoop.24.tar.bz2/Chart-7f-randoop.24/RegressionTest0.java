import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        java.lang.Number number1 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, number1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        java.util.Calendar calendar26 = null;
        try {
            day25.peg(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.lang.String str2 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        java.util.TimeZone timeZone15 = null;
        try {
            org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date7, timeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        try {
            timePeriodValues3.update(4, (java.lang.Number) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 12);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue3 = timePeriodValues1.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        try {
            timePeriodValues3.update((int) ' ', (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getStartMillis();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, 10, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getDayOfMonth();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day2.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[2019,10]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        try {
            java.lang.Number number7 = timePeriodValues3.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.TimePeriod timePeriod5 = null;
        try {
            timePeriodValues3.add(timePeriod5, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        java.util.Calendar calendar4 = null;
        try {
            year2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        try {
            int int5 = simpleTimePeriod2.compareTo((java.lang.Object) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day2.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass2);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 10);
        boolean boolean27 = day22.equals((java.lang.Object) 10);
        int int28 = day22.getMonth();
        java.util.Date date29 = day22.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass32 = seriesChangeEvent31.getClass();
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date33, timeZone34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass40 = seriesChangeEvent39.getClass();
        java.util.Date date41 = null;
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date41, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date37, timeZone42);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        java.util.Date date46 = year45.getEnd();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date46, timeZone47);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass51 = seriesChangeEvent50.getClass();
        java.util.Date date52 = null;
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone53);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date46, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date29, timeZone53);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent58 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass59 = seriesChangeEvent58.getClass();
        java.util.Date date60 = null;
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date60, timeZone61);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent66 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass67 = seriesChangeEvent66.getClass();
        java.util.Date date68 = null;
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date68, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date64, timeZone69);
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        java.util.Date date73 = year72.getEnd();
        java.util.TimeZone timeZone74 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date73, timeZone74);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent77 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass78 = seriesChangeEvent77.getClass();
        java.util.Date date79 = null;
        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass78, date79, timeZone80);
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date73, timeZone80);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent84 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass85 = seriesChangeEvent84.getClass();
        java.util.Date date86 = null;
        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass85, date86, timeZone87);
        org.jfree.data.time.Year year89 = new org.jfree.data.time.Year();
        java.util.Date date90 = year89.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent92 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass93 = seriesChangeEvent92.getClass();
        java.util.Date date94 = null;
        java.util.TimeZone timeZone95 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass93, date94, timeZone95);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass85, date90, timeZone95);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date73, timeZone95);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNotNull(timeZone80);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertNotNull(wildcardClass85);
        org.junit.Assert.assertNotNull(timeZone87);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertNotNull(date90);
        org.junit.Assert.assertNotNull(wildcardClass93);
        org.junit.Assert.assertNotNull(timeZone95);
        org.junit.Assert.assertNull(regularTimePeriod96);
        org.junit.Assert.assertNull(regularTimePeriod97);
        org.junit.Assert.assertNull(regularTimePeriod98);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "hi!", "");
        int int6 = timePeriodValues5.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 3, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        java.lang.String str4 = timePeriodValue3.toString();
        java.lang.String str5 = timePeriodValue3.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TimePeriodValue[2019,10]" + "'", str4.equals("TimePeriodValue[2019,10]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[2019,10]" + "'", str5.equals("TimePeriodValue[2019,10]"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        long long4 = day2.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int11 = day9.getDayOfMonth();
        boolean boolean12 = timePeriodValues3.equals((java.lang.Object) day9);
        java.util.Calendar calendar13 = null;
        try {
            day9.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("31-December-2019");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        boolean boolean4 = timePeriodValues3.getNotify();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (byte) 0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: hi!");
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("2019");
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues3.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setKey((java.lang.Comparable) (short) -1);
        java.lang.String str6 = timePeriodValues3.getDescription();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj8 = timePeriodValues3.clone();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues29.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener32);
        boolean boolean34 = day25.equals((java.lang.Object) seriesChangeListener32);
        java.util.Calendar calendar35 = null;
        try {
            day25.peg(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        int int4 = day2.getMonth();
        int int5 = day2.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("2019");
        try {
            java.lang.Number number9 = timePeriodValues3.getValue(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setKey((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getRangeDescription();
        int int9 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        java.util.Calendar calendar10 = null;
        try {
            day2.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        int int26 = day25.getYear();
        java.util.Calendar calendar27 = null;
        try {
            long long28 = day25.getFirstMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        java.lang.String str17 = timePeriodValues3.getRangeDescription();
        java.lang.String str18 = timePeriodValues3.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener19);
        try {
            org.jfree.data.time.TimePeriod timePeriod22 = timePeriodValues3.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        try {
            java.lang.Number number9 = timePeriodValues3.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("31-December-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        long long4 = day2.getLastMillisecond();
        int int5 = day2.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(43830L, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue3.getPeriod();
        java.lang.Object obj5 = timePeriodValue3.clone();
        java.lang.Object obj6 = timePeriodValue3.clone();
        java.lang.String str7 = timePeriodValue3.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[2019,10]" + "'", str7.equals("TimePeriodValue[2019,10]"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        int int14 = timePeriodValues13.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        try {
            timePeriodValues3.delete((int) (byte) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 0.0d);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0.0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=0.0]"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getEndMillis();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.Calendar calendar6 = null;
        try {
            year5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        boolean boolean4 = timePeriodValues3.getNotify();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int11 = day9.getDayOfMonth();
        boolean boolean12 = timePeriodValues3.equals((java.lang.Object) day9);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues3.createCopy((int) (byte) 10, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue3.getPeriod();
        java.lang.Object obj5 = timePeriodValue3.clone();
        boolean boolean7 = timePeriodValue3.equals((java.lang.Object) "2019");
        java.lang.Number number8 = timePeriodValue3.getValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10 + "'", number8.equals(10));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        int int7 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        int int7 = day2.compareTo((java.lang.Object) (byte) 10);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        boolean boolean4 = timePeriodValues3.getNotify();
        timePeriodValues3.setRangeDescription("2019");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        try {
            timePeriodValues3.update((int) (byte) -1, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        try {
            timePeriodValues3.update((int) (byte) 0, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue18 = timePeriodValues3.getDataItem(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(timePeriodValues16);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMinEndIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues3.getTimePeriod(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getDayOfMonth();
        java.util.Date date5 = day2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) 10);
        long long10 = year6.getFirstMillisecond();
        long long11 = year6.getSerialIndex();
        long long12 = year6.getFirstMillisecond();
        int int13 = day2.compareTo((java.lang.Object) long12);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day2.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        int int4 = day2.getMonth();
        int int5 = day2.getYear();
        long long6 = day2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577779200000L + "'", long6 == 1577779200000L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.Class<?> wildcardClass3 = date1.getClass();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        int int5 = year4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass28 = seriesChangeEvent27.getClass();
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass36 = seriesChangeEvent35.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date33, timeZone38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.util.Date date42 = year41.getEnd();
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date42, timeZone43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass28);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        java.util.Date date50 = year49.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year49, (java.lang.Number) 10);
        boolean boolean53 = day48.equals((java.lang.Object) 10);
        int int54 = day48.getMonth();
        java.util.Date date55 = day48.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent57 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass58 = seriesChangeEvent57.getClass();
        java.util.Date date59 = null;
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date59, timeZone60);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        java.util.Date date63 = year62.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass66 = seriesChangeEvent65.getClass();
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date67, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date63, timeZone68);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        java.util.Date date72 = year71.getEnd();
        java.util.TimeZone timeZone73 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date72, timeZone73);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent76 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass77 = seriesChangeEvent76.getClass();
        java.util.Date date78 = null;
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date78, timeZone79);
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date72, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date55, timeZone79);
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(date16, timeZone79);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent85 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass86 = seriesChangeEvent85.getClass();
        java.util.Date date87 = null;
        java.util.TimeZone timeZone88 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass86, date87, timeZone88);
        org.jfree.data.time.Year year90 = new org.jfree.data.time.Year();
        java.util.Date date91 = year90.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent93 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass94 = seriesChangeEvent93.getClass();
        java.util.Date date95 = null;
        java.util.TimeZone timeZone96 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass94, date95, timeZone96);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass86, date91, timeZone96);
        org.jfree.data.time.Year year99 = new org.jfree.data.time.Year(date16, timeZone96);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 12 + "'", int54 == 12);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(wildcardClass86);
        org.junit.Assert.assertNotNull(timeZone88);
        org.junit.Assert.assertNull(regularTimePeriod89);
        org.junit.Assert.assertNotNull(date91);
        org.junit.Assert.assertNotNull(wildcardClass94);
        org.junit.Assert.assertNotNull(timeZone96);
        org.junit.Assert.assertNull(regularTimePeriod97);
        org.junit.Assert.assertNull(regularTimePeriod98);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int11 = day9.getDayOfMonth();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day9, (double) 6L);
        java.util.Calendar calendar14 = null;
        try {
            day9.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        int int17 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        java.lang.Object obj14 = timePeriodValues13.clone();
        try {
            java.lang.Number number16 = timePeriodValues13.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 2, 1577865599999L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 2);
        java.lang.String str6 = timePeriodValue5.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[2019,2.0]" + "'", str6.equals("TimePeriodValue[2019,2.0]"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
        java.lang.Object obj9 = timePeriodValue7.clone();
        java.lang.Object obj10 = timePeriodValue7.clone();
        try {
            int int11 = simpleTimePeriod2.compareTo(obj10);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValue cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timePeriod8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue3.getPeriod();
        java.lang.String str5 = timePeriodValue3.toString();
        java.lang.String str6 = timePeriodValue3.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[2019,10]" + "'", str5.equals("TimePeriodValue[2019,10]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[2019,10]" + "'", str6.equals("TimePeriodValue[2019,10]"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int21 = timePeriodValues20.getMaxStartIndex();
        boolean boolean22 = timePeriodValues20.isEmpty();
        int int23 = day16.compareTo((java.lang.Object) timePeriodValues20);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day16, (double) 12);
        try {
            timePeriodValues3.update(9, (java.lang.Number) 43830L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long14 = simpleTimePeriod13.getStartMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        int int17 = year16.getYear();
        int int18 = day2.compareTo((java.lang.Object) year16);
        org.jfree.data.time.SerialDate serialDate19 = day2.getSerialDate();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = day2.getFirstMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 6L + "'", long14 == 6L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        int int11 = day10.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        timePeriodValues3.setKey((java.lang.Comparable) date9);
        try {
            timePeriodValues3.update(1969, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        int int4 = day2.getMonth();
        int int5 = day2.getYear();
        java.util.Calendar calendar6 = null;
        try {
            day2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass2);
        java.lang.Object obj20 = seriesChangeEvent19.getSource();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, 0.0d);
        int int9 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setKey((java.lang.Comparable) (short) -1);
        java.lang.String str6 = timePeriodValues3.getDescription();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        int int8 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day2.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "hi!", "");
        try {
            timePeriodValues5.delete(0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable throwable2 = null;
        try {
            seriesException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        java.lang.String str10 = day2.toString();
        int int11 = day2.getDayOfMonth();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day2.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getEndMillis();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) 1L);
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) '#');
        timePeriodValue7.setValue((java.lang.Number) 100.0f);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        java.lang.String str10 = day2.toString();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.lang.Class<?> wildcardClass14 = date12.getClass();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date12, timeZone15);
        boolean boolean17 = day2.equals((java.lang.Object) date12);
        java.util.Date date18 = day2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day2.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        int int26 = day25.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues30.addChangeListener(seriesChangeListener31);
        int int33 = timePeriodValues30.getMaxMiddleIndex();
        boolean boolean34 = day25.equals((java.lang.Object) timePeriodValues30);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue36 = timePeriodValues30.getDataItem((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Number number9 = null;
        try {
            timePeriodValues3.update(6, number9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        java.lang.String str10 = day2.toString();
        long long11 = day2.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 10);
        long long14 = year10.getFirstMillisecond();
        java.util.Date date15 = year10.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year10.next();
        boolean boolean17 = day2.equals((java.lang.Object) regularTimePeriod16);
        long long18 = day2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577822399999L + "'", long18 == 1577822399999L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long14 = simpleTimePeriod13.getStartMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        int int17 = year16.getYear();
        int int18 = day2.compareTo((java.lang.Object) year16);
        long long19 = year16.getFirstMillisecond();
        long long20 = year16.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 6L + "'", long14 == 6L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-31507200000L) + "'", long19 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-31507200000L) + "'", long20 == (-31507200000L));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        int int26 = day25.getYear();
        int int27 = day25.getDayOfMonth();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 31 + "'", int27 == 31);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        java.lang.String str6 = year0.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        java.lang.String str10 = day2.toString();
        int int11 = day2.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day2.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
        try {
            org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValues4.getTimePeriod((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setKey((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        try {
            timePeriodValues3.update((int) (short) 0, (java.lang.Number) 7L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,2.0]");
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        boolean boolean4 = timePeriodValues3.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int9 = timePeriodValues8.getMaxEndIndex();
        int int10 = timePeriodValues8.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues8.addChangeListener(seriesChangeListener11);
        java.lang.String str13 = timePeriodValues8.getDescription();
        timePeriodValues8.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = timePeriodValues8.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = timePeriodValues8.createCopy((int) (byte) 0, 3);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.Date date23 = year22.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year25, (java.lang.Number) 10);
        boolean boolean29 = day24.equals((java.lang.Object) 10);
        java.util.Date date30 = day24.getStart();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) 0.0d);
        try {
            int int33 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues8);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 6L + "'", long4 == 6L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(timePeriodValues18);
        org.junit.Assert.assertNotNull(timePeriodValues21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getDayOfMonth();
        java.util.Date date5 = day2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) 10);
        long long10 = year6.getFirstMillisecond();
        long long11 = year6.getSerialIndex();
        long long12 = year6.getFirstMillisecond();
        int int13 = day2.compareTo((java.lang.Object) long12);
        long long14 = day2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577822399999L + "'", long14 == 1577822399999L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 2);
        long long6 = year0.getLastMillisecond();
        int int7 = year0.getYear();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        int int7 = day2.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        boolean boolean14 = day2.equals((java.lang.Object) regularTimePeriod13);
        long long15 = day2.getFirstMillisecond();
        java.lang.String str16 = day2.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577779200000L + "'", long15 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31-December-2019" + "'", str16.equals("31-December-2019"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getDayOfMonth();
        java.util.Date date5 = day2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        boolean boolean4 = timePeriodValues3.getNotify();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 10);
        long long12 = year8.getFirstMillisecond();
        long long13 = year8.getSerialIndex();
        long long14 = year8.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 1L);
        int int17 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        int int4 = day2.getMonth();
        int int5 = day2.getYear();
        long long6 = day2.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43830L + "'", long6 == 43830L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getSerialIndex();
        long long3 = year0.getFirstMillisecond();
        boolean boolean5 = year0.equals((java.lang.Object) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        boolean boolean11 = year0.equals((java.lang.Object) year10);
        java.util.Calendar calendar12 = null;
        try {
            year0.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        java.lang.String str10 = day2.toString();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.lang.Class<?> wildcardClass14 = date12.getClass();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date12, timeZone15);
        boolean boolean17 = day2.equals((java.lang.Object) date12);
        int int18 = day2.getDayOfMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 31 + "'", int18 == 31);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        boolean boolean4 = timePeriodValues3.getNotify();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        timePeriodValues3.setRangeDescription("TimePeriodValue[2019,10]");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) 0L);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue16 = timePeriodValues3.getDataItem((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1546329600000L, 7L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 6L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        java.lang.Comparable comparable5 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0d) + "'", comparable5.equals((-1.0d)));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (java.lang.Number) 10);
        boolean boolean24 = day19.equals((java.lang.Object) 10);
        java.util.Date date25 = day19.getStart();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 0.0d);
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
        timePeriodValues3.add(timePeriodValue7);
        java.lang.String str10 = timePeriodValue7.toString();
        timePeriodValue7.setValue((java.lang.Number) 1L);
        java.lang.Number number13 = timePeriodValue7.getValue();
        timePeriodValue7.setValue((java.lang.Number) (byte) 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timePeriod8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,10]" + "'", str10.equals("TimePeriodValue[2019,10]"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1L + "'", number13.equals(1L));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long14 = simpleTimePeriod13.getStartMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        int int17 = year16.getYear();
        int int18 = day2.compareTo((java.lang.Object) year16);
        long long19 = year16.getFirstMillisecond();
        long long20 = year16.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 6L + "'", long14 == 6L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-31507200000L) + "'", long19 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28799999L + "'", long20 == 28799999L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj5 = timePeriodValues3.clone();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getDayOfMonth();
        long long5 = day2.getSerialIndex();
        long long6 = day2.getSerialIndex();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43830L + "'", long5 == 43830L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43830L + "'", long6 == 43830L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setNotify(true);
        int int8 = timePeriodValues3.getMinStartIndex();
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int21 = timePeriodValues20.getMaxStartIndex();
        boolean boolean22 = timePeriodValues20.isEmpty();
        int int23 = day16.compareTo((java.lang.Object) timePeriodValues20);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day16, (double) 12);
        long long26 = day16.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) ' ', (long) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getStart();
        java.lang.Object obj6 = null;
        int int7 = year4.compareTo(obj6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setKey((java.lang.Comparable) (short) -1);
        java.lang.String str6 = timePeriodValues3.getDescription();
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        java.util.Calendar calendar12 = null;
        try {
            day11.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        java.lang.Class<?> wildcardClass12 = serialDate10.getClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "hi!", "");
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        long long7 = simpleTimePeriod2.getEndMillis();
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = simpleTimePeriod2.compareTo((java.lang.Object) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 12);
        java.lang.String str13 = timePeriodValues12.getRangeDescription();
        int int14 = timePeriodValues12.getMinStartIndex();
        int int15 = year9.compareTo((java.lang.Object) timePeriodValues12);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        boolean boolean4 = timePeriodValues3.getNotify();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int8 = timePeriodValues3.getItemCount();
        try {
            org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues3.getTimePeriod((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue3.getPeriod();
        java.lang.Object obj5 = timePeriodValue3.clone();
        boolean boolean7 = timePeriodValue3.equals((java.lang.Object) "2019");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        boolean boolean12 = timePeriodValue3.equals((java.lang.Object) regularTimePeriod11);
        java.lang.Number number13 = timePeriodValue3.getValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10 + "'", number13.equals(10));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        boolean boolean5 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0L);
        java.util.Date date8 = year0.getStart();
        java.lang.String str9 = year0.toString();
        java.util.Calendar calendar10 = null;
        try {
            year0.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long14 = simpleTimePeriod13.getStartMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        int int17 = year16.getYear();
        int int18 = day2.compareTo((java.lang.Object) year16);
        org.jfree.data.time.SerialDate serialDate19 = day2.getSerialDate();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 6L + "'", long14 == 6L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 11, (long) '4');
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
        timePeriodValues3.add(timePeriodValue7);
        int int10 = timePeriodValues3.getMaxStartIndex();
        int int11 = timePeriodValues3.getMaxEndIndex();
        boolean boolean12 = timePeriodValues3.getNotify();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 12);
        java.lang.String str7 = timePeriodValues6.getRangeDescription();
        java.lang.Comparable comparable8 = timePeriodValues6.getKey();
        boolean boolean9 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues6);
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues6.getTimePeriod(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 12 + "'", comparable8.equals(12));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass28 = seriesChangeEvent27.getClass();
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass36 = seriesChangeEvent35.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date33, timeZone38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.util.Date date42 = year41.getEnd();
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date42, timeZone43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass28);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        java.util.Date date50 = year49.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year49, (java.lang.Number) 10);
        boolean boolean53 = day48.equals((java.lang.Object) 10);
        int int54 = day48.getMonth();
        java.util.Date date55 = day48.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent57 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass58 = seriesChangeEvent57.getClass();
        java.util.Date date59 = null;
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date59, timeZone60);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        java.util.Date date63 = year62.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass66 = seriesChangeEvent65.getClass();
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date67, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date63, timeZone68);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        java.util.Date date72 = year71.getEnd();
        java.util.TimeZone timeZone73 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date72, timeZone73);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent76 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass77 = seriesChangeEvent76.getClass();
        java.util.Date date78 = null;
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date78, timeZone79);
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date72, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date55, timeZone79);
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(date16, timeZone79);
        java.util.Calendar calendar84 = null;
        try {
            long long85 = year83.getFirstMillisecond(calendar84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 12 + "'", int54 == 12);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod82);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue3.getPeriod();
        java.lang.Object obj5 = timePeriodValue3.clone();
        timePeriodValue3.setValue((java.lang.Number) 10.0d);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue3.getPeriod();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(timePeriod8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues29.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener32);
        boolean boolean34 = day25.equals((java.lang.Object) seriesChangeListener32);
        long long35 = day25.getLastMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        java.lang.String str10 = day2.toString();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.lang.Class<?> wildcardClass14 = date12.getClass();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date12, timeZone15);
        boolean boolean17 = day2.equals((java.lang.Object) date12);
        java.util.Date date18 = day2.getEnd();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = day2.getMiddleMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getItemCount();
        int int7 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        long long3 = year2.getSerialIndex();
        java.util.Date date4 = year2.getEnd();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,10]");
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
        timePeriodValues3.add(timePeriodValue7);
        int int10 = timePeriodValues3.getMaxStartIndex();
        int int11 = timePeriodValues3.getMaxEndIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValues3.getTimePeriod(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue6 = timePeriodValues3.getDataItem((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 8);
        java.lang.Number number4 = timePeriodValue3.getValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 8 + "'", number4.equals(8));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        int int5 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,2.0]");
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0d, "31-December-2019", "2019");
        boolean boolean4 = timePeriodValues3.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int9 = timePeriodValues8.getMaxEndIndex();
        int int10 = timePeriodValues8.getMinMiddleIndex();
        int int11 = timePeriodValues8.getMaxStartIndex();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.String str15 = day14.toString();
        int int16 = day14.getDayOfMonth();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day14, (double) 6L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 3);
        java.util.Calendar calendar21 = null;
        try {
            day14.peg(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31-December-2019" + "'", str15.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (java.lang.Number) 10);
        boolean boolean24 = day19.equals((java.lang.Object) 10);
        java.util.Date date25 = day19.getStart();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 0.0d);
        long long28 = day19.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577779200000L + "'", long28 == 1577779200000L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0d, "31-December-2019", "2019");
        boolean boolean4 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        try {
            timePeriodValues3.delete(11, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        int int7 = day2.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        boolean boolean14 = day2.equals((java.lang.Object) regularTimePeriod13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day2.previous();
        long long16 = day2.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43830L + "'", long16 == 43830L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        try {
            int int7 = simpleTimePeriod2.compareTo((java.lang.Object) 43830L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass28 = seriesChangeEvent27.getClass();
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass36 = seriesChangeEvent35.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date33, timeZone38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.util.Date date42 = year41.getEnd();
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date42, timeZone43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass28);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        java.util.Date date50 = year49.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year49, (java.lang.Number) 10);
        boolean boolean53 = day48.equals((java.lang.Object) 10);
        int int54 = day48.getMonth();
        java.util.Date date55 = day48.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent57 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass58 = seriesChangeEvent57.getClass();
        java.util.Date date59 = null;
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date59, timeZone60);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        java.util.Date date63 = year62.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass66 = seriesChangeEvent65.getClass();
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date67, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date63, timeZone68);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        java.util.Date date72 = year71.getEnd();
        java.util.TimeZone timeZone73 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date72, timeZone73);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent76 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass77 = seriesChangeEvent76.getClass();
        java.util.Date date78 = null;
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date78, timeZone79);
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date72, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date55, timeZone79);
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(date16, timeZone79);
        org.jfree.data.time.TimePeriodValues timePeriodValues85 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "31-December-2019");
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year();
        java.util.Date date87 = year86.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue89 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year86, (java.lang.Number) 10);
        long long90 = year86.getFirstMillisecond();
        long long91 = year86.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue93 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year86, (java.lang.Number) 0L);
        java.util.Date date94 = year86.getStart();
        java.lang.String str95 = year86.toString();
        timePeriodValues85.setKey((java.lang.Comparable) year86);
        int int97 = year83.compareTo((java.lang.Object) year86);
        long long98 = year83.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 12 + "'", int54 == 12);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1546329600000L + "'", long90 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 2019L + "'", long91 == 2019L);
        org.junit.Assert.assertNotNull(date94);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "2019" + "'", str95.equals("2019"));
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
        org.junit.Assert.assertTrue("'" + long98 + "' != '" + 2019L + "'", long98 == 2019L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        int int5 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setDescription("");
        int int8 = timePeriodValues3.getMinStartIndex();
        try {
            timePeriodValues3.update(3, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues29.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener32);
        boolean boolean34 = day25.equals((java.lang.Object) seriesChangeListener32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day25.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day25, "", "TimePeriodValue[2019,10]");
        timePeriodValues38.setRangeDescription("31-December-2019");
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timePeriodValues38.addPropertyChangeListener(propertyChangeListener41);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long14 = simpleTimePeriod13.getStartMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        int int17 = year16.getYear();
        int int18 = day2.compareTo((java.lang.Object) year16);
        org.jfree.data.time.SerialDate serialDate19 = day2.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day2.next();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 10);
        boolean boolean28 = day23.equals((java.lang.Object) 10);
        int int29 = day23.getMonth();
        java.util.Date date30 = day23.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.util.Date date32 = year31.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (java.lang.Number) 10);
        long long35 = year31.getFirstMillisecond();
        java.util.Date date36 = year31.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year31.next();
        boolean boolean38 = day23.equals((java.lang.Object) regularTimePeriod37);
        boolean boolean39 = day2.equals((java.lang.Object) boolean38);
        java.util.Calendar calendar40 = null;
        try {
            long long41 = day2.getLastMillisecond(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 6L + "'", long14 == 6L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("1969");
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("2019");
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 12);
        java.lang.String str7 = timePeriodValues6.getRangeDescription();
        java.lang.Comparable comparable8 = timePeriodValues6.getKey();
        boolean boolean9 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues6);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues13.addChangeListener(seriesChangeListener14);
        timePeriodValues13.setNotify(true);
        boolean boolean18 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues13);
        int int19 = timePeriodValues13.getItemCount();
        try {
            org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValues13.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 12 + "'", comparable8.equals(12));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long14 = simpleTimePeriod13.getStartMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        int int17 = year16.getYear();
        int int18 = day2.compareTo((java.lang.Object) year16);
        long long19 = year16.getFirstMillisecond();
        java.util.Calendar calendar20 = null;
        try {
            year16.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 6L + "'", long14 == 6L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-31507200000L) + "'", long19 == (-31507200000L));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0L);
        java.util.Date date8 = year0.getStart();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year0.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) 0 + "'", obj3.equals((byte) 0));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        long long6 = year0.getLastMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        long long11 = day9.getSerialIndex();
        boolean boolean12 = year0.equals((java.lang.Object) day9);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day9);
        java.lang.String str14 = seriesChangeEvent13.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43830L + "'", long11 == 43830L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=31-December-2019]" + "'", str14.equals("org.jfree.data.general.SeriesChangeEvent[source=31-December-2019]"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean13 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "hi!", "");
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        long long7 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass18 = seriesChangeEvent17.getClass();
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date15, timeZone20);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        boolean boolean24 = simpleTimePeriod2.equals((java.lang.Object) class23);
        java.util.Date date25 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues29.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener32);
        boolean boolean34 = timePeriodValues29.isEmpty();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        java.util.Date date36 = year35.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year35, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod39 = timePeriodValue38.getPeriod();
        java.lang.Object obj40 = timePeriodValue38.clone();
        boolean boolean42 = timePeriodValue38.equals((java.lang.Object) "2019");
        timePeriodValues29.add(timePeriodValue38);
        int int44 = timePeriodValues29.getMinStartIndex();
        try {
            int int45 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues29);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timePeriod39);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getEndMillis();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) 1L);
        long long6 = simpleTimePeriod2.getStartMillis();
        long long7 = simpleTimePeriod2.getStartMillis();
        java.util.Date date8 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 10);
        boolean boolean16 = day11.equals((java.lang.Object) 10);
        int int17 = day11.getMonth();
        java.util.Date date18 = day11.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date8, date18);
        java.util.Date date20 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date8, date20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 6L + "'", long6 == 6L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 6L + "'", long7 == 6L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0L);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues15.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues15.removeChangeListener(seriesChangeListener18);
        int int20 = year10.compareTo((java.lang.Object) seriesChangeListener18);
        int int21 = year0.compareTo((java.lang.Object) seriesChangeListener18);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        java.util.Date date5 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        long long7 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 0.0d);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 0.0d + "'", obj2.equals(0.0d));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
        timePeriodValues3.add(timePeriodValue7);
        try {
            timePeriodValues3.update((int) (byte) 1, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timePeriod8);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        java.lang.String str17 = timePeriodValues3.getDomainDescription();
        java.lang.Class<?> wildcardClass18 = timePeriodValues3.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        int int26 = day25.getYear();
        long long27 = day25.getFirstMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577779200000L + "'", long27 == 1577779200000L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        long long3 = year2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long14 = simpleTimePeriod13.getStartMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        int int17 = year16.getYear();
        int int18 = day2.compareTo((java.lang.Object) year16);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int23 = timePeriodValues22.getMaxEndIndex();
        int int24 = timePeriodValues22.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timePeriodValues22.addChangeListener(seriesChangeListener25);
        java.lang.String str27 = timePeriodValues22.getDescription();
        timePeriodValues22.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = timePeriodValues22.createCopy(8, (int) (byte) 10);
        boolean boolean33 = timePeriodValues32.isEmpty();
        boolean boolean34 = timePeriodValues32.isEmpty();
        int int35 = year16.compareTo((java.lang.Object) boolean34);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 6L + "'", long14 == 6L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(timePeriodValues32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date1);
        timePeriodValues3.setRangeDescription("TimePeriodValue[2019,2.0]");
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 1, (long) 9);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int21 = timePeriodValues20.getMaxStartIndex();
        boolean boolean22 = timePeriodValues20.isEmpty();
        int int23 = day16.compareTo((java.lang.Object) timePeriodValues20);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day16, (double) 12);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = day16.getLastMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0d, "31-December-2019", "2019");
        boolean boolean4 = timePeriodValues3.isEmpty();
        try {
            java.lang.Number number6 = timePeriodValues3.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        org.jfree.data.time.SerialDate serialDate26 = day25.getSerialDate();
        int int27 = day25.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day25.next();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 31 + "'", int27 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getDayOfMonth();
        java.lang.Object obj5 = null;
        int int6 = day2.compareTo(obj5);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.Class<?> wildcardClass3 = date1.getClass();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (java.lang.Number) 10);
        long long9 = year5.getFirstMillisecond();
        java.util.Date date10 = year5.getStart();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date1, date10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        org.jfree.data.time.SerialDate serialDate26 = day25.getSerialDate();
        int int27 = day25.getMonth();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues29.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener32);
        boolean boolean34 = day25.equals((java.lang.Object) seriesChangeListener32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day25.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day25, "", "TimePeriodValue[2019,10]");
        timePeriodValues38.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
        int int41 = timePeriodValues38.getMinStartIndex();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 2);
        java.lang.String str6 = year0.toString();
        long long7 = year0.getSerialIndex();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue3.getPeriod();
        java.lang.Number number5 = timePeriodValue3.getValue();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues9.addChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues9.getMaxMiddleIndex();
        timePeriodValues9.fireSeriesChanged();
        boolean boolean14 = timePeriodValue3.equals((java.lang.Object) timePeriodValues9);
        java.lang.String str15 = timePeriodValue3.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10 + "'", number5.equals(10));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TimePeriodValue[2019,10]" + "'", str15.equals("TimePeriodValue[2019,10]"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        int int14 = timePeriodValues3.getMinEndIndex();
        int int15 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0d, "31-December-2019", "2019");
        int int4 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int10 = timePeriodValues9.getMaxStartIndex();
        boolean boolean11 = timePeriodValues9.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues9.removePropertyChangeListener(propertyChangeListener12);
        boolean boolean14 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues9);
        java.lang.Object obj15 = null;
        boolean boolean16 = simpleTimePeriod2.equals(obj15);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
        timePeriodValues3.add(timePeriodValue7);
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) str10);
        java.lang.Object obj12 = seriesChangeEvent11.getSource();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timePeriod8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + obj12 + "' != '" + "" + "'", obj12.equals(""));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int10 = timePeriodValues9.getMaxStartIndex();
        boolean boolean11 = timePeriodValues9.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues9.removePropertyChangeListener(propertyChangeListener12);
        boolean boolean14 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues9);
        try {
            java.lang.Number number16 = timePeriodValues9.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMinEndIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValues1.getTimePeriod((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        int int6 = timePeriodValues3.getMaxStartIndex();
        int int7 = timePeriodValues3.getMinMiddleIndex();
        int int8 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        long long6 = year0.getLastMillisecond();
        long long7 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long7);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(7, 9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        int int26 = day25.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues30.addChangeListener(seriesChangeListener31);
        int int33 = timePeriodValues30.getMaxMiddleIndex();
        boolean boolean34 = day25.equals((java.lang.Object) timePeriodValues30);
        java.util.Calendar calendar35 = null;
        try {
            long long36 = day25.getMiddleMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day2);
        java.util.Calendar calendar7 = null;
        try {
            day2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        try {
            timePeriodValues3.update((int) (byte) 100, (java.lang.Number) (-31507200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "hi!", "");
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        java.lang.String str10 = day2.toString();
        java.util.Calendar calendar11 = null;
        try {
            day2.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        timePeriodValues13.setDomainDescription("31-December-2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues19.setNotify(false);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year22, 0.0d);
        timePeriodValues13.setKey((java.lang.Comparable) year22);
        timePeriodValues13.setDescription("1969");
        try {
            java.lang.Number number29 = timePeriodValues13.getValue(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getEndMillis();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) 1L);
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) '#');
        try {
            int int9 = simpleTimePeriod2.compareTo((java.lang.Object) "org.jfree.data.general.SeriesChangeEvent[source=31-December-2019]");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        boolean boolean8 = timePeriodValues3.isEmpty();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue12.getPeriod();
        java.lang.Object obj14 = timePeriodValue12.clone();
        boolean boolean16 = timePeriodValue12.equals((java.lang.Object) "2019");
        timePeriodValues3.add(timePeriodValue12);
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
        int int20 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timePeriod13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 12);
        java.lang.String str2 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.fireSeriesChanged();
        int int4 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 12);
        java.lang.String str7 = timePeriodValues6.getRangeDescription();
        java.lang.Comparable comparable8 = timePeriodValues6.getKey();
        boolean boolean9 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues6);
        boolean boolean11 = simpleTimePeriod2.equals((java.lang.Object) (byte) 10);
        java.util.Date date12 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 12 + "'", comparable8.equals(12));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        java.util.Date date5 = year4.getEnd();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 6L + "'", long5 == 6L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "hi!", "");
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        long long7 = simpleTimePeriod2.getEndMillis();
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = simpleTimePeriod2.compareTo((java.lang.Object) year9);
        long long11 = year9.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[2019,10]");
        timePeriodValues3.setNotify(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("2019");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) 9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 3);
        boolean boolean14 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setKey((java.lang.Comparable) (short) -1);
        java.lang.String str6 = timePeriodValues3.getDescription();
        timePeriodValues3.fireSeriesChanged();
        try {
            java.lang.Number number9 = timePeriodValues3.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        boolean boolean4 = timePeriodValues3.getNotify();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        timePeriodValues3.fireSeriesChanged();
        int int9 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
        timePeriodValues3.add(timePeriodValue7);
        java.lang.String str10 = timePeriodValue7.toString();
        timePeriodValue7.setValue((java.lang.Number) 1L);
        java.lang.String str13 = timePeriodValue7.toString();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timePeriod8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,10]" + "'", str10.equals("TimePeriodValue[2019,10]"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[2019,1]" + "'", str13.equals("TimePeriodValue[2019,1]"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass28 = seriesChangeEvent27.getClass();
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass36 = seriesChangeEvent35.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date33, timeZone38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.util.Date date42 = year41.getEnd();
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date42, timeZone43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass28);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        java.util.Date date50 = year49.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year49, (java.lang.Number) 10);
        boolean boolean53 = day48.equals((java.lang.Object) 10);
        int int54 = day48.getMonth();
        java.util.Date date55 = day48.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent57 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass58 = seriesChangeEvent57.getClass();
        java.util.Date date59 = null;
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date59, timeZone60);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        java.util.Date date63 = year62.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass66 = seriesChangeEvent65.getClass();
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date67, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date63, timeZone68);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        java.util.Date date72 = year71.getEnd();
        java.util.TimeZone timeZone73 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date72, timeZone73);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent76 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass77 = seriesChangeEvent76.getClass();
        java.util.Date date78 = null;
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date78, timeZone79);
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date72, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date55, timeZone79);
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(date16, timeZone79);
        org.jfree.data.time.TimePeriodValues timePeriodValues85 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "31-December-2019");
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year();
        java.util.Date date87 = year86.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue89 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year86, (java.lang.Number) 10);
        long long90 = year86.getFirstMillisecond();
        long long91 = year86.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue93 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year86, (java.lang.Number) 0L);
        java.util.Date date94 = year86.getStart();
        java.lang.String str95 = year86.toString();
        timePeriodValues85.setKey((java.lang.Comparable) year86);
        int int97 = year83.compareTo((java.lang.Object) year86);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent98 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) int97);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 12 + "'", int54 == 12);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1546329600000L + "'", long90 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 2019L + "'", long91 == 2019L);
        org.junit.Assert.assertNotNull(date94);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "2019" + "'", str95.equals("2019"));
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMinEndIndex();
        try {
            timePeriodValues3.update((int) ' ', (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        long long6 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 6L + "'", long6 == 6L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate10);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMaxStartIndex();
        java.lang.Class<?> wildcardClass6 = timePeriodValues3.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 10);
        boolean boolean15 = day10.equals((java.lang.Object) 10);
        int int16 = day10.getMonth();
        java.util.Date date17 = day10.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date17, timeZone18);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date17, "TimePeriodValue[2019,10]", "org.jfree.data.time.TimePeriodFormatException: 31-December-2019");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        int int6 = timePeriodValues3.getMaxStartIndex();
        int int7 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDomainDescription("31-December-2019");
        java.lang.String str10 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy(0, 1);
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        java.lang.String str10 = day2.toString();
        int int11 = day2.getDayOfMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues15.setKey((java.lang.Comparable) (short) -1);
        java.lang.String str18 = timePeriodValues15.getDescription();
        java.lang.String str19 = timePeriodValues15.getDomainDescription();
        int int20 = day2.compareTo((java.lang.Object) str19);
        int int21 = day2.getDayOfMonth();
        java.util.Calendar calendar22 = null;
        try {
            day2.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 31 + "'", int21 == 31);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        java.util.Calendar calendar8 = null;
        try {
            year5.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        int int6 = timePeriodValues3.getMaxStartIndex();
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0L);
        java.util.Date date8 = year0.getStart();
        java.util.Calendar calendar9 = null;
        try {
            year0.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
        timePeriodValues3.add(timePeriodValue7);
        int int10 = timePeriodValues3.getMaxStartIndex();
        int int11 = timePeriodValues3.getMaxEndIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValues3.getTimePeriod(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "hi!", "");
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        long long7 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass18 = seriesChangeEvent17.getClass();
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date15, timeZone20);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        boolean boolean24 = simpleTimePeriod2.equals((java.lang.Object) class23);
        long long25 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 7L + "'", long25 == 7L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj5 = timePeriodValues3.clone();
        int int6 = timePeriodValues3.getItemCount();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long10 = simpleTimePeriod9.getEndMillis();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod9, (double) (byte) 10);
        try {
            int int14 = simpleTimePeriod9.compareTo((java.lang.Object) 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 7L + "'", long10 == 7L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(3, 0, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        java.util.Date date8 = day2.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass12 = seriesChangeEvent11.getClass();
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass20 = seriesChangeEvent19.getClass();
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date17, timeZone22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getEnd();
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date26, timeZone27);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass12);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.util.Date date31 = year30.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.util.Date date34 = year33.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 10);
        boolean boolean37 = day32.equals((java.lang.Object) 10);
        int int38 = day32.getMonth();
        java.util.Date date39 = day32.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass42 = seriesChangeEvent41.getClass();
        java.util.Date date43 = null;
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date43, timeZone44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent49 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass50 = seriesChangeEvent49.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date47, timeZone52);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        java.util.Date date56 = year55.getEnd();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date56, timeZone57);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent60 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass61 = seriesChangeEvent60.getClass();
        java.util.Date date62 = null;
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date62, timeZone63);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date56, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date39, timeZone63);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod67 = new org.jfree.data.time.SimpleTimePeriod(date8, date39);
        java.util.Date date68 = simpleTimePeriod67.getStart();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(date68);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '4', 3, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'day' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        java.lang.String str10 = day2.toString();
        int int11 = day2.getDayOfMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues15.setKey((java.lang.Comparable) (short) -1);
        java.lang.String str18 = timePeriodValues15.getDescription();
        java.lang.String str19 = timePeriodValues15.getDomainDescription();
        int int20 = day2.compareTo((java.lang.Object) str19);
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day2.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener14);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue3.getPeriod();
        timePeriodValue3.setValue((java.lang.Number) 0.0d);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 10);
        boolean boolean14 = day9.equals((java.lang.Object) 10);
        int int15 = day9.getMonth();
        java.util.Date date16 = day9.getStart();
        boolean boolean17 = timePeriodValue3.equals((java.lang.Object) date16);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getEnd();
        boolean boolean11 = day2.equals((java.lang.Object) ' ');
        long long12 = day2.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day2, "org.jfree.data.general.SeriesChangeEvent[source=0.0]", "TimePeriodValue[2019,2.0]");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577779200000L + "'", long12 == 1577779200000L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("31-December-2019");
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
        java.lang.String str7 = year6.toString();
        long long8 = year6.getFirstMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year6.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969" + "'", str7.equals("1969"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-31507200000L) + "'", long8 == (-31507200000L));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        int int7 = day2.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        boolean boolean14 = day2.equals((java.lang.Object) regularTimePeriod13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day2.previous();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = day2.getMiddleMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        int int26 = day25.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues30.addChangeListener(seriesChangeListener31);
        int int33 = timePeriodValues30.getMaxMiddleIndex();
        boolean boolean34 = day25.equals((java.lang.Object) timePeriodValues30);
        timePeriodValues30.setDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.String str37 = timePeriodValues30.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = timePeriodValues30.createCopy((int) 'a', 5);
        timePeriodValues30.fireSeriesChanged();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(timePeriodValues40);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("2019");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) 9);
        boolean boolean12 = timePeriodValues3.isEmpty();
        int int13 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getEnd();
        boolean boolean11 = day2.equals((java.lang.Object) ' ');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass14 = seriesChangeEvent13.getClass();
        java.lang.String str15 = seriesChangeEvent13.toString();
        boolean boolean16 = day2.equals((java.lang.Object) str15);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str15.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("2019");
        timePeriodValues3.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues3.createCopy(1, 100);
        try {
            timePeriodValues12.update((int) (short) 100, (java.lang.Number) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues12);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int11 = day9.getDayOfMonth();
        boolean boolean12 = timePeriodValues3.equals((java.lang.Object) day9);
        try {
            java.lang.Number number14 = timePeriodValues3.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        long long6 = year0.getLastMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        long long11 = day9.getSerialIndex();
        boolean boolean12 = year0.equals((java.lang.Object) day9);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day9);
        long long14 = day9.getSerialIndex();
        java.util.Calendar calendar15 = null;
        try {
            day9.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43830L + "'", long11 == 43830L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43830L + "'", long14 == 43830L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 3);
        java.lang.String str14 = timePeriodValues3.getDomainDescription();
        int int15 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        boolean boolean4 = timePeriodValues3.getNotify();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        long long6 = year0.getFirstMillisecond();
        long long7 = year0.getMiddleMillisecond();
        int int8 = year0.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMaxStartIndex();
        java.lang.Class<?> wildcardClass6 = timePeriodValues3.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 10);
        boolean boolean15 = day10.equals((java.lang.Object) 10);
        int int16 = day10.getMonth();
        java.util.Date date17 = day10.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date17, timeZone18);
        java.util.Date date20 = regularTimePeriod19.getStart();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMinEndIndex();
        int int7 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        int int4 = day2.getMonth();
        int int5 = day2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
        long long7 = day2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577822399999L + "'", long7 == 1577822399999L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getDayOfMonth();
        java.util.Date date5 = day2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) 10);
        long long10 = year6.getFirstMillisecond();
        long long11 = year6.getSerialIndex();
        long long12 = year6.getFirstMillisecond();
        int int13 = day2.compareTo((java.lang.Object) long12);
        long long14 = day2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577779200000L + "'", long14 == 1577779200000L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        boolean boolean14 = timePeriodValues13.isEmpty();
        java.lang.String str15 = timePeriodValues13.getDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        int int5 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setDescription("");
        int int8 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue12.getPeriod();
        java.lang.Object obj14 = timePeriodValue12.clone();
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) timePeriodValue12);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue17 = timePeriodValues3.getDataItem((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timePeriod13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod9, "hi!", "");
        java.util.Date date13 = simpleTimePeriod9.getEnd();
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod9);
        java.lang.Class<?> wildcardClass15 = simpleTimePeriod9.getClass();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        java.util.Date date4 = year2.getStart();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        java.lang.Object obj8 = null;
        int int9 = year5.compareTo(obj8);
        int int10 = year5.getYear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getItemCount();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue12.getPeriod();
        java.lang.Object obj14 = timePeriodValue12.clone();
        java.lang.Number number15 = timePeriodValue12.getValue();
        timePeriodValues3.add(timePeriodValue12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timePeriod13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10 + "'", number15.equals(10));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        timePeriodValues16.setNotify(true);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue20 = timePeriodValues16.getDataItem(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(timePeriodValues16);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("2019");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener10);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMaxStartIndex();
        java.lang.Class<?> wildcardClass6 = timePeriodValues3.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize(class7);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize(class8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.lang.Class<?> wildcardClass8 = date6.getClass();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date3, timeZone9);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day11.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        java.util.Date date8 = day2.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass15 = seriesChangeEvent14.getClass();
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.Date date20 = year19.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass23 = seriesChangeEvent22.getClass();
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date20, timeZone25);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.util.Date date29 = year28.getEnd();
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date29, timeZone30);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass34 = seriesChangeEvent33.getClass();
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date35, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date29, timeZone36);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date10, timeZone36);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass42 = seriesChangeEvent41.getClass();
        java.util.Date date43 = null;
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date43, timeZone44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent49 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass50 = seriesChangeEvent49.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date47, timeZone52);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        java.util.Date date56 = year55.getEnd();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date56, timeZone57);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent59 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass42);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        java.util.Date date61 = year60.getEnd();
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        java.util.Date date64 = year63.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year63, (java.lang.Number) 10);
        boolean boolean67 = day62.equals((java.lang.Object) 10);
        int int68 = day62.getMonth();
        java.util.Date date69 = day62.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent71 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass72 = seriesChangeEvent71.getClass();
        java.util.Date date73 = null;
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date73, timeZone74);
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year();
        java.util.Date date77 = year76.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent79 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass80 = seriesChangeEvent79.getClass();
        java.util.Date date81 = null;
        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass80, date81, timeZone82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date77, timeZone82);
        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year();
        java.util.Date date86 = year85.getEnd();
        java.util.TimeZone timeZone87 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date86, timeZone87);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent90 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass91 = seriesChangeEvent90.getClass();
        java.util.Date date92 = null;
        java.util.TimeZone timeZone93 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass91, date92, timeZone93);
        org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(date86, timeZone93);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date69, timeZone93);
        org.jfree.data.time.Year year97 = new org.jfree.data.time.Year(date10, timeZone93);
        org.jfree.data.time.Year year98 = new org.jfree.data.time.Year(date8, timeZone93);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 12 + "'", int68 == 12);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertNotNull(wildcardClass91);
        org.junit.Assert.assertNotNull(timeZone93);
        org.junit.Assert.assertNull(regularTimePeriod94);
        org.junit.Assert.assertNull(regularTimePeriod96);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
        int int4 = day2.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getItemCount();
        boolean boolean9 = timePeriodValues3.getNotify();
        try {
            java.lang.Number number11 = timePeriodValues3.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getSerialIndex();
        java.lang.String str3 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
        timePeriodValues3.add(timePeriodValue7);
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timePeriod8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        int int5 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setDescription("");
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: 31-December-2019");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        boolean boolean4 = timePeriodValues3.getNotify();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(6, 31);
        int int10 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj11 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue3.getPeriod();
        java.lang.Number number5 = null;
        timePeriodValue3.setValue(number5);
        java.lang.Object obj7 = timePeriodValue3.clone();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 31, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        long long12 = day11.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0L);
        java.util.Date date8 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        java.lang.String str17 = timePeriodValues3.getDomainDescription();
        int int18 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Calendar calendar5 = null;
        try {
            year4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        int int7 = day2.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        boolean boolean14 = day2.equals((java.lang.Object) regularTimePeriod13);
        long long15 = day2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day2.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577779200000L + "'", long15 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        try {
            timePeriodValues3.delete(0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        org.jfree.data.time.SerialDate serialDate26 = day25.getSerialDate();
        org.jfree.data.time.SerialDate serialDate27 = day25.getSerialDate();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        java.lang.Object obj4 = null;
        int int5 = day2.compareTo(obj4);
        java.lang.String str6 = day2.toString();
        int int7 = day2.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getSerialIndex();
        long long3 = year0.getFirstMillisecond();
        boolean boolean5 = year0.equals((java.lang.Object) (-1.0d));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        boolean boolean11 = year0.equals((java.lang.Object) year10);
        java.lang.String str12 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        java.lang.String str6 = year0.toString();
        int int7 = year0.getYear();
        long long8 = year0.getFirstMillisecond();
        int int9 = year0.getYear();
        java.util.Calendar calendar10 = null;
        try {
            year0.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 2);
        java.lang.String str6 = year0.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "1969", "TimePeriodValue[2019,1]");
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year0.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMaxStartIndex();
        java.lang.Class<?> wildcardClass6 = timePeriodValues3.getClass();
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues3.getTimePeriod((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (java.lang.Number) 10);
        boolean boolean24 = day19.equals((java.lang.Object) 10);
        java.util.Date date25 = day19.getStart();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 0.0d);
        java.lang.String str28 = day19.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "31-December-2019" + "'", str28.equals("31-December-2019"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        timePeriodValues13.setDomainDescription("31-December-2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues19.setNotify(false);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year22, 0.0d);
        timePeriodValues13.setKey((java.lang.Comparable) year22);
        timePeriodValues13.setDescription("1969");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timePeriodValues13.addChangeListener(seriesChangeListener28);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener30);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(12, 11, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getItemCount();
        boolean boolean9 = timePeriodValues3.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("31-December-2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("31-December-2019");
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) seriesException8);
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException6.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        int int6 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(false);
        try {
            org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue3.getPeriod();
        java.lang.Object obj5 = timePeriodValue3.clone();
        boolean boolean7 = timePeriodValue3.equals((java.lang.Object) "2019");
        timePeriodValue3.setValue((java.lang.Number) 8);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        java.util.Calendar calendar4 = null;
        try {
            year3.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        int int5 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        java.lang.String str8 = year5.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        long long6 = year0.getLastMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        long long11 = day9.getSerialIndex();
        boolean boolean12 = year0.equals((java.lang.Object) day9);
        java.util.Calendar calendar13 = null;
        try {
            year0.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43830L + "'", long11 == 43830L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "hi!", "");
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass9 = seriesChangeEvent8.getClass();
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass17 = seriesChangeEvent16.getClass();
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone19);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.Date date23 = year22.getEnd();
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date23, timeZone24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass28 = seriesChangeEvent27.getClass();
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date23, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
        boolean boolean34 = simpleTimePeriod2.equals((java.lang.Object) day32);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        java.util.Date date8 = day2.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        long long10 = day9.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577822399999L + "'", long10 == 1577822399999L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        timePeriodValues13.setDomainDescription("31-December-2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues19.setNotify(false);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year22, 0.0d);
        timePeriodValues13.setKey((java.lang.Comparable) year22);
        timePeriodValues13.setDescription("1969");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timePeriodValues13.addChangeListener(seriesChangeListener28);
        java.lang.Object obj30 = null;
        boolean boolean31 = timePeriodValues13.equals(obj30);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day2);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int11 = timePeriodValues10.getMaxEndIndex();
        int int12 = timePeriodValues10.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues10.addChangeListener(seriesChangeListener13);
        java.lang.String str15 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues10.createCopy(8, (int) (byte) 10);
        timePeriodValues20.setDomainDescription("31-December-2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues26.setNotify(false);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year29, 0.0d);
        timePeriodValues20.setKey((java.lang.Comparable) year29);
        timePeriodValues20.setDescription("1969");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues20.addChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        java.util.Date date38 = year37.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year37, (java.lang.Number) 10);
        java.lang.String str41 = timePeriodValue40.toString();
        timePeriodValues20.add(timePeriodValue40);
        int int43 = day2.compareTo((java.lang.Object) timePeriodValue40);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(timePeriodValues20);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "TimePeriodValue[2019,10]" + "'", str41.equals("TimePeriodValue[2019,10]"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        int int4 = day2.getMonth();
        int int5 = day2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
        java.lang.String str7 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day2.next();
        java.util.Calendar calendar9 = null;
        try {
            day2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getSerialIndex();
        long long3 = year0.getFirstMillisecond();
        boolean boolean5 = year0.equals((java.lang.Object) (-1.0d));
        long long6 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long14 = simpleTimePeriod13.getStartMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        int int17 = year16.getYear();
        int int18 = day2.compareTo((java.lang.Object) year16);
        org.jfree.data.time.SerialDate serialDate19 = day2.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues24.setKey((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timePeriodValues24.addChangeListener(seriesChangeListener27);
        int int29 = timePeriodValues24.getMinStartIndex();
        int int30 = day2.compareTo((java.lang.Object) timePeriodValues24);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues24.removeChangeListener(seriesChangeListener31);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 6L + "'", long14 == 6L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year3, "org.jfree.data.general.SeriesChangeEvent[source=31-December-2019]", "TimePeriodValue[2019,2.0]");
        java.lang.Class<?> wildcardClass7 = year3.getClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 2);
        java.lang.String str6 = year0.toString();
        long long7 = year0.getSerialIndex();
        long long8 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
        timePeriodValues3.add(timePeriodValue7);
        java.lang.Object obj10 = timePeriodValue7.clone();
        timePeriodValue7.setValue((java.lang.Number) (short) 0);
        java.lang.Number number13 = timePeriodValue7.getValue();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timePeriod8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 0 + "'", number13.equals((short) 0));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMaxStartIndex();
        java.lang.Class<?> wildcardClass6 = timePeriodValues3.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "hi!", "");
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) ' ');
        long long8 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 7L + "'", long8 == 7L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "31-December-2019");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (java.lang.Number) 10);
        long long6 = year2.getFirstMillisecond();
        long long7 = year2.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (java.lang.Number) 0L);
        java.util.Date date10 = year2.getStart();
        java.lang.String str11 = year2.toString();
        timePeriodValues1.setKey((java.lang.Comparable) year2);
        java.lang.String str13 = year2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year2.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getDayOfMonth();
        long long5 = day2.getSerialIndex();
        long long6 = day2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day2.previous();
        int int8 = day2.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43830L + "'", long5 == 43830L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.Class<?> wildcardClass3 = date1.getClass();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 11);
        java.lang.Object obj7 = timePeriodValue6.clone();
        java.lang.Number number8 = timePeriodValue6.getValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 11 + "'", number8.equals(11));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass2);
        java.lang.String str20 = seriesChangeEvent19.toString();
        java.lang.Object obj21 = seriesChangeEvent19.getSource();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=class org.jfree.data.general.SeriesChangeEvent]" + "'", str20.equals("org.jfree.data.general.SeriesChangeEvent[source=class org.jfree.data.general.SeriesChangeEvent]"));
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("2019");
        int int8 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("1969");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: hi!");
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (java.lang.Number) 10);
        boolean boolean24 = day19.equals((java.lang.Object) 10);
        java.util.Date date25 = day19.getStart();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 0.0d);
        java.lang.String str28 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long14 = simpleTimePeriod13.getStartMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        int int17 = year16.getYear();
        int int18 = day2.compareTo((java.lang.Object) year16);
        org.jfree.data.time.SerialDate serialDate19 = day2.getSerialDate();
        org.jfree.data.time.SerialDate serialDate20 = day2.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate20);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 6L + "'", long14 == 6L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        int int7 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
//        timePeriodValues3.setNotify(false);
//        timePeriodValues3.setDomainDescription("2019");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        java.util.Date date11 = year10.getEnd();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        java.util.Date date14 = year13.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (java.lang.Number) 10);
//        boolean boolean17 = day12.equals((java.lang.Object) 10);
//        int int18 = day12.getMonth();
//        java.util.Date date19 = day12.getStart();
//        java.lang.String str20 = day12.toString();
//        int int21 = day12.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
//        timePeriodValues25.setKey((java.lang.Comparable) (short) -1);
//        java.lang.String str28 = timePeriodValues25.getDescription();
//        java.lang.String str29 = timePeriodValues25.getDomainDescription();
//        int int30 = day12.compareTo((java.lang.Object) str29);
//        timePeriodValues3.setKey((java.lang.Comparable) int30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        long long33 = day32.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day32, (double) 31);
//        timePeriodValues3.add(timePeriodValue35);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31-December-2019" + "'", str20.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 31 + "'", int21 == 31);
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560495599999L + "'", long33 == 1560495599999L);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.Date date6 = year5.getEnd();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year5.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setNotify(false);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass2);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 10);
        boolean boolean27 = day22.equals((java.lang.Object) 10);
        int int28 = day22.getMonth();
        java.util.Date date29 = day22.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass32 = seriesChangeEvent31.getClass();
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date33, timeZone34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass40 = seriesChangeEvent39.getClass();
        java.util.Date date41 = null;
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date41, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date37, timeZone42);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        java.util.Date date46 = year45.getEnd();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date46, timeZone47);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass51 = seriesChangeEvent50.getClass();
        java.util.Date date52 = null;
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone53);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date46, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date29, timeZone53);
        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class58 = org.jfree.data.time.RegularTimePeriod.downsize(class57);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(class57);
        org.junit.Assert.assertNotNull(class58);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "hi!", "");
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        long long7 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long7);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 12);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        boolean boolean12 = timePeriodValues11.getNotify();
        boolean boolean13 = timePeriodValue7.equals((java.lang.Object) boolean12);
        java.lang.String str14 = timePeriodValue7.toString();
        timePeriodValues1.add(timePeriodValue7);
        try {
            timePeriodValues1.update(8, (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[2019,10]" + "'", str14.equals("TimePeriodValue[2019,10]"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        int int26 = day25.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues30.addChangeListener(seriesChangeListener31);
        int int33 = timePeriodValues30.getMaxMiddleIndex();
        boolean boolean34 = day25.equals((java.lang.Object) timePeriodValues30);
        long long35 = day25.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43830L + "'", long35 == 43830L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        java.lang.String str6 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.next();
        long long8 = year0.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year0.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1562097599999L, 1546329600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues9.addChangeListener(seriesChangeListener10);
        java.lang.String str12 = timePeriodValues9.getDomainDescription();
        java.lang.String str13 = timePeriodValues9.getRangeDescription();
        boolean boolean14 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues9);
        java.lang.Class<?> wildcardClass15 = simpleTimePeriod2.getClass();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "hi!", "");
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        long long7 = simpleTimePeriod2.getEndMillis();
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = simpleTimePeriod2.compareTo((java.lang.Object) year9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 10);
        boolean boolean18 = day13.equals((java.lang.Object) 10);
        int int19 = day13.getMonth();
        java.util.Date date20 = day13.getStart();
        java.lang.String str21 = day13.toString();
        int int22 = day13.getDayOfMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues26.setKey((java.lang.Comparable) (short) -1);
        java.lang.String str29 = timePeriodValues26.getDescription();
        java.lang.String str30 = timePeriodValues26.getDomainDescription();
        int int31 = day13.compareTo((java.lang.Object) str30);
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 11);
        int int34 = simpleTimePeriod2.compareTo((java.lang.Object) day13);
        long long35 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "31-December-2019" + "'", str21.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 31 + "'", int22 == 31);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 7L + "'", long35 == 7L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        int int4 = day2.getMonth();
        int int5 = day2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod6, (double) 1.0f);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        java.util.Calendar calendar11 = null;
        try {
            day2.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        int int6 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        try {
            timePeriodValues3.update(5, (java.lang.Number) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        int int26 = day25.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues30.addChangeListener(seriesChangeListener31);
        int int33 = timePeriodValues30.getMaxMiddleIndex();
        boolean boolean34 = day25.equals((java.lang.Object) timePeriodValues30);
        timePeriodValues30.setDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.String str37 = timePeriodValues30.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = timePeriodValues30.createCopy((int) 'a', 5);
        int int41 = timePeriodValues40.getMinEndIndex();
        timePeriodValues40.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues40.removePropertyChangeListener(propertyChangeListener43);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(timePeriodValues40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass28 = seriesChangeEvent27.getClass();
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass36 = seriesChangeEvent35.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date33, timeZone38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.util.Date date42 = year41.getEnd();
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date42, timeZone43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass28);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        java.util.Date date50 = year49.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year49, (java.lang.Number) 10);
        boolean boolean53 = day48.equals((java.lang.Object) 10);
        int int54 = day48.getMonth();
        java.util.Date date55 = day48.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent57 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass58 = seriesChangeEvent57.getClass();
        java.util.Date date59 = null;
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date59, timeZone60);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        java.util.Date date63 = year62.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass66 = seriesChangeEvent65.getClass();
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date67, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date63, timeZone68);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        java.util.Date date72 = year71.getEnd();
        java.util.TimeZone timeZone73 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date72, timeZone73);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent76 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass77 = seriesChangeEvent76.getClass();
        java.util.Date date78 = null;
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date78, timeZone79);
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date72, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date55, timeZone79);
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(date16, timeZone79);
        org.jfree.data.time.TimePeriodValues timePeriodValues85 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "31-December-2019");
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year();
        java.util.Date date87 = year86.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue89 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year86, (java.lang.Number) 10);
        long long90 = year86.getFirstMillisecond();
        long long91 = year86.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue93 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year86, (java.lang.Number) 0L);
        java.util.Date date94 = year86.getStart();
        java.lang.String str95 = year86.toString();
        timePeriodValues85.setKey((java.lang.Comparable) year86);
        int int97 = year83.compareTo((java.lang.Object) year86);
        long long98 = year83.getLastMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 12 + "'", int54 == 12);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1546329600000L + "'", long90 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 2019L + "'", long91 == 2019L);
        org.junit.Assert.assertNotNull(date94);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "2019" + "'", str95.equals("2019"));
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
        org.junit.Assert.assertTrue("'" + long98 + "' != '" + 1577865599999L + "'", long98 == 1577865599999L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues29.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener32);
        boolean boolean34 = day25.equals((java.lang.Object) seriesChangeListener32);
        long long35 = day25.getSerialIndex();
        java.util.Calendar calendar36 = null;
        try {
            long long37 = day25.getFirstMillisecond(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43830L + "'", long35 == 43830L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setKey((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("2019");
        boolean boolean11 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        int int6 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.fireSeriesChanged();
        boolean boolean8 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        java.lang.String str7 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: 31-December-2019");
        int int10 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue3.getPeriod();
        java.lang.Number number5 = null;
        timePeriodValue3.setValue(number5);
        java.lang.String str7 = timePeriodValue3.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[2019,null]" + "'", str7.equals("TimePeriodValue[2019,null]"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 11);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        java.lang.String str6 = year0.toString();
        int int7 = year0.getYear();
        long long8 = year0.getFirstMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year0.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int11 = day9.getDayOfMonth();
        boolean boolean12 = timePeriodValues3.equals((java.lang.Object) day9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        int int15 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0.0]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener18);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 7);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.next();
        java.util.Date date5 = year2.getStart();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMaxStartIndex();
        java.lang.Class<?> wildcardClass6 = timePeriodValues3.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 10);
        long long13 = year9.getFirstMillisecond();
        long long14 = year9.getSerialIndex();
        java.lang.String str15 = year9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year9.next();
        java.util.Date date17 = regularTimePeriod16.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date17, timeZone18);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) 0 + "'", obj3.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (byte) 0 + "'", obj4.equals((byte) 0));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues29.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener32);
        boolean boolean34 = day25.equals((java.lang.Object) seriesChangeListener32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day25.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day25, "", "TimePeriodValue[2019,10]");
        timePeriodValues38.setRangeDescription("31-December-2019");
        timePeriodValues38.setKey((java.lang.Comparable) 0.0f);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue44 = timePeriodValues38.getDataItem(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getEndMillis();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) 1L);
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 6L + "'", long6 == 6L);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        java.lang.String str6 = year0.toString();
        int int7 = year0.getYear();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.lang.Class<?> wildcardClass8 = date6.getClass();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date4, timeZone9);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setNotify(true);
        int int8 = timePeriodValues3.getMinStartIndex();
        int int9 = timePeriodValues3.getMinEndIndex();
        try {
            java.lang.Number number11 = timePeriodValues3.getValue(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.Class<?> wildcardClass3 = date1.getClass();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) -1);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int7 = timePeriodValues6.getMaxEndIndex();
        int int8 = timePeriodValues6.getMaxStartIndex();
        java.lang.Class<?> wildcardClass9 = timePeriodValues6.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 10);
        boolean boolean18 = day13.equals((java.lang.Object) 10);
        int int19 = day13.getMonth();
        java.util.Date date20 = day13.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date20, timeZone21);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod22, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
        timePeriodValues3.add(timePeriodValue7);
        try {
            timePeriodValues3.delete(1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timePeriod8);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int11 = day9.getDayOfMonth();
        boolean boolean12 = timePeriodValues3.equals((java.lang.Object) day9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        int int15 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0.0]");
        boolean boolean18 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int7 = timePeriodValues6.getMaxStartIndex();
        boolean boolean8 = timePeriodValues6.isEmpty();
        int int9 = day2.compareTo((java.lang.Object) timePeriodValues6);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day2);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3, "", "");
        try {
            timePeriodValues6.update(31, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        java.lang.String str17 = timePeriodValues3.getRangeDescription();
        java.lang.String str18 = timePeriodValues3.getRangeDescription();
        int int19 = timePeriodValues3.getMinEndIndex();
        boolean boolean20 = timePeriodValues3.isEmpty();
        try {
            org.jfree.data.time.TimePeriod timePeriod22 = timePeriodValues3.getTimePeriod((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMaxStartIndex();
        java.lang.Class<?> wildcardClass6 = timePeriodValues3.getClass();
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues3.getTimePeriod(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod10, "hi!", "");
        boolean boolean14 = day2.equals((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        java.lang.Class<?> wildcardClass18 = date16.getClass();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date16, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "31-December-2019");
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 10);
        long long27 = year23.getFirstMillisecond();
        long long28 = year23.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 0L);
        java.util.Date date31 = year23.getStart();
        java.lang.String str32 = year23.toString();
        timePeriodValues22.setKey((java.lang.Comparable) year23);
        int int34 = day20.compareTo((java.lang.Object) timePeriodValues22);
        boolean boolean35 = day2.equals((java.lang.Object) int34);
        long long36 = day2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577779200000L + "'", long36 == 1577779200000L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int21 = timePeriodValues20.getMaxStartIndex();
        boolean boolean22 = timePeriodValues20.isEmpty();
        int int23 = day16.compareTo((java.lang.Object) timePeriodValues20);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day16, (double) 12);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = day16.getFirstMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 7);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, 0.0d);
        java.lang.String str9 = year6.toString();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int10 = timePeriodValues9.getMaxEndIndex();
        int int11 = timePeriodValues9.getMinMiddleIndex();
        timePeriodValues9.setNotify(false);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 10);
        boolean boolean21 = day16.equals((java.lang.Object) 10);
        int int22 = day16.getMonth();
        java.util.Date date23 = day16.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 10);
        long long28 = year24.getFirstMillisecond();
        java.util.Date date29 = year24.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year24.next();
        boolean boolean31 = day16.equals((java.lang.Object) regularTimePeriod30);
        boolean boolean32 = timePeriodValues9.equals((java.lang.Object) day16);
        int int33 = simpleTimePeriod2.compareTo((java.lang.Object) day16);
        java.lang.String str34 = day16.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day16.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "31-December-2019" + "'", str34.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass2);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 10);
        boolean boolean27 = day22.equals((java.lang.Object) 10);
        int int28 = day22.getMonth();
        java.util.Date date29 = day22.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass32 = seriesChangeEvent31.getClass();
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date33, timeZone34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass40 = seriesChangeEvent39.getClass();
        java.util.Date date41 = null;
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date41, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date37, timeZone42);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        java.util.Date date46 = year45.getEnd();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date46, timeZone47);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass51 = seriesChangeEvent50.getClass();
        java.util.Date date52 = null;
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone53);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date46, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date29, timeZone53);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date29);
        java.lang.Class<?> wildcardClass58 = date29.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(wildcardClass58);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMinStartIndex();
        java.lang.Object obj9 = timePeriodValues3.clone();
        timePeriodValues3.setRangeDescription("Value");
        try {
            org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValues3.getTimePeriod((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) (byte) 0, 3);
        java.lang.String str17 = timePeriodValues3.getRangeDescription();
        java.lang.String str18 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.Date date20 = year19.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.Date date23 = year22.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 10);
        boolean boolean26 = day21.equals((java.lang.Object) 10);
        int int27 = day21.getMonth();
        java.util.Date date28 = day21.getStart();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day21, 100.0d);
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
        org.junit.Assert.assertNotNull(date28);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        java.util.Date date8 = day2.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass12 = seriesChangeEvent11.getClass();
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass20 = seriesChangeEvent19.getClass();
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date17, timeZone22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getEnd();
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date26, timeZone27);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass12);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.util.Date date31 = year30.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.util.Date date34 = year33.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 10);
        boolean boolean37 = day32.equals((java.lang.Object) 10);
        int int38 = day32.getMonth();
        java.util.Date date39 = day32.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass42 = seriesChangeEvent41.getClass();
        java.util.Date date43 = null;
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date43, timeZone44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent49 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass50 = seriesChangeEvent49.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date47, timeZone52);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        java.util.Date date56 = year55.getEnd();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date56, timeZone57);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent60 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass61 = seriesChangeEvent60.getClass();
        java.util.Date date62 = null;
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date62, timeZone63);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date56, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date39, timeZone63);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod67 = new org.jfree.data.time.SimpleTimePeriod(date8, date39);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        java.util.Date date69 = year68.getEnd();
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date69);
        java.lang.Class<?> wildcardClass71 = date69.getClass();
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date69, timeZone72);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date39, timeZone72);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod77 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long78 = simpleTimePeriod77.getStartMillis();
        java.util.Date date79 = simpleTimePeriod77.getStart();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date79);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent82 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass83 = seriesChangeEvent82.getClass();
        java.util.Date date84 = null;
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass83, date84, timeZone85);
        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date79, timeZone85);
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date39, timeZone85);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 6L + "'", long78 == 6L);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(wildcardClass83);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertNull(regularTimePeriod86);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3, "", "");
        int int7 = timePeriodValues6.getMaxEndIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setKey((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        timePeriodValues3.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        java.util.Date date8 = day2.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass12 = seriesChangeEvent11.getClass();
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass20 = seriesChangeEvent19.getClass();
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date17, timeZone22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getEnd();
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date26, timeZone27);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass12);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.util.Date date31 = year30.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.util.Date date34 = year33.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 10);
        boolean boolean37 = day32.equals((java.lang.Object) 10);
        int int38 = day32.getMonth();
        java.util.Date date39 = day32.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass42 = seriesChangeEvent41.getClass();
        java.util.Date date43 = null;
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date43, timeZone44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent49 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass50 = seriesChangeEvent49.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date47, timeZone52);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        java.util.Date date56 = year55.getEnd();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date56, timeZone57);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent60 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass61 = seriesChangeEvent60.getClass();
        java.util.Date date62 = null;
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date62, timeZone63);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date56, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date39, timeZone63);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod67 = new org.jfree.data.time.SimpleTimePeriod(date8, date39);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        java.util.Date date69 = year68.getEnd();
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date69);
        java.lang.Class<?> wildcardClass71 = date69.getClass();
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date69, timeZone72);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date39, timeZone72);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent76 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass77 = seriesChangeEvent76.getClass();
        java.util.Date date78 = null;
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date78, timeZone79);
        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year();
        java.util.Date date82 = year81.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent84 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass85 = seriesChangeEvent84.getClass();
        java.util.Date date86 = null;
        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass85, date86, timeZone87);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date82, timeZone87);
        org.jfree.data.time.Year year90 = new org.jfree.data.time.Year();
        java.util.Date date91 = year90.getEnd();
        java.util.TimeZone timeZone92 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date91, timeZone92);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent94 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass77);
        java.lang.Class class95 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass77);
        int int96 = year74.compareTo((java.lang.Object) wildcardClass77);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(wildcardClass85);
        org.junit.Assert.assertNotNull(timeZone87);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertNull(regularTimePeriod89);
        org.junit.Assert.assertNotNull(date91);
        org.junit.Assert.assertNull(regularTimePeriod93);
        org.junit.Assert.assertNotNull(class95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1 + "'", int96 == 1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        int int26 = day25.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues30.addChangeListener(seriesChangeListener31);
        int int33 = timePeriodValues30.getMaxMiddleIndex();
        boolean boolean34 = day25.equals((java.lang.Object) timePeriodValues30);
        timePeriodValues30.setDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.String str37 = timePeriodValues30.getDescription();
        int int38 = timePeriodValues30.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        java.lang.String str6 = year0.toString();
        int int7 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int12 = timePeriodValues11.getMaxEndIndex();
        int int13 = timePeriodValues11.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues11.addChangeListener(seriesChangeListener14);
        java.lang.String str16 = timePeriodValues11.getDescription();
        timePeriodValues11.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = timePeriodValues11.createCopy(8, (int) (byte) 10);
        timePeriodValues21.setDomainDescription("31-December-2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues27.setNotify(false);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) year30, 0.0d);
        timePeriodValues21.setKey((java.lang.Comparable) year30);
        timePeriodValues21.setDescription("1969");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
        timePeriodValues21.addChangeListener(seriesChangeListener36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue41 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year38, (java.lang.Number) 10);
        java.lang.String str42 = timePeriodValue41.toString();
        timePeriodValues21.add(timePeriodValue41);
        try {
            int int44 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues21);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(timePeriodValues21);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "TimePeriodValue[2019,10]" + "'", str42.equals("TimePeriodValue[2019,10]"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        int int26 = day25.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues30.addChangeListener(seriesChangeListener31);
        int int33 = timePeriodValues30.getMaxMiddleIndex();
        boolean boolean34 = day25.equals((java.lang.Object) timePeriodValues30);
        timePeriodValues30.setDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.String str37 = timePeriodValues30.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = timePeriodValues30.createCopy((int) 'a', 5);
        int int41 = timePeriodValues40.getMinEndIndex();
        java.lang.String str42 = timePeriodValues40.getDomainDescription();
        timePeriodValues40.setDescription("TimePeriodValue[2019,null]");
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(timePeriodValues40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass2);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 10);
        boolean boolean27 = day22.equals((java.lang.Object) 10);
        int int28 = day22.getMonth();
        java.util.Date date29 = day22.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass32 = seriesChangeEvent31.getClass();
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date33, timeZone34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass40 = seriesChangeEvent39.getClass();
        java.util.Date date41 = null;
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date41, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date37, timeZone42);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        java.util.Date date46 = year45.getEnd();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date46, timeZone47);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass51 = seriesChangeEvent50.getClass();
        java.util.Date date52 = null;
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone53);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date46, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date29, timeZone53);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date29);
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        java.util.Date date59 = year58.getEnd();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        java.util.Date date62 = year61.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue64 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year61, (java.lang.Number) 10);
        boolean boolean65 = day60.equals((java.lang.Object) 10);
        int int66 = day60.getMonth();
        java.util.Date date67 = day60.getStart();
        org.jfree.data.time.SerialDate serialDate68 = day60.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod71 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long72 = simpleTimePeriod71.getStartMillis();
        java.util.Date date73 = simpleTimePeriod71.getStart();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date73);
        int int75 = year74.getYear();
        int int76 = day60.compareTo((java.lang.Object) year74);
        org.jfree.data.time.SerialDate serialDate77 = day60.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = day60.next();
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year();
        java.util.Date date80 = year79.getEnd();
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date80);
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year();
        java.util.Date date83 = year82.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue85 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year82, (java.lang.Number) 10);
        boolean boolean86 = day81.equals((java.lang.Object) 10);
        int int87 = day81.getMonth();
        java.util.Date date88 = day81.getStart();
        org.jfree.data.time.Year year89 = new org.jfree.data.time.Year();
        java.util.Date date90 = year89.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue92 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year89, (java.lang.Number) 10);
        long long93 = year89.getFirstMillisecond();
        java.util.Date date94 = year89.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = year89.next();
        boolean boolean96 = day81.equals((java.lang.Object) regularTimePeriod95);
        boolean boolean97 = day60.equals((java.lang.Object) boolean96);
        boolean boolean98 = year57.equals((java.lang.Object) day60);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 12 + "'", int66 == 12);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 6L + "'", long72 == 6L);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1969 + "'", int75 == 1969);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 12 + "'", int87 == 12);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(date90);
        org.junit.Assert.assertTrue("'" + long93 + "' != '" + 1546329600000L + "'", long93 == 1546329600000L);
        org.junit.Assert.assertNotNull(date94);
        org.junit.Assert.assertNotNull(regularTimePeriod95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setNotify(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        timePeriodValues3.setKey((java.lang.Comparable) date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long14 = simpleTimePeriod13.getEndMillis();
        boolean boolean16 = simpleTimePeriod13.equals((java.lang.Object) 1L);
        long long17 = simpleTimePeriod13.getStartMillis();
        long long18 = simpleTimePeriod13.getStartMillis();
        java.util.Date date19 = simpleTimePeriod13.getEnd();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date9, date19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 7L + "'", long14 == 7L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 6L + "'", long17 == 6L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 6L + "'", long18 == 6L);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("2019");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) 9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValue15.getPeriod();
        java.lang.String str17 = timePeriodValue15.toString();
        boolean boolean18 = timePeriodValues3.equals((java.lang.Object) timePeriodValue15);
        java.lang.String str19 = timePeriodValue15.toString();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timePeriod16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TimePeriodValue[2019,10]" + "'", str17.equals("TimePeriodValue[2019,10]"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TimePeriodValue[2019,10]" + "'", str19.equals("TimePeriodValue[2019,10]"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) (byte) 1);
        long long3 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass12 = seriesChangeEvent11.getClass();
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date18, timeZone19);
        boolean boolean21 = year0.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.Date date23 = year22.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 10);
        long long26 = year22.getFirstMillisecond();
        long long27 = year22.getSerialIndex();
        long long28 = year22.getLastMillisecond();
        boolean boolean29 = year0.equals((java.lang.Object) year22);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass32 = seriesChangeEvent31.getClass();
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date33, timeZone34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass40 = seriesChangeEvent39.getClass();
        java.util.Date date41 = null;
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date41, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date37, timeZone42);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        java.util.Date date46 = year45.getEnd();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date46, timeZone47);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass51 = seriesChangeEvent50.getClass();
        java.util.Date date52 = null;
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone53);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date46, timeZone53);
        org.jfree.data.time.SerialDate serialDate56 = day55.getSerialDate();
        int int57 = day55.getDayOfMonth();
        boolean boolean58 = year22.equals((java.lang.Object) day55);
        java.lang.String str59 = day55.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 31 + "'", int57 == 31);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "31-December-2019" + "'", str59.equals("31-December-2019"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setKey((java.lang.Comparable) (short) -1);
        java.lang.String str6 = timePeriodValues3.getDescription();
        timePeriodValues3.fireSeriesChanged();
        try {
            timePeriodValues3.update(11, (java.lang.Number) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        int int6 = timePeriodValues3.getMaxStartIndex();
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) 100.0d);
        timePeriodValues3.setNotify(false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 7);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (java.lang.Number) 12);
        timePeriodValues3.add(timePeriodValue16);
        timePeriodValues3.delete((int) (byte) 100, (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 6L + "'", long4 == 6L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "hi!", "");
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        long long7 = simpleTimePeriod2.getEndMillis();
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        int int10 = day9.getMonth();
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long14 = simpleTimePeriod13.getStartMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        int int17 = year16.getYear();
        int int18 = day2.compareTo((java.lang.Object) year16);
        org.jfree.data.time.SerialDate serialDate19 = day2.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues24.setKey((java.lang.Comparable) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timePeriodValues24.addChangeListener(seriesChangeListener27);
        int int29 = timePeriodValues24.getMinStartIndex();
        int int30 = day2.compareTo((java.lang.Object) timePeriodValues24);
        long long31 = day2.getSerialIndex();
        java.util.Calendar calendar32 = null;
        try {
            long long33 = day2.getFirstMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 6L + "'", long14 == 6L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43830L + "'", long31 == 43830L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0L);
        java.lang.String str8 = year0.toString();
        int int9 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass12 = seriesChangeEvent11.getClass();
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date18, timeZone19);
        boolean boolean21 = year0.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.Date date23 = year22.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 10);
        long long26 = year22.getFirstMillisecond();
        long long27 = year22.getSerialIndex();
        long long28 = year22.getLastMillisecond();
        boolean boolean29 = year0.equals((java.lang.Object) year22);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass32 = seriesChangeEvent31.getClass();
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date33, timeZone34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass40 = seriesChangeEvent39.getClass();
        java.util.Date date41 = null;
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date41, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date37, timeZone42);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        java.util.Date date46 = year45.getEnd();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date46, timeZone47);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass51 = seriesChangeEvent50.getClass();
        java.util.Date date52 = null;
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone53);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date46, timeZone53);
        org.jfree.data.time.SerialDate serialDate56 = day55.getSerialDate();
        int int57 = day55.getDayOfMonth();
        boolean boolean58 = year22.equals((java.lang.Object) day55);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        java.util.Date date60 = year59.getEnd();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
        int int62 = year22.compareTo((java.lang.Object) day61);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 31 + "'", int57 == 31);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int7 = timePeriodValues6.getMaxStartIndex();
        boolean boolean8 = timePeriodValues6.isEmpty();
        int int9 = day2.compareTo((java.lang.Object) timePeriodValues6);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day2);
        java.lang.Comparable comparable11 = timePeriodValues10.getKey();
        java.lang.Object obj12 = timePeriodValues10.clone();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(comparable11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long14 = simpleTimePeriod13.getStartMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        int int17 = year16.getYear();
        int int18 = day2.compareTo((java.lang.Object) year16);
        org.jfree.data.time.SerialDate serialDate19 = day2.getSerialDate();
        org.jfree.data.time.SerialDate serialDate20 = day2.getSerialDate();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = day2.getMiddleMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 6L + "'", long14 == 6L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMaxStartIndex();
        java.lang.Class<?> wildcardClass6 = timePeriodValues3.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 10);
        boolean boolean15 = day10.equals((java.lang.Object) 10);
        int int16 = day10.getMonth();
        java.util.Date date17 = day10.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date17, timeZone18);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = regularTimePeriod19.getMiddleMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        boolean boolean4 = timePeriodValues3.getNotify();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 10);
        long long12 = year8.getFirstMillisecond();
        long long13 = year8.getSerialIndex();
        long long14 = year8.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 1L);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 3);
        java.util.Calendar calendar14 = null;
        try {
            year8.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0d, "31-December-2019", "2019");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("31-December-2019");
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("hi!");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) seriesException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("31-December-2019");
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("hi!");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) seriesException16);
        seriesException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        seriesException6.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        boolean boolean20 = timePeriodValues3.equals((java.lang.Object) seriesException6);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener21);
        int int23 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.util.Date date0 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date4 = simpleTimePeriod3.getStart();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod(date0, date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValue16.getPeriod();
        java.lang.Object obj18 = timePeriodValue16.clone();
        org.jfree.data.time.TimePeriod timePeriod19 = timePeriodValue16.getPeriod();
        timePeriodValues3.add(timePeriodValue16);
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue16.getPeriod();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timePeriod17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(timePeriod19);
        org.junit.Assert.assertNotNull(timePeriod21);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        int int26 = day25.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues30.addChangeListener(seriesChangeListener31);
        int int33 = timePeriodValues30.getMaxMiddleIndex();
        boolean boolean34 = day25.equals((java.lang.Object) timePeriodValues30);
        timePeriodValues30.setDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.String str37 = timePeriodValues30.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = timePeriodValues30.createCopy((int) 'a', 5);
        int int41 = timePeriodValues40.getMinEndIndex();
        timePeriodValues40.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriod timePeriod44 = timePeriodValues40.getTimePeriod((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(timePeriodValues40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        boolean boolean4 = timePeriodValues3.getNotify();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(6, 31);
        java.lang.String str10 = timePeriodValues3.getDescription();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue14.getPeriod();
        java.lang.Object obj16 = timePeriodValue14.clone();
        boolean boolean18 = timePeriodValue14.equals((java.lang.Object) "2019");
        org.jfree.data.time.TimePeriod timePeriod19 = timePeriodValue14.getPeriod();
        timePeriodValue14.setValue((java.lang.Number) 7);
        timePeriodValues3.add(timePeriodValue14);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timePeriod15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timePeriod19);
        org.junit.Assert.assertNotNull(timePeriodValues25);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue3.getPeriod();
        java.lang.Object obj5 = timePeriodValue3.clone();
        boolean boolean7 = timePeriodValue3.equals((java.lang.Object) "2019");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        boolean boolean12 = timePeriodValue3.equals((java.lang.Object) regularTimePeriod11);
        java.lang.Object obj13 = timePeriodValue3.clone();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timePeriod4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        try {
            org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValues3.getTimePeriod(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date7 = simpleTimePeriod6.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        boolean boolean9 = year0.equals((java.lang.Object) day8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setKey((java.lang.Comparable) (short) -1);
        java.lang.String str6 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue7.getPeriod();
        timePeriodValues3.add(timePeriodValue7);
        java.lang.String str10 = timePeriodValue7.toString();
        timePeriodValue7.setValue((java.lang.Number) 1L);
        java.lang.Number number13 = timePeriodValue7.getValue();
        java.lang.Number number14 = timePeriodValue7.getValue();
        java.lang.Class<?> wildcardClass15 = timePeriodValue7.getClass();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timePeriod8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,10]" + "'", str10.equals("TimePeriodValue[2019,10]"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1L + "'", number13.equals(1L));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1L + "'", number14.equals(1L));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        boolean boolean8 = timePeriodValues3.isEmpty();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue12.getPeriod();
        java.lang.Object obj14 = timePeriodValue12.clone();
        boolean boolean16 = timePeriodValue12.equals((java.lang.Object) "2019");
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        java.util.Date date23 = year22.getStart();
        timePeriodValues3.setKey((java.lang.Comparable) date23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass27 = seriesChangeEvent26.getClass();
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date28, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.util.Date date32 = year31.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass35 = seriesChangeEvent34.getClass();
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date32, timeZone37);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        java.util.Date date41 = year40.getEnd();
        java.util.TimeZone timeZone42 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date41, timeZone42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass46 = seriesChangeEvent45.getClass();
        java.util.Date date47 = null;
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date47, timeZone48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date41, timeZone48);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(date23, date41);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timePeriod13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.util.Date date0 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date8, timeZone13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date17, timeZone18);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass3);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 10);
        boolean boolean28 = day23.equals((java.lang.Object) 10);
        int int29 = day23.getMonth();
        java.util.Date date30 = day23.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass33 = seriesChangeEvent32.getClass();
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date34, timeZone35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        java.util.Date date38 = year37.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass41 = seriesChangeEvent40.getClass();
        java.util.Date date42 = null;
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date42, timeZone43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date38, timeZone43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date47, timeZone48);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent51 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass52 = seriesChangeEvent51.getClass();
        java.util.Date date53 = null;
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date53, timeZone54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date47, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date30, timeZone54);
        try {
            org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date0, timeZone54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNull(regularTimePeriod57);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        java.lang.Class<?> wildcardClass4 = day2.getClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "hi!", "");
        boolean boolean6 = timePeriodValues5.isEmpty();
        try {
            java.lang.Number number8 = timePeriodValues5.getValue(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues29.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener32);
        boolean boolean34 = day25.equals((java.lang.Object) seriesChangeListener32);
        long long35 = day25.getSerialIndex();
        long long36 = day25.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43830L + "'", long35 == 43830L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43830L + "'", long36 == 43830L);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, 0.0d);
        long long9 = year6.getSerialIndex();
        long long10 = year6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        int int4 = day2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        int int7 = day2.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        boolean boolean14 = day2.equals((java.lang.Object) regularTimePeriod13);
        long long15 = day2.getFirstMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = day2.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577779200000L + "'", long15 == 1577779200000L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[2019,1]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 12, 28799999L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        boolean boolean14 = timePeriodValues13.isEmpty();
        boolean boolean15 = timePeriodValues13.isEmpty();
        timePeriodValues13.setRangeDescription("TimePeriodValue[2019,10]");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass20 = seriesChangeEvent19.getClass();
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass28 = seriesChangeEvent27.getClass();
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date25, timeZone30);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.util.Date date34 = year33.getEnd();
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date34, timeZone35);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass39 = seriesChangeEvent38.getClass();
        java.util.Date date40 = null;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date40, timeZone41);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date34, timeZone41);
        org.jfree.data.time.SerialDate serialDate44 = day43.getSerialDate();
        int int45 = day43.getDayOfMonth();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day43, (java.lang.Number) 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 31 + "'", int45 == 31);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.String str3 = day2.toString();
        long long4 = day2.getLastMillisecond();
        int int5 = day2.getMonth();
        int int6 = day2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day2.previous();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        java.lang.String str11 = day10.toString();
        int int12 = day10.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate13 = day10.getSerialDate();
        int int15 = day10.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass18 = seriesChangeEvent17.getClass();
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date19, timeZone20);
        boolean boolean22 = day10.equals((java.lang.Object) regularTimePeriod21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day10.previous();
        boolean boolean24 = day2.equals((java.lang.Object) day10);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31-December-2019" + "'", str3.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues29.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener32);
        boolean boolean34 = day25.equals((java.lang.Object) seriesChangeListener32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day25.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day25, "", "TimePeriodValue[2019,10]");
        timePeriodValues38.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=class org.jfree.data.general.SeriesChangeEvent]");
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass12 = seriesChangeEvent11.getClass();
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date18, timeZone19);
        boolean boolean21 = year0.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.Date date23 = year22.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 10);
        long long26 = year22.getFirstMillisecond();
        long long27 = year22.getSerialIndex();
        long long28 = year22.getLastMillisecond();
        boolean boolean29 = year0.equals((java.lang.Object) year22);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass32 = seriesChangeEvent31.getClass();
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date33, timeZone34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass40 = seriesChangeEvent39.getClass();
        java.util.Date date41 = null;
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date41, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date37, timeZone42);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        java.util.Date date46 = year45.getEnd();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date46, timeZone47);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass51 = seriesChangeEvent50.getClass();
        java.util.Date date52 = null;
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone53);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date46, timeZone53);
        org.jfree.data.time.SerialDate serialDate56 = day55.getSerialDate();
        int int57 = day55.getDayOfMonth();
        boolean boolean58 = year22.equals((java.lang.Object) day55);
        org.jfree.data.time.TimePeriodValues timePeriodValues62 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        boolean boolean63 = timePeriodValues62.getNotify();
        int int64 = timePeriodValues62.getMinMiddleIndex();
        timePeriodValues62.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues68 = timePeriodValues62.createCopy(6, 31);
        java.lang.String str69 = timePeriodValues62.getDescription();
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year();
        java.util.Date date71 = year70.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue73 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year70, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriod timePeriod74 = timePeriodValue73.getPeriod();
        java.lang.Object obj75 = timePeriodValue73.clone();
        boolean boolean77 = timePeriodValue73.equals((java.lang.Object) "2019");
        org.jfree.data.time.TimePeriod timePeriod78 = timePeriodValue73.getPeriod();
        timePeriodValue73.setValue((java.lang.Number) 7);
        timePeriodValues62.add(timePeriodValue73);
        int int82 = year22.compareTo((java.lang.Object) timePeriodValue73);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 31 + "'", int57 == 31);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues68);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(timePeriod74);
        org.junit.Assert.assertNotNull(obj75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(timePeriod78);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMinEndIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues3.getTimePeriod(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("31-December-2019");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) seriesException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("31-December-2019");
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("hi!");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) seriesException11);
        seriesException6.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.String str15 = timePeriodFormatException9.toString();
        java.lang.Class<?> wildcardClass16 = timePeriodFormatException9.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 31-December-2019" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: 31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod10, "hi!", "");
        boolean boolean14 = day2.equals((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        java.lang.Class<?> wildcardClass18 = date16.getClass();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date16, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "31-December-2019");
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 10);
        long long27 = year23.getFirstMillisecond();
        long long28 = year23.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 0L);
        java.util.Date date31 = year23.getStart();
        java.lang.String str32 = year23.toString();
        timePeriodValues22.setKey((java.lang.Comparable) year23);
        int int34 = day20.compareTo((java.lang.Object) timePeriodValues22);
        boolean boolean35 = day2.equals((java.lang.Object) int34);
        java.lang.String str36 = day2.toString();
        int int37 = day2.getDayOfMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31-December-2019" + "'", str36.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        int int4 = day2.getMonth();
        int int5 = day2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
        java.lang.String str7 = day2.toString();
        org.jfree.data.time.SerialDate serialDate8 = day2.getSerialDate();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("2019");
        timePeriodValues3.setNotify(true);
        timePeriodValues3.setDescription("");
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setNotify(true);
        int int8 = timePeriodValues3.getMinStartIndex();
        java.lang.String str9 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("31-December-2019");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) seriesException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        java.lang.Object obj4 = null;
        int int5 = day2.compareTo(obj4);
        java.lang.String str6 = day2.toString();
        int int7 = day2.getDayOfMonth();
        long long8 = day2.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-December-2019" + "'", str6.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass16 = seriesChangeEvent15.getClass();
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date17, timeZone18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass24 = seriesChangeEvent23.getClass();
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone26);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.util.Date date30 = year29.getEnd();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date30, timeZone31);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass35 = seriesChangeEvent34.getClass();
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date36, timeZone37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date30, timeZone37);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date11, timeZone37);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent42 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass43 = seriesChangeEvent42.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        java.util.Date date48 = year47.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass51 = seriesChangeEvent50.getClass();
        java.util.Date date52 = null;
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date48, timeZone53);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        java.util.Date date57 = year56.getEnd();
        java.util.TimeZone timeZone58 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date57, timeZone58);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent60 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass43);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        java.util.Date date62 = year61.getEnd();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date62);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        java.util.Date date65 = year64.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year64, (java.lang.Number) 10);
        boolean boolean68 = day63.equals((java.lang.Object) 10);
        int int69 = day63.getMonth();
        java.util.Date date70 = day63.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent72 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass73 = seriesChangeEvent72.getClass();
        java.util.Date date74 = null;
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date74, timeZone75);
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year();
        java.util.Date date78 = year77.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent80 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass81 = seriesChangeEvent80.getClass();
        java.util.Date date82 = null;
        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass81, date82, timeZone83);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date78, timeZone83);
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year();
        java.util.Date date87 = year86.getEnd();
        java.util.TimeZone timeZone88 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date87, timeZone88);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent91 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass92 = seriesChangeEvent91.getClass();
        java.util.Date date93 = null;
        java.util.TimeZone timeZone94 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass92, date93, timeZone94);
        org.jfree.data.time.Day day96 = new org.jfree.data.time.Day(date87, timeZone94);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date70, timeZone94);
        org.jfree.data.time.Year year98 = new org.jfree.data.time.Year(date11, timeZone94);
        org.jfree.data.time.Year year99 = new org.jfree.data.time.Year(date7, timeZone94);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 12 + "'", int69 == 12);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertNotNull(timeZone83);
        org.junit.Assert.assertNull(regularTimePeriod84);
        org.junit.Assert.assertNull(regularTimePeriod85);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertNull(regularTimePeriod89);
        org.junit.Assert.assertNotNull(wildcardClass92);
        org.junit.Assert.assertNotNull(timeZone94);
        org.junit.Assert.assertNull(regularTimePeriod95);
        org.junit.Assert.assertNull(regularTimePeriod97);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(8, (int) (byte) 10);
        java.lang.Object obj14 = timePeriodValues13.clone();
        timePeriodValues13.delete((int) 'a', 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long3 = simpleTimePeriod2.getEndMillis();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) 1L);
        long long6 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 10);
        boolean boolean14 = day9.equals((java.lang.Object) 10);
        int int15 = day9.getMonth();
        long long16 = day9.getFirstMillisecond();
        java.lang.String str17 = day9.toString();
        try {
            int int18 = simpleTimePeriod2.compareTo((java.lang.Object) str17);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 6L + "'", long6 == 6L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577779200000L + "'", long16 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31-December-2019" + "'", str17.equals("31-December-2019"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        int int8 = day2.getMonth();
        java.util.Date date9 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day2.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        long long14 = simpleTimePeriod13.getStartMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        int int17 = year16.getYear();
        int int18 = day2.compareTo((java.lang.Object) year16);
        java.lang.Class<?> wildcardClass19 = year16.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) 7);
        java.util.Date date23 = simpleTimePeriod22.getEnd();
        java.util.Date date24 = simpleTimePeriod22.getStart();
        java.util.Date date25 = simpleTimePeriod22.getStart();
        java.util.Date date26 = simpleTimePeriod22.getEnd();
        boolean boolean27 = year16.equals((java.lang.Object) simpleTimePeriod22);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 6L + "'", long14 == 6L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("31-December-2019");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) seriesException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("31-December-2019");
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("hi!");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) seriesException11);
        seriesException6.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray17 = seriesException16.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("31-December-2019");
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("hi!");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) seriesException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("31-December-2019");
        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("hi!");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) seriesException26);
        seriesException21.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        seriesException16.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.String str30 = timePeriodFormatException24.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.String str32 = seriesException1.toString();
        java.lang.String str33 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 31-December-2019" + "'", str30.equals("org.jfree.data.time.TimePeriodFormatException: 31-December-2019"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str32.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str33.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 12);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        boolean boolean12 = timePeriodValues11.getNotify();
        boolean boolean13 = timePeriodValue7.equals((java.lang.Object) boolean12);
        java.lang.String str14 = timePeriodValue7.toString();
        timePeriodValues1.add(timePeriodValue7);
        org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValues1.getTimePeriod((int) (byte) 0);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener18);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[2019,10]" + "'", str14.equals("TimePeriodValue[2019,10]"));
        org.junit.Assert.assertNotNull(timePeriod17);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        long long6 = year0.getLastMillisecond();
        long long7 = year0.getLastMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 10);
        boolean boolean7 = day2.equals((java.lang.Object) 10);
        java.util.Date date8 = day2.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass12 = seriesChangeEvent11.getClass();
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass20 = seriesChangeEvent19.getClass();
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date17, timeZone22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getEnd();
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date26, timeZone27);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass12);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.util.Date date31 = year30.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.util.Date date34 = year33.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 10);
        boolean boolean37 = day32.equals((java.lang.Object) 10);
        int int38 = day32.getMonth();
        java.util.Date date39 = day32.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass42 = seriesChangeEvent41.getClass();
        java.util.Date date43 = null;
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date43, timeZone44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent49 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass50 = seriesChangeEvent49.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date47, timeZone52);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        java.util.Date date56 = year55.getEnd();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date56, timeZone57);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent60 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass61 = seriesChangeEvent60.getClass();
        java.util.Date date62 = null;
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date62, timeZone63);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date56, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date39, timeZone63);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod67 = new org.jfree.data.time.SimpleTimePeriod(date8, date39);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        java.util.Date date69 = year68.getEnd();
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date69);
        java.lang.Class<?> wildcardClass71 = date69.getClass();
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date69, timeZone72);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date39, timeZone72);
        java.util.Calendar calendar75 = null;
        try {
            long long76 = year74.getLastMillisecond(calendar75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(timeZone72);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        int int11 = day9.getDayOfMonth();
        boolean boolean12 = timePeriodValues3.equals((java.lang.Object) day9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        int int15 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0.0]");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        java.lang.String str6 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.next();
        long long8 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long8, "", "31-December-2019");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.Date date3 = year2.getEnd();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        boolean boolean5 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 12, (long) 31);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setDomainDescription("Value");
        timePeriodValues3.fireSeriesChanged();
        int int10 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date1);
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues8.addChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues8.getMaxMiddleIndex();
        int int12 = timePeriodValues8.getMinStartIndex();
        boolean boolean13 = timePeriodValues3.equals((java.lang.Object) int12);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(comparable4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getSerialIndex();
        long long6 = year0.getLastMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.lang.String str10 = day9.toString();
        long long11 = day9.getSerialIndex();
        boolean boolean12 = year0.equals((java.lang.Object) day9);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day9);
        long long14 = day9.getSerialIndex();
        int int15 = day9.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43830L + "'", long11 == 43830L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43830L + "'", long14 == 43830L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getSerialIndex();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 10);
        long long4 = year0.getFirstMillisecond();
        java.util.Date date5 = year0.getStart();
        long long6 = year0.getSerialIndex();
        long long7 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }
}

