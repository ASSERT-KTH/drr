import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        waferMapPlot1.setNoDataMessage("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        waferMapPlot1.setOutlineStroke(stroke4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = waferMapPlot1.getDrawingSupplier();
        java.lang.Object obj7 = waferMapPlot1.clone();
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection8 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 100);
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        java.lang.String str4 = multiplePiePlot0.getPlotType();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot5.setLimit((double) 100);
        org.jfree.chart.util.TableOrder tableOrder8 = multiplePiePlot5.getDataExtractOrder();
        multiplePiePlot0.setDataExtractOrder(tableOrder8);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Multiple Pie Plot" + "'", str4.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(tableOrder8);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = multiplePiePlot0.getLegendItems();
        multiplePiePlot0.setLimit(0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        barRenderer0.setSeriesURLGenerator(0, categoryURLGenerator6);
        java.awt.Paint paint8 = barRenderer0.getBaseLegendTextPaint();
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        long long4 = segmentedTimeline3.getSegmentsGroupSize();
        try {
            boolean boolean7 = segmentedTimeline3.containsDomainRange((long) 2147483647, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: domainValueEnd (0) < domainValueStart (2147483647)");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.lang.String str2 = textTitle1.getToolTipText();
        textTitle1.visible = true;
        java.awt.Paint paint5 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer2.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer2.getBaseToolTipGenerator();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int11 = numberTickUnit9.compareTo((java.lang.Object) 10);
        numberAxis7.setTickUnit(numberTickUnit9);
        float float13 = numberAxis7.getMinorTickMarkInsideLength();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity19 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis7, shape16, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint20 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape16, paint20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = legendGraphic21.getShapeLocation();
        java.awt.Paint paint23 = legendGraphic21.getFillPaint();
        barRenderer2.setBaseItemLabelPaint(paint23, true);
        java.awt.geom.RectangularShape rectangularShape29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection31 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot30.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot30.getRangeAxisEdge();
        try {
            gradientBarPainter0.paintBarShadow(graphics2D1, barRenderer2, 255, (int) 'a', false, rectangularShape29, rectangleEdge33, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 500, (double) 3600000L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("{0}: ({1}, {2})");
        unknownKeyException1.addSuppressed((java.lang.Throwable) seriesException3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        waferMapPlot1.setNoDataMessage("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        waferMapPlot1.setOutlineStroke(stroke4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = waferMapPlot1.getDrawingSupplier();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = waferMapPlot1.getInsets();
        java.lang.String str8 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "WMAP_Plot" + "'", str8.equals("WMAP_Plot"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, comparable1, 5.0d, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection1 = xYAreaRenderer0.getAnnotations();
        xYAreaRenderer0.clearSeriesStrokes(true);
        org.junit.Assert.assertNotNull(collection1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset4 = new org.jfree.data.xy.DefaultXYDataset();
        boolean boolean5 = standardXYToolTipGenerator3.equals((java.lang.Object) defaultXYDataset4);
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) defaultXYDataset4);
        try {
            java.lang.Number number9 = defaultXYDataset4.getY(10, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint8 = xYStepRenderer5.lookupLegendTextPaint((int) 'a');
        xYStepRenderer5.setBaseLinesVisible(true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        boolean boolean12 = xYStepRenderer5.removeAnnotation(xYAnnotation11);
        java.awt.Shape shape14 = xYStepRenderer5.lookupLegendShape((int) (short) 10);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) 0, "hi!", "{0}: ({1}, {2})", false);
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat((double) 0, "hi!", "{0}: ({1}, {2})", false);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator12 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat11);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = new org.jfree.chart.axis.NumberTickUnit((double) 15, (java.text.NumberFormat) logFormat6);
        java.util.Currency currency14 = null;
        try {
            logFormat6.setCurrency(currency14);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getIgnoreNullValues();
        java.awt.Paint paint3 = piePlot1.getShadowPaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot1.getLabelDistributor();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection2 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        try {
            java.lang.Number number8 = xYSeriesCollection4.getY(2147483647, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot1.getLabelDistributor();
        abstractPieLabelDistributor4.clear();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint14 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape10, paint14);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape10, "ThreadContext", "DateTickMarkPosition.MIDDLE");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        xYPlot0.setRangeMinorGridlinesVisible(true);
        java.awt.Color color17 = java.awt.Color.blue;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color17);
        int int19 = color17.getAlpha();
        float[] floatArray24 = new float[] { (byte) -1, (-1.0f), 2147483647, 4 };
        float[] floatArray25 = color17.getColorComponents(floatArray24);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        java.text.NumberFormat numberFormat4 = standardXYToolTipGenerator3.getYFormat();
        java.lang.String str5 = standardXYToolTipGenerator3.getFormatString();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot6.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        java.awt.Paint paint9 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint9, (java.lang.Object) basicProjectInfo10);
        xYPlot6.setRangeCrosshairPaint(paint9);
        java.awt.Paint paint13 = xYPlot6.getRangeZeroBaselinePaint();
        xYPlot6.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot6.zoomRangeAxes(Double.NaN, plotRenderingInfo17, point2D18, true);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.entity.EntityCollection entityCollection24 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo(entityCollection24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = chartRenderingInfo25.getPlotInfo();
        org.jfree.chart.plot.CrosshairState crosshairState28 = new org.jfree.chart.plot.CrosshairState(false);
        int int29 = crosshairState28.getRangeAxisIndex();
        boolean boolean30 = xYPlot6.render(graphics2D21, rectangle2D22, 3, plotRenderingInfo26, crosshairState28);
        crosshairState28.setAnchorX(0.0d);
        boolean boolean33 = standardXYToolTipGenerator3.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(plotRenderingInfo26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-33));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -33");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 4, range1, lengthConstraintType2, 1.0E-5d, range4, lengthConstraintType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        int int10 = xYSeriesCollection4.indexOf(xYSeries9);
        org.jfree.data.Range range12 = xYSeriesCollection4.getDomainBounds(false);
        org.jfree.data.xy.XYSeries xYSeries16 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        xYSeriesCollection4.addSeries(xYSeries16);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        double double1 = combinedRangeXYPlot0.getGap();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double4 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month7);
        java.text.DateFormat dateFormat10 = null;
        java.text.DateFormat dateFormat11 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator12 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat10, dateFormat11);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator12, xYURLGenerator13);
        java.awt.Font font18 = xYStepRenderer14.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        boolean boolean21 = xYPlot20.isRangeCrosshairVisible();
        java.awt.Paint paint22 = xYPlot20.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis24.pan(0.0d);
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        xYStepRenderer14.drawRangeMarker(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) numberAxis24, marker27, rectangle2D28);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        xYPlot20.datasetChanged(datasetChangeEvent30);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit35 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int37 = numberTickUnit35.compareTo((java.lang.Object) 10);
        numberAxis33.setTickUnit(numberTickUnit35);
        numberAxis33.setMinorTickMarkInsideLength((-1.0f));
        numberAxis33.pan((double) 2147483647);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit46 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int48 = numberTickUnit46.compareTo((java.lang.Object) 10);
        numberAxis44.setTickUnit(numberTickUnit46);
        float float50 = numberAxis44.getMinorTickMarkInsideLength();
        java.awt.Shape shape51 = numberAxis44.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit55 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int57 = numberTickUnit55.compareTo((java.lang.Object) 10);
        numberAxis53.setTickUnit(numberTickUnit55);
        java.awt.Shape shape65 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color66 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke67 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint68 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape65, (java.awt.Paint) color66, stroke67, paint68);
        numberAxis53.setRightArrow(shape65);
        org.jfree.chart.axis.NumberAxis numberAxis72 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape73 = numberAxis72.getLeftArrow();
        java.awt.Paint paint74 = numberAxis72.getTickLabelPaint();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray75 = new org.jfree.chart.axis.ValueAxis[] { numberAxis33, numberAxis44, numberAxis53, numberAxis72 };
        xYPlot20.setDomainAxes(valueAxisArray75);
        int int77 = month7.compareTo((java.lang.Object) xYPlot20);
        combinedRangeXYPlot0.add(xYPlot20, 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 0.0f + "'", float50 == 0.0f);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(shape73);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(valueAxisArray75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection2 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        try {
            java.lang.Number number7 = xYSeriesCollection4.getY(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list2 = timeSeries1.getItems();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries1.getTimePeriod((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot1.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener4 = null;
        timeSeriesCollection2.addChangeListener(datasetChangeListener4);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeriesCollection2.getSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.DomainOrder domainOrder8 = timeSeriesCollection2.getDomainOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis3D10.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D13, rectangleEdge14);
        java.awt.Paint paint17 = null;
        categoryAxis3D10.setTickLabelPaint((java.lang.Comparable) 1.0d, paint17);
        java.awt.Font font20 = categoryAxis3D10.getTickLabelFont((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) categoryAxis3D10, seriesChangeInfo21);
        timeSeriesCollection2.seriesChanged(seriesChangeEvent22);
        timeSeriesCollection0.seriesChanged(seriesChangeEvent22);
        try {
            org.jfree.data.time.TimeSeries timeSeries26 = timeSeriesCollection0.getSeries(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (2147483647).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeries7);
        org.junit.Assert.assertNotNull(domainOrder8);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        org.jfree.chart.title.Title title3 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity5 = new org.jfree.chart.entity.TitleEntity(shape2, title3, "ItemLabelAnchor.INSIDE11");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'title' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot11.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot11.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot11.setOrientation(plotOrientation15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 10.0f);
        float float22 = intervalMarker21.getAlpha();
        org.jfree.chart.entity.EntityCollection entityCollection23 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo(entityCollection23);
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo24.getChartArea();
        chartRenderingInfo24.clear();
        java.awt.geom.Rectangle2D rectangle2D27 = chartRenderingInfo24.getChartArea();
        xYStepRenderer5.drawDomainMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis18, (org.jfree.chart.plot.Marker) intervalMarker21, rectangle2D27);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.8f + "'", float22 == 0.8f);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D27);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Paint paint2 = xYPlot0.getBackgroundPaint();
        xYPlot0.setRangeCrosshairValue(0.0d, true);
        boolean boolean6 = xYPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape10 = numberAxis9.getLeftArrow();
        java.awt.Paint paint11 = numberAxis9.getTickLabelPaint();
        xYPlot0.setDomainAxis(2, (org.jfree.chart.axis.ValueAxis) numberAxis9, false);
        xYPlot0.setRangePannable(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape13, (java.awt.Paint) color14, stroke15, paint16);
        numberAxis1.setRightArrow(shape13);
        numberAxis1.configure();
        numberAxis1.setTickMarksVisible(true);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = categoryAxis3D24.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D27, rectangleEdge28);
        java.awt.Font font31 = null;
        categoryAxis3D24.setTickLabelFont((java.lang.Comparable) (-1L), font31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.text.TextLine textLine37 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean39 = textLine37.equals((java.lang.Object) rectangleEdge38);
        org.jfree.chart.axis.AxisState axisState40 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D24.drawTickMarks(graphics2D33, (double) 1.0f, rectangle2D35, rectangleEdge38, axisState40);
        org.jfree.chart.entity.EntityCollection entityCollection46 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = new org.jfree.chart.ChartRenderingInfo(entityCollection46);
        java.awt.geom.Rectangle2D rectangle2D48 = chartRenderingInfo47.getChartArea();
        chartRenderingInfo47.clear();
        java.awt.geom.Rectangle2D rectangle2D50 = chartRenderingInfo47.getChartArea();
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit55 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int57 = numberTickUnit55.compareTo((java.lang.Object) 10);
        numberAxis53.setTickUnit(numberTickUnit55);
        float float59 = numberAxis53.getMinorTickMarkInsideLength();
        java.awt.Shape shape62 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity65 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis53, shape62, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D66 = null;
        org.jfree.chart.axis.AxisState axisState67 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = null;
        java.util.List list70 = numberAxis53.refreshTicks(graphics2D66, axisState67, rectangle2D68, rectangleEdge69);
        org.jfree.chart.plot.XYPlot xYPlot71 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection72 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot71.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection72);
        java.awt.Color color74 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot71.setRangeZeroBaselinePaint((java.awt.Paint) color74);
        numberAxis53.setTickLabelPaint((java.awt.Paint) color74);
        org.jfree.chart.LegendItem legendItem77 = new org.jfree.chart.LegendItem("item", "Last", "DateTickMarkPosition.MIDDLE", "{0}: ({1}, {2})", (java.awt.Shape) rectangle2D50, stroke51, (java.awt.Paint) color74);
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = null;
        java.util.List list79 = numberAxis1.refreshTicks(graphics2D22, axisState40, rectangle2D50, rectangleEdge78);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 0.0f + "'", float59 == 0.0f);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertNotNull(list70);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(list79);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot0.getRangeAxis(10);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis3D11.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D14, rectangleEdge15);
        java.awt.Font font18 = null;
        categoryAxis3D11.setTickLabelFont((java.lang.Comparable) (-1L), font18);
        org.jfree.chart.entity.EntityCollection entityCollection25 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = new org.jfree.chart.ChartRenderingInfo(entityCollection25);
        java.awt.geom.Rectangle2D rectangle2D27 = chartRenderingInfo26.getChartArea();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = categoryAxis3D29.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D32, rectangleEdge33);
        java.awt.Font font36 = null;
        categoryAxis3D29.setTickLabelFont((java.lang.Comparable) (-1L), font36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.text.TextLine textLine42 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean44 = textLine42.equals((java.lang.Object) rectangleEdge43);
        org.jfree.chart.axis.AxisState axisState45 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D29.drawTickMarks(graphics2D38, (double) 1.0f, rectangle2D40, rectangleEdge43, axisState45);
        double double47 = categoryAxis3D11.getCategorySeriesMiddle(4, (int) '#', (int) (byte) -1, (int) (short) 100, Double.POSITIVE_INFINITY, rectangle2D27, rectangleEdge43);
        try {
            xYPlot0.drawBackground(graphics2D9, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        xYPlot11.datasetChanged(datasetChangeEvent21);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit26 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int28 = numberTickUnit26.compareTo((java.lang.Object) 10);
        numberAxis24.setTickUnit(numberTickUnit26);
        numberAxis24.setMinorTickMarkInsideLength((-1.0f));
        numberAxis24.pan((double) 2147483647);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int39 = numberTickUnit37.compareTo((java.lang.Object) 10);
        numberAxis35.setTickUnit(numberTickUnit37);
        float float41 = numberAxis35.getMinorTickMarkInsideLength();
        java.awt.Shape shape42 = numberAxis35.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit46 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int48 = numberTickUnit46.compareTo((java.lang.Object) 10);
        numberAxis44.setTickUnit(numberTickUnit46);
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint59 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem60 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape56, (java.awt.Paint) color57, stroke58, paint59);
        numberAxis44.setRightArrow(shape56);
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape64 = numberAxis63.getLeftArrow();
        java.awt.Paint paint65 = numberAxis63.getTickLabelPaint();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray66 = new org.jfree.chart.axis.ValueAxis[] { numberAxis24, numberAxis35, numberAxis44, numberAxis63 };
        xYPlot11.setDomainAxes(valueAxisArray66);
        org.jfree.chart.util.Layer layer68 = null;
        java.util.Collection collection69 = xYPlot11.getRangeMarkers(layer68);
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis71.pan(0.0d);
        xYPlot11.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis71);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(valueAxisArray66);
        org.junit.Assert.assertNull(collection69);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        float float3 = numberAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("");
        textLine1.removeFragment(textFragment3);
        java.lang.String str5 = textFragment3.getText();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TitleEntity: tooltip = null");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection1.getSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection1.getDomainOrder();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot8.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot8.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot8.setOrientation(plotOrientation12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list18 = timeSeries17.getItems();
        xYPlot8.drawRangeTickBands(graphics2D14, rectangle2D15, list18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list18, true);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double24 = timeSeries23.getMinY();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double29 = timeSeries28.getMinY();
        timeSeries28.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        int int33 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.Year year34 = month32.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 255, true);
        java.lang.Class class39 = timeSeries23.getTimePeriodClass();
        timeSeriesCollection1.removeSeries(timeSeries23);
        try {
            int int44 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) timeSeriesCollection1, 7, (double) 0, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeries6);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(class39);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("ThreadContext", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setTickMarkOutsideLength(10.0f);
        numberAxis1.setLowerBound((double) 100.0f);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint29 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape26, (java.awt.Paint) color27, stroke28, paint29);
        java.awt.Stroke stroke31 = legendItem30.getOutlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit35 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int37 = numberTickUnit35.compareTo((java.lang.Object) 10);
        numberAxis33.setTickUnit(numberTickUnit35);
        float float39 = numberAxis33.getMinorTickMarkInsideLength();
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity45 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis33, shape42, "hi!", "{0}: ({1}, {2})");
        legendItem30.setShape(shape42);
        legendItem30.setURLText("ItemLabelAnchor.INSIDE11");
        java.awt.Font font49 = legendItem30.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle52 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint53 = textTitle52.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean55 = categoryPlot54.isDomainGridlinesVisible();
        java.awt.Stroke stroke56 = categoryPlot54.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) 2, paint53, stroke56);
        java.awt.Font font58 = valueMarker57.getLabelFont();
        legendItem30.setLabelFont(font58);
        numberAxis1.setTickLabelFont(font58);
        boolean boolean61 = numberAxis1.isMinorTickMarksVisible();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.0f + "'", float39 == 0.0f);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(font49);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo1.getChartArea();
        chartRenderingInfo1.clear();
        java.awt.geom.Rectangle2D rectangle2D4 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.RenderingSource renderingSource5 = chartRenderingInfo1.getRenderingSource();
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNull(renderingSource5);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setAnchorValue((double) 10, true);
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        boolean boolean6 = categoryPlot0.isRangePannable();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boolean boolean8 = categoryPlot0.equals((java.lang.Object) color7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.pan(0.0d);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        numberAxis1.setStandardTickUnits(tickUnitSource4);
        numberAxis1.setLabelAngle((double) (byte) -1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        try {
            java.awt.Color color1 = java.awt.Color.decode("JFreeChartEntity: tooltip = null");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"JFreeChartEntity: tooltip = null\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(255);
        barRenderer0.setDefaultEntityRadius(5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer2.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer2.setNegativeItemLabelPositionFallback(itemLabelPosition5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer2.setSeriesURLGenerator(0, categoryURLGenerator8);
        java.text.DateFormat dateFormat11 = null;
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator13 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat11, dateFormat12);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset14 = new org.jfree.data.xy.DefaultXYDataset();
        boolean boolean15 = standardXYToolTipGenerator13.equals((java.lang.Object) defaultXYDataset14);
        boolean boolean16 = barRenderer2.equals((java.lang.Object) standardXYToolTipGenerator13);
        barRenderer2.clearSeriesStrokes(true);
        boolean boolean19 = defaultXYDataset0.equals((java.lang.Object) true);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, false);
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        xYPlot11.datasetChanged(datasetChangeEvent21);
        java.awt.Stroke stroke23 = null;
        try {
            xYPlot11.setDomainCrosshairStroke(stroke23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        java.awt.Stroke stroke11 = legendItem10.getOutlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int17 = numberTickUnit15.compareTo((java.lang.Object) 10);
        numberAxis13.setTickUnit(numberTickUnit15);
        float float19 = numberAxis13.getMinorTickMarkInsideLength();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis13, shape22, "hi!", "{0}: ({1}, {2})");
        legendItem10.setShape(shape22);
        legendItem10.setURLText("ItemLabelAnchor.INSIDE11");
        java.awt.Shape shape29 = legendItem10.getShape();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        xYPlot0.setDomainMinorGridlinesVisible(false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CrosshairState crosshairState14 = new org.jfree.chart.plot.CrosshairState(false);
        boolean boolean15 = xYPlot0.render(graphics2D9, rectangle2D10, (int) (short) 0, plotRenderingInfo12, crosshairState14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation(axisLocation16);
        xYPlot0.setWeight(7);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        java.text.NumberFormat numberFormat4 = standardXYToolTipGenerator3.getYFormat();
        java.text.DateFormat dateFormat5 = standardXYToolTipGenerator3.getYDateFormat();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer7 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator6);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertNull(dateFormat5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Stroke stroke7 = xYStepRenderer5.lookupSeriesStroke((int) (byte) 0);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = null;
        xYStepRenderer5.setBaseItemLabelGenerator(xYItemLabelGenerator8, false);
        java.awt.Paint paint12 = xYStepRenderer5.lookupSeriesPaint((int) (short) -1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        barRenderer0.setSeriesURLGenerator(0, categoryURLGenerator6);
        java.text.DateFormat dateFormat9 = null;
        java.text.DateFormat dateFormat10 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat9, dateFormat10);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        boolean boolean13 = standardXYToolTipGenerator11.equals((java.lang.Object) defaultXYDataset12);
        boolean boolean14 = barRenderer0.equals((java.lang.Object) standardXYToolTipGenerator11);
        java.text.DateFormat dateFormat15 = standardXYToolTipGenerator11.getXDateFormat();
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(dateFormat15);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list2 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list5 = timeSeries4.getItems();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double8 = timeSeries7.getMinY();
        timeSeries7.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month11);
        org.jfree.data.time.Year year13 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        timeSeries4.add(regularTimePeriod14, (double) 2958465);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod14, 0.0d);
        timeSeries1.add(timeSeriesDataItem18, true);
        long long21 = timeSeries1.getMaximumItemAge();
        int int22 = timeSeries1.getItemCount();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        boolean boolean6 = barRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            barRenderer0.addAnnotation(categoryAnnotation7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(layer8);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean3 = textLine1.equals((java.lang.Object) rectangleEdge2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        java.lang.Object obj12 = null;
        boolean boolean13 = textAnchor11.equals(obj12);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        java.awt.Shape shape16 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D8, (float) 10L, (float) '4', textAnchor11, (double) 24234L, textAnchor15);
        try {
            textLine1.draw(graphics2D4, (float) (short) 0, (float) 0L, textAnchor11, (float) 3, (float) (byte) 1, (double) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNull(shape16);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        boolean boolean6 = barRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        double double7 = barRenderer0.getUpperClip();
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        timeSeries1.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        java.text.DateFormat dateFormat8 = null;
        java.text.DateFormat dateFormat9 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator10 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat8, dateFormat9);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator10, xYURLGenerator11);
        java.awt.Font font16 = xYStepRenderer12.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        boolean boolean19 = xYPlot18.isRangeCrosshairVisible();
        java.awt.Paint paint20 = xYPlot18.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis22.pan(0.0d);
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        xYStepRenderer12.drawRangeMarker(graphics2D17, xYPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis22, marker25, rectangle2D26);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = null;
        xYPlot18.datasetChanged(datasetChangeEvent28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int35 = numberTickUnit33.compareTo((java.lang.Object) 10);
        numberAxis31.setTickUnit(numberTickUnit33);
        numberAxis31.setMinorTickMarkInsideLength((-1.0f));
        numberAxis31.pan((double) 2147483647);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit44 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int46 = numberTickUnit44.compareTo((java.lang.Object) 10);
        numberAxis42.setTickUnit(numberTickUnit44);
        float float48 = numberAxis42.getMinorTickMarkInsideLength();
        java.awt.Shape shape49 = numberAxis42.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit53 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int55 = numberTickUnit53.compareTo((java.lang.Object) 10);
        numberAxis51.setTickUnit(numberTickUnit53);
        java.awt.Shape shape63 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke65 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint66 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape63, (java.awt.Paint) color64, stroke65, paint66);
        numberAxis51.setRightArrow(shape63);
        org.jfree.chart.axis.NumberAxis numberAxis70 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape71 = numberAxis70.getLeftArrow();
        java.awt.Paint paint72 = numberAxis70.getTickLabelPaint();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray73 = new org.jfree.chart.axis.ValueAxis[] { numberAxis31, numberAxis42, numberAxis51, numberAxis70 };
        xYPlot18.setDomainAxes(valueAxisArray73);
        int int75 = month5.compareTo((java.lang.Object) xYPlot18);
        org.jfree.chart.entity.EntityCollection entityCollection78 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo79 = new org.jfree.chart.ChartRenderingInfo(entityCollection78);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = chartRenderingInfo79.getPlotInfo();
        xYPlot18.handleClick(5, (int) (byte) 10, plotRenderingInfo80);
        java.awt.Paint paint82 = xYPlot18.getRangeTickBandPaint();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 0.0f + "'", float48 == 0.0f);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(shape71);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(valueAxisArray73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertNotNull(plotRenderingInfo80);
        org.junit.Assert.assertNull(paint82);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape6, paint13);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity18 = new org.jfree.chart.entity.AxisEntity(shape6, (org.jfree.chart.axis.Axis) categoryAxis3D15, "", "Size2D[width=0.0, height=0.0]");
        categoryAxis3D15.setTickMarksVisible(false);
        float float21 = categoryAxis3D15.getMinorTickMarkInsideLength();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean2 = categoryPlot1.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot1.getDrawingSupplier();
        waferMapPlot0.setDrawingSupplier(drawingSupplier4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 100);
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection5 = xYAreaRenderer4.getAnnotations();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYAreaRenderer4);
        boolean boolean7 = multiplePiePlot0.equals((java.lang.Object) xYAreaRenderer4);
        boolean boolean8 = xYAreaRenderer4.getUseFillPaint();
        xYAreaRenderer4.setBaseCreateEntities(false, false);
        xYAreaRenderer4.setUseFillPaint(false);
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        org.jfree.data.xy.XYDataItem xYDataItem3 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 5, (java.lang.Number) 1);
        xYDataItem3.setSelected(false);
        double double6 = xYDataItem3.getXValue();
        boolean boolean7 = strokeMap0.containsKey((java.lang.Comparable) xYDataItem3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("DomainOrder.ASCENDING");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition11 = dateAxis10.getTickMarkPosition();
        java.util.Date date12 = dateAxis10.getMaximumDate();
        java.lang.String str13 = dateTickUnit8.dateToString(date12);
        java.awt.Stroke stroke14 = strokeMap0.getStroke((java.lang.Comparable) str13);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.0d + "'", double6 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "12/31/69 4:00 PM" + "'", str13.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNull(stroke14);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DomainOrder.ASCENDING");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
        java.util.TimeZone timeZone3 = null;
        try {
            dateAxis1.setTimeZone(timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        java.awt.Stroke stroke11 = legendItem10.getOutlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int17 = numberTickUnit15.compareTo((java.lang.Object) 10);
        numberAxis13.setTickUnit(numberTickUnit15);
        float float19 = numberAxis13.getMinorTickMarkInsideLength();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis13, shape22, "hi!", "{0}: ({1}, {2})");
        legendItem10.setShape(shape22);
        org.jfree.chart.text.TextFragment textFragment28 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font29 = textFragment28.getFont();
        java.awt.Paint paint30 = textFragment28.getPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic31 = new org.jfree.chart.title.LegendGraphic(shape22, paint30);
        legendGraphic31.setShapeFilled(true);
        legendGraphic31.setShapeVisible(true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        double double3 = piePlot2.getStartAngle();
        double double4 = piePlot2.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        double double7 = piePlot6.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot6.getLabelPadding();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator9 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot6.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator9);
        piePlot2.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator9);
        org.jfree.chart.entity.EntityCollection entityCollection16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo(entityCollection16);
        java.awt.geom.Rectangle2D rectangle2D18 = chartRenderingInfo17.getChartArea();
        chartRenderingInfo17.clear();
        java.awt.geom.Rectangle2D rectangle2D20 = chartRenderingInfo17.getChartArea();
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit25 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int27 = numberTickUnit25.compareTo((java.lang.Object) 10);
        numberAxis23.setTickUnit(numberTickUnit25);
        float float29 = numberAxis23.getMinorTickMarkInsideLength();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity35 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis23, shape32, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.AxisState axisState37 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        java.util.List list40 = numberAxis23.refreshTicks(graphics2D36, axisState37, rectangle2D38, rectangleEdge39);
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection42 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot41.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection42);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot41.setRangeZeroBaselinePaint((java.awt.Paint) color44);
        numberAxis23.setTickLabelPaint((java.awt.Paint) color44);
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("item", "Last", "DateTickMarkPosition.MIDDLE", "{0}: ({1}, {2})", (java.awt.Shape) rectangle2D20, stroke21, (java.awt.Paint) color44);
        piePlot2.setLegendItemShape((java.awt.Shape) rectangle2D20);
        try {
            boolean boolean49 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 90.0d + "'", double3 == 90.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(color44);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot1.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener4 = null;
        timeSeriesCollection2.addChangeListener(datasetChangeListener4);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeriesCollection2.getSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.DomainOrder domainOrder8 = timeSeriesCollection2.getDomainOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis3D10.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D13, rectangleEdge14);
        java.awt.Paint paint17 = null;
        categoryAxis3D10.setTickLabelPaint((java.lang.Comparable) 1.0d, paint17);
        java.awt.Font font20 = categoryAxis3D10.getTickLabelFont((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) categoryAxis3D10, seriesChangeInfo21);
        timeSeriesCollection2.seriesChanged(seriesChangeEvent22);
        timeSeriesCollection0.seriesChanged(seriesChangeEvent22);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0, false);
        org.junit.Assert.assertNull(timeSeries7);
        org.junit.Assert.assertNotNull(domainOrder8);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(range26);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint14 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape10, paint14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        legendGraphic15.setOutlineStroke(stroke16);
        java.awt.Paint paint18 = legendGraphic15.getOutlinePaint();
        java.awt.Paint paint19 = legendGraphic15.getLinePaint();
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        legendGraphic15.setOutlinePaint(paint20);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 1.0f, false);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint7 = textTitle6.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.isDomainGridlinesVisible();
        java.awt.Stroke stroke10 = categoryPlot8.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 2, paint7, stroke10);
        categoryPlot0.setRangeCrosshairStroke(stroke10);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot0.getRendererForDataset(categoryDataset13);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(categoryItemRenderer14);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D4, rectangleEdge5);
        java.awt.Paint paint8 = null;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) 1.0d, paint8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis3D13.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D16, rectangleEdge17);
        java.awt.Paint paint20 = null;
        categoryAxis3D13.setTickLabelPaint((java.lang.Comparable) 1.0d, paint20);
        java.awt.Font font23 = categoryAxis3D13.getTickLabelFont((java.lang.Comparable) 100L);
        categoryAxis3D13.removeCategoryLabelToolTip((java.lang.Comparable) "[size=10]");
        org.jfree.data.xy.XYDataItem xYDataItem28 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 5, (java.lang.Number) 1);
        xYDataItem28.setSelected(false);
        categoryAxis3D13.addCategoryLabelToolTip((java.lang.Comparable) xYDataItem28, "Value");
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.axis.AxisState axisState34 = new org.jfree.chart.axis.AxisState();
        axisState34.cursorDown((double) 0.0f);
        org.jfree.chart.entity.EntityCollection entityCollection41 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo(entityCollection41);
        java.awt.geom.Rectangle2D rectangle2D43 = chartRenderingInfo42.getChartArea();
        chartRenderingInfo42.clear();
        java.awt.geom.Rectangle2D rectangle2D45 = chartRenderingInfo42.getChartArea();
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit50 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int52 = numberTickUnit50.compareTo((java.lang.Object) 10);
        numberAxis48.setTickUnit(numberTickUnit50);
        float float54 = numberAxis48.getMinorTickMarkInsideLength();
        java.awt.Shape shape57 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity60 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis48, shape57, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.axis.AxisState axisState62 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        java.util.List list65 = numberAxis48.refreshTicks(graphics2D61, axisState62, rectangle2D63, rectangleEdge64);
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection67 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot66.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection67);
        java.awt.Color color69 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot66.setRangeZeroBaselinePaint((java.awt.Paint) color69);
        numberAxis48.setTickLabelPaint((java.awt.Paint) color69);
        org.jfree.chart.LegendItem legendItem72 = new org.jfree.chart.LegendItem("item", "Last", "DateTickMarkPosition.MIDDLE", "{0}: ({1}, {2})", (java.awt.Shape) rectangle2D45, stroke46, (java.awt.Paint) color69);
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = org.jfree.chart.util.RectangleEdge.TOP;
        java.util.List list74 = categoryAxis3D13.refreshTicks(graphics2D33, axisState34, rectangle2D45, rectangleEdge73);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D76 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D79 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = null;
        double double81 = categoryAxis3D76.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D79, rectangleEdge80);
        java.awt.Font font83 = null;
        categoryAxis3D76.setTickLabelFont((java.lang.Comparable) (-1L), font83);
        java.awt.Graphics2D graphics2D85 = null;
        java.awt.geom.Rectangle2D rectangle2D87 = null;
        org.jfree.chart.text.TextLine textLine89 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge90 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean91 = textLine89.equals((java.lang.Object) rectangleEdge90);
        org.jfree.chart.axis.AxisState axisState92 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D76.drawTickMarks(graphics2D85, (double) 1.0f, rectangle2D87, rectangleEdge90, axisState92);
        boolean boolean94 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge90);
        double double95 = categoryAxis3D1.getCategoryStart(10, 1, rectangle2D45, rectangleEdge90);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 0.0f + "'", float54 == 0.0f);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(list65);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertNotNull(list74);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 100);
        java.lang.Object obj3 = multiplePiePlot0.clone();
        org.jfree.chart.plot.Plot plot4 = multiplePiePlot0.getParent();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot0.setOrientation(plotOrientation4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list10 = timeSeries9.getItems();
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace12);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 1.0f, false);
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font6 = textFragment5.getFont();
        java.awt.Paint paint7 = textFragment5.getPaint();
        categoryPlot0.setRangeCrosshairPaint(paint7);
        categoryPlot0.mapDatasetToRangeAxis(1, (int) (byte) 0);
        categoryPlot0.clearDomainMarkers(100);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setAnchorValue((double) 10, true);
        int int5 = categoryPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Multiple Pie Plot");
        int int2 = legendItem1.getSeriesIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 0, (java.lang.Boolean) false, true);
        boolean boolean5 = barRenderer0.isDrawBarOutline();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.Range range7 = barRenderer0.findRangeBounds(categoryDataset6);
        barRenderer0.removeAnnotations();
        barRenderer0.setMaximumBarWidth((double) 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape8 = numberAxis1.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot9.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint12, (java.lang.Object) basicProjectInfo13);
        xYPlot9.setRangeCrosshairPaint(paint12);
        java.awt.Paint paint16 = xYPlot9.getRangeCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) xYPlot9, "{0}: ({1}, {2})");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.lang.String str21 = textTitle20.getToolTipText();
        org.jfree.chart.entity.TitleEntity titleEntity22 = new org.jfree.chart.entity.TitleEntity(shape8, (org.jfree.chart.title.Title) textTitle20);
        java.lang.String str23 = titleEntity22.toString();
        org.jfree.chart.title.Title title24 = titleEntity22.getTitle();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "TitleEntity: tooltip = null" + "'", str23.equals("TitleEntity: tooltip = null"));
        org.junit.Assert.assertNotNull(title24);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape8 = numberAxis1.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot9.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint12, (java.lang.Object) basicProjectInfo13);
        xYPlot9.setRangeCrosshairPaint(paint12);
        java.awt.Paint paint16 = xYPlot9.getRangeCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) xYPlot9, "{0}: ({1}, {2})");
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint23 = textTitle22.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean25 = categoryPlot24.isDomainGridlinesVisible();
        java.awt.Stroke stroke26 = categoryPlot24.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 2, paint23, stroke26);
        java.awt.Font font28 = valueMarker27.getLabelFont();
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean30 = xYPlot9.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker27, layer29);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit34 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int36 = numberTickUnit34.compareTo((java.lang.Object) 10);
        numberAxis32.setTickUnit(numberTickUnit34);
        float float38 = numberAxis32.getMinorTickMarkInsideLength();
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity44 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis32, shape41, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint45 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic46 = new org.jfree.chart.title.LegendGraphic(shape41, paint45);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer47 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor48 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        boolean boolean49 = standardGradientPaintTransformer47.equals((java.lang.Object) itemLabelAnchor48);
        legendGraphic46.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer47);
        boolean boolean51 = valueMarker27.equals((java.lang.Object) standardGradientPaintTransformer47);
        java.awt.Shape shape58 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke60 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint61 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem62 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape58, (java.awt.Paint) color59, stroke60, paint61);
        java.awt.Stroke stroke63 = legendItem62.getOutlineStroke();
        valueMarker27.setStroke(stroke63);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 0.0f + "'", float38 == 0.0f);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(itemLabelAnchor48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(stroke63);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 10.0f);
        java.awt.Stroke stroke3 = intervalMarker2.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("RectangleAnchor.BOTTOM_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleAnchor.BOTTOM_RIGHT");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint10 = xYStepRenderer5.getItemFillPaint(0, (int) (short) 100, false);
        xYStepRenderer5.clearSeriesStrokes(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = xYStepRenderer5.getSeriesURLGenerator(8);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(xYURLGenerator14);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Color color1 = java.awt.Color.getColor("AxisLabelEntity: label = hi!");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        int int3 = java.awt.Color.HSBtoRGB((float) 3600000L, (float) 24234L, (float) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-65536) + "'", int3 == (-65536));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot1.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot1.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot1.setOrientation(plotOrientation5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list11 = timeSeries10.getItems();
        xYPlot1.drawRangeTickBands(graphics2D7, rectangle2D8, list11);
        projectInfo0.setContributors(list11);
        java.lang.String str14 = projectInfo0.getLicenceText();
        java.awt.Image image15 = null;
        projectInfo0.setLogo(image15);
        java.util.List list17 = projectInfo0.getContributors();
        java.lang.String str18 = projectInfo0.getVersion();
        java.awt.Image image19 = projectInfo0.getLogo();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(image19);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        long long3 = month2.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 35L);
        timeSeries1.add(timeSeriesDataItem5, true);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list12 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list15 = timeSeries14.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double18 = timeSeries17.getMinY();
        timeSeries17.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) month21);
        org.jfree.data.time.Year year23 = month21.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        timeSeries14.add(regularTimePeriod24, (double) 2958465);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod24, 0.0d);
        timeSeries11.add(timeSeriesDataItem28, true);
        long long31 = timeSeries11.getMaximumItemAge();
        try {
            org.jfree.data.time.TimeSeries timeSeries32 = timeSeries1.addAndOrUpdate(timeSeries11);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        float float2 = textFragment1.getBaselineOffset();
        java.lang.String str3 = textFragment1.getText();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape10, (java.awt.Paint) color11, stroke12, paint13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        boolean boolean16 = xYPlot15.isRangeCrosshairVisible();
        java.awt.Paint paint17 = xYPlot15.getBackgroundPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape10, paint17);
        boolean boolean19 = textFragment1.equals((java.lang.Object) shape10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.entity.EntityCollection entityCollection18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo(entityCollection18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = chartRenderingInfo19.getPlotInfo();
        org.jfree.chart.plot.CrosshairState crosshairState22 = new org.jfree.chart.plot.CrosshairState(false);
        int int23 = crosshairState22.getRangeAxisIndex();
        boolean boolean24 = xYPlot0.render(graphics2D15, rectangle2D16, 3, plotRenderingInfo20, crosshairState22);
        double double25 = crosshairState22.getCrosshairX();
        java.awt.geom.Point2D point2D26 = null;
        crosshairState22.setAnchor(point2D26);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(plotRenderingInfo20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        categoryPlot0.clearRangeMarkers((int) (byte) 0);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(axisSpace21);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DomainOrder.ASCENDING");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
        java.util.Date date3 = dateAxis1.getMaximumDate();
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection1 = xYAreaRenderer0.getAnnotations();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer0.setSeriesStroke(0, stroke3, true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        boolean boolean7 = xYPlot6.isRangeCrosshairVisible();
        java.awt.Paint paint8 = xYPlot6.getBackgroundPaint();
        xYAreaRenderer0.setBaseOutlinePaint(paint8, false);
        java.awt.Shape shape11 = xYAreaRenderer0.getLegendArea();
        boolean boolean12 = xYAreaRenderer0.getPlotArea();
        xYAreaRenderer0.setBaseSeriesVisible(true);
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 1.0f, false);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint7 = textTitle6.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.isDomainGridlinesVisible();
        java.awt.Stroke stroke10 = categoryPlot8.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 2, paint7, stroke10);
        categoryPlot0.setRangeCrosshairStroke(stroke10);
        java.awt.Paint paint13 = categoryPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 10.0f);
        float float18 = intervalMarker17.getAlpha();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.8f + "'", float18 == 0.8f);
        org.junit.Assert.assertNull(valueAxis20);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int12 = numberTickUnit10.compareTo((java.lang.Object) 10);
        numberAxis8.setTickUnit(numberTickUnit10);
        float float14 = numberAxis8.getMinorTickMarkInsideLength();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity20 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis8, shape17, "hi!", "{0}: ({1}, {2})");
        int int21 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis8);
        numberAxis8.setAutoRangeIncludesZero(false);
        java.awt.Shape shape24 = numberAxis8.getDownArrow();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextBlockAnchor.BOTTOM_RIGHT", graphics2D1, (float) (byte) 0, 0.0f, (double) 100L, (float) (short) -1, (float) 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double7 = timeSeries6.getMinY();
        timeSeries6.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 255, true);
        java.lang.String str17 = timeSeries1.getRangeDescription();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int23 = numberTickUnit21.compareTo((java.lang.Object) 10);
        numberAxis19.setTickUnit(numberTickUnit21);
        float float25 = numberAxis19.getMinorTickMarkInsideLength();
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity31 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis19, shape28, "hi!", "{0}: ({1}, {2})");
        numberAxis19.setVerticalTickLabels(false);
        numberAxis19.setTickMarkOutsideLength(10.0f);
        numberAxis19.setLowerBound((double) 100.0f);
        boolean boolean38 = timeSeries1.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D4, rectangleEdge5);
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean2 = categoryPlot1.isDomainGridlinesVisible();
        categoryPlot1.setAnchorValue((double) 10, true);
        boolean boolean6 = standardGradientPaintTransformer0.equals((java.lang.Object) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        xYPlot0.zoom((double) 0L);
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean14 = xYPlot0.isDomainPannable();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection1.getSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection1.getDomainOrder();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot8.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot8.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot8.setOrientation(plotOrientation12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list18 = timeSeries17.getItems();
        xYPlot8.drawRangeTickBands(graphics2D14, rectangle2D15, list18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list18, true);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double24 = timeSeries23.getMinY();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double29 = timeSeries28.getMinY();
        timeSeries28.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        int int33 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.Year year34 = month32.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 255, true);
        java.lang.Class class39 = timeSeries23.getTimePeriodClass();
        timeSeriesCollection1.removeSeries(timeSeries23);
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor42 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        java.lang.Object obj43 = null;
        boolean boolean44 = timePeriodAnchor42.equals(obj43);
        timeSeriesCollection1.setXPosition(timePeriodAnchor42);
        org.junit.Assert.assertNull(timeSeries6);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertEquals((double) number41, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timePeriodAnchor42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setAnchorValue((double) 10, true);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace5, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.height;
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        int int2 = crosshairState1.getRangeAxisIndex();
        crosshairState1.setCrosshairX(0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.setDomainPannable(true);
        java.awt.Stroke stroke10 = xYPlot0.getDomainZeroBaselineStroke();
        int int11 = xYPlot0.getDomainAxisCount();
        try {
            java.awt.Paint paint13 = xYPlot0.getQuadrantPaint((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (100) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("AxisEntity: tooltip = ", graphics2D1, 10.0f, 0.0f, textAnchor4, 0.0d, (float) (byte) 10, (float) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer5.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = xYStepRenderer5.hasListener((java.util.EventListener) categoryPlot25);
        categoryPlot25.setCrosshairDatasetIndex(0);
        categoryPlot25.setDomainCrosshairVisible(true);
        java.awt.Paint paint31 = categoryPlot25.getRangeGridlinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = null;
        org.jfree.chart.util.Layer layer33 = null;
        try {
            categoryPlot25.addDomainMarker(categoryMarker32, layer33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        int int7 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRendererForDataset(categoryDataset8);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection11 = xYAreaRenderer10.getAnnotations();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer10.setSeriesStroke(0, stroke13, true);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        boolean boolean17 = xYPlot16.isRangeCrosshairVisible();
        java.awt.Paint paint18 = xYPlot16.getBackgroundPaint();
        xYAreaRenderer10.setBaseOutlinePaint(paint18, false);
        java.awt.Shape shape21 = xYAreaRenderer10.getLegendArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean23 = categoryPlot22.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = categoryPlot22.getFixedLegendItems();
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot22);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity26 = new org.jfree.chart.entity.JFreeChartEntity(shape21, jFreeChart25);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart25);
        org.jfree.chart.event.ChartChangeListener chartChangeListener28 = null;
        try {
            jFreeChart25.removeChangeListener(chartChangeListener28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(legendItemCollection24);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        xYStepRenderer5.setBaseItemLabelsVisible(false, false);
        java.awt.Shape shape10 = xYStepRenderer5.getLegendLine();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 100);
        int int2 = pieLabelDistributor1.getItemCount();
        int int3 = pieLabelDistributor1.getItemCount();
        pieLabelDistributor1.sort();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        barRenderer0.setSeriesURLGenerator(0, categoryURLGenerator6);
        java.text.DateFormat dateFormat9 = null;
        java.text.DateFormat dateFormat10 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat9, dateFormat10);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        boolean boolean13 = standardXYToolTipGenerator11.equals((java.lang.Object) defaultXYDataset12);
        boolean boolean14 = barRenderer0.equals((java.lang.Object) standardXYToolTipGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer0.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint14 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape10, paint14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendGraphic15.getShapeLocation();
        legendGraphic15.setShapeFilled(false);
        boolean boolean19 = legendGraphic15.isShapeFilled();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list2 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list5 = timeSeries4.getItems();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double8 = timeSeries7.getMinY();
        timeSeries7.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month11);
        org.jfree.data.time.Year year13 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        timeSeries4.add(regularTimePeriod14, (double) 2958465);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod14, 0.0d);
        timeSeries1.add(timeSeriesDataItem18, true);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        long long22 = month21.getSerialIndex();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month21, (double) (-33), true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth(3.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        timeSeries1.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list9 = timeSeries8.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double12 = timeSeries11.getMinY();
        timeSeries11.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year17 = month15.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        timeSeries8.add(regularTimePeriod18, (double) 2958465);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod18, 0.0d);
        timeSeries1.add(timeSeriesDataItem22);
        java.lang.Object obj24 = timeSeriesDataItem22.clone();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double7 = timeSeries6.getMinY();
        timeSeries6.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 255, true);
        java.lang.Class class17 = timeSeries1.getTimePeriodClass();
        try {
            timeSeries1.update((int) (byte) -1, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(class17);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape8 = numberAxis1.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot9.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint12, (java.lang.Object) basicProjectInfo13);
        xYPlot9.setRangeCrosshairPaint(paint12);
        java.awt.Paint paint16 = xYPlot9.getRangeCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) xYPlot9, "{0}: ({1}, {2})");
        org.jfree.chart.plot.Plot plot19 = plotEntity18.getPlot();
        java.lang.String str20 = plotEntity18.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(plot19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PlotEntity: tooltip = {0}: ({1}, {2})" + "'", str20.equals("PlotEntity: tooltip = {0}: ({1}, {2})"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        xYPlot11.datasetChanged(datasetChangeEvent21);
        java.awt.geom.GeneralPath generalPath23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.RenderingSource renderingSource25 = null;
        xYPlot11.select(generalPath23, rectangle2D24, renderingSource25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot11.getRenderer();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(xYItemRenderer27);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        java.awt.Stroke stroke11 = legendItem10.getOutlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int17 = numberTickUnit15.compareTo((java.lang.Object) 10);
        numberAxis13.setTickUnit(numberTickUnit15);
        float float19 = numberAxis13.getMinorTickMarkInsideLength();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis13, shape22, "hi!", "{0}: ({1}, {2})");
        legendItem10.setShape(shape22);
        java.awt.Paint paint27 = legendItem10.getLinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit31 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int33 = numberTickUnit31.compareTo((java.lang.Object) 10);
        numberAxis29.setTickUnit(numberTickUnit31);
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke43 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint44 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape41, (java.awt.Paint) color42, stroke43, paint44);
        numberAxis29.setRightArrow(shape41);
        legendItem10.setShape(shape41);
        java.lang.String str48 = legendItem10.getLabel();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        java.awt.Stroke stroke11 = legendItem10.getOutlineStroke();
        java.awt.Stroke stroke12 = legendItem10.getLineStroke();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str1 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.TOP" + "'", str1.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        int int7 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setDomainCrosshairRowKey((java.lang.Comparable) 1.0f, false);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint15 = textTitle14.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryPlot16.isDomainGridlinesVisible();
        java.awt.Stroke stroke18 = categoryPlot16.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 2, paint15, stroke18);
        categoryPlot8.setRangeCrosshairStroke(stroke18);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        double double23 = piePlot22.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot22.getLabelPadding();
        java.awt.Paint paint25 = piePlot22.getBaseSectionOutlinePaint();
        categoryPlot8.setDomainCrosshairPaint(paint25);
        categoryPlot0.setBackgroundPaint(paint25);
        java.awt.Paint paint28 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Paint paint29 = categoryPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 90.0d + "'", double23 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.get(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int9 = numberTickUnit7.compareTo((java.lang.Object) 10);
        numberAxis5.setTickUnit(numberTickUnit7);
        float float11 = numberAxis5.getMinorTickMarkInsideLength();
        java.awt.Shape shape12 = numberAxis5.getLeftArrow();
        java.awt.Shape shape13 = null;
        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.equal(shape12, shape13);
        org.jfree.data.general.WaferMapDataset waferMapDataset15 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot16 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset15);
        waferMapPlot16.setNoDataMessage("hi!");
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        waferMapPlot16.setOutlineStroke(stroke19);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer21 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot23.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot23.setRangeZeroBaselinePaint((java.awt.Paint) color26);
        int int28 = color26.getBlue();
        xYAreaRenderer21.setSeriesItemLabelPaint((int) ' ', (java.awt.Paint) color26, false);
        try {
            org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem(attributedString0, "RectangleAnchor.BOTTOM_RIGHT", "12/31/69 4:00 PM", "DomainOrder.ASCENDING", shape12, stroke19, (java.awt.Paint) color26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 128 + "'", int28 == 128);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DomainOrder.ASCENDING");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis2.getTickMarkPosition();
        java.util.Date date4 = dateAxis2.getMaximumDate();
        java.lang.String str5 = dateTickUnit0.dateToString(date4);
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) str5);
        java.lang.Object obj7 = xYSeries6.clone();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12/31/69 4:00 PM" + "'", str5.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 0, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator6, false);
        double double9 = barRenderer0.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double6 = timeSeries5.getMinY();
        timeSeries5.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.Year year11 = month9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        java.lang.String str13 = standardPieSectionLabelGenerator2.generateSectionLabel(pieDataset3, (java.lang.Comparable) regularTimePeriod12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        long long16 = month15.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (double) 35L);
        org.jfree.data.time.Year year19 = month15.getYear();
        java.lang.String str20 = standardPieSectionLabelGenerator2.generateSectionLabel(pieDataset14, (java.lang.Comparable) year19);
        int int21 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getIgnoreNullValues();
        java.awt.Paint paint3 = piePlot1.getShadowPaint();
        java.awt.Paint paint4 = piePlot1.getBaseSectionOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        java.awt.Paint paint8 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo9 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint8, (java.lang.Object) basicProjectInfo9);
        xYPlot5.setRangeCrosshairPaint(paint8);
        java.awt.Paint paint12 = xYPlot5.getRangeCrosshairPaint();
        piePlot1.setLabelOutlinePaint(paint12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot6.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo10, point2D11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo17 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint16, (java.lang.Object) basicProjectInfo17);
        xYPlot13.setRangeCrosshairPaint(paint16);
        java.awt.Paint paint20 = xYPlot13.getRangeZeroBaselinePaint();
        xYPlot13.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = xYPlot13.getAxisOffset();
        categoryPlot6.setAxisOffset(rectangleInsets23);
        categoryPlot6.clearRangeMarkers((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot6.setRangeAxisLocation(255, axisLocation28);
        java.awt.Stroke stroke30 = categoryPlot6.getRangeCrosshairStroke();
        java.awt.Stroke stroke31 = categoryPlot6.getRangeGridlineStroke();
        java.util.List list32 = categoryPlot6.getCategories();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis3D34.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D37, rectangleEdge38);
        java.awt.Font font41 = null;
        categoryAxis3D34.setTickLabelFont((java.lang.Comparable) (-1L), font41);
        org.jfree.chart.entity.EntityCollection entityCollection48 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo49 = new org.jfree.chart.ChartRenderingInfo(entityCollection48);
        java.awt.geom.Rectangle2D rectangle2D50 = chartRenderingInfo49.getChartArea();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        double double57 = categoryAxis3D52.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D55, rectangleEdge56);
        java.awt.Font font59 = null;
        categoryAxis3D52.setTickLabelFont((java.lang.Comparable) (-1L), font59);
        java.awt.Graphics2D graphics2D61 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.text.TextLine textLine65 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean67 = textLine65.equals((java.lang.Object) rectangleEdge66);
        org.jfree.chart.axis.AxisState axisState68 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D52.drawTickMarks(graphics2D61, (double) 1.0f, rectangle2D63, rectangleEdge66, axisState68);
        double double70 = categoryAxis3D34.getCategorySeriesMiddle(4, (int) '#', (int) (byte) -1, (int) (short) 100, Double.POSITIVE_INFINITY, rectangle2D50, rectangleEdge66);
        try {
            barRenderer0.drawBackground(graphics2D5, categoryPlot6, rectangle2D50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(list32);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot1.getLabelDistributor();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font9 = textFragment8.getFont();
        java.awt.Paint paint10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("", font9, paint10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot12.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection13);
        java.awt.Paint paint15 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo16 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint15, (java.lang.Object) basicProjectInfo16);
        xYPlot12.setRangeCrosshairPaint(paint15);
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font9, paint15);
        piePlot1.setLabelFont(font9);
        piePlot1.clearSectionPaints(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double6 = timeSeries5.getMinY();
        timeSeries5.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.Year year11 = month9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        java.lang.String str13 = standardPieSectionLabelGenerator2.generateSectionLabel(pieDataset3, (java.lang.Comparable) regularTimePeriod12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        long long16 = month15.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (double) 35L);
        org.jfree.data.time.Year year19 = month15.getYear();
        java.lang.String str20 = standardPieSectionLabelGenerator2.generateSectionLabel(pieDataset14, (java.lang.Comparable) year19);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        java.lang.String str23 = standardPieSectionLabelGenerator2.generateSectionLabel(pieDataset21, (java.lang.Comparable) day22);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 0L, true);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        numberAxis1.setMinorTickMarkInsideLength((-1.0f));
        numberAxis1.setLabelURL("");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int6 = numberTickUnit4.compareTo((java.lang.Object) 10);
        numberAxis2.setTickUnit(numberTickUnit4);
        float float8 = numberAxis2.getMinorTickMarkInsideLength();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity14 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis2, shape11, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis2.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        try {
            org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset0, list19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = xYPlot0.getAxisOffset();
        org.jfree.data.general.WaferMapDataset waferMapDataset11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset11);
        waferMapPlot12.setNoDataMessage("hi!");
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        waferMapPlot12.setOutlineStroke(stroke15);
        xYPlot0.setDomainZeroBaselineStroke(stroke15);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection20 = xYAreaRenderer19.getAnnotations();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer19.setSeriesStroke(0, stroke22, true);
        java.awt.Paint paint28 = xYAreaRenderer19.getItemOutlinePaint((int) (short) 10, (int) (short) 100, false);
        try {
            xYPlot0.setQuadrantPaint((int) (short) 10, paint28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.lang.String str2 = textTitle1.getToolTipText();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        textTitle1.setBackgroundPaint((java.awt.Paint) color3);
        int int5 = color3.getTransparency();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItemCollection2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 60000L, (double) (short) 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        xYSeriesCollection4.removeSeries(xYSeries8);
        double double10 = xYSeries8.getMaxX();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        xYSeries8.removeChangeListener(seriesChangeListener11);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer5.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = xYStepRenderer5.hasListener((java.util.EventListener) categoryPlot25);
        java.util.List list27 = categoryPlot25.getCategories();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(list27);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.text.DateFormat dateFormat2 = null;
        java.text.DateFormat dateFormat3 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat2, dateFormat3);
        java.text.NumberFormat numberFormat5 = standardXYToolTipGenerator4.getYFormat();
        numberFormat5.setParseIntegerOnly(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat5);
        org.junit.Assert.assertNotNull(numberFormat5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = xYPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Stroke stroke7 = xYStepRenderer5.lookupSeriesStroke((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        xYStepRenderer5.setSeriesNegativeItemLabelPosition(3, itemLabelPosition9);
        xYStepRenderer5.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.plot.XYPlot xYPlot13 = xYStepRenderer5.getPlot();
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(xYPlot13);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot1.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot1.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot1.setOrientation(plotOrientation5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list11 = timeSeries10.getItems();
        xYPlot1.drawRangeTickBands(graphics2D7, rectangle2D8, list11);
        projectInfo0.setContributors(list11);
        java.lang.String str14 = projectInfo0.getLicenceText();
        java.awt.Image image15 = null;
        projectInfo0.setLogo(image15);
        java.util.List list17 = projectInfo0.getContributors();
        java.lang.String str18 = projectInfo0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str18.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        xYPlot11.datasetChanged(datasetChangeEvent21);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit26 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int28 = numberTickUnit26.compareTo((java.lang.Object) 10);
        numberAxis24.setTickUnit(numberTickUnit26);
        numberAxis24.setMinorTickMarkInsideLength((-1.0f));
        numberAxis24.pan((double) 2147483647);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int39 = numberTickUnit37.compareTo((java.lang.Object) 10);
        numberAxis35.setTickUnit(numberTickUnit37);
        float float41 = numberAxis35.getMinorTickMarkInsideLength();
        java.awt.Shape shape42 = numberAxis35.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit46 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int48 = numberTickUnit46.compareTo((java.lang.Object) 10);
        numberAxis44.setTickUnit(numberTickUnit46);
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint59 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem60 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape56, (java.awt.Paint) color57, stroke58, paint59);
        numberAxis44.setRightArrow(shape56);
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape64 = numberAxis63.getLeftArrow();
        java.awt.Paint paint65 = numberAxis63.getTickLabelPaint();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray66 = new org.jfree.chart.axis.ValueAxis[] { numberAxis24, numberAxis35, numberAxis44, numberAxis63 };
        xYPlot11.setDomainAxes(valueAxisArray66);
        java.awt.Paint paint68 = xYPlot11.getRangeGridlinePaint();
        java.awt.Paint paint69 = xYPlot11.getDomainGridlinePaint();
        org.jfree.chart.util.Layer layer70 = null;
        java.util.Collection collection71 = xYPlot11.getRangeMarkers(layer70);
        int int72 = xYPlot11.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(valueAxisArray66);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNull(collection71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 15 + "'", int72 == 15);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font6 = textFragment5.getFont();
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font6, paint7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot9.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint12, (java.lang.Object) basicProjectInfo13);
        xYPlot9.setRangeCrosshairPaint(paint12);
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font6, paint12);
        xYAreaRenderer0.setBaseItemLabelPaint(paint12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = xYAreaRenderer0.getPositiveItemLabelPosition(15, (int) ' ', true);
        java.lang.Boolean boolean23 = xYAreaRenderer0.getSeriesItemLabelsVisible(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNull(boolean23);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = xYPlot0.getAxisOffset();
        xYPlot0.setRangeMinorGridlinesVisible(true);
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, (float) 100L, (float) '#');
        xYPlot0.setDomainMinorGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot0.getDomainAxisEdge(2958465);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str1 = datasetGroup0.getID();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOID" + "'", str1.equals("NOID"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 0, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator6, false);
        boolean boolean10 = barRenderer0.isSeriesVisible((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.setDomainPannable(true);
        java.awt.Stroke stroke10 = xYPlot0.getDomainZeroBaselineStroke();
        java.awt.Paint paint11 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection1.getSeries((java.lang.Comparable) 100L);
        try {
            java.lang.Number number9 = timeSeriesCollection1.getX(500, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeries6);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape8 = numberAxis1.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot9.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint12, (java.lang.Object) basicProjectInfo13);
        xYPlot9.setRangeCrosshairPaint(paint12);
        java.awt.Paint paint16 = xYPlot9.getRangeCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) xYPlot9, "{0}: ({1}, {2})");
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot9.getDomainAxis((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(valueAxis20);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = xYPlot2.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot2.setOrientation(plotOrientation6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list12 = timeSeries11.getItems();
        xYPlot2.drawRangeTickBands(graphics2D8, rectangle2D9, list12);
        projectInfo1.setContributors(list12);
        java.lang.String str15 = projectInfo1.getLicenceText();
        java.awt.Image image16 = null;
        projectInfo1.setLogo(image16);
        boolean boolean18 = tickUnits0.equals((java.lang.Object) projectInfo1);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection1.getSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection1.getDomainOrder();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot8.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot8.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot8.setOrientation(plotOrientation12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list18 = timeSeries17.getItems();
        xYPlot8.drawRangeTickBands(graphics2D14, rectangle2D15, list18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list18, true);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double24 = timeSeries23.getMinY();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double29 = timeSeries28.getMinY();
        timeSeries28.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        int int33 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.Year year34 = month32.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 255, true);
        java.lang.Class class39 = timeSeries23.getTimePeriodClass();
        timeSeriesCollection1.removeSeries(timeSeries23);
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        double double43 = timeSeriesCollection1.getDomainLowerBound(true);
        org.junit.Assert.assertNull(timeSeries6);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertEquals((double) number41, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection1 = xYAreaRenderer0.getAnnotations();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer0.setSeriesStroke(0, stroke3, true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        boolean boolean7 = xYPlot6.isRangeCrosshairVisible();
        java.awt.Paint paint8 = xYPlot6.getBackgroundPaint();
        xYAreaRenderer0.setBaseOutlinePaint(paint8, false);
        xYAreaRenderer0.setSeriesVisibleInLegend(15, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) (-1), keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font6 = textFragment5.getFont();
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font6, paint7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot9.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint12, (java.lang.Object) basicProjectInfo13);
        xYPlot9.setRangeCrosshairPaint(paint12);
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font6, paint12);
        xYAreaRenderer0.setBaseItemLabelPaint(paint12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = xYAreaRenderer0.getPositiveItemLabelPosition(15, (int) ' ', true);
        java.lang.Object obj22 = null;
        boolean boolean23 = itemLabelPosition21.equals(obj22);
        java.lang.Object obj24 = null;
        boolean boolean25 = itemLabelPosition21.equals(obj24);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        java.lang.Class class1 = null;
//        try {
//            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("DateTickMarkPosition.START", class1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer5.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = xYStepRenderer5.hasListener((java.util.EventListener) categoryPlot25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace27);
        try {
            categoryPlot25.zoom(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 5, (double) 2.0f);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        boolean boolean3 = xYPlot2.isRangeCrosshairVisible();
        boolean boolean4 = xYAreaRenderer0.hasListener((java.util.EventListener) xYPlot2);
        xYAreaRenderer0.setUseFillPaint(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) 0, "hi!", "{0}: ({1}, {2})", false);
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat((double) 0, "hi!", "{0}: ({1}, {2})", false);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", (java.text.NumberFormat) logFormat5, (java.text.NumberFormat) logFormat10);
        java.text.NumberFormat numberFormat12 = logFormat10.getExponentFormat();
        java.lang.StringBuffer stringBuffer14 = null;
        java.text.FieldPosition fieldPosition15 = null;
        java.lang.StringBuffer stringBuffer16 = logFormat10.format((long) 4, stringBuffer14, fieldPosition15);
        org.junit.Assert.assertNotNull(numberFormat12);
        org.junit.Assert.assertNotNull(stringBuffer16);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.FULL" + "'", str1.equals("RangeType.FULL"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        java.lang.Object obj7 = null;
        boolean boolean8 = categoryPlot0.equals(obj7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxisForDataset(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryAxis10);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.entity.EntityCollection entityCollection18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo(entityCollection18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = chartRenderingInfo19.getPlotInfo();
        org.jfree.chart.plot.CrosshairState crosshairState22 = new org.jfree.chart.plot.CrosshairState(false);
        int int23 = crosshairState22.getRangeAxisIndex();
        boolean boolean24 = xYPlot0.render(graphics2D15, rectangle2D16, 3, plotRenderingInfo20, crosshairState22);
        int int25 = crosshairState22.getDatasetIndex();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(plotRenderingInfo20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 100);
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection5 = xYAreaRenderer4.getAnnotations();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYAreaRenderer4);
        boolean boolean7 = multiplePiePlot0.equals((java.lang.Object) xYAreaRenderer4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYAreaRenderer4.getSeriesPositiveItemLabelPosition((int) (short) 10);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = itemLabelPosition9.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape6, paint13);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity18 = new org.jfree.chart.entity.AxisEntity(shape6, (org.jfree.chart.axis.Axis) categoryAxis3D15, "", "Size2D[width=0.0, height=0.0]");
        java.awt.Paint paint19 = categoryAxis3D15.getTickLabelPaint();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double22 = timeSeries21.getMinY();
        timeSeries21.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        int int26 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.Year year27 = month25.getYear();
        java.awt.Font font28 = categoryAxis3D15.getTickLabelFont((java.lang.Comparable) year27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.next();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) 13, "ItemLabelAnchor.INSIDE11", false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot2.setOrientation(plotOrientation3);
        boolean boolean5 = textTitle1.equals((java.lang.Object) categoryPlot2);
        java.text.DateFormat dateFormat7 = null;
        java.text.DateFormat dateFormat8 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator9 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat7, dateFormat8);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer11 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator9, xYURLGenerator10);
        java.awt.Shape shape12 = xYStepRenderer11.getBaseShape();
        java.awt.Paint paint14 = xYStepRenderer11.lookupLegendTextPaint((int) 'a');
        xYStepRenderer11.setDefaultEntityRadius(0);
        xYStepRenderer11.setDrawOutlines(false);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint22 = textTitle21.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean24 = categoryPlot23.isDomainGridlinesVisible();
        java.awt.Stroke stroke25 = categoryPlot23.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 2, paint22, stroke25);
        xYStepRenderer11.setBaseOutlineStroke(stroke25);
        categoryPlot2.setRangeCrosshairStroke(stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = categoryPlot2.getAxisOffset();
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection32 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot31.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection32);
        java.awt.Paint paint34 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo35 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint34, (java.lang.Object) basicProjectInfo35);
        xYPlot31.setRangeCrosshairPaint(paint34);
        java.awt.Paint paint38 = xYPlot31.getRangeZeroBaselinePaint();
        xYPlot31.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        xYPlot31.zoomRangeAxes(Double.NaN, plotRenderingInfo42, point2D43, true);
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.entity.EntityCollection entityCollection49 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo(entityCollection49);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = chartRenderingInfo50.getPlotInfo();
        org.jfree.chart.plot.CrosshairState crosshairState53 = new org.jfree.chart.plot.CrosshairState(false);
        int int54 = crosshairState53.getRangeAxisIndex();
        boolean boolean55 = xYPlot31.render(graphics2D46, rectangle2D47, 3, plotRenderingInfo51, crosshairState53);
        java.lang.Object obj56 = plotRenderingInfo51.clone();
        java.awt.geom.Rectangle2D rectangle2D57 = plotRenderingInfo51.getDataArea();
        java.awt.geom.Point2D point2D58 = null;
        categoryPlot2.zoomDomainAxes(0.0d, plotRenderingInfo51, point2D58);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(plotRenderingInfo51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(obj56);
        org.junit.Assert.assertNotNull(rectangle2D57);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int7 = numberTickUnit5.compareTo((java.lang.Object) 10);
        numberAxis3.setTickUnit(numberTickUnit5);
        float float9 = numberAxis3.getMinorTickMarkInsideLength();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity15 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis3, shape12, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape12, paint16);
        boolean boolean18 = textTitle1.equals((java.lang.Object) paint16);
        boolean boolean19 = textTitle1.visible;
        textTitle1.setExpandToFitSpace(false);
        double double22 = textTitle1.getContentYOffset();
        textTitle1.setMaximumLinesToDisplay((int) '#');
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//        org.jfree.data.general.PieDataset pieDataset2 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
//        double double5 = timeSeries4.getMinY();
//        timeSeries4.setKey((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        int int9 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
//        org.jfree.data.time.Year year10 = month8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        java.lang.String str12 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) regularTimePeriod11);
//        org.jfree.data.general.PieDataset pieDataset13 = null;
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        long long15 = month14.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 35L);
//        org.jfree.data.time.Year year18 = month14.getYear();
//        java.lang.String str19 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset13, (java.lang.Comparable) year18);
//        org.jfree.data.general.PieDataset pieDataset20 = null;
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.String str22 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset20, (java.lang.Comparable) day21);
//        int int23 = day21.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate24 = day21.getSerialDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 13 + "'", int23 == 13);
//        org.junit.Assert.assertNotNull(serialDate24);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint8 = xYStepRenderer5.lookupLegendTextPaint((int) 'a');
        xYStepRenderer5.setDefaultEntityRadius(0);
        xYStepRenderer5.setDrawOutlines(false);
        xYStepRenderer5.setAutoPopulateSeriesStroke(true);
        boolean boolean17 = xYStepRenderer5.getItemVisible(0, (int) (byte) 100);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int7 = numberTickUnit5.compareTo((java.lang.Object) 10);
        numberAxis3.setTickUnit(numberTickUnit5);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape15, (java.awt.Paint) color16, stroke17, paint18);
        numberAxis3.setRightArrow(shape15);
        shapeList0.setShape(2, shape15);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color3);
        xYPlot0.mapDatasetToRangeAxis((int) '#', 0);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace20);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer5.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = xYStepRenderer5.hasListener((java.util.EventListener) categoryPlot25);
        categoryPlot25.setCrosshairDatasetIndex(0);
        categoryPlot25.setDomainCrosshairVisible(true);
        java.awt.Paint paint31 = categoryPlot25.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot25.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setDomainAxisLocation(axisLocation33);
        categoryPlot25.clearDomainMarkers(100);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint8 = xYStepRenderer5.lookupLegendTextPaint((int) 'a');
        xYStepRenderer5.setDefaultEntityRadius(0);
        xYStepRenderer5.setDrawOutlines(false);
        xYStepRenderer5.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYStepRenderer5.getLegendItems();
        int int16 = legendItemCollection15.getItemCount();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 100);
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection5 = xYAreaRenderer4.getAnnotations();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYAreaRenderer4);
        boolean boolean7 = multiplePiePlot0.equals((java.lang.Object) xYAreaRenderer4);
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke8, jFreeChart9, (int) (byte) -1, 1);
        multiplePiePlot0.setOutlineStroke(stroke8);
        multiplePiePlot0.setLimit(4.0d);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        multiplePiePlot0.setDataset(categoryDataset16);
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        timeSeriesCollection1.validateObject();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean11 = segmentedTimeline9.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list14 = timeSeries13.getItems();
        segmentedTimeline9.setExceptionSegments(list14);
        int int16 = segmentedTimeline9.getSegmentsIncluded();
        java.util.List list17 = segmentedTimeline9.getExceptionSegments();
        org.jfree.data.Range range18 = null;
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list17, range18, true);
        try {
            java.util.Collection collection21 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list17);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D4, rectangleEdge5);
        java.awt.Font font8 = null;
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) (-1L), font8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean16 = textLine14.equals((java.lang.Object) rectangleEdge15);
        org.jfree.chart.axis.AxisState axisState17 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D1.drawTickMarks(graphics2D10, (double) 1.0f, rectangle2D12, rectangleEdge15, axisState17);
        axisState17.cursorLeft(3.0d);
        axisState17.cursorUp(0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        try {
            java.lang.String[] strArray3 = jFreeChartResources0.getStringArray("DatasetRenderingOrder.REVERSE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key DatasetRenderingOrder.REVERSE");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        int int7 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRendererForDataset(categoryDataset8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape6, paint13);
        java.awt.Paint paint15 = legendGraphic14.getFillPaint();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = xYPlot0.getAxisOffset();
        boolean boolean11 = xYPlot0.isRangeCrosshairLockedOnData();
        int int12 = xYPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) 0, "hi!", "{0}: ({1}, {2})", false);
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat((double) 0, "hi!", "{0}: ({1}, {2})", false);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator12 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat11);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = new org.jfree.chart.axis.NumberTickUnit((double) 15, (java.text.NumberFormat) logFormat6);
        org.jfree.chart.axis.AxisState axisState15 = new org.jfree.chart.axis.AxisState((double) 100.0f);
        int int16 = numberTickUnit13.compareTo((java.lang.Object) 100.0f);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        timeSeries1.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list9 = timeSeries8.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double12 = timeSeries11.getMinY();
        timeSeries11.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year17 = month15.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        timeSeries8.add(regularTimePeriod18, (double) 2958465);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod18, 0.0d);
        timeSeries1.add(timeSeriesDataItem22);
        java.lang.Number number24 = timeSeriesDataItem22.getValue();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.0d + "'", number24.equals(0.0d));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection1.getSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor7 = org.jfree.data.time.TimePeriodAnchor.START;
        timeSeriesCollection1.setXPosition(timePeriodAnchor7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot9.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint12, (java.lang.Object) basicProjectInfo13);
        xYPlot9.setRangeCrosshairPaint(paint12);
        java.awt.Paint paint16 = xYPlot9.getRangeCrosshairPaint();
        timeSeriesCollection1.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot9);
        try {
            double double20 = timeSeriesCollection1.getEndYValue(2958465, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeries6);
        org.junit.Assert.assertNotNull(timePeriodAnchor7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        timeSeries1.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot5.getLabelPadding();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot5.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator8);
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator8);
        piePlot1.setLabelLinkMargin((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 90.0d + "'", double6 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint8 = xYStepRenderer5.lookupLegendTextPaint((int) 'a');
        xYStepRenderer5.setBaseLinesVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot11.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        java.awt.Paint paint14 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint14, (java.lang.Object) basicProjectInfo15);
        xYPlot11.setRangeCrosshairPaint(paint14);
        java.awt.Paint paint18 = xYPlot11.getRangeZeroBaselinePaint();
        xYPlot11.setDomainPannable(true);
        java.awt.Stroke stroke21 = xYPlot11.getDomainZeroBaselineStroke();
        xYStepRenderer5.setBaseStroke(stroke21, true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int9 = numberTickUnit7.compareTo((java.lang.Object) 10);
        numberAxis5.setTickUnit(numberTickUnit7);
        float float11 = numberAxis5.getMinorTickMarkInsideLength();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity17 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis5, shape14, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint18 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic(shape14, paint18);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendGraphic19.getShapeLocation();
        java.awt.Paint paint21 = legendGraphic19.getFillPaint();
        barRenderer0.setBaseItemLabelPaint(paint21, true);
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator27 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator27, true);
        barRenderer0.setItemMargin(0.0d);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator33 = null;
        try {
            barRenderer0.setSeriesItemLabelGenerator(2147483647, categoryItemLabelGenerator33);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(15);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color3);
        boolean boolean5 = xYPlot0.canSelectByPoint();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot1.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener4 = null;
        timeSeriesCollection2.addChangeListener(datasetChangeListener4);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeriesCollection2.getSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.DomainOrder domainOrder8 = timeSeriesCollection2.getDomainOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis3D10.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D13, rectangleEdge14);
        java.awt.Paint paint17 = null;
        categoryAxis3D10.setTickLabelPaint((java.lang.Comparable) 1.0d, paint17);
        java.awt.Font font20 = categoryAxis3D10.getTickLabelFont((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) categoryAxis3D10, seriesChangeInfo21);
        timeSeriesCollection2.seriesChanged(seriesChangeEvent22);
        timeSeriesCollection0.seriesChanged(seriesChangeEvent22);
        try {
            int int28 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (int) '4', (double) '#', (double) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeries7);
        org.junit.Assert.assertNotNull(domainOrder8);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            int int2 = defaultXYDataset0.getItemCount(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = new org.jfree.chart.util.RectangleInsets();
        boolean boolean2 = domainOrder0.equals((java.lang.Object) rectangleInsets1);
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D2.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D5, rectangleEdge6);
        java.awt.Paint paint9 = null;
        categoryAxis3D2.setTickLabelPaint((java.lang.Comparable) 1.0d, paint9);
        java.awt.Font font12 = categoryAxis3D2.getTickLabelFont((java.lang.Comparable) 100L);
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("DateTickMarkPosition.START", font12);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Stroke stroke2 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection1.getSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor7 = org.jfree.data.time.TimePeriodAnchor.START;
        timeSeriesCollection1.setXPosition(timePeriodAnchor7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot9.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint12, (java.lang.Object) basicProjectInfo13);
        xYPlot9.setRangeCrosshairPaint(paint12);
        java.awt.Paint paint16 = xYPlot9.getRangeCrosshairPaint();
        timeSeriesCollection1.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot9);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor18 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        java.lang.Object obj19 = null;
        boolean boolean20 = timePeriodAnchor18.equals(obj19);
        timeSeriesCollection1.setXPosition(timePeriodAnchor18);
        org.junit.Assert.assertNull(timeSeries6);
        org.junit.Assert.assertNotNull(timePeriodAnchor7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(timePeriodAnchor18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.setDomainPannable(true);
        java.awt.Stroke stroke10 = xYPlot0.getDomainZeroBaselineStroke();
        java.text.DateFormat dateFormat12 = null;
        java.text.DateFormat dateFormat13 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator14 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat12, dateFormat13);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset15 = new org.jfree.data.xy.DefaultXYDataset();
        boolean boolean16 = standardXYToolTipGenerator14.equals((java.lang.Object) defaultXYDataset15);
        int int17 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) defaultXYDataset15);
        java.awt.Stroke stroke18 = xYPlot0.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D4, rectangleEdge5);
        java.awt.Paint paint8 = null;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) 1.0d, paint8);
        java.awt.Font font11 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) categoryAxis3D1, seriesChangeInfo12);
        double double14 = categoryAxis3D1.getUpperMargin();
        categoryAxis3D1.setLowerMargin((double) 2958465);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot18.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection19);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener21 = null;
        timeSeriesCollection19.addChangeListener(datasetChangeListener21);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeriesCollection19.getSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor25 = org.jfree.data.time.TimePeriodAnchor.START;
        timeSeriesCollection19.setXPosition(timePeriodAnchor25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection28 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot27.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection28);
        java.awt.Paint paint30 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo31 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint30, (java.lang.Object) basicProjectInfo31);
        xYPlot27.setRangeCrosshairPaint(paint30);
        java.awt.Paint paint34 = xYPlot27.getRangeCrosshairPaint();
        timeSeriesCollection19.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot27);
        org.jfree.chart.text.TextLine textLine37 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment39 = new org.jfree.chart.text.TextFragment("");
        textLine37.removeFragment(textFragment39);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape43 = numberAxis42.getLeftArrow();
        java.awt.Paint paint44 = numberAxis42.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource45 = numberAxis42.getStandardTickUnits();
        boolean boolean46 = textLine37.equals((java.lang.Object) numberAxis42);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.util.Size2D size2D48 = textLine37.calculateDimensions(graphics2D47);
        size2D48.setHeight((double) 11);
        org.jfree.chart.text.TextFragment textFragment56 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font57 = textFragment56.getFont();
        java.awt.Paint paint58 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine59 = new org.jfree.chart.text.TextLine("", font57, paint58);
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection61 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot60.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection61);
        java.awt.Paint paint63 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo64 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean65 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint63, (java.lang.Object) basicProjectInfo64);
        xYPlot60.setRangeCrosshairPaint(paint63);
        org.jfree.chart.block.LabelBlock labelBlock67 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font57, paint63);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = labelBlock67.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D69 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D48, 0.05d, 90.0d, rectangleAnchor68);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = null;
        org.jfree.chart.axis.AxisSpace axisSpace71 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace72 = categoryAxis3D1.reserveSpace(graphics2D17, (org.jfree.chart.plot.Plot) xYPlot27, rectangle2D69, rectangleEdge70, axisSpace71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNull(timeSeries24);
        org.junit.Assert.assertNotNull(timePeriodAnchor25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(tickUnitSource45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(size2D48);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor68);
        org.junit.Assert.assertNotNull(rectangle2D69);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getAutoPopulateSectionOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        timeSeries1.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        timeSeries1.setNotify(true);
        double double9 = timeSeries1.getMaxY();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean2 = xYAreaRenderer1.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font7 = textFragment6.getFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("", font7, paint8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot10.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        java.awt.Paint paint13 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo14 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint13, (java.lang.Object) basicProjectInfo14);
        xYPlot10.setRangeCrosshairPaint(paint13);
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font7, paint13);
        xYAreaRenderer1.setBaseItemLabelPaint(paint13);
        boolean boolean19 = chartChangeEventType0.equals((java.lang.Object) xYAreaRenderer1);
        org.jfree.chart.LegendItem legendItem22 = xYAreaRenderer1.getLegendItem(10, (int) (byte) 1);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(legendItem22);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES_AND_LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = multiplePiePlot0.getLegendItems();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("Multiple Pie Plot");
        legendItemCollection1.add(legendItem3);
        java.awt.Stroke stroke5 = legendItem3.getOutlineStroke();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str1.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.pan(0.0d);
        java.awt.Shape shape4 = null;
        try {
            numberAxis1.setUpArrow(shape4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int9 = numberTickUnit7.compareTo((java.lang.Object) 10);
        numberAxis5.setTickUnit(numberTickUnit7);
        float float11 = numberAxis5.getMinorTickMarkInsideLength();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity17 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis5, shape14, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.AxisState axisState19 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        java.util.List list22 = numberAxis5.refreshTicks(graphics2D18, axisState19, rectangle2D20, rectangleEdge21);
        boolean boolean23 = numberAxis5.isMinorTickMarksVisible();
        org.jfree.data.Range range24 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = numberAxis5.getLabelInsets();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//        org.jfree.data.general.PieDataset pieDataset1 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
//        double double4 = timeSeries3.getMinY();
//        timeSeries3.setKey((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month7);
//        org.jfree.data.time.Year year9 = month7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
//        java.lang.String str11 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) regularTimePeriod10);
//        org.jfree.data.general.PieDataset pieDataset12 = null;
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        long long14 = month13.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) 35L);
//        org.jfree.data.time.Year year17 = month13.getYear();
//        java.lang.String str18 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset12, (java.lang.Comparable) year17);
//        org.jfree.data.general.PieDataset pieDataset19 = null;
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.String str21 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset19, (java.lang.Comparable) day20);
//        int int22 = day20.getDayOfMonth();
//        org.jfree.data.general.PieDataset pieDataset23 = null;
//        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
//        double double25 = piePlot24.getStartAngle();
//        boolean boolean26 = piePlot24.getIgnoreZeroValues();
//        boolean boolean27 = day20.equals((java.lang.Object) piePlot24);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean(4);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 9223372036854775807L, "", "item", false);
        boolean boolean5 = logFormat4.isParseIntegerOnly();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseOutlineStroke();
        barRenderer0.setBaseSeriesVisible(true);
        java.awt.Paint paint5 = barRenderer0.lookupSeriesOutlinePaint((int) (short) 1);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        boolean boolean0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D4, rectangleEdge5);
        java.awt.Paint paint8 = null;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) 1.0d, paint8);
        java.awt.Font font11 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) categoryAxis3D1, seriesChangeInfo12);
        double double14 = categoryAxis3D1.getUpperMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean16 = categoryPlot15.isDomainGridlinesVisible();
        java.awt.Stroke stroke17 = categoryPlot15.getDomainGridlineStroke();
        categoryAxis3D1.setTickMarkStroke(stroke17);
        java.awt.Paint paint19 = categoryAxis3D1.getTickMarkPaint();
        categoryAxis3D1.configure();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape10, (java.awt.Paint) color11, stroke12, paint13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        boolean boolean16 = xYPlot15.isRangeCrosshairVisible();
        java.awt.Paint paint17 = xYPlot15.getBackgroundPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape10, paint17);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity22 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D19, "", "Size2D[width=0.0, height=0.0]");
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer24 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean25 = xYAreaRenderer24.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font30 = textFragment29.getFont();
        java.awt.Paint paint31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine("", font30, paint31);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection34 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot33.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection34);
        java.awt.Paint paint36 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo37 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint36, (java.lang.Object) basicProjectInfo37);
        xYPlot33.setRangeCrosshairPaint(paint36);
        org.jfree.chart.block.LabelBlock labelBlock40 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font30, paint36);
        xYAreaRenderer24.setBaseItemLabelPaint(paint36);
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("AxisLabelEntity: label = hi!", "Rotation.ANTICLOCKWISE", "RectangleAnchor.CENTER", "Rotation.ANTICLOCKWISE", shape10, stroke23, paint36);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.lang.Object obj45 = textTitle44.clone();
        boolean boolean46 = textTitle44.getExpandToFitSpace();
        textTitle44.setExpandToFitSpace(false);
        java.awt.Paint paint49 = textTitle44.getPaint();
        org.jfree.chart.entity.TitleEntity titleEntity51 = new org.jfree.chart.entity.TitleEntity(shape10, (org.jfree.chart.title.Title) textTitle44, "AxisEntity: tooltip = ");
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(paint49);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 3.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        java.util.List list18 = numberAxis1.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection20 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot19.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot19.setRangeZeroBaselinePaint((java.awt.Paint) color22);
        numberAxis1.setTickLabelPaint((java.awt.Paint) color22);
        java.awt.Shape shape25 = numberAxis1.getRightArrow();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot26 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot26.setLimit((double) 100);
        org.jfree.chart.JFreeChart jFreeChart29 = multiplePiePlot26.getPieChart();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity32 = new org.jfree.chart.entity.JFreeChartEntity(shape25, jFreeChart29, "", "TitleEntity: tooltip = null");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(jFreeChart29);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        boolean boolean3 = xYPlot2.isRangeCrosshairVisible();
        boolean boolean4 = xYAreaRenderer0.hasListener((java.util.EventListener) xYPlot2);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean6 = categoryPlot5.isDomainGridlinesVisible();
        categoryPlot5.setAnchorValue((double) 10, true);
        java.awt.Paint paint10 = categoryPlot5.getDomainGridlinePaint();
        xYPlot2.setDomainCrosshairPaint(paint10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        int int10 = xYSeriesCollection4.indexOf(xYSeries9);
        org.jfree.data.Range range12 = xYSeriesCollection4.getDomainBounds(false);
        double double13 = xYSeriesCollection4.getIntervalWidth();
        double double15 = xYSeriesCollection4.getDomainUpperBound(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 100);
        int int2 = pieLabelDistributor1.getItemCount();
        pieLabelDistributor1.distributeLabels((double) (byte) 0, (double) 86400000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        piePlot1.setShadowYOffset((double) 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int7 = numberTickUnit5.compareTo((java.lang.Object) 10);
        numberAxis3.setTickUnit(numberTickUnit5);
        float float9 = numberAxis3.getMinorTickMarkInsideLength();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity15 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis3, shape12, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape12, paint16);
        boolean boolean18 = textTitle1.equals((java.lang.Object) paint16);
        boolean boolean19 = textTitle1.visible;
        textTitle1.setExpandToFitSpace(false);
        double double22 = textTitle1.getContentYOffset();
        boolean boolean23 = textTitle1.visible;
        java.lang.Object obj24 = textTitle1.clone();
        java.lang.String str25 = textTitle1.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = textTitle1.getPadding();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        double double20 = rectangleInsets17.calculateBottomOutset((double) 0L);
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets17.getUnitType();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertNotNull(unitType21);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) 24234L, (double) 'a', 0.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint14 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape10, paint14);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer16 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        boolean boolean18 = standardGradientPaintTransformer16.equals((java.lang.Object) itemLabelAnchor17);
        legendGraphic15.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer16);
        java.awt.Stroke stroke20 = legendGraphic15.getOutlineStroke();
        boolean boolean21 = legendGraphic15.isLineVisible();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape6, paint13);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot16.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot16.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        int int21 = color19.getBlue();
        boolean boolean22 = standardXYToolTipGenerator15.equals((java.lang.Object) color19);
        legendGraphic14.setFillPaint((java.awt.Paint) color19);
        boolean boolean24 = legendGraphic14.isLineVisible();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 128 + "'", int21 == 128);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list8 = timeSeries7.getItems();
        segmentedTimeline3.setExceptionSegments(list8);
        int int10 = segmentedTimeline3.getSegmentsIncluded();
        java.text.DateFormat dateFormat12 = null;
        java.text.DateFormat dateFormat13 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator14 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat12, dateFormat13);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator14, xYURLGenerator15);
        java.awt.Shape shape17 = xYStepRenderer16.getBaseShape();
        java.awt.Paint paint21 = xYStepRenderer16.getItemFillPaint(0, (int) (short) 100, false);
        boolean boolean22 = segmentedTimeline3.equals((java.lang.Object) false);
        int int23 = segmentedTimeline3.getSegmentsExcluded();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(2958465);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        boolean boolean4 = xYPlot3.isRangeCrosshairVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 10.0f);
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = xYPlot3.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker7, layer8);
        try {
            objectList1.set((-33), (java.lang.Object) intervalMarker7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        boolean boolean4 = barRenderer0.getIncludeBaseInRange();
        boolean boolean5 = barRenderer0.isDrawBarOutline();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        java.lang.String str14 = axisLabelEntity13.toString();
        java.lang.Object obj15 = axisLabelEntity13.clone();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AxisLabelEntity: label = hi!" + "'", str14.equals("AxisLabelEntity: label = hi!"));
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("WMAP_Plot", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        boolean boolean6 = barRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer7 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor8 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        boolean boolean9 = standardGradientPaintTransformer7.equals((java.lang.Object) itemLabelAnchor8);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType10 = standardGradientPaintTransformer7.getType();
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer7);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint13 = blockBorder12.getPaint();
        barRenderer0.setBaseFillPaint(paint13, true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        double double2 = categoryAxis3D1.getCategoryMargin();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        categoryAxis3D1.drawTickMarks(graphics2D3, (double) (short) 100, rectangle2D5, rectangleEdge6, axisState7);
        categoryAxis3D1.setCategoryLabelPositionOffset(0);
        categoryAxis3D1.setLabelAngle((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (byte) 0, (double) 1577865599999L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 1.0f, false);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint7 = textTitle6.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.isDomainGridlinesVisible();
        java.awt.Stroke stroke10 = categoryPlot8.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 2, paint7, stroke10);
        categoryPlot0.setRangeCrosshairStroke(stroke10);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        double double15 = piePlot14.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = piePlot14.getLabelPadding();
        java.awt.Paint paint17 = piePlot14.getBaseSectionOutlinePaint();
        categoryPlot0.setDomainCrosshairPaint(paint17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot0.getRendererForDataset(categoryDataset19);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint30 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape27, (java.awt.Paint) color28, stroke29, paint30);
        java.awt.Stroke stroke32 = legendItem31.getOutlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit36 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int38 = numberTickUnit36.compareTo((java.lang.Object) 10);
        numberAxis34.setTickUnit(numberTickUnit36);
        float float40 = numberAxis34.getMinorTickMarkInsideLength();
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity46 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis34, shape43, "hi!", "{0}: ({1}, {2})");
        legendItem31.setShape(shape43);
        org.jfree.chart.text.TextFragment textFragment49 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font50 = textFragment49.getFont();
        java.awt.Paint paint51 = textFragment49.getPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic52 = new org.jfree.chart.title.LegendGraphic(shape43, paint51);
        org.jfree.chart.text.TextFragment textFragment54 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font55 = textFragment54.getFont();
        java.awt.Paint paint56 = textFragment54.getPaint();
        legendGraphic52.setLinePaint(paint56);
        categoryPlot0.setRangeGridlinePaint(paint56);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 90.0d + "'", double15 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 0.0f + "'", float40 == 0.0f);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(paint56);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font4 = textFragment3.getFont();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font4, paint5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font4, paint10);
        java.lang.Object obj15 = labelBlock14.clone();
        java.lang.String str16 = labelBlock14.getURLText();
        java.lang.String str17 = labelBlock14.getToolTipText();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowYOffset((double) (-1L));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator5, false);
        barRenderer0.setShadowXOffset((double) 10);
        java.awt.Shape shape10 = null;
        try {
            barRenderer0.setBaseShape(shape10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) -1);
        double double2 = valueMarker1.getValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double4 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month7);
        java.text.DateFormat dateFormat10 = null;
        java.text.DateFormat dateFormat11 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator12 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat10, dateFormat11);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator12, xYURLGenerator13);
        java.awt.Font font18 = xYStepRenderer14.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        boolean boolean21 = xYPlot20.isRangeCrosshairVisible();
        java.awt.Paint paint22 = xYPlot20.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis24.pan(0.0d);
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        xYStepRenderer14.drawRangeMarker(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) numberAxis24, marker27, rectangle2D28);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        xYPlot20.datasetChanged(datasetChangeEvent30);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit35 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int37 = numberTickUnit35.compareTo((java.lang.Object) 10);
        numberAxis33.setTickUnit(numberTickUnit35);
        numberAxis33.setMinorTickMarkInsideLength((-1.0f));
        numberAxis33.pan((double) 2147483647);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit46 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int48 = numberTickUnit46.compareTo((java.lang.Object) 10);
        numberAxis44.setTickUnit(numberTickUnit46);
        float float50 = numberAxis44.getMinorTickMarkInsideLength();
        java.awt.Shape shape51 = numberAxis44.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit55 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int57 = numberTickUnit55.compareTo((java.lang.Object) 10);
        numberAxis53.setTickUnit(numberTickUnit55);
        java.awt.Shape shape65 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color66 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke67 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint68 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape65, (java.awt.Paint) color66, stroke67, paint68);
        numberAxis53.setRightArrow(shape65);
        org.jfree.chart.axis.NumberAxis numberAxis72 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape73 = numberAxis72.getLeftArrow();
        java.awt.Paint paint74 = numberAxis72.getTickLabelPaint();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray75 = new org.jfree.chart.axis.ValueAxis[] { numberAxis33, numberAxis44, numberAxis53, numberAxis72 };
        xYPlot20.setDomainAxes(valueAxisArray75);
        int int77 = month7.compareTo((java.lang.Object) xYPlot20);
        org.jfree.chart.entity.EntityCollection entityCollection80 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo81 = new org.jfree.chart.ChartRenderingInfo(entityCollection80);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = chartRenderingInfo81.getPlotInfo();
        xYPlot20.handleClick(5, (int) (byte) 10, plotRenderingInfo82);
        java.awt.geom.Point2D point2D84 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) 35L, plotRenderingInfo82, point2D84, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 0.0f + "'", float50 == 0.0f);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(shape73);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(valueAxisArray75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertNotNull(plotRenderingInfo82);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        xYSeriesCollection4.removeSeries(xYSeries8);
        org.jfree.data.xy.XYSeries xYSeries13 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection(xYSeries13);
        org.jfree.data.xy.XYSeries xYSeries18 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        xYSeriesCollection14.removeSeries(xYSeries18);
        xYSeriesCollection4.removeSeries(xYSeries18);
        try {
            java.lang.Number number23 = xYSeriesCollection4.getStartX((int) (short) 0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        blockResult0.setEntityCollection(entityCollection1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot1.getLabelPadding();
        java.awt.Paint paint4 = piePlot1.getBaseSectionOutlinePaint();
        boolean boolean5 = piePlot1.getLabelLinksVisible();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = piePlot1.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord8 = abstractPieLabelDistributor6.getPieLabelRecord((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint8 = xYStepRenderer5.lookupLegendTextPaint((int) 'a');
        xYStepRenderer5.setDefaultEntityRadius(0);
        xYStepRenderer5.setDrawOutlines(false);
        xYStepRenderer5.setAutoPopulateSeriesStroke(true);
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYStepRenderer5.setSeriesItemLabelFont((int) '#', font16, true);
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font23 = textFragment22.getFont();
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("ThreadContext", font23);
        xYStepRenderer5.setLegendTextFont(1, font23);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.setDomainPannable(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot0.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis3D6.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D9, rectangleEdge10);
        java.awt.Paint paint13 = null;
        categoryAxis3D6.setTickLabelPaint((java.lang.Comparable) 1.0d, paint13);
        java.awt.Font font16 = categoryAxis3D6.getTickLabelFont((java.lang.Comparable) 100L);
        categoryAxis3D6.removeCategoryLabelToolTip((java.lang.Comparable) "[size=10]");
        org.jfree.data.xy.XYDataItem xYDataItem21 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 5, (java.lang.Number) 1);
        xYDataItem21.setSelected(false);
        categoryAxis3D6.addCategoryLabelToolTip((java.lang.Comparable) xYDataItem21, "Value");
        xYSeries3.add(xYDataItem21, false);
        xYSeries3.add((double) 255, (java.lang.Number) 10);
        org.jfree.data.xy.XYDataItem xYDataItem33 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 5, (java.lang.Number) 1);
        xYDataItem33.setSelected(false);
        xYSeries3.add(xYDataItem33);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("JFreeChartEntity: tooltip = null");
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Paint paint4 = categoryPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        java.awt.Stroke stroke11 = legendItem10.getOutlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int17 = numberTickUnit15.compareTo((java.lang.Object) 10);
        numberAxis13.setTickUnit(numberTickUnit15);
        float float19 = numberAxis13.getMinorTickMarkInsideLength();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis13, shape22, "hi!", "{0}: ({1}, {2})");
        legendItem10.setShape(shape22);
        legendItem10.setURLText("ItemLabelAnchor.INSIDE11");
        legendItem10.setLineVisible(false);
        java.awt.Font font31 = legendItem10.getLabelFont();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(font31);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(9);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) (short) 10);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segmentedTimeline3.getSegment((long) 255);
        segment7.dec((long) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(segment7);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D3 = chartRenderingInfo1.getChartArea();
        chartRenderingInfo1.clear();
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
        org.junit.Assert.assertNotNull(rectangle2D3);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape6, paint13);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity18 = new org.jfree.chart.entity.AxisEntity(shape6, (org.jfree.chart.axis.Axis) categoryAxis3D15, "", "Size2D[width=0.0, height=0.0]");
        categoryAxis3D15.setFixedDimension(90.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis3D6.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D9, rectangleEdge10);
        java.awt.Paint paint13 = null;
        categoryAxis3D6.setTickLabelPaint((java.lang.Comparable) 1.0d, paint13);
        java.awt.Font font16 = categoryAxis3D6.getTickLabelFont((java.lang.Comparable) 100L);
        categoryAxis3D6.removeCategoryLabelToolTip((java.lang.Comparable) "[size=10]");
        org.jfree.data.xy.XYDataItem xYDataItem21 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 5, (java.lang.Number) 1);
        xYDataItem21.setSelected(false);
        categoryAxis3D6.addCategoryLabelToolTip((java.lang.Comparable) xYDataItem21, "Value");
        xYSeries3.add(xYDataItem21, false);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem29 = xYSeries3.getDataItem((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        numberAxis1.setMinorTickMarkInsideLength((-1.0f));
        numberAxis1.pan((double) 2147483647);
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = numberAxis1.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(tickUnitSource11);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        boolean boolean10 = xYStepRenderer5.getUseOutlinePaint();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYStepRenderer5.getSeriesURLGenerator((int) (byte) 10);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(xYURLGenerator12);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.data.xy.XYSeries xYSeries4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection(xYSeries4);
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        xYSeriesCollection5.removeSeries(xYSeries9);
        boolean boolean11 = verticalAlignment0.equals((java.lang.Object) xYSeries9);
        double double12 = xYSeries9.getMinX();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape8 = numberAxis1.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot9.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint12, (java.lang.Object) basicProjectInfo13);
        xYPlot9.setRangeCrosshairPaint(paint12);
        java.awt.Paint paint16 = xYPlot9.getRangeCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) xYPlot9, "{0}: ({1}, {2})");
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint23 = textTitle22.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean25 = categoryPlot24.isDomainGridlinesVisible();
        java.awt.Stroke stroke26 = categoryPlot24.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 2, paint23, stroke26);
        java.awt.Font font28 = valueMarker27.getLabelFont();
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean30 = xYPlot9.removeDomainMarker(11, (org.jfree.chart.plot.Marker) valueMarker27, layer29);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit34 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int36 = numberTickUnit34.compareTo((java.lang.Object) 10);
        numberAxis32.setTickUnit(numberTickUnit34);
        float float38 = numberAxis32.getMinorTickMarkInsideLength();
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity44 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis32, shape41, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint45 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic46 = new org.jfree.chart.title.LegendGraphic(shape41, paint45);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer47 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor48 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        boolean boolean49 = standardGradientPaintTransformer47.equals((java.lang.Object) itemLabelAnchor48);
        legendGraphic46.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer47);
        boolean boolean51 = valueMarker27.equals((java.lang.Object) standardGradientPaintTransformer47);
        org.jfree.data.general.PieDataset pieDataset52 = null;
        org.jfree.chart.plot.PiePlot piePlot53 = new org.jfree.chart.plot.PiePlot(pieDataset52);
        double double54 = piePlot53.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = piePlot53.getLabelPadding();
        valueMarker27.setLabelOffset(rectangleInsets55);
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        try {
            rectangleInsets55.trim(rectangle2D57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 0.0f + "'", float38 == 0.0f);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(itemLabelAnchor48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 90.0d + "'", double54 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        boolean boolean10 = xYStepRenderer5.getUseOutlinePaint();
        java.awt.Paint paint14 = xYStepRenderer5.getItemFillPaint(1, 0, true);
        xYStepRenderer5.setSeriesItemLabelsVisible(2958465, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.util.Enumeration<java.lang.String> strEnumeration2 = jFreeChartResources0.getKeys();
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNotNull(strEnumeration2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (short) -1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = categoryPlot0.getRenderer((int) (byte) 10);
        categoryPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.SortOrder sortOrder7 = null;
        try {
            categoryPlot0.setColumnRenderingOrder(sortOrder7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        categoryPlot0.clearRangeMarkers((int) (byte) 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = barRenderer21.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = null;
        barRenderer21.setNegativeItemLabelPositionFallback(itemLabelPosition24);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = null;
        barRenderer21.setSeriesURLGenerator(0, categoryURLGenerator27);
        java.text.DateFormat dateFormat30 = null;
        java.text.DateFormat dateFormat31 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator32 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat30, dateFormat31);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset33 = new org.jfree.data.xy.DefaultXYDataset();
        boolean boolean34 = standardXYToolTipGenerator32.equals((java.lang.Object) defaultXYDataset33);
        boolean boolean35 = barRenderer21.equals((java.lang.Object) standardXYToolTipGenerator32);
        boolean boolean36 = categoryPlot0.equals((java.lang.Object) barRenderer21);
        categoryPlot0.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) 100);
        double double40 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        categoryPlot0.clearRangeMarkers((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        categoryPlot0.setRangeAxisLocation(255, axisLocation22);
        java.awt.Stroke stroke24 = categoryPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke25 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 10.0f);
        float float29 = intervalMarker28.getAlpha();
        boolean boolean30 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker28);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace31, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.8f + "'", float29 == 0.8f);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = null;
        axisState0.moveCursor((double) 128, rectangleEdge2);
        axisState0.cursorRight((double) 255);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        double double3 = piePlot2.getStartAngle();
        double double4 = piePlot2.getMaximumExplodePercent();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot2.getLabelDistributor();
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font10 = textFragment9.getFont();
        java.awt.Paint paint11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("", font10, paint11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo17 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint16, (java.lang.Object) basicProjectInfo17);
        xYPlot13.setRangeCrosshairPaint(paint16);
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font10, paint16);
        piePlot2.setLabelFont(font10);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot22.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection23);
        java.awt.Paint paint25 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo26 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean27 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint25, (java.lang.Object) basicProjectInfo26);
        xYPlot22.setRangeCrosshairPaint(paint25);
        org.jfree.chart.text.TextMeasurer textMeasurer30 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock31 = org.jfree.chart.text.TextUtilities.createTextBlock("Combined Range XYPlot", font10, paint25, (float) 100L, textMeasurer30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 90.0d + "'", double3 == 90.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.setDomainPannable(true);
        java.awt.Stroke stroke10 = xYPlot0.getDomainZeroBaselineStroke();
        java.text.DateFormat dateFormat12 = null;
        java.text.DateFormat dateFormat13 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator14 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat12, dateFormat13);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset15 = new org.jfree.data.xy.DefaultXYDataset();
        boolean boolean16 = standardXYToolTipGenerator14.equals((java.lang.Object) defaultXYDataset15);
        int int17 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) defaultXYDataset15);
        xYPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", dateFormat1, dateFormat2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection2 = xYAreaRenderer1.getAnnotations();
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYAreaRenderer1.setBaseItemLabelFont(font3);
        java.awt.Paint paint5 = null;
        try {
            org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("DomainOrder.ASCENDING", font3, paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 9223372036854775807L, "", "item", false);
        java.lang.String str6 = logFormat4.format((long) (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "�" + "'", str6.equals("�"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape8 = numberAxis1.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot9.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint12, (java.lang.Object) basicProjectInfo13);
        xYPlot9.setRangeCrosshairPaint(paint12);
        java.awt.Paint paint16 = xYPlot9.getRangeCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) xYPlot9, "{0}: ({1}, {2})");
        org.jfree.chart.plot.Plot plot19 = plotEntity18.getPlot();
        org.jfree.chart.plot.Plot plot20 = plotEntity18.getPlot();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int26 = numberTickUnit24.compareTo((java.lang.Object) 10);
        numberAxis22.setTickUnit(numberTickUnit24);
        float float28 = numberAxis22.getMinorTickMarkInsideLength();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity34 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis22, shape31, "hi!", "{0}: ({1}, {2})");
        plotEntity18.setArea(shape31);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(plot19);
        org.junit.Assert.assertNotNull(plot20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisEntity: tooltip = ");
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.lang.Object obj2 = textTitle1.clone();
        boolean boolean3 = textTitle1.getExpandToFitSpace();
        textTitle1.setExpandToFitSpace(false);
        java.awt.Paint paint6 = textTitle1.getPaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        textTitle1.setBackgroundPaint(paint7);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        boolean boolean2 = standardGradientPaintTransformer0.equals((java.lang.Object) itemLabelAnchor1);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType3 = standardGradientPaintTransformer0.getType();
        java.lang.Object obj4 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        xYPlot0.setRangeMinorGridlinesVisible(true);
        java.awt.Font font17 = xYPlot0.getNoDataMessageFont();
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot0.getRangeMarkers(layer18);
        boolean boolean20 = xYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowYOffset((double) (-1L));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator3, true);
        java.awt.Paint paint7 = barRenderer0.getSeriesFillPaint((int) (byte) -1);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement23 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment19, verticalAlignment20, (double) (-1), (double) 2147483647);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer24 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean25 = xYAreaRenderer24.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        boolean boolean27 = xYPlot26.isRangeCrosshairVisible();
        boolean boolean28 = xYAreaRenderer24.hasListener((java.util.EventListener) xYPlot26);
        boolean boolean29 = columnArrangement23.equals((java.lang.Object) xYAreaRenderer24);
        boolean boolean30 = rectangleInsets17.equals((java.lang.Object) columnArrangement23);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot1.getLabelPadding();
        int int4 = piePlot1.getPieIndex();
        java.awt.Stroke stroke5 = piePlot1.getLabelOutlineStroke();
        int int6 = piePlot1.getPieIndex();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        java.util.List list18 = numberAxis1.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection20 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot19.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot19.setRangeZeroBaselinePaint((java.awt.Paint) color22);
        numberAxis1.setTickLabelPaint((java.awt.Paint) color22);
        java.awt.Shape shape25 = numberAxis1.getRightArrow();
        java.lang.Object obj26 = numberAxis1.clone();
        java.awt.Paint paint27 = numberAxis1.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        double double1 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = multiplePiePlot0.getLegendItems();
        int int2 = legendItemCollection1.getItemCount();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DomainOrder.ASCENDING");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
        java.util.Date date3 = dateAxis1.getMaximumDate();
        float float4 = dateAxis1.getTickMarkInsideLength();
        boolean boolean6 = dateAxis1.isHiddenValue(9223372036854775807L);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot1.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        java.awt.Paint paint4 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint4, (java.lang.Object) basicProjectInfo5);
        xYPlot1.setRangeCrosshairPaint(paint4);
        java.awt.Paint paint8 = xYPlot1.getRangeCrosshairPaint();
        java.text.DateFormat dateFormat10 = null;
        java.text.DateFormat dateFormat11 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator12 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat10, dateFormat11);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator12, xYURLGenerator13);
        java.awt.Font font18 = xYStepRenderer14.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        boolean boolean21 = xYPlot20.isRangeCrosshairVisible();
        java.awt.Paint paint22 = xYPlot20.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis24.pan(0.0d);
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        xYStepRenderer14.drawRangeMarker(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) numberAxis24, marker27, rectangle2D28);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer14.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color31, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean35 = xYStepRenderer14.hasListener((java.util.EventListener) categoryPlot34);
        boolean boolean36 = xYStepRenderer14.getDrawSeriesLineAsPath();
        xYStepRenderer14.setAutoPopulateSeriesFillPaint(false);
        int int39 = xYPlot1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer14);
        java.awt.Font font40 = xYPlot1.getNoDataMessageFont();
        java.awt.Color color41 = java.awt.Color.blue;
        org.jfree.chart.text.TextFragment textFragment43 = new org.jfree.chart.text.TextFragment("RangeType.FULL", font40, (java.awt.Paint) color41, (float) 1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1L, (float) (byte) 0);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape17, (java.awt.Paint) color18, stroke19, paint20);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        boolean boolean23 = xYPlot22.isRangeCrosshairVisible();
        java.awt.Paint paint24 = xYPlot22.getBackgroundPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic25 = new org.jfree.chart.title.LegendGraphic(shape17, paint24);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity29 = new org.jfree.chart.entity.AxisEntity(shape17, (org.jfree.chart.axis.Axis) categoryAxis3D26, "", "Size2D[width=0.0, height=0.0]");
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer31 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean32 = xYAreaRenderer31.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font37 = textFragment36.getFont();
        java.awt.Paint paint38 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine39 = new org.jfree.chart.text.TextLine("", font37, paint38);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection41 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot40.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection41);
        java.awt.Paint paint43 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo44 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint43, (java.lang.Object) basicProjectInfo44);
        xYPlot40.setRangeCrosshairPaint(paint43);
        org.jfree.chart.block.LabelBlock labelBlock47 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font37, paint43);
        xYAreaRenderer31.setBaseItemLabelPaint(paint43);
        org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem("AxisLabelEntity: label = hi!", "Rotation.ANTICLOCKWISE", "RectangleAnchor.CENTER", "Rotation.ANTICLOCKWISE", shape17, stroke30, paint43);
        try {
            org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem(attributedString0, "{0}", "ItemLabelAnchor.INSIDE11", "item", shape6, paint43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        boolean boolean3 = xYPlot0.canSelectByPoint();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int9 = numberTickUnit7.compareTo((java.lang.Object) 10);
        numberAxis5.setTickUnit(numberTickUnit7);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape17, (java.awt.Paint) color18, stroke19, paint20);
        numberAxis5.setRightArrow(shape17);
        double double23 = numberAxis5.getAutoRangeMinimumSize();
        boolean boolean24 = numberAxis5.isVisible();
        boolean boolean25 = numberAxis5.isNegativeArrowVisible();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0E-8d + "'", double23 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setLabelURL("item");
        java.text.DateFormat dateFormat6 = null;
        java.text.DateFormat dateFormat7 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator8 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat6, dateFormat7);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer10 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator8, xYURLGenerator9);
        java.awt.Stroke stroke12 = xYStepRenderer10.lookupSeriesStroke((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        xYStepRenderer10.setSeriesNegativeItemLabelPosition(3, itemLabelPosition14);
        java.lang.Boolean boolean17 = xYStepRenderer10.getSeriesLinesVisible((int) '#');
        java.awt.Paint paint21 = xYStepRenderer10.getItemFillPaint(100, (int) (short) -1, true);
        categoryAxis2.setTickLabelPaint(paint21);
        try {
            paintList0.setPaint(2147483647, paint21);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        numberAxis1.setMinorTickMarkInsideLength((-1.0f));
        numberAxis1.pan((double) 2147483647);
        boolean boolean11 = numberAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = multiplePiePlot0.getLegendItems();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("Multiple Pie Plot");
        legendItemCollection1.add(legendItem3);
        legendItem3.setSeriesIndex((-65536));
        org.junit.Assert.assertNotNull(legendItemCollection1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.text.NumberFormat numberFormat1 = null;
        org.jfree.chart.util.LogFormat logFormat7 = new org.jfree.chart.util.LogFormat((double) 0, "hi!", "{0}: ({1}, {2})", false);
        org.jfree.chart.util.LogFormat logFormat12 = new org.jfree.chart.util.LogFormat((double) 0, "hi!", "{0}: ({1}, {2})", false);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator13 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", (java.text.NumberFormat) logFormat7, (java.text.NumberFormat) logFormat12);
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator14 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleAnchor.BOTTOM_RIGHT", numberFormat1, (java.text.NumberFormat) logFormat7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.entity.EntityCollection entityCollection18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo(entityCollection18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = chartRenderingInfo19.getPlotInfo();
        org.jfree.chart.plot.CrosshairState crosshairState22 = new org.jfree.chart.plot.CrosshairState(false);
        int int23 = crosshairState22.getRangeAxisIndex();
        boolean boolean24 = xYPlot0.render(graphics2D15, rectangle2D16, 3, plotRenderingInfo20, crosshairState22);
        double double25 = crosshairState22.getAnchorY();
        crosshairState22.setAnchorX((double) (byte) 100);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(plotRenderingInfo20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (-1), (double) 2147483647);
        columnArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = columnArrangement4.arrange(blockContainer6, graphics2D7, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot1.getLabelPadding();
        int int4 = piePlot1.getPieIndex();
        java.awt.Color color6 = java.awt.Color.orange;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 13, (java.awt.Paint) color6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        org.jfree.data.RangeType rangeType21 = numberAxis15.getRangeType();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rangeType21);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        java.lang.Comparable comparable3 = categoryPlot0.getDomainCrosshairRowKey();
        int int4 = categoryPlot0.getCrosshairDatasetIndex();
        categoryPlot0.setRangePannable(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNull(comparable3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) (short) 10);
        long long6 = segmentedTimeline3.getSegmentsGroupSize();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline10 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean12 = segmentedTimeline10.equals((java.lang.Object) (short) 10);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment14 = segmentedTimeline10.getSegment((long) 255);
        java.util.Date date15 = segment14.getDate();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline3.getSegment(date15);
        java.util.TimeZone timeZone17 = null;
        java.util.Locale locale18 = null;
        try {
            org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date15, timeZone17, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(segment14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(segment16);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.data.xy.XYSeries xYSeries4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection(xYSeries4);
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        xYSeriesCollection5.removeSeries(xYSeries9);
        boolean boolean11 = verticalAlignment0.equals((java.lang.Object) xYSeries9);
        double double12 = xYSeries9.getMaxX();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Paint paint22 = xYStepRenderer5.getSeriesPaint((int) (short) -1);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(paint22);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.text.DateFormat dateFormat2 = null;
        java.text.DateFormat dateFormat3 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat2, dateFormat3);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator4, xYURLGenerator5);
        java.awt.Font font10 = xYStepRenderer6.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        boolean boolean13 = xYPlot12.isRangeCrosshairVisible();
        java.awt.Paint paint14 = xYPlot12.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis16.pan(0.0d);
        org.jfree.chart.plot.Marker marker19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYStepRenderer6.drawRangeMarker(graphics2D11, xYPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis16, marker19, rectangle2D20);
        boolean boolean22 = defaultDrawingSupplier0.equals((java.lang.Object) xYStepRenderer6);
        java.awt.Stroke stroke23 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint14 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape10, paint14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        legendGraphic15.setOutlineStroke(stroke16);
        legendGraphic15.setShapeOutlineVisible(false);
        java.awt.Stroke stroke20 = legendGraphic15.getOutlineStroke();
        double double21 = legendGraphic15.getContentYOffset();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.text.DateFormat dateFormat1 = standardXYToolTipGenerator0.getYDateFormat();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNull(dateFormat1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 1.0f, false);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint7 = textTitle6.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.isDomainGridlinesVisible();
        java.awt.Stroke stroke10 = categoryPlot8.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 2, paint7, stroke10);
        categoryPlot0.setRangeCrosshairStroke(stroke10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot14.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        java.awt.Paint paint17 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo18 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint17, (java.lang.Object) basicProjectInfo18);
        xYPlot14.setRangeCrosshairPaint(paint17);
        java.awt.Paint paint21 = xYPlot14.getRangeZeroBaselinePaint();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot14.zoomRangeAxes(Double.NaN, plotRenderingInfo25, point2D26, true);
        xYPlot14.setRangeMinorGridlinesVisible(true);
        java.awt.Color color31 = java.awt.Color.blue;
        xYPlot14.setDomainTickBandPaint((java.awt.Paint) color31);
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color31);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection1.getSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection1.getDomainOrder();
        try {
            java.lang.Number number10 = timeSeriesCollection1.getStartY(500, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeries6);
        org.junit.Assert.assertNotNull(domainOrder7);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list2 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double5 = timeSeries4.getMinY();
        timeSeries4.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year10 = month8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.add(regularTimePeriod11, (double) 2958465);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod11, (java.lang.Number) 500);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection1 = xYAreaRenderer0.getAnnotations();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer0.setSeriesStroke(0, stroke3, true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        boolean boolean7 = xYPlot6.isRangeCrosshairVisible();
        java.awt.Paint paint8 = xYPlot6.getBackgroundPaint();
        xYAreaRenderer0.setBaseOutlinePaint(paint8, false);
        java.awt.Stroke stroke11 = xYAreaRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        java.awt.Paint paint5 = barRenderer0.getBaseLegendTextPaint();
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        java.awt.geom.Rectangle2D rectangle2D4 = chartRenderingInfo3.getChartArea();
        chartRenderingInfo3.clear();
        java.awt.geom.Rectangle2D rectangle2D6 = chartRenderingInfo3.getChartArea();
        java.text.DateFormat dateFormat8 = null;
        java.text.DateFormat dateFormat9 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator10 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat8, dateFormat9);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator10, xYURLGenerator11);
        java.awt.Font font16 = xYStepRenderer12.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        boolean boolean19 = xYPlot18.isRangeCrosshairVisible();
        java.awt.Paint paint20 = xYPlot18.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis22.pan(0.0d);
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        xYStepRenderer12.drawRangeMarker(graphics2D17, xYPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis22, marker25, rectangle2D26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer12.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color29, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean33 = xYStepRenderer12.hasListener((java.util.EventListener) categoryPlot32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot32.setFixedDomainAxisSpace(axisSpace34);
        boolean boolean36 = categoryPlot32.isDomainPannable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState39 = barRenderer3D0.initialise(graphics2D1, rectangle2D6, categoryPlot32, 9, plotRenderingInfo38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("Combined Range XYPlot", "DateTickMarkPosition.MIDDLE", "RectangleAnchor.BOTTOM_RIGHT", "RectangleAnchor.CENTER");
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        int int10 = xYSeriesCollection4.indexOf(xYSeries9);
        java.lang.Number number11 = null;
        int int12 = xYSeries9.indexOf(number11);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.ASCENDING;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint8 = xYStepRenderer5.lookupLegendTextPaint((int) 'a');
        xYStepRenderer5.setBaseLinesVisible(true);
        boolean boolean13 = xYStepRenderer5.getItemShapeFilled((int) (short) 100, 0);
        java.util.EventListener eventListener14 = null;
        boolean boolean15 = xYStepRenderer5.hasListener(eventListener14);
        java.awt.Paint paint19 = xYStepRenderer5.getItemPaint(500, (int) (byte) 10, false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setSectionDepth((double) (-2208960000000L));
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot4.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot11.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        java.awt.Paint paint14 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint14, (java.lang.Object) basicProjectInfo15);
        xYPlot11.setRangeCrosshairPaint(paint14);
        java.awt.Paint paint18 = xYPlot11.getRangeZeroBaselinePaint();
        xYPlot11.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = xYPlot11.getAxisOffset();
        categoryPlot4.setAxisOffset(rectangleInsets21);
        categoryPlot4.setRangeMinorGridlinesVisible(false);
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent29 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke25, jFreeChart26, (int) (byte) -1, 1);
        categoryPlot4.setDomainGridlineStroke(stroke25);
        ringPlot1.setBaseSectionOutlineStroke(stroke25);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent25 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke21, jFreeChart22, (int) (byte) -1, 1);
        categoryPlot0.setDomainGridlineStroke(stroke21);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        categoryPlot0.setRenderer(categoryItemRenderer29, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 100);
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection5 = xYAreaRenderer4.getAnnotations();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYAreaRenderer4);
        boolean boolean7 = multiplePiePlot0.equals((java.lang.Object) xYAreaRenderer4);
        boolean boolean8 = xYAreaRenderer4.getUseFillPaint();
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font14 = textFragment13.getFont();
        java.awt.Paint paint15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("", font14, paint15);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot17.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        java.awt.Paint paint20 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo21 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint20, (java.lang.Object) basicProjectInfo21);
        xYPlot17.setRangeCrosshairPaint(paint20);
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font14, paint20);
        xYAreaRenderer4.setSeriesPaint(8, paint20);
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer5.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = xYStepRenderer5.hasListener((java.util.EventListener) categoryPlot25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace27);
        java.awt.Paint paint29 = null;
        try {
            categoryPlot25.setRangeMinorGridlinePaint(paint29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        java.awt.Stroke stroke11 = legendItem10.getOutlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int17 = numberTickUnit15.compareTo((java.lang.Object) 10);
        numberAxis13.setTickUnit(numberTickUnit15);
        float float19 = numberAxis13.getMinorTickMarkInsideLength();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis13, shape22, "hi!", "{0}: ({1}, {2})");
        legendItem10.setShape(shape22);
        legendItem10.setURLText("ItemLabelAnchor.INSIDE11");
        java.awt.Font font29 = legendItem10.getLabelFont();
        java.awt.Stroke stroke30 = legendItem10.getOutlineStroke();
        java.awt.Shape shape31 = legendItem10.getShape();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(font29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        java.text.NumberFormat numberFormat4 = standardXYToolTipGenerator3.getYFormat();
        int int5 = numberFormat4.getMaximumIntegerDigits();
        numberFormat4.setMaximumIntegerDigits((int) (byte) 1);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double7 = timeSeries6.getMinY();
        timeSeries6.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 255, true);
        java.lang.String str17 = year12.toString();
        int int18 = year12.getYear();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("");
        java.lang.Throwable[] throwableArray2 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        int int10 = xYSeriesCollection4.indexOf(xYSeries9);
        org.jfree.data.Range range12 = xYSeriesCollection4.getDomainBounds(false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate13 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        try {
            java.lang.Number number16 = xYSeriesCollection4.getX((-33), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle19.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getItemLabelPadding();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = categoryAxis3D24.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D27, rectangleEdge28);
        java.awt.Font font31 = null;
        categoryAxis3D24.setTickLabelFont((java.lang.Comparable) (-1L), font31);
        org.jfree.chart.entity.EntityCollection entityCollection38 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = new org.jfree.chart.ChartRenderingInfo(entityCollection38);
        java.awt.geom.Rectangle2D rectangle2D40 = chartRenderingInfo39.getChartArea();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D42 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        double double47 = categoryAxis3D42.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D45, rectangleEdge46);
        java.awt.Font font49 = null;
        categoryAxis3D42.setTickLabelFont((java.lang.Comparable) (-1L), font49);
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.text.TextLine textLine55 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean57 = textLine55.equals((java.lang.Object) rectangleEdge56);
        org.jfree.chart.axis.AxisState axisState58 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D42.drawTickMarks(graphics2D51, (double) 1.0f, rectangle2D53, rectangleEdge56, axisState58);
        double double60 = categoryAxis3D24.getCategorySeriesMiddle(4, (int) '#', (int) (byte) -1, (int) (short) 100, Double.POSITIVE_INFINITY, rectangle2D40, rectangleEdge56);
        try {
            legendTitle19.draw(graphics2D22, rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertEquals((double) double60, Double.NaN, 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.setDomainPannable(true);
        java.awt.Stroke stroke10 = xYPlot0.getDomainZeroBaselineStroke();
        int int11 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot0.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) (short) 10);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segmentedTimeline3.getSegment((long) 255);
        java.util.Date date8 = segment7.getDate();
        boolean boolean11 = segment7.contains((long) 'a', 3600000L);
        boolean boolean14 = segment7.contains((long) 3, (long) 2019);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(segment7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        legendItem10.setLineVisible(false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int7 = numberTickUnit5.compareTo((java.lang.Object) 10);
        numberAxis3.setTickUnit(numberTickUnit5);
        float float9 = numberAxis3.getMinorTickMarkInsideLength();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity15 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis3, shape12, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape12, paint16);
        boolean boolean18 = textTitle1.equals((java.lang.Object) paint16);
        boolean boolean19 = textTitle1.visible;
        textTitle1.setExpandToFitSpace(false);
        double double22 = textTitle1.getContentYOffset();
        boolean boolean23 = textTitle1.visible;
        textTitle1.setText("");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint14 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape10, paint14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendGraphic15.getShapeLocation();
        legendGraphic15.setShapeFilled(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean20 = categoryPlot19.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot19.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo23, point2D24);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection27 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot26.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection27);
        java.awt.Paint paint29 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo30 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint29, (java.lang.Object) basicProjectInfo30);
        xYPlot26.setRangeCrosshairPaint(paint29);
        java.awt.Paint paint33 = xYPlot26.getRangeZeroBaselinePaint();
        xYPlot26.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = xYPlot26.getAxisOffset();
        categoryPlot19.setAxisOffset(rectangleInsets36);
        categoryPlot19.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = categoryPlot19.getDomainMarkers(layer40);
        java.awt.Paint paint42 = categoryPlot19.getDomainCrosshairPaint();
        legendGraphic15.setFillPaint(paint42);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.data.Range range2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 0, range2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint3.toUnconstrainedHeight();
        boolean boolean5 = textAnchor0.equals((java.lang.Object) rectangleConstraint4);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("DomainOrder.ASCENDING");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis3.getTickMarkPosition();
        java.util.Date date5 = dateAxis3.getMaximumDate();
        java.lang.String str6 = dateTickUnit1.dateToString(date5);
        try {
            org.jfree.chart.axis.TickUnit tickUnit7 = tickUnits0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "12/31/69 4:00 PM" + "'", str6.equals("12/31/69 4:00 PM"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        java.lang.String str1 = domainOrder0.toString();
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DomainOrder.NONE" + "'", str1.equals("DomainOrder.NONE"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        java.awt.Stroke stroke11 = legendItem10.getOutlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int17 = numberTickUnit15.compareTo((java.lang.Object) 10);
        numberAxis13.setTickUnit(numberTickUnit15);
        float float19 = numberAxis13.getMinorTickMarkInsideLength();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis13, shape22, "hi!", "{0}: ({1}, {2})");
        legendItem10.setShape(shape22);
        java.awt.Paint paint27 = legendItem10.getLinePaint();
        java.awt.Font font28 = legendItem10.getLabelFont();
        legendItem10.setDatasetIndex(0);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(font28);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        xYStepRenderer5.setBaseItemLabelsVisible(false, true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator10 = null;
        xYStepRenderer5.setSeriesItemLabelGenerator((int) ' ', xYItemLabelGenerator10);
        xYStepRenderer5.setSeriesShapesVisible(4, (java.lang.Boolean) true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) ' ');
        java.awt.Paint paint2 = xYAreaRenderer1.getBaseFillPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list8 = timeSeries7.getItems();
        segmentedTimeline3.setExceptionSegments(list8);
        int int10 = segmentedTimeline3.getSegmentsIncluded();
        java.util.List list11 = segmentedTimeline3.getExceptionSegments();
        try {
            boolean boolean13 = segmentedTimeline3.containsDomainValue(100L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        categoryPlot0.clearRangeMarkers((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        categoryPlot0.setRangeAxisLocation(255, axisLocation22);
        java.awt.Stroke stroke24 = categoryPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke25 = categoryPlot0.getRangeGridlineStroke();
        java.awt.Paint paint26 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        timeSeriesCollection1.validateObject();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean11 = segmentedTimeline9.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list14 = timeSeries13.getItems();
        segmentedTimeline9.setExceptionSegments(list14);
        int int16 = segmentedTimeline9.getSegmentsIncluded();
        java.util.List list17 = segmentedTimeline9.getExceptionSegments();
        org.jfree.data.Range range18 = null;
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list17, range18, true);
        java.lang.Object obj21 = timeSeriesCollection1.clone();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list2 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double5 = timeSeries4.getMinY();
        timeSeries4.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year10 = month8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        timeSeries1.add(regularTimePeriod11, (double) 2958465);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator14 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double18 = timeSeries17.getMinY();
        timeSeries17.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) month21);
        org.jfree.data.time.Year year23 = month21.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        java.lang.String str25 = standardPieSectionLabelGenerator14.generateSectionLabel(pieDataset15, (java.lang.Comparable) regularTimePeriod24);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        long long28 = month27.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (double) 35L);
        org.jfree.data.time.Year year31 = month27.getYear();
        java.lang.String str32 = standardPieSectionLabelGenerator14.generateSectionLabel(pieDataset26, (java.lang.Comparable) year31);
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        java.lang.String str35 = standardPieSectionLabelGenerator14.generateSectionLabel(pieDataset33, (java.lang.Comparable) day34);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day34, (double) 13);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNull(str35);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int7 = numberTickUnit5.compareTo((java.lang.Object) 10);
        numberAxis3.setTickUnit(numberTickUnit5);
        float float9 = numberAxis3.getMinorTickMarkInsideLength();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity15 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis3, shape12, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape12, paint16);
        boolean boolean18 = textTitle1.equals((java.lang.Object) paint16);
        boolean boolean19 = textTitle1.visible;
        textTitle1.setVisible(true);
        org.jfree.chart.block.BlockFrame blockFrame22 = textTitle1.getFrame();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(blockFrame22);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot2.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (-1), (java.awt.Paint) color5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        intervalMarker7.setLabelOffsetType(lengthAdjustmentType8);
        java.lang.Object obj10 = intervalMarker7.clone();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Stroke stroke7 = xYStepRenderer5.lookupSeriesStroke((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        xYStepRenderer5.setSeriesNegativeItemLabelPosition(3, itemLabelPosition9);
        java.lang.Boolean boolean12 = xYStepRenderer5.getSeriesLinesVisible((int) '#');
        java.awt.Paint paint16 = xYStepRenderer5.getItemFillPaint(100, (int) (short) -1, true);
        xYStepRenderer5.clearSeriesPaints(true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        java.awt.Stroke stroke11 = legendItem10.getOutlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int17 = numberTickUnit15.compareTo((java.lang.Object) 10);
        numberAxis13.setTickUnit(numberTickUnit15);
        float float19 = numberAxis13.getMinorTickMarkInsideLength();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis13, shape22, "hi!", "{0}: ({1}, {2})");
        legendItem10.setShape(shape22);
        legendItem10.setURLText("ItemLabelAnchor.INSIDE11");
        java.awt.Font font29 = legendItem10.getLabelFont();
        java.awt.Stroke stroke30 = legendItem10.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot31.setDomainCrosshairRowKey((java.lang.Comparable) 1.0f, false);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint38 = textTitle37.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean40 = categoryPlot39.isDomainGridlinesVisible();
        java.awt.Stroke stroke41 = categoryPlot39.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) 2, paint38, stroke41);
        categoryPlot31.setRangeCrosshairStroke(stroke41);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D45 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = null;
        double double50 = categoryAxis3D45.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D48, rectangleEdge49);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D52.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D55 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = categoryAxis3D55.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D58, rectangleEdge59);
        java.awt.Paint paint62 = null;
        categoryAxis3D55.setTickLabelPaint((java.lang.Comparable) 1.0d, paint62);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D65 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D65.setMaximumCategoryLabelLines(10);
        categoryAxis3D65.removeCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D71 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = categoryAxis3D71.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D74, rectangleEdge75);
        java.awt.Paint paint78 = null;
        categoryAxis3D71.setTickLabelPaint((java.lang.Comparable) 1.0d, paint78);
        java.awt.Font font81 = categoryAxis3D71.getTickLabelFont((java.lang.Comparable) 100L);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D83 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray84 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D45, categoryAxis3D52, categoryAxis3D55, categoryAxis3D65, categoryAxis3D71, categoryAxis3D83 };
        categoryPlot31.setDomainAxes(categoryAxisArray84);
        org.jfree.chart.axis.ValueAxis valueAxis86 = categoryPlot31.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation87 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot31.setDomainAxisLocation(axisLocation87);
        java.awt.Paint paint89 = categoryPlot31.getRangeGridlinePaint();
        legendItem10.setFillPaint(paint89);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(font29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(font81);
        org.junit.Assert.assertNotNull(categoryAxisArray84);
        org.junit.Assert.assertNull(valueAxis86);
        org.junit.Assert.assertNotNull(axisLocation87);
        org.junit.Assert.assertNotNull(paint89);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.getDataItem(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = categoryPlot0.getDatasetRenderingOrder();
        java.lang.String str4 = datasetRenderingOrder3.toString();
        java.text.DateFormat dateFormat6 = null;
        java.text.DateFormat dateFormat7 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator8 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat6, dateFormat7);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer10 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator8, xYURLGenerator9);
        java.awt.Shape shape11 = xYStepRenderer10.getBaseShape();
        java.awt.Paint paint13 = xYStepRenderer10.lookupLegendTextPaint((int) 'a');
        xYStepRenderer10.setDefaultEntityRadius(0);
        xYStepRenderer10.setDrawOutlines(false);
        xYStepRenderer10.setSeriesShapesVisible(500, false);
        boolean boolean21 = datasetRenderingOrder3.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str4.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint2 = textTitle1.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle1.getMargin();
        java.awt.Paint paint4 = textTitle1.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle1.getPosition();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (byte) 0, (java.lang.Boolean) false, true);
        boolean boolean5 = barRenderer0.isDrawBarOutline();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.Range range7 = barRenderer0.findRangeBounds(categoryDataset6);
        barRenderer0.removeAnnotations();
        int int9 = barRenderer0.getColumnCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        xYPlot0.setRangeMinorGridlinesVisible(true);
        java.awt.Color color17 = java.awt.Color.blue;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color17);
        xYPlot0.clearDomainMarkers((int) (byte) 1);
        xYPlot0.clearSelection();
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int30 = numberTickUnit28.compareTo((java.lang.Object) 10);
        numberAxis26.setTickUnit(numberTickUnit28);
        float float32 = numberAxis26.getMinorTickMarkInsideLength();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity38 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis26, shape35, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint39 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic40 = new org.jfree.chart.title.LegendGraphic(shape35, paint39);
        boolean boolean41 = textTitle24.equals((java.lang.Object) paint39);
        xYPlot0.setQuadrantPaint(2, paint39);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.0f + "'", float32 == 0.0f);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer2.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer2.setNegativeItemLabelPositionFallback(itemLabelPosition5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer2.setSeriesURLGenerator(0, categoryURLGenerator8);
        java.text.DateFormat dateFormat11 = null;
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator13 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat11, dateFormat12);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset14 = new org.jfree.data.xy.DefaultXYDataset();
        boolean boolean15 = standardXYToolTipGenerator13.equals((java.lang.Object) defaultXYDataset14);
        boolean boolean16 = barRenderer2.equals((java.lang.Object) standardXYToolTipGenerator13);
        barRenderer2.clearSeriesStrokes(true);
        boolean boolean19 = defaultXYDataset0.equals((java.lang.Object) true);
        java.lang.Object obj20 = defaultXYDataset0.clone();
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Paint paint2 = xYPlot0.getBackgroundPaint();
        xYPlot0.setRangeCrosshairValue(0.0d, true);
        boolean boolean6 = xYPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape10 = numberAxis9.getLeftArrow();
        java.awt.Paint paint11 = numberAxis9.getTickLabelPaint();
        xYPlot0.setDomainAxis(2, (org.jfree.chart.axis.ValueAxis) numberAxis9, false);
        numberAxis9.configure();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) 0, "hi!", "{0}: ({1}, {2})", false);
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat((double) 0, "hi!", "{0}: ({1}, {2})", false);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", (java.text.NumberFormat) logFormat5, (java.text.NumberFormat) logFormat10);
        java.text.NumberFormat numberFormat12 = logFormat10.getExponentFormat();
        int int13 = numberFormat12.getMinimumFractionDigits();
        numberFormat12.setMinimumFractionDigits(9999);
        org.junit.Assert.assertNotNull(numberFormat12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        timeSeries1.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Calendar calendar7 = null;
        try {
            month5.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        java.awt.Stroke stroke6 = barRenderer0.getSeriesOutlineStroke(15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertNull(stroke6);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        categoryPlot0.clearRangeMarkers((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        categoryPlot0.setRangeAxisLocation(255, axisLocation22);
        java.awt.Stroke stroke24 = categoryPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke25 = categoryPlot0.getRangeGridlineStroke();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer27 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean28 = xYAreaRenderer27.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment32 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font33 = textFragment32.getFont();
        java.awt.Paint paint34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine35 = new org.jfree.chart.text.TextLine("", font33, paint34);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection37 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot36.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection37);
        java.awt.Paint paint39 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo40 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean41 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint39, (java.lang.Object) basicProjectInfo40);
        xYPlot36.setRangeCrosshairPaint(paint39);
        org.jfree.chart.block.LabelBlock labelBlock43 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font33, paint39);
        xYAreaRenderer27.setBaseItemLabelPaint(paint39);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = xYAreaRenderer27.getPositiveItemLabelPosition(15, (int) ' ', true);
        org.jfree.chart.entity.EntityCollection entityCollection49 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo(entityCollection49);
        java.awt.geom.Rectangle2D rectangle2D51 = chartRenderingInfo50.getChartArea();
        xYAreaRenderer27.setBaseShape((java.awt.Shape) rectangle2D51);
        try {
            categoryPlot0.drawBackground(graphics2D26, rectangle2D51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition48);
        org.junit.Assert.assertNotNull(rectangle2D51);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 100);
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        boolean boolean4 = jFreeChart3.isNotify();
        org.jfree.chart.entity.EntityCollection entityCollection7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo(entityCollection7);
        jFreeChart3.handleClick(11, (int) '#', chartRenderingInfo8);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test409");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = multiplePiePlot0.getAggregatedItemsKey();
        org.junit.Assert.assertTrue("'" + comparable1 + "' != '" + "Other" + "'", comparable1.equals("Other"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot2.setOrientation(plotOrientation3);
        boolean boolean5 = textTitle1.equals((java.lang.Object) categoryPlot2);
        java.text.DateFormat dateFormat7 = null;
        java.text.DateFormat dateFormat8 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator9 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat7, dateFormat8);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer11 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator9, xYURLGenerator10);
        java.awt.Shape shape12 = xYStepRenderer11.getBaseShape();
        java.awt.Paint paint14 = xYStepRenderer11.lookupLegendTextPaint((int) 'a');
        xYStepRenderer11.setDefaultEntityRadius(0);
        xYStepRenderer11.setDrawOutlines(false);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint22 = textTitle21.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean24 = categoryPlot23.isDomainGridlinesVisible();
        java.awt.Stroke stroke25 = categoryPlot23.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 2, paint22, stroke25);
        xYStepRenderer11.setBaseOutlineStroke(stroke25);
        categoryPlot2.setRangeCrosshairStroke(stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = categoryPlot2.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = categoryPlot2.getDomainAxisForDataset(255);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = null;
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            categoryPlot2.addDomainMarker(2147483647, categoryMarker33, layer34, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNull(categoryAxis31);
        org.junit.Assert.assertNotNull(layer34);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseOutlineStroke();
        barRenderer0.setBaseSeriesVisible(true);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape11, (java.awt.Paint) color12, stroke13, paint14);
        java.awt.Stroke stroke16 = legendItem15.getOutlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int22 = numberTickUnit20.compareTo((java.lang.Object) 10);
        numberAxis18.setTickUnit(numberTickUnit20);
        float float24 = numberAxis18.getMinorTickMarkInsideLength();
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity30 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis18, shape27, "hi!", "{0}: ({1}, {2})");
        legendItem15.setShape(shape27);
        legendItem15.setURLText("ItemLabelAnchor.INSIDE11");
        java.awt.Font font34 = legendItem15.getLabelFont();
        java.awt.Stroke stroke35 = legendItem15.getOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) (short) 10, stroke35, true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNull(font34);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 1L, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (short) -1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = categoryPlot0.getRenderer((int) (byte) 10);
        categoryPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        xYPlot7.clearRangeMarkers(100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot7.zoomDomainAxes((double) 0, plotRenderingInfo17, point2D18);
        org.jfree.chart.axis.ValueAxis valueAxis21 = xYPlot7.getDomainAxis((int) '#');
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection24 = xYPlot7.getRangeMarkers(0, layer23);
        java.util.Collection collection25 = categoryPlot0.getDomainMarkers(layer23);
        org.junit.Assert.assertNull(categoryItemRenderer4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(collection25);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        double double2 = categoryAxis3D1.getCategoryMargin();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        categoryAxis3D1.drawTickMarks(graphics2D3, (double) (short) 100, rectangle2D5, rectangleEdge6, axisState7);
        double double9 = categoryAxis3D1.getCategoryMargin();
        java.awt.Paint paint11 = categoryAxis3D1.getTickLabelPaint((java.lang.Comparable) 0.0f);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int18 = numberTickUnit16.compareTo((java.lang.Object) 10);
        numberAxis14.setTickUnit(numberTickUnit16);
        float float20 = numberAxis14.getMinorTickMarkInsideLength();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity26 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis14, shape23, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.AxisState axisState28 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        java.util.List list31 = numberAxis14.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer32 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean33 = xYAreaRenderer32.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment37 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font38 = textFragment37.getFont();
        java.awt.Paint paint39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine40 = new org.jfree.chart.text.TextLine("", font38, paint39);
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection42 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot41.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection42);
        java.awt.Paint paint44 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo45 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean46 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint44, (java.lang.Object) basicProjectInfo45);
        xYPlot41.setRangeCrosshairPaint(paint44);
        org.jfree.chart.block.LabelBlock labelBlock48 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font38, paint44);
        xYAreaRenderer32.setBaseItemLabelPaint(paint44);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition53 = xYAreaRenderer32.getPositiveItemLabelPosition(15, (int) ' ', true);
        org.jfree.chart.entity.EntityCollection entityCollection54 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo55 = new org.jfree.chart.ChartRenderingInfo(entityCollection54);
        java.awt.geom.Rectangle2D rectangle2D56 = chartRenderingInfo55.getChartArea();
        xYAreaRenderer32.setBaseShape((java.awt.Shape) rectangle2D56);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.util.List list59 = categoryAxis3D1.refreshTicks(graphics2D12, axisState28, rectangle2D56, rectangleEdge58);
        categoryAxis3D1.setTickMarkInsideLength(0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition53);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(list59);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        jFreeChart3.setPadding(rectangleInsets4);
        try {
            org.jfree.chart.plot.XYPlot xYPlot6 = jFreeChart3.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        timeSeriesCollection1.validateObject();
        timeSeriesCollection1.validateObject();
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("Size2D[width=0.0, height=0.0]", "DateTickMarkPosition.MIDDLE");
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangePannable();
        categoryPlot0.clearDomainMarkers();
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        java.text.NumberFormat numberFormat4 = standardXYToolTipGenerator3.getYFormat();
        java.lang.String str5 = standardXYToolTipGenerator3.getFormatString();
        java.text.NumberFormat numberFormat6 = standardXYToolTipGenerator3.getYFormat();
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(numberFormat6);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list2 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list5 = timeSeries4.getItems();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double8 = timeSeries7.getMinY();
        timeSeries7.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month11);
        org.jfree.data.time.Year year13 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        timeSeries4.add(regularTimePeriod14, (double) 2958465);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod14, 0.0d);
        timeSeries1.add(timeSeriesDataItem18, true);
        long long21 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double24 = timeSeries23.getMinY();
        timeSeries23.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int28 = timeSeries23.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list31 = timeSeries30.getItems();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double34 = timeSeries33.getMinY();
        timeSeries33.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        int int38 = timeSeries33.getIndex((org.jfree.data.time.RegularTimePeriod) month37);
        org.jfree.data.time.Year year39 = month37.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.previous();
        timeSeries30.add(regularTimePeriod40, (double) 2958465);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod40, 0.0d);
        timeSeries23.add(timeSeriesDataItem44);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries1.addOrUpdate(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot1.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot1.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot1.setOrientation(plotOrientation5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list11 = timeSeries10.getItems();
        xYPlot1.drawRangeTickBands(graphics2D7, rectangle2D8, list11);
        projectInfo0.setContributors(list11);
        java.lang.String str14 = projectInfo0.getLicenceText();
        java.awt.Image image15 = null;
        projectInfo0.setLogo(image15);
        java.util.List list17 = projectInfo0.getContributors();
        java.lang.String str18 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.entity.EntityCollection entityCollection18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo(entityCollection18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = chartRenderingInfo19.getPlotInfo();
        org.jfree.chart.plot.CrosshairState crosshairState22 = new org.jfree.chart.plot.CrosshairState(false);
        int int23 = crosshairState22.getRangeAxisIndex();
        boolean boolean24 = xYPlot0.render(graphics2D15, rectangle2D16, 3, plotRenderingInfo20, crosshairState22);
        java.lang.Object obj25 = plotRenderingInfo20.clone();
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo20.getPlotArea();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(plotRenderingInfo20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNull(rectangle2D26);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font3 = textFragment2.getFont();
        java.awt.Paint paint4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("", font3, paint4);
        org.jfree.chart.text.TextFragment textFragment6 = textLine5.getLastTextFragment();
        float float7 = textFragment6.getBaselineOffset();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textFragment6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        boolean boolean10 = xYStepRenderer5.getBaseItemLabelsVisible();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        jFreeChart3.removeLegend();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItemCollection2);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        timeSeries1.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list9 = timeSeries8.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double12 = timeSeries11.getMinY();
        timeSeries11.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year17 = month15.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        timeSeries8.add(regularTimePeriod18, (double) 2958465);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod18, 0.0d);
        timeSeries1.add(timeSeriesDataItem22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        long long25 = month24.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 35L);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowYOffset((double) (-1L));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNull(itemLabelPosition5);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        boolean boolean10 = xYStepRenderer5.getUseOutlinePaint();
        java.lang.Boolean boolean12 = xYStepRenderer5.getSeriesCreateEntities((int) (byte) 10);
        boolean boolean13 = xYStepRenderer5.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = xYPlot0.getAxisOffset();
        org.jfree.data.general.WaferMapDataset waferMapDataset11 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset11);
        waferMapPlot12.setNoDataMessage("hi!");
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        waferMapPlot12.setOutlineStroke(stroke15);
        xYPlot0.setDomainZeroBaselineStroke(stroke15);
        boolean boolean18 = xYPlot0.isSubplot();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) (short) 10);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segmentedTimeline3.getSegment((long) 255);
        java.util.Date date8 = segment7.getDate();
        segment7.moveIndexToStart();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(segment7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("AxisEntity: tooltip = ");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        java.lang.Object obj7 = null;
        boolean boolean8 = categoryPlot0.equals(obj7);
        float float9 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 1.0f, false);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint7 = textTitle6.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.isDomainGridlinesVisible();
        java.awt.Stroke stroke10 = categoryPlot8.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 2, paint7, stroke10);
        categoryPlot0.setRangeCrosshairStroke(stroke10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis3D14.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D17, rectangleEdge18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D21.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = categoryAxis3D24.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D27, rectangleEdge28);
        java.awt.Paint paint31 = null;
        categoryAxis3D24.setTickLabelPaint((java.lang.Comparable) 1.0d, paint31);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D34.setMaximumCategoryLabelLines(10);
        categoryAxis3D34.removeCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = categoryAxis3D40.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D43, rectangleEdge44);
        java.awt.Paint paint47 = null;
        categoryAxis3D40.setTickLabelPaint((java.lang.Comparable) 1.0d, paint47);
        java.awt.Font font50 = categoryAxis3D40.getTickLabelFont((java.lang.Comparable) 100L);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray53 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D14, categoryAxis3D21, categoryAxis3D24, categoryAxis3D34, categoryAxis3D40, categoryAxis3D52 };
        categoryPlot0.setDomainAxes(categoryAxisArray53);
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis57.pan(0.0d);
        categoryPlot0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis57);
        org.jfree.chart.plot.CategoryMarker categoryMarker62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection64 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot63.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection64);
        java.awt.Paint paint66 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo67 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean68 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint66, (java.lang.Object) basicProjectInfo67);
        xYPlot63.setRangeCrosshairPaint(paint66);
        java.awt.Paint paint70 = xYPlot63.getRangeZeroBaselinePaint();
        xYPlot63.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = null;
        java.awt.geom.Point2D point2D75 = null;
        xYPlot63.zoomRangeAxes(Double.NaN, plotRenderingInfo74, point2D75, true);
        xYPlot63.setRangeMinorGridlinesVisible(true);
        java.awt.Font font80 = xYPlot63.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle83 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint84 = textTitle83.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot85 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean86 = categoryPlot85.isDomainGridlinesVisible();
        java.awt.Stroke stroke87 = categoryPlot85.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker88 = new org.jfree.chart.plot.ValueMarker((double) 2, paint84, stroke87);
        java.awt.Paint paint89 = valueMarker88.getPaint();
        org.jfree.chart.util.Layer layer90 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean91 = xYPlot63.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker88, layer90);
        try {
            categoryPlot0.addDomainMarker((int) (short) 1, categoryMarker62, layer90);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(categoryAxisArray53);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(font80);
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(stroke87);
        org.junit.Assert.assertNotNull(paint89);
        org.junit.Assert.assertNotNull(layer90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot1.getLabelPadding();
        int int4 = piePlot1.getPieIndex();
        java.awt.Stroke stroke5 = piePlot1.getLabelOutlineStroke();
        double double6 = piePlot1.getLabelLinkMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        java.util.List list2 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        xYPlot11.datasetChanged(datasetChangeEvent21);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation23 = null;
        try {
            xYPlot11.addAnnotation(xYAnnotation23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLabelURL("item");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int9 = numberTickUnit7.compareTo((java.lang.Object) 10);
        numberAxis5.setTickUnit(numberTickUnit7);
        float float11 = numberAxis5.getMinorTickMarkInsideLength();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer12.setSeriesVisible((int) (byte) 0, (java.lang.Boolean) false, true);
        double double17 = barRenderer12.getItemMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = categoryAxis3D20.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D23, rectangleEdge24);
        java.awt.Paint paint27 = null;
        categoryAxis3D20.setTickLabelPaint((java.lang.Comparable) 1.0d, paint27);
        java.awt.Font font30 = categoryAxis3D20.getTickLabelFont((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo31 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) categoryAxis3D20, seriesChangeInfo31);
        double double33 = categoryAxis3D20.getUpperMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean35 = categoryPlot34.isDomainGridlinesVisible();
        java.awt.Stroke stroke36 = categoryPlot34.getDomainGridlineStroke();
        categoryAxis3D20.setTickMarkStroke(stroke36);
        categoryPlot18.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D20);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLabelURL("item");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int9 = numberTickUnit7.compareTo((java.lang.Object) 10);
        numberAxis5.setTickUnit(numberTickUnit7);
        float float11 = numberAxis5.getMinorTickMarkInsideLength();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer12.setSeriesVisible((int) (byte) 0, (java.lang.Boolean) false, true);
        double double17 = barRenderer12.getItemMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.entity.EntityCollection entityCollection23 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo(entityCollection23);
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo24.getChartArea();
        chartRenderingInfo24.clear();
        java.awt.geom.Rectangle2D rectangle2D27 = chartRenderingInfo24.getChartArea();
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit32 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int34 = numberTickUnit32.compareTo((java.lang.Object) 10);
        numberAxis30.setTickUnit(numberTickUnit32);
        float float36 = numberAxis30.getMinorTickMarkInsideLength();
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity42 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis30, shape39, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.axis.AxisState axisState44 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        java.util.List list47 = numberAxis30.refreshTicks(graphics2D43, axisState44, rectangle2D45, rectangleEdge46);
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot48.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot48.setRangeZeroBaselinePaint((java.awt.Paint) color51);
        numberAxis30.setTickLabelPaint((java.awt.Paint) color51);
        org.jfree.chart.LegendItem legendItem54 = new org.jfree.chart.LegendItem("item", "Last", "DateTickMarkPosition.MIDDLE", "{0}: ({1}, {2})", (java.awt.Shape) rectangle2D27, stroke28, (java.awt.Paint) color51);
        barRenderer12.setBaseStroke(stroke28, false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(list47);
        org.junit.Assert.assertNotNull(color51);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE5" + "'", str1.equals("ItemLabelAnchor.INSIDE5"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer5.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = xYStepRenderer5.hasListener((java.util.EventListener) categoryPlot25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection29 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot28.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection29);
        java.awt.Paint paint31 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo32 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean33 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint31, (java.lang.Object) basicProjectInfo32);
        xYPlot28.setRangeCrosshairPaint(paint31);
        java.awt.Paint paint35 = xYPlot28.getRangeZeroBaselinePaint();
        xYPlot28.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        xYPlot28.zoomRangeAxes(Double.NaN, plotRenderingInfo39, point2D40, true);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.entity.EntityCollection entityCollection46 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = new org.jfree.chart.ChartRenderingInfo(entityCollection46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = chartRenderingInfo47.getPlotInfo();
        org.jfree.chart.plot.CrosshairState crosshairState50 = new org.jfree.chart.plot.CrosshairState(false);
        int int51 = crosshairState50.getRangeAxisIndex();
        boolean boolean52 = xYPlot28.render(graphics2D43, rectangle2D44, 3, plotRenderingInfo48, crosshairState50);
        java.lang.Object obj53 = plotRenderingInfo48.clone();
        java.awt.geom.Rectangle2D rectangle2D54 = plotRenderingInfo48.getDataArea();
        try {
            categoryPlot25.drawOutline(graphics2D27, rectangle2D54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(plotRenderingInfo48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNotNull(rectangle2D54);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.updateCrosshairY((double) 0);
        crosshairState0.updateCrosshairY((double) 1.0f);
        crosshairState0.setAnchorY((double) 9);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer5.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = xYStepRenderer5.hasListener((java.util.EventListener) categoryPlot25);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint36 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape33, (java.awt.Paint) color34, stroke35, paint36);
        categoryPlot25.setDomainGridlinePaint((java.awt.Paint) color34);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D1.setMaximumCategoryLabelLines(10);
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter4 = new org.jfree.chart.renderer.category.GradientBarPainter();
        boolean boolean5 = categoryAxis3D1.equals((java.lang.Object) gradientBarPainter4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setLabelURL("item");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int16 = numberTickUnit14.compareTo((java.lang.Object) 10);
        numberAxis12.setTickUnit(numberTickUnit14);
        float float18 = numberAxis12.getMinorTickMarkInsideLength();
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer19.setSeriesVisible((int) (byte) 0, (java.lang.Boolean) false, true);
        double double24 = barRenderer19.getItemMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean30 = xYAreaRenderer29.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font35 = textFragment34.getFont();
        java.awt.Paint paint36 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine37 = new org.jfree.chart.text.TextLine("", font35, paint36);
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection39 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot38.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection39);
        java.awt.Paint paint41 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo42 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean43 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint41, (java.lang.Object) basicProjectInfo42);
        xYPlot38.setRangeCrosshairPaint(paint41);
        org.jfree.chart.block.LabelBlock labelBlock45 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font35, paint41);
        xYAreaRenderer29.setBaseItemLabelPaint(paint41);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition50 = xYAreaRenderer29.getPositiveItemLabelPosition(15, (int) ' ', true);
        org.jfree.chart.entity.EntityCollection entityCollection51 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo52 = new org.jfree.chart.ChartRenderingInfo(entityCollection51);
        java.awt.geom.Rectangle2D rectangle2D53 = chartRenderingInfo52.getChartArea();
        xYAreaRenderer29.setBaseShape((java.awt.Shape) rectangle2D53);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            gradientBarPainter4.paintBar(graphics2D6, barRenderer19, 500, (int) (byte) 0, true, (java.awt.geom.RectangularShape) rectangle2D53, rectangleEdge55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition50);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Multiple Pie Plot");
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        legendItem1.setOutlineStroke(stroke2);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        int int10 = xYSeriesCollection4.indexOf(xYSeries9);
        xYSeries9.add((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("2019");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key 2019");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Stroke stroke4 = piePlot1.getLabelLinkStroke();
        double double5 = piePlot1.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        int int5 = xYSeries3.indexOf((java.lang.Number) 0.2d);
        int int6 = xYSeries3.getItemCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        boolean boolean3 = xYPlot2.isRangeCrosshairVisible();
        boolean boolean4 = xYAreaRenderer0.hasListener((java.util.EventListener) xYPlot2);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean7 = xYAreaRenderer6.getAutoPopulateSeriesOutlinePaint();
        boolean boolean8 = xYAreaRenderer6.getAutoPopulateSeriesPaint();
        xYPlot2.setRenderer((int) '#', (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer6, false);
        org.jfree.chart.plot.XYPlot xYPlot11 = xYAreaRenderer6.getPlot();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo17 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint16, (java.lang.Object) basicProjectInfo17);
        xYPlot13.setRangeCrosshairPaint(paint16);
        java.awt.Paint paint20 = xYPlot13.getRangeZeroBaselinePaint();
        xYPlot13.clearDomainMarkers((int) 'a');
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.CrosshairState crosshairState27 = null;
        boolean boolean28 = xYPlot13.render(graphics2D23, rectangle2D24, (int) (byte) 1, plotRenderingInfo26, crosshairState27);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int35 = numberTickUnit33.compareTo((java.lang.Object) 10);
        numberAxis31.setTickUnit(numberTickUnit33);
        xYPlot13.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis31, false);
        xYPlot11.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis31, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(xYPlot11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint4 = textTitle3.getPaint();
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = textTitle3.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment5, (double) (-65536), (double) 100.0f);
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment5, 0.2d, 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(verticalAlignment5);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle19.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getItemLabelPadding();
        java.awt.Font font22 = legendTitle19.getItemFont();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        piePlot1.setAutoPopulateSectionOutlineStroke(true);
        java.awt.Paint paint5 = null;
        piePlot1.setShadowPaint(paint5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) (short) 10);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segmentedTimeline3.getSegment((long) 255);
        java.util.Date date8 = segment7.getDate();
        boolean boolean11 = segment7.contains((long) 'a', 3600000L);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment14 = segment7.intersect((long) (short) 100, (long) 11);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(segment7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(segment14);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot1.getLabelPadding();
        boolean boolean4 = piePlot1.getSectionOutlinesVisible();
        boolean boolean5 = piePlot1.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toRangeHeight((org.jfree.data.Range) dateRange1);
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange1);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint8 = xYStepRenderer5.lookupLegendTextPaint((int) 'a');
        xYStepRenderer5.setDefaultEntityRadius(0);
        xYStepRenderer5.setDrawOutlines(false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = xYStepRenderer5.getBaseToolTipGenerator();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape20, (java.awt.Paint) color21, stroke22, paint23);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        boolean boolean26 = xYPlot25.isRangeCrosshairVisible();
        java.awt.Paint paint27 = xYPlot25.getBackgroundPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape20, paint27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = legendGraphic28.getShapeLocation();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer30 = legendGraphic28.getFillPaintTransformer();
        boolean boolean31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYToolTipGenerator13, (java.lang.Object) legendGraphic28);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(xYToolTipGenerator13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(gradientPaintTransformer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int9 = numberTickUnit7.compareTo((java.lang.Object) 10);
        numberAxis5.setTickUnit(numberTickUnit7);
        float float11 = numberAxis5.getMinorTickMarkInsideLength();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity17 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis5, shape14, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint18 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic(shape14, paint18);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendGraphic19.getShapeLocation();
        java.awt.Paint paint21 = legendGraphic19.getFillPaint();
        barRenderer0.setBaseItemLabelPaint(paint21, true);
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setSeriesItemLabelsVisible(8, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke0, jFreeChart1, (int) (byte) -1, 1);
        int int5 = chartProgressEvent4.getPercent();
        org.jfree.chart.JFreeChart jFreeChart6 = chartProgressEvent4.getChart();
        int int7 = chartProgressEvent4.getType();
        org.junit.Assert.assertNotNull(stroke0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(jFreeChart6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection1 = xYAreaRenderer0.getAnnotations();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer0.setSeriesStroke(0, stroke3, true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        boolean boolean7 = xYPlot6.isRangeCrosshairVisible();
        java.awt.Paint paint8 = xYPlot6.getBackgroundPaint();
        xYAreaRenderer0.setBaseOutlinePaint(paint8, false);
        java.awt.Shape shape11 = xYAreaRenderer0.getLegendArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot12.getFixedLegendItems();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity16 = new org.jfree.chart.entity.JFreeChartEntity(shape11, jFreeChart15);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator17 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator18 = null;
        java.lang.String str19 = jFreeChartEntity16.getImageMapAreaTag(toolTipTagFragmentGenerator17, uRLTagFragmentGenerator18);
        jFreeChartEntity16.setToolTipText("[size=10]");
        java.lang.Object obj22 = jFreeChartEntity16.clone();
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(legendItemCollection14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        timeSeries1.removeAgedItems(0L, false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.setDomainPannable(true);
        xYPlot0.clearAnnotations();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("RectangleEdge.TOP", font2);
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("PlotEntity: tooltip = {0}: ({1}, {2})", font2);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorDown((double) 0.0f);
        axisState0.cursorDown((double) 10L);
        axisState0.cursorLeft((double) 2147483647);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        int int10 = xYSeriesCollection4.indexOf(xYSeries9);
        org.jfree.data.Range range12 = xYSeriesCollection4.getDomainBounds(false);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYSeriesCollection4.equals(obj13);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("");
        textLine1.removeFragment(textFragment3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        java.awt.Paint paint8 = numberAxis6.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis6.getStandardTickUnits();
        boolean boolean10 = textLine1.equals((java.lang.Object) numberAxis6);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textLine1.calculateDimensions(graphics2D11);
        size2D12.setHeight((double) 11);
        double double15 = size2D12.width;
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        int int7 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) "Other");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double11 = timeSeries10.getMinY();
        timeSeries10.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        int int15 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
        java.text.DateFormat dateFormat17 = null;
        java.text.DateFormat dateFormat18 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator19 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat17, dateFormat18);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer21 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator19, xYURLGenerator20);
        java.awt.Font font25 = xYStepRenderer21.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        boolean boolean28 = xYPlot27.isRangeCrosshairVisible();
        java.awt.Paint paint29 = xYPlot27.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis31.pan(0.0d);
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        xYStepRenderer21.drawRangeMarker(graphics2D26, xYPlot27, (org.jfree.chart.axis.ValueAxis) numberAxis31, marker34, rectangle2D35);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent37 = null;
        xYPlot27.datasetChanged(datasetChangeEvent37);
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit42 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int44 = numberTickUnit42.compareTo((java.lang.Object) 10);
        numberAxis40.setTickUnit(numberTickUnit42);
        numberAxis40.setMinorTickMarkInsideLength((-1.0f));
        numberAxis40.pan((double) 2147483647);
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit53 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int55 = numberTickUnit53.compareTo((java.lang.Object) 10);
        numberAxis51.setTickUnit(numberTickUnit53);
        float float57 = numberAxis51.getMinorTickMarkInsideLength();
        java.awt.Shape shape58 = numberAxis51.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit62 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int64 = numberTickUnit62.compareTo((java.lang.Object) 10);
        numberAxis60.setTickUnit(numberTickUnit62);
        java.awt.Shape shape72 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color73 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke74 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint75 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem76 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape72, (java.awt.Paint) color73, stroke74, paint75);
        numberAxis60.setRightArrow(shape72);
        org.jfree.chart.axis.NumberAxis numberAxis79 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape80 = numberAxis79.getLeftArrow();
        java.awt.Paint paint81 = numberAxis79.getTickLabelPaint();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray82 = new org.jfree.chart.axis.ValueAxis[] { numberAxis40, numberAxis51, numberAxis60, numberAxis79 };
        xYPlot27.setDomainAxes(valueAxisArray82);
        int int84 = month14.compareTo((java.lang.Object) xYPlot27);
        org.jfree.chart.axis.AxisLocation axisLocation86 = xYPlot27.getDomainAxisLocation(8);
        xYPlot0.setDomainAxisLocation((int) (short) 100, axisLocation86, true);
        xYPlot0.setDomainCrosshairValue((double) (short) 0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + float57 + "' != '" + 0.0f + "'", float57 == 0.0f);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertNotNull(shape80);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNotNull(valueAxisArray82);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(axisLocation86);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis3D15.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D18, rectangleEdge19);
        java.awt.Paint paint22 = null;
        categoryAxis3D15.setTickLabelPaint((java.lang.Comparable) 1.0d, paint22);
        java.awt.Font font25 = categoryAxis3D15.getTickLabelFont((java.lang.Comparable) 100L);
        categoryAxis3D15.removeCategoryLabelToolTip((java.lang.Comparable) "[size=10]");
        org.jfree.chart.entity.AxisEntity axisEntity30 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D15, "Value", "ThreadContext");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list8 = timeSeries7.getItems();
        segmentedTimeline3.setExceptionSegments(list8);
        int int10 = segmentedTimeline3.getSegmentsIncluded();
        java.text.DateFormat dateFormat12 = null;
        java.text.DateFormat dateFormat13 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator14 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat12, dateFormat13);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator14, xYURLGenerator15);
        java.awt.Shape shape17 = xYStepRenderer16.getBaseShape();
        java.awt.Paint paint21 = xYStepRenderer16.getItemFillPaint(0, (int) (short) 100, false);
        boolean boolean22 = segmentedTimeline3.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("DomainOrder.ASCENDING");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition26 = dateAxis25.getTickMarkPosition();
        java.util.Date date27 = dateAxis25.getMaximumDate();
        java.lang.String str28 = dateTickUnit23.dateToString(date27);
        long long29 = segmentedTimeline3.getTime(date27);
        java.util.TimeZone timeZone30 = null;
        try {
            org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date27, timeZone30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(dateTickMarkPosition26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "12/31/69 4:00 PM" + "'", str28.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer4.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer4.getLegendItemLabelGenerator();
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis3D6.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D9, rectangleEdge10);
        java.awt.Paint paint13 = null;
        categoryAxis3D6.setTickLabelPaint((java.lang.Comparable) 1.0d, paint13);
        java.awt.Font font16 = categoryAxis3D6.getTickLabelFont((java.lang.Comparable) 100L);
        categoryAxis3D6.removeCategoryLabelToolTip((java.lang.Comparable) "[size=10]");
        org.jfree.data.xy.XYDataItem xYDataItem21 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 5, (java.lang.Number) 1);
        xYDataItem21.setSelected(false);
        categoryAxis3D6.addCategoryLabelToolTip((java.lang.Comparable) xYDataItem21, "Value");
        xYSeries3.add(xYDataItem21, false);
        org.jfree.data.xy.XYSeries xYSeries31 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection32 = new org.jfree.data.xy.XYSeriesCollection(xYSeries31);
        org.jfree.data.xy.XYDataItem xYDataItem35 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 5, (java.lang.Number) 1);
        xYDataItem35.setSelected(false);
        xYSeries31.add(xYDataItem35);
        java.lang.Number number39 = xYDataItem35.getX();
        xYSeries3.add(xYDataItem35);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 5 + "'", number39.equals(5));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = multiplePiePlot0.getLegendItems();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis3D4.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint11 = null;
        categoryAxis3D4.setTickLabelPaint((java.lang.Comparable) 1.0d, paint11);
        java.awt.Font font14 = categoryAxis3D4.getTickLabelFont((java.lang.Comparable) 100L);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int22 = numberTickUnit20.compareTo((java.lang.Object) 10);
        numberAxis18.setTickUnit(numberTickUnit20);
        org.jfree.chart.entity.EntityCollection entityCollection25 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = new org.jfree.chart.ChartRenderingInfo(entityCollection25);
        java.awt.geom.Rectangle2D rectangle2D27 = chartRenderingInfo26.getChartArea();
        chartRenderingInfo26.clear();
        java.awt.geom.Rectangle2D rectangle2D29 = chartRenderingInfo26.getChartArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double31 = numberAxis18.java2DToValue(1.0E-8d, rectangle2D29, rectangleEdge30);
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean35 = textLine33.equals((java.lang.Object) rectangleEdge34);
        double double36 = categoryAxis3D4.getCategoryEnd((int) (short) -1, 0, rectangle2D29, rectangleEdge34);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor40 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection44 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot43.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = xYPlot43.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation47 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot43.setOrientation(plotOrientation47);
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list53 = timeSeries52.getItems();
        xYPlot43.drawRangeTickBands(graphics2D49, rectangle2D50, list53);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.entity.EntityCollection entityCollection56 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo57 = new org.jfree.chart.ChartRenderingInfo(entityCollection56);
        java.awt.geom.Rectangle2D rectangle2D58 = chartRenderingInfo57.getChartArea();
        chartRenderingInfo57.clear();
        java.awt.geom.Rectangle2D rectangle2D60 = chartRenderingInfo57.getChartArea();
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list63 = timeSeries62.getItems();
        xYPlot43.drawRangeTickBands(graphics2D55, rectangle2D60, list63);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double66 = categoryAxis39.getCategoryJava2DCoordinate(categoryAnchor40, 7, (int) (short) 1, rectangle2D60, rectangleEdge65);
        java.awt.geom.Point2D point2D67 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 11, (double) 1561964399999L, rectangle2D60);
        org.jfree.chart.plot.PlotState plotState68 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.entity.EntityCollection entityCollection69 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo70 = new org.jfree.chart.ChartRenderingInfo(entityCollection69);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = chartRenderingInfo70.getPlotInfo();
        try {
            multiplePiePlot0.draw(graphics2D2, rectangle2D29, point2D67, plotState68, plotRenderingInfo71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.POSITIVE_INFINITY + "'", double31 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNotNull(plotOrientation47);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(list63);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(point2D67);
        org.junit.Assert.assertNotNull(plotRenderingInfo71);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        double double20 = rectangleInsets17.calculateBottomOutset((double) 0L);
        double double22 = rectangleInsets17.extendWidth((double) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 9.0d + "'", double22 == 9.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint8 = xYStepRenderer5.lookupLegendTextPaint((int) 'a');
        xYStepRenderer5.setBaseLinesVisible(true);
        xYStepRenderer5.setUseFillPaint(false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = xYStepRenderer5.getLegendItemToolTipGenerator();
        java.awt.Paint paint14 = xYStepRenderer5.getBaseItemLabelPaint();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer5.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = xYStepRenderer5.hasListener((java.util.EventListener) categoryPlot25);
        boolean boolean27 = xYStepRenderer5.getDrawSeriesLineAsPath();
        xYStepRenderer5.setAutoPopulateSeriesFillPaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYStepRenderer5.getNegativeItemLabelPosition((int) (short) -1, (int) (short) 0, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = xYStepRenderer5.getDrawingSupplier();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator35 = null;
        try {
            xYStepRenderer5.setLegendItemLabelGenerator(xYSeriesLabelGenerator35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNull(drawingSupplier34);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Paint paint2 = xYPlot0.getBackgroundPaint();
        xYPlot0.setRangeCrosshairValue(0.0d, true);
        boolean boolean6 = xYPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape10 = numberAxis9.getLeftArrow();
        java.awt.Paint paint11 = numberAxis9.getTickLabelPaint();
        xYPlot0.setDomainAxis(2, (org.jfree.chart.axis.ValueAxis) numberAxis9, false);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int19 = numberTickUnit17.compareTo((java.lang.Object) 10);
        numberAxis15.setTickUnit(numberTickUnit17);
        numberAxis9.setTickUnit(numberTickUnit17, false, false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = numberAxis9.getMarkerBand();
        boolean boolean25 = numberAxis9.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(markerAxisBand24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator2);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        timeSeries1.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.Year year7 = month5.getYear();
        long long8 = month5.getLastMillisecond();
        java.lang.String str9 = month5.toString();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape6, paint13);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot16.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot16.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        int int21 = color19.getBlue();
        boolean boolean22 = standardXYToolTipGenerator15.equals((java.lang.Object) color19);
        legendGraphic14.setFillPaint((java.awt.Paint) color19);
        int int24 = color19.getGreen();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 128 + "'", int21 == 128);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        int int3 = java.awt.Color.HSBtoRGB((float) 5, (float) 35L, (float) 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-153) + "'", int3 == (-153));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DomainOrder.ASCENDING");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis2.getTickMarkPosition();
        java.util.Date date4 = dateAxis2.getMaximumDate();
        java.lang.String str5 = dateTickUnit0.dateToString(date4);
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) str5);
        double[][] doubleArray7 = xYSeries6.toArray();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12/31/69 4:00 PM" + "'", str5.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.text.DateFormat dateFormat2 = null;
        java.text.DateFormat dateFormat3 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat2, dateFormat3);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator4, xYURLGenerator5);
        java.awt.Font font10 = xYStepRenderer6.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        boolean boolean13 = xYPlot12.isRangeCrosshairVisible();
        java.awt.Paint paint14 = xYPlot12.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis16.pan(0.0d);
        org.jfree.chart.plot.Marker marker19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYStepRenderer6.drawRangeMarker(graphics2D11, xYPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis16, marker19, rectangle2D20);
        boolean boolean22 = defaultDrawingSupplier0.equals((java.lang.Object) xYStepRenderer6);
        java.lang.Boolean boolean24 = xYStepRenderer6.getSeriesShapesFilled(1);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(boolean24);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.text.DateFormat dateFormat2 = null;
        java.text.DateFormat dateFormat3 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat2, dateFormat3);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator4, xYURLGenerator5);
        java.awt.Font font10 = xYStepRenderer6.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        boolean boolean13 = xYPlot12.isRangeCrosshairVisible();
        java.awt.Paint paint14 = xYPlot12.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis16.pan(0.0d);
        org.jfree.chart.plot.Marker marker19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYStepRenderer6.drawRangeMarker(graphics2D11, xYPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis16, marker19, rectangle2D20);
        boolean boolean22 = defaultDrawingSupplier0.equals((java.lang.Object) xYStepRenderer6);
        xYStepRenderer6.setStepPoint(0.05d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        xYPlot11.datasetChanged(datasetChangeEvent21);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit26 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int28 = numberTickUnit26.compareTo((java.lang.Object) 10);
        numberAxis24.setTickUnit(numberTickUnit26);
        numberAxis24.setMinorTickMarkInsideLength((-1.0f));
        numberAxis24.pan((double) 2147483647);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int39 = numberTickUnit37.compareTo((java.lang.Object) 10);
        numberAxis35.setTickUnit(numberTickUnit37);
        float float41 = numberAxis35.getMinorTickMarkInsideLength();
        java.awt.Shape shape42 = numberAxis35.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit46 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int48 = numberTickUnit46.compareTo((java.lang.Object) 10);
        numberAxis44.setTickUnit(numberTickUnit46);
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint59 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem60 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape56, (java.awt.Paint) color57, stroke58, paint59);
        numberAxis44.setRightArrow(shape56);
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape64 = numberAxis63.getLeftArrow();
        java.awt.Paint paint65 = numberAxis63.getTickLabelPaint();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray66 = new org.jfree.chart.axis.ValueAxis[] { numberAxis24, numberAxis35, numberAxis44, numberAxis63 };
        xYPlot11.setDomainAxes(valueAxisArray66);
        org.jfree.chart.util.Layer layer68 = null;
        java.util.Collection collection69 = xYPlot11.getRangeMarkers(layer68);
        boolean boolean70 = xYPlot11.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace71 = xYPlot11.getFixedRangeAxisSpace();
        java.awt.Paint paint72 = xYPlot11.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(valueAxisArray66);
        org.junit.Assert.assertNull(collection69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNull(axisSpace71);
        org.junit.Assert.assertNotNull(paint72);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font6 = xYStepRenderer5.getBaseLegendTextFont();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = xYStepRenderer5.getBaseItemLabelGenerator();
        java.awt.Font font11 = xYStepRenderer5.getItemLabelFont((-153), 8, true);
        org.junit.Assert.assertNull(font6);
        org.junit.Assert.assertNull(xYItemLabelGenerator7);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection1 = xYAreaRenderer0.getAnnotations();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer0.setSeriesStroke(0, stroke3, true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        boolean boolean7 = xYPlot6.isRangeCrosshairVisible();
        java.awt.Paint paint8 = xYPlot6.getBackgroundPaint();
        xYAreaRenderer0.setBaseOutlinePaint(paint8, false);
        java.awt.Shape shape11 = xYAreaRenderer0.getLegendArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot12.getFixedLegendItems();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity16 = new org.jfree.chart.entity.JFreeChartEntity(shape11, jFreeChart15);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator17 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator18 = null;
        java.lang.String str19 = jFreeChartEntity16.getImageMapAreaTag(toolTipTagFragmentGenerator17, uRLTagFragmentGenerator18);
        jFreeChartEntity16.setToolTipText("[size=10]");
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection27 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot26.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot26.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot26.setOrientation(plotOrientation30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list36 = timeSeries35.getItems();
        xYPlot26.drawRangeTickBands(graphics2D32, rectangle2D33, list36);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.entity.EntityCollection entityCollection39 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = new org.jfree.chart.ChartRenderingInfo(entityCollection39);
        java.awt.geom.Rectangle2D rectangle2D41 = chartRenderingInfo40.getChartArea();
        chartRenderingInfo40.clear();
        java.awt.geom.Rectangle2D rectangle2D43 = chartRenderingInfo40.getChartArea();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list46 = timeSeries45.getItems();
        xYPlot26.drawRangeTickBands(graphics2D38, rectangle2D43, list46);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double49 = categoryAxis22.getCategoryJava2DCoordinate(categoryAnchor23, 7, (int) (short) 1, rectangle2D43, rectangleEdge48);
        jFreeChartEntity16.setArea((java.awt.Shape) rectangle2D43);
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(legendItemCollection14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }
}

