import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Paint paint0 = null;
        java.awt.Paint paint1 = null;
        boolean boolean2 = org.jfree.chart.util.PaintUtilities.equal(paint0, paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("hi!", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.text.NumberFormat numberFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", numberFormat1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'xFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Color color0 = null;
        try {
            java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        waferMapPlot1.setNoDataMessage("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        waferMapPlot1.setOutlineStroke(stroke4);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection6 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "", jFreeChart4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (byte) -1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange(range0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Shape shape0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity6 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "", "", categoryDataset3, (java.lang.Comparable) 'a', (java.lang.Comparable) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.util.TimeZone timeZone0 = null;
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0, locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = null;
        try {
            xYStepRenderer5.setLegendLine(shape6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'line' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        try {
            numberAxis1.setAutoRangeMinimumSize((double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieToolTipGenerator.DEFAULT_TOOLTIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        try {
            long long5 = segmentedTimeline3.toMillisecond((long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            int int4 = timeSeriesCollection1.getItemCount(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) '4', (double) 0.0f, 3, (java.lang.Comparable) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (-1), (double) 1, (double) 0.0f);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = null;
        java.awt.geom.RectangularShape rectangularShape9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        try {
            gradientBarPainter3.paintBar(graphics2D4, barRenderer5, (int) (byte) -1, (int) 'a', false, rectangularShape9, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            xYPlot0.addRangeMarker(marker3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color3);
        float[] floatArray7 = new float[] { 0.5f, 2147483647 };
        try {
            float[] floatArray8 = color3.getColorComponents(floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean4 = segmentedTimeline3.getAdjustForDaylightSaving();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        org.jfree.chart.title.Title title14 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity17 = new org.jfree.chart.entity.TitleEntity(shape10, title14, "hi!", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'title' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (-1), (double) 1, (double) 0.0f);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = null;
        java.awt.geom.RectangularShape rectangularShape9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        try {
            gradientBarPainter3.paintBar(graphics2D4, barRenderer5, 100, (int) (short) -1, false, rectangularShape9, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D4, rectangleEdge5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int13 = numberTickUnit11.compareTo((java.lang.Object) 10);
        numberAxis9.setTickUnit(numberTickUnit11);
        float float15 = numberAxis9.getMinorTickMarkInsideLength();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity21 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis9, shape18, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.AxisState axisState23 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        java.util.List list26 = numberAxis9.refreshTicks(graphics2D22, axisState23, rectangle2D24, rectangleEdge25);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        try {
            java.util.List list29 = categoryAxis3D1.refreshTicks(graphics2D7, axisState23, rectangle2D27, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(list26);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = null;
        try {
            xYPlot0.setInsets(rectangleInsets7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.plot.Marker marker3 = null;
        try {
            xYPlot0.addDomainMarker(marker3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        waferMapPlot1.setNoDataMessage("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        waferMapPlot1.setOutlineStroke(stroke4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = waferMapPlot1.getDrawingSupplier();
        java.lang.Object obj7 = waferMapPlot1.clone();
        int int8 = waferMapPlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, 0.0d, "hi!", textAnchor3, textAnchor4, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) (short) 10);
        java.util.Date date6 = null;
        try {
            segmentedTimeline3.addBaseTimelineException(date6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = xYPlot0.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets10.createInsetRectangle(rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 0, range1);
        double double3 = rectangleConstraint2.getHeight();
        org.jfree.data.Range range4 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toRangeHeight(range4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int3 = numberTickUnit1.compareTo((java.lang.Object) 10);
        int int4 = numberTickUnit1.getMinorTickCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.MIDDLE" + "'", str1.equals("DateTickMarkPosition.MIDDLE"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int6 = numberTickUnit4.compareTo((java.lang.Object) 10);
        numberAxis2.setTickUnit(numberTickUnit4);
        float float8 = numberAxis2.getMinorTickMarkInsideLength();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity14 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis2, shape11, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis2.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        try {
            org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, list19, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        xYPlot0.setDomainMinorGridlinesVisible(false);
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            xYPlot0.addRangeMarker((int) (short) 10, marker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D4, rectangleEdge5);
        java.awt.Paint paint8 = null;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) 1.0d, paint8);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot16.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot16.getRangeAxisEdge();
        try {
            double double20 = categoryAxis3D1.getCategorySeriesMiddle((int) (short) 100, 10, (-1), 1, (double) '4', rectangle2D15, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        double double2 = categoryAxis3D1.getCategoryMargin();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot6.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = xYPlot6.getRangeAxisEdge();
        try {
            double double10 = categoryAxis3D1.getCategoryMiddle(128, (int) (short) 1, rectangle2D5, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 128");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font6 = xYStepRenderer5.getBaseLegendTextFont();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = null;
        try {
            xYStepRenderer5.setSeriesItemLabelGenerator((-1), xYItemLabelGenerator8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font6);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font4 = textFragment3.getFont();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font4, paint5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font4, paint10);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.Range range17 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 0, range17);
        double double19 = rectangleConstraint18.getHeight();
        try {
            org.jfree.chart.util.Size2D size2D20 = labelBlock14.arrange(graphics2D15, rectangleConstraint18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color3);
        int int5 = color3.getBlue();
        java.awt.color.ColorSpace colorSpace6 = color3.getColorSpace();
        int int7 = color3.getTransparency();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 128 + "'", int5 == 128);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.awt.Shape shape0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity3 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        java.io.ObjectOutputStream objectOutputStream11 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke8, objectOutputStream11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color3);
        int int5 = color3.getBlue();
        java.awt.color.ColorSpace colorSpace6 = color3.getColorSpace();
        int int7 = color3.getAlpha();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 128 + "'", int5 == 128);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 255 + "'", int7 == 255);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int0 = java.text.NumberFormat.INTEGER_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, (float) ' ', (float) 24234L, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("AxisLabelEntity: label = hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            xYPlot0.drawBackground(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("AxisLabelEntity: label = hi!", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            boolean boolean4 = xYPlot0.removeAnnotation(xYAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        xYPlot0.clearRangeMarkers(100);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9, false);
        java.awt.Paint paint12 = xYPlot0.getOutlinePaint();
        xYPlot0.setRangePannable(true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = xYPlot0.getAxisOffset();
        double double12 = rectangleInsets10.calculateBottomOutset(1.0d);
        double double14 = rectangleInsets10.calculateLeftInset((double) 0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D4, rectangleEdge5);
        java.awt.Paint paint8 = null;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) 1.0d, paint8);
        java.awt.Font font11 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) 100L);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        boolean boolean14 = xYPlot13.isRangeCrosshairVisible();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace18 = categoryAxis3D1.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) xYPlot13, rectangle2D15, rectangleEdge16, axisSpace17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke0, jFreeChart1, (int) (byte) -1, 1);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        chartProgressEvent4.setChart(jFreeChart5);
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot2.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        int int7 = color5.getBlue();
        xYAreaRenderer0.setSeriesItemLabelPaint((int) ' ', (java.awt.Paint) color5, false);
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        try {
            xYAreaRenderer0.setSeriesItemLabelFont((int) (byte) -1, font11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 128 + "'", int7 == 128);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend3 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, (org.jfree.chart.axis.ValueAxis) numberAxis2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        try {
            boolean boolean6 = xYPlot0.removeAnnotation(xYAnnotation4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font4 = textFragment3.getFont();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font4, paint5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font4, paint10);
        boolean boolean16 = labelBlock14.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 100L, "{0}: ({1}, {2})", textAnchor3, textAnchor4, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE11" + "'", str1.equals("ItemLabelAnchor.INSIDE11"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo1 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint0, (java.lang.Object) basicProjectInfo1);
        java.lang.String str3 = basicProjectInfo1.getVersion();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("");
        textLine1.removeFragment(textFragment3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        java.awt.Paint paint8 = numberAxis6.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis6.getStandardTickUnits();
        boolean boolean10 = textLine1.equals((java.lang.Object) numberAxis6);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean16 = textLine14.equals((java.lang.Object) rectangleEdge15);
        try {
            double double17 = numberAxis6.valueToJava2D((double) 5, rectangle2D12, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ItemLabelAnchor.INSIDE11", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 100);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        try {
            xYPlot0.setRangeAxisLocation(axisLocation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D1.setMaximumCategoryLabelLines(10);
        categoryAxis3D1.removeCategoryLabelToolTip((java.lang.Comparable) 10);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 100, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        chartChangeEvent3.setChart(jFreeChart4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "hi!" + "'", str0.equals("hi!"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range1, lengthConstraintType2, (double) 1, range4, lengthConstraintType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D4.clearCategoryLabelToolTips();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int11 = numberTickUnit9.compareTo((java.lang.Object) 10);
        numberAxis7.setTickUnit(numberTickUnit9);
        float float13 = numberAxis7.getMinorTickMarkInsideLength();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity19 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis7, shape16, "hi!", "{0}: ({1}, {2})");
        numberAxis7.setVerticalTickLabels(false);
        org.jfree.chart.util.Layer layer22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            barRenderer0.drawAnnotations(graphics2D1, rectangle2D2, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D4, (org.jfree.chart.axis.ValueAxis) numberAxis7, layer22, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset4 = new org.jfree.data.xy.DefaultXYDataset();
        boolean boolean5 = standardXYToolTipGenerator3.equals((java.lang.Object) defaultXYDataset4);
        try {
            java.lang.Comparable comparable7 = defaultXYDataset4.getSeriesKey((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) (-1));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint2, (java.lang.Object) basicProjectInfo3);
        try {
            org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("DateTickMarkPosition.MIDDLE", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        timeSeries1.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) 100 + "'", comparable7.equals((short) 100));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D4, rectangleEdge5);
        java.awt.Paint paint8 = null;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) 1.0d, paint8);
        java.awt.Font font11 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) categoryAxis3D1, seriesChangeInfo12);
        java.awt.Font font14 = null;
        try {
            categoryAxis3D1.setTickLabelFont(font14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            java.lang.Number number3 = timeSeriesCollection0.getEndX((-1), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int6 = numberTickUnit4.compareTo((java.lang.Object) 10);
        numberAxis2.setTickUnit(numberTickUnit4);
        float float8 = numberAxis2.getMinorTickMarkInsideLength();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity14 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis2, shape11, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis2.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        try {
            org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds(xYDataset0, list19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot1.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        java.awt.Paint paint4 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint4, (java.lang.Object) basicProjectInfo5);
        xYPlot1.setRangeCrosshairPaint(paint4);
        java.awt.Paint paint8 = xYPlot1.getRangeZeroBaselinePaint();
        xYPlot1.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot1.zoomRangeAxes(Double.NaN, plotRenderingInfo12, point2D13, true);
        xYPlot1.setRangeMinorGridlinesVisible(true);
        java.awt.Font font18 = xYPlot1.getNoDataMessageFont();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape25, (java.awt.Paint) color26, stroke27, paint28);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D31 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = categoryAxis3D31.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D34, rectangleEdge35);
        java.awt.Font font38 = null;
        categoryAxis3D31.setTickLabelFont((java.lang.Comparable) (-1L), font38);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.text.TextLine textLine44 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean46 = textLine44.equals((java.lang.Object) rectangleEdge45);
        org.jfree.chart.axis.AxisState axisState47 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D31.drawTickMarks(graphics2D40, (double) 1.0f, rectangle2D42, rectangleEdge45, axisState47);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment49 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment50 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        try {
            org.jfree.chart.title.TextTitle textTitle52 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE", font18, (java.awt.Paint) color26, rectangleEdge45, horizontalAlignment49, verticalAlignment50, rectangleInsets51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(rectangleInsets51);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint10 = xYStepRenderer5.getItemFillPaint(0, (int) (short) 100, false);
        xYStepRenderer5.setSeriesLinesVisible((int) (short) 10, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("");
        textLine1.removeFragment(textFragment3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        java.awt.Paint paint8 = numberAxis6.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis6.getStandardTickUnits();
        boolean boolean10 = textLine1.equals((java.lang.Object) numberAxis6);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textLine1.calculateDimensions(graphics2D11);
        java.lang.String str13 = size2D12.toString();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str13.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        barRenderer0.setSeriesToolTipGenerator(0, categoryToolTipGenerator6, true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        xYPlot0.setDomainMinorGridlinesVisible(false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CrosshairState crosshairState14 = new org.jfree.chart.plot.CrosshairState(false);
        boolean boolean15 = xYPlot0.render(graphics2D9, rectangle2D10, (int) (short) 0, plotRenderingInfo12, crosshairState14);
        java.awt.Font font16 = null;
        try {
            xYPlot0.setNoDataMessageFont(font16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color3);
        java.awt.Color color5 = color3.brighter();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        double double2 = categoryAxis3D1.getCategoryMargin();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        categoryAxis3D1.drawTickMarks(graphics2D3, (double) (short) 100, rectangle2D5, rectangleEdge6, axisState7);
        double double9 = categoryAxis3D1.getCategoryMargin();
        java.awt.Paint paint11 = categoryAxis3D1.getTickLabelPaint((java.lang.Comparable) 0.0f);
        categoryAxis3D1.setLabel("ItemLabelAnchor.INSIDE11");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint10 = xYStepRenderer5.getItemFillPaint(0, (int) (short) 100, false);
        boolean boolean11 = xYStepRenderer5.getBaseItemLabelsVisible();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesPaint();
        xYAreaRenderer0.setBaseItemLabelsVisible(false, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Size2D[width=0.0, height=0.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Size2D[width=0.0, height=0.0], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        double double2 = categoryAxis3D1.getCategoryMargin();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        categoryAxis3D1.drawTickMarks(graphics2D3, (double) (short) 100, rectangle2D5, rectangleEdge6, axisState7);
        double double9 = categoryAxis3D1.getCategoryMargin();
        java.lang.String str10 = categoryAxis3D1.getLabelURL();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        xYPlot0.clearRangeMarkers(100);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9, false);
        boolean boolean12 = xYPlot0.canSelectByPoint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("");
        textLine5.removeFragment(textFragment7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape11 = numberAxis10.getLeftArrow();
        java.awt.Paint paint12 = numberAxis10.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = numberAxis10.getStandardTickUnits();
        boolean boolean14 = textLine5.equals((java.lang.Object) numberAxis10);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.util.Size2D size2D16 = textLine5.calculateDimensions(graphics2D15);
        try {
            org.jfree.chart.util.Size2D size2D17 = rectangleConstraint2.calculateConstrainedSize(size2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(size2D16);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 100);
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection5 = xYAreaRenderer4.getAnnotations();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYAreaRenderer4);
        boolean boolean7 = multiplePiePlot0.equals((java.lang.Object) xYAreaRenderer4);
        java.lang.Object obj8 = multiplePiePlot0.clone();
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape7, (java.awt.Paint) color8, stroke9, paint10);
        java.awt.Stroke stroke12 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 86400000L, (java.awt.Paint) color8, stroke12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint10 = xYStepRenderer5.getItemFillPaint(0, (int) (short) 100, false);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape14 = numberAxis13.getLeftArrow();
        try {
            xYStepRenderer5.setSeriesShape((int) (short) -1, shape14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer2.getSeriesItemLabelGenerator(255);
        java.awt.geom.RectangularShape rectangularShape8 = null;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean12 = textLine10.equals((java.lang.Object) rectangleEdge11);
        try {
            gradientBarPainter0.paintBarShadow(graphics2D1, barRenderer2, 2, (int) (short) 0, false, rectangularShape8, rectangleEdge11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.text.DateFormat dateFormat22 = null;
        java.text.DateFormat dateFormat23 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator24 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat22, dateFormat23);
        java.text.NumberFormat numberFormat25 = standardXYToolTipGenerator24.getXFormat();
        boolean boolean26 = numberAxis15.equals((java.lang.Object) standardXYToolTipGenerator24);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(numberFormat25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint10 = xYStepRenderer5.getItemFillPaint(0, (int) (short) 100, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = null;
        xYStepRenderer5.setSeriesItemLabelGenerator((int) '#', xYItemLabelGenerator12);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        java.awt.Stroke stroke11 = legendItem10.getOutlineStroke();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot12.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection13);
        java.awt.Paint paint15 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo16 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint15, (java.lang.Object) basicProjectInfo16);
        xYPlot12.setRangeCrosshairPaint(paint15);
        java.awt.Paint paint19 = xYPlot12.getRangeZeroBaselinePaint();
        legendItem10.setOutlinePaint(paint19);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            timeSeriesCollection0.setSelected(10, (int) (byte) 10, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot4.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color7);
        int int9 = color7.getBlue();
        java.awt.color.ColorSpace colorSpace10 = color7.getColorSpace();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot11.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        java.awt.Paint paint14 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint14, (java.lang.Object) basicProjectInfo15);
        xYPlot11.setRangeCrosshairPaint(paint14);
        java.awt.Paint paint18 = xYPlot11.getRangeZeroBaselinePaint();
        xYPlot11.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = xYPlot11.getAxisOffset();
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot23 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset22);
        waferMapPlot23.setNoDataMessage("hi!");
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        waferMapPlot23.setOutlineStroke(stroke26);
        xYPlot11.setDomainZeroBaselineStroke(stroke26);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 10L, (java.awt.Paint) color2, stroke3, (java.awt.Paint) color7, stroke26, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 128 + "'", int9 == 128);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot2.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        int int7 = color5.getBlue();
        xYAreaRenderer0.setSeriesItemLabelPaint((int) ' ', (java.awt.Paint) color5, false);
        boolean boolean10 = xYAreaRenderer0.isOutline();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot12.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection13);
        java.awt.Paint paint15 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo16 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint15, (java.lang.Object) basicProjectInfo16);
        xYPlot12.setRangeCrosshairPaint(paint15);
        java.awt.Paint paint19 = xYPlot12.getRangeZeroBaselinePaint();
        xYPlot12.clearDomainMarkers((int) 'a');
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.CrosshairState crosshairState26 = null;
        boolean boolean27 = xYPlot12.render(graphics2D22, rectangle2D23, (int) (byte) 1, plotRenderingInfo25, crosshairState26);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit32 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int34 = numberTickUnit32.compareTo((java.lang.Object) 10);
        numberAxis30.setTickUnit(numberTickUnit32);
        xYPlot12.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis30, false);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit41 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int43 = numberTickUnit41.compareTo((java.lang.Object) 10);
        numberAxis39.setTickUnit(numberTickUnit41);
        float float45 = numberAxis39.getMinorTickMarkInsideLength();
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity51 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis39, shape48, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.axis.AxisState axisState53 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        java.util.List list56 = numberAxis39.refreshTicks(graphics2D52, axisState53, rectangle2D54, rectangleEdge55);
        boolean boolean57 = numberAxis39.isMinorTickMarksVisible();
        numberAxis39.setFixedAutoRange((double) (-1));
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        try {
            xYAreaRenderer0.fillRangeGridBand(graphics2D11, xYPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis39, rectangle2D60, (double) 0.5f, 4.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 128 + "'", int7 == 128);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 0.0f + "'", float45 == 0.0f);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(list56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape6, paint13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendGraphic14.getShapeLocation();
        java.awt.Shape shape16 = legendGraphic14.getLine();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNull(shape16);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        boolean boolean5 = standardXYToolTipGenerator3.equals((java.lang.Object) color4);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        xYPlot0.clearRangeMarkers(100);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation9 = null;
        try {
            boolean boolean11 = xYPlot0.removeAnnotation(xYAnnotation9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int12 = numberTickUnit10.compareTo((java.lang.Object) 10);
        numberAxis8.setTickUnit(numberTickUnit10);
        float float14 = numberAxis8.getMinorTickMarkInsideLength();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity20 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis8, shape17, "hi!", "{0}: ({1}, {2})");
        int int21 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis8);
        boolean boolean22 = numberAxis8.isAxisLineVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        boolean boolean7 = xYStepRenderer5.getUseOutlinePaint();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) ' ', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        long long2 = month1.getSerialIndex();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) long2, false);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Rotation.ANTICLOCKWISE");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        xYPlot0.setRangeMinorGridlinesVisible(true);
        java.awt.Font font17 = xYPlot0.getNoDataMessageFont();
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot0.getRangeMarkers(layer18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int25 = numberTickUnit23.compareTo((java.lang.Object) 10);
        numberAxis21.setTickUnit(numberTickUnit23);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint36 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape33, (java.awt.Paint) color34, stroke35, paint36);
        numberAxis21.setRightArrow(shape33);
        double double39 = numberAxis21.getAutoRangeMinimumSize();
        boolean boolean40 = numberAxis21.isVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        xYPlot0.setDomainMinorGridlinesVisible(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0E-8d + "'", double39 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Paint paint2 = xYPlot0.getBackgroundPaint();
        xYPlot0.setRangeCrosshairValue(0.0d, true);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getRangeAxisForDataset((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 10 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairVisible();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        try {
            xYPlot0.rendererChanged(rendererChangeEvent2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        try {
            timeSeries1.delete(128, 128, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection1.getSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection1.getDomainOrder();
        java.lang.String str8 = domainOrder7.toString();
        org.junit.Assert.assertNull(timeSeries6);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DomainOrder.ASCENDING" + "'", str8.equals("DomainOrder.ASCENDING"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        numberAxis1.setUpperMargin(0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setMinimumBarLength((double) 0L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        timeSeries1.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        java.text.DateFormat dateFormat8 = null;
        java.text.DateFormat dateFormat9 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator10 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat8, dateFormat9);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator10, xYURLGenerator11);
        java.awt.Font font16 = xYStepRenderer12.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        boolean boolean19 = xYPlot18.isRangeCrosshairVisible();
        java.awt.Paint paint20 = xYPlot18.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis22.pan(0.0d);
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        xYStepRenderer12.drawRangeMarker(graphics2D17, xYPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis22, marker25, rectangle2D26);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = null;
        xYPlot18.datasetChanged(datasetChangeEvent28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int35 = numberTickUnit33.compareTo((java.lang.Object) 10);
        numberAxis31.setTickUnit(numberTickUnit33);
        numberAxis31.setMinorTickMarkInsideLength((-1.0f));
        numberAxis31.pan((double) 2147483647);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit44 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int46 = numberTickUnit44.compareTo((java.lang.Object) 10);
        numberAxis42.setTickUnit(numberTickUnit44);
        float float48 = numberAxis42.getMinorTickMarkInsideLength();
        java.awt.Shape shape49 = numberAxis42.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit53 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int55 = numberTickUnit53.compareTo((java.lang.Object) 10);
        numberAxis51.setTickUnit(numberTickUnit53);
        java.awt.Shape shape63 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke65 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint66 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape63, (java.awt.Paint) color64, stroke65, paint66);
        numberAxis51.setRightArrow(shape63);
        org.jfree.chart.axis.NumberAxis numberAxis70 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape71 = numberAxis70.getLeftArrow();
        java.awt.Paint paint72 = numberAxis70.getTickLabelPaint();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray73 = new org.jfree.chart.axis.ValueAxis[] { numberAxis31, numberAxis42, numberAxis51, numberAxis70 };
        xYPlot18.setDomainAxes(valueAxisArray73);
        int int75 = month5.compareTo((java.lang.Object) xYPlot18);
        java.util.Calendar calendar76 = null;
        try {
            long long77 = month5.getFirstMillisecond(calendar76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 0.0f + "'", float48 == 0.0f);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(shape71);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(valueAxisArray73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (short) -1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list6 = timeSeries5.getItems();
        try {
            categoryPlot0.mapDatasetToRangeAxes((-1), list6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot1.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        java.awt.Paint paint4 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint4, (java.lang.Object) basicProjectInfo5);
        xYPlot1.setRangeCrosshairPaint(paint4);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot1.getRangeAxis(10);
        boolean boolean10 = xYPlot1.canSelectByRegion();
        boolean boolean11 = verticalAlignment0.equals((java.lang.Object) boolean10);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        timeSeries1.removeAgedItems((long) (short) -1, true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 35L);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int9 = numberTickUnit7.compareTo((java.lang.Object) 10);
        java.lang.String str10 = numberTickUnit7.toString();
        java.lang.Comparable[] comparableArray11 = new java.lang.Comparable[] { month0, 2147483647, (short) -1, str10 };
        java.lang.String[] strArray13 = org.jfree.data.time.SerialDate.getMonths(false);
        double[] doubleArray16 = new double[] { 10.0d, 10.0d };
        double[] doubleArray19 = new double[] { 10.0d, 10.0d };
        double[][] doubleArray20 = new double[][] { doubleArray16, doubleArray19 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray11, (java.lang.Comparable[]) strArray13, doubleArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[size=10]" + "'", str10.equals("[size=10]"));
        org.junit.Assert.assertNotNull(comparableArray11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke0, jFreeChart1, (int) (byte) -1, 1);
        int int5 = chartProgressEvent4.getPercent();
        int int6 = chartProgressEvent4.getPercent();
        org.junit.Assert.assertNotNull(stroke0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowYOffset((double) (-1L));
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        barRenderer0.setBasePaint(paint3, false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = numberAxis1.getLeftArrow();
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape2, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        xYPlot0.setBackgroundAlpha((float) 1);
        xYPlot0.mapDatasetToDomainAxis((int) (byte) 10, 255);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D4, rectangleEdge5);
        java.awt.Font font8 = null;
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) (-1L), font8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean16 = textLine14.equals((java.lang.Object) rectangleEdge15);
        org.jfree.chart.axis.AxisState axisState17 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D1.drawTickMarks(graphics2D10, (double) 1.0f, rectangle2D12, rectangleEdge15, axisState17);
        categoryAxis3D1.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = null;
        try {
            categoryAxis3D1.setLabelInsets(rectangleInsets20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        timeSeries1.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        timeSeries1.setNotify(true);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries1.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}: ({1}, {2})");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.START" + "'", str1.equals("DateTickMarkPosition.START"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Rotation.ANTICLOCKWISE");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint14 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape10, paint14);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer16 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        boolean boolean18 = standardGradientPaintTransformer16.equals((java.lang.Object) itemLabelAnchor17);
        legendGraphic15.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer16);
        java.awt.GradientPaint gradientPaint20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int26 = numberTickUnit24.compareTo((java.lang.Object) 10);
        numberAxis22.setTickUnit(numberTickUnit24);
        float float28 = numberAxis22.getMinorTickMarkInsideLength();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity34 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis22, shape31, "hi!", "{0}: ({1}, {2})");
        numberAxis22.setVerticalTickLabels(false);
        numberAxis22.setTickMarkOutsideLength(10.0f);
        numberAxis22.setLowerBound((double) 100.0f);
        java.awt.Shape shape41 = numberAxis22.getDownArrow();
        try {
            java.awt.GradientPaint gradientPaint42 = standardGradientPaintTransformer16.transform(gradientPaint20, shape41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape41);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 100);
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot0.getDataExtractOrder();
        java.lang.String str4 = multiplePiePlot0.getPlotType();
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Multiple Pie Plot" + "'", str4.equals("Multiple Pie Plot"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer5.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = xYStepRenderer5.hasListener((java.util.EventListener) categoryPlot25);
        boolean boolean27 = xYStepRenderer5.getDrawSeriesLineAsPath();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) boolean27);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        xYPlot0.setRangeMinorGridlinesVisible(true);
        float float17 = xYPlot0.getBackgroundImageAlpha();
        java.lang.Object obj18 = null;
        boolean boolean19 = xYPlot0.equals(obj18);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 1L, (double) 100.0f, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot0.setOrientation(plotOrientation4);
        xYPlot0.setRangeMinorGridlinesVisible(false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(plotOrientation4);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        long long3 = month2.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 35L);
        timeSeries1.add(timeSeriesDataItem5, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            timeSeries1.add(regularTimePeriod8, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity14 = new org.jfree.chart.entity.JFreeChartEntity(shape6, jFreeChart11, "", "RectangleAnchor.CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'chart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font4 = textFragment3.getFont();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font4, paint5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font4, paint10);
        java.lang.Object obj15 = labelBlock14.clone();
        labelBlock14.setToolTipText("Rotation.ANTICLOCKWISE");
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        boolean boolean2 = xYPlot1.isRangeCrosshairVisible();
        java.awt.Paint paint3 = xYPlot1.getBackgroundPaint();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot1);
        int int5 = xYPlot1.getRendererCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo(entityCollection1);
        java.awt.geom.Rectangle2D rectangle2D3 = chartRenderingInfo2.getChartArea();
        chartRenderingInfo2.clear();
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo2.getChartArea();
        try {
            boolean boolean6 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(rectangle2D5);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer5.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color22, true);
        xYStepRenderer5.setBaseShapesFilled(false);
        boolean boolean29 = xYStepRenderer5.getItemVisible(2, 0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        java.lang.Object obj1 = standardPieToolTipGenerator0.clone();
        java.lang.String str2 = standardPieToolTipGenerator0.getLabelFormat();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}: ({1}, {2})" + "'", str2.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis4.setMinorTickMarksVisible(false);
        org.jfree.chart.entity.EntityCollection entityCollection7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo(entityCollection7);
        java.awt.geom.Rectangle2D rectangle2D9 = chartRenderingInfo8.getChartArea();
        chartRenderingInfo8.clear();
        java.awt.geom.Rectangle2D rectangle2D11 = chartRenderingInfo8.getChartArea();
        try {
            xYAreaRenderer0.fillDomainGridBand(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) numberAxis4, rectangle2D11, (double) (byte) -1, (double) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangle2D11);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("{0}: ({1}, {2})", "DomainOrder.ASCENDING", "DateTickMarkPosition.MIDDLE", "[size=10]");
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.data.Range range4 = rectangleConstraint3.getHeightRange();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint8 = xYStepRenderer5.lookupLegendTextPaint((int) 'a');
        xYStepRenderer5.setDefaultEntityRadius(0);
        xYStepRenderer5.setDrawOutlines(false);
        xYStepRenderer5.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYStepRenderer5.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem17 = legendItemCollection15.get((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        timeSeriesCollection1.validateObject();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (-1), (double) 1, (double) 0.0f);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer5.getSeriesItemLabelGenerator(255);
        org.jfree.chart.entity.EntityCollection entityCollection11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo(entityCollection11);
        java.awt.geom.Rectangle2D rectangle2D13 = chartRenderingInfo12.getChartArea();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis3D15.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D18, rectangleEdge19);
        java.awt.Font font22 = null;
        categoryAxis3D15.setTickLabelFont((java.lang.Comparable) (-1L), font22);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean30 = textLine28.equals((java.lang.Object) rectangleEdge29);
        org.jfree.chart.axis.AxisState axisState31 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D15.drawTickMarks(graphics2D24, (double) 1.0f, rectangle2D26, rectangleEdge29, axisState31);
        try {
            gradientBarPainter3.paintBarShadow(graphics2D4, barRenderer5, 2, 0, true, (java.awt.geom.RectangularShape) rectangle2D13, rectangleEdge29, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 1.0f, false);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(8, layer5);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat(0.0d, "Multiple Pie Plot", "DateTickMarkPosition.MIDDLE", false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperMargin();
        numberAxis1.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape6, paint13);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity18 = new org.jfree.chart.entity.AxisEntity(shape6, (org.jfree.chart.axis.Axis) categoryAxis3D15, "", "Size2D[width=0.0, height=0.0]");
        java.lang.String str19 = axisEntity18.toString();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "AxisEntity: tooltip = " + "'", str19.equals("AxisEntity: tooltip = "));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("AxisEntity: tooltip = ", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo6 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint5, (java.lang.Object) basicProjectInfo6);
        xYPlot2.setRangeCrosshairPaint(paint5);
        java.awt.Paint paint9 = xYPlot2.getRangeZeroBaselinePaint();
        paintList0.setPaint(3, paint9);
        paintList0.clear();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer5.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = xYStepRenderer5.hasListener((java.util.EventListener) categoryPlot25);
        boolean boolean27 = xYStepRenderer5.getDrawSeriesLineAsPath();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit31 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int33 = numberTickUnit31.compareTo((java.lang.Object) 10);
        numberAxis29.setTickUnit(numberTickUnit31);
        float float35 = numberAxis29.getMinorTickMarkInsideLength();
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity41 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis29, shape38, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint42 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic43 = new org.jfree.chart.title.LegendGraphic(shape38, paint42);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        legendGraphic43.setOutlineStroke(stroke44);
        xYStepRenderer5.setBaseStroke(stroke44);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection1 = xYAreaRenderer0.getAnnotations();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer0.setSeriesStroke(0, stroke3, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean8 = xYAreaRenderer7.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font13 = textFragment12.getFont();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine15 = new org.jfree.chart.text.TextLine("", font13, paint14);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot16.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        java.awt.Paint paint19 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo20 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint19, (java.lang.Object) basicProjectInfo20);
        xYPlot16.setRangeCrosshairPaint(paint19);
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font13, paint19);
        xYAreaRenderer7.setBaseItemLabelPaint(paint19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = xYAreaRenderer7.getPositiveItemLabelPosition(15, (int) ' ', true);
        java.lang.Object obj29 = null;
        boolean boolean30 = itemLabelPosition28.equals(obj29);
        try {
            xYAreaRenderer0.setSeriesPositiveItemLabelPosition((int) (short) -1, itemLabelPosition28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        numberAxis15.setAutoRange(false);
        org.jfree.data.Range range23 = null;
        try {
            numberAxis15.setDefaultAutoRange(range23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double4 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        java.lang.String str11 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) regularTimePeriod10);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        try {
            java.text.AttributedString attributedString14 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset12, (java.lang.Comparable) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list2 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list5 = timeSeries4.getItems();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double8 = timeSeries7.getMinY();
        timeSeries7.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month11);
        org.jfree.data.time.Year year13 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        timeSeries4.add(regularTimePeriod14, (double) 2958465);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod14, 0.0d);
        timeSeries1.add(timeSeriesDataItem18, true);
        boolean boolean21 = timeSeriesDataItem18.isSelected();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 3;
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_ITEM_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "item" + "'", str0.equals("item"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        java.lang.Object obj1 = null;
        boolean boolean2 = timePeriodAnchor0.equals(obj1);
        java.lang.String str3 = timePeriodAnchor0.toString();
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TimePeriodAnchor.MIDDLE" + "'", str3.equals("TimePeriodAnchor.MIDDLE"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            piePlot1.setSimpleLabelOffset(rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setTickMarkOutsideLength(10.0f);
        numberAxis1.setLowerBound((double) 100.0f);
        numberAxis1.setAutoRangeMinimumSize((double) 10, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer5.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = xYStepRenderer5.hasListener((java.util.EventListener) categoryPlot25);
        boolean boolean27 = xYStepRenderer5.getDrawSeriesLineAsPath();
        double double28 = xYStepRenderer5.getStepPoint();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) (short) 10);
        java.util.Date date6 = null;
        try {
            long long7 = segmentedTimeline3.getTime(date6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        timeSeriesCollection1.validateObject();
        try {
            int int9 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) timeSeriesCollection1, 11, (double) ' ', (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (11).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double3 = timeSeries2.getMinY();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double8 = timeSeries7.getMinY();
        timeSeries7.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month11);
        org.jfree.data.time.Year year13 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 255, true);
        java.lang.Class class18 = timeSeries2.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double21 = timeSeries20.getMinY();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) month22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double26 = timeSeries25.getMinY();
        timeSeries25.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        int int30 = timeSeries25.getIndex((org.jfree.data.time.RegularTimePeriod) month29);
        org.jfree.data.time.Year year31 = month29.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.previous();
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 255, true);
        java.lang.Class class36 = timeSeries20.getTimePeriodClass();
        java.lang.Object obj37 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("[size=10]", class18, class36);
        boolean boolean38 = org.jfree.chart.util.SerialUtilities.isSerializable(class36);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertNull(obj37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(255, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection1.getSeries((java.lang.Comparable) 100.0f);
        try {
            boolean boolean9 = timeSeriesCollection1.isSelected(1, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeries6);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        int int15 = xYPlot0.getRendererCount();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 4, (float) '4', (float) 5);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("AxisLabelEntity: label = hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key AxisLabelEntity: label = hi!");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets17.createInsetRectangle(rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("");
        textLine1.removeFragment(textFragment3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        try {
            textFragment3.draw(graphics2D5, 0.0f, (float) (-1L), textAnchor8, (float) 5, (float) (byte) 0, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean7 = categoryPlot6.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot6.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo10, point2D11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo17 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint16, (java.lang.Object) basicProjectInfo17);
        xYPlot13.setRangeCrosshairPaint(paint16);
        java.awt.Paint paint20 = xYPlot13.getRangeZeroBaselinePaint();
        xYPlot13.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = xYPlot13.getAxisOffset();
        categoryPlot6.setAxisOffset(rectangleInsets23);
        categoryPlot6.setRangeMinorGridlinesVisible(false);
        java.awt.Stroke stroke27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.JFreeChart jFreeChart28 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent31 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke27, jFreeChart28, (int) (byte) -1, 1);
        categoryPlot6.setDomainGridlineStroke(stroke27);
        try {
            barRenderer0.setSeriesOutlineStroke((int) (byte) -1, stroke27, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape8 = numberAxis1.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot9.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint12, (java.lang.Object) basicProjectInfo13);
        xYPlot9.setRangeCrosshairPaint(paint12);
        java.awt.Paint paint16 = xYPlot9.getRangeCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) xYPlot9, "{0}: ({1}, {2})");
        boolean boolean19 = xYPlot9.isRangeCrosshairVisible();
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint23 = textTitle22.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean25 = categoryPlot24.isDomainGridlinesVisible();
        java.awt.Stroke stroke26 = categoryPlot24.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 2, paint23, stroke26);
        java.awt.Font font28 = valueMarker27.getLabelFont();
        org.jfree.chart.util.Layer layer29 = null;
        try {
            xYPlot9.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker27, layer29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color3);
        int int5 = color3.getBlue();
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color3.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        java.awt.color.ColorSpace colorSpace12 = color3.getColorSpace();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 128 + "'", int5 == 128);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertNotNull(colorSpace12);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = xYPlot0.getAxisOffset();
        xYPlot0.setRangeMinorGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        try {
            xYPlot0.setRangeAxisLocation((int) (byte) 0, axisLocation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        int int2 = crosshairState1.getRangeAxisIndex();
        int int3 = crosshairState1.getDomainAxisIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo(entityCollection1);
        java.awt.geom.Rectangle2D rectangle2D3 = chartRenderingInfo2.getChartArea();
        try {
            boolean boolean4 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        try {
            boolean boolean6 = segmentedTimeline3.containsDomainRange((long) 7, (long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: domainValueEnd (5) < domainValueStart (7)");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        xYPlot0.clearRangeMarkers(100);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        xYPlot0.datasetChanged(datasetChangeEvent9);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot1.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot1.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot1.setOrientation(plotOrientation5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list11 = timeSeries10.getItems();
        xYPlot1.drawRangeTickBands(graphics2D7, rectangle2D8, list11);
        projectInfo0.setContributors(list11);
        java.lang.String str14 = projectInfo0.getLicenceText();
        java.lang.String str15 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Paint paint2 = xYPlot0.getBackgroundPaint();
        xYPlot0.setRangeCrosshairValue(0.0d, true);
        boolean boolean6 = xYPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape10 = numberAxis9.getLeftArrow();
        java.awt.Paint paint11 = numberAxis9.getTickLabelPaint();
        xYPlot0.setDomainAxis(2, (org.jfree.chart.axis.ValueAxis) numberAxis9, false);
        numberAxis9.setPositiveArrowVisible(false);
        numberAxis9.setMinorTickMarkOutsideLength((float) 35L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.plot.CrosshairState crosshairState14 = null;
        boolean boolean15 = xYPlot0.render(graphics2D10, rectangle2D11, (int) (byte) 1, plotRenderingInfo13, crosshairState14);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int22 = numberTickUnit20.compareTo((java.lang.Object) 10);
        numberAxis18.setTickUnit(numberTickUnit20);
        xYPlot0.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis18, false);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot27.setLimit((double) 100);
        org.jfree.chart.entity.EntityCollection entityCollection30 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = new org.jfree.chart.ChartRenderingInfo(entityCollection30);
        java.awt.geom.Rectangle2D rectangle2D32 = chartRenderingInfo31.getChartArea();
        chartRenderingInfo31.clear();
        java.awt.geom.Rectangle2D rectangle2D34 = chartRenderingInfo31.getChartArea();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis3D36.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D39, rectangleEdge40);
        java.awt.Font font43 = null;
        categoryAxis3D36.setTickLabelFont((java.lang.Comparable) (-1L), font43);
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.text.TextLine textLine49 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean51 = textLine49.equals((java.lang.Object) rectangleEdge50);
        org.jfree.chart.axis.AxisState axisState52 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D36.drawTickMarks(graphics2D45, (double) 1.0f, rectangle2D47, rectangleEdge50, axisState52);
        org.jfree.chart.axis.AxisSpace axisSpace54 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace55 = numberAxis18.reserveSpace(graphics2D26, (org.jfree.chart.plot.Plot) multiplePiePlot27, rectangle2D34, rectangleEdge50, axisSpace54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        int int7 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            boolean boolean12 = categoryPlot0.removeAnnotation(categoryAnnotation10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection1 = xYAreaRenderer0.getAnnotations();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer0.setSeriesStroke(0, stroke3, true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        xYAreaRenderer0.setSeriesURLGenerator(10, xYURLGenerator7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot11.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        java.awt.Paint paint14 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint14, (java.lang.Object) basicProjectInfo15);
        xYPlot11.setRangeCrosshairPaint(paint14);
        java.awt.Paint paint18 = xYPlot11.getRangeZeroBaselinePaint();
        xYPlot11.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot11.zoomRangeAxes(Double.NaN, plotRenderingInfo22, point2D23, true);
        xYPlot11.setRangeMinorGridlinesVisible(true);
        java.awt.Font font28 = xYPlot11.getNoDataMessageFont();
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = xYPlot11.getRangeMarkers(layer29);
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection32 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot31.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection32);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener34 = null;
        timeSeriesCollection32.addChangeListener(datasetChangeListener34);
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeriesCollection32.getSeries((java.lang.Comparable) 100L);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState39 = xYAreaRenderer0.initialise(graphics2D9, rectangle2D10, xYPlot11, (org.jfree.data.xy.XYDataset) timeSeriesCollection32, plotRenderingInfo38);
        java.util.List list40 = null;
        org.jfree.data.Range range41 = null;
        try {
            org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection32, list40, range41, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNull(timeSeries37);
        org.junit.Assert.assertNotNull(xYItemRendererState39);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 100, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent3.getType();
        org.junit.Assert.assertNull(chartChangeEventType4);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        org.junit.Assert.assertNull(plot1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.entity.EntityCollection entityCollection5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo(entityCollection5);
        java.awt.geom.Rectangle2D rectangle2D7 = chartRenderingInfo6.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo(entityCollection8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = chartRenderingInfo9.getPlotInfo();
        try {
            jFreeChart3.draw(graphics2D4, rectangle2D7, chartRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(plotRenderingInfo10);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        timeSeries1.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.Year year7 = month5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        long long9 = year7.getLastMillisecond();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int7 = numberTickUnit5.compareTo((java.lang.Object) 10);
        numberAxis3.setTickUnit(numberTickUnit5);
        float float9 = numberAxis3.getMinorTickMarkInsideLength();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity15 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis3, shape12, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape12, paint16);
        boolean boolean18 = textTitle1.equals((java.lang.Object) paint16);
        boolean boolean19 = textTitle1.visible;
        textTitle1.setExpandToFitSpace(false);
        java.lang.Object obj22 = textTitle1.clone();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItemCollection2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        try {
            org.jfree.chart.title.Title title5 = jFreeChart3.getSubtitle(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItemCollection2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        double double2 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection1.getSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection1.getDomainOrder();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot8.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot8.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot8.setOrientation(plotOrientation12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list18 = timeSeries17.getItems();
        xYPlot8.drawRangeTickBands(graphics2D14, rectangle2D15, list18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list18, true);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double24 = timeSeries23.getMinY();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double29 = timeSeries28.getMinY();
        timeSeries28.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        int int33 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.Year year34 = month32.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 255, true);
        java.lang.Class class39 = timeSeries23.getTimePeriodClass();
        timeSeriesCollection1.removeSeries(timeSeries23);
        try {
            java.lang.Number number43 = timeSeriesCollection1.getEndX((int) (short) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeries6);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(class39);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint3 = textTitle2.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isDomainGridlinesVisible();
        java.awt.Stroke stroke6 = categoryPlot4.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 2, paint3, stroke6);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = null;
        try {
            valueMarker7.setLabelOffsetType(lengthAdjustmentType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.lang.Object obj2 = chartRenderingInfo1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) true, true);
        barRenderer0.setAutoPopulateSeriesPaint(false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot7.setLimit((double) 100);
        org.jfree.chart.util.TableOrder tableOrder10 = multiplePiePlot7.getDataExtractOrder();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection12 = xYAreaRenderer11.getAnnotations();
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYAreaRenderer11);
        boolean boolean14 = multiplePiePlot7.equals((java.lang.Object) xYAreaRenderer11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYAreaRenderer11.getSeriesPositiveItemLabelPosition((int) (short) 10);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition16);
        org.junit.Assert.assertNotNull(tableOrder10);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double7 = timeSeries6.getMinY();
        timeSeries6.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 255, true);
        java.lang.Comparable comparable17 = timeSeries1.getKey();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (-1) + "'", comparable17.equals((-1)));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("RectangleAnchor.CENTER", "RectangleAnchor.CENTER", "[size=10]", "ItemLabelAnchor.INSIDE11");
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.entity.EntityCollection entityCollection7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo(entityCollection7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = chartRenderingInfo8.getPlotInfo();
        try {
            java.awt.image.BufferedImage bufferedImage10 = jFreeChart3.createBufferedImage((int) (byte) 1, 0, (-1), chartRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(plotRenderingInfo9);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection1.getSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection1.getDomainOrder();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot8.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot8.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot8.setOrientation(plotOrientation12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list18 = timeSeries17.getItems();
        xYPlot8.drawRangeTickBands(graphics2D14, rectangle2D15, list18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list18, true);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double24 = timeSeries23.getMinY();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double29 = timeSeries28.getMinY();
        timeSeries28.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        int int33 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.Year year34 = month32.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 255, true);
        java.lang.Class class39 = timeSeries23.getTimePeriodClass();
        timeSeriesCollection1.removeSeries(timeSeries23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries23.addOrUpdate(regularTimePeriod41, (java.lang.Number) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeries6);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(class39);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = rendererState1.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.data.Range range4 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint3.toRangeHeight(range4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Shape shape0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.pan(0.0d);
        numberAxis2.resizeRange((double) 4, (double) 100.0f);
        try {
            org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) numberAxis2, "AxisEntity: tooltip = ", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtLeft();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        xYPlot0.setFixedLegendItems(legendItemCollection1);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint6 = textTitle5.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean8 = categoryPlot7.isDomainGridlinesVisible();
        java.awt.Stroke stroke9 = categoryPlot7.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 2, paint6, stroke9);
        org.jfree.chart.util.Layer layer11 = null;
        try {
            xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setSimpleLabels(true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        boolean boolean3 = xYPlot2.isRangeCrosshairVisible();
        boolean boolean4 = xYAreaRenderer0.hasListener((java.util.EventListener) xYPlot2);
        java.lang.Object obj5 = xYAreaRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.plot.Plot plot3 = waferMapPlot2.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent(plot3);
        org.jfree.chart.plot.Plot plot5 = plotChangeEvent4.getPlot();
        org.junit.Assert.assertNotNull(plot3);
        org.junit.Assert.assertNotNull(plot5);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("");
        textLine1.removeFragment(textFragment3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape7 = numberAxis6.getLeftArrow();
        java.awt.Paint paint8 = numberAxis6.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis6.getStandardTickUnits();
        boolean boolean10 = textLine1.equals((java.lang.Object) numberAxis6);
        java.lang.Object obj11 = numberAxis6.clone();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setDomainCrosshairRowKey((java.lang.Comparable) 1.0f, false);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint8 = textTitle7.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean10 = categoryPlot9.isDomainGridlinesVisible();
        java.awt.Stroke stroke11 = categoryPlot9.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 2, paint8, stroke11);
        categoryPlot1.setRangeCrosshairStroke(stroke11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis3D15.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D18, rectangleEdge19);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D22.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis3D25.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D28, rectangleEdge29);
        java.awt.Paint paint32 = null;
        categoryAxis3D25.setTickLabelPaint((java.lang.Comparable) 1.0d, paint32);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D35.setMaximumCategoryLabelLines(10);
        categoryAxis3D35.removeCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = categoryAxis3D41.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D44, rectangleEdge45);
        java.awt.Paint paint48 = null;
        categoryAxis3D41.setTickLabelPaint((java.lang.Comparable) 1.0d, paint48);
        java.awt.Font font51 = categoryAxis3D41.getTickLabelFont((java.lang.Comparable) 100L);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D53 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray54 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D15, categoryAxis3D22, categoryAxis3D25, categoryAxis3D35, categoryAxis3D41, categoryAxis3D53 };
        categoryPlot1.setDomainAxes(categoryAxisArray54);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis58.pan(0.0d);
        categoryPlot1.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis58);
        boolean boolean62 = textBlockAnchor0.equals((java.lang.Object) 1);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(categoryAxisArray54);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        java.awt.RenderingHints renderingHints4 = null;
        try {
            jFreeChart3.setRenderingHints(renderingHints4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItemCollection2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getIgnoreNullValues();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = piePlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieURLGenerator3);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = plotRenderingInfo2.getSubplotInfo(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("TimePeriodAnchor.MIDDLE", "Value", "Value", "DateTickMarkPosition.START", "Rotation.ANTICLOCKWISE");
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        xYPlot0.setDomainMinorGridlinesVisible(false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CrosshairState crosshairState14 = new org.jfree.chart.plot.CrosshairState(false);
        boolean boolean15 = xYPlot0.render(graphics2D9, rectangle2D10, (int) (short) 0, plotRenderingInfo12, crosshairState14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation(axisLocation16);
        java.awt.Paint paint18 = xYPlot0.getRangeMinorGridlinePaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        boolean boolean6 = barRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer7 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor8 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        boolean boolean9 = standardGradientPaintTransformer7.equals((java.lang.Object) itemLabelAnchor8);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType10 = standardGradientPaintTransformer7.getType();
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer7);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot13.setOrientation(plotOrientation17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list23 = timeSeries22.getItems();
        xYPlot13.drawRangeTickBands(graphics2D19, rectangle2D20, list23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        java.awt.geom.Rectangle2D rectangle2D28 = chartRenderingInfo27.getChartArea();
        chartRenderingInfo27.clear();
        java.awt.geom.Rectangle2D rectangle2D30 = chartRenderingInfo27.getChartArea();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list33 = timeSeries32.getItems();
        xYPlot13.drawRangeTickBands(graphics2D25, rectangle2D30, list33);
        java.text.DateFormat dateFormat36 = null;
        java.text.DateFormat dateFormat37 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator38 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat36, dateFormat37);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator39 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer40 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator38, xYURLGenerator39);
        java.awt.Font font44 = xYStepRenderer40.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        boolean boolean47 = xYPlot46.isRangeCrosshairVisible();
        java.awt.Paint paint48 = xYPlot46.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis50.pan(0.0d);
        org.jfree.chart.plot.Marker marker53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        xYStepRenderer40.drawRangeMarker(graphics2D45, xYPlot46, (org.jfree.chart.axis.ValueAxis) numberAxis50, marker53, rectangle2D54);
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer40.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color57, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean61 = xYStepRenderer40.hasListener((java.util.EventListener) categoryPlot60);
        org.jfree.chart.axis.AxisSpace axisSpace62 = null;
        categoryPlot60.setFixedDomainAxisSpace(axisSpace62);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState66 = barRenderer0.initialise(graphics2D12, rectangle2D30, categoryPlot60, (int) (byte) -1, plotRenderingInfo65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType10);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            timeSeriesCollection0.setSelected((int) (short) 1, 1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double4 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        java.lang.String str11 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) regularTimePeriod10);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        long long14 = month13.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) 35L);
        org.jfree.data.time.Year year17 = month13.getYear();
        java.lang.String str18 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset12, (java.lang.Comparable) year17);
        java.lang.String str19 = year17.toString();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.entity.EntityCollection entityCollection18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo(entityCollection18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = chartRenderingInfo19.getPlotInfo();
        org.jfree.chart.plot.CrosshairState crosshairState22 = new org.jfree.chart.plot.CrosshairState(false);
        int int23 = crosshairState22.getRangeAxisIndex();
        boolean boolean24 = xYPlot0.render(graphics2D15, rectangle2D16, 3, plotRenderingInfo20, crosshairState22);
        org.jfree.chart.ui.ProjectInfo projectInfo26 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection28 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot27.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot27.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot27.setOrientation(plotOrientation31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list37 = timeSeries36.getItems();
        xYPlot27.drawRangeTickBands(graphics2D33, rectangle2D34, list37);
        projectInfo26.setContributors(list37);
        try {
            xYPlot0.mapDatasetToRangeAxes((int) 'a', list37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(plotRenderingInfo20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(list37);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setTickMarkOutsideLength(10.0f);
        org.jfree.data.Range range18 = null;
        try {
            numberAxis1.setRangeWithMargins(range18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (-1), (double) 1, (double) 0.0f);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer5.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        barRenderer5.setNegativeItemLabelPositionFallback(itemLabelPosition8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        barRenderer5.setSeriesURLGenerator(0, categoryURLGenerator11);
        java.text.DateFormat dateFormat14 = null;
        java.text.DateFormat dateFormat15 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator16 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat14, dateFormat15);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset17 = new org.jfree.data.xy.DefaultXYDataset();
        boolean boolean18 = standardXYToolTipGenerator16.equals((java.lang.Object) defaultXYDataset17);
        boolean boolean19 = barRenderer5.equals((java.lang.Object) standardXYToolTipGenerator16);
        org.jfree.chart.entity.EntityCollection entityCollection23 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo(entityCollection23);
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo24.getChartArea();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection31 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot30.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot30.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot30.setOrientation(plotOrientation34);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list40 = timeSeries39.getItems();
        xYPlot30.drawRangeTickBands(graphics2D36, rectangle2D37, list40);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        java.awt.geom.Rectangle2D rectangle2D45 = chartRenderingInfo44.getChartArea();
        chartRenderingInfo44.clear();
        java.awt.geom.Rectangle2D rectangle2D47 = chartRenderingInfo44.getChartArea();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list50 = timeSeries49.getItems();
        xYPlot30.drawRangeTickBands(graphics2D42, rectangle2D47, list50);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double53 = categoryAxis26.getCategoryJava2DCoordinate(categoryAnchor27, 7, (int) (short) 1, rectangle2D47, rectangleEdge52);
        try {
            gradientBarPainter3.paintBarShadow(graphics2D4, barRenderer5, (int) (short) 1, 7, true, (java.awt.geom.RectangularShape) rectangle2D25, rectangleEdge52, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(plotOrientation34);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(list50);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer(5, xYToolTipGenerator1, xYURLGenerator2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection1.getSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection1.getDomainOrder();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot8.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot8.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot8.setOrientation(plotOrientation12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list18 = timeSeries17.getItems();
        xYPlot8.drawRangeTickBands(graphics2D14, rectangle2D15, list18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list18, true);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double24 = timeSeries23.getMinY();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double29 = timeSeries28.getMinY();
        timeSeries28.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        int int33 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.Year year34 = month32.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 255, true);
        java.lang.Class class39 = timeSeries23.getTimePeriodClass();
        timeSeriesCollection1.removeSeries(timeSeries23);
        try {
            java.lang.Number number43 = timeSeriesCollection1.getEndY(1, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeries6);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(class39);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        xYPlot0.setWeight((-1));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.text.DateFormat dateFormat1 = null;
        org.jfree.chart.util.LogFormat logFormat2 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("2019", dateFormat1, (java.text.NumberFormat) logFormat2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer5.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = xYStepRenderer5.hasListener((java.util.EventListener) categoryPlot25);
        boolean boolean27 = xYStepRenderer5.getDrawSeriesLineAsPath();
        xYStepRenderer5.setAutoPopulateSeriesFillPaint(false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator30 = null;
        try {
            xYStepRenderer5.setLegendItemLabelGenerator(xYSeriesLabelGenerator30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot1.getLabelPadding();
        int int4 = piePlot1.getPieIndex();
        java.awt.Stroke stroke5 = piePlot1.getLabelOutlineStroke();
        double double6 = piePlot1.getLabelGap();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        try {
            xYSeries3.updateByIndex(5, (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((double) 11);
        axisState0.cursorDown((double) (-1L));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double7 = timeSeries6.getMinY();
        timeSeries6.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 255, true);
        java.lang.String str17 = timeSeries1.getRangeDescription();
        int int18 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(xYBarPainter0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DomainOrder.ASCENDING");
        try {
            dateAxis1.setRange((double) 15, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot5.getLabelPadding();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot5.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator8);
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int17 = numberTickUnit15.compareTo((java.lang.Object) 10);
        numberAxis13.setTickUnit(numberTickUnit15);
        org.jfree.chart.entity.EntityCollection entityCollection20 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo(entityCollection20);
        java.awt.geom.Rectangle2D rectangle2D22 = chartRenderingInfo21.getChartArea();
        chartRenderingInfo21.clear();
        java.awt.geom.Rectangle2D rectangle2D24 = chartRenderingInfo21.getChartArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double26 = numberAxis13.java2DToValue(1.0E-8d, rectangle2D24, rectangleEdge25);
        java.awt.geom.Point2D point2D27 = null;
        org.jfree.chart.plot.PlotState plotState28 = null;
        org.jfree.chart.entity.EntityCollection entityCollection29 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo(entityCollection29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = chartRenderingInfo30.getPlotInfo();
        try {
            piePlot1.draw(graphics2D11, rectangle2D24, point2D27, plotState28, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 90.0d + "'", double6 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.POSITIVE_INFINITY + "'", double26 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(plotRenderingInfo31);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D4, rectangleEdge5);
        java.awt.Font font8 = null;
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) (-1L), font8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean16 = textLine14.equals((java.lang.Object) rectangleEdge15);
        org.jfree.chart.axis.AxisState axisState17 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D1.drawTickMarks(graphics2D10, (double) 1.0f, rectangle2D12, rectangleEdge15, axisState17);
        boolean boolean19 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge15);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list22 = timeSeries21.getItems();
        boolean boolean23 = rectangleEdge15.equals((java.lang.Object) timeSeries21);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 35L);
        java.lang.String str4 = month0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        java.awt.Paint paint3 = categoryPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape8 = numberAxis1.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot9.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint12, (java.lang.Object) basicProjectInfo13);
        xYPlot9.setRangeCrosshairPaint(paint12);
        java.awt.Paint paint16 = xYPlot9.getRangeCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) xYPlot9, "{0}: ({1}, {2})");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.lang.String str21 = textTitle20.getToolTipText();
        org.jfree.chart.entity.TitleEntity titleEntity22 = new org.jfree.chart.entity.TitleEntity(shape8, (org.jfree.chart.title.Title) textTitle20);
        textTitle20.visible = false;
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 1.0f, false);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint7 = textTitle6.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.isDomainGridlinesVisible();
        java.awt.Stroke stroke10 = categoryPlot8.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 2, paint7, stroke10);
        categoryPlot0.setRangeCrosshairStroke(stroke10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis3D14.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D17, rectangleEdge18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D21.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = categoryAxis3D24.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D27, rectangleEdge28);
        java.awt.Paint paint31 = null;
        categoryAxis3D24.setTickLabelPaint((java.lang.Comparable) 1.0d, paint31);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D34.setMaximumCategoryLabelLines(10);
        categoryAxis3D34.removeCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = categoryAxis3D40.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D43, rectangleEdge44);
        java.awt.Paint paint47 = null;
        categoryAxis3D40.setTickLabelPaint((java.lang.Comparable) 1.0d, paint47);
        java.awt.Font font50 = categoryAxis3D40.getTickLabelFont((java.lang.Comparable) 100L);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray53 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D14, categoryAxis3D21, categoryAxis3D24, categoryAxis3D34, categoryAxis3D40, categoryAxis3D52 };
        categoryPlot0.setDomainAxes(categoryAxisArray53);
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis57.pan(0.0d);
        categoryPlot0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis57);
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = numberAxis57.getLabelInsets();
        java.awt.Paint paint62 = numberAxis57.getLabelPaint();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(categoryAxisArray53);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertNotNull(paint62);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Last");
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font4 = textFragment3.getFont();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font4, paint5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font4, paint10);
        labelBlock14.setToolTipText("DateTickMarkPosition.MIDDLE");
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.SortOrder sortOrder2 = null;
        try {
            categoryPlot0.setColumnRenderingOrder(sortOrder2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        boolean boolean3 = xYPlot2.isRangeCrosshairVisible();
        boolean boolean4 = xYAreaRenderer0.hasListener((java.util.EventListener) xYPlot2);
        xYAreaRenderer0.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        categoryPlot0.clearRangeMarkers((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        categoryPlot0.setRangeAxisLocation(255, axisLocation22);
        java.awt.Stroke stroke24 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection27 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot26.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection27);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener29 = null;
        timeSeriesCollection27.addChangeListener(datasetChangeListener29);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeriesCollection27.getSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.DomainOrder domainOrder33 = timeSeriesCollection27.getDomainOrder();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection35 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot34.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot34.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation38 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot34.setOrientation(plotOrientation38);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list44 = timeSeries43.getItems();
        xYPlot34.drawRangeTickBands(graphics2D40, rectangle2D41, list44);
        org.jfree.data.Range range47 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection27, list44, true);
        try {
            categoryPlot0.mapDatasetToDomainAxes((-1), list44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(timeSeries32);
        org.junit.Assert.assertNotNull(domainOrder33);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(plotOrientation38);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertNull(range47);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape10, (java.awt.Paint) color11, stroke12, paint13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot15.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot15.setRangeZeroBaselinePaint((java.awt.Paint) color18);
        int int20 = color18.getBlue();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        long long25 = month24.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 35L);
        timeSeries23.add(timeSeriesDataItem27, true);
        java.awt.Color color30 = java.awt.Color.ORANGE;
        boolean boolean31 = timeSeriesDataItem27.equals((java.lang.Object) color30);
        try {
            org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem(attributedString0, "TitleEntity: tooltip = null", "", "AxisEntity: tooltip = ", shape10, (java.awt.Paint) color18, stroke21, (java.awt.Paint) color30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 128 + "'", int20 == 128);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.isInverted();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection(xYSeries9);
        try {
            java.lang.String str13 = standardXYToolTipGenerator3.generateToolTip((org.jfree.data.xy.XYDataset) xYSeriesCollection10, 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        xYPlot11.datasetChanged(datasetChangeEvent21);
        java.awt.geom.GeneralPath generalPath23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.RenderingSource renderingSource25 = null;
        xYPlot11.select(generalPath23, rectangle2D24, renderingSource25);
        java.awt.Paint paint27 = xYPlot11.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = xYStepRenderer5.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(xYToolTipGenerator7);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.awt.Color color0 = java.awt.Color.blue;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str1.equals("RectangleAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("[size=10]", timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangePannable();
        int int2 = categoryPlot0.getCrosshairDatasetIndex();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 100);
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection5 = xYAreaRenderer4.getAnnotations();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYAreaRenderer4);
        boolean boolean7 = multiplePiePlot0.equals((java.lang.Object) xYAreaRenderer4);
        boolean boolean8 = xYAreaRenderer4.getUseFillPaint();
        boolean boolean9 = xYAreaRenderer4.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) 1, 3);
        try {
            long long5 = segmentedTimeline3.toTimelineValue((long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "TimePeriodAnchor.MIDDLE", "ThreadContext", "Last", "");
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font3 = textFragment2.getFont();
        java.awt.Paint paint4 = textFragment2.getPaint();
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot6 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset5);
        waferMapPlot6.setNoDataMessage("hi!");
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        waferMapPlot6.setOutlineStroke(stroke9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke12 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 1577865599999L, paint4, stroke9, (java.awt.Paint) color11, stroke12, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.entity.EntityCollection entityCollection18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo(entityCollection18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = chartRenderingInfo19.getPlotInfo();
        org.jfree.chart.plot.CrosshairState crosshairState22 = new org.jfree.chart.plot.CrosshairState(false);
        int int23 = crosshairState22.getRangeAxisIndex();
        boolean boolean24 = xYPlot0.render(graphics2D15, rectangle2D16, 3, plotRenderingInfo20, crosshairState22);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = plotRenderingInfo20.getSubplotInfo(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(plotRenderingInfo20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        try {
            java.lang.Number number5 = defaultXYDataset0.getY((-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape10, (java.awt.Paint) color11, stroke12, paint13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        boolean boolean16 = xYPlot15.isRangeCrosshairVisible();
        java.awt.Paint paint17 = xYPlot15.getBackgroundPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape10, paint17);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity22 = new org.jfree.chart.entity.AxisEntity(shape10, (org.jfree.chart.axis.Axis) categoryAxis3D19, "", "Size2D[width=0.0, height=0.0]");
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer24 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean25 = xYAreaRenderer24.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font30 = textFragment29.getFont();
        java.awt.Paint paint31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine("", font30, paint31);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection34 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot33.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection34);
        java.awt.Paint paint36 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo37 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint36, (java.lang.Object) basicProjectInfo37);
        xYPlot33.setRangeCrosshairPaint(paint36);
        org.jfree.chart.block.LabelBlock labelBlock40 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font30, paint36);
        xYAreaRenderer24.setBaseItemLabelPaint(paint36);
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("AxisLabelEntity: label = hi!", "Rotation.ANTICLOCKWISE", "RectangleAnchor.CENTER", "Rotation.ANTICLOCKWISE", shape10, stroke23, paint36);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer43 = legendItem42.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer43);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot1.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener4 = null;
        timeSeriesCollection2.addChangeListener(datasetChangeListener4);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeriesCollection2.getSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.DomainOrder domainOrder8 = timeSeriesCollection2.getDomainOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis3D10.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D13, rectangleEdge14);
        java.awt.Paint paint17 = null;
        categoryAxis3D10.setTickLabelPaint((java.lang.Comparable) 1.0d, paint17);
        java.awt.Font font20 = categoryAxis3D10.getTickLabelFont((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) categoryAxis3D10, seriesChangeInfo21);
        timeSeriesCollection2.seriesChanged(seriesChangeEvent22);
        timeSeriesCollection0.seriesChanged(seriesChangeEvent22);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer28 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection29 = xYAreaRenderer28.getAnnotations();
        java.awt.Stroke stroke31 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer28.setSeriesStroke(0, stroke31, true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator35 = null;
        xYAreaRenderer28.setSeriesURLGenerator(10, xYURLGenerator35);
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis26, valueAxis27, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot38 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot38.setLimit((double) 100);
        org.jfree.chart.util.TableOrder tableOrder41 = multiplePiePlot38.getDataExtractOrder();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer42 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection43 = xYAreaRenderer42.getAnnotations();
        java.lang.Object obj44 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYAreaRenderer42);
        boolean boolean45 = multiplePiePlot38.equals((java.lang.Object) xYAreaRenderer42);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = xYAreaRenderer42.getSeriesPositiveItemLabelPosition((int) (short) 10);
        xYAreaRenderer28.setBaseNegativeItemLabelPosition(itemLabelPosition47);
        org.junit.Assert.assertNull(timeSeries7);
        org.junit.Assert.assertNotNull(domainOrder8);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(tableOrder41);
        org.junit.Assert.assertNotNull(collection43);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Stroke stroke7 = xYStepRenderer5.lookupSeriesStroke((int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        xYStepRenderer5.setSeriesNegativeItemLabelPosition(3, itemLabelPosition9);
        xYStepRenderer5.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.LegendItem legendItem15 = xYStepRenderer5.getLegendItem(128, (int) (byte) 1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(legendItem15);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection1 = xYAreaRenderer0.getAnnotations();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer0.setSeriesStroke(0, stroke3, true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        boolean boolean7 = xYPlot6.isRangeCrosshairVisible();
        java.awt.Paint paint8 = xYPlot6.getBackgroundPaint();
        xYAreaRenderer0.setBaseOutlinePaint(paint8, false);
        java.awt.Shape shape11 = xYAreaRenderer0.getLegendArea();
        java.awt.Stroke stroke13 = null;
        xYAreaRenderer0.setSeriesOutlineStroke(2, stroke13, true);
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot0.setOrientation(plotOrientation4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list10 = timeSeries9.getItems();
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        java.awt.geom.Rectangle2D rectangle2D15 = chartRenderingInfo14.getChartArea();
        chartRenderingInfo14.clear();
        java.awt.geom.Rectangle2D rectangle2D17 = chartRenderingInfo14.getChartArea();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list20 = timeSeries19.getItems();
        xYPlot0.drawRangeTickBands(graphics2D12, rectangle2D17, list20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace22);
        xYPlot0.setRangeCrosshairValue(4.0d);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("JFreeChartEntity: tooltip = null", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D4, rectangleEdge5);
        java.awt.Paint paint8 = null;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) 1.0d, paint8);
        java.awt.Font font11 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) 100L);
        categoryAxis3D1.removeCategoryLabelToolTip((java.lang.Comparable) "[size=10]");
        org.jfree.data.xy.XYDataItem xYDataItem16 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 5, (java.lang.Number) 1);
        xYDataItem16.setSelected(false);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) xYDataItem16, "Value");
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot21.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection22);
        java.awt.Paint paint24 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo25 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean26 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint24, (java.lang.Object) basicProjectInfo25);
        xYPlot21.setRangeCrosshairPaint(paint24);
        java.awt.Paint paint28 = xYPlot21.getRangeZeroBaselinePaint();
        xYPlot21.setDomainPannable(true);
        java.awt.Stroke stroke31 = xYPlot21.getDomainZeroBaselineStroke();
        boolean boolean32 = categoryAxis3D1.hasListener((java.util.EventListener) xYPlot21);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        int int7 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            categoryPlot0.addDomainMarker((int) (byte) 10, categoryMarker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 0, range1);
        double double3 = rectangleConstraint2.getHeight();
        org.jfree.data.Range range4 = rectangleConstraint2.getWidthRange();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int3 = numberTickUnit1.compareTo((java.lang.Object) 10);
        java.lang.String str4 = numberTickUnit1.toString();
        double double5 = numberTickUnit1.getSize();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[size=10]" + "'", str4.equals("[size=10]"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 100);
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        java.awt.geom.Rectangle2D rectangle2D11 = chartRenderingInfo10.getChartArea();
        chartRenderingInfo10.clear();
        java.awt.geom.Rectangle2D rectangle2D13 = chartRenderingInfo10.getChartArea();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int20 = numberTickUnit18.compareTo((java.lang.Object) 10);
        numberAxis16.setTickUnit(numberTickUnit18);
        float float22 = numberAxis16.getMinorTickMarkInsideLength();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity28 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis16, shape25, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.axis.AxisState axisState30 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        java.util.List list33 = numberAxis16.refreshTicks(graphics2D29, axisState30, rectangle2D31, rectangleEdge32);
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection35 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot34.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot34.setRangeZeroBaselinePaint((java.awt.Paint) color37);
        numberAxis16.setTickLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("item", "Last", "DateTickMarkPosition.MIDDLE", "{0}: ({1}, {2})", (java.awt.Shape) rectangle2D13, stroke14, (java.awt.Paint) color37);
        java.awt.geom.Point2D point2D41 = null;
        org.jfree.chart.plot.PlotState plotState42 = null;
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = chartRenderingInfo44.getPlotInfo();
        try {
            multiplePiePlot0.draw(graphics2D4, rectangle2D13, point2D41, plotState42, plotRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(plotRenderingInfo45);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        numberAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) true, true);
        barRenderer0.setAutoPopulateSeriesPaint(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator8, false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        java.lang.Object obj1 = null;
        boolean boolean2 = timePeriodAnchor0.equals(obj1);
        org.jfree.chart.util.Rotation rotation3 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str4 = rotation3.toString();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal(obj1, (java.lang.Object) str4);
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str4.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("AxisLabelEntity: label = hi!", "");
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        long long4 = segmentedTimeline3.getSegmentSize();
        boolean boolean5 = segmentedTimeline3.getAdjustForDaylightSaving();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        boolean boolean3 = piePlot1.getAutoPopulateSectionPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot1.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord6 = abstractPieLabelDistributor4.getPieLabelRecord(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.text.DateFormat dateFormat2 = null;
        java.text.DateFormat dateFormat3 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat2, dateFormat3);
        java.text.NumberFormat numberFormat5 = standardXYToolTipGenerator4.getYFormat();
        numberFormat5.setParseIntegerOnly(true);
        java.text.NumberFormat numberFormat9 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f), numberFormat9);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("Rotation.ANTICLOCKWISE", numberFormat5, numberFormat9);
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertNotNull(numberFormat9);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "TitleEntity: tooltip = null", "TimePeriodAnchor.MIDDLE");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        int int10 = xYPlot0.getWeight();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) true, true);
        barRenderer0.setAutoPopulateSeriesPaint(false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot8.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo12, point2D13);
        int int15 = categoryPlot8.getBackgroundImageAlignment();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) 1.0f, false);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint23 = textTitle22.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean25 = categoryPlot24.isDomainGridlinesVisible();
        java.awt.Stroke stroke26 = categoryPlot24.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 2, paint23, stroke26);
        categoryPlot16.setRangeCrosshairStroke(stroke26);
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        double double31 = piePlot30.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = piePlot30.getLabelPadding();
        java.awt.Paint paint33 = piePlot30.getBaseSectionOutlinePaint();
        categoryPlot16.setDomainCrosshairPaint(paint33);
        categoryPlot8.setBackgroundPaint(paint33);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer36 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean37 = xYAreaRenderer36.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment41 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font42 = textFragment41.getFont();
        java.awt.Paint paint43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine44 = new org.jfree.chart.text.TextLine("", font42, paint43);
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection46 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot45.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection46);
        java.awt.Paint paint48 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo49 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean50 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint48, (java.lang.Object) basicProjectInfo49);
        xYPlot45.setRangeCrosshairPaint(paint48);
        org.jfree.chart.block.LabelBlock labelBlock52 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font42, paint48);
        xYAreaRenderer36.setBaseItemLabelPaint(paint48);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = xYAreaRenderer36.getPositiveItemLabelPosition(15, (int) ' ', true);
        org.jfree.chart.entity.EntityCollection entityCollection58 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo59 = new org.jfree.chart.ChartRenderingInfo(entityCollection58);
        java.awt.geom.Rectangle2D rectangle2D60 = chartRenderingInfo59.getChartArea();
        xYAreaRenderer36.setBaseShape((java.awt.Shape) rectangle2D60);
        try {
            barRenderer0.drawOutline(graphics2D7, categoryPlot8, rectangle2D60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 90.0d + "'", double31 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition57);
        org.junit.Assert.assertNotNull(rectangle2D60);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = xYAreaRenderer0.getToolTipGenerator((int) ' ', (int) '#', true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        int int0 = java.text.NumberFormat.FRACTION_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        textTitle1.setPadding(0.0d, (double) 24234L, (double) (byte) 100, 0.0d);
        textTitle1.setMaximumLinesToDisplay(9);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("JFreeChartEntity: tooltip = null", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection1.getSeries((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor7 = org.jfree.data.time.TimePeriodAnchor.START;
        timeSeriesCollection1.setXPosition(timePeriodAnchor7);
        java.lang.Number number9 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.junit.Assert.assertNull(timeSeries6);
        org.junit.Assert.assertNotNull(timePeriodAnchor7);
        org.junit.Assert.assertEquals((double) number9, Double.NaN, 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setAnchorValue((double) 10, true);
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        try {
            boolean boolean7 = categoryPlot0.removeAnnotation(categoryAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint8 = xYStepRenderer5.lookupLegendTextPaint((int) 'a');
        xYStepRenderer5.setDefaultEntityRadius(0);
        xYStepRenderer5.setDrawOutlines(false);
        xYStepRenderer5.setDrawOutlines(false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font2 = textFragment1.getFont();
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textFragment1.calculateDimensions(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        int int10 = xYSeriesCollection4.indexOf(xYSeries9);
        try {
            java.lang.Number number13 = xYSeriesCollection4.getX(128, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot1.getLabelPadding();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLabelGenerator();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Multiple Pie Plot");
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D4, rectangleEdge5);
        java.awt.Font font8 = null;
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) (-1L), font8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean16 = textLine14.equals((java.lang.Object) rectangleEdge15);
        org.jfree.chart.axis.AxisState axisState17 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D1.drawTickMarks(graphics2D10, (double) 1.0f, rectangle2D12, rectangleEdge15, axisState17);
        axisState17.cursorLeft(3.0d);
        axisState17.cursorLeft((double) 1577865599999L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot1.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener4 = null;
        timeSeriesCollection2.addChangeListener(datasetChangeListener4);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeriesCollection2.getSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.DomainOrder domainOrder8 = timeSeriesCollection2.getDomainOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis3D10.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D13, rectangleEdge14);
        java.awt.Paint paint17 = null;
        categoryAxis3D10.setTickLabelPaint((java.lang.Comparable) 1.0d, paint17);
        java.awt.Font font20 = categoryAxis3D10.getTickLabelFont((java.lang.Comparable) 100L);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) categoryAxis3D10, seriesChangeInfo21);
        timeSeriesCollection2.seriesChanged(seriesChangeEvent22);
        timeSeriesCollection0.seriesChanged(seriesChangeEvent22);
        try {
            java.lang.Comparable comparable26 = timeSeriesCollection0.getSeriesKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeries7);
        org.junit.Assert.assertNotNull(domainOrder8);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "{0}: ({1}, {2})");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0}: ({1}, {2})" + "'", str4.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double2 = timeSeries1.getMinY();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double7 = timeSeries6.getMinY();
        timeSeries6.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 255, true);
        try {
            timeSeries1.delete(128, (int) 'a', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowYOffset((double) (-1L));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator3);
        org.jfree.chart.entity.EntityCollection entityCollection10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo(entityCollection10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo11.getChartArea();
        chartRenderingInfo11.clear();
        java.awt.geom.Rectangle2D rectangle2D14 = chartRenderingInfo11.getChartArea();
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int21 = numberTickUnit19.compareTo((java.lang.Object) 10);
        numberAxis17.setTickUnit(numberTickUnit19);
        float float23 = numberAxis17.getMinorTickMarkInsideLength();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity29 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis17, shape26, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.AxisState axisState31 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        java.util.List list34 = numberAxis17.refreshTicks(graphics2D30, axisState31, rectangle2D32, rectangleEdge33);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection36 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot35.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot35.setRangeZeroBaselinePaint((java.awt.Paint) color38);
        numberAxis17.setTickLabelPaint((java.awt.Paint) color38);
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("item", "Last", "DateTickMarkPosition.MIDDLE", "{0}: ({1}, {2})", (java.awt.Shape) rectangle2D14, stroke15, (java.awt.Paint) color38);
        barRenderer0.setSeriesFillPaint(9, (java.awt.Paint) color38, true);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint8 = xYStepRenderer5.lookupLegendTextPaint((int) 'a');
        xYStepRenderer5.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = xYStepRenderer5.getBaseItemLabelGenerator();
        java.awt.Stroke stroke13 = xYStepRenderer5.getSeriesOutlineStroke(3);
        java.awt.Paint paint15 = xYStepRenderer5.lookupSeriesPaint(500);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(xYItemLabelGenerator11);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        int int3 = java.awt.Color.HSBtoRGB((float) 500, (float) 100, (float) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-33) + "'", int3 == (-33));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        try {
            java.lang.Number number4 = defaultXYDataset0.getY(7, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.entity.EntityCollection entityCollection6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo(entityCollection6);
        java.awt.geom.Rectangle2D rectangle2D8 = chartRenderingInfo7.getChartArea();
        org.jfree.chart.RenderingSource renderingSource9 = null;
        chartRenderingInfo7.setRenderingSource(renderingSource9);
        try {
            java.awt.image.BufferedImage bufferedImage11 = jFreeChart3.createBufferedImage((int) '4', 0, chartRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (52) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(rectangle2D8);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape6, paint13);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.entity.AxisEntity axisEntity18 = new org.jfree.chart.entity.AxisEntity(shape6, (org.jfree.chart.axis.Axis) categoryAxis3D15, "", "Size2D[width=0.0, height=0.0]");
        double double19 = categoryAxis3D15.getLowerMargin();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f), numberFormat1);
        java.util.Currency currency3 = null;
        try {
            numberFormat1.setCurrency(currency3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        categoryPlot0.clearRangeMarkers((int) (byte) 0);
        boolean boolean21 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        try {
            xYSeriesCollection4.setSelected((int) (byte) 100, (int) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        java.lang.String str14 = axisLabelEntity13.getToolTipText();
        java.lang.String str15 = axisLabelEntity13.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "AxisLabelEntity: label = hi!" + "'", str15.equals("AxisLabelEntity: label = hi!"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(7, (int) (byte) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer2.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer2.setNegativeItemLabelPositionFallback(itemLabelPosition5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer2.setSeriesURLGenerator(0, categoryURLGenerator8);
        java.text.DateFormat dateFormat11 = null;
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator13 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat11, dateFormat12);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset14 = new org.jfree.data.xy.DefaultXYDataset();
        boolean boolean15 = standardXYToolTipGenerator13.equals((java.lang.Object) defaultXYDataset14);
        boolean boolean16 = barRenderer2.equals((java.lang.Object) standardXYToolTipGenerator13);
        barRenderer2.clearSeriesStrokes(true);
        boolean boolean19 = defaultXYDataset0.equals((java.lang.Object) true);
        try {
            java.lang.Comparable comparable21 = defaultXYDataset0.getSeriesKey(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        java.util.List list18 = numberAxis1.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge17);
        boolean boolean19 = numberAxis1.isMinorTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape22 = numberAxis21.getLeftArrow();
        java.awt.Paint paint23 = numberAxis21.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = numberAxis21.getStandardTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource24);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(tickUnitSource24);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        int int10 = xYSeriesCollection4.indexOf(xYSeries9);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem12 = xYSeries9.remove((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int1 = dateTickUnit0.getRollMultiple();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        boolean boolean2 = xYPlot1.isRangeCrosshairVisible();
        java.awt.Paint paint3 = xYPlot1.getBackgroundPaint();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot1);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener8 = null;
        timeSeriesCollection6.addChangeListener(datasetChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeriesCollection6.getSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.DomainOrder domainOrder12 = timeSeriesCollection6.getDomainOrder();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot13.setOrientation(plotOrientation17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list23 = timeSeries22.getItems();
        xYPlot13.drawRangeTickBands(graphics2D19, rectangle2D20, list23);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6, list23, true);
        org.jfree.data.Range range27 = null;
        try {
            org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0, list23, range27, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'xRange' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(timeSeries11);
        org.junit.Assert.assertNotNull(domainOrder12);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNull(range26);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot1.getLabelDistributor();
        double double5 = piePlot1.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint14 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape10, paint14);
        java.awt.Stroke stroke16 = legendGraphic15.getLineStroke();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(stroke16);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        long long3 = month2.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 35L);
        timeSeries1.add(timeSeriesDataItem5, true);
        try {
            timeSeries1.delete((-1), 2958465, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        xYPlot0.setRangeMinorGridlinesVisible(true);
        java.awt.Font font17 = xYPlot0.getNoDataMessageFont();
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot0.getRangeMarkers(layer18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int25 = numberTickUnit23.compareTo((java.lang.Object) 10);
        numberAxis21.setTickUnit(numberTickUnit23);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint36 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape33, (java.awt.Paint) color34, stroke35, paint36);
        numberAxis21.setRightArrow(shape33);
        double double39 = numberAxis21.getAutoRangeMinimumSize();
        boolean boolean40 = numberAxis21.isVisible();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        numberAxis21.setAutoTickUnitSelection(true);
        double double44 = numberAxis21.getUpperBound();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0E-8d + "'", double39 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.05d + "'", double44 == 1.05d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) itemLabelAnchor0);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setAnchorValue((double) 10, true);
        java.awt.Paint paint5 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.setOutlineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) 0, "hi!", "{0}: ({1}, {2})", false);
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat((double) 0, "hi!", "{0}: ({1}, {2})", false);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", (java.text.NumberFormat) logFormat5, (java.text.NumberFormat) logFormat10);
        java.text.NumberFormat numberFormat12 = logFormat10.getExponentFormat();
        logFormat10.setMinimumIntegerDigits((int) ' ');
        java.text.ParsePosition parsePosition16 = null;
        java.lang.Object obj17 = logFormat10.parseObject("", parsePosition16);
        org.junit.Assert.assertNotNull(numberFormat12);
        org.junit.Assert.assertNull(obj17);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot0.getRangeMarkers(128, layer9);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(collection10);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 10.0f);
        float float3 = intervalMarker2.getAlpha();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.8f + "'", float3 == 0.8f);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape10, "hi!", "{0}: ({1}, {2})");
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        java.util.List list18 = numberAxis1.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge17);
        boolean boolean19 = numberAxis1.isMinorTickMarksVisible();
        java.awt.Shape shape20 = numberAxis1.getUpArrow();
        numberAxis1.setAutoRangeMinimumSize((double) 9, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D4, rectangleEdge5);
        java.awt.Font font8 = null;
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) (-1L), font8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean16 = textLine14.equals((java.lang.Object) rectangleEdge15);
        org.jfree.chart.axis.AxisState axisState17 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D1.drawTickMarks(graphics2D10, (double) 1.0f, rectangle2D12, rectangleEdge15, axisState17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowYOffset((double) (-1L));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator5, false);
        barRenderer0.setShadowXOffset((double) 10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = barRenderer0.getSeriesURLGenerator(0);
        org.junit.Assert.assertNull(categoryURLGenerator11);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot1.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        java.awt.Paint paint4 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint4, (java.lang.Object) basicProjectInfo5);
        xYPlot1.setRangeCrosshairPaint(paint4);
        java.awt.Paint paint8 = xYPlot1.getRangeZeroBaselinePaint();
        xYPlot1.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot1.getAxisOffset();
        xYPlot1.setRangeMinorGridlinesVisible(true);
        boolean boolean14 = centerArrangement0.equals((java.lang.Object) true);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        boolean boolean16 = centerArrangement0.equals((java.lang.Object) textAnchor15);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.BOTTOM_RIGHT" + "'", str1.equals("TextBlockAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 100);
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection5 = xYAreaRenderer4.getAnnotations();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYAreaRenderer4);
        boolean boolean7 = multiplePiePlot0.equals((java.lang.Object) xYAreaRenderer4);
        boolean boolean8 = xYAreaRenderer4.getUseFillPaint();
        java.lang.Boolean boolean10 = xYAreaRenderer4.getSeriesVisibleInLegend(1);
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(boolean10);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection1 = xYAreaRenderer0.getAnnotations();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer0.setSeriesStroke(0, stroke3, true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        boolean boolean7 = xYPlot6.isRangeCrosshairVisible();
        java.awt.Paint paint8 = xYPlot6.getBackgroundPaint();
        xYAreaRenderer0.setBaseOutlinePaint(paint8, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        try {
            xYAreaRenderer0.setSeriesToolTipGenerator(2147483647, xYToolTipGenerator12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = basicProjectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double5 = timeSeries4.getMinY();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double10 = timeSeries9.getMinY();
        timeSeries9.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.Year year15 = month13.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 255, true);
        java.lang.Class class20 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double23 = timeSeries22.getMinY();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double28 = timeSeries27.getMinY();
        timeSeries27.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        int int32 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) month31);
        org.jfree.data.time.Year year33 = month31.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.previous();
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) 255, true);
        java.lang.Class class38 = timeSeries22.getTimePeriodClass();
        java.lang.Object obj39 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("[size=10]", class20, class38);
        java.io.InputStream inputStream40 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Rotation.ANTICLOCKWISE", class38);
        java.lang.Object obj41 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("TextBlockAnchor.BOTTOM_RIGHT", class38);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertNull(inputStream40);
        org.junit.Assert.assertNull(obj41);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection1 = xYAreaRenderer0.getAnnotations();
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYAreaRenderer0.setBaseItemLabelFont(font2);
        boolean boolean4 = xYAreaRenderer0.getPlotArea();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator5 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 100);
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection5 = xYAreaRenderer4.getAnnotations();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYAreaRenderer4);
        boolean boolean7 = multiplePiePlot0.equals((java.lang.Object) xYAreaRenderer4);
        boolean boolean8 = xYAreaRenderer4.getUseFillPaint();
        java.awt.Paint paint9 = xYAreaRenderer4.getBaseOutlinePaint();
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        long long3 = month2.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 35L);
        timeSeries1.add(timeSeriesDataItem5, true);
        java.awt.Color color8 = java.awt.Color.ORANGE;
        boolean boolean9 = timeSeriesDataItem5.equals((java.lang.Object) color8);
        java.text.DateFormat dateFormat11 = null;
        java.text.DateFormat dateFormat12 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator13 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat11, dateFormat12);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer15 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13, xYURLGenerator14);
        java.awt.Font font19 = xYStepRenderer15.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        boolean boolean22 = xYPlot21.isRangeCrosshairVisible();
        java.awt.Paint paint23 = xYPlot21.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis25.pan(0.0d);
        org.jfree.chart.plot.Marker marker28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        xYStepRenderer15.drawRangeMarker(graphics2D20, xYPlot21, (org.jfree.chart.axis.ValueAxis) numberAxis25, marker28, rectangle2D29);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer15.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color32, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean36 = xYStepRenderer15.hasListener((java.util.EventListener) categoryPlot35);
        boolean boolean37 = xYStepRenderer15.getDrawSeriesLineAsPath();
        xYStepRenderer15.setAutoPopulateSeriesFillPaint(false);
        boolean boolean40 = timeSeriesDataItem5.equals((java.lang.Object) xYStepRenderer15);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) 8, (double) 100, (double) '#');
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D4, rectangleEdge5);
        java.awt.Paint paint8 = null;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) 1.0d, paint8);
        java.awt.Font font11 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) 100L);
        categoryAxis3D1.removeCategoryLabelToolTip((java.lang.Comparable) "[size=10]");
        org.jfree.data.xy.XYDataItem xYDataItem16 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 5, (java.lang.Number) 1);
        xYDataItem16.setSelected(false);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) xYDataItem16, "Value");
        boolean boolean21 = xYDataItem16.isSelected();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint10 = xYStepRenderer5.getItemFillPaint(0, (int) (short) 100, false);
        xYStepRenderer5.clearSeriesStrokes(true);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape20, (java.awt.Paint) color21, stroke22, paint23);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        boolean boolean26 = xYPlot25.isRangeCrosshairVisible();
        java.awt.Paint paint27 = xYPlot25.getBackgroundPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape20, paint27);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator29 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection31 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot30.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot30.setRangeZeroBaselinePaint((java.awt.Paint) color33);
        int int35 = color33.getBlue();
        boolean boolean36 = standardXYToolTipGenerator29.equals((java.lang.Object) color33);
        legendGraphic28.setFillPaint((java.awt.Paint) color33);
        xYStepRenderer5.setSeriesFillPaint(3, (java.awt.Paint) color33);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 128 + "'", int35 == 128);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double4 = timeSeries3.getMinY();
        timeSeries3.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month7);
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        java.lang.String str11 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) regularTimePeriod10);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        long long14 = month13.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) 35L);
        org.jfree.data.time.Year year17 = month13.getYear();
        java.lang.String str18 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset12, (java.lang.Comparable) year17);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        java.lang.String str21 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset19, (java.lang.Comparable) day20);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = day20.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        double double3 = piePlot1.getMaximumExplodePercent();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot1.getLabelDistributor();
        piePlot1.setShadowXOffset(10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Shape shape6 = xYStepRenderer5.getBaseShape();
        java.awt.Paint paint8 = xYStepRenderer5.lookupLegendTextPaint((int) 'a');
        xYStepRenderer5.setBaseLinesVisible(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = xYStepRenderer5.getBaseItemLabelGenerator();
        java.awt.Stroke stroke13 = xYStepRenderer5.getSeriesOutlineStroke(3);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean16 = xYAreaRenderer15.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font21 = textFragment20.getFont();
        java.awt.Paint paint22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("", font21, paint22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection25 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot24.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection25);
        java.awt.Paint paint27 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo28 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint27, (java.lang.Object) basicProjectInfo28);
        xYPlot24.setRangeCrosshairPaint(paint27);
        org.jfree.chart.block.LabelBlock labelBlock31 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font21, paint27);
        xYAreaRenderer15.setBaseItemLabelPaint(paint27);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = xYAreaRenderer15.getPositiveItemLabelPosition(15, (int) ' ', true);
        java.lang.Object obj37 = null;
        boolean boolean38 = itemLabelPosition36.equals(obj37);
        xYStepRenderer5.setSeriesPositiveItemLabelPosition((int) '#', itemLabelPosition36);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(xYItemLabelGenerator11);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer5.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color22, true);
        xYStepRenderer5.setBaseShapesFilled(false);
        java.lang.Boolean boolean28 = xYStepRenderer5.getSeriesItemLabelsVisible(0);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(boolean28);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        float float7 = numberAxis1.getMinorTickMarkInsideLength();
        java.awt.Shape shape8 = numberAxis1.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot9.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint12, (java.lang.Object) basicProjectInfo13);
        xYPlot9.setRangeCrosshairPaint(paint12);
        java.awt.Paint paint16 = xYPlot9.getRangeCrosshairPaint();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) xYPlot9, "{0}: ({1}, {2})");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.lang.String str21 = textTitle20.getToolTipText();
        org.jfree.chart.entity.TitleEntity titleEntity22 = new org.jfree.chart.entity.TitleEntity(shape8, (org.jfree.chart.title.Title) textTitle20);
        boolean boolean23 = textTitle20.visible;
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Second" + "'", str1.equals("Second"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double4 = timeSeries3.getMinY();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double9 = timeSeries8.getMinY();
        timeSeries8.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        int int13 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Year year14 = month12.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 255, true);
        java.lang.Class class19 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double22 = timeSeries21.getMinY();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        double double27 = timeSeries26.getMinY();
        timeSeries26.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        int int31 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) month30);
        org.jfree.data.time.Year year32 = month30.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 255, true);
        java.lang.Class class37 = timeSeries21.getTimePeriodClass();
        java.lang.Object obj38 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("[size=10]", class19, class37);
        java.io.InputStream inputStream39 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("JFreeChartEntity: tooltip = null", class37);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(class37);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertNull(inputStream39);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        timeSeriesCollection1.addChangeListener(datasetChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection1.getSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection1.getDomainOrder();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor8 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        java.lang.Object obj9 = null;
        boolean boolean10 = timePeriodAnchor8.equals(obj9);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape17, (java.awt.Paint) color18, stroke19, paint20);
        java.awt.Stroke stroke22 = legendItem21.getOutlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit26 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int28 = numberTickUnit26.compareTo((java.lang.Object) 10);
        numberAxis24.setTickUnit(numberTickUnit26);
        float float30 = numberAxis24.getMinorTickMarkInsideLength();
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity36 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis24, shape33, "hi!", "{0}: ({1}, {2})");
        legendItem21.setShape(shape33);
        boolean boolean38 = timePeriodAnchor8.equals((java.lang.Object) legendItem21);
        timeSeriesCollection1.setXPosition(timePeriodAnchor8);
        org.junit.Assert.assertNull(timeSeries6);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertNotNull(timePeriodAnchor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) true, true);
        double double5 = barRenderer0.getMinimumBarLength();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorDown((double) 0.0f);
        axisState0.setCursor((double) 3);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 3, "AxisEntity: tooltip = ", textAnchor2, textAnchor3, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Paint paint2 = xYPlot0.getBackgroundPaint();
        xYPlot0.setRangeCrosshairValue(0.0d, true);
        boolean boolean6 = xYPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape10 = numberAxis9.getLeftArrow();
        java.awt.Paint paint11 = numberAxis9.getTickLabelPaint();
        xYPlot0.setDomainAxis(2, (org.jfree.chart.axis.ValueAxis) numberAxis9, false);
        numberAxis9.setPositiveArrowVisible(false);
        numberAxis9.setLabelToolTip("TitleEntity: tooltip = null");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = numberAxis9.getMarkerBand();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(markerAxisBand18);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 100);
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.data.general.DatasetGroup datasetGroup4 = multiplePiePlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNull(datasetGroup4);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }
}

