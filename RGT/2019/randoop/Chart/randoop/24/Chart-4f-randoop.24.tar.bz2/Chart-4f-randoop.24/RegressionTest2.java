import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Value");
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D4, rectangleEdge5);
        java.awt.Paint paint8 = null;
        categoryAxis3D1.setTickLabelPaint((java.lang.Comparable) 1.0d, paint8);
        java.awt.Font font11 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) 100L);
        categoryAxis3D1.setLowerMargin((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(font11);
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test04");
//        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//        org.jfree.data.general.PieDataset pieDataset2 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
//        double double5 = timeSeries4.getMinY();
//        timeSeries4.setKey((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        int int9 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
//        org.jfree.data.time.Year year10 = month8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        java.lang.String str12 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) regularTimePeriod11);
//        org.jfree.data.general.PieDataset pieDataset13 = null;
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        long long15 = month14.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 35L);
//        org.jfree.data.time.Year year18 = month14.getYear();
//        java.lang.String str19 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset13, (java.lang.Comparable) year18);
//        org.jfree.data.general.PieDataset pieDataset20 = null;
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.String str22 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset20, (java.lang.Comparable) day21);
//        int int23 = day21.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate24 = day21.getSerialDate();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
//        java.lang.String str26 = serialDate24.toString();
//        try {
//            org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(13, serialDate24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 13 + "'", int23 == 13);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        double double1 = combinedRangeXYPlot0.getGap();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot2.setLimit((double) 100);
        org.jfree.chart.util.TableOrder tableOrder5 = multiplePiePlot2.getDataExtractOrder();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection7 = xYAreaRenderer6.getAnnotations();
        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYAreaRenderer6);
        boolean boolean9 = multiplePiePlot2.equals((java.lang.Object) xYAreaRenderer6);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
        org.junit.Assert.assertNotNull(tableOrder5);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) true, true);
        barRenderer0.setAutoPopulateSeriesPaint(false);
        java.awt.Font font8 = barRenderer0.lookupLegendTextFont((int) '4');
        org.junit.Assert.assertNull(font8);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer5.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = xYStepRenderer5.hasListener((java.util.EventListener) categoryPlot25);
        boolean boolean27 = xYStepRenderer5.getDrawSeriesLineAsPath();
        xYStepRenderer5.setAutoPopulateSeriesFillPaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYStepRenderer5.getNegativeItemLabelPosition((int) (short) -1, (int) (short) 0, true);
        org.jfree.chart.text.TextAnchor textAnchor34 = itemLabelPosition33.getTextAnchor();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(textAnchor34);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.setDomainPannable(true);
        java.awt.Stroke stroke10 = xYPlot0.getDomainZeroBaselineStroke();
        int int11 = xYPlot0.getDomainAxisCount();
        java.text.DateFormat dateFormat13 = null;
        java.text.DateFormat dateFormat14 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat13, dateFormat14);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer17 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, xYURLGenerator16);
        java.awt.Shape shape18 = xYStepRenderer17.getBaseShape();
        java.awt.Paint paint22 = xYStepRenderer17.getItemFillPaint(0, (int) (short) 100, false);
        xYPlot0.setBackgroundPaint(paint22);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot6.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = xYPlot6.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot6.setOrientation(plotOrientation10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list16 = timeSeries15.getItems();
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.entity.EntityCollection entityCollection19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo(entityCollection19);
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo20.getChartArea();
        chartRenderingInfo20.clear();
        java.awt.geom.Rectangle2D rectangle2D23 = chartRenderingInfo20.getChartArea();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list26 = timeSeries25.getItems();
        xYPlot6.drawRangeTickBands(graphics2D18, rectangle2D23, list26);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double29 = categoryAxis2.getCategoryJava2DCoordinate(categoryAnchor3, 7, (int) (short) 1, rectangle2D23, rectangleEdge28);
        lineBorder0.draw(graphics2D1, rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection1 = xYAreaRenderer0.getAnnotations();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer0.setSeriesStroke(0, stroke3, true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        boolean boolean7 = xYPlot6.isRangeCrosshairVisible();
        java.awt.Paint paint8 = xYPlot6.getBackgroundPaint();
        xYAreaRenderer0.setBaseOutlinePaint(paint8, false);
        java.awt.Shape shape11 = xYAreaRenderer0.getLegendArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot12.getFixedLegendItems();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity16 = new org.jfree.chart.entity.JFreeChartEntity(shape11, jFreeChart15);
        jFreeChart15.clearSubtitles();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot23.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot23.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot23.setOrientation(plotOrientation27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list33 = timeSeries32.getItems();
        xYPlot23.drawRangeTickBands(graphics2D29, rectangle2D30, list33);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.entity.EntityCollection entityCollection36 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = new org.jfree.chart.ChartRenderingInfo(entityCollection36);
        java.awt.geom.Rectangle2D rectangle2D38 = chartRenderingInfo37.getChartArea();
        chartRenderingInfo37.clear();
        java.awt.geom.Rectangle2D rectangle2D40 = chartRenderingInfo37.getChartArea();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list43 = timeSeries42.getItems();
        xYPlot23.drawRangeTickBands(graphics2D35, rectangle2D40, list43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double46 = categoryAxis19.getCategoryJava2DCoordinate(categoryAnchor20, 7, (int) (short) 1, rectangle2D40, rectangleEdge45);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor50 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection54 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot53.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection54);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = xYPlot53.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation57 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot53.setOrientation(plotOrientation57);
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list63 = timeSeries62.getItems();
        xYPlot53.drawRangeTickBands(graphics2D59, rectangle2D60, list63);
        java.awt.Graphics2D graphics2D65 = null;
        org.jfree.chart.entity.EntityCollection entityCollection66 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo67 = new org.jfree.chart.ChartRenderingInfo(entityCollection66);
        java.awt.geom.Rectangle2D rectangle2D68 = chartRenderingInfo67.getChartArea();
        chartRenderingInfo67.clear();
        java.awt.geom.Rectangle2D rectangle2D70 = chartRenderingInfo67.getChartArea();
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list73 = timeSeries72.getItems();
        xYPlot53.drawRangeTickBands(graphics2D65, rectangle2D70, list73);
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double76 = categoryAxis49.getCategoryJava2DCoordinate(categoryAnchor50, 7, (int) (short) 1, rectangle2D70, rectangleEdge75);
        java.awt.geom.Point2D point2D77 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 11, (double) 1561964399999L, rectangle2D70);
        org.jfree.chart.entity.EntityCollection entityCollection78 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo79 = new org.jfree.chart.ChartRenderingInfo(entityCollection78);
        java.awt.geom.Rectangle2D rectangle2D80 = chartRenderingInfo79.getChartArea();
        org.jfree.chart.RenderingSource renderingSource81 = null;
        chartRenderingInfo79.setRenderingSource(renderingSource81);
        try {
            jFreeChart15.draw(graphics2D18, rectangle2D40, point2D77, chartRenderingInfo79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNotNull(plotOrientation57);
        org.junit.Assert.assertNotNull(list63);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(list73);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(point2D77);
        org.junit.Assert.assertNotNull(rectangle2D80);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        xYSeriesCollection4.removeSeries(xYSeries8);
        double double10 = xYSeries8.getMaxX();
        java.lang.Comparable comparable11 = xYSeries8.getKey();
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 1.0d + "'", comparable11.equals(1.0d));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        xYSeriesCollection4.setAutoWidth(false);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 10.0f);
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker4, layer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getRangeAxisLocation(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot0.getDomainMarkers(layer21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.setDomainCrosshairRowKey((java.lang.Comparable) 1.0f, false);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint30 = textTitle29.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean32 = categoryPlot31.isDomainGridlinesVisible();
        java.awt.Stroke stroke33 = categoryPlot31.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) 2, paint30, stroke33);
        categoryPlot23.setRangeCrosshairStroke(stroke33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = categoryAxis3D37.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D40, rectangleEdge41);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D44 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D44.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D47 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = null;
        double double52 = categoryAxis3D47.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D50, rectangleEdge51);
        java.awt.Paint paint54 = null;
        categoryAxis3D47.setTickLabelPaint((java.lang.Comparable) 1.0d, paint54);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D57 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        categoryAxis3D57.setMaximumCategoryLabelLines(10);
        categoryAxis3D57.removeCategoryLabelToolTip((java.lang.Comparable) 10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D63 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = null;
        double double68 = categoryAxis3D63.getCategoryStart((int) ' ', (int) (short) 10, rectangle2D66, rectangleEdge67);
        java.awt.Paint paint70 = null;
        categoryAxis3D63.setTickLabelPaint((java.lang.Comparable) 1.0d, paint70);
        java.awt.Font font73 = categoryAxis3D63.getTickLabelFont((java.lang.Comparable) 100L);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D75 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray76 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D37, categoryAxis3D44, categoryAxis3D47, categoryAxis3D57, categoryAxis3D63, categoryAxis3D75 };
        categoryPlot23.setDomainAxes(categoryAxisArray76);
        org.jfree.chart.axis.ValueAxis valueAxis78 = categoryPlot23.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation79 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot23.setDomainAxisLocation(axisLocation79);
        categoryPlot0.setDomainAxisLocation(axisLocation79, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertNotNull(categoryAxisArray76);
        org.junit.Assert.assertNull(valueAxis78);
        org.junit.Assert.assertNotNull(axisLocation79);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeCrosshairPaint();
        java.text.DateFormat dateFormat9 = null;
        java.text.DateFormat dateFormat10 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat9, dateFormat10);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator11, xYURLGenerator12);
        java.awt.Font font17 = xYStepRenderer13.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        boolean boolean20 = xYPlot19.isRangeCrosshairVisible();
        java.awt.Paint paint21 = xYPlot19.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis23.pan(0.0d);
        org.jfree.chart.plot.Marker marker26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        xYStepRenderer13.drawRangeMarker(graphics2D18, xYPlot19, (org.jfree.chart.axis.ValueAxis) numberAxis23, marker26, rectangle2D27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer13.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color30, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean34 = xYStepRenderer13.hasListener((java.util.EventListener) categoryPlot33);
        boolean boolean35 = xYStepRenderer13.getDrawSeriesLineAsPath();
        xYStepRenderer13.setAutoPopulateSeriesFillPaint(false);
        int int38 = xYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer13);
        java.awt.Font font39 = xYPlot0.getNoDataMessageFont();
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = xYPlot0.getOrientation();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(plotOrientation40);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        float[] floatArray3 = null;
        float[] floatArray4 = java.awt.Color.RGBtoHSB((-33), (int) '#', 1900, floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection1 = xYAreaRenderer0.getAnnotations();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYAreaRenderer0.setSeriesStroke(0, stroke3, true);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        boolean boolean7 = xYPlot6.isRangeCrosshairVisible();
        java.awt.Paint paint8 = xYPlot6.getBackgroundPaint();
        xYAreaRenderer0.setBaseOutlinePaint(paint8, false);
        xYAreaRenderer0.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        try {
            java.lang.Object obj2 = logFormat0.parseObject("TitleEntity: tooltip = null");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        long long4 = segmentedTimeline3.getSegmentsGroupSize();
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean5 = segmentedTimeline3.equals((java.lang.Object) (short) 10);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segmentedTimeline3.getSegment((long) 255);
        java.util.Date date8 = segment7.getDate();
        boolean boolean11 = segment7.contains((long) 'a', 3600000L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean17 = segmentedTimeline15.equals((java.lang.Object) (short) 10);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment19 = segmentedTimeline15.getSegment((long) 255);
        java.util.Date date20 = segment19.getDate();
        boolean boolean23 = segment19.contains((long) 'a', 3600000L);
        boolean boolean24 = segment7.before(segment19);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(segment7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(segment19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.text.DateFormat dateFormat2 = null;
        java.text.DateFormat dateFormat3 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat2, dateFormat3);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator4, xYURLGenerator5);
        java.awt.Font font10 = xYStepRenderer6.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        boolean boolean13 = xYPlot12.isRangeCrosshairVisible();
        java.awt.Paint paint14 = xYPlot12.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis16.pan(0.0d);
        org.jfree.chart.plot.Marker marker19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYStepRenderer6.drawRangeMarker(graphics2D11, xYPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis16, marker19, rectangle2D20);
        boolean boolean22 = defaultDrawingSupplier0.equals((java.lang.Object) xYStepRenderer6);
        java.awt.Stroke stroke23 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int5 = numberTickUnit3.compareTo((java.lang.Object) 10);
        numberAxis1.setTickUnit(numberTickUnit3);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape13, (java.awt.Paint) color14, stroke15, paint16);
        numberAxis1.setRightArrow(shape13);
        java.lang.Object obj19 = numberAxis1.clone();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.chart.renderer.RendererUtilities rendererUtilities0 = new org.jfree.chart.renderer.RendererUtilities();
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.setRangeGridlinesVisible(false);
        java.awt.Stroke stroke10 = null;
        try {
            xYPlot0.setDomainMinorGridlineStroke(stroke10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(2958465);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer3.setShadowYOffset((double) (-1L));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        barRenderer3.setSeriesToolTipGenerator(0, categoryToolTipGenerator7, false);
        boolean boolean13 = barRenderer3.getItemCreateEntity((-65536), 6, false);
        objectList1.set(4, (java.lang.Object) barRenderer3);
        java.lang.Object obj15 = objectList1.clone();
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) 6, (double) '#', (double) 2);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        java.text.NumberFormat numberFormat4 = standardXYToolTipGenerator3.getYFormat();
        numberFormat4.setParseIntegerOnly(true);
        java.lang.String str8 = numberFormat4.format((double) 60000L);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "60,000" + "'", str8.equals("60,000"));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowYOffset((double) (-1L));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator5, false);
        barRenderer0.setShadowXOffset((double) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        boolean boolean11 = barRenderer0.removeAnnotation(categoryAnnotation10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        xYPlot11.datasetChanged(datasetChangeEvent21);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit26 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int28 = numberTickUnit26.compareTo((java.lang.Object) 10);
        numberAxis24.setTickUnit(numberTickUnit26);
        numberAxis24.setMinorTickMarkInsideLength((-1.0f));
        numberAxis24.pan((double) 2147483647);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int39 = numberTickUnit37.compareTo((java.lang.Object) 10);
        numberAxis35.setTickUnit(numberTickUnit37);
        float float41 = numberAxis35.getMinorTickMarkInsideLength();
        java.awt.Shape shape42 = numberAxis35.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit46 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int48 = numberTickUnit46.compareTo((java.lang.Object) 10);
        numberAxis44.setTickUnit(numberTickUnit46);
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint59 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem60 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape56, (java.awt.Paint) color57, stroke58, paint59);
        numberAxis44.setRightArrow(shape56);
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape64 = numberAxis63.getLeftArrow();
        java.awt.Paint paint65 = numberAxis63.getTickLabelPaint();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray66 = new org.jfree.chart.axis.ValueAxis[] { numberAxis24, numberAxis35, numberAxis44, numberAxis63 };
        xYPlot11.setDomainAxes(valueAxisArray66);
        java.awt.Paint paint68 = xYPlot11.getRangeGridlinePaint();
        java.awt.Stroke stroke69 = xYPlot11.getDomainZeroBaselineStroke();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent70 = null;
        xYPlot11.datasetChanged(datasetChangeEvent70);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(valueAxisArray66);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(stroke69);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int7 = numberTickUnit5.compareTo((java.lang.Object) 10);
        numberAxis3.setTickUnit(numberTickUnit5);
        float float9 = numberAxis3.getMinorTickMarkInsideLength();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity15 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis3, shape12, "hi!", "{0}: ({1}, {2})");
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape12, paint16);
        boolean boolean18 = textTitle1.equals((java.lang.Object) paint16);
        boolean boolean19 = textTitle1.visible;
        textTitle1.setExpandToFitSpace(false);
        double double22 = textTitle1.getContentYOffset();
        boolean boolean23 = textTitle1.visible;
        java.lang.Object obj24 = textTitle1.clone();
        java.lang.String str25 = textTitle1.getURLText();
        textTitle1.visible = true;
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot2.setOrientation(plotOrientation3);
        boolean boolean5 = textTitle1.equals((java.lang.Object) categoryPlot2);
        java.text.DateFormat dateFormat7 = null;
        java.text.DateFormat dateFormat8 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator9 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat7, dateFormat8);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer11 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator9, xYURLGenerator10);
        java.awt.Shape shape12 = xYStepRenderer11.getBaseShape();
        java.awt.Paint paint14 = xYStepRenderer11.lookupLegendTextPaint((int) 'a');
        xYStepRenderer11.setDefaultEntityRadius(0);
        xYStepRenderer11.setDrawOutlines(false);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("DateTickMarkPosition.MIDDLE");
        java.awt.Paint paint22 = textTitle21.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean24 = categoryPlot23.isDomainGridlinesVisible();
        java.awt.Stroke stroke25 = categoryPlot23.getDomainGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 2, paint22, stroke25);
        xYStepRenderer11.setBaseOutlineStroke(stroke25);
        categoryPlot2.setRangeCrosshairStroke(stroke25);
        categoryPlot2.setAnchorValue((double) (-65536));
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator33 = barRenderer31.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = null;
        barRenderer31.setNegativeItemLabelPositionFallback(itemLabelPosition34);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator37 = null;
        barRenderer31.setSeriesURLGenerator(0, categoryURLGenerator37);
        java.text.DateFormat dateFormat40 = null;
        java.text.DateFormat dateFormat41 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator42 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat40, dateFormat41);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset43 = new org.jfree.data.xy.DefaultXYDataset();
        boolean boolean44 = standardXYToolTipGenerator42.equals((java.lang.Object) defaultXYDataset43);
        boolean boolean45 = barRenderer31.equals((java.lang.Object) standardXYToolTipGenerator42);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor50 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection54 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot53.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection54);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = xYPlot53.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation57 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot53.setOrientation(plotOrientation57);
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list63 = timeSeries62.getItems();
        xYPlot53.drawRangeTickBands(graphics2D59, rectangle2D60, list63);
        java.awt.Graphics2D graphics2D65 = null;
        org.jfree.chart.entity.EntityCollection entityCollection66 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo67 = new org.jfree.chart.ChartRenderingInfo(entityCollection66);
        java.awt.geom.Rectangle2D rectangle2D68 = chartRenderingInfo67.getChartArea();
        chartRenderingInfo67.clear();
        java.awt.geom.Rectangle2D rectangle2D70 = chartRenderingInfo67.getChartArea();
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list73 = timeSeries72.getItems();
        xYPlot53.drawRangeTickBands(graphics2D65, rectangle2D70, list73);
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double76 = categoryAxis49.getCategoryJava2DCoordinate(categoryAnchor50, 7, (int) (short) 1, rectangle2D70, rectangleEdge75);
        java.awt.geom.Point2D point2D77 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 11, (double) 1561964399999L, rectangle2D70);
        barRenderer31.setSeriesShape(6, (java.awt.Shape) rectangle2D70, false);
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer31);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(categoryItemLabelGenerator33);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNotNull(plotOrientation57);
        org.junit.Assert.assertNotNull(list63);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(list73);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(point2D77);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setShadowYOffset((double) (-1L));
        java.awt.Font font3 = barRenderer0.getBaseItemLabelFont();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape10, (java.awt.Paint) color11, stroke12, paint13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        boolean boolean16 = xYPlot15.isRangeCrosshairVisible();
        java.awt.Paint paint17 = xYPlot15.getBackgroundPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape10, paint17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = legendGraphic18.getShapeLocation();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = legendGraphic18.getFillPaintTransformer();
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer20);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Stroke stroke4 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = null;
        piePlot1.axisChanged(axisChangeEvent5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        double double2 = categoryAxis3D1.getCategoryMargin();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        categoryAxis3D1.drawTickMarks(graphics2D3, (double) (short) 100, rectangle2D5, rectangleEdge6, axisState7);
        categoryAxis3D1.setCategoryLabelPositionOffset(0);
        categoryAxis3D1.setLabelURL("Second");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer5.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = xYStepRenderer5.hasListener((java.util.EventListener) categoryPlot25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace27);
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint38 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape35, (java.awt.Paint) color36, stroke37, paint38);
        categoryPlot25.setDomainGridlinePaint(paint38);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        categoryPlot25.rendererChanged(rendererChangeEvent41);
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = null;
        try {
            categoryPlot25.addDomainMarker(categoryMarker43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelURL("item");
        boolean boolean3 = categoryAxis0.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        xYPlot0.clearRangeMarkers(100);
        xYPlot0.clearRangeMarkers(0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        waferMapPlot1.setNoDataMessage("hi!");
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        waferMapPlot1.setOutlineStroke(stroke4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = waferMapPlot1.getDrawingSupplier();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = waferMapPlot1.getInsets();
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("");
        textLine9.removeFragment(textFragment11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape15 = numberAxis14.getLeftArrow();
        java.awt.Paint paint16 = numberAxis14.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = numberAxis14.getStandardTickUnits();
        boolean boolean18 = textLine9.equals((java.lang.Object) numberAxis14);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = textLine9.calculateDimensions(graphics2D19);
        size2D20.setHeight((double) 11);
        org.jfree.chart.text.TextFragment textFragment28 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font29 = textFragment28.getFont();
        java.awt.Paint paint30 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("", font29, paint30);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection33 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot32.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection33);
        java.awt.Paint paint35 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo36 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint35, (java.lang.Object) basicProjectInfo36);
        xYPlot32.setRangeCrosshairPaint(paint35);
        org.jfree.chart.block.LabelBlock labelBlock39 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font29, paint35);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = labelBlock39.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, 0.05d, 90.0d, rectangleAnchor40);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.geom.Rectangle2D rectangle2D45 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, (-1.0d), (double) 2.0f, rectangleAnchor44);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets7.createInsetRectangle(rectangle2D45);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D46);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection1 = xYAreaRenderer0.getAnnotations();
        java.awt.Paint paint3 = xYAreaRenderer0.getSeriesPaint(7);
        java.lang.Boolean boolean5 = xYAreaRenderer0.getSeriesItemLabelsVisible(0);
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.lang.String str1 = combinedRangeXYPlot0.getPlotType();
        java.lang.Object obj2 = combinedRangeXYPlot0.clone();
        double double3 = combinedRangeXYPlot0.getGap();
        double double4 = combinedRangeXYPlot0.getGap();
        java.awt.Paint paint6 = combinedRangeXYPlot0.getQuadrantPaint(0);
        org.jfree.data.xy.XYDataset xYDataset7 = combinedRangeXYPlot0.getDataset();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Combined Range XYPlot" + "'", str1.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.0d + "'", double4 == 5.0d);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(xYDataset7);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        java.lang.Comparable[] comparableArray2 = null;
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection(xYSeries6);
        double[][] doubleArray8 = xYSeries6.toArray();
        try {
            org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[]) strArray1, comparableArray2, doubleArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DomainOrder.ASCENDING");
        boolean boolean2 = dateAxis1.isVerticalTickLabels();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = new org.jfree.chart.axis.SegmentedTimeline((long) '#', (int) (short) 0, 0);
        boolean boolean8 = segmentedTimeline6.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list11 = timeSeries10.getItems();
        segmentedTimeline6.setExceptionSegments(list11);
        int int13 = segmentedTimeline6.getSegmentsIncluded();
        java.util.List list14 = segmentedTimeline6.getExceptionSegments();
        boolean boolean15 = segmentedTimeline6.getAdjustForDaylightSaving();
        dateAxis1.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline6);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition17 = dateAxis1.getTickMarkPosition();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition17);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        xYPlot11.datasetChanged(datasetChangeEvent21);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit26 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int28 = numberTickUnit26.compareTo((java.lang.Object) 10);
        numberAxis24.setTickUnit(numberTickUnit26);
        numberAxis24.setMinorTickMarkInsideLength((-1.0f));
        numberAxis24.pan((double) 2147483647);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int39 = numberTickUnit37.compareTo((java.lang.Object) 10);
        numberAxis35.setTickUnit(numberTickUnit37);
        float float41 = numberAxis35.getMinorTickMarkInsideLength();
        java.awt.Shape shape42 = numberAxis35.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit46 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int48 = numberTickUnit46.compareTo((java.lang.Object) 10);
        numberAxis44.setTickUnit(numberTickUnit46);
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint59 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem60 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape56, (java.awt.Paint) color57, stroke58, paint59);
        numberAxis44.setRightArrow(shape56);
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape64 = numberAxis63.getLeftArrow();
        java.awt.Paint paint65 = numberAxis63.getTickLabelPaint();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray66 = new org.jfree.chart.axis.ValueAxis[] { numberAxis24, numberAxis35, numberAxis44, numberAxis63 };
        xYPlot11.setDomainAxes(valueAxisArray66);
        java.awt.Paint paint68 = xYPlot11.getRangeGridlinePaint();
        xYPlot11.setNoDataMessage("item");
        org.jfree.chart.plot.XYPlot xYPlot72 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection73 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot72.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection73);
        java.awt.Paint paint75 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo76 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean77 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint75, (java.lang.Object) basicProjectInfo76);
        xYPlot72.setRangeCrosshairPaint(paint75);
        xYPlot72.clearRangeMarkers(100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = null;
        java.awt.geom.Point2D point2D83 = null;
        xYPlot72.zoomDomainAxes((double) 0, plotRenderingInfo82, point2D83);
        org.jfree.chart.axis.ValueAxis valueAxis86 = xYPlot72.getDomainAxis((int) '#');
        org.jfree.chart.util.Layer layer88 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection89 = xYPlot72.getRangeMarkers(0, layer88);
        java.util.Collection collection90 = xYPlot11.getRangeMarkers((int) (byte) -1, layer88);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(valueAxisArray66);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNull(valueAxis86);
        org.junit.Assert.assertNotNull(layer88);
        org.junit.Assert.assertNull(collection89);
        org.junit.Assert.assertNull(collection90);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getDomainMinorGridlinePaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font3 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 6);
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font3);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 100);
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot0.getPieChart();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape10, (java.awt.Paint) color11, stroke12, paint13);
        multiplePiePlot0.setLegendItemShape(shape10);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        int int7 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CrosshairState crosshairState11 = new org.jfree.chart.plot.CrosshairState(false);
        crosshairState11.updateCrosshairX((double) (byte) 1);
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        crosshairState11.updateCrosshairPoint((double) 0, (double) 3600000L, (-33), (int) (byte) -1, (double) 13, 1.05d, plotOrientation20);
        categoryPlot0.setOrientation(plotOrientation20);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(plotOrientation20);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint10, (java.lang.Object) basicProjectInfo11);
        xYPlot7.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint14 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot7.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot0.getDomainMarkers(layer21);
        float float23 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((double) 11);
        axisState0.setMax((double) 24234L);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean6 = categoryPlot5.isDomainGridlinesVisible();
        categoryPlot5.setAnchorValue((double) 10, true);
        java.awt.Paint paint10 = categoryPlot5.getDomainGridlinePaint();
        barRenderer0.setShadowPaint(paint10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = barRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toRangeHeight((org.jfree.data.Range) dateRange1);
        boolean boolean4 = dateRange1.contains((double) (-1));
        org.jfree.data.Range range6 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange1, 0.2d);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean3 = categoryPlot2.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = categoryPlot2.getFixedLegendItems();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot2);
        waferMapPlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("");
        textLine9.removeFragment(textFragment11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape15 = numberAxis14.getLeftArrow();
        java.awt.Paint paint16 = numberAxis14.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = numberAxis14.getStandardTickUnits();
        boolean boolean18 = textLine9.equals((java.lang.Object) numberAxis14);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = textLine9.calculateDimensions(graphics2D19);
        size2D20.setHeight((double) 11);
        org.jfree.chart.text.TextFragment textFragment28 = new org.jfree.chart.text.TextFragment("");
        java.awt.Font font29 = textFragment28.getFont();
        java.awt.Paint paint30 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("", font29, paint30);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection33 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot32.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection33);
        java.awt.Paint paint35 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo36 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint35, (java.lang.Object) basicProjectInfo36);
        xYPlot32.setRangeCrosshairPaint(paint35);
        org.jfree.chart.block.LabelBlock labelBlock39 = new org.jfree.chart.block.LabelBlock("DateTickMarkPosition.MIDDLE", font29, paint35);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = labelBlock39.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, 0.05d, 90.0d, rectangleAnchor40);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor45 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection49 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot48.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection49);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = xYPlot48.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation52 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot48.setOrientation(plotOrientation52);
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list58 = timeSeries57.getItems();
        xYPlot48.drawRangeTickBands(graphics2D54, rectangle2D55, list58);
        java.awt.Graphics2D graphics2D60 = null;
        org.jfree.chart.entity.EntityCollection entityCollection61 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = new org.jfree.chart.ChartRenderingInfo(entityCollection61);
        java.awt.geom.Rectangle2D rectangle2D63 = chartRenderingInfo62.getChartArea();
        chartRenderingInfo62.clear();
        java.awt.geom.Rectangle2D rectangle2D65 = chartRenderingInfo62.getChartArea();
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list68 = timeSeries67.getItems();
        xYPlot48.drawRangeTickBands(graphics2D60, rectangle2D65, list68);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double71 = categoryAxis44.getCategoryJava2DCoordinate(categoryAnchor45, 7, (int) (short) 1, rectangle2D65, rectangleEdge70);
        java.awt.geom.Point2D point2D72 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 11, (double) 1561964399999L, rectangle2D65);
        org.jfree.chart.entity.EntityCollection entityCollection73 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo74 = new org.jfree.chart.ChartRenderingInfo(entityCollection73);
        java.awt.geom.Rectangle2D rectangle2D75 = chartRenderingInfo74.getChartArea();
        try {
            jFreeChart5.draw(graphics2D7, rectangle2D41, point2D72, chartRenderingInfo74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertNotNull(plotOrientation52);
        org.junit.Assert.assertNotNull(list58);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(list68);
        org.junit.Assert.assertNotNull(rectangleEdge70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(point2D72);
        org.junit.Assert.assertNotNull(rectangle2D75);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot2.setRangeZeroBaselinePaint((java.awt.Paint) color5);
        int int7 = color5.getBlue();
        xYAreaRenderer0.setSeriesItemLabelPaint((int) ' ', (java.awt.Paint) color5, false);
        boolean boolean10 = xYAreaRenderer0.isOutline();
        java.awt.Stroke stroke12 = xYAreaRenderer0.getSeriesOutlineStroke((int) (byte) 10);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation13 = null;
        boolean boolean14 = xYAreaRenderer0.removeAnnotation(xYAnnotation13);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 128 + "'", int7 == 128);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (-1), (double) 2147483647);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        boolean boolean8 = xYPlot7.isRangeCrosshairVisible();
        boolean boolean9 = xYAreaRenderer5.hasListener((java.util.EventListener) xYPlot7);
        boolean boolean10 = columnArrangement4.equals((java.lang.Object) xYAreaRenderer5);
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        xYAreaRenderer5.setSeriesItemLabelFont(0, font12, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 1.0d, false, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        double double5 = xYSeries3.getMaxY();
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.text.DateFormat dateFormat2 = null;
        java.text.DateFormat dateFormat3 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat2, dateFormat3);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator4, xYURLGenerator5);
        java.awt.Font font10 = xYStepRenderer6.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        boolean boolean13 = xYPlot12.isRangeCrosshairVisible();
        java.awt.Paint paint14 = xYPlot12.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis16.pan(0.0d);
        org.jfree.chart.plot.Marker marker19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYStepRenderer6.drawRangeMarker(graphics2D11, xYPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis16, marker19, rectangle2D20);
        boolean boolean22 = defaultDrawingSupplier0.equals((java.lang.Object) xYStepRenderer6);
        java.awt.Paint paint23 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 0, range1);
        double double3 = rectangleConstraint2.getHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint2.getWidthConstraintType();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        boolean boolean10 = xYStepRenderer5.getUseOutlinePaint();
        java.lang.Boolean boolean12 = xYStepRenderer5.getSeriesCreateEntities((int) (byte) 10);
        org.jfree.chart.LegendItem legendItem15 = xYStepRenderer5.getLegendItem((int) 'a', 7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertNull(legendItem15);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomRangeAxes(Double.NaN, plotRenderingInfo11, point2D12, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 10.0f);
        float float18 = intervalMarker17.getAlpha();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        java.text.DateFormat dateFormat21 = null;
        java.text.DateFormat dateFormat22 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator23 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat21, dateFormat22);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer25 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator23, xYURLGenerator24);
        java.awt.Font font29 = xYStepRenderer25.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        boolean boolean32 = xYPlot31.isRangeCrosshairVisible();
        java.awt.Paint paint33 = xYPlot31.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis35.pan(0.0d);
        org.jfree.chart.plot.Marker marker38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        xYStepRenderer25.drawRangeMarker(graphics2D30, xYPlot31, (org.jfree.chart.axis.ValueAxis) numberAxis35, marker38, rectangle2D39);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYStepRenderer25.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color42, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean46 = xYStepRenderer25.hasListener((java.util.EventListener) categoryPlot45);
        categoryPlot45.setCrosshairDatasetIndex(0);
        categoryPlot45.setDomainCrosshairVisible(true);
        java.awt.Paint paint51 = categoryPlot45.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot45.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation53 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot45.setDomainAxisLocation(axisLocation53);
        xYPlot0.setDomainAxisLocation(axisLocation53, true);
        org.jfree.chart.axis.AxisLocation axisLocation57 = xYPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.8f + "'", float18 == 0.8f);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNotNull(axisLocation57);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.awt.Paint paint3 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint3, (java.lang.Object) basicProjectInfo4);
        xYPlot0.setRangeCrosshairPaint(paint3);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = xYPlot0.getAxisOffset();
        xYPlot0.setRangeMinorGridlinesVisible(true);
        java.awt.Color color16 = java.awt.Color.getHSBColor(0.0f, (float) 100L, (float) '#');
        xYPlot0.setDomainMinorGridlinePaint((java.awt.Paint) color16);
        java.text.DateFormat dateFormat19 = null;
        java.text.DateFormat dateFormat20 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator21 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat19, dateFormat20);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator22 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer23 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator21, xYURLGenerator22);
        java.awt.Shape shape24 = xYStepRenderer23.getBaseShape();
        java.awt.Paint paint26 = xYStepRenderer23.lookupLegendTextPaint((int) 'a');
        xYStepRenderer23.setBaseLinesVisible(true);
        xYStepRenderer23.setUseFillPaint(false);
        xYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer23);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(paint26);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) itemLabelAnchor1);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        java.lang.Object obj7 = null;
        boolean boolean8 = textAnchor6.equals(obj7);
        try {
            java.awt.Shape shape9 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", graphics2D1, (-1.0f), 2.0f, textAnchor4, 0.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test67");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, (double) (byte) 10, plotRenderingInfo4, point2D5);
        int int7 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRendererForDataset(categoryDataset8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot0.getDomainMarkers(2, layer11);
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test68");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.util.Collection collection1 = xYAreaRenderer0.getAnnotations();
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYAreaRenderer0.setBaseItemLabelFont(font2);
        boolean boolean4 = xYAreaRenderer0.getPlotArea();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("DomainOrder.ASCENDING");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition8 = dateAxis7.getTickMarkPosition();
        java.util.Date date9 = dateAxis7.getMaximumDate();
        java.lang.String str10 = dateTickUnit5.dateToString(date9);
        int int11 = dateTickUnit5.getCalendarField();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType12 = dateTickUnit5.getUnitType();
        int int13 = dateTickUnit5.getRollMultiple();
        boolean boolean14 = xYAreaRenderer0.equals((java.lang.Object) int13);
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "12/31/69 4:00 PM" + "'", str10.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertNotNull(dateTickUnitType12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test69");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getIgnoreNullValues();
        java.awt.Paint paint3 = piePlot1.getShadowPaint();
        java.awt.Paint paint4 = piePlot1.getBaseSectionOutlinePaint();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = null;
        piePlot1.axisChanged(axisChangeEvent5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test70");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot0.setOrientation(plotOrientation4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list10 = timeSeries9.getItems();
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        java.awt.geom.Rectangle2D rectangle2D15 = chartRenderingInfo14.getChartArea();
        chartRenderingInfo14.clear();
        java.awt.geom.Rectangle2D rectangle2D17 = chartRenderingInfo14.getChartArea();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        java.util.List list20 = timeSeries19.getItems();
        xYPlot0.drawRangeTickBands(graphics2D12, rectangle2D17, list20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace22);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test71");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        java.awt.Font font9 = xYStepRenderer5.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        boolean boolean12 = xYPlot11.isRangeCrosshairVisible();
        java.awt.Paint paint13 = xYPlot11.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis15.pan(0.0d);
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYStepRenderer5.drawRangeMarker(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis15, marker18, rectangle2D19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        xYPlot11.datasetChanged(datasetChangeEvent21);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit26 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int28 = numberTickUnit26.compareTo((java.lang.Object) 10);
        numberAxis24.setTickUnit(numberTickUnit26);
        numberAxis24.setMinorTickMarkInsideLength((-1.0f));
        numberAxis24.pan((double) 2147483647);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int39 = numberTickUnit37.compareTo((java.lang.Object) 10);
        numberAxis35.setTickUnit(numberTickUnit37);
        float float41 = numberAxis35.getMinorTickMarkInsideLength();
        java.awt.Shape shape42 = numberAxis35.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit46 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int48 = numberTickUnit46.compareTo((java.lang.Object) 10);
        numberAxis44.setTickUnit(numberTickUnit46);
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint59 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem60 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape56, (java.awt.Paint) color57, stroke58, paint59);
        numberAxis44.setRightArrow(shape56);
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape64 = numberAxis63.getLeftArrow();
        java.awt.Paint paint65 = numberAxis63.getTickLabelPaint();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray66 = new org.jfree.chart.axis.ValueAxis[] { numberAxis24, numberAxis35, numberAxis44, numberAxis63 };
        xYPlot11.setDomainAxes(valueAxisArray66);
        java.awt.Paint paint68 = xYPlot11.getRangeGridlinePaint();
        java.awt.Paint paint69 = xYPlot11.getDomainGridlinePaint();
        org.jfree.chart.util.Layer layer70 = null;
        java.util.Collection collection71 = xYPlot11.getRangeMarkers(layer70);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = xYPlot11.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(valueAxisArray66);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNull(collection71);
        org.junit.Assert.assertNotNull(rectangleEdge72);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test72");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) true, true);
        barRenderer0.setAutoPopulateSeriesPaint(false);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        double double10 = piePlot9.getStartAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = piePlot9.getLabelPadding();
        java.awt.Paint paint12 = piePlot9.getBaseSectionOutlinePaint();
        boolean boolean13 = piePlot9.getLabelLinksVisible();
        java.text.DateFormat dateFormat15 = null;
        java.text.DateFormat dateFormat16 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator17 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat15, dateFormat16);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer19 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator17, xYURLGenerator18);
        java.awt.Font font23 = xYStepRenderer19.getItemLabelFont((-1), (int) '#', true);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        boolean boolean26 = xYPlot25.isRangeCrosshairVisible();
        java.awt.Paint paint27 = xYPlot25.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis29.pan(0.0d);
        org.jfree.chart.plot.Marker marker32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        xYStepRenderer19.drawRangeMarker(graphics2D24, xYPlot25, (org.jfree.chart.axis.ValueAxis) numberAxis29, marker32, rectangle2D33);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent35 = null;
        xYPlot25.datasetChanged(datasetChangeEvent35);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit40 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int42 = numberTickUnit40.compareTo((java.lang.Object) 10);
        numberAxis38.setTickUnit(numberTickUnit40);
        numberAxis38.setMinorTickMarkInsideLength((-1.0f));
        numberAxis38.pan((double) 2147483647);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit51 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int53 = numberTickUnit51.compareTo((java.lang.Object) 10);
        numberAxis49.setTickUnit(numberTickUnit51);
        float float55 = numberAxis49.getMinorTickMarkInsideLength();
        java.awt.Shape shape56 = numberAxis49.getLeftArrow();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit60 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        int int62 = numberTickUnit60.compareTo((java.lang.Object) 10);
        numberAxis58.setTickUnit(numberTickUnit60);
        java.awt.Shape shape70 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), (float) (-1));
        java.awt.Color color71 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Stroke stroke72 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint73 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem74 = new org.jfree.chart.LegendItem("hi!", "{0}: ({1}, {2})", "", "", shape70, (java.awt.Paint) color71, stroke72, paint73);
        numberAxis58.setRightArrow(shape70);
        org.jfree.chart.axis.NumberAxis numberAxis77 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape78 = numberAxis77.getLeftArrow();
        java.awt.Paint paint79 = numberAxis77.getTickLabelPaint();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray80 = new org.jfree.chart.axis.ValueAxis[] { numberAxis38, numberAxis49, numberAxis58, numberAxis77 };
        xYPlot25.setDomainAxes(valueAxisArray80);
        java.awt.Paint paint82 = xYPlot25.getRangeGridlinePaint();
        java.awt.Paint paint83 = xYPlot25.getDomainGridlinePaint();
        piePlot9.setLabelShadowPaint(paint83);
        barRenderer0.setSeriesOutlinePaint(3, paint83);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 0.0f + "'", float55 == 0.0f);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(shape70);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(shape78);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(valueAxisArray80);
        org.junit.Assert.assertNotNull(paint82);
        org.junit.Assert.assertNotNull(paint83);
    }
}

