import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        java.lang.Number number2 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 43626L);
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        java.lang.Object obj8 = null;
        boolean boolean9 = timeSeriesDataItem6.equals(obj8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        double double6 = timeSeries3.getMinY();
        java.lang.Class class7 = timeSeries3.getTimePeriodClass();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setNotify(false);
        timeSeries3.setDomainDescription("10-June-2019");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.util.Date date14 = month13.getStart();
        boolean boolean16 = month13.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month13.next();
        long long18 = month13.getFirstMillisecond();
        long long19 = month13.getLastMillisecond();
        int int20 = month13.getMonth();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        java.util.Date date26 = month25.getStart();
        boolean boolean28 = month25.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month25.next();
        long long30 = month25.getFirstMillisecond();
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) month25, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month13, (org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year34, (double) (byte) 100);
        timeSeries3.setMaximumItemAge((long) 2147483647);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("8");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
        java.util.Calendar calendar10 = null;
        fixedMillisecond7.peg(calendar10);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) (byte) 1);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        java.util.List list16 = timeSeries3.getItems();
        timeSeries3.setDescription("June 2019");
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.addAndOrUpdate(timeSeries22);
        boolean boolean25 = timeSeries24.getNotify();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.util.Date date27 = month26.getStart();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date27);
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 100, true);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) (-1.0f));
        timeSeries3.setDescription("");
        long long38 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeries3.getNextTimePeriod();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 9223372036854775807L + "'", long38 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("October 97");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test007");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 0L);
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "June 2019", "");
//        timeSeries8.removeAgedItems(true);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries8.getDataItem((int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test008");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries3.setDescription("");
//        java.lang.String str6 = timeSeries3.getDomainDescription();
//        java.lang.String str7 = timeSeries3.getDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        int int11 = day8.compareTo((java.lang.Object) 0L);
//        java.lang.String str12 = day8.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        long long14 = day8.getMiddleMillisecond();
//        java.lang.Number number15 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        long long16 = day8.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560193199999L + "'", long14 == 1560193199999L);
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getFirstMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(12, year2);
        long long5 = year2.getFirstMillisecond();
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) ' ', year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getStart();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
        java.util.Date date8 = month6.getEnd();
        int int9 = fixedMillisecond1.compareTo((java.lang.Object) date8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond1.next();
        java.util.Date date11 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean13 = fixedMillisecond1.equals((java.lang.Object) day12);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
        double double6 = timeSeries3.getMaxY();
        long long7 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int11 = day8.compareTo((java.lang.Object) 0L);
        int int12 = day8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
        java.lang.Class<?> wildcardClass14 = regularTimePeriod13.getClass();
        timeSeries3.delete(regularTimePeriod13);
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test012");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 10);
//        long long6 = day0.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getMiddleMillisecond(calendar6);
        long long8 = fixedMillisecond1.getSerialIndex();
        long long9 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 0L);
        int int4 = day0.getYear();
        java.util.Date date5 = day0.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries10.setDescription("");
        double double13 = timeSeries10.getMinY();
        java.lang.Class class14 = timeSeries10.getTimePeriodClass();
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        java.util.Date date17 = month16.getStart();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
        timeSeries10.add(regularTimePeriod19, (double) 2019);
        boolean boolean22 = year6.equals((java.lang.Object) timeSeries10);
        java.lang.String str23 = timeSeries10.getDomainDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        boolean boolean3 = month0.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        long long5 = month0.getLastMillisecond();
        int int6 = month0.getYearValue();
        java.lang.String str7 = month0.toString();
        long long8 = month0.getLastMillisecond();
        long long9 = month0.getFirstMillisecond();
        java.util.Date date10 = month0.getStart();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date10);
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date10, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertNotNull(date10);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test016");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
//        timeSeries3.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries11.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        java.util.Calendar calendar18 = null;
//        fixedMillisecond15.peg(calendar18);
//        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (byte) 1);
//        java.util.Collection collection22 = timeSeries11.getTimePeriods();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        java.util.Date date25 = month24.getStart();
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date25, timeZone26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date25);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries34.setDescription("");
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day37.next();
//        int int40 = day37.compareTo((java.lang.Object) 0L);
//        int int41 = day37.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day37.previous();
//        long long43 = day37.getSerialIndex();
//        java.lang.Number number44 = null;
//        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) day37, number44, false);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = day47.next();
//        int int50 = day47.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day47, (double) 10);
//        boolean boolean54 = timeSeriesDataItem52.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries34.addOrUpdate(timeSeriesDataItem52);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = timeSeriesDataItem55.getPeriod();
//        java.util.Date date57 = regularTimePeriod56.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond(date57);
//        boolean boolean59 = month30.equals((java.lang.Object) fixedMillisecond58);
//        java.util.Date date60 = fixedMillisecond58.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, (double) 12);
//        boolean boolean63 = timeSeries3.equals((java.lang.Object) fixedMillisecond58);
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 43626L + "'", long43 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNull(timeSeriesDataItem62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test017");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
//        java.lang.Object obj6 = timeSeries3.clone();
//        timeSeries3.setRangeDescription("8");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(8);
//        java.lang.String str11 = year10.toString();
//        boolean boolean12 = timeSeries3.equals((java.lang.Object) str11);
//        double double13 = timeSeries3.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries17.setDescription("");
//        timeSeries17.setDomainDescription("June 2019");
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.addAndOrUpdate(timeSeries17);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        java.util.Date date24 = month23.getStart();
//        boolean boolean26 = month23.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.next();
//        int int30 = day27.compareTo((java.lang.Object) 0L);
//        java.lang.String str31 = day27.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day27.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day27.previous();
//        boolean boolean34 = month23.equals((java.lang.Object) regularTimePeriod33);
//        int int35 = month23.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class40 = timeSeries39.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries37.addAndOrUpdate(timeSeries39);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 100L);
//        java.lang.Object obj46 = timeSeries39.clone();
//        timeSeries39.setDomainDescription("10-June-2019");
//        int int49 = timeSeries39.getMaximumItemCount();
//        boolean boolean50 = month23.equals((java.lang.Object) timeSeries39);
//        long long51 = month23.getFirstMillisecond();
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month23);
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "8" + "'", str11.equals("8"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10-June-2019" + "'", str31.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertNull(class40);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertNotNull(obj46);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2147483647 + "'", int49 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1559372400000L + "'", long51 == 1559372400000L);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test019");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 100L);
//        java.lang.Object obj10 = timeSeries3.clone();
//        timeSeries3.setDomainDescription("10-June-2019");
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        java.util.Date date14 = month13.getStart();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month15.next();
//        timeSeries3.setKey((java.lang.Comparable) month15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.getDataItem(0);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.next();
//        int int23 = day20.compareTo((java.lang.Object) 0L);
//        java.lang.String str24 = day20.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day20.next();
//        long long26 = day20.getMiddleMillisecond();
//        java.lang.String str27 = day20.toString();
//        long long28 = day20.getSerialIndex();
//        java.lang.String str29 = day20.toString();
//        boolean boolean30 = timeSeries3.equals((java.lang.Object) str29);
//        boolean boolean31 = timeSeries3.getNotify();
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10-June-2019" + "'", str24.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560193199999L + "'", long26 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "10-June-2019" + "'", str27.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43626L + "'", long28 == 43626L);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "10-June-2019" + "'", str29.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1);
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test021");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.util.Date date1 = month0.getStart();
//        boolean boolean3 = month0.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int7 = day4.compareTo((java.lang.Object) 0L);
//        java.lang.String str8 = day4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day4.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day4.previous();
//        boolean boolean11 = month0.equals((java.lang.Object) regularTimePeriod10);
//        int int12 = month0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month0.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        boolean boolean3 = month0.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        boolean boolean6 = month0.equals((java.lang.Object) year4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 1.0f);
        long long14 = fixedMillisecond9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond9.next();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond9.getLastMillisecond(calendar16);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        int int25 = day22.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (double) 10);
        boolean boolean29 = timeSeriesDataItem27.equals((java.lang.Object) 100L);
        timeSeries21.add(timeSeriesDataItem27, false);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year((int) (byte) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.previous();
        int int35 = timeSeriesDataItem27.compareTo((java.lang.Object) year33);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        java.util.Date date41 = month40.getStart();
        boolean boolean43 = month40.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month40.next();
        long long45 = month40.getFirstMillisecond();
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) month40, 0.0d);
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timeSeries37.removePropertyChangeListener(propertyChangeListener48);
        int int50 = year33.compareTo((java.lang.Object) propertyChangeListener48);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int50);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        java.util.Date date53 = month52.getStart();
        boolean boolean55 = month52.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month52.next();
        long long57 = month52.getLastMillisecond();
        int int58 = month52.getYearValue();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day59.next();
        int int62 = day59.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day59, (double) 10);
        int int65 = month52.compareTo((java.lang.Object) day59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = day59.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries51.addOrUpdate(regularTimePeriod66, (java.lang.Number) 24234L);
        int int69 = fixedMillisecond9.compareTo((java.lang.Object) regularTimePeriod66);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1559372400000L + "'", long45 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1561964399999L + "'", long57 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNull(timeSeriesDataItem68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 0L);
        int int4 = day0.getYear();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries10.addAndOrUpdate(timeSeries12);
        timeSeries10.clear();
        java.lang.Comparable comparable16 = timeSeries10.getKey();
        timeSeries10.setNotify(true);
        int int19 = timeSeries10.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener20);
        boolean boolean22 = day0.equals((java.lang.Object) timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2147483647 + "'", int19 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test024");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries3.setDescription("");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
//        int int9 = day6.compareTo((java.lang.Object) 0L);
//        int int10 = day6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
//        long long12 = day6.getSerialIndex();
//        java.lang.Number number13 = null;
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day6, number13, false);
//        org.jfree.data.time.SerialDate serialDate16 = day6.getSerialDate();
//        int int17 = day6.getMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test025");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries3.setDescription("");
//        timeSeries3.setDomainDescription("June 2019");
//        java.lang.Object obj8 = timeSeries3.clone();
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        int int13 = day10.compareTo((java.lang.Object) 0L);
//        int int14 = day10.getYear();
//        java.lang.String str15 = day10.toString();
//        java.lang.Number number16 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Object obj17 = null;
//        boolean boolean18 = day10.equals(obj17);
//        java.lang.String str19 = day10.toString();
//        java.util.Date date20 = day10.getEnd();
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date20);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        timeSeries3.setDomainDescription("June 2019");
        java.lang.Object obj8 = timeSeries3.clone();
        java.lang.Class class9 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        int int13 = day10.compareTo((java.lang.Object) 0L);
        int int14 = day10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day10.previous();
        timeSeries3.add(regularTimePeriod15, (double) (-1L), false);
        timeSeries3.removeAgedItems(0L, true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        double double6 = timeSeries3.getMinY();
        java.lang.Class class7 = timeSeries3.getTimePeriodClass();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setNotify(false);
        timeSeries3.setDomainDescription("10-June-2019");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.util.Date date14 = month13.getStart();
        boolean boolean16 = month13.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month13.next();
        long long18 = month13.getFirstMillisecond();
        long long19 = month13.getLastMillisecond();
        int int20 = month13.getMonth();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        java.util.Date date26 = month25.getStart();
        boolean boolean28 = month25.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month25.next();
        long long30 = month25.getFirstMillisecond();
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) month25, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month13, (org.jfree.data.time.RegularTimePeriod) month25);
        java.util.Date date34 = month25.getEnd();
        java.util.Date date35 = month25.getEnd();
        java.util.Calendar calendar36 = null;
        try {
            long long37 = month25.getFirstMillisecond(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date35);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
        java.util.Calendar calendar10 = null;
        fixedMillisecond7.peg(calendar10);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) (byte) 1);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        java.util.List list16 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries20.setDescription("");
        timeSeries20.setDomainDescription("June 2019");
        java.lang.Object obj25 = timeSeries20.clone();
        java.util.Collection collection26 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        long long27 = timeSeries20.getMaximumItemAge();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.util.Date date29 = month28.getStart();
        int int31 = month28.compareTo((java.lang.Object) true);
        long long32 = month28.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month28.next();
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) month28, (double) 100.0f, true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries20.removeChangeListener(seriesChangeListener37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = null;
        try {
            timeSeries20.add(regularTimePeriod39, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223372036854775807L + "'", long27 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, (int) (short) 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        long long5 = fixedMillisecond1.getSerialIndex();
        java.util.Date date6 = fixedMillisecond1.getEnd();
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test031");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries3.setDescription("");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
//        int int9 = day6.compareTo((java.lang.Object) 0L);
//        int int10 = day6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
//        long long12 = day6.getSerialIndex();
//        java.lang.Number number13 = null;
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day6, number13, false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
//        int int19 = day16.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) 10);
//        boolean boolean23 = timeSeriesDataItem21.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries3.addOrUpdate(timeSeriesDataItem21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeriesDataItem24.getPeriod();
//        timeSeriesDataItem24.setValue((java.lang.Number) 1546329600000L);
//        timeSeriesDataItem24.setValue((java.lang.Number) 2019L);
//        boolean boolean30 = timeSeriesDataItem24.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem24, "org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]", "Value");
//        timeSeries33.setDomainDescription("Overwritten values from: 100.0");
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries39.setDescription("");
//        double double42 = timeSeries39.getMinY();
//        java.lang.Class class43 = timeSeries39.getTimePeriodClass();
//        timeSeries39.fireSeriesChanged();
//        timeSeries39.setNotify(false);
//        timeSeries39.setDomainDescription("10-June-2019");
//        double double49 = timeSeries39.getMinY();
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        java.util.Date date51 = month50.getStart();
//        boolean boolean53 = month50.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        long long55 = year54.getFirstMillisecond();
//        boolean boolean56 = month50.equals((java.lang.Object) year54);
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean56);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.util.Calendar calendar60 = null;
//        long long61 = fixedMillisecond59.getFirstMillisecond(calendar60);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries57.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (java.lang.Number) 1.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond59.previous();
//        timeSeries39.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (java.lang.Number) (short) -1, true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
//        org.junit.Assert.assertNull(class43);
//        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1546329600000L + "'", long55 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 10L + "'", long61 == 10L);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        java.util.List list4 = timeSeries3.getItems();
        java.lang.String str5 = timeSeries3.getRangeDescription();
        long long6 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries10.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Calendar calendar17 = null;
        fixedMillisecond14.peg(calendar17);
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) (byte) 1);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond14.getFirstMillisecond(calendar21);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 1L);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.lang.Object obj6 = timeSeries3.clone();
        timeSeries3.setRangeDescription("8");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(8);
        java.lang.String str11 = year10.toString();
        boolean boolean12 = timeSeries3.equals((java.lang.Object) str11);
        double double13 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries17.setDescription("");
        timeSeries17.setDomainDescription("June 2019");
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.addAndOrUpdate(timeSeries17);
        java.lang.Object obj23 = timeSeries3.clone();
        timeSeries3.setMaximumItemCount(10);
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "8" + "'", str11.equals("8"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(obj23);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test034");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries4.setDescription("");
//        timeSeries4.setDomainDescription("June 2019");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.next();
//        int int12 = day9.compareTo((java.lang.Object) 0L);
//        java.lang.String str13 = day9.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day9.next();
//        long long15 = day9.getMiddleMillisecond();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        java.util.Date date18 = month17.getStart();
//        boolean boolean20 = month17.equals((java.lang.Object) (short) 100);
//        java.util.Date date21 = month17.getStart();
//        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month17, (double) 1561964399999L, true);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.util.Date date26 = month25.getEnd();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
//        boolean boolean28 = month17.equals((java.lang.Object) date26);
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date26, timeZone29);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560193199999L + "'", long15 == 1560193199999L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 0L);
        int int4 = day0.getYear();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 5);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) 12);
        timeSeriesDataItem13.setSelected(true);
        timeSeriesDataItem13.setValue((java.lang.Number) 1560150000000L);
        int int18 = day0.compareTo((java.lang.Object) timeSeriesDataItem13);
        timeSeriesDataItem13.setValue((java.lang.Number) (byte) 100);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries6.addAndOrUpdate(timeSeries8);
        boolean boolean11 = timeSeries10.getNotify();
        boolean boolean12 = fixedMillisecond3.equals((java.lang.Object) timeSeries10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries2.getDataItem(regularTimePeriod14);
        timeSeries2.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test039");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries3.setDescription("");
//        double double6 = timeSeries3.getMinY();
//        java.lang.Class class7 = timeSeries3.getTimePeriodClass();
//        timeSeries3.fireSeriesChanged();
//        timeSeries3.setNotify(false);
//        timeSeries3.setMaximumItemAge(1560150000000L);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries16.setDescription("");
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
//        int int22 = day19.compareTo((java.lang.Object) 0L);
//        int int23 = day19.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day19.previous();
//        long long25 = day19.getSerialIndex();
//        java.lang.Number number26 = null;
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day19, number26, false);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.next();
//        int int32 = day29.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (double) 10);
//        boolean boolean36 = timeSeriesDataItem34.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries16.addOrUpdate(timeSeriesDataItem34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = timeSeriesDataItem37.getPeriod();
//        timeSeriesDataItem37.setValue((java.lang.Number) 1546329600000L);
//        timeSeriesDataItem37.setValue((java.lang.Number) 2019L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate(timeSeriesDataItem37);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertNull(class7);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
        java.util.Calendar calendar10 = null;
        fixedMillisecond7.peg(calendar10);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) (byte) 1);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        java.util.List list16 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries20.setDescription("");
        timeSeries20.setDomainDescription("June 2019");
        java.lang.Object obj25 = timeSeries20.clone();
        java.util.Collection collection26 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        long long27 = timeSeries20.getMaximumItemAge();
        timeSeries20.clear();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223372036854775807L + "'", long27 == 9223372036854775807L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getStart();
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
        java.util.Calendar calendar10 = null;
        fixedMillisecond7.peg(calendar10);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) (byte) 1);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        java.util.List list16 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries20.setDescription("");
        timeSeries20.setDomainDescription("June 2019");
        java.lang.Object obj25 = timeSeries20.clone();
        java.util.Collection collection26 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        int int27 = timeSeries3.getItemCount();
        timeSeries3.clear();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener29);
        timeSeries3.setMaximumItemAge(0L);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year33.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year33.previous();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(8);
        boolean boolean8 = fixedMillisecond1.equals((java.lang.Object) year7);
        java.util.Date date9 = year7.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        int int11 = year10.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test044");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        boolean boolean3 = day0.equals((java.lang.Object) '4');
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int7 = day4.compareTo((java.lang.Object) 0L);
//        java.lang.String str8 = day4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day4.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day4.previous();
//        boolean boolean11 = day0.equals((java.lang.Object) regularTimePeriod10);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.addAndOrUpdate(timeSeries15);
//        timeSeries17.clear();
//        timeSeries17.fireSeriesChanged();
//        int int20 = day0.compareTo((java.lang.Object) timeSeries17);
//        timeSeries17.setRangeDescription("1");
//        long long23 = timeSeries17.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries25.addAndOrUpdate(timeSeries27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.next();
//        int int33 = day30.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) 10);
//        timeSeries29.delete((org.jfree.data.time.RegularTimePeriod) day30);
//        java.lang.Class class37 = timeSeries29.getTimePeriodClass();
//        java.lang.String str38 = timeSeries29.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries17.addAndOrUpdate(timeSeries29);
//        boolean boolean40 = timeSeries17.getNotify();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
//        org.junit.Assert.assertNull(class28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNull(class37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Value" + "'", str38.equals("Value"));
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        int int3 = month0.compareTo((java.lang.Object) true);
        int int4 = month0.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 9223372036854775807L);
        timeSeriesDataItem6.setValue((java.lang.Number) 5);
        java.lang.Object obj9 = timeSeriesDataItem6.clone();
        java.lang.Object obj10 = timeSeriesDataItem6.clone();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(5, 2147483647);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) 5);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        long long17 = year15.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class22 = timeSeries21.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries19.addAndOrUpdate(timeSeries21);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 100L);
        java.lang.Class class28 = timeSeries21.getTimePeriodClass();
        int int29 = timeSeries21.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries21.removePropertyChangeListener(propertyChangeListener30);
        int int32 = year15.compareTo((java.lang.Object) propertyChangeListener30);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class37 = timeSeries36.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries34.addAndOrUpdate(timeSeries36);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) 100L);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.next();
        int int46 = day43.compareTo((java.lang.Object) 0L);
        int int47 = day43.getYear();
        java.util.Date date48 = day43.getEnd();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date48);
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        java.lang.String str51 = month50.toString();
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) month49, (org.jfree.data.time.RegularTimePeriod) month50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year53.next();
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day55.next();
        int int58 = day55.compareTo((java.lang.Object) 0L);
        int int59 = day55.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day55.previous();
        boolean boolean61 = year53.equals((java.lang.Object) regularTimePeriod60);
        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) year53, Double.NaN);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 4);
        boolean boolean66 = year15.equals((java.lang.Object) 4);
        boolean boolean67 = timeSeriesDataItem6.equals((java.lang.Object) 4);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNull(class22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2147483647 + "'", int29 == 2147483647);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNull(class37);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "June 2019" + "'", str51.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getStart();
        boolean boolean7 = month4.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        boolean boolean10 = month4.equals((java.lang.Object) year8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 1.0f);
        long long18 = fixedMillisecond13.getFirstMillisecond();
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond13.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond13.getTime();
        boolean boolean22 = month3.equals((java.lang.Object) fixedMillisecond13);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getStart();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
        java.util.Date date8 = month6.getEnd();
        int int9 = fixedMillisecond1.compareTo((java.lang.Object) date8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) (-6.19149024E13d));
        timeSeriesDataItem12.setValue((java.lang.Number) 8L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        double double6 = timeSeries3.getMinY();
        java.lang.Class class7 = timeSeries3.getTimePeriodClass();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setNotify(false);
        timeSeries3.setDomainDescription("10-June-2019");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.util.Date date14 = month13.getStart();
        boolean boolean16 = month13.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month13.next();
        long long18 = month13.getFirstMillisecond();
        long long19 = month13.getLastMillisecond();
        int int20 = month13.getMonth();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        java.util.Date date26 = month25.getStart();
        boolean boolean28 = month25.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month25.next();
        long long30 = month25.getFirstMillisecond();
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) month25, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month13, (org.jfree.data.time.RegularTimePeriod) month25);
        java.util.Date date34 = month25.getEnd();
        int int35 = month25.getYearValue();
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test049");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        boolean boolean3 = day0.equals((java.lang.Object) '4');
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int7 = day4.compareTo((java.lang.Object) 0L);
//        java.lang.String str8 = day4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day4.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day4.previous();
//        boolean boolean11 = day0.equals((java.lang.Object) regularTimePeriod10);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.addAndOrUpdate(timeSeries15);
//        timeSeries17.clear();
//        timeSeries17.fireSeriesChanged();
//        int int20 = day0.compareTo((java.lang.Object) timeSeries17);
//        timeSeries17.setRangeDescription("1");
//        long long23 = timeSeries17.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries25.addAndOrUpdate(timeSeries27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.next();
//        int int33 = day30.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) 10);
//        timeSeries29.delete((org.jfree.data.time.RegularTimePeriod) day30);
//        java.lang.Class class37 = timeSeries29.getTimePeriodClass();
//        java.lang.String str38 = timeSeries29.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries17.addAndOrUpdate(timeSeries29);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries17.getDataItem(4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
//        org.junit.Assert.assertNull(class28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNull(class37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Value" + "'", str38.equals("Value"));
//        org.junit.Assert.assertNotNull(timeSeries39);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test050");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries4.setDescription("");
//        double double7 = timeSeries4.getMinY();
//        java.lang.Class class8 = timeSeries4.getTimePeriodClass();
//        timeSeries4.fireSeriesChanged();
//        int int10 = day0.compareTo((java.lang.Object) timeSeries4);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
//        int int14 = day11.compareTo((java.lang.Object) 0L);
//        java.lang.String str15 = day11.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.previous();
//        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day11, (double) 8, false);
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        int int4 = year0.compareTo((java.lang.Object) day3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        int int6 = year0.getYear();
        long long7 = year0.getFirstMillisecond();
        java.lang.String str8 = year0.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test053");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries3.setDescription("");
//        double double6 = timeSeries3.getMinY();
//        java.lang.Class class7 = timeSeries3.getTimePeriodClass();
//        timeSeries3.setMaximumItemAge(0L);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries13.setDescription("");
//        timeSeries13.setDomainDescription("June 2019");
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
//        int int21 = day18.compareTo((java.lang.Object) 0L);
//        java.lang.String str22 = day18.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day18.next();
//        long long24 = day18.getMiddleMillisecond();
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        timeSeries13.removeAgedItems((long) 0, true);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries32.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond36.getFirstMillisecond(calendar37);
//        java.util.Calendar calendar39 = null;
//        fixedMillisecond36.peg(calendar39);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) (byte) 1);
//        long long43 = fixedMillisecond36.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) (byte) 100);
//        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) 4);
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries3.addAndOrUpdate(timeSeries13);
//        timeSeries48.setMaximumItemCount(1);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertNull(class7);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560193199999L + "'", long24 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
//        org.junit.Assert.assertNotNull(timeSeries48);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test055");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries3.setDescription("");
//        timeSeries3.setDomainDescription("June 2019");
//        java.lang.Object obj8 = timeSeries3.clone();
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        int int13 = day10.compareTo((java.lang.Object) 0L);
//        int int14 = day10.getYear();
//        java.lang.String str15 = day10.toString();
//        java.lang.Number number16 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        timeSeries3.setDomainDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
//        java.lang.Number number21 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond19.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 1577865599999L);
//        timeSeries3.setNotify(false);
//        timeSeries3.setMaximumItemAge(1L);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 100L);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        int int13 = day10.compareTo((java.lang.Object) 0L);
        int int14 = day10.getYear();
        java.util.Date date15 = day10.getEnd();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) month17);
        try {
            timeSeries19.delete(5, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries19);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test057");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries3.setDescription("");
//        timeSeries3.setDomainDescription("June 2019");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        int int11 = day8.compareTo((java.lang.Object) 0L);
//        java.lang.String str12 = day8.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        long long14 = day8.getMiddleMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day8);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener16);
//        int int18 = timeSeries3.getMaximumItemCount();
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560193199999L + "'", long14 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        timeSeries3.setDomainDescription("June 2019");
        timeSeries3.setDescription("");
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.util.Date date13 = month12.getStart();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 6);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month14);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) (byte) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        long long23 = year21.getLastMillisecond();
        java.lang.Object obj24 = null;
        boolean boolean25 = year21.equals(obj24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(2, year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year21.previous();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) 100);
        int int30 = year21.getYear();
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62104204800001L) + "'", long23 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
        java.util.Calendar calendar10 = null;
        fixedMillisecond7.peg(calendar10);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) (byte) 1);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        java.util.List list16 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries20.setDescription("");
        timeSeries20.setDomainDescription("June 2019");
        java.lang.Object obj25 = timeSeries20.clone();
        java.util.Collection collection26 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        java.util.List list27 = timeSeries3.getItems();
        boolean boolean28 = timeSeries3.getNotify();
        try {
            timeSeries3.delete(0, 9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        double double6 = timeSeries3.getMinY();
        java.lang.Class class7 = timeSeries3.getTimePeriodClass();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setNotify(false);
        timeSeries3.setDomainDescription("10-June-2019");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.util.Date date14 = month13.getStart();
        boolean boolean16 = month13.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month13.next();
        long long18 = month13.getFirstMillisecond();
        long long19 = month13.getLastMillisecond();
        int int20 = month13.getMonth();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        java.util.Date date26 = month25.getStart();
        boolean boolean28 = month25.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month25.next();
        long long30 = month25.getFirstMillisecond();
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) month25, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month13, (org.jfree.data.time.RegularTimePeriod) month25);
        boolean boolean34 = timeSeries3.isEmpty();
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        timeSeries3.setDomainDescription("June 2019");
        timeSeries3.setRangeDescription("hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getStart();
        long long12 = month10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.previous();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        int int17 = day14.compareTo((java.lang.Object) 0L);
        int int18 = day14.getYear();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo19 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day14, seriesChangeInfo19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day14.previous();
        int int22 = day14.getMonth();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        int int26 = day23.compareTo((java.lang.Object) 0L);
        int int27 = day23.getYear();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo28 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day23, seriesChangeInfo28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day23.previous();
        boolean boolean31 = day14.equals((java.lang.Object) day23);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) day14);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day14);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(timeSeries32);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        long long5 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
        java.lang.String str7 = regularTimePeriod6.toString();
        long long8 = regularTimePeriod6.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str7.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9L + "'", long8 == 9L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 10);
        boolean boolean6 = timeSeriesDataItem5.isSelected();
        timeSeriesDataItem5.setSelected(true);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries12.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.next();
        java.util.Calendar calendar18 = null;
        fixedMillisecond16.peg(calendar18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond16.previous();
        timeSeries12.add(regularTimePeriod20, (java.lang.Number) (-1.0d));
        timeSeries12.removeAgedItems(false);
        java.lang.String str25 = timeSeries12.getRangeDescription();
        boolean boolean26 = timeSeriesDataItem5.equals((java.lang.Object) str25);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        java.lang.String str6 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        int int10 = day7.compareTo((java.lang.Object) 0L);
        int int11 = day7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate(regularTimePeriod12, (double) 0L);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        int int18 = day15.compareTo((java.lang.Object) 0L);
        int int19 = day15.getYear();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, number20);
        timeSeries3.add(timeSeriesDataItem21, false);
        timeSeries3.removeAgedItems(true);
        timeSeries3.removeAgedItems(false);
        double double28 = timeSeries3.getMinY();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        boolean boolean3 = month0.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        boolean boolean6 = month0.equals((java.lang.Object) year4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean6);
        double double8 = timeSeries7.getMinY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries10.addAndOrUpdate(timeSeries12);
        boolean boolean15 = timeSeries14.getNotify();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        java.util.Date date17 = month16.getStart();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date17);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 100, true);
        long long24 = fixedMillisecond20.getFirstMillisecond();
        long long25 = fixedMillisecond20.getMiddleMillisecond();
        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond20);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1559372400000L + "'", long24 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1559372400000L + "'", long25 == 1559372400000L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        int int9 = day6.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (double) 10);
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) day6);
        java.lang.Class class13 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        int int17 = day14.compareTo((java.lang.Object) 0L);
        int int18 = day14.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day14.previous();
        java.lang.Class<?> wildcardClass20 = regularTimePeriod19.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries5.getDataItem(regularTimePeriod19);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.util.Date date23 = month22.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.next();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) (short) -1, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month22.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month22.next();
        java.util.Date date30 = regularTimePeriod29.getStart();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        double double6 = timeSeries3.getMinY();
        timeSeries3.clear();
        timeSeries3.clear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getStart();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        int int13 = year9.compareTo((java.lang.Object) day12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year9.next();
        java.lang.Number number15 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, number15, true);
        java.lang.Class class18 = timeSeries3.getTimePeriodClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize(class18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.util.Date date21 = month20.getStart();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date21);
        java.util.Calendar calendar25 = null;
        fixedMillisecond24.peg(calendar25);
        java.util.Date date27 = fixedMillisecond24.getStart();
        java.util.Date date28 = fixedMillisecond24.getTime();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date28, timeZone30);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod31);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        timeSeries3.setDomainDescription("June 2019");
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        java.util.List list12 = timeSeries11.getItems();
        java.lang.String str13 = timeSeries11.getRangeDescription();
        timeSeries11.fireSeriesChanged();
        java.lang.Comparable comparable15 = timeSeries11.getKey();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries17.addAndOrUpdate(timeSeries19);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 100L);
        java.lang.Object obj26 = timeSeries19.clone();
        boolean boolean27 = timeSeries11.equals((java.lang.Object) timeSeries19);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries3.addAndOrUpdate(timeSeries11);
        int int29 = timeSeries11.getMaximumItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries11.addChangeListener(seriesChangeListener30);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + '#' + "'", comparable15.equals('#'));
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2147483647 + "'", int29 == 2147483647);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.junit.Assert.assertNotNull(year1);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test070");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 0L);
//        int int4 = day0.getYear();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod7, (double) 1L);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries13.setDescription("");
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
//        int int19 = day16.compareTo((java.lang.Object) 0L);
//        int int20 = day16.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day16.previous();
//        long long22 = day16.getSerialIndex();
//        java.lang.Number number23 = null;
//        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) day16, number23, false);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
//        int int29 = day26.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day26, (double) 10);
//        boolean boolean33 = timeSeriesDataItem31.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries13.addOrUpdate(timeSeriesDataItem31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = timeSeriesDataItem34.getPeriod();
//        timeSeriesDataItem34.setValue((java.lang.Number) 1546329600000L);
//        int int38 = timeSeriesDataItem9.compareTo((java.lang.Object) timeSeriesDataItem34);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43626L + "'", long22 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener2);
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        timeSeries1.removeAgedItems(false);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        try {
            timeSeries1.delete(1, 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
        timeSeries1.clear();
        java.lang.String str7 = timeSeries1.getDescription();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
        int int19 = day16.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) 10);
        boolean boolean23 = timeSeriesDataItem21.equals((java.lang.Object) 100L);
        timeSeries15.add(timeSeriesDataItem21, false);
        int int26 = month10.compareTo((java.lang.Object) timeSeries15);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.next();
        int int30 = day27.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day27, (double) 10);
        boolean boolean33 = timeSeriesDataItem32.isSelected();
        java.lang.Object obj34 = timeSeriesDataItem32.clone();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries15.addOrUpdate(timeSeriesDataItem32);
        timeSeries1.add(timeSeriesDataItem32, false);
        timeSeriesDataItem32.setSelected(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeriesDataItem32.getPeriod();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        java.lang.String str6 = timeSeries3.getDomainDescription();
        timeSeries3.removeAgedItems(9223372036854775807L, false);
        double double10 = timeSeries3.getMinY();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test074");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries3.setDescription("");
//        timeSeries3.setDomainDescription("June 2019");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        int int11 = day8.compareTo((java.lang.Object) 0L);
//        java.lang.String str12 = day8.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.next();
//        long long14 = day8.getMiddleMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day8);
//        timeSeries3.clear();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
//        java.util.Collection collection21 = timeSeries18.getTimePeriods();
//        java.util.Collection collection22 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        double double23 = timeSeries3.getMinY();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        java.util.Date date25 = month24.getStart();
//        boolean boolean27 = month24.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getFirstMillisecond();
//        boolean boolean30 = month24.equals((java.lang.Object) year28);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 1.0f);
//        long long38 = fixedMillisecond33.getFirstMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond33.getMiddleMillisecond(calendar39);
//        java.lang.Number number41 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class46 = timeSeries45.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries43.addAndOrUpdate(timeSeries45);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year49, (java.lang.Number) 100L);
//        java.lang.Object obj52 = timeSeries45.clone();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries45.getDataItem((int) (byte) 0);
//        timeSeries3.add(timeSeriesDataItem54, true);
//        timeSeriesDataItem54.setValue((java.lang.Number) 10.0d);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560193199999L + "'", long14 == 1560193199999L);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
//        org.junit.Assert.assertNull(number41);
//        org.junit.Assert.assertNull(class46);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertNull(timeSeriesDataItem51);
//        org.junit.Assert.assertNotNull(obj52);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem54);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        boolean boolean3 = month0.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        long long5 = month0.getLastMillisecond();
        int int6 = month0.getYearValue();
        java.lang.String str7 = month0.toString();
        long long8 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month0.previous();
        java.util.Date date10 = month0.getStart();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(11, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test077");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries3.setDescription("");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
//        int int9 = day6.compareTo((java.lang.Object) 0L);
//        int int10 = day6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
//        long long12 = day6.getSerialIndex();
//        java.lang.Number number13 = null;
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day6, number13, false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
//        int int19 = day16.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) 10);
//        boolean boolean23 = timeSeriesDataItem21.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries3.addOrUpdate(timeSeriesDataItem21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeriesDataItem24.getPeriod();
//        boolean boolean26 = timeSeriesDataItem24.isSelected();
//        java.lang.Object obj27 = timeSeriesDataItem24.clone();
//        boolean boolean28 = timeSeriesDataItem24.isSelected();
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(obj27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 100L);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        int int13 = day10.compareTo((java.lang.Object) 0L);
        int int14 = day10.getYear();
        java.util.Date date15 = day10.getEnd();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.TimeSeries timeSeries20 = null;
        try {
            java.util.Collection collection21 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries19);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test080");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.util.Date date1 = month0.getStart();
//        boolean boolean3 = month0.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
//        long long5 = month0.getLastMillisecond();
//        int int6 = month0.getYearValue();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        int int10 = day7.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) 10);
//        int int13 = month0.compareTo((java.lang.Object) day7);
//        org.jfree.data.time.SerialDate serialDate14 = day7.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.addAndOrUpdate(timeSeries18);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 100L);
//        boolean boolean25 = day7.equals((java.lang.Object) timeSeries18);
//        long long26 = day7.getLastMillisecond();
//        int int27 = day7.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.next();
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond29.peg(calendar31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond29.previous();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(8);
//        boolean boolean36 = fixedMillisecond29.equals((java.lang.Object) year35);
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond29.getMiddleMillisecond(calendar37);
//        long long39 = fixedMillisecond29.getLastMillisecond();
//        int int40 = day7.compareTo((java.lang.Object) long39);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNull(class19);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560236399999L + "'", long26 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        java.lang.String str6 = timeSeries3.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, 10.0d);
        long long11 = fixedMillisecond8.getSerialIndex();
        java.lang.Object obj12 = null;
        boolean boolean13 = fixedMillisecond8.equals(obj12);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond8.getLastMillisecond(calendar14);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 100L);
        java.lang.Object obj10 = timeSeries3.clone();
        timeSeries3.setDomainDescription("10-June-2019");
        int int13 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.util.Date date15 = month14.getStart();
        boolean boolean17 = month14.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month14.next();
        long long19 = month14.getLastMillisecond();
        int int20 = month14.getYearValue();
        java.lang.String str21 = month14.toString();
        int int22 = month14.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 2147483647);
        try {
            timeSeries3.add(timeSeriesDataItem25, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        java.lang.String str6 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        int int10 = day7.compareTo((java.lang.Object) 0L);
        int int11 = day7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate(regularTimePeriod12, (double) 0L);
        int int15 = timeSeries3.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries19.setDescription("");
        double double22 = timeSeries19.getMinY();
        java.lang.Class class23 = timeSeries19.getTimePeriodClass();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        boolean boolean27 = month24.equals((java.lang.Object) 'a');
        timeSeries19.setKey((java.lang.Comparable) boolean27);
        boolean boolean29 = timeSeries3.equals((java.lang.Object) boolean27);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test085");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 0L);
//        int int4 = day0.getYear();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo5);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = seriesChangeEvent6.getSummary();
//        java.lang.String str8 = seriesChangeEvent6.toString();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
//        seriesChangeEvent6.setSummary(seriesChangeInfo9);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
//        seriesChangeEvent6.setSummary(seriesChangeInfo11);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = null;
//        seriesChangeEvent6.setSummary(seriesChangeInfo13);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
//        seriesChangeEvent6.setSummary(seriesChangeInfo15);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNull(seriesChangeInfo7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]" + "'", str8.equals("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]"));
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
        java.util.Calendar calendar10 = null;
        fixedMillisecond7.peg(calendar10);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) (byte) 1);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        java.util.List list16 = timeSeries3.getItems();
        timeSeries3.setDescription("June 2019");
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.addAndOrUpdate(timeSeries22);
        boolean boolean25 = timeSeries24.getNotify();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.util.Date date27 = month26.getStart();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date27);
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 100, true);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) (-1.0f));
        java.lang.Number number36 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, number36);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        boolean boolean3 = month0.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        long long5 = month0.getFirstMillisecond();
        java.util.Date date6 = month0.getEnd();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test088");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries4.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100L);
//        java.lang.Object obj13 = timeSeries6.clone();
//        timeSeries6.setDomainDescription("10-June-2019");
//        boolean boolean16 = day0.equals((java.lang.Object) timeSeries6);
//        int int17 = timeSeries6.getItemCount();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries20 = timeSeries6.createCopy((-2007), 2147483647);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNull(class7);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(8);
        boolean boolean8 = fixedMillisecond1.equals((java.lang.Object) year7);
        java.util.Date date9 = year7.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        java.util.Calendar calendar11 = null;
        try {
            year10.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test091");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 0L);
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        long long6 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560193199999L + "'", long6 == 1560193199999L);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        boolean boolean3 = month0.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries5.addAndOrUpdate(timeSeries7);
        boolean boolean10 = timeSeries9.getNotify();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.util.Date date12 = month11.getStart();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 100, true);
        java.lang.Class class19 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.util.Date date21 = month20.getStart();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date21);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone25);
        boolean boolean27 = month0.equals((java.lang.Object) date21);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        long long6 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
        java.util.Calendar calendar10 = null;
        fixedMillisecond7.peg(calendar10);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) (byte) 1);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        java.util.List list16 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries20.setDescription("");
        timeSeries20.setDomainDescription("June 2019");
        java.lang.Object obj25 = timeSeries20.clone();
        java.util.Collection collection26 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        long long27 = timeSeries20.getMaximumItemAge();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.util.Date date29 = month28.getStart();
        int int31 = month28.compareTo((java.lang.Object) true);
        long long32 = month28.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month28.next();
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) month28, (double) 100.0f, true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries20.removeChangeListener(seriesChangeListener37);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(8);
        java.lang.String str41 = year40.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year40.next();
        try {
            timeSeries20.add(regularTimePeriod42, (java.lang.Number) 2019L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223372036854775807L + "'", long27 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "8" + "'", str41.equals("8"));
        org.junit.Assert.assertNotNull(regularTimePeriod42);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-61914902400000L));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.util.Date date7 = month6.getStart();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        int int10 = month8.getYearValue();
        java.lang.Number number11 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month8);
        long long12 = month8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month8.next();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = day0.getStart();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries6.setDescription("");
        timeSeries6.setDomainDescription("June 2019");
        java.lang.Object obj11 = timeSeries6.clone();
        java.lang.Class class12 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        int int16 = day13.compareTo((java.lang.Object) 0L);
        int int17 = day13.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day13.previous();
        timeSeries6.add(regularTimePeriod18, (double) (-1L), false);
        int int22 = day0.compareTo((java.lang.Object) regularTimePeriod18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (byte) -1);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        java.util.Calendar calendar7 = null;
        try {
            day5.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        timeSeries3.setDomainDescription("June 2019");
        java.lang.Object obj8 = timeSeries3.clone();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.removeChangeListener(seriesChangeListener10);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
        int int19 = day16.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) 10);
        boolean boolean23 = timeSeriesDataItem21.equals((java.lang.Object) 100L);
        timeSeries15.add(timeSeriesDataItem21, false);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) (byte) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        int int29 = timeSeriesDataItem21.compareTo((java.lang.Object) year27);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        java.util.Date date35 = month34.getStart();
        boolean boolean37 = month34.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month34.next();
        long long39 = month34.getFirstMillisecond();
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timeSeries31.removePropertyChangeListener(propertyChangeListener42);
        int int44 = year27.compareTo((java.lang.Object) propertyChangeListener42);
        java.lang.String str45 = year27.toString();
        java.lang.Number number46 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year27);
        timeSeries3.setMaximumItemAge((long) 10);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1559372400000L + "'", long39 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "1" + "'", str45.equals("1"));
        org.junit.Assert.assertNull(number46);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.next();
        int int5 = year2.getYear();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(12, year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.lang.String str6 = timeSeries3.getRangeDescription();
        timeSeries3.setDescription("");
        java.lang.String str9 = timeSeries3.getDomainDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            int int11 = timeSeries3.getIndex(regularTimePeriod10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        timeSeries3.setDomainDescription("June 2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int11 = day8.compareTo((java.lang.Object) 0L);
        int int12 = day8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day8.previous();
        timeSeries3.add(regularTimePeriod13, (java.lang.Number) 43626L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getFirstMillisecond(calendar18);
        java.util.Calendar calendar20 = null;
        fixedMillisecond17.peg(calendar20);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond17.getFirstMillisecond(calendar22);
        long long24 = fixedMillisecond17.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond17.previous();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 2147483647, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (byte) 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("8");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("Time");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=10-June-2019]");
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray17 = seriesException16.getSuppressed();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) seriesException16);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test106");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        boolean boolean3 = day0.equals((java.lang.Object) '4');
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int7 = day4.compareTo((java.lang.Object) 0L);
//        java.lang.String str8 = day4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day4.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day4.previous();
//        boolean boolean11 = day0.equals((java.lang.Object) regularTimePeriod10);
//        int int12 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        long long2 = year1.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1);
        long long4 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800000L) + "'", long2 == (-62104204800000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62104204800000L) + "'", long4 == (-62104204800000L));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getMonth();
        java.lang.Object obj4 = null;
        int int5 = month2.compareTo(obj4);
        java.lang.Object obj6 = null;
        int int7 = month2.compareTo(obj6);
        int int8 = month2.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        double double6 = timeSeries3.getMinY();
        java.lang.Class class7 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        boolean boolean11 = month8.equals((java.lang.Object) 'a');
        timeSeries3.setKey((java.lang.Comparable) boolean11);
        java.lang.Class class13 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.util.Date date15 = month14.getStart();
        boolean boolean17 = month14.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getFirstMillisecond();
        boolean boolean20 = month14.equals((java.lang.Object) year18);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        int int25 = day22.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (double) 10);
        java.lang.Object obj28 = timeSeriesDataItem27.clone();
        boolean boolean30 = timeSeriesDataItem27.equals((java.lang.Object) 1560193199999L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries21.addOrUpdate(timeSeriesDataItem27);
        java.lang.Object obj32 = timeSeriesDataItem27.clone();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries3.addOrUpdate(timeSeriesDataItem27);
        timeSeriesDataItem27.setSelected(false);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) 12);
        timeSeriesDataItem3.setSelected(true);
        timeSeriesDataItem3.setValue((java.lang.Number) 1560150000000L);
        timeSeriesDataItem3.setSelected(true);
        timeSeriesDataItem3.setSelected(false);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test111");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries4.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 100L);
//        java.lang.Object obj13 = timeSeries6.clone();
//        timeSeries6.setDomainDescription("10-June-2019");
//        boolean boolean16 = day0.equals((java.lang.Object) timeSeries6);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        java.util.Date date18 = month17.getStart();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        long long20 = day19.getSerialIndex();
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 9223372036854775807L, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNull(class7);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43617L + "'", long20 == 43617L);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test112");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        java.util.Date date3 = month2.getStart();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        int int13 = day10.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (double) 10);
//        boolean boolean17 = timeSeriesDataItem15.equals((java.lang.Object) 100L);
//        timeSeries9.add(timeSeriesDataItem15, false);
//        int int20 = month4.compareTo((java.lang.Object) timeSeries9);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
//        int int24 = day21.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) 10);
//        boolean boolean27 = timeSeriesDataItem26.isSelected();
//        java.lang.Object obj28 = timeSeriesDataItem26.clone();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries9.addOrUpdate(timeSeriesDataItem26);
//        int int30 = day0.compareTo((java.lang.Object) timeSeriesDataItem26);
//        timeSeriesDataItem26.setSelected(true);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener2);
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getStart();
        int int10 = month7.compareTo((java.lang.Object) true);
        int int11 = month7.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (double) 9223372036854775807L);
        timeSeriesDataItem13.setValue((java.lang.Number) 5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem13.getPeriod();
        timeSeries1.add(regularTimePeriod16, (java.lang.Number) (short) -1, true);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        java.lang.String str6 = timeSeries3.getDomainDescription();
        timeSeries3.removeAgedItems(9223372036854775807L, false);
        java.util.List list10 = timeSeries3.getItems();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.getDataItem(regularTimePeriod13);
        double double15 = timeSeries3.getMaxY();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        double double6 = timeSeries3.getMinY();
        java.lang.Class class7 = timeSeries3.getTimePeriodClass();
        timeSeries3.fireSeriesChanged();
        timeSeries3.setNotify(false);
        timeSeries3.setMaximumItemAge(1560150000000L);
        int int13 = timeSeries3.getItemCount();
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        double double6 = timeSeries3.getMinY();
        java.lang.Class class7 = timeSeries3.getTimePeriodClass();
        timeSeries3.fireSeriesChanged();
        boolean boolean9 = timeSeries3.isEmpty();
        java.lang.Object obj10 = timeSeries3.clone();
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 0L);
        int int4 = day0.getYear();
        java.util.Date date5 = day0.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test118");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
//        java.lang.Object obj6 = timeSeries3.clone();
//        timeSeries3.setRangeDescription("8");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(8);
//        java.lang.String str11 = year10.toString();
//        boolean boolean12 = timeSeries3.equals((java.lang.Object) str11);
//        double double13 = timeSeries3.getMinY();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries3.addChangeListener(seriesChangeListener14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond17.getFirstMillisecond(calendar18);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond17.getLastMillisecond(calendar20);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond17.getMiddleMillisecond(calendar22);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (org.jfree.data.time.RegularTimePeriod) year25);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries30.setDescription("");
//        double double33 = timeSeries30.getMinY();
//        java.lang.Class class34 = timeSeries30.getTimePeriodClass();
//        timeSeries30.fireSeriesChanged();
//        timeSeries30.setNotify(false);
//        timeSeries30.setDomainDescription("10-June-2019");
//        timeSeries30.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries26.addAndOrUpdate(timeSeries30);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries46.setDescription("");
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.next();
//        int int52 = day49.compareTo((java.lang.Object) 0L);
//        int int53 = day49.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day49.previous();
//        long long55 = day49.getSerialIndex();
//        java.lang.Number number56 = null;
//        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) day49, number56, false);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day59.next();
//        int int62 = day59.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day59, (double) 10);
//        boolean boolean66 = timeSeriesDataItem64.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries46.addOrUpdate(timeSeriesDataItem64);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries42.addOrUpdate(timeSeriesDataItem64);
//        java.beans.PropertyChangeListener propertyChangeListener69 = null;
//        timeSeries42.removePropertyChangeListener(propertyChangeListener69);
//        int int71 = timeSeries42.getMaximumItemCount();
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "8" + "'", str11.equals("8"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
//        org.junit.Assert.assertNull(class34);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2019 + "'", int53 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 43626L + "'", long55 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem67);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2147483647 + "'", int71 == 2147483647);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        int int4 = month3.getMonth();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month3.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test120");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries3.setDescription("");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
//        int int9 = day6.compareTo((java.lang.Object) 0L);
//        int int10 = day6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
//        long long12 = day6.getSerialIndex();
//        java.lang.Number number13 = null;
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day6, number13, false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
//        int int19 = day16.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) 10);
//        boolean boolean23 = timeSeriesDataItem21.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries3.addOrUpdate(timeSeriesDataItem21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeriesDataItem24.getPeriod();
//        java.util.Date date26 = regularTimePeriod25.getEnd();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
//        long long28 = year27.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        timeSeries3.setDomainDescription("June 2019");
        java.lang.Object obj8 = timeSeries3.clone();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.removeChangeListener(seriesChangeListener10);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timeSeries3.getRangeDescription();
        java.lang.Class class15 = timeSeries3.getTimePeriodClass();
        int int16 = timeSeries3.getItemCount();
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("June 2019");
        long long2 = month1.getSerialIndex();
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date4, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test125");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries4.addAndOrUpdate(timeSeries6);
//        boolean boolean9 = timeSeries8.getNotify();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        java.util.Date date11 = month10.getStart();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date11);
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 100, true);
//        int int18 = day0.compareTo((java.lang.Object) true);
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = day0.getLastMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNull(class7);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 0L);
        int int4 = day0.getYear();
        java.util.Date date5 = day0.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date5, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 0L);
        int int4 = day0.getYear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.util.Date date6 = month5.getStart();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        int int8 = day0.compareTo((java.lang.Object) date6);
        java.util.Date date9 = day0.getStart();
        org.jfree.data.time.SerialDate serialDate10 = day0.getSerialDate();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        long long3 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(8);
        long long2 = year1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61883280000001L) + "'", long2 == (-61883280000001L));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
        java.util.Calendar calendar10 = null;
        fixedMillisecond7.peg(calendar10);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) (byte) 1);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond7.getFirstMillisecond(calendar14);
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond7.getMiddleMillisecond(calendar16);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        int int3 = month0.compareTo((java.lang.Object) true);
        int int4 = month0.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 9223372036854775807L);
        int int7 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month0.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 0L);
        int int4 = day0.getYear();
        java.util.Date date5 = day0.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getStart();
        boolean boolean7 = month4.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month4.next();
        long long9 = month4.getFirstMillisecond();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, 0.0d);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int3 = day0.compareTo((java.lang.Object) 0L);
        int int4 = day0.getYear();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
        int int8 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate9 = day0.getSerialDate();
        java.util.Date date10 = day0.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = day0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test137");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.util.Date date1 = month0.getStart();
//        boolean boolean3 = month0.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        int int7 = day4.compareTo((java.lang.Object) 0L);
//        java.lang.String str8 = day4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day4.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day4.previous();
//        boolean boolean11 = month0.equals((java.lang.Object) regularTimePeriod10);
//        int int12 = month0.getMonth();
//        java.lang.String str13 = month0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test138");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 0L);
//        int int4 = day0.getYear();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 5);
//        long long10 = day0.getSerialIndex();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day0.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test139");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries3.setDescription("");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
//        int int9 = day6.compareTo((java.lang.Object) 0L);
//        int int10 = day6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
//        long long12 = day6.getSerialIndex();
//        java.lang.Number number13 = null;
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day6, number13, false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
//        int int19 = day16.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) 10);
//        boolean boolean23 = timeSeriesDataItem21.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries3.addOrUpdate(timeSeriesDataItem21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeriesDataItem24.getPeriod();
//        timeSeriesDataItem24.setValue((java.lang.Number) 1546329600000L);
//        timeSeriesDataItem24.setValue((java.lang.Number) 2019L);
//        timeSeriesDataItem24.setValue((java.lang.Number) 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.lang.Object obj6 = timeSeries3.clone();
        timeSeries3.setRangeDescription("8");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(8);
        java.lang.String str11 = year10.toString();
        boolean boolean12 = timeSeries3.equals((java.lang.Object) str11);
        double double13 = timeSeries3.getMinY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.addChangeListener(seriesChangeListener14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getFirstMillisecond(calendar18);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond17.getLastMillisecond(calendar20);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond17.getMiddleMillisecond(calendar22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (org.jfree.data.time.RegularTimePeriod) year25);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        timeSeries30.setDescription("");
        double double33 = timeSeries30.getMinY();
        java.lang.Class class34 = timeSeries30.getTimePeriodClass();
        timeSeries30.fireSeriesChanged();
        timeSeries30.setNotify(false);
        timeSeries30.setDomainDescription("10-June-2019");
        timeSeries30.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries26.addAndOrUpdate(timeSeries30);
        java.lang.String str43 = timeSeries26.getDomainDescription();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        java.util.Date date45 = month44.getStart();
        boolean boolean47 = month44.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month44.next();
        long long49 = month44.getLastMillisecond();
        int int50 = month44.getYearValue();
        java.lang.String str51 = month44.toString();
        boolean boolean52 = timeSeries26.equals((java.lang.Object) month44);
        try {
            timeSeries26.delete(2, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "8" + "'", str11.equals("8"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNull(class34);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Time" + "'", str43.equals("Time"));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1561964399999L + "'", long49 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "June 2019" + "'", str51.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.lang.Class<?> wildcardClass3 = year0.getClass();
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone5);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        int int7 = day4.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 10);
        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) 100L);
        timeSeries3.add(timeSeriesDataItem9, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond15.previous();
        java.lang.Number number19 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.util.Date date21 = month20.getStart();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
        int int31 = day28.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day28, (double) 10);
        boolean boolean35 = timeSeriesDataItem33.equals((java.lang.Object) 100L);
        timeSeries27.add(timeSeriesDataItem33, false);
        int int38 = month22.compareTo((java.lang.Object) timeSeries27);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries27.removeChangeListener(seriesChangeListener39);
        int int41 = fixedMillisecond15.compareTo((java.lang.Object) timeSeries27);
        try {
            timeSeries27.delete(12, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 10.0d + "'", number19.equals(10.0d));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test143");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 0L);
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
//        int int8 = timeSeries7.getItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener9);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener2);
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        timeSeries1.removeAgedItems(false);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', (int) (byte) 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        int int9 = day6.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (double) 10);
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) day6);
        java.util.Collection collection13 = timeSeries5.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond15.next();
        java.util.Calendar calendar17 = null;
        fixedMillisecond15.peg(calendar17);
        long long19 = fixedMillisecond15.getSerialIndex();
        java.util.Date date20 = fixedMillisecond15.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond21.next();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test147");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int3 = day0.compareTo((java.lang.Object) 0L);
//        int int4 = day0.getYear();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
//        int int8 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day0.getSerialDate();
//        long long10 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test148");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        java.util.Date date8 = month7.getStart();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date8);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 100, true);
//        java.lang.Class class15 = timeSeries5.getTimePeriodClass();
//        java.lang.String str16 = timeSeries5.getDomainDescription();
//        java.lang.Class class17 = timeSeries5.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries21.setDescription("");
//        timeSeries21.setDomainDescription("June 2019");
//        java.lang.Object obj26 = timeSeries21.clone();
//        timeSeries21.fireSeriesChanged();
//        timeSeries21.removeAgedItems((long) '#', true);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries5.addAndOrUpdate(timeSeries21);
//        java.lang.Class class32 = timeSeries5.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries36.setDescription("");
//        timeSeries36.setDomainDescription("June 2019");
//        java.lang.Object obj41 = timeSeries36.clone();
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries45.setDescription("");
//        timeSeries45.setDomainDescription("June 2019");
//        java.lang.Object obj50 = timeSeries45.clone();
//        timeSeries45.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries55.setDescription("");
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.next();
//        int int61 = day58.compareTo((java.lang.Object) 0L);
//        int int62 = day58.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = day58.previous();
//        long long64 = day58.getSerialIndex();
//        java.lang.Number number65 = null;
//        timeSeries55.add((org.jfree.data.time.RegularTimePeriod) day58, number65, false);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = day68.next();
//        int int71 = day68.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day68, (double) 10);
//        boolean boolean75 = timeSeriesDataItem73.equals((java.lang.Object) 100L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries55.addOrUpdate(timeSeriesDataItem73);
//        timeSeries45.add(timeSeriesDataItem76, true);
//        timeSeries36.add(timeSeriesDataItem76);
//        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month();
//        java.util.Date date81 = month80.getStart();
//        long long82 = month80.getLastMillisecond();
//        java.lang.String str83 = month80.toString();
//        boolean boolean84 = timeSeriesDataItem76.equals((java.lang.Object) str83);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = timeSeriesDataItem76.getPeriod();
//        try {
//            timeSeries5.add(timeSeriesDataItem76, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(obj26);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertNotNull(obj41);
//        org.junit.Assert.assertNotNull(obj50);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2019 + "'", int62 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 43626L + "'", long64 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem76);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1561964399999L + "'", long82 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "June 2019" + "'", str83.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod85);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 100L);
        java.lang.Class class10 = timeSeries3.getTimePeriodClass();
        timeSeries3.setRangeDescription("org.jfree.data.general.SeriesException: ");
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.createCopy(11, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
        timeSeries1.clear();
        java.lang.String str7 = timeSeries1.getDescription();
        boolean boolean8 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate(timeSeriesDataItem9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test151");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.util.Date date2 = day0.getStart();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test152");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.util.Date date1 = month0.getStart();
//        long long2 = month0.getLastMillisecond();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
//        int int6 = day3.compareTo((java.lang.Object) 0L);
//        java.lang.String str7 = day3.toString();
//        boolean boolean8 = month0.equals((java.lang.Object) day3);
//        java.lang.String str9 = month0.toString();
//        org.jfree.data.time.Year year10 = month0.getYear();
//        long long11 = month0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 24234L + "'", long11 == 24234L);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test153");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries3.setDescription("");
//        java.lang.String str6 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        int int10 = day7.compareTo((java.lang.Object) 0L);
//        int int11 = day7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate(regularTimePeriod12, (double) 0L);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        int int18 = day15.compareTo((java.lang.Object) 0L);
//        int int19 = day15.getYear();
//        java.lang.Number number20 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, number20);
//        timeSeries3.add(timeSeriesDataItem21, false);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
//        int int31 = day28.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day28, (double) 10);
//        boolean boolean35 = timeSeriesDataItem33.equals((java.lang.Object) 100L);
//        timeSeries27.add(timeSeriesDataItem33, false);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (byte) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.previous();
//        int int41 = timeSeriesDataItem33.compareTo((java.lang.Object) year39);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.beans.PropertyChangeListener propertyChangeListener44 = null;
//        timeSeries43.addPropertyChangeListener(propertyChangeListener44);
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
//        java.util.Date date47 = month46.getStart();
//        boolean boolean49 = month46.equals((java.lang.Object) (short) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month46.next();
//        long long51 = month46.getFirstMillisecond();
//        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) month46, 0.0d);
//        java.beans.PropertyChangeListener propertyChangeListener54 = null;
//        timeSeries43.removePropertyChangeListener(propertyChangeListener54);
//        int int56 = year39.compareTo((java.lang.Object) propertyChangeListener54);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        java.lang.String str58 = day57.toString();
//        int int59 = year39.compareTo((java.lang.Object) day57);
//        int int60 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day57);
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class65 = timeSeries64.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries62.addAndOrUpdate(timeSeries64);
//        boolean boolean67 = timeSeries66.getNotify();
//        long long68 = timeSeries66.getMaximumItemAge();
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = day69.next();
//        int int72 = day69.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day69, (double) 10);
//        boolean boolean76 = timeSeriesDataItem74.equals((java.lang.Object) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = timeSeriesDataItem74.getPeriod();
//        timeSeries66.add(timeSeriesDataItem74);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries3.addOrUpdate(timeSeriesDataItem74);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1559372400000L + "'", long51 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "10-June-2019" + "'", str58.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertNull(class65);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 9223372036854775807L + "'", long68 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem79);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test154");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.util.Date date1 = month0.getEnd();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "10-June-2019", "10-June-2019");
//        timeSeries6.setDescription("");
//        timeSeries6.setDomainDescription("June 2019");
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
//        int int14 = day11.compareTo((java.lang.Object) 0L);
//        java.lang.String str15 = day11.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.next();
//        long long17 = day11.getMiddleMillisecond();
//        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day11);
//        timeSeries6.clear();
//        boolean boolean20 = year2.equals((java.lang.Object) timeSeries6);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
//        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.addAndOrUpdate(timeSeries24);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.next();
//        int int30 = day27.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day27, (double) 10);
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        java.util.Collection collection34 = timeSeries26.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond36.next();
//        java.util.Calendar calendar38 = null;
//        fixedMillisecond36.peg(calendar38);
//        long long40 = fixedMillisecond36.getSerialIndex();
//        java.util.Date date41 = fixedMillisecond36.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date41);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (double) (byte) 100);
//        boolean boolean45 = timeSeries6.equals((java.lang.Object) timeSeries26);
//        java.beans.PropertyChangeListener propertyChangeListener46 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener46);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560193199999L + "'", long17 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNull(class25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(collection34);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        int int9 = day6.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (double) 10);
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) day6);
        java.lang.Class class13 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        int int17 = day14.compareTo((java.lang.Object) 0L);
        int int18 = day14.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day14.previous();
        java.lang.Class<?> wildcardClass20 = regularTimePeriod19.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries5.getDataItem(regularTimePeriod19);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.util.Date date23 = month22.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.next();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) (short) -1, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) (byte) 0);
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }
}

