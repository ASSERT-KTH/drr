import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) ' ');
        int int4 = week2.compareTo((java.lang.Object) (-62177990400001L));
        long long5 = week2.getLastMillisecond();
        int int7 = week2.compareTo((java.lang.Object) '#');
        long long8 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.next();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61151644800001L) + "'", long5 == (-61151644800001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1706L + "'", long8 == 1706L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test02() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test02");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 53);
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
//        long long8 = week7.getSerialIndex();
//        int int10 = week7.compareTo((java.lang.Object) 1L);
//        long long11 = week7.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass12 = week7.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(class14);
//    }

//    @Test
//    public void test03() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test03");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        java.lang.String str5 = week4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.previous();
//        java.lang.String str7 = week4.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) ' ');
        int int4 = week2.compareTo((java.lang.Object) (-62177990400001L));
        long long5 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
        int int11 = week9.compareTo((java.lang.Object) 53);
        java.util.Date date12 = week9.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) -1, (int) (byte) 10);
        java.util.Date date16 = week15.getEnd();
        int int17 = week15.getWeek();
        boolean boolean18 = week9.equals((java.lang.Object) int17);
        java.util.Date date19 = week9.getEnd();
        int int20 = week8.compareTo((java.lang.Object) date19);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
        java.util.Date date22 = week21.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week21.next();
        java.util.Date date24 = regularTimePeriod23.getEnd();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date24, timeZone25);
        java.util.Locale locale27 = null;
        try {
            org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date19, timeZone25, locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61151644800001L) + "'", long5 == (-61151644800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
    }

//    @Test
//    public void test05() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test05");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 53);
//        int int3 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, (int) (byte) 10);
        boolean boolean4 = week2.equals((java.lang.Object) '#');
        long long5 = week2.getSerialIndex();
        long long6 = week2.getFirstMillisecond();
        java.util.Date date7 = week2.getEnd();
        int int8 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 529L + "'", long5 == 529L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61853212800000L) + "'", long6 == (-61853212800000L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, (int) (byte) 10);
        boolean boolean4 = week2.equals((java.lang.Object) '#');
        long long5 = week2.getSerialIndex();
        long long6 = week2.getFirstMillisecond();
        java.util.Date date7 = week2.getEnd();
        java.lang.String str8 = week2.toString();
        try {
            org.jfree.data.time.Year year9 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 529L + "'", long5 == 529L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61853212800000L) + "'", long6 == (-61853212800000L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week -1, 10" + "'", str8.equals("Week -1, 10"));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 0");
    }

//    @Test
//    public void test09() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test09");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 53);
//        int int3 = week0.getWeek();
//        int int4 = week0.getWeek();
//        java.lang.String str5 = week0.toString();
//        java.util.Date date6 = week0.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test10() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test10");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.lang.Class<?> wildcardClass2 = date1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int9 = week7.compareTo((java.lang.Object) 53);
//        long long10 = week7.getLastMillisecond();
//        long long11 = week7.getMiddleMillisecond();
//        java.util.Date date12 = week7.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        int int15 = week13.compareTo((java.lang.Object) 53);
//        long long16 = week13.getLastMillisecond();
//        long long17 = week13.getMiddleMillisecond();
//        java.util.Date date18 = week13.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date12, timeZone19);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date12);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int25 = week23.compareTo((java.lang.Object) 53);
//        long long26 = week23.getLastMillisecond();
//        long long27 = week23.getMiddleMillisecond();
//        java.util.Date date28 = week23.getEnd();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date28, timeZone29);
//        long long31 = week30.getSerialIndex();
//        java.util.Date date32 = week30.getEnd();
//        java.lang.Class class33 = null;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        int int36 = week34.compareTo((java.lang.Object) 53);
//        long long37 = week34.getLastMillisecond();
//        long long38 = week34.getMiddleMillisecond();
//        java.util.Date date39 = week34.getEnd();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        int int42 = week40.compareTo((java.lang.Object) 53);
//        long long43 = week40.getLastMillisecond();
//        long long44 = week40.getMiddleMillisecond();
//        java.util.Date date45 = week40.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date45, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date39, timeZone46);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date32, timeZone46);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(10, (int) ' ');
//        int int54 = week52.compareTo((java.lang.Object) (-62177990400001L));
//        long long55 = week52.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week52.next();
//        java.util.Date date57 = regularTimePeriod56.getEnd();
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date57);
//        java.util.Date date59 = week58.getEnd();
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
//        int int62 = week60.compareTo((java.lang.Object) 53);
//        long long63 = week60.getLastMillisecond();
//        long long64 = week60.getMiddleMillisecond();
//        java.util.Date date65 = week60.getEnd();
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date65, timeZone66);
//        java.util.Date date68 = week67.getStart();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week();
//        int int71 = week69.compareTo((java.lang.Object) 53);
//        long long72 = week69.getLastMillisecond();
//        long long73 = week69.getMiddleMillisecond();
//        java.util.Date date74 = week69.getEnd();
//        java.util.Date date75 = week69.getEnd();
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week();
//        int int78 = week76.compareTo((java.lang.Object) 53);
//        long long79 = week76.getLastMillisecond();
//        long long80 = week76.getMiddleMillisecond();
//        java.util.Date date81 = week76.getEnd();
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date81, timeZone82);
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date75, timeZone82);
//        java.lang.Class<?> wildcardClass85 = timeZone82.getClass();
//        java.lang.Class<?> wildcardClass86 = timeZone82.getClass();
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date68, timeZone82);
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date59, timeZone82);
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date32, timeZone82);
//        java.lang.Class<?> wildcardClass90 = timeZone82.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date12, timeZone82);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560668399999L + "'", long10 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560365999999L + "'", long11 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560668399999L + "'", long16 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560365999999L + "'", long17 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560668399999L + "'", long26 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560365999999L + "'", long27 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 107031L + "'", long31 == 107031L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560668399999L + "'", long37 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560365999999L + "'", long38 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560668399999L + "'", long43 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560365999999L + "'", long44 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-61151644800001L) + "'", long55 == (-61151644800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560668399999L + "'", long63 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560365999999L + "'", long64 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1560668399999L + "'", long72 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560365999999L + "'", long73 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1560668399999L + "'", long79 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1560365999999L + "'", long80 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertNotNull(wildcardClass85);
//        org.junit.Assert.assertNotNull(wildcardClass86);
//        org.junit.Assert.assertNotNull(wildcardClass90);
//        org.junit.Assert.assertNotNull(regularTimePeriod91);
//    }

//    @Test
//    public void test11() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test11");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getLastMillisecond();
//        int int5 = week0.getYearValue();
//        java.util.Calendar calendar6 = null;
//        try {
//            week0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

//    @Test
//    public void test12() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test12");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 53);
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
//        long long8 = week7.getSerialIndex();
//        java.util.Date date9 = week7.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (byte) -1, (int) (byte) 10);
//        java.util.Date date13 = week12.getEnd();
//        java.lang.Class<?> wildcardClass14 = week12.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        java.util.Date date17 = week16.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week16.next();
//        long long19 = regularTimePeriod18.getMiddleMillisecond();
//        java.util.Date date20 = regularTimePeriod18.getEnd();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        int int23 = week21.compareTo((java.lang.Object) 53);
//        long long24 = week21.getLastMillisecond();
//        long long25 = week21.getMiddleMillisecond();
//        java.util.Date date26 = week21.getEnd();
//        java.util.Date date27 = week21.getEnd();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        int int30 = week28.compareTo((java.lang.Object) 53);
//        long long31 = week28.getLastMillisecond();
//        long long32 = week28.getMiddleMillisecond();
//        java.util.Date date33 = week28.getEnd();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date33, timeZone34);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date27, timeZone34);
//        java.lang.Class<?> wildcardClass37 = timeZone34.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize(class38);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        int int42 = week40.compareTo((java.lang.Object) 53);
//        long long43 = week40.getLastMillisecond();
//        long long44 = week40.getMiddleMillisecond();
//        java.util.Date date45 = week40.getEnd();
//        java.util.Date date46 = week40.getEnd();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date46);
//        java.util.Date date48 = week47.getStart();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        int int51 = week49.compareTo((java.lang.Object) 53);
//        long long52 = week49.getLastMillisecond();
//        long long53 = week49.getMiddleMillisecond();
//        java.util.Date date54 = week49.getEnd();
//        java.util.Date date55 = week49.getEnd();
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
//        int int58 = week56.compareTo((java.lang.Object) 53);
//        long long59 = week56.getLastMillisecond();
//        long long60 = week56.getMiddleMillisecond();
//        java.util.Date date61 = week56.getEnd();
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date61, timeZone62);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date55, timeZone62);
//        java.lang.Class<?> wildcardClass65 = timeZone62.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date48, timeZone62);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(10, (int) ' ');
//        int int71 = week69.compareTo((java.lang.Object) (-62177990400001L));
//        long long72 = week69.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = week69.next();
//        java.util.Date date74 = regularTimePeriod73.getEnd();
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week();
//        int int77 = week75.compareTo((java.lang.Object) 53);
//        long long78 = week75.getLastMillisecond();
//        long long79 = week75.getMiddleMillisecond();
//        java.util.Date date80 = week75.getEnd();
//        java.util.Date date81 = week75.getEnd();
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week();
//        int int84 = week82.compareTo((java.lang.Object) 53);
//        long long85 = week82.getLastMillisecond();
//        long long86 = week82.getMiddleMillisecond();
//        java.util.Date date87 = week82.getEnd();
//        java.util.TimeZone timeZone88 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date87, timeZone88);
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date81, timeZone88);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date74, timeZone88);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date20, timeZone88);
//        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date9, timeZone88);
//        int int94 = week93.getWeek();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560970799999L + "'", long19 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560668399999L + "'", long24 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560365999999L + "'", long25 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560668399999L + "'", long31 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560365999999L + "'", long32 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560668399999L + "'", long43 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560365999999L + "'", long44 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560668399999L + "'", long52 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560365999999L + "'", long53 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560668399999L + "'", long59 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560365999999L + "'", long60 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNotNull(wildcardClass65);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-61151644800001L) + "'", long72 == (-61151644800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1560668399999L + "'", long78 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1560365999999L + "'", long79 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560668399999L + "'", long85 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 1560365999999L + "'", long86 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date87);
//        org.junit.Assert.assertNotNull(timeZone88);
//        org.junit.Assert.assertNull(regularTimePeriod91);
//        org.junit.Assert.assertNotNull(regularTimePeriod92);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 24 + "'", int94 == 24);
//    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test13");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 53);
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        java.util.Date date6 = week0.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int9 = week7.compareTo((java.lang.Object) 53);
//        long long10 = week7.getLastMillisecond();
//        long long11 = week7.getMiddleMillisecond();
//        java.util.Date date12 = week7.getEnd();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date12, timeZone13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date6, timeZone13);
//        java.lang.Class<?> wildcardClass16 = timeZone13.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize(class19);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560668399999L + "'", long10 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560365999999L + "'", long11 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(class20);
//    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 7);
        java.util.Date date3 = week2.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test15() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test15");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 0);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int5 = week3.compareTo((java.lang.Object) 53);
//        long long6 = week3.getFirstMillisecond();
//        int int7 = week2.compareTo((java.lang.Object) week3);
//        int int8 = week3.getYearValue();
//        int int9 = week3.getYearValue();
//        java.util.Date date10 = week3.getStart();
//        long long11 = week3.getLastMillisecond();
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = week3.getLastMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-2019) + "'", int7 == (-2019));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 2);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        int int5 = week2.getYearValue();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104809600000L) + "'", long3 == (-62104809600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test17() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test17");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int3 = week1.compareTo((java.lang.Object) 53);
//        long long4 = week1.getLastMillisecond();
//        long long5 = week1.getMiddleMillisecond();
//        java.util.Date date6 = week1.getEnd();
//        java.util.Date date7 = week1.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        int int10 = week8.compareTo((java.lang.Object) 53);
//        long long11 = week8.getLastMillisecond();
//        long long12 = week8.getMiddleMillisecond();
//        java.util.Date date13 = week8.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date7, timeZone14);
//        long long17 = week16.getFirstMillisecond();
//        int int18 = week16.getWeek();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        int int21 = week19.compareTo((java.lang.Object) 53);
//        java.util.Date date22 = week19.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week19.next();
//        long long24 = week19.getSerialIndex();
//        long long25 = week19.getLastMillisecond();
//        java.lang.String str26 = week19.toString();
//        org.jfree.data.time.Year year27 = week19.getYear();
//        int int28 = week16.compareTo((java.lang.Object) year27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(12, year27);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560365999999L + "'", long12 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 107031L + "'", long24 == 107031L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560668399999L + "'", long25 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 24, 2019" + "'", str26.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (-1));
        int int4 = week2.compareTo((java.lang.Object) 0);
        java.util.Date date5 = week2.getStart();
        long long6 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62178595200000L) + "'", long6 == (-62178595200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test19() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test19");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 53);
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        java.util.Date date6 = week0.getEnd();
//        org.jfree.data.time.Year year7 = week0.getYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(year7);
//    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test20");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        java.util.Date date4 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test21");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 53);
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
//        long long8 = week7.getSerialIndex();
//        long long9 = week7.getLastMillisecond();
//        int int10 = week7.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week7.previous();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

//    @Test
//    public void test22() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test22");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 53);
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//    }

//    @Test
//    public void test23() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test23");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 53);
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
//        java.util.Date date8 = week7.getStart();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        org.jfree.data.time.Year year10 = week7.getYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(year10);
//    }

//    @Test
//    public void test24() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test24");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 53);
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test25() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test25");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Date date3 = week0.getStart();
//        long long4 = week0.getLastMillisecond();
//        int int5 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//    }

//    @Test
//    public void test26() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test26");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int3 = week1.compareTo((java.lang.Object) 53);
//        java.util.Date date4 = week1.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week1.next();
//        long long6 = week1.getSerialIndex();
//        long long7 = week1.getLastMillisecond();
//        java.lang.String str8 = week1.toString();
//        org.jfree.data.time.Year year9 = week1.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, year9);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year9);
//    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) '#');
    }

//    @Test
//    public void test28() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test28");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 0);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int6 = week4.compareTo((java.lang.Object) 53);
//        long long7 = week4.getFirstMillisecond();
//        int int8 = week3.compareTo((java.lang.Object) week4);
//        int int9 = week4.getYearValue();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        int int12 = week10.compareTo((java.lang.Object) 53);
//        int int13 = week10.getWeek();
//        int int14 = week10.getWeek();
//        int int15 = week10.getYearValue();
//        int int16 = week4.compareTo((java.lang.Object) week10);
//        org.jfree.data.time.Year year17 = week10.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(0, year17);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-2019) + "'", int8 == (-2019));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(year17);
//    }

//    @Test
//    public void test29() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test29");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) 53);
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        int int10 = week8.compareTo((java.lang.Object) 53);
//        long long11 = week8.getLastMillisecond();
//        long long12 = week8.getMiddleMillisecond();
//        java.util.Date date13 = week8.getEnd();
//        java.util.Date date14 = week8.getEnd();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        int int17 = week15.compareTo((java.lang.Object) 53);
//        long long18 = week15.getLastMillisecond();
//        long long19 = week15.getMiddleMillisecond();
//        java.util.Date date20 = week15.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date14, timeZone21);
//        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date5, timeZone21);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        int int28 = week26.compareTo((java.lang.Object) 53);
//        long long29 = week26.getLastMillisecond();
//        long long30 = week26.getMiddleMillisecond();
//        java.util.Date date31 = week26.getEnd();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        int int34 = week32.compareTo((java.lang.Object) 53);
//        long long35 = week32.getLastMillisecond();
//        long long36 = week32.getMiddleMillisecond();
//        java.util.Date date37 = week32.getEnd();
//        java.util.Date date38 = week32.getEnd();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        int int41 = week39.compareTo((java.lang.Object) 53);
//        long long42 = week39.getLastMillisecond();
//        long long43 = week39.getMiddleMillisecond();
//        java.util.Date date44 = week39.getEnd();
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date44, timeZone45);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date38, timeZone45);
//        java.lang.Class<?> wildcardClass48 = timeZone45.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        int int52 = week50.compareTo((java.lang.Object) 53);
//        long long53 = week50.getLastMillisecond();
//        long long54 = week50.getMiddleMillisecond();
//        java.util.Date date55 = week50.getEnd();
//        java.util.Date date56 = week50.getEnd();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        int int59 = week57.compareTo((java.lang.Object) 53);
//        long long60 = week57.getLastMillisecond();
//        long long61 = week57.getMiddleMillisecond();
//        java.util.Date date62 = week57.getEnd();
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date62, timeZone63);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date56, timeZone63);
//        java.lang.Class class66 = null;
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        int int69 = week67.compareTo((java.lang.Object) 53);
//        long long70 = week67.getLastMillisecond();
//        long long71 = week67.getMiddleMillisecond();
//        java.util.Date date72 = week67.getEnd();
//        java.util.Date date73 = week67.getEnd();
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week();
//        int int76 = week74.compareTo((java.lang.Object) 53);
//        long long77 = week74.getLastMillisecond();
//        long long78 = week74.getMiddleMillisecond();
//        java.util.Date date79 = week74.getEnd();
//        java.util.Date date80 = week74.getEnd();
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week();
//        int int83 = week81.compareTo((java.lang.Object) 53);
//        long long84 = week81.getLastMillisecond();
//        long long85 = week81.getMiddleMillisecond();
//        java.util.Date date86 = week81.getEnd();
//        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date86, timeZone87);
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date80, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date73, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date56, timeZone87);
//        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date31, timeZone87);
//        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date5, timeZone87);
//        int int94 = week93.getYearValue();
//        long long95 = week93.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560365999999L + "'", long12 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560668399999L + "'", long18 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560365999999L + "'", long19 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560668399999L + "'", long29 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560365999999L + "'", long30 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560668399999L + "'", long35 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560365999999L + "'", long36 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560668399999L + "'", long42 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560365999999L + "'", long43 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560668399999L + "'", long53 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560365999999L + "'", long54 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560668399999L + "'", long60 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560365999999L + "'", long61 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560668399999L + "'", long70 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560365999999L + "'", long71 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1560668399999L + "'", long77 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1560365999999L + "'", long78 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1560668399999L + "'", long84 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560365999999L + "'", long85 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNotNull(timeZone87);
//        org.junit.Assert.assertNull(regularTimePeriod90);
//        org.junit.Assert.assertNotNull(regularTimePeriod91);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 2019 + "'", int94 == 2019);
//        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 107031L + "'", long95 == 107031L);
//    }
//}

