import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType70 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        intervalMarker66.setLabelOffsetType(lengthAdjustmentType70);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(lengthAdjustmentType70);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint1.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart5 = chartChangeEvent4.getChart();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) chartChangeEvent4);
        org.jfree.chart.RenderingSource renderingSource7 = null;
        chartRenderingInfo0.setRenderingSource(renderingSource7);
        org.jfree.chart.RenderingSource renderingSource9 = chartRenderingInfo0.getRenderingSource();
        java.lang.Object obj10 = null;
        boolean boolean11 = chartRenderingInfo0.equals(obj10);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNull(jFreeChart5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(renderingSource9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.RenderingSource renderingSource12 = null;
        combinedDomainXYPlot0.select((double) 1L, (double) ' ', rectangle2D11, renderingSource12);
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean15 = piePlot3D14.getDarkerSides();
        combinedDomainXYPlot0.setParent((org.jfree.chart.plot.Plot) piePlot3D14);
        boolean boolean17 = combinedDomainXYPlot0.isDomainMinorGridlinesVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        timeSeriesCollection1.clearSelection();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setMinimumArcAngleToDraw((double) (byte) -1);
        piePlot3D3.setBackgroundImageAlignment(13);
        boolean boolean8 = timeSeriesCollection1.equals((java.lang.Object) piePlot3D3);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor9 = timeSeriesCollection1.getXPosition();
        try {
            java.lang.Number number12 = timeSeriesCollection1.getEndX((-16777216), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timePeriodAnchor9);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D8.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D8.setLabelLinkStroke(stroke11);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint15.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart19 = chartChangeEvent18.getChart();
        boolean boolean20 = chartRenderingInfo14.equals((java.lang.Object) chartChangeEvent18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo14.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState22 = piePlot3D0.initialise(graphics2D6, rectangle2D7, (org.jfree.chart.plot.PiePlot) piePlot3D8, (java.lang.Integer) 0, plotRenderingInfo21);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = null;
        combinedDomainXYPlot23.setFixedLegendItems(legendItemCollection24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        combinedDomainXYPlot23.setRenderer(xYItemRenderer26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray33 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray34 = color28.getRGBColorComponents(floatArray33);
        int int35 = color28.getAlpha();
        combinedDomainXYPlot23.setRangeTickBandPaint((java.awt.Paint) color28);
        piePlot3D8.setBackgroundPaint((java.awt.Paint) color28);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNull(jFreeChart19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(piePlotState22);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 255 + "'", int35 == 255);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart5.setBackgroundPaint((java.awt.Paint) color6);
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart5.createBufferedImage(8, (int) (short) 1);
        jFreeChart5.setTitle("UnitType.RELATIVE");
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(bufferedImage10);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 6, (double) 13);
        columnArrangement4.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator6 = logFormat4.formatToCharacterIterator((java.lang.Object) 0);
        logFormat4.setGroupingUsed(false);
        int int9 = logFormat4.getMinimumIntegerDigits();
        java.text.ParsePosition parsePosition11 = null;
        java.lang.Object obj12 = logFormat4.parseObject("java.awt.Color[r=128,g=128,b=255]", parsePosition11);
        org.junit.Assert.assertNotNull(attributedCharacterIterator6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator21 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj22 = standardXYToolTipGenerator21.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer24 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator21, xYURLGenerator23);
        java.lang.Object obj25 = standardXYToolTipGenerator21.clone();
        xYBarRenderer0.setSeriesToolTipGenerator(12, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator21);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray6, numberArray10, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset16, (double) (-2208960000000L));
        double double19 = range18.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range18, 100.0d);
        boolean boolean24 = range18.intersects((double) (byte) 10, (double) 9999);
        dateAxis0.setRange(range18, true, false);
        dateAxis0.setAutoRange(false);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-2.20896E12d) + "'", double19 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray7 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray8 = color2.getRGBColorComponents(floatArray7);
        int int9 = color2.getAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, (double) (-2208960000000L), (java.awt.Paint) color2);
        org.jfree.chart.text.TextAnchor textAnchor11 = intervalMarker10.getLabelTextAnchor();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries13 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection(timeSeries13);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        polarPlot12.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot12);
        java.util.List list18 = jFreeChart17.getSubtitles();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray27 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray28 = color22.getRGBColorComponents(floatArray27);
        int int29 = color22.getAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, (double) (-2208960000000L), (java.awt.Paint) color22);
        java.awt.Color color31 = java.awt.Color.getColor("Pie 3D Plot", color22);
        jFreeChart17.setBorderPaint((java.awt.Paint) color31);
        intervalMarker10.setLabelPaint((java.awt.Paint) color31);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 255 + "'", int29 == 255);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.RenderingSource renderingSource12 = null;
        combinedDomainXYPlot0.select((double) 1L, (double) ' ', rectangle2D11, renderingSource12);
        java.lang.String str14 = combinedDomainXYPlot0.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedDomainXYPlot0.getRenderer();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        combinedDomainXYPlot0.setFixedRangeAxisSpace(axisSpace16);
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean20 = logAxis19.isInverted();
        logAxis19.resizeRange(0.0d);
        java.awt.Paint paint23 = logAxis19.getTickMarkPaint();
        combinedDomainXYPlot0.setBackgroundPaint(paint23);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined_Domain_XYPlot" + "'", str14.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        combinedDomainXYPlot20.setGap((double) 12);
        org.jfree.chart.util.Layer layer72 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection73 = combinedDomainXYPlot20.getDomainMarkers(layer72);
        java.awt.Paint paint74 = null;
        try {
            combinedDomainXYPlot20.setRangeMinorGridlinePaint(paint74);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(layer72);
        org.junit.Assert.assertNull(collection73);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        org.jfree.chart.util.StrokeList strokeList4 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D6.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D6.setLabelLinkStroke(stroke9);
        strokeList4.setStroke(0, stroke9);
        logAxis1.setAxisLineStroke(stroke9);
        org.jfree.chart.plot.Plot plot13 = logAxis1.getPlot();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(plot13);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        double double6 = piePlot3D0.getLabelGap();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = piePlot3D0.getLegendLabelURLGenerator();
        java.awt.Stroke stroke8 = piePlot3D0.getLabelOutlineStroke();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
        org.junit.Assert.assertNull(pieURLGenerator7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        org.jfree.chart.StandardChartTheme standardChartTheme6 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        try {
            java.lang.String str7 = logFormat4.format((java.lang.Object) standardChartTheme6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        double double5 = logAxis1.calculateValue(0.0d);
        boolean boolean6 = logAxis1.isTickLabelsVisible();
        logAxis1.setAutoRangeMinimumSize((double) 5, false);
        logAxis1.setFixedAutoRange(9.0d);
        logAxis1.centerRange(0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        org.jfree.chart.LegendItem legendItem8 = xYStepRenderer2.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        combinedDomainXYPlot13.setFixedLegendItems(legendItemCollection14);
        java.awt.Paint paint16 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot13.setDomainGridlinePaint(paint16);
        boolean boolean18 = combinedDomainXYPlot13.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        combinedDomainXYPlot13.setDataset((int) (short) 0, xYDataset20);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.RenderingSource renderingSource25 = null;
        combinedDomainXYPlot13.select((double) 1L, (double) ' ', rectangle2D24, renderingSource25);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection27 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D28.setMinimumArcAngleToDraw((double) (byte) -1);
        double double31 = piePlot3D28.getInteriorGap();
        piePlot3D28.setDarkerSides(false);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D36.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D36.setLabelLinkStroke(stroke39);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint43.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart47 = chartChangeEvent46.getChart();
        boolean boolean48 = chartRenderingInfo42.equals((java.lang.Object) chartChangeEvent46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = chartRenderingInfo42.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState50 = piePlot3D28.initialise(graphics2D34, rectangle2D35, (org.jfree.chart.plot.PiePlot) piePlot3D36, (java.lang.Integer) 0, plotRenderingInfo49);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState51 = xYStepRenderer2.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13, (org.jfree.data.xy.XYDataset) xYSeriesCollection27, plotRenderingInfo49);
        try {
            org.jfree.data.xy.XYSeries xYSeries53 = xYSeriesCollection27.getSeries((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.08d + "'", double31 == 0.08d);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNull(jFreeChart47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo49);
        org.junit.Assert.assertNotNull(piePlotState50);
        org.junit.Assert.assertNotNull(xYItemRendererState51);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator3);
        boolean boolean5 = xYAreaRenderer4.getPlotArea();
        xYAreaRenderer4.setOutline(false);
        xYAreaRenderer4.setBaseItemLabelsVisible(false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D8.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D8.setLabelLinkStroke(stroke11);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint15.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart19 = chartChangeEvent18.getChart();
        boolean boolean20 = chartRenderingInfo14.equals((java.lang.Object) chartChangeEvent18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo14.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState22 = piePlot3D0.initialise(graphics2D6, rectangle2D7, (org.jfree.chart.plot.PiePlot) piePlot3D8, (java.lang.Integer) 0, plotRenderingInfo21);
        boolean boolean23 = piePlot3D0.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNull(jFreeChart19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(piePlotState22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        xYBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition5);
        java.awt.Paint paint8 = xYBarRenderer0.getSeriesFillPaint((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        double double5 = logAxis1.calculateValue(0.0d);
        boolean boolean6 = logAxis1.isTickLabelsVisible();
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        logAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange7, true, false);
        java.lang.String str11 = logAxis1.getLabel();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!�" + "'", str11.equals("hi!�"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        boolean boolean5 = xYStepRenderer2.getItemLineVisible((-1), (int) ' ');
        boolean boolean6 = xYStepRenderer2.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = xYStepRenderer2.getBaseToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator7);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator3);
        org.jfree.chart.LegendItem legendItem7 = xYAreaRenderer4.getLegendItem(12, 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYAreaRenderer4.getSeriesNegativeItemLabelPosition(1900);
        xYAreaRenderer4.setOutline(false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(legendItem7);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYStepRenderer2.getBaseToolTipGenerator();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font5);
        xYStepRenderer2.setBaseItemLabelFont(font5);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D8.setMinimumArcAngleToDraw((double) (byte) -1);
        double double11 = piePlot3D8.getInteriorGap();
        piePlot3D8.setDarkerSides(false);
        piePlot3D8.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D16 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean17 = piePlot3D16.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot3D16.getLegendLabelGenerator();
        piePlot3D8.setLegendLabelGenerator(pieSectionLabelGenerator18);
        java.awt.Shape shape20 = piePlot3D8.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries22 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection(timeSeries22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection23);
        polarPlot21.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection23);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot21);
        java.util.List list27 = jFreeChart26.getSubtitles();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity28 = new org.jfree.chart.entity.JFreeChartEntity(shape20, jFreeChart26);
        xYStepRenderer2.setLegendLine(shape20);
        double double30 = xYStepRenderer2.getStepPoint();
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08d + "'", double11 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        java.awt.Paint paint4 = piePlot3D0.getLabelPaint();
        try {
            piePlot3D0.setInteriorGap(10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (10.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) "PieLabelLinkStyle.STANDARD");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.START;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator(13, categoryToolTipGenerator2);
        java.awt.Paint paint4 = barRenderer0.getBaseLegendTextPaint();
        double double5 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator3);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        xYAreaRenderer4.setBaseURLGenerator(xYURLGenerator5);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        xYAreaRenderer4.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator7);
        java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYAreaRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = new org.jfree.chart.event.RendererChangeEvent(obj9, false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        java.util.List list8 = logAxis1.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge7);
        double double9 = logAxis1.getAutoRangeMinimumSize();
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator17 = logFormat15.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat15, (int) (byte) -1);
        logAxis1.setNumberFormatOverride((java.text.NumberFormat) logFormat15);
        logFormat15.setMinimumFractionDigits(2019);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-8d + "'", double9 == 1.0E-8d);
        org.junit.Assert.assertNotNull(attributedCharacterIterator17);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        org.jfree.chart.LegendItem legendItem8 = xYStepRenderer2.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        org.jfree.chart.plot.XYPlot xYPlot11 = xYStepRenderer2.getPlot();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator13 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj14 = standardXYToolTipGenerator13.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13, xYURLGenerator15);
        org.jfree.chart.LegendItem legendItem19 = xYAreaRenderer16.getLegendItem(12, 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = xYAreaRenderer16.getPositiveItemLabelPosition((int) (byte) 100, 0, true);
        xYStepRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition23, false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNull(xYPlot11);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock2, (java.lang.Object) 100L);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = labelBlock2.getMargin();
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean7 = piePlot3D6.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot3D6.getLegendLabelGenerator();
        boolean boolean9 = labelBlock2.equals((java.lang.Object) piePlot3D6);
        piePlot3D6.setMaximumLabelWidth((double) (byte) 1);
        boolean boolean12 = piePlot3D6.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        double double1 = combinedDomainXYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        double double2 = barRenderer0.getBase();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        boolean boolean3 = piePlot3D0.getAutoPopulateSectionOutlineStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator4);
        java.awt.Paint paint6 = piePlot3D0.getLabelBackgroundPaint();
        piePlot3D0.setInteriorGap(1.0E-8d);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator9 = null;
        piePlot3D0.setURLGenerator(pieURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.text.TextAnchor textAnchor5 = intervalMarker2.getLabelTextAnchor();
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis7.pan(0.0d);
        org.jfree.chart.util.StrokeList strokeList10 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D12.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D12.setLabelLinkStroke(stroke15);
        strokeList10.setStroke(0, stroke15);
        logAxis7.setAxisLineStroke(stroke15);
        intervalMarker2.setOutlineStroke(stroke15);
        intervalMarker2.setEndValue((double) 1);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator3);
        org.jfree.chart.LegendItem legendItem7 = xYAreaRenderer4.getLegendItem(12, 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYAreaRenderer4.getPositiveItemLabelPosition((int) (byte) 100, 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer12.setSeriesOutlinePaint((int) (short) 10, paint14);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection17 = null;
        combinedDomainXYPlot16.setFixedLegendItems(legendItemCollection17);
        java.awt.Paint paint19 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot16.setDomainGridlinePaint(paint19);
        boolean boolean21 = combinedDomainXYPlot16.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        combinedDomainXYPlot16.setDataset((int) (short) 0, xYDataset23);
        combinedDomainXYPlot16.setBackgroundImageAlignment((int) (byte) -1);
        int int27 = combinedDomainXYPlot16.getDatasetCount();
        xYBarRenderer12.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot16);
        xYBarRenderer12.setShadowXOffset(45.0d);
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem32.setShapeVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer35 = legendItem32.getFillPaintTransformer();
        xYBarRenderer12.setGradientPaintTransformer(gradientPaintTransformer35);
        xYAreaRenderer4.setGradientTransformer(gradientPaintTransformer35);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(legendItem7);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer35);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("Nearest", timeZone1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getYearValue();
        java.util.Date date5 = month3.getEnd();
        dateAxis2.setMaximumDate(date5);
        java.util.TimeZone timeZone7 = dateAxis2.getTimeZone();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CrosshairState crosshairState13 = null;
        boolean boolean14 = combinedDomainXYPlot0.render(graphics2D9, rectangle2D10, 10, plotRenderingInfo12, crosshairState13);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.Layer layer19 = null;
        combinedDomainXYPlot0.addRangeMarker((-4767), (org.jfree.chart.plot.Marker) intervalMarker18, layer19, true);
        org.jfree.data.general.DatasetGroup datasetGroup22 = combinedDomainXYPlot0.getDatasetGroup();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent23);
        boolean boolean25 = combinedDomainXYPlot0.isSubplot();
        int int26 = combinedDomainXYPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.BLACK;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2);
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textBlock4.setLineAlignment(horizontalAlignment5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment5, verticalAlignment7, 0.0d, (double) (-1.0f));
        flowArrangement10.clear();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYStepRenderer2.getBaseToolTipGenerator();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font5);
        xYStepRenderer2.setBaseItemLabelFont(font5);
        boolean boolean9 = xYStepRenderer2.equals((java.lang.Object) (byte) 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepRenderer2.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        java.awt.Stroke stroke18 = null;
        xYBarRenderer0.setSeriesOutlineStroke((int) (byte) 100, stroke18);
        boolean boolean20 = xYBarRenderer0.getBaseSeriesVisible();
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("", font22);
        xYBarRenderer0.setBaseItemLabelFont(font22);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        piePlot3D0.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean9 = piePlot3D8.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        java.awt.Shape shape12 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.plot.Plot plot13 = piePlot3D0.getRootPlot();
        java.awt.Paint paint15 = piePlot3D0.getSectionOutlinePaint((java.lang.Comparable) "12-January-1900");
        java.awt.Stroke stroke16 = piePlot3D0.getLabelLinkStroke();
        boolean boolean17 = piePlot3D0.getAutoPopulateSectionPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator18 = piePlot3D0.getLegendLabelURLGenerator();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(plot13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(pieURLGenerator18);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange2);
        java.lang.String str4 = dateRange2.toString();
        long long5 = dateRange2.getLowerMillis();
        boolean boolean6 = gradientPaintTransformType0.equals((java.lang.Object) long5);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str4.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.String str1 = size2D0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str1.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        java.awt.Color color2 = java.awt.Color.cyan;
        standardChartTheme1.setAxisLabelPaint((java.awt.Paint) color2);
        java.awt.Paint paint4 = standardChartTheme1.getAxisLabelPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = null;
        try {
            org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(xYBarPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        org.jfree.chart.LegendItem legendItem8 = xYStepRenderer2.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        xYStepRenderer2.setBaseShapesFilled(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(legendItem8);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) '#', "", textAnchor3, textAnchor4, (double) 6);
        java.lang.String str7 = numberTick6.getText();
        java.lang.Object obj8 = numberTick6.clone();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_PREFIX;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "index.html" + "'", str0.equals("index.html"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        float float1 = polarPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.5f + "'", float1 == 0.5f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = combinedDomainXYPlot0.getRangeMarkers((int) (short) 1, layer4);
        combinedDomainXYPlot0.clearDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis8 = combinedDomainXYPlot0.getDomainAxisForDataset(0);
        org.jfree.data.time.TimeSeries timeSeries10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeSeries10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection11, valueAxis12, polarItemRenderer13);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator15 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer17 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator15, xYURLGenerator16);
        java.awt.Paint paint18 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer17.setBaseItemLabelPaint(paint18, false);
        org.jfree.chart.LegendItem legendItem23 = xYStepRenderer17.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer17.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection29 = null;
        combinedDomainXYPlot28.setFixedLegendItems(legendItemCollection29);
        java.awt.Paint paint31 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot28.setDomainGridlinePaint(paint31);
        boolean boolean33 = combinedDomainXYPlot28.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        combinedDomainXYPlot28.setDataset((int) (short) 0, xYDataset35);
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.RenderingSource renderingSource40 = null;
        combinedDomainXYPlot28.select((double) 1L, (double) ' ', rectangle2D39, renderingSource40);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection42 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D43 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D43.setMinimumArcAngleToDraw((double) (byte) -1);
        double double46 = piePlot3D43.getInteriorGap();
        piePlot3D43.setDarkerSides(false);
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D51 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D51.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D51.setLabelLinkStroke(stroke54);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo57 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint60 = rectangleConstraint58.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent61 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart62 = chartChangeEvent61.getChart();
        boolean boolean63 = chartRenderingInfo57.equals((java.lang.Object) chartChangeEvent61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = chartRenderingInfo57.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState65 = piePlot3D43.initialise(graphics2D49, rectangle2D50, (org.jfree.chart.plot.PiePlot) piePlot3D51, (java.lang.Integer) 0, plotRenderingInfo64);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState66 = xYStepRenderer17.initialise(graphics2D26, rectangle2D27, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot28, (org.jfree.data.xy.XYDataset) xYSeriesCollection42, plotRenderingInfo64);
        timeSeriesCollection11.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection42);
        org.jfree.data.Range range69 = xYSeriesCollection42.getDomainBounds(false);
        double double70 = xYSeriesCollection42.getIntervalPositionFactor();
        combinedDomainXYPlot0.setDataset(100, (org.jfree.data.xy.XYDataset) xYSeriesCollection42);
        try {
            xYSeriesCollection42.setSelected(13, (int) (short) 0, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(legendItem23);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.08d + "'", double46 == 0.08d);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(rectangleConstraint58);
        org.junit.Assert.assertNotNull(rectangleConstraint60);
        org.junit.Assert.assertNull(jFreeChart62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo64);
        org.junit.Assert.assertNotNull(piePlotState65);
        org.junit.Assert.assertNotNull(xYItemRendererState66);
        org.junit.Assert.assertNull(range69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.5d + "'", double70 == 0.5d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot3D0.getLegendLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset3 = piePlot3D0.getDataset();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNull(pieDataset3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        piePlot3D0.setBackgroundImageAlignment(13);
        boolean boolean5 = piePlot3D0.getAutoPopulateSectionOutlinePaint();
        java.lang.String str6 = piePlot3D0.getPlotType();
        int int7 = piePlot3D0.getPieIndex();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pie 3D Plot" + "'", str6.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock2, (java.lang.Object) 100L);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray10, numberArray14, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset20, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) categoryDataset20, (java.lang.Comparable) (short) 1);
        java.lang.Object obj25 = legendItemBlockContainer24.clone();
        java.lang.String str26 = legendItemBlockContainer24.getID();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D30 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D30.setMinimumArcAngleToDraw((double) (byte) -1);
        double double33 = piePlot3D30.getInteriorGap();
        piePlot3D30.setDarkerSides(false);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D38 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D38.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D38.setLabelLinkStroke(stroke41);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = rectangleConstraint45.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart49 = chartChangeEvent48.getChart();
        boolean boolean50 = chartRenderingInfo44.equals((java.lang.Object) chartChangeEvent48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = chartRenderingInfo44.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState52 = piePlot3D30.initialise(graphics2D36, rectangle2D37, (org.jfree.chart.plot.PiePlot) piePlot3D38, (java.lang.Integer) 0, plotRenderingInfo51);
        java.awt.geom.Rectangle2D rectangle2D53 = plotRenderingInfo51.getDataArea();
        boolean boolean54 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 4, (double) (-398), rectangle2D53);
        try {
            legendItemBlockContainer24.draw(graphics2D27, rectangle2D53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.08d + "'", double33 == 0.08d);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNotNull(rectangleConstraint47);
        org.junit.Assert.assertNull(jFreeChart49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo51);
        org.junit.Assert.assertNotNull(piePlotState52);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = xYPlot4.getAxisOffset();
        xYPlot4.clearSelection();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxis();
        org.jfree.chart.plot.Plot plot8 = xYPlot4.getParent();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        boolean boolean6 = xYStepRenderer2.getBaseLinesVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = xYStepRenderer2.getToolTipGenerator(0, (int) (byte) 100, true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(xYToolTipGenerator10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        combinedDomainXYPlot20.setGap((double) 12);
        combinedDomainXYPlot20.setRangeCrosshairValue((-1.0d));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.DomainOrder domainOrder1 = xYSeriesCollection0.getDomainOrder();
        java.lang.String str2 = domainOrder1.toString();
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DomainOrder.ASCENDING" + "'", str2.equals("DomainOrder.ASCENDING"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        combinedDomainXYPlot0.setRangeGridlinePaint(paint5);
        boolean boolean7 = combinedDomainXYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot0.getRenderer();
        java.awt.Stroke stroke6 = combinedDomainXYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        combinedDomainXYPlot7.setFixedLegendItems(legendItemCollection8);
        java.awt.Paint paint10 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot7.setDomainGridlinePaint(paint10);
        boolean boolean12 = combinedDomainXYPlot7.canSelectByPoint();
        int int13 = combinedDomainXYPlot7.getSeriesCount();
        int int14 = combinedDomainXYPlot7.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = combinedDomainXYPlot7.getLegendItems();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem17.setShapeVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = legendItem17.getFillPaintTransformer();
        legendItem17.setURLText("hi!�");
        legendItemCollection15.add(legendItem17);
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection15);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        boolean boolean3 = piePlot3D0.getAutoPopulateSectionOutlineStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator4);
        java.awt.Paint paint6 = piePlot3D0.getLabelBackgroundPaint();
        piePlot3D0.setInteriorGap(1.0E-8d);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator9 = piePlot3D0.getURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(pieURLGenerator9);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        piePlot3D0.setStartAngle((double) (byte) -1);
        piePlot3D0.setShadowYOffset((double) (short) 100);
        int int7 = piePlot3D0.getPieIndex();
        piePlot3D0.setShadowYOffset(0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator8 = logFormat6.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat6, (int) (byte) -1);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        logFormat15.setMinimumIntegerDigits((int) (short) 100);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator18 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined_Domain_XYPlot", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat15);
        int int19 = logFormat6.getMaximumFractionDigits();
        org.junit.Assert.assertNotNull(attributedCharacterIterator8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.awt.Font font2 = labelBlock1.getFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj4 = categoryAxis3.clone();
        java.lang.Object obj5 = categoryAxis3.clone();
        categoryAxis3.setCategoryMargin(0.08d);
        boolean boolean8 = labelBlock1.equals((java.lang.Object) 0.08d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        timeSeriesCollection1.clearSelection();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setMinimumArcAngleToDraw((double) (byte) -1);
        piePlot3D3.setBackgroundImageAlignment(13);
        boolean boolean8 = timeSeriesCollection1.equals((java.lang.Object) piePlot3D3);
        java.awt.Paint paint9 = piePlot3D3.getLabelPaint();
        double double10 = piePlot3D3.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        int int2 = legendItem1.getDatasetIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.TOP" + "'", str1.equals("VerticalAlignment.TOP"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean2 = rectangleAnchor0.equals((java.lang.Object) textAnchor1);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("[size=hi!-0.0]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        java.util.List list8 = logAxis1.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge7);
        double double9 = logAxis1.getFixedDimension();
        double double10 = logAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = dateAxis0.getTickLabelInsets();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets1.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(unitType2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        double double5 = logAxis1.calculateValue(0.0d);
        boolean boolean6 = logAxis1.isTickLabelsVisible();
        logAxis1.setAutoRangeMinimumSize((double) 5, false);
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D14.setMinimumArcAngleToDraw((double) (byte) -1);
        double double17 = piePlot3D14.getInteriorGap();
        piePlot3D14.setDarkerSides(false);
        piePlot3D14.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D22 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean23 = piePlot3D22.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator24 = piePlot3D22.getLegendLabelGenerator();
        piePlot3D14.setLegendLabelGenerator(pieSectionLabelGenerator24);
        java.awt.Shape shape26 = piePlot3D14.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries28 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection29 = new org.jfree.data.time.TimeSeriesCollection(timeSeries28);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection29);
        polarPlot27.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection29);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot27);
        java.util.List list33 = jFreeChart32.getSubtitles();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity34 = new org.jfree.chart.entity.JFreeChartEntity(shape26, jFreeChart32);
        java.awt.Paint paint35 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("Last", "HorizontalAlignment.CENTER", "Pie 3D Plot", "", shape26, paint35);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity39 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis1, shape26, "hi!�", "hi!�");
        try {
            logAxis1.setRangeWithMargins((double) 100, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.08d + "'", double17 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("Nearest", timeZone1);
        java.util.Locale locale3 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource4 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone1, locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray14);
        java.lang.Number number16 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.data.general.PieDataset pieDataset18 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset15, 0);
        org.jfree.data.general.PieDataset pieDataset21 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset18, (java.lang.Comparable) "PieLabelLinkStyle.STANDARD", (double) (byte) 100);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1.0d + "'", number16.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset18);
        org.junit.Assert.assertNotNull(pieDataset21);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer7 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator5, xYURLGenerator6);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer7.setBaseItemLabelPaint(paint8, false);
        org.jfree.chart.LegendItem legendItem13 = xYStepRenderer7.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer7.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = null;
        combinedDomainXYPlot18.setFixedLegendItems(legendItemCollection19);
        java.awt.Paint paint21 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot18.setDomainGridlinePaint(paint21);
        boolean boolean23 = combinedDomainXYPlot18.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        combinedDomainXYPlot18.setDataset((int) (short) 0, xYDataset25);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.RenderingSource renderingSource30 = null;
        combinedDomainXYPlot18.select((double) 1L, (double) ' ', rectangle2D29, renderingSource30);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection32 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D33.setMinimumArcAngleToDraw((double) (byte) -1);
        double double36 = piePlot3D33.getInteriorGap();
        piePlot3D33.setDarkerSides(false);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D41 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D41.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D41.setLabelLinkStroke(stroke44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = rectangleConstraint48.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent51 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart52 = chartChangeEvent51.getChart();
        boolean boolean53 = chartRenderingInfo47.equals((java.lang.Object) chartChangeEvent51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = chartRenderingInfo47.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState55 = piePlot3D33.initialise(graphics2D39, rectangle2D40, (org.jfree.chart.plot.PiePlot) piePlot3D41, (java.lang.Integer) 0, plotRenderingInfo54);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState56 = xYStepRenderer7.initialise(graphics2D16, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot18, (org.jfree.data.xy.XYDataset) xYSeriesCollection32, plotRenderingInfo54);
        boolean boolean57 = intervalMarker2.equals((java.lang.Object) graphics2D16);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator59 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj60 = standardXYToolTipGenerator59.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator61 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer62 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator59, xYURLGenerator61);
        boolean boolean63 = xYAreaRenderer62.getPlotLines();
        java.awt.Stroke stroke64 = xYAreaRenderer62.getBaseOutlineStroke();
        intervalMarker2.setStroke(stroke64);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.08d + "'", double36 == 0.08d);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
        org.junit.Assert.assertNotNull(rectangleConstraint50);
        org.junit.Assert.assertNull(jFreeChart52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo54);
        org.junit.Assert.assertNotNull(piePlotState55);
        org.junit.Assert.assertNotNull(xYItemRendererState56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(stroke64);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        combinedDomainXYPlot0.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = combinedDomainXYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = combinedDomainXYPlot0.removeDomainMarker(12, (org.jfree.chart.plot.Marker) intervalMarker15, layer16);
        int int18 = combinedDomainXYPlot0.getSeriesCount();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart5.setBackgroundPaint((java.awt.Paint) color6);
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart5.createBufferedImage(8, (int) (short) 1);
        jFreeChart5.setAntiAlias(false);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(bufferedImage10);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = itemLabelPosition2.getRotationAnchor();
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection5, valueAxis6, polarItemRenderer7);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer11 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator9, xYURLGenerator10);
        java.awt.Paint paint12 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer11.setBaseItemLabelPaint(paint12, false);
        org.jfree.chart.LegendItem legendItem17 = xYStepRenderer11.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer11.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = null;
        combinedDomainXYPlot22.setFixedLegendItems(legendItemCollection23);
        java.awt.Paint paint25 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot22.setDomainGridlinePaint(paint25);
        boolean boolean27 = combinedDomainXYPlot22.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        combinedDomainXYPlot22.setDataset((int) (short) 0, xYDataset29);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.RenderingSource renderingSource34 = null;
        combinedDomainXYPlot22.select((double) 1L, (double) ' ', rectangle2D33, renderingSource34);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection36 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D37.setMinimumArcAngleToDraw((double) (byte) -1);
        double double40 = piePlot3D37.getInteriorGap();
        piePlot3D37.setDarkerSides(false);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D45 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D45.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D45.setLabelLinkStroke(stroke48);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo51 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint52 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = rectangleConstraint52.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent55 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart56 = chartChangeEvent55.getChart();
        boolean boolean57 = chartRenderingInfo51.equals((java.lang.Object) chartChangeEvent55);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = chartRenderingInfo51.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState59 = piePlot3D37.initialise(graphics2D43, rectangle2D44, (org.jfree.chart.plot.PiePlot) piePlot3D45, (java.lang.Integer) 0, plotRenderingInfo58);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState60 = xYStepRenderer11.initialise(graphics2D20, rectangle2D21, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot22, (org.jfree.data.xy.XYDataset) xYSeriesCollection36, plotRenderingInfo58);
        timeSeriesCollection5.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection36);
        org.jfree.chart.ui.ProjectInfo projectInfo62 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.axis.LogAxis logAxis64 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis64.pan(0.0d);
        java.awt.Graphics2D graphics2D67 = null;
        org.jfree.chart.axis.AxisState axisState68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = null;
        java.util.List list71 = logAxis64.refreshTicks(graphics2D67, axisState68, rectangle2D69, rectangleEdge70);
        projectInfo62.setContributors(list71);
        org.jfree.data.Range range74 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection5, list71, true);
        java.lang.Object obj75 = timeSeriesCollection5.clone();
        boolean boolean76 = itemLabelPosition2.equals((java.lang.Object) timeSeriesCollection5);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(legendItem17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.08d + "'", double40 == 0.08d);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleConstraint52);
        org.junit.Assert.assertNotNull(rectangleConstraint54);
        org.junit.Assert.assertNull(jFreeChart56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo58);
        org.junit.Assert.assertNotNull(piePlotState59);
        org.junit.Assert.assertNotNull(xYItemRendererState60);
        org.junit.Assert.assertNotNull(list71);
        org.junit.Assert.assertNull(range74);
        org.junit.Assert.assertNotNull(obj75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        java.awt.Font font3 = standardChartTheme2.getExtraLargeFont();
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer8 = new org.jfree.chart.text.G2TextMeasurer(graphics2D7);
        try {
            org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("DatasetRenderingOrder.REVERSE", font3, paint4, (float) (-16777216), (int) (byte) 100, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 60000L, (double) 2.0f, (double) 15, (double) (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange1);
        java.lang.String str3 = dateRange1.toString();
        long long4 = dateRange1.getLowerMillis();
        java.util.Date date5 = dateRange1.getLowerDate();
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str3.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYStepRenderer2.getLegendItems();
        int int4 = xYStepRenderer2.getPassCount();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection6, valueAxis7, polarItemRenderer8);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator10, xYURLGenerator11);
        java.awt.Paint paint13 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer12.setBaseItemLabelPaint(paint13, false);
        org.jfree.chart.LegendItem legendItem18 = xYStepRenderer12.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer12.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = null;
        combinedDomainXYPlot23.setFixedLegendItems(legendItemCollection24);
        java.awt.Paint paint26 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot23.setDomainGridlinePaint(paint26);
        boolean boolean28 = combinedDomainXYPlot23.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        combinedDomainXYPlot23.setDataset((int) (short) 0, xYDataset30);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.RenderingSource renderingSource35 = null;
        combinedDomainXYPlot23.select((double) 1L, (double) ' ', rectangle2D34, renderingSource35);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection37 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D38 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D38.setMinimumArcAngleToDraw((double) (byte) -1);
        double double41 = piePlot3D38.getInteriorGap();
        piePlot3D38.setDarkerSides(false);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D46 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D46.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D46.setLabelLinkStroke(stroke49);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo52 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint53 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = rectangleConstraint53.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent56 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart57 = chartChangeEvent56.getChart();
        boolean boolean58 = chartRenderingInfo52.equals((java.lang.Object) chartChangeEvent56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = chartRenderingInfo52.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState60 = piePlot3D38.initialise(graphics2D44, rectangle2D45, (org.jfree.chart.plot.PiePlot) piePlot3D46, (java.lang.Integer) 0, plotRenderingInfo59);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState61 = xYStepRenderer12.initialise(graphics2D21, rectangle2D22, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot23, (org.jfree.data.xy.XYDataset) xYSeriesCollection37, plotRenderingInfo59);
        timeSeriesCollection6.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection37);
        boolean boolean63 = xYStepRenderer2.equals((java.lang.Object) xYSeriesCollection37);
        org.jfree.data.xy.XYSeries xYSeries64 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection65 = new org.jfree.data.xy.XYSeriesCollection(xYSeries64);
        boolean boolean66 = xYSeriesCollection37.hasListener((java.util.EventListener) xYSeriesCollection65);
        try {
            java.lang.Number number69 = xYSeriesCollection65.getStartX((int) 'a', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem18);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.08d + "'", double41 == 0.08d);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(rectangleConstraint53);
        org.junit.Assert.assertNotNull(rectangleConstraint55);
        org.junit.Assert.assertNull(jFreeChart57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo59);
        org.junit.Assert.assertNotNull(piePlotState60);
        org.junit.Assert.assertNotNull(xYItemRendererState61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray10 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray11 = color5.getRGBColorComponents(floatArray10);
        int int12 = color5.getAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, (double) (-2208960000000L), (java.awt.Paint) color5);
        java.awt.Color color14 = java.awt.Color.getColor("Pie 3D Plot", color5);
        standardChartTheme1.setLegendItemPaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        combinedDomainXYPlot0.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.xy.XYSeries xYSeries11 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection12 = new org.jfree.data.xy.XYSeriesCollection(xYSeries11);
        double double14 = xYSeriesCollection12.getDomainLowerBound(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedDomainXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection12);
        double double16 = xYSeriesCollection12.getIntervalPositionFactor();
        try {
            int[] intArray20 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) xYSeriesCollection12, 9999, 45.0d, 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.5d + "'", double16 == 0.5d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Size2D[width=0.0, height=0.0]");
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean2 = logAxis1.isInverted();
        logAxis1.resizeRange(0.0d);
        logAxis1.setLowerMargin((double) 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CrosshairState crosshairState13 = null;
        boolean boolean14 = combinedDomainXYPlot0.render(graphics2D9, rectangle2D10, 10, plotRenderingInfo12, crosshairState13);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.Layer layer19 = null;
        combinedDomainXYPlot0.addRangeMarker((-4767), (org.jfree.chart.plot.Marker) intervalMarker18, layer19, true);
        java.awt.Stroke stroke22 = intervalMarker18.getStroke();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart5.setTitle("12-January-1900");
        java.lang.Object obj8 = jFreeChart5.clone();
        float float9 = jFreeChart5.getBackgroundImageAlpha();
        jFreeChart5.fireChartChanged();
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart5.getTitle();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint13.toFixedWidth((double) 0.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint15.toUnconstrainedHeight();
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] { numberArray22, numberArray26, numberArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray31);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset32, (double) (-2208960000000L));
        double double35 = range34.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint(range34, 100.0d);
        boolean boolean40 = range34.intersects((double) (byte) 10, (double) 9999);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = rectangleConstraint15.toRangeWidth(range34);
        try {
            org.jfree.chart.util.Size2D size2D42 = textTitle11.arrange(graphics2D12, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-2.20896E12d) + "'", double35 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint41);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYStepRenderer2.getBaseToolTipGenerator();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font5);
        xYStepRenderer2.setBaseItemLabelFont(font5);
        xYStepRenderer2.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) (byte) 1, true);
        xYStepRenderer2.notifyListeners(rendererChangeEvent13);
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D15.setMinimumArcAngleToDraw((double) (byte) -1);
        double double18 = piePlot3D15.getInteriorGap();
        java.awt.Paint paint19 = piePlot3D15.getLabelPaint();
        xYStepRenderer2.setBasePaint(paint19, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = xYStepRenderer2.getSeriesURLGenerator((int) (byte) -1);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.08d + "'", double18 == 0.08d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(xYURLGenerator23);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 900000L, (double) (-398));
        double double3 = size2D2.getHeight();
        size2D2.width = 8;
        java.lang.Object obj6 = size2D2.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-398.0d) + "'", double3 == (-398.0d));
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation2 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer3.setSeriesOutlinePaint((int) (short) 10, paint5);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        combinedDomainXYPlot7.setFixedLegendItems(legendItemCollection8);
        java.awt.Paint paint10 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot7.setDomainGridlinePaint(paint10);
        boolean boolean12 = combinedDomainXYPlot7.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        combinedDomainXYPlot7.setDataset((int) (short) 0, xYDataset14);
        combinedDomainXYPlot7.setBackgroundImageAlignment((int) (byte) -1);
        int int18 = combinedDomainXYPlot7.getDatasetCount();
        xYBarRenderer3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot7);
        xYBarRenderer3.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = null;
        combinedDomainXYPlot23.setFixedLegendItems(legendItemCollection24);
        java.awt.Paint paint26 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot23.setDomainGridlinePaint(paint26);
        boolean boolean28 = combinedDomainXYPlot23.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        combinedDomainXYPlot23.setDataset((int) (short) 0, xYDataset30);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.RenderingSource renderingSource35 = null;
        combinedDomainXYPlot23.select((double) 1L, (double) ' ', rectangle2D34, renderingSource35);
        java.lang.String str37 = combinedDomainXYPlot23.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = combinedDomainXYPlot23.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray45, numberArray49, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray54);
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset55, (double) (-2208960000000L));
        double double58 = range57.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint60 = new org.jfree.chart.block.RectangleConstraint(range57, 100.0d);
        boolean boolean63 = range57.intersects((double) (byte) 10, (double) 9999);
        dateAxis39.setRange(range57, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker69 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str70 = intervalMarker69.getLabel();
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        xYBarRenderer3.drawRangeMarker(graphics2D22, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot23, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.plot.Marker) intervalMarker69, rectangle2D71);
        combinedDomainXYPlot23.setGap((double) 12);
        org.jfree.chart.util.Layer layer75 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection76 = combinedDomainXYPlot23.getDomainMarkers(layer75);
        try {
            barRenderer0.addAnnotation(categoryAnnotation2, layer75);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Combined_Domain_XYPlot" + "'", str37.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + (-2.20896E12d) + "'", double58 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNotNull(layer75);
        org.junit.Assert.assertNull(collection76);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart5.setBackgroundPaint((java.awt.Paint) color6);
        jFreeChart5.removeLegend();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 0L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj1 = categoryPlot0.clone();
        java.awt.Stroke stroke2 = categoryPlot0.getRangeZeroBaselineStroke();
        categoryPlot0.mapDatasetToRangeAxis((int) (short) 100, 10);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        int int6 = combinedDomainXYPlot0.getSeriesCount();
        boolean boolean7 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer9.setSeriesOutlinePaint((int) (short) 10, paint11);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        combinedDomainXYPlot13.setFixedLegendItems(legendItemCollection14);
        java.awt.Paint paint16 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot13.setDomainGridlinePaint(paint16);
        boolean boolean18 = combinedDomainXYPlot13.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        combinedDomainXYPlot13.setDataset((int) (short) 0, xYDataset20);
        combinedDomainXYPlot13.setBackgroundImageAlignment((int) (byte) -1);
        int int24 = combinedDomainXYPlot13.getDatasetCount();
        xYBarRenderer9.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot13);
        xYBarRenderer9.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot29 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        combinedDomainXYPlot29.setFixedLegendItems(legendItemCollection30);
        java.awt.Paint paint32 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot29.setDomainGridlinePaint(paint32);
        boolean boolean34 = combinedDomainXYPlot29.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        combinedDomainXYPlot29.setDataset((int) (short) 0, xYDataset36);
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.RenderingSource renderingSource41 = null;
        combinedDomainXYPlot29.select((double) 1L, (double) ' ', rectangle2D40, renderingSource41);
        java.lang.String str43 = combinedDomainXYPlot29.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = combinedDomainXYPlot29.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray59 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray60 = new java.lang.Number[][] { numberArray51, numberArray55, numberArray59 };
        org.jfree.data.category.CategoryDataset categoryDataset61 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray60);
        org.jfree.data.Range range63 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset61, (double) (-2208960000000L));
        double double64 = range63.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint66 = new org.jfree.chart.block.RectangleConstraint(range63, 100.0d);
        boolean boolean69 = range63.intersects((double) (byte) 10, (double) 9999);
        dateAxis45.setRange(range63, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker75 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str76 = intervalMarker75.getLabel();
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        xYBarRenderer9.drawRangeMarker(graphics2D28, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot29, (org.jfree.chart.axis.ValueAxis) dateAxis45, (org.jfree.chart.plot.Marker) intervalMarker75, rectangle2D77);
        combinedDomainXYPlot29.setGap((double) 12);
        org.jfree.chart.util.Layer layer81 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection82 = combinedDomainXYPlot29.getDomainMarkers(layer81);
        java.util.Collection collection83 = combinedDomainXYPlot0.getRangeMarkers((int) (byte) 0, layer81);
        java.util.List list84 = combinedDomainXYPlot0.getSubplots();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Combined_Domain_XYPlot" + "'", str43.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer44);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(categoryDataset61);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + (-2.20896E12d) + "'", double64 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNull(str76);
        org.junit.Assert.assertNotNull(layer81);
        org.junit.Assert.assertNull(collection82);
        org.junit.Assert.assertNull(collection83);
        org.junit.Assert.assertNotNull(list84);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray6, numberArray10, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset16);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset16, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj21 = categoryAxis20.clone();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer23.setSeriesOutlinePaint((int) (short) 10, paint25);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        combinedDomainXYPlot27.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot27.setDomainGridlinePaint(paint30);
        boolean boolean32 = combinedDomainXYPlot27.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        combinedDomainXYPlot27.setDataset((int) (short) 0, xYDataset34);
        combinedDomainXYPlot27.setBackgroundImageAlignment((int) (byte) -1);
        int int38 = combinedDomainXYPlot27.getDatasetCount();
        xYBarRenderer23.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot27);
        java.awt.Font font41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer23.setLegendTextFont((int) (short) 100, font41);
        categoryAxis20.setTickLabelFont((java.lang.Comparable) month22, font41);
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset19, (java.lang.Comparable) month22, (double) 5, 12);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int48 = month47.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod49, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeriesDataItem51.getPeriod();
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("UnitType.ABSOLUTE", (org.jfree.data.time.RegularTimePeriod) month22, regularTimePeriod52);
        try {
            org.jfree.data.Range range54 = periodAxis53.getRange();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.5593724E12) <= upper (1.559372399999E12).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(pieDataset46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYStepRenderer2.getBaseToolTipGenerator();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font5);
        xYStepRenderer2.setBaseItemLabelFont(font5);
        xYStepRenderer2.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) (byte) 1, true);
        xYStepRenderer2.notifyListeners(rendererChangeEvent13);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator15 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        java.lang.Object obj16 = standardXYSeriesLabelGenerator15.clone();
        xYStepRenderer2.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator15);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock2, (java.lang.Object) 100L);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray10, numberArray14, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset20, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) categoryDataset20, (java.lang.Comparable) (short) 1);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer28);
        boolean boolean31 = legendTitle30.visible;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = legendTitle30.getPosition();
        legendItemBlockContainer24.add((org.jfree.chart.block.Block) legendTitle30);
        java.awt.Graphics2D graphics2D34 = null;
        try {
            org.jfree.chart.util.Size2D size2D35 = legendTitle30.arrange(graphics2D34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean2 = logAxis1.isInverted();
        logAxis1.resizeRange(0.0d);
        logAxis1.configure();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray6, numberArray10, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset16);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset16, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj21 = categoryAxis20.clone();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer23.setSeriesOutlinePaint((int) (short) 10, paint25);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        combinedDomainXYPlot27.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot27.setDomainGridlinePaint(paint30);
        boolean boolean32 = combinedDomainXYPlot27.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        combinedDomainXYPlot27.setDataset((int) (short) 0, xYDataset34);
        combinedDomainXYPlot27.setBackgroundImageAlignment((int) (byte) -1);
        int int38 = combinedDomainXYPlot27.getDatasetCount();
        xYBarRenderer23.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot27);
        java.awt.Font font41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer23.setLegendTextFont((int) (short) 100, font41);
        categoryAxis20.setTickLabelFont((java.lang.Comparable) month22, font41);
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset19, (java.lang.Comparable) month22, (double) 5, 12);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int48 = month47.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod49, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeriesDataItem51.getPeriod();
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("UnitType.ABSOLUTE", (org.jfree.data.time.RegularTimePeriod) month22, regularTimePeriod52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = periodAxis53.getLast();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        long long56 = month55.getFirstMillisecond();
        periodAxis53.setFirst((org.jfree.data.time.RegularTimePeriod) month55);
        periodAxis53.configure();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(pieDataset46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1559372400000L + "'", long56 == 1559372400000L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj4 = standardXYToolTipGenerator3.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator5);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer6.getLegendItem(12, 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer6.setBasePaint((java.awt.Paint) color10, true);
        standardChartTheme1.setShadowPaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter17 = new org.jfree.chart.renderer.category.GradientBarPainter(4.0d, (double) (byte) 10, 0.0d);
        standardChartTheme1.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter17);
        java.awt.Paint paint19 = standardChartTheme1.getAxisLabelPaint();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray6, numberArray10, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset16);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset16, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj21 = categoryAxis20.clone();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer23.setSeriesOutlinePaint((int) (short) 10, paint25);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        combinedDomainXYPlot27.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot27.setDomainGridlinePaint(paint30);
        boolean boolean32 = combinedDomainXYPlot27.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        combinedDomainXYPlot27.setDataset((int) (short) 0, xYDataset34);
        combinedDomainXYPlot27.setBackgroundImageAlignment((int) (byte) -1);
        int int38 = combinedDomainXYPlot27.getDatasetCount();
        xYBarRenderer23.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot27);
        java.awt.Font font41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer23.setLegendTextFont((int) (short) 100, font41);
        categoryAxis20.setTickLabelFont((java.lang.Comparable) month22, font41);
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset19, (java.lang.Comparable) month22, (double) 5, 12);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int48 = month47.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod49, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeriesDataItem51.getPeriod();
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("UnitType.ABSOLUTE", (org.jfree.data.time.RegularTimePeriod) month22, regularTimePeriod52);
        periodAxis53.setMinorTickMarkOutsideLength((float) 0);
        org.jfree.chart.plot.PiePlot3D piePlot3D56 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D56.setMinimumArcAngleToDraw((double) (byte) -1);
        double double59 = piePlot3D56.getInteriorGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent60 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3D56);
        org.jfree.data.general.PieDataset pieDataset61 = piePlot3D56.getDataset();
        boolean boolean62 = piePlot3D56.getSectionOutlinesVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker65 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.awt.Stroke stroke66 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        intervalMarker65.setStroke(stroke66);
        piePlot3D56.setBaseSectionOutlineStroke(stroke66);
        boolean boolean69 = periodAxis53.equals((java.lang.Object) piePlot3D56);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(pieDataset46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.08d + "'", double59 == 0.08d);
        org.junit.Assert.assertNull(pieDataset61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot0.getRenderer();
        java.awt.Stroke stroke6 = combinedDomainXYPlot0.getDomainZeroBaselineStroke();
        boolean boolean7 = combinedDomainXYPlot0.isRangePannable();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth((double) 0.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray9, numberArray13, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset19, (double) (-2208960000000L));
        double double22 = range21.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint(range21, 100.0d);
        boolean boolean27 = range21.intersects((double) (byte) 10, (double) 9999);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint2.toRangeWidth(range21);
        java.lang.String str29 = rectangleConstraint2.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-2.20896E12d) + "'", double22 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]" + "'", str29.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer70 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean71 = xYBarRenderer70.isDrawBarOutline();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator72 = null;
        xYBarRenderer70.setBaseItemLabelGenerator(xYItemLabelGenerator72, true);
        int int75 = combinedDomainXYPlot20.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer70);
        java.awt.Paint paint76 = combinedDomainXYPlot20.getRangeTickBandPaint();
        int int77 = combinedDomainXYPlot20.getSeriesCount();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNull(paint76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D2.setMinimumArcAngleToDraw((double) (byte) -1);
        piePlot3D2.setBackgroundImageAlignment(13);
        boolean boolean7 = piePlot3D2.getAutoPopulateSectionOutlinePaint();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        piePlot3D2.setLabelBackgroundPaint((java.awt.Paint) color8);
        paintList0.setPaint((int) (byte) 1, (java.awt.Paint) color8);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        java.lang.String str2 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str2.equals("Rotation.ANTICLOCKWISE"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = (-1L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = null;
        combinedDomainXYPlot5.setFixedLegendItems(legendItemCollection6);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot5.setDomainGridlinePaint(paint8);
        boolean boolean10 = combinedDomainXYPlot5.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        combinedDomainXYPlot5.setDataset((int) (short) 0, xYDataset12);
        combinedDomainXYPlot5.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = combinedDomainXYPlot5.getDatasetRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = combinedDomainXYPlot5.removeDomainMarker(12, (org.jfree.chart.plot.Marker) intervalMarker20, layer21);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot4.setRenderer(xYItemRenderer24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation(2019, axisLocation27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double31 = rectangleInsets29.calculateRightOutset((double) 900000L);
        double double33 = rectangleInsets29.calculateLeftOutset(0.05d);
        xYPlot4.setInsets(rectangleInsets29, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean38 = xYBarRenderer37.isDrawBarOutline();
        xYBarRenderer37.setBaseCreateEntities(false);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot42 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection43 = null;
        combinedDomainXYPlot42.setFixedLegendItems(legendItemCollection43);
        java.awt.Paint paint45 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot42.setDomainGridlinePaint(paint45);
        int int47 = combinedDomainXYPlot42.getDomainAxisCount();
        org.jfree.chart.axis.LogAxis logAxis49 = new org.jfree.chart.axis.LogAxis("hi!�");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot50 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection51 = null;
        combinedDomainXYPlot50.setFixedLegendItems(legendItemCollection51);
        java.awt.Paint paint53 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot50.setDomainGridlinePaint(paint53);
        boolean boolean55 = combinedDomainXYPlot50.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        combinedDomainXYPlot50.setDataset((int) (short) 0, xYDataset57);
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = null;
        org.jfree.chart.plot.CrosshairState crosshairState63 = null;
        boolean boolean64 = combinedDomainXYPlot50.render(graphics2D59, rectangle2D60, 10, plotRenderingInfo62, crosshairState63);
        org.jfree.chart.plot.IntervalMarker intervalMarker68 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.Layer layer69 = null;
        combinedDomainXYPlot50.addRangeMarker((-4767), (org.jfree.chart.plot.Marker) intervalMarker68, layer69, true);
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        xYBarRenderer37.drawDomainMarker(graphics2D41, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot42, (org.jfree.chart.axis.ValueAxis) logAxis49, (org.jfree.chart.plot.Marker) intervalMarker68, rectangle2D72);
        try {
            xYPlot4.setRangeAxis((int) (byte) -1, (org.jfree.chart.axis.ValueAxis) logAxis49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.0d + "'", double33 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer70 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean71 = xYBarRenderer70.isDrawBarOutline();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator72 = null;
        xYBarRenderer70.setBaseItemLabelGenerator(xYItemLabelGenerator72, true);
        int int75 = combinedDomainXYPlot20.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer70);
        java.awt.Paint paint76 = combinedDomainXYPlot20.getRangeTickBandPaint();
        boolean boolean77 = combinedDomainXYPlot20.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNull(paint76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        logAxis1.setMinorTickCount((int) (byte) 100);
        logAxis1.setBase(100.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray6, numberArray10, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset16);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset16, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj21 = categoryAxis20.clone();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer23.setSeriesOutlinePaint((int) (short) 10, paint25);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        combinedDomainXYPlot27.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot27.setDomainGridlinePaint(paint30);
        boolean boolean32 = combinedDomainXYPlot27.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        combinedDomainXYPlot27.setDataset((int) (short) 0, xYDataset34);
        combinedDomainXYPlot27.setBackgroundImageAlignment((int) (byte) -1);
        int int38 = combinedDomainXYPlot27.getDatasetCount();
        xYBarRenderer23.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot27);
        java.awt.Font font41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer23.setLegendTextFont((int) (short) 100, font41);
        categoryAxis20.setTickLabelFont((java.lang.Comparable) month22, font41);
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset19, (java.lang.Comparable) month22, (double) 5, 12);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int48 = month47.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod49, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeriesDataItem51.getPeriod();
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("UnitType.ABSOLUTE", (org.jfree.data.time.RegularTimePeriod) month22, regularTimePeriod52);
        java.lang.Class class54 = periodAxis53.getAutoRangeTimePeriodClass();
        periodAxis53.setMinorTickMarkInsideLength(0.0f);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(pieDataset46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(class54);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        java.awt.Font font2 = standardChartTheme1.getExtraLargeFont();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem4.setShapeVisible(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendItem4.setLabelPaint((java.awt.Paint) color7);
        standardChartTheme1.setGridBandPaint((java.awt.Paint) color7);
        java.awt.Color color10 = java.awt.Color.white;
        standardChartTheme1.setWallPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        java.util.List list6 = jFreeChart5.getSubtitles();
        java.awt.Paint paint7 = jFreeChart5.getBorderPaint();
        org.jfree.chart.block.CenterArrangement centerArrangement8 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement8.add((org.jfree.chart.block.Block) labelBlock10, (java.lang.Object) 100L);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray18, numberArray22, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer32 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement8, (org.jfree.data.general.Dataset) categoryDataset28, (java.lang.Comparable) (short) 1);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset33, valueAxis34, valueAxis35, xYItemRenderer36);
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer36);
        boolean boolean39 = legendTitle38.visible;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = legendTitle38.getPosition();
        legendItemBlockContainer32.add((org.jfree.chart.block.Block) legendTitle38);
        double double42 = legendTitle38.getContentXOffset();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent43 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle38);
        jFreeChart5.removeSubtitle((org.jfree.chart.title.Title) legendTitle38);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        java.lang.String str2 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str1.equals("PieLabelLinkStyle.STANDARD"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str2.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        int int6 = combinedDomainXYPlot0.getSeriesCount();
        combinedDomainXYPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = null;
        combinedDomainXYPlot10.setFixedLegendItems(legendItemCollection11);
        java.awt.Paint paint13 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot10.setDomainGridlinePaint(paint13);
        boolean boolean15 = combinedDomainXYPlot10.canSelectByPoint();
        int int16 = combinedDomainXYPlot10.getSeriesCount();
        boolean boolean17 = combinedDomainXYPlot10.canSelectByPoint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint21.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart25 = chartChangeEvent24.getChart();
        boolean boolean26 = chartRenderingInfo20.equals((java.lang.Object) chartChangeEvent24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = chartRenderingInfo20.getPlotInfo();
        combinedDomainXYPlot10.handleClick((-4767), 8, plotRenderingInfo27);
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = null;
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
        polarPlot29.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo32, point2D35);
        combinedDomainXYPlot0.zoomDomainAxes((double) 1L, plotRenderingInfo27, point2D35);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis39 = combinedDomainXYPlot0.getRangeAxisForDataset((-4767));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -4767 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNull(jFreeChart25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo27);
        org.junit.Assert.assertNotNull(point2D35);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(13);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate4.toSerial();
        org.jfree.data.time.SerialDate serialDate7 = null;
        try {
            boolean boolean9 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, serialDate7, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator3);
        org.jfree.chart.LegendItem legendItem7 = xYAreaRenderer4.getLegendItem(12, 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYAreaRenderer4.getSeriesNegativeItemLabelPosition(1900);
        java.awt.Stroke stroke10 = null;
        try {
            xYAreaRenderer4.setBaseStroke(stroke10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(legendItem7);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        timeSeriesCollection1.clearSelection();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setMinimumArcAngleToDraw((double) (byte) -1);
        piePlot3D3.setBackgroundImageAlignment(13);
        boolean boolean8 = timeSeriesCollection1.equals((java.lang.Object) piePlot3D3);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor9 = timeSeriesCollection1.getXPosition();
        timeSeriesCollection1.clearSelection();
        try {
            double double13 = timeSeriesCollection1.getStartXValue((int) 'a', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timePeriodAnchor9);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint1.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart5 = chartChangeEvent4.getChart();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) chartChangeEvent4);
        org.jfree.chart.RenderingSource renderingSource7 = null;
        chartRenderingInfo0.setRenderingSource(renderingSource7);
        org.jfree.chart.RenderingSource renderingSource9 = chartRenderingInfo0.getRenderingSource();
        chartRenderingInfo0.clear();
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNull(jFreeChart5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(renderingSource9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.canSelectByPoint();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer3);
        boolean boolean6 = legendTitle5.visible;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle5.getPosition();
        java.awt.Color color8 = java.awt.Color.BLACK;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8);
        legendTitle5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = null;
        legendTitle5.setLegendItemGraphicLocation(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator3);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        xYAreaRenderer4.setBaseURLGenerator(xYURLGenerator5);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        xYAreaRenderer4.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator7);
        java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYAreaRenderer4);
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = null;
        java.awt.geom.Point2D point2D16 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D14, rectangleAnchor15);
        polarPlot10.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo13, point2D16);
        boolean boolean18 = polarPlot10.isAngleGridlinesVisible();
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean21 = logAxis20.isInverted();
        org.jfree.data.Range range22 = polarPlot10.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis20);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        polarPlot10.setRenderer(polarItemRenderer23);
        boolean boolean25 = xYAreaRenderer4.equals((java.lang.Object) polarItemRenderer23);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(point2D16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray8, numberArray12, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray17);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset18);
        org.jfree.data.general.PieDataset pieDataset21 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset18, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj23 = categoryAxis22.clone();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer25.setSeriesOutlinePaint((int) (short) 10, paint27);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot29 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        combinedDomainXYPlot29.setFixedLegendItems(legendItemCollection30);
        java.awt.Paint paint32 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot29.setDomainGridlinePaint(paint32);
        boolean boolean34 = combinedDomainXYPlot29.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        combinedDomainXYPlot29.setDataset((int) (short) 0, xYDataset36);
        combinedDomainXYPlot29.setBackgroundImageAlignment((int) (byte) -1);
        int int40 = combinedDomainXYPlot29.getDatasetCount();
        xYBarRenderer25.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot29);
        java.awt.Font font43 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer25.setLegendTextFont((int) (short) 100, font43);
        categoryAxis22.setTickLabelFont((java.lang.Comparable) month24, font43);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset21, (java.lang.Comparable) month24, (double) 5, 12);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        int int50 = month49.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month49.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod51, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = timeSeriesDataItem53.getPeriod();
        org.jfree.chart.axis.PeriodAxis periodAxis55 = new org.jfree.chart.axis.PeriodAxis("UnitType.ABSOLUTE", (org.jfree.data.time.RegularTimePeriod) month24, regularTimePeriod54);
        java.lang.Class class56 = periodAxis55.getAutoRangeTimePeriodClass();
        java.net.URL uRL57 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("HorizontalAlignment.CENTER", class56);
        java.io.InputStream inputStream58 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("DomainOrder.ASCENDING", class56);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1.0d + "'", number19.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset21);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(class56);
        org.junit.Assert.assertNull(uRL57);
        org.junit.Assert.assertNull(inputStream58);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        java.awt.Paint paint6 = combinedDomainXYPlot0.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        combinedDomainXYPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = dateAxis9.valueToJava2D(3.0d, rectangle2D11, rectangleEdge12);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = null;
        combinedDomainXYPlot14.setFixedLegendItems(legendItemCollection15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.plot.CrosshairState crosshairState21 = null;
        boolean boolean22 = combinedDomainXYPlot14.render(graphics2D17, rectangle2D18, (int) 'a', plotRenderingInfo20, crosshairState21);
        dateAxis9.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot14);
        org.jfree.data.Range range24 = combinedDomainXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(range24);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list1 = projectInfo0.getContributors();
        org.junit.Assert.assertNull(list1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYStepRenderer2.getLegendItems();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = xYStepRenderer2.getURLGenerator((int) (byte) 100, (int) '#', true);
        xYStepRenderer2.setAutoPopulateSeriesPaint(false);
        xYStepRenderer2.setSeriesVisible(2019, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(xYURLGenerator7);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.TickUnit tickUnit1 = polarPlot0.getAngleTickUnit();
        java.awt.Paint paint2 = polarPlot0.getAngleGridlinePaint();
        org.junit.Assert.assertNotNull(tickUnit1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = combinedDomainXYPlot0.getRangeMarkers((int) (short) 1, layer4);
        combinedDomainXYPlot0.clearDomainAxes();
        java.awt.Paint paint7 = combinedDomainXYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot3D0.getLegendLabelGenerator();
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        piePlot3D0.setLabelLinkPaint(paint3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        java.lang.Object obj1 = paintMap0.clone();
        java.awt.Paint paint3 = null;
        paintMap0.put((java.lang.Comparable) (byte) 0, paint3);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray8, numberArray12, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray17);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset18);
        org.jfree.data.general.PieDataset pieDataset21 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset18, 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot0.getRendererForDataset(categoryDataset18);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1.0d + "'", number19.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset21);
        org.junit.Assert.assertNull(categoryItemRenderer22);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) textAnchor0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator2 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj3 = standardXYToolTipGenerator2.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator2, xYURLGenerator4);
        org.jfree.chart.LegendItem legendItem8 = xYAreaRenderer5.getLegendItem(12, 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer5.setBasePaint((java.awt.Paint) color9, true);
        boolean boolean12 = itemLabelAnchor0.equals((java.lang.Object) xYAreaRenderer5);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        boolean boolean5 = xYStepRenderer2.getItemLineVisible((-1), (int) ' ');
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean7 = xYBarRenderer6.isDrawBarOutline();
        xYBarRenderer6.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = xYBarRenderer6.getDrawingSupplier();
        xYBarRenderer6.setShadowYOffset((double) 0L);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator13 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        java.lang.Object obj14 = standardXYSeriesLabelGenerator13.clone();
        xYBarRenderer6.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator13);
        xYStepRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        org.jfree.chart.axis.NumberTick numberTick8 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.08d, "hi!", textAnchor3, textAnchor5, (double) 2.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor5);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock2, (java.lang.Object) 100L);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray10, numberArray14, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset20, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) categoryDataset20, (java.lang.Comparable) (short) 1);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer28);
        boolean boolean31 = legendTitle30.visible;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = legendTitle30.getPosition();
        legendItemBlockContainer24.add((org.jfree.chart.block.Block) legendTitle30);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.TOP;
        legendTitle30.setLegendItemGraphicLocation(rectangleAnchor34);
        legendTitle30.setPadding((double) (-1), (double) ' ', 100.0d, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer41 = legendTitle30.getWrapper();
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNull(blockContainer41);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock2, (java.lang.Object) 100L);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray10, numberArray14, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset20, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) categoryDataset20, (java.lang.Comparable) (short) 1);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset20);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset20, true);
        double double29 = range27.constrain((double) 2958465);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.0d + "'", double29 == 10.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100);
        timeSeries1.setMaximumItemAge((long) (byte) 0);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.TickUnit tickUnit5 = polarPlot4.getAngleTickUnit();
        boolean boolean6 = polarPlot4.isAngleGridlinesVisible();
        boolean boolean7 = timeSeries1.equals((java.lang.Object) polarPlot4);
        org.junit.Assert.assertNotNull(tickUnit5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray7 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray8 = color2.getRGBColorComponents(floatArray7);
        int int9 = color2.getAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, (double) (-2208960000000L), (java.awt.Paint) color2);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str14 = intervalMarker13.getLabel();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.TOP;
        intervalMarker13.setLabelAnchor(rectangleAnchor15);
        intervalMarker10.setLabelAnchor(rectangleAnchor15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.TOP;
        intervalMarker10.setLabelAnchor(rectangleAnchor18);
        intervalMarker10.setEndValue((-2.20896E12d));
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem23.setSeriesIndex((int) '4');
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray31, numberArray35, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray40);
        java.lang.Number number42 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset41);
        legendItem23.setDataset((org.jfree.data.general.Dataset) categoryDataset41);
        java.awt.Stroke stroke44 = legendItem23.getOutlineStroke();
        intervalMarker10.setStroke(stroke44);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 1.0d + "'", number42.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        java.awt.Paint paint9 = combinedDomainXYPlot0.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = combinedDomainXYPlot0.getAxisOffset();
        double double12 = rectangleInsets10.extendHeight((double) 15);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 23.0d + "'", double12 == 23.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj1 = categoryPlot0.clone();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer3 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = xYStepRenderer3.getBaseToolTipGenerator();
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font6);
        xYStepRenderer3.setBaseItemLabelFont(font6);
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("hi!�");
        java.awt.Paint paint11 = logAxis10.getTickLabelPaint();
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("HorizontalAlignment.CENTER", font6, paint11, 0.5f);
        java.lang.String str14 = textFragment13.getText();
        org.jfree.chart.block.CenterArrangement centerArrangement15 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement15.add((org.jfree.chart.block.Block) labelBlock17, (java.lang.Object) 100L);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = labelBlock17.getMargin();
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean22 = piePlot3D21.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = piePlot3D21.getLegendLabelGenerator();
        boolean boolean24 = labelBlock17.equals((java.lang.Object) piePlot3D21);
        piePlot3D21.setMaximumLabelWidth((double) (byte) 1);
        boolean boolean27 = textFragment13.equals((java.lang.Object) (byte) 1);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        try {
            textFragment13.draw(graphics2D28, (float) (-460), (float) (-4767), textAnchor31, (float) 255, (float) 2, 45.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYToolTipGenerator4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "HorizontalAlignment.CENTER" + "'", str14.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(textAnchor31);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = xYPlot4.getAxisOffset();
        xYPlot4.clearSelection();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxis();
        java.awt.Stroke stroke8 = xYPlot4.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        xYBarRenderer0.setBaseCreateEntities(false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = null;
        combinedDomainXYPlot5.setFixedLegendItems(legendItemCollection6);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot5.setDomainGridlinePaint(paint8);
        int int10 = combinedDomainXYPlot5.getDomainAxisCount();
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("hi!�");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        combinedDomainXYPlot13.setFixedLegendItems(legendItemCollection14);
        java.awt.Paint paint16 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot13.setDomainGridlinePaint(paint16);
        boolean boolean18 = combinedDomainXYPlot13.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        combinedDomainXYPlot13.setDataset((int) (short) 0, xYDataset20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.CrosshairState crosshairState26 = null;
        boolean boolean27 = combinedDomainXYPlot13.render(graphics2D22, rectangle2D23, 10, plotRenderingInfo25, crosshairState26);
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.Layer layer32 = null;
        combinedDomainXYPlot13.addRangeMarker((-4767), (org.jfree.chart.plot.Marker) intervalMarker31, layer32, true);
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        xYBarRenderer0.drawDomainMarker(graphics2D4, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot5, (org.jfree.chart.axis.ValueAxis) logAxis12, (org.jfree.chart.plot.Marker) intervalMarker31, rectangle2D35);
        combinedDomainXYPlot5.setDomainCrosshairValue((double) 15);
        org.jfree.chart.plot.PlotOrientation plotOrientation39 = null;
        try {
            combinedDomainXYPlot5.setOrientation(plotOrientation39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 900000L);
        double double4 = rectangleInsets0.extendWidth(4.0d);
        java.awt.Color color5 = java.awt.Color.PINK;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color5);
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 899992.0d + "'", double2 == 899992.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.0d + "'", double4 == 12.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(unitType7);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            java.lang.Number number2 = defaultKeyedValues0.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D2.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D2.setLabelLinkStroke(stroke5);
        strokeList0.setStroke(0, stroke5);
        java.awt.Stroke stroke9 = strokeList0.getStroke(4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(stroke9);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer8);
        boolean boolean11 = legendTitle10.visible;
        legendTitle10.setHeight((double) 8);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle10.getLegendItemGraphicEdge();
        org.jfree.chart.axis.AxisState axisState15 = null;
        categoryAxis0.drawTickMarks(graphics2D2, (double) ' ', rectangle2D4, rectangleEdge14, axisState15);
        categoryAxis0.setCategoryLabelPositionOffset(9999);
        categoryAxis0.setCategoryLabelPositionOffset((int) (byte) 1);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        piePlot3D0.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean9 = piePlot3D8.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        java.awt.Shape shape12 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        polarPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot13);
        java.util.List list19 = jFreeChart18.getSubtitles();
        java.awt.Paint paint20 = jFreeChart18.getBorderPaint();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity21 = new org.jfree.chart.entity.JFreeChartEntity(shape12, jFreeChart18);
        java.io.ObjectOutputStream objectOutputStream22 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape12, objectOutputStream22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        piePlot3D0.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean9 = piePlot3D8.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        java.awt.Shape shape12 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        polarPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot13);
        java.util.List list19 = jFreeChart18.getSubtitles();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity20 = new org.jfree.chart.entity.JFreeChartEntity(shape12, jFreeChart18);
        org.jfree.chart.axis.LogAxis logAxis22 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis22.pan(0.0d);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.AxisState axisState26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        java.util.List list29 = logAxis22.refreshTicks(graphics2D25, axisState26, rectangle2D27, rectangleEdge28);
        org.jfree.chart.util.LogFormat logFormat36 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator38 = logFormat36.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit40 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat36, (int) (byte) -1);
        org.jfree.chart.util.LogFormat logFormat45 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        logFormat45.setMinimumIntegerDigits((int) (short) 100);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator48 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined_Domain_XYPlot", (java.text.NumberFormat) logFormat36, (java.text.NumberFormat) logFormat45);
        java.lang.String str50 = logFormat36.format(0.0d);
        org.jfree.chart.util.LogFormat logFormat55 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator57 = logFormat55.formatToCharacterIterator((java.lang.Object) 0);
        java.lang.String str59 = logFormat55.format((double) 10);
        logFormat36.setExponentFormat((java.text.NumberFormat) logFormat55);
        logAxis22.setNumberFormatOverride((java.text.NumberFormat) logFormat55);
        org.jfree.chart.entity.AxisEntity axisEntity64 = new org.jfree.chart.entity.AxisEntity(shape12, (org.jfree.chart.axis.Axis) logAxis22, "Pie 3D Plot", "Nearest");
        logAxis22.setLabelToolTip("Pie 3D Plot");
        double double67 = logAxis22.getLabelAngle();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(attributedCharacterIterator38);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!�" + "'", str50.equals("hi!�"));
        org.junit.Assert.assertNotNull(attributedCharacterIterator57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!-0.0" + "'", str59.equals("hi!-0.0"));
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        int int6 = combinedDomainXYPlot0.getSeriesCount();
        int int7 = combinedDomainXYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        combinedDomainXYPlot0.setSeriesRenderingOrder(seriesRenderingOrder8);
        combinedDomainXYPlot0.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, true);
        org.jfree.chart.util.SortOrder sortOrder4 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator8 = logFormat6.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat6, (int) (byte) -1);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        logFormat15.setMinimumIntegerDigits((int) (short) 100);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator18 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined_Domain_XYPlot", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat15);
        java.lang.String str20 = logFormat6.format(0.0d);
        org.jfree.chart.util.LogFormat logFormat25 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator27 = logFormat25.formatToCharacterIterator((java.lang.Object) 0);
        java.lang.String str29 = logFormat25.format((double) 10);
        logFormat6.setExponentFormat((java.text.NumberFormat) logFormat25);
        logFormat25.setGroupingUsed(true);
        org.junit.Assert.assertNotNull(attributedCharacterIterator8);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!�" + "'", str20.equals("hi!�"));
        org.junit.Assert.assertNotNull(attributedCharacterIterator27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!-0.0" + "'", str29.equals("hi!-0.0"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer3);
        boolean boolean6 = legendTitle5.visible;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle5.getPosition();
        java.awt.Color color8 = java.awt.Color.BLACK;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8);
        legendTitle5.setBackgroundPaint((java.awt.Paint) color8);
        legendTitle5.visible = true;
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = lineBorder13.getInsets();
        legendTitle5.setFrame((org.jfree.chart.block.BlockFrame) lineBorder13);
        java.awt.Paint paint16 = lineBorder13.getPaint();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer3);
        legendTitle5.setWidth(2.0d);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D9.setMinimumArcAngleToDraw((double) (byte) -1);
        double double12 = piePlot3D9.getInteriorGap();
        piePlot3D9.setDarkerSides(false);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D17.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D17.setLabelLinkStroke(stroke20);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint24.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart28 = chartChangeEvent27.getChart();
        boolean boolean29 = chartRenderingInfo23.equals((java.lang.Object) chartChangeEvent27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = chartRenderingInfo23.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState31 = piePlot3D9.initialise(graphics2D15, rectangle2D16, (org.jfree.chart.plot.PiePlot) piePlot3D17, (java.lang.Integer) 0, plotRenderingInfo30);
        java.awt.geom.Rectangle2D rectangle2D32 = plotRenderingInfo30.getDataArea();
        try {
            legendTitle5.draw(graphics2D8, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.08d + "'", double12 == 0.08d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNull(jFreeChart28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo30);
        org.junit.Assert.assertNotNull(piePlotState31);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer8);
        boolean boolean11 = legendTitle10.visible;
        legendTitle10.setHeight((double) 8);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle10.getLegendItemGraphicEdge();
        org.jfree.chart.axis.AxisState axisState15 = null;
        categoryAxis0.drawTickMarks(graphics2D2, (double) ' ', rectangle2D4, rectangleEdge14, axisState15);
        categoryAxis0.setAxisLineVisible(true);
        categoryAxis0.setUpperMargin((double) (byte) 0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        try {
            java.lang.Number number4 = xYSeriesCollection1.getStartX((int) (short) 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator3);
        org.jfree.chart.LegendItem legendItem7 = xYAreaRenderer4.getLegendItem(12, 1);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer4.setBasePaint((java.awt.Paint) color8, true);
        xYAreaRenderer4.setBaseItemLabelsVisible(true, false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(legendItem7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray6, numberArray10, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset16);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset16, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj21 = categoryAxis20.clone();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer23.setSeriesOutlinePaint((int) (short) 10, paint25);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        combinedDomainXYPlot27.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot27.setDomainGridlinePaint(paint30);
        boolean boolean32 = combinedDomainXYPlot27.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        combinedDomainXYPlot27.setDataset((int) (short) 0, xYDataset34);
        combinedDomainXYPlot27.setBackgroundImageAlignment((int) (byte) -1);
        int int38 = combinedDomainXYPlot27.getDatasetCount();
        xYBarRenderer23.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot27);
        java.awt.Font font41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer23.setLegendTextFont((int) (short) 100, font41);
        categoryAxis20.setTickLabelFont((java.lang.Comparable) month22, font41);
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset19, (java.lang.Comparable) month22, (double) 5, 12);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int48 = month47.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod49, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeriesDataItem51.getPeriod();
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("UnitType.ABSOLUTE", (org.jfree.data.time.RegularTimePeriod) month22, regularTimePeriod52);
        periodAxis53.setMinorTickMarkOutsideLength((float) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = periodAxis53.getFirst();
        org.jfree.data.xy.XYSeries xYSeries57 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) regularTimePeriod56);
        try {
            java.lang.Number number59 = xYSeries57.getX((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(pieDataset46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray7 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray8 = color2.getRGBColorComponents(floatArray7);
        int int9 = color2.getAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, (double) (-2208960000000L), (java.awt.Paint) color2);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str14 = intervalMarker13.getLabel();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.TOP;
        intervalMarker13.setLabelAnchor(rectangleAnchor15);
        intervalMarker10.setLabelAnchor(rectangleAnchor15);
        java.lang.String str18 = intervalMarker10.getLabel();
        java.awt.Font font19 = intervalMarker10.getLabelFont();
        double double20 = intervalMarker10.getStartValue();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj4 = standardXYToolTipGenerator3.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator5);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer6.getLegendItem(12, 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer6.setBasePaint((java.awt.Paint) color10, true);
        standardChartTheme1.setShadowPaint((java.awt.Paint) color10);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace15 = color14.getColorSpace();
        standardChartTheme1.setDomainGridlinePaint((java.awt.Paint) color14);
        java.awt.Paint paint17 = null;
        try {
            standardChartTheme1.setRangeGridlinePaint(paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(colorSpace15);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100);
        timeSeries1.setMaximumItemCount((int) (byte) 100);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month5.next();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        java.awt.Paint paint9 = combinedDomainXYPlot0.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = combinedDomainXYPlot0.getAxisOffset();
        combinedDomainXYPlot0.clearRangeMarkers(5);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        double double5 = logAxis1.calculateValue(0.0d);
        float float6 = logAxis1.getMinorTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str2 = spreadsheetDate1.toString();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day4.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12-January-1900" + "'", str2.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = combinedDomainXYPlot0.getRangeMarkers((int) (short) 1, layer4);
        boolean boolean6 = combinedDomainXYPlot0.isDomainCrosshairVisible();
        java.awt.Stroke stroke7 = combinedDomainXYPlot0.getDomainZeroBaselineStroke();
        int int8 = combinedDomainXYPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        double double5 = logAxis1.calculateValue(0.0d);
        boolean boolean6 = logAxis1.isTickLabelsVisible();
        java.awt.Font font7 = logAxis1.getLabelFont();
        java.text.NumberFormat numberFormat8 = logAxis1.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(numberFormat8);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        int int6 = combinedDomainXYPlot0.getSeriesCount();
        int int7 = combinedDomainXYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = combinedDomainXYPlot0.getLegendItems();
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem10.setShapeVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = legendItem10.getFillPaintTransformer();
        legendItem10.setURLText("hi!�");
        legendItemCollection8.add(legendItem10);
        int int17 = legendItem10.getSeriesIndex();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.CenterArrangement centerArrangement1 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement1.add((org.jfree.chart.block.Block) labelBlock3, (java.lang.Object) 100L);
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray11, numberArray15, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray20);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset21, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer25 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement1, (org.jfree.data.general.Dataset) categoryDataset21, (java.lang.Comparable) (short) 1);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset21);
        categoryPlot0.setDataset(categoryDataset21);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection29 = null;
        combinedDomainXYPlot28.setFixedLegendItems(legendItemCollection29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        combinedDomainXYPlot28.setRenderer(xYItemRenderer31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray38 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray39 = color33.getRGBColorComponents(floatArray38);
        int int40 = color33.getAlpha();
        combinedDomainXYPlot28.setRangeTickBandPaint((java.awt.Paint) color33);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color33);
        org.jfree.chart.util.SortOrder sortOrder43 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 10.0d + "'", number26.equals(10.0d));
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 255 + "'", int40 == 255);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) 0L, (double) 100.0f, (double) 1);
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem5.setShapeVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = legendItem5.getFillPaintTransformer();
        legendItem5.setShapeVisible(false);
        java.awt.Stroke stroke11 = legendItem5.getLineStroke();
        int int12 = legendItem5.getSeriesIndex();
        boolean boolean13 = legendItem5.isLineVisible();
        boolean boolean14 = gradientXYBarPainter3.equals((java.lang.Object) legendItem5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator(13, categoryToolTipGenerator2);
        java.awt.Paint paint4 = barRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation5 = null;
        boolean boolean6 = barRenderer0.removeAnnotation(categoryAnnotation5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator8);
        double double10 = barRenderer0.getUpperClip();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        org.jfree.chart.LegendItem legendItem8 = xYStepRenderer2.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        java.awt.Paint paint12 = xYStepRenderer2.getSeriesOutlinePaint(5);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = null;
        java.awt.geom.Point2D point2D6 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D4, rectangleAnchor5);
        polarPlot0.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo3, point2D6);
        boolean boolean8 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean11 = logAxis10.isInverted();
        org.jfree.data.Range range12 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis10);
        float float13 = logAxis10.getMinorTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D16 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D16.setMinimumArcAngleToDraw((double) (byte) -1);
        double double19 = piePlot3D16.getInteriorGap();
        piePlot3D16.setDarkerSides(false);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D24 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D24.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D24.setLabelLinkStroke(stroke27);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = rectangleConstraint31.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart35 = chartChangeEvent34.getChart();
        boolean boolean36 = chartRenderingInfo30.equals((java.lang.Object) chartChangeEvent34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = chartRenderingInfo30.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState38 = piePlot3D16.initialise(graphics2D22, rectangle2D23, (org.jfree.chart.plot.PiePlot) piePlot3D24, (java.lang.Integer) 0, plotRenderingInfo37);
        java.awt.geom.Rectangle2D rectangle2D39 = plotRenderingInfo37.getDataArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D40 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D40.setMinimumArcAngleToDraw((double) (byte) -1);
        double double43 = piePlot3D40.getInteriorGap();
        piePlot3D40.setDarkerSides(false);
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D48 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D48.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D48.setLabelLinkStroke(stroke51);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo54 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = rectangleConstraint55.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent58 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart59 = chartChangeEvent58.getChart();
        boolean boolean60 = chartRenderingInfo54.equals((java.lang.Object) chartChangeEvent58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = chartRenderingInfo54.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState62 = piePlot3D40.initialise(graphics2D46, rectangle2D47, (org.jfree.chart.plot.PiePlot) piePlot3D48, (java.lang.Integer) 0, plotRenderingInfo61);
        java.awt.geom.Rectangle2D rectangle2D63 = plotRenderingInfo61.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.plot.PiePlot3D piePlot3D65 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D65.setMinimumArcAngleToDraw((double) (byte) -1);
        double double68 = piePlot3D65.getInteriorGap();
        piePlot3D65.setDarkerSides(false);
        java.awt.Graphics2D graphics2D71 = null;
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D73 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D73.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke76 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D73.setLabelLinkStroke(stroke76);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo79 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint80 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint82 = rectangleConstraint80.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent83 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart84 = chartChangeEvent83.getChart();
        boolean boolean85 = chartRenderingInfo79.equals((java.lang.Object) chartChangeEvent83);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo86 = chartRenderingInfo79.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState87 = piePlot3D65.initialise(graphics2D71, rectangle2D72, (org.jfree.chart.plot.PiePlot) piePlot3D73, (java.lang.Integer) 0, plotRenderingInfo86);
        java.awt.geom.Rectangle2D rectangle2D88 = plotRenderingInfo86.getDataArea();
        try {
            org.jfree.chart.axis.AxisState axisState89 = logAxis10.draw(graphics2D14, (double) 1900, rectangle2D39, rectangle2D63, rectangleEdge64, plotRenderingInfo86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.08d + "'", double19 == 0.08d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleConstraint31);
        org.junit.Assert.assertNotNull(rectangleConstraint33);
        org.junit.Assert.assertNull(jFreeChart35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo37);
        org.junit.Assert.assertNotNull(piePlotState38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.08d + "'", double43 == 0.08d);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(rectangleConstraint55);
        org.junit.Assert.assertNotNull(rectangleConstraint57);
        org.junit.Assert.assertNull(jFreeChart59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo61);
        org.junit.Assert.assertNotNull(piePlotState62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.08d + "'", double68 == 0.08d);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(rectangleConstraint80);
        org.junit.Assert.assertNotNull(rectangleConstraint82);
        org.junit.Assert.assertNull(jFreeChart84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo86);
        org.junit.Assert.assertNotNull(piePlotState87);
        org.junit.Assert.assertNotNull(rectangle2D88);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            boolean boolean19 = combinedDomainXYPlot4.removeRangeMarker(marker17, layer18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(layer18);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth((double) 0.0f);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer3.setSeriesOutlinePaint((int) (short) 10, paint5);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        combinedDomainXYPlot7.setFixedLegendItems(legendItemCollection8);
        java.awt.Paint paint10 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot7.setDomainGridlinePaint(paint10);
        boolean boolean12 = combinedDomainXYPlot7.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        combinedDomainXYPlot7.setDataset((int) (short) 0, xYDataset14);
        combinedDomainXYPlot7.setBackgroundImageAlignment((int) (byte) -1);
        int int18 = combinedDomainXYPlot7.getDatasetCount();
        xYBarRenderer3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot7);
        xYBarRenderer3.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = null;
        combinedDomainXYPlot23.setFixedLegendItems(legendItemCollection24);
        java.awt.Paint paint26 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot23.setDomainGridlinePaint(paint26);
        boolean boolean28 = combinedDomainXYPlot23.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        combinedDomainXYPlot23.setDataset((int) (short) 0, xYDataset30);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.RenderingSource renderingSource35 = null;
        combinedDomainXYPlot23.select((double) 1L, (double) ' ', rectangle2D34, renderingSource35);
        java.lang.String str37 = combinedDomainXYPlot23.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = combinedDomainXYPlot23.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray45, numberArray49, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray54);
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset55, (double) (-2208960000000L));
        double double58 = range57.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint60 = new org.jfree.chart.block.RectangleConstraint(range57, 100.0d);
        boolean boolean63 = range57.intersects((double) (byte) 10, (double) 9999);
        dateAxis39.setRange(range57, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker69 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str70 = intervalMarker69.getLabel();
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        xYBarRenderer3.drawRangeMarker(graphics2D22, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot23, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.plot.Marker) intervalMarker69, rectangle2D71);
        org.jfree.data.Range range73 = dateAxis39.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint74 = rectangleConstraint0.toRangeWidth(range73);
        double double75 = rectangleConstraint0.getHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Combined_Domain_XYPlot" + "'", str37.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + (-2.20896E12d) + "'", double58 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNotNull(rectangleConstraint74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray7 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray8 = color2.getRGBColorComponents(floatArray7);
        int int9 = color2.getAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, (double) (-2208960000000L), (java.awt.Paint) color2);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str14 = intervalMarker13.getLabel();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.TOP;
        intervalMarker13.setLabelAnchor(rectangleAnchor15);
        intervalMarker10.setLabelAnchor(rectangleAnchor15);
        java.lang.String str18 = intervalMarker10.getLabel();
        try {
            intervalMarker10.setAlpha((float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        boolean boolean3 = piePlot3D0.getAutoPopulateSectionOutlineStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot3D0.getLegendLabelURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(pieURLGenerator6);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray6, numberArray10, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset16);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset16, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj21 = categoryAxis20.clone();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer23.setSeriesOutlinePaint((int) (short) 10, paint25);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        combinedDomainXYPlot27.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot27.setDomainGridlinePaint(paint30);
        boolean boolean32 = combinedDomainXYPlot27.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        combinedDomainXYPlot27.setDataset((int) (short) 0, xYDataset34);
        combinedDomainXYPlot27.setBackgroundImageAlignment((int) (byte) -1);
        int int38 = combinedDomainXYPlot27.getDatasetCount();
        xYBarRenderer23.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot27);
        java.awt.Font font41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer23.setLegendTextFont((int) (short) 100, font41);
        categoryAxis20.setTickLabelFont((java.lang.Comparable) month22, font41);
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset19, (java.lang.Comparable) month22, (double) 5, 12);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int48 = month47.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod49, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeriesDataItem51.getPeriod();
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("UnitType.ABSOLUTE", (org.jfree.data.time.RegularTimePeriod) month22, regularTimePeriod52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = month22.previous();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(pieDataset46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        combinedDomainXYPlot0.setRenderer(xYItemRenderer3);
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("hi!");
        java.awt.Font font7 = labelBlock6.getFont();
        java.awt.Paint paint8 = labelBlock6.getPaint();
        combinedDomainXYPlot0.setRangeZeroBaselinePaint(paint8);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock2, (java.lang.Object) 100L);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray10, numberArray14, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset20, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) categoryDataset20, (java.lang.Comparable) (short) 1);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset20);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset20);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range26);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseShapesVisible(false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        combinedDomainXYPlot0.setBackgroundImageAlignment((int) (byte) -1);
        int int11 = combinedDomainXYPlot0.getDatasetCount();
        java.awt.Paint paint12 = combinedDomainXYPlot0.getBackgroundPaint();
        org.jfree.data.time.TimeSeries timeSeries13 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection(timeSeries13);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedDomainXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100);
        timeSeries18.setMaximumItemAge((long) (byte) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries18.removeChangeListener(seriesChangeListener21);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener23);
        int int25 = timeSeriesCollection14.indexOf(timeSeries18);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        boolean boolean6 = xYStepRenderer2.getAutoPopulateSeriesPaint();
        boolean boolean7 = xYStepRenderer2.getAutoPopulateSeriesStroke();
        xYStepRenderer2.setUseFillPaint(true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        boolean boolean5 = xYStepRenderer2.getItemLineVisible((-1), (int) ' ');
        boolean boolean6 = xYStepRenderer2.getBaseCreateEntities();
        java.lang.Boolean boolean8 = xYStepRenderer2.getSeriesItemLabelsVisible((-398));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str2 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        combinedDomainXYPlot7.setFixedLegendItems(legendItemCollection8);
        java.awt.Paint paint10 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot7.setDomainGridlinePaint(paint10);
        boolean boolean12 = combinedDomainXYPlot7.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        combinedDomainXYPlot7.setDataset((int) (short) 0, xYDataset14);
        combinedDomainXYPlot7.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.xy.XYSeries xYSeries18 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection19 = new org.jfree.data.xy.XYSeriesCollection(xYSeries18);
        double double21 = xYSeriesCollection19.getDomainLowerBound(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = combinedDomainXYPlot7.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection19);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot7.setDomainAxisLocation(axisLocation23);
        boolean boolean25 = spreadsheetDate1.equals((java.lang.Object) combinedDomainXYPlot7);
        java.awt.Paint paint26 = combinedDomainXYPlot7.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12-January-1900" + "'", str2.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12-January-1900" + "'", str5.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            java.lang.Number number5 = timeSeriesCollection1.getY((int) (short) 100, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        org.jfree.chart.util.StrokeList strokeList4 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D6.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D6.setLabelLinkStroke(stroke9);
        strokeList4.setStroke(0, stroke9);
        logAxis1.setAxisLineStroke(stroke9);
        boolean boolean13 = logAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        crosshairState1.setDatasetIndex(15);
        double double4 = crosshairState1.getCrosshairDistance();
        double double5 = crosshairState1.getAnchorY();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        java.util.List list6 = jFreeChart5.getSubtitles();
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart5.getTitle();
        java.awt.Image image8 = jFreeChart5.getBackgroundImage();
        jFreeChart5.setBorderVisible(false);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(textTitle7);
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        xYBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = xYBarRenderer0.getDrawingSupplier();
        xYBarRenderer0.setShadowYOffset((double) 0L);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYBarRenderer0.setSeriesURLGenerator((int) 'a', xYURLGenerator8, false);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("", font12);
        xYBarRenderer0.setBaseItemLabelFont(font12);
        xYBarRenderer0.setMargin(9.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) "DomainOrder.ASCENDING");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("index.html", "DatasetRenderingOrder.REVERSE", "", "hi!�");
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        float float2 = categoryAxis0.getMinorTickMarkInsideLength();
        java.lang.Comparable comparable3 = null;
        try {
            categoryAxis0.addCategoryLabelToolTip(comparable3, "index.html");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = combinedDomainXYPlot0.getRangeMarkers((int) 'a', layer4);
        combinedDomainXYPlot0.setWeight((int) (byte) 100);
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.CenterArrangement centerArrangement1 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement1.add((org.jfree.chart.block.Block) labelBlock3, (java.lang.Object) 100L);
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray11, numberArray15, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray20);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset21, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer25 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement1, (org.jfree.data.general.Dataset) categoryDataset21, (java.lang.Comparable) (short) 1);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset21);
        categoryPlot0.setDataset(categoryDataset21);
        int int28 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 10.0d + "'", number26.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100);
        timeSeries1.setMaximumItemCount((int) (byte) 100);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        timeSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection4);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        combinedDomainXYPlot0.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = combinedDomainXYPlot0.getDatasetRenderingOrder();
        boolean boolean12 = combinedDomainXYPlot0.isOutlineVisible();
        org.jfree.data.time.TimeSeries timeSeries13 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection(timeSeries13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection14, valueAxis15, polarItemRenderer16);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer20 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator18, xYURLGenerator19);
        java.awt.Paint paint21 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer20.setBaseItemLabelPaint(paint21, false);
        org.jfree.chart.LegendItem legendItem26 = xYStepRenderer20.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer20.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot31 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = null;
        combinedDomainXYPlot31.setFixedLegendItems(legendItemCollection32);
        java.awt.Paint paint34 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot31.setDomainGridlinePaint(paint34);
        boolean boolean36 = combinedDomainXYPlot31.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        combinedDomainXYPlot31.setDataset((int) (short) 0, xYDataset38);
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.RenderingSource renderingSource43 = null;
        combinedDomainXYPlot31.select((double) 1L, (double) ' ', rectangle2D42, renderingSource43);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection45 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D46 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D46.setMinimumArcAngleToDraw((double) (byte) -1);
        double double49 = piePlot3D46.getInteriorGap();
        piePlot3D46.setDarkerSides(false);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D54 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D54.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke57 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D54.setLabelLinkStroke(stroke57);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo60 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint61 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint63 = rectangleConstraint61.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent64 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart65 = chartChangeEvent64.getChart();
        boolean boolean66 = chartRenderingInfo60.equals((java.lang.Object) chartChangeEvent64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = chartRenderingInfo60.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState68 = piePlot3D46.initialise(graphics2D52, rectangle2D53, (org.jfree.chart.plot.PiePlot) piePlot3D54, (java.lang.Integer) 0, plotRenderingInfo67);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState69 = xYStepRenderer20.initialise(graphics2D29, rectangle2D30, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot31, (org.jfree.data.xy.XYDataset) xYSeriesCollection45, plotRenderingInfo67);
        timeSeriesCollection14.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection45);
        org.jfree.data.Range range72 = xYSeriesCollection45.getDomainBounds(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = combinedDomainXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection45);
        org.jfree.data.Range range74 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection45);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(legendItem26);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.08d + "'", double49 == 0.08d);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(rectangleConstraint61);
        org.junit.Assert.assertNotNull(rectangleConstraint63);
        org.junit.Assert.assertNull(jFreeChart65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo67);
        org.junit.Assert.assertNotNull(piePlotState68);
        org.junit.Assert.assertNotNull(xYItemRendererState69);
        org.junit.Assert.assertNull(range72);
        org.junit.Assert.assertNull(xYItemRenderer73);
        org.junit.Assert.assertNull(range74);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean2 = logAxis1.isInverted();
        logAxis1.resizeRange(0.0d);
        java.awt.Paint paint5 = logAxis1.getTickMarkPaint();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = logAxis1.getTickUnit();
        boolean boolean7 = logAxis1.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        java.awt.Font font18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer0.setLegendTextFont((int) (short) 100, font18);
        org.jfree.data.time.TimeSeries timeSeries20 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection(timeSeries20);
        org.jfree.data.Range range22 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection21);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection21);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(range23);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = null;
        xYBarRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator1);
        boolean boolean3 = xYBarRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer3);
        boolean boolean6 = legendTitle5.visible;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle5.getPosition();
        java.awt.Color color8 = java.awt.Color.BLACK;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8);
        legendTitle5.setBackgroundPaint((java.awt.Paint) color8);
        legendTitle5.visible = true;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle5.getItemLabelPadding();
        org.jfree.chart.block.CenterArrangement centerArrangement14 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement14.add((org.jfree.chart.block.Block) labelBlock16, (java.lang.Object) 100L);
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray24, numberArray28, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset34, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer38 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement14, (org.jfree.data.general.Dataset) categoryDataset34, (java.lang.Comparable) (short) 1);
        java.lang.Object obj39 = legendItemBlockContainer38.clone();
        java.lang.String str40 = legendItemBlockContainer38.getURLText();
        legendTitle5.setWrapper((org.jfree.chart.block.BlockContainer) legendItemBlockContainer38);
        legendItemBlockContainer38.setHeight((-1.0d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNull(str40);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = polarPlot4.getOrientation();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer6.setSeriesOutlinePaint((int) (short) 10, paint8);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = null;
        combinedDomainXYPlot10.setFixedLegendItems(legendItemCollection11);
        java.awt.Paint paint13 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot10.setDomainGridlinePaint(paint13);
        boolean boolean15 = combinedDomainXYPlot10.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        combinedDomainXYPlot10.setDataset((int) (short) 0, xYDataset17);
        combinedDomainXYPlot10.setBackgroundImageAlignment((int) (byte) -1);
        int int21 = combinedDomainXYPlot10.getDatasetCount();
        xYBarRenderer6.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot10);
        xYBarRenderer6.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = null;
        combinedDomainXYPlot26.setFixedLegendItems(legendItemCollection27);
        java.awt.Paint paint29 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot26.setDomainGridlinePaint(paint29);
        boolean boolean31 = combinedDomainXYPlot26.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        combinedDomainXYPlot26.setDataset((int) (short) 0, xYDataset33);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.RenderingSource renderingSource38 = null;
        combinedDomainXYPlot26.select((double) 1L, (double) ' ', rectangle2D37, renderingSource38);
        java.lang.String str40 = combinedDomainXYPlot26.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = combinedDomainXYPlot26.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray52 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray56 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray57 = new java.lang.Number[][] { numberArray48, numberArray52, numberArray56 };
        org.jfree.data.category.CategoryDataset categoryDataset58 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray57);
        org.jfree.data.Range range60 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset58, (double) (-2208960000000L));
        double double61 = range60.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint63 = new org.jfree.chart.block.RectangleConstraint(range60, 100.0d);
        boolean boolean66 = range60.intersects((double) (byte) 10, (double) 9999);
        dateAxis42.setRange(range60, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker72 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str73 = intervalMarker72.getLabel();
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        xYBarRenderer6.drawRangeMarker(graphics2D25, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot26, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.plot.Marker) intervalMarker72, rectangle2D74);
        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month();
        int int77 = month76.getYearValue();
        java.util.Date date78 = month76.getEnd();
        dateAxis42.setMaximumDate(date78);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition80 = org.jfree.chart.axis.DateTickMarkPosition.END;
        dateAxis42.setTickMarkPosition(dateTickMarkPosition80);
        org.jfree.data.Range range82 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis42);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Combined_Domain_XYPlot" + "'", str40.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer41);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(categoryDataset58);
        org.junit.Assert.assertNotNull(range60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + (-2.20896E12d) + "'", double61 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2019 + "'", int77 == 2019);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(dateTickMarkPosition80);
        org.junit.Assert.assertNull(range82);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        piePlot3D0.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean9 = piePlot3D8.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        java.awt.Shape shape12 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.plot.Plot plot13 = piePlot3D0.getRootPlot();
        java.awt.Paint paint15 = piePlot3D0.getSectionOutlinePaint((java.lang.Comparable) "12-January-1900");
        java.awt.Stroke stroke16 = piePlot3D0.getLabelLinkStroke();
        java.awt.Shape shape17 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = null;
        combinedDomainXYPlot18.setFixedLegendItems(legendItemCollection19);
        java.awt.Paint paint21 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot18.setDomainGridlinePaint(paint21);
        boolean boolean23 = combinedDomainXYPlot18.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        combinedDomainXYPlot18.setDataset((int) (short) 0, xYDataset25);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.RenderingSource renderingSource30 = null;
        combinedDomainXYPlot18.select((double) 1L, (double) ' ', rectangle2D29, renderingSource30);
        java.lang.String str32 = combinedDomainXYPlot18.getPlotType();
        org.jfree.chart.entity.PlotEntity plotEntity35 = new org.jfree.chart.entity.PlotEntity(shape17, (org.jfree.chart.plot.Plot) combinedDomainXYPlot18, "Time", "java.awt.Color[r=255,g=255,b=0]");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot36 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot36.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = combinedDomainXYPlot36.getRangeMarkers((int) (short) 1, layer40);
        combinedDomainXYPlot36.clearDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis44 = combinedDomainXYPlot36.getDomainAxisForDataset(0);
        org.jfree.chart.entity.PlotEntity plotEntity45 = new org.jfree.chart.entity.PlotEntity(shape17, (org.jfree.chart.plot.Plot) combinedDomainXYPlot36);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(plot13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Combined_Domain_XYPlot" + "'", str32.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNull(valueAxis44);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getVersion();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2.0-pre" + "'", str1.equals("1.2.0-pre"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 0.5f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        org.jfree.chart.LegendItem legendItem8 = xYStepRenderer2.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        combinedDomainXYPlot13.setFixedLegendItems(legendItemCollection14);
        java.awt.Paint paint16 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot13.setDomainGridlinePaint(paint16);
        boolean boolean18 = combinedDomainXYPlot13.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        combinedDomainXYPlot13.setDataset((int) (short) 0, xYDataset20);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.RenderingSource renderingSource25 = null;
        combinedDomainXYPlot13.select((double) 1L, (double) ' ', rectangle2D24, renderingSource25);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection27 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D28.setMinimumArcAngleToDraw((double) (byte) -1);
        double double31 = piePlot3D28.getInteriorGap();
        piePlot3D28.setDarkerSides(false);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D36.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D36.setLabelLinkStroke(stroke39);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint43.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart47 = chartChangeEvent46.getChart();
        boolean boolean48 = chartRenderingInfo42.equals((java.lang.Object) chartChangeEvent46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = chartRenderingInfo42.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState50 = piePlot3D28.initialise(graphics2D34, rectangle2D35, (org.jfree.chart.plot.PiePlot) piePlot3D36, (java.lang.Integer) 0, plotRenderingInfo49);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState51 = xYStepRenderer2.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13, (org.jfree.data.xy.XYDataset) xYSeriesCollection27, plotRenderingInfo49);
        boolean boolean52 = xYItemRendererState51.getProcessVisibleItemsOnly();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.08d + "'", double31 == 0.08d);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNull(jFreeChart47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo49);
        org.junit.Assert.assertNotNull(piePlotState50);
        org.junit.Assert.assertNotNull(xYItemRendererState51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        java.util.List list6 = jFreeChart5.getSubtitles();
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart5.getTitle();
        boolean boolean8 = jFreeChart5.isBorderVisible();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(textTitle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter(3.0d, (double) (short) -1, 0.05d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("PieLabelLinkStyle.STANDARD");
        java.text.AttributedString attributedString3 = null;
        standardPieSectionLabelGenerator1.setAttributedLabel(0, attributedString3);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke((-4767));
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray9, numberArray13, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray18);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset19);
        org.jfree.data.general.PieDataset pieDataset22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset19, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj24 = categoryAxis23.clone();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint28 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer26.setSeriesOutlinePaint((int) (short) 10, paint28);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        combinedDomainXYPlot30.setFixedLegendItems(legendItemCollection31);
        java.awt.Paint paint33 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot30.setDomainGridlinePaint(paint33);
        boolean boolean35 = combinedDomainXYPlot30.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        combinedDomainXYPlot30.setDataset((int) (short) 0, xYDataset37);
        combinedDomainXYPlot30.setBackgroundImageAlignment((int) (byte) -1);
        int int41 = combinedDomainXYPlot30.getDatasetCount();
        xYBarRenderer26.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot30);
        java.awt.Font font44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer26.setLegendTextFont((int) (short) 100, font44);
        categoryAxis23.setTickLabelFont((java.lang.Comparable) month25, font44);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset22, (java.lang.Comparable) month25, (double) 5, 12);
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        int int51 = month50.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = month50.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod52, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = timeSeriesDataItem54.getPeriod();
        org.jfree.chart.axis.PeriodAxis periodAxis56 = new org.jfree.chart.axis.PeriodAxis("UnitType.ABSOLUTE", (org.jfree.data.time.RegularTimePeriod) month25, regularTimePeriod55);
        boolean boolean57 = strokeList0.equals((java.lang.Object) regularTimePeriod55);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.0d + "'", number20.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset22);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer8);
        boolean boolean11 = legendTitle10.visible;
        legendTitle10.setHeight((double) 8);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle10.getLegendItemGraphicEdge();
        org.jfree.chart.axis.AxisState axisState15 = null;
        categoryAxis0.drawTickMarks(graphics2D2, (double) ' ', rectangle2D4, rectangleEdge14, axisState15);
        categoryAxis0.setCategoryLabelPositionOffset(9999);
        java.lang.Comparable comparable19 = null;
        try {
            categoryAxis0.addCategoryLabelToolTip(comparable19, "NOID");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray9 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray10 = color4.getRGBColorComponents(floatArray9);
        int int11 = color4.getAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, (double) (-2208960000000L), (java.awt.Paint) color4);
        java.awt.Color color13 = java.awt.Color.getColor("Pie 3D Plot", color4);
        float[] floatArray14 = null;
        float[] floatArray15 = color4.getColorComponents(floatArray14);
        try {
            float[] floatArray16 = color0.getRGBComponents(floatArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray7 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray8 = color2.getRGBColorComponents(floatArray7);
        int int9 = color2.getAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, (double) (-2208960000000L), (java.awt.Paint) color2);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str14 = intervalMarker13.getLabel();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.TOP;
        intervalMarker13.setLabelAnchor(rectangleAnchor15);
        intervalMarker10.setLabelAnchor(rectangleAnchor15);
        java.lang.String str18 = intervalMarker10.getLabel();
        java.awt.Font font19 = intervalMarker10.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        intervalMarker10.setLabelOffset(rectangleInsets20);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        boolean boolean6 = xYStepRenderer2.getBaseLinesVisible();
        boolean boolean7 = xYStepRenderer2.getDrawSeriesLineAsPath();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart5.setTitle("12-January-1900");
        java.lang.Object obj8 = jFreeChart5.clone();
        float float9 = jFreeChart5.getBackgroundImageAlpha();
        jFreeChart5.fireChartChanged();
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart5.getTitle();
        textTitle11.setMaximumLinesToDisplay(13);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNotNull(textTitle11);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        java.awt.Font font2 = standardChartTheme1.getExtraLargeFont();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem4.setShapeVisible(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendItem4.setLabelPaint((java.awt.Paint) color7);
        standardChartTheme1.setGridBandPaint((java.awt.Paint) color7);
        java.awt.Paint paint10 = standardChartTheme1.getErrorIndicatorPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setMinimumArcAngleToDraw((double) (byte) -1);
        double double7 = piePlot3D4.getInteriorGap();
        piePlot3D4.setDarkerSides(false);
        piePlot3D4.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean13 = piePlot3D12.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = piePlot3D12.getLegendLabelGenerator();
        piePlot3D4.setLegendLabelGenerator(pieSectionLabelGenerator14);
        java.awt.Shape shape16 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries18 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection(timeSeries18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection19);
        polarPlot17.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection19);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot17);
        java.util.List list23 = jFreeChart22.getSubtitles();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity24 = new org.jfree.chart.entity.JFreeChartEntity(shape16, jFreeChart22);
        java.awt.Paint paint25 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("Last", "HorizontalAlignment.CENTER", "Pie 3D Plot", "", shape16, paint25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("hi!�");
        java.awt.Paint paint29 = logAxis28.getTickLabelPaint();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape16, (org.jfree.chart.axis.Axis) logAxis28, "UnitType.ABSOLUTE");
        java.lang.Object obj32 = axisEntity31.clone();
        java.lang.String str33 = axisEntity31.toString();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AxisEntity: tooltip = UnitType.ABSOLUTE" + "'", str33.equals("AxisEntity: tooltip = UnitType.ABSOLUTE"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator(13, categoryToolTipGenerator2);
        java.awt.Paint paint4 = barRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation5 = null;
        boolean boolean6 = barRenderer0.removeAnnotation(categoryAnnotation5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(itemLabelPosition10);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean2 = logAxis1.isInverted();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity6 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis1, shape3, "java.awt.Color[r=255,g=255,b=0]", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray9, numberArray13, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray18);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset19);
        org.jfree.data.general.PieDataset pieDataset22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset19, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj24 = categoryAxis23.clone();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint28 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer26.setSeriesOutlinePaint((int) (short) 10, paint28);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        combinedDomainXYPlot30.setFixedLegendItems(legendItemCollection31);
        java.awt.Paint paint33 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot30.setDomainGridlinePaint(paint33);
        boolean boolean35 = combinedDomainXYPlot30.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        combinedDomainXYPlot30.setDataset((int) (short) 0, xYDataset37);
        combinedDomainXYPlot30.setBackgroundImageAlignment((int) (byte) -1);
        int int41 = combinedDomainXYPlot30.getDatasetCount();
        xYBarRenderer26.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot30);
        java.awt.Font font44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer26.setLegendTextFont((int) (short) 100, font44);
        categoryAxis23.setTickLabelFont((java.lang.Comparable) month25, font44);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset22, (java.lang.Comparable) month25, (double) 5, 12);
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        int int51 = month50.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = month50.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod52, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = timeSeriesDataItem54.getPeriod();
        org.jfree.chart.axis.PeriodAxis periodAxis56 = new org.jfree.chart.axis.PeriodAxis("UnitType.ABSOLUTE", (org.jfree.data.time.RegularTimePeriod) month25, regularTimePeriod55);
        java.lang.Class class57 = periodAxis56.getAutoRangeTimePeriodClass();
        java.net.URL uRL58 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("HorizontalAlignment.CENTER", class57);
        java.net.URL uRL59 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("[size=hi!-0.0]", class57);
        java.io.InputStream inputStream60 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", class57);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.0d + "'", number20.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset22);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(class57);
        org.junit.Assert.assertNull(uRL58);
        org.junit.Assert.assertNull(uRL59);
        org.junit.Assert.assertNull(inputStream60);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYStepRenderer2.getLegendItems();
        int int4 = xYStepRenderer2.getPassCount();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection6, valueAxis7, polarItemRenderer8);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator10, xYURLGenerator11);
        java.awt.Paint paint13 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer12.setBaseItemLabelPaint(paint13, false);
        org.jfree.chart.LegendItem legendItem18 = xYStepRenderer12.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer12.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = null;
        combinedDomainXYPlot23.setFixedLegendItems(legendItemCollection24);
        java.awt.Paint paint26 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot23.setDomainGridlinePaint(paint26);
        boolean boolean28 = combinedDomainXYPlot23.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        combinedDomainXYPlot23.setDataset((int) (short) 0, xYDataset30);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.RenderingSource renderingSource35 = null;
        combinedDomainXYPlot23.select((double) 1L, (double) ' ', rectangle2D34, renderingSource35);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection37 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D38 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D38.setMinimumArcAngleToDraw((double) (byte) -1);
        double double41 = piePlot3D38.getInteriorGap();
        piePlot3D38.setDarkerSides(false);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D46 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D46.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D46.setLabelLinkStroke(stroke49);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo52 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint53 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = rectangleConstraint53.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent56 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart57 = chartChangeEvent56.getChart();
        boolean boolean58 = chartRenderingInfo52.equals((java.lang.Object) chartChangeEvent56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = chartRenderingInfo52.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState60 = piePlot3D38.initialise(graphics2D44, rectangle2D45, (org.jfree.chart.plot.PiePlot) piePlot3D46, (java.lang.Integer) 0, plotRenderingInfo59);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState61 = xYStepRenderer12.initialise(graphics2D21, rectangle2D22, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot23, (org.jfree.data.xy.XYDataset) xYSeriesCollection37, plotRenderingInfo59);
        timeSeriesCollection6.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection37);
        boolean boolean63 = xYStepRenderer2.equals((java.lang.Object) xYSeriesCollection37);
        boolean boolean64 = xYStepRenderer2.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem18);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.08d + "'", double41 == 0.08d);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(rectangleConstraint53);
        org.junit.Assert.assertNotNull(rectangleConstraint55);
        org.junit.Assert.assertNull(jFreeChart57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo59);
        org.junit.Assert.assertNotNull(piePlotState60);
        org.junit.Assert.assertNotNull(xYItemRendererState61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        combinedDomainXYPlot0.setRenderer(xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray10 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray11 = color5.getRGBColorComponents(floatArray10);
        int int12 = color5.getAlpha();
        combinedDomainXYPlot0.setRangeTickBandPaint((java.awt.Paint) color5);
        boolean boolean14 = combinedDomainXYPlot0.isDomainCrosshairVisible();
        combinedDomainXYPlot0.mapDatasetToRangeAxis(0, 500);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("[size=hi!-0.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = dateAxis0.getTickLabelInsets();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        java.util.TimeZone timeZone3 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        dateAxis0.setTimeZone(timeZone3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D7.setMinimumArcAngleToDraw((double) (byte) -1);
        double double10 = piePlot3D7.getInteriorGap();
        piePlot3D7.setDarkerSides(false);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D15.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D15.setLabelLinkStroke(stroke18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint22.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart26 = chartChangeEvent25.getChart();
        boolean boolean27 = chartRenderingInfo21.equals((java.lang.Object) chartChangeEvent25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = chartRenderingInfo21.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState29 = piePlot3D7.initialise(graphics2D13, rectangle2D14, (org.jfree.chart.plot.PiePlot) piePlot3D15, (java.lang.Integer) 0, plotRenderingInfo28);
        java.awt.geom.Rectangle2D rectangle2D30 = plotRenderingInfo28.getDataArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D31 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D31.setMinimumArcAngleToDraw((double) (byte) -1);
        double double34 = piePlot3D31.getInteriorGap();
        piePlot3D31.setDarkerSides(false);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D39 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D39.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D39.setLabelLinkStroke(stroke42);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo45 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = rectangleConstraint46.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart50 = chartChangeEvent49.getChart();
        boolean boolean51 = chartRenderingInfo45.equals((java.lang.Object) chartChangeEvent49);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = chartRenderingInfo45.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState53 = piePlot3D31.initialise(graphics2D37, rectangle2D38, (org.jfree.chart.plot.PiePlot) piePlot3D39, (java.lang.Integer) 0, plotRenderingInfo52);
        java.awt.geom.Rectangle2D rectangle2D54 = plotRenderingInfo52.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot56 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection57 = null;
        combinedDomainXYPlot56.setFixedLegendItems(legendItemCollection57);
        java.awt.Paint paint59 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot56.setDomainGridlinePaint(paint59);
        boolean boolean61 = combinedDomainXYPlot56.canSelectByPoint();
        int int62 = combinedDomainXYPlot56.getSeriesCount();
        combinedDomainXYPlot56.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot66 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection67 = null;
        combinedDomainXYPlot66.setFixedLegendItems(legendItemCollection67);
        java.awt.Paint paint69 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot66.setDomainGridlinePaint(paint69);
        boolean boolean71 = combinedDomainXYPlot66.canSelectByPoint();
        int int72 = combinedDomainXYPlot66.getSeriesCount();
        boolean boolean73 = combinedDomainXYPlot66.canSelectByPoint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo76 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint77 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint79 = rectangleConstraint77.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent80 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart81 = chartChangeEvent80.getChart();
        boolean boolean82 = chartRenderingInfo76.equals((java.lang.Object) chartChangeEvent80);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo83 = chartRenderingInfo76.getPlotInfo();
        combinedDomainXYPlot66.handleClick((-4767), 8, plotRenderingInfo83);
        org.jfree.chart.plot.PolarPlot polarPlot85 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo88 = null;
        java.awt.geom.Rectangle2D rectangle2D89 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor90 = null;
        java.awt.geom.Point2D point2D91 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D89, rectangleAnchor90);
        polarPlot85.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo88, point2D91);
        combinedDomainXYPlot56.zoomDomainAxes((double) 1L, plotRenderingInfo83, point2D91);
        try {
            org.jfree.chart.axis.AxisState axisState94 = dateAxis0.draw(graphics2D5, (double) (-1), rectangle2D30, rectangle2D54, rectangleEdge55, plotRenderingInfo83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.08d + "'", double10 == 0.08d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNull(jFreeChart26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo28);
        org.junit.Assert.assertNotNull(piePlotState29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.08d + "'", double34 == 0.08d);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(rectangleConstraint46);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
        org.junit.Assert.assertNull(jFreeChart50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo52);
        org.junit.Assert.assertNotNull(piePlotState53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint77);
        org.junit.Assert.assertNotNull(rectangleConstraint79);
        org.junit.Assert.assertNull(jFreeChart81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo83);
        org.junit.Assert.assertNotNull(point2D91);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem1.setShapeVisible(true);
        java.lang.Comparable comparable4 = legendItem1.getSeriesKey();
        legendItem1.setURLText("ERROR : Relative To String");
        org.jfree.data.general.Dataset dataset7 = legendItem1.getDataset();
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertNull(dataset7);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        boolean boolean70 = combinedDomainXYPlot20.canSelectByRegion();
        combinedDomainXYPlot20.setGap((double) 2019);
        org.jfree.chart.axis.ValueAxis valueAxis74 = combinedDomainXYPlot20.getRangeAxisForDataset((int) (byte) 0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder75 = combinedDomainXYPlot20.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(valueAxis74);
        org.junit.Assert.assertNotNull(datasetRenderingOrder75);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setShadowXOffset(45.0d);
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) textAnchor19, true);
        xYBarRenderer0.notifyListeners(rendererChangeEvent21);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter23 = xYBarRenderer0.getBarPainter();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(xYBarPainter23);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer3 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = xYStepRenderer3.getBaseToolTipGenerator();
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font6);
        xYStepRenderer3.setBaseItemLabelFont(font6);
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("hi!�");
        java.awt.Paint paint11 = logAxis10.getTickLabelPaint();
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("HorizontalAlignment.CENTER", font6, paint11, 0.5f);
        java.awt.Paint paint14 = textFragment13.getPaint();
        org.junit.Assert.assertNull(xYToolTipGenerator4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        org.jfree.data.Range range70 = dateAxis36.getRange();
        java.util.TimeZone timeZone72 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis73 = new org.jfree.chart.axis.DateAxis("Nearest", timeZone72);
        dateAxis36.setTimeZone(timeZone72);
        org.jfree.chart.axis.DateTickUnit dateTickUnit75 = null;
        try {
            java.util.Date date76 = dateAxis36.calculateHighestVisibleTickValue(dateTickUnit75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertNotNull(timeZone72);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        boolean boolean5 = xYStepRenderer2.getItemLineVisible((-1), (int) ' ');
        boolean boolean7 = xYStepRenderer2.isSeriesVisible((int) (short) 0);
        xYStepRenderer2.setItemLabelAnchorOffset(899992.0d);
        org.jfree.chart.block.CenterArrangement centerArrangement10 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement10.add((org.jfree.chart.block.Block) labelBlock12, (java.lang.Object) 100L);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        labelBlock12.setContentAlignmentPoint(textBlockAnchor15);
        boolean boolean17 = xYStepRenderer2.equals((java.lang.Object) labelBlock12);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.NumberTick numberTick9 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 9.0d, "Size2D[width=0.0, height=0.0]", textAnchor6, textAnchor7, (double) 60000L);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor14 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor14, textAnchor15);
        org.jfree.chart.axis.NumberTick numberTick18 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.08d, "hi!", textAnchor13, textAnchor15, (double) 2.0f);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (byte) 0, (float) 4, textAnchor6, 0.5d, textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(itemLabelAnchor14);
        org.junit.Assert.assertNotNull(textAnchor15);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        boolean boolean2 = xYStepAreaRenderer1.getPlotArea();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj1 = categoryPlot0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace2, true);
        categoryPlot0.setRangeMinorGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        boolean boolean6 = xYStepRenderer2.getBaseLinesVisible();
        boolean boolean7 = xYStepRenderer2.getBaseLinesVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D2.setMinimumArcAngleToDraw((double) (byte) -1);
        piePlot3D2.setStartAngle((double) (byte) -1);
        boolean boolean7 = dateTickMarkPosition0.equals((java.lang.Object) piePlot3D2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.MIDDLE" + "'", str1.equals("DateTickMarkPosition.MIDDLE"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = null;
        java.awt.geom.Point2D point2D6 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D4, rectangleAnchor5);
        polarPlot0.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo3, point2D6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        polarPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D(pieDataset10);
        boolean boolean12 = polarPlot0.equals((java.lang.Object) piePlot3D11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets13.calculateLeftOutset((double) 2);
        piePlot3D11.setInsets(rectangleInsets13, true);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CrosshairState crosshairState13 = null;
        boolean boolean14 = combinedDomainXYPlot0.render(graphics2D9, rectangle2D10, 10, plotRenderingInfo12, crosshairState13);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.Layer layer19 = null;
        combinedDomainXYPlot0.addRangeMarker((-4767), (org.jfree.chart.plot.Marker) intervalMarker18, layer19, true);
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem23.setSeriesIndex((int) '4');
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray31, numberArray35, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray40);
        java.lang.Number number42 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset41);
        legendItem23.setDataset((org.jfree.data.general.Dataset) categoryDataset41);
        java.awt.Stroke stroke44 = legendItem23.getOutlineStroke();
        combinedDomainXYPlot0.setRangeZeroBaselineStroke(stroke44);
        java.awt.Paint paint46 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainCrosshairPaint(paint46);
        org.jfree.chart.plot.IntervalMarker intervalMarker50 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer51 = null;
        intervalMarker50.setGradientPaintTransformer(gradientPaintTransformer51);
        org.jfree.chart.text.TextAnchor textAnchor53 = intervalMarker50.getLabelTextAnchor();
        combinedDomainXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker50);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 1.0d + "'", number42.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(textAnchor53);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth((double) 0.0f);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer3.setSeriesOutlinePaint((int) (short) 10, paint5);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        combinedDomainXYPlot7.setFixedLegendItems(legendItemCollection8);
        java.awt.Paint paint10 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot7.setDomainGridlinePaint(paint10);
        boolean boolean12 = combinedDomainXYPlot7.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        combinedDomainXYPlot7.setDataset((int) (short) 0, xYDataset14);
        combinedDomainXYPlot7.setBackgroundImageAlignment((int) (byte) -1);
        int int18 = combinedDomainXYPlot7.getDatasetCount();
        xYBarRenderer3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot7);
        xYBarRenderer3.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = null;
        combinedDomainXYPlot23.setFixedLegendItems(legendItemCollection24);
        java.awt.Paint paint26 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot23.setDomainGridlinePaint(paint26);
        boolean boolean28 = combinedDomainXYPlot23.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        combinedDomainXYPlot23.setDataset((int) (short) 0, xYDataset30);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.RenderingSource renderingSource35 = null;
        combinedDomainXYPlot23.select((double) 1L, (double) ' ', rectangle2D34, renderingSource35);
        java.lang.String str37 = combinedDomainXYPlot23.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = combinedDomainXYPlot23.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray45, numberArray49, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray54);
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset55, (double) (-2208960000000L));
        double double58 = range57.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint60 = new org.jfree.chart.block.RectangleConstraint(range57, 100.0d);
        boolean boolean63 = range57.intersects((double) (byte) 10, (double) 9999);
        dateAxis39.setRange(range57, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker69 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str70 = intervalMarker69.getLabel();
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        xYBarRenderer3.drawRangeMarker(graphics2D22, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot23, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.plot.Marker) intervalMarker69, rectangle2D71);
        org.jfree.data.Range range73 = dateAxis39.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint74 = rectangleConstraint0.toRangeWidth(range73);
        boolean boolean77 = range73.intersects((-2.20895999997E12d), 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Combined_Domain_XYPlot" + "'", str37.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + (-2.20896E12d) + "'", double58 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNotNull(rectangleConstraint74);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = null;
        try {
            defaultKeyedValues0.sortByKeys(sortOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(13);
        int int3 = spreadsheetDate2.getYYYY();
        int int4 = spreadsheetDate2.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D8.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D8.setLabelLinkStroke(stroke11);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint15.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart19 = chartChangeEvent18.getChart();
        boolean boolean20 = chartRenderingInfo14.equals((java.lang.Object) chartChangeEvent18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo14.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState22 = piePlot3D0.initialise(graphics2D6, rectangle2D7, (org.jfree.chart.plot.PiePlot) piePlot3D8, (java.lang.Integer) 0, plotRenderingInfo21);
        java.awt.Font font25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font25);
        java.awt.Color color27 = java.awt.Color.green;
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("", font25, (java.awt.Paint) color27);
        piePlot3D8.setLabelPaint((java.awt.Paint) color27);
        double double30 = piePlot3D8.getMaximumLabelWidth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNull(jFreeChart19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(piePlotState22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(textBlock28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.14d + "'", double30 == 0.14d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.canSelectByRegion();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint8.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart12 = chartChangeEvent11.getChart();
        boolean boolean13 = chartRenderingInfo7.equals((java.lang.Object) chartChangeEvent11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo7.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        xYPlot4.panDomainAxes((double) (short) 10, plotRenderingInfo14, point2D17);
        java.awt.Stroke stroke19 = xYPlot4.getDomainZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNull(jFreeChart12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3D0);
        org.jfree.data.general.PieDataset pieDataset5 = piePlot3D0.getDataset();
        boolean boolean6 = piePlot3D0.getSectionOutlinesVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        intervalMarker9.setStroke(stroke10);
        piePlot3D0.setBaseSectionOutlineStroke(stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot3D0.getSimpleLabelOffset();
        piePlot3D0.setIgnoreNullValues(false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list1 = defaultKeyedValues0.getKeys();
        java.lang.Comparable comparable2 = null;
        try {
            defaultKeyedValues0.removeValue(comparable2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart5.setTitle("12-January-1900");
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart5.getLegend(2958465);
        org.jfree.chart.plot.Plot plot10 = jFreeChart5.getPlot();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(legendTitle9);
        org.junit.Assert.assertNotNull(plot10);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator3);
        org.jfree.chart.LegendItem legendItem7 = xYAreaRenderer4.getLegendItem(12, 1);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer4.setBasePaint((java.awt.Paint) color8, true);
        java.awt.Color color12 = org.jfree.chart.util.PaintUtilities.stringToColor("DateTickMarkPosition.MIDDLE");
        xYAreaRenderer4.setBaseOutlinePaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(legendItem7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        int int2 = crosshairState1.getDatasetIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = null;
        try {
            combinedDomainXYPlot0.setDomainAxes(valueAxisArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem1.setSeriesIndex((int) '4');
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray9, numberArray13, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray18);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset19);
        legendItem1.setDataset((org.jfree.data.general.Dataset) categoryDataset19);
        java.awt.Stroke stroke22 = legendItem1.getOutlineStroke();
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        legendItem1.setFillPaint(paint23);
        java.awt.Paint paint25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem1.setFillPaint(paint25);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.0d + "'", number20.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds(xYDataset0, list1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D1.setMinimumArcAngleToDraw((double) (byte) -1);
        double double4 = piePlot3D1.getInteriorGap();
        piePlot3D1.setDarkerSides(false);
        piePlot3D1.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean10 = piePlot3D9.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot3D9.getLegendLabelGenerator();
        piePlot3D1.setLegendLabelGenerator(pieSectionLabelGenerator11);
        java.awt.Shape shape13 = piePlot3D1.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries15 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeSeries15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        polarPlot14.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot14);
        java.util.List list20 = jFreeChart19.getSubtitles();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity21 = new org.jfree.chart.entity.JFreeChartEntity(shape13, jFreeChart19);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 'a', jFreeChart19);
        org.jfree.chart.event.ChartProgressListener chartProgressListener23 = null;
        jFreeChart19.removeProgressListener(chartProgressListener23);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj4 = standardXYToolTipGenerator3.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator5);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer6.getLegendItem(12, 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer6.setBasePaint((java.awt.Paint) color10, true);
        standardChartTheme1.setShadowPaint((java.awt.Paint) color10);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        standardChartTheme1.setPlotOutlinePaint((java.awt.Paint) color14);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection17 = null;
        combinedDomainXYPlot16.setFixedLegendItems(legendItemCollection17);
        java.awt.Paint paint19 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot16.setDomainGridlinePaint(paint19);
        boolean boolean21 = combinedDomainXYPlot16.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        combinedDomainXYPlot16.setDataset((int) (short) 0, xYDataset23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.plot.CrosshairState crosshairState29 = null;
        boolean boolean30 = combinedDomainXYPlot16.render(graphics2D25, rectangle2D26, 10, plotRenderingInfo28, crosshairState29);
        org.jfree.chart.plot.IntervalMarker intervalMarker34 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.Layer layer35 = null;
        combinedDomainXYPlot16.addRangeMarker((-4767), (org.jfree.chart.plot.Marker) intervalMarker34, layer35, true);
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem39.setSeriesIndex((int) '4');
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray47, numberArray51, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray56);
        java.lang.Number number58 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset57);
        legendItem39.setDataset((org.jfree.data.general.Dataset) categoryDataset57);
        java.awt.Stroke stroke60 = legendItem39.getOutlineStroke();
        combinedDomainXYPlot16.setRangeZeroBaselineStroke(stroke60);
        java.awt.Paint paint62 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot16.setDomainCrosshairPaint(paint62);
        standardChartTheme1.setAxisLabelPaint(paint62);
        org.jfree.chart.StandardChartTheme standardChartTheme66 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator68 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj69 = standardXYToolTipGenerator68.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator70 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer71 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator68, xYURLGenerator70);
        org.jfree.chart.LegendItem legendItem74 = xYAreaRenderer71.getLegendItem(12, 1);
        java.awt.Color color75 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer71.setBasePaint((java.awt.Paint) color75, true);
        standardChartTheme66.setShadowPaint((java.awt.Paint) color75);
        standardChartTheme1.setLegendItemPaint((java.awt.Paint) color75);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + 1.0d + "'", number58.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(obj69);
        org.junit.Assert.assertNull(legendItem74);
        org.junit.Assert.assertNotNull(color75);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer3);
        boolean boolean6 = legendTitle5.visible;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle5.getPosition();
        java.awt.Color color8 = java.awt.Color.BLACK;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8);
        legendTitle5.setBackgroundPaint((java.awt.Paint) color8);
        legendTitle5.visible = true;
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str16 = intervalMarker15.getLabel();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP;
        intervalMarker15.setLabelAnchor(rectangleAnchor17);
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor17);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent20 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("MAJOR", "Size2D[width=0.0, height=0.0]", "null", "null");
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CrosshairState crosshairState13 = null;
        boolean boolean14 = combinedDomainXYPlot0.render(graphics2D9, rectangle2D10, 10, plotRenderingInfo12, crosshairState13);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.Layer layer19 = null;
        combinedDomainXYPlot0.addRangeMarker((-4767), (org.jfree.chart.plot.Marker) intervalMarker18, layer19, true);
        org.jfree.data.general.DatasetGroup datasetGroup22 = combinedDomainXYPlot0.getDatasetGroup();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent23);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis26 = combinedDomainXYPlot0.getDomainAxisForDataset(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 12 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(datasetGroup22);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray6, numberArray10, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset16);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset16, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj21 = categoryAxis20.clone();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer23.setSeriesOutlinePaint((int) (short) 10, paint25);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        combinedDomainXYPlot27.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot27.setDomainGridlinePaint(paint30);
        boolean boolean32 = combinedDomainXYPlot27.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        combinedDomainXYPlot27.setDataset((int) (short) 0, xYDataset34);
        combinedDomainXYPlot27.setBackgroundImageAlignment((int) (byte) -1);
        int int38 = combinedDomainXYPlot27.getDatasetCount();
        xYBarRenderer23.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot27);
        java.awt.Font font41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer23.setLegendTextFont((int) (short) 100, font41);
        categoryAxis20.setTickLabelFont((java.lang.Comparable) month22, font41);
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset19, (java.lang.Comparable) month22, (double) 5, 12);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int48 = month47.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod49, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeriesDataItem51.getPeriod();
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("UnitType.ABSOLUTE", (org.jfree.data.time.RegularTimePeriod) month22, regularTimePeriod52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = periodAxis53.getLast();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        long long56 = month55.getFirstMillisecond();
        periodAxis53.setFirst((org.jfree.data.time.RegularTimePeriod) month55);
        periodAxis53.setMinorTickMarksVisible(false);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(pieDataset46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1559372400000L + "'", long56 == 1559372400000L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-460), year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        java.awt.Font font3 = xYBarRenderer0.lookupLegendTextFont(3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = xYBarRenderer0.getGradientPaintTransformer();
        boolean boolean8 = xYBarRenderer0.getItemCreateEntity(2019, (int) (byte) 1, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean10 = xYBarRenderer9.isDrawBarOutline();
        xYBarRenderer9.setBaseCreateEntities(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYBarRenderer9.getNegativeItemLabelPosition(255, (-4767), false);
        xYBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition16, false);
        java.awt.Stroke stroke19 = null;
        try {
            xYBarRenderer0.setBaseOutlineStroke(stroke19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        int int6 = combinedDomainXYPlot0.getSeriesCount();
        int int7 = combinedDomainXYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = combinedDomainXYPlot0.getLegendItems();
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D11.setMinimumArcAngleToDraw((double) (byte) -1);
        double double14 = piePlot3D11.getInteriorGap();
        piePlot3D11.setDarkerSides(false);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D19 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D19.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D19.setLabelLinkStroke(stroke22);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint26.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart30 = chartChangeEvent29.getChart();
        boolean boolean31 = chartRenderingInfo25.equals((java.lang.Object) chartChangeEvent29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = chartRenderingInfo25.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState33 = piePlot3D11.initialise(graphics2D17, rectangle2D18, (org.jfree.chart.plot.PiePlot) piePlot3D19, (java.lang.Integer) 0, plotRenderingInfo32);
        java.awt.geom.Rectangle2D rectangle2D34 = plotRenderingInfo32.getDataArea();
        combinedDomainXYPlot0.handleClick((int) '4', 1, plotRenderingInfo32);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.08d + "'", double14 == 0.08d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertNull(jFreeChart30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo32);
        org.junit.Assert.assertNotNull(piePlotState33);
        org.junit.Assert.assertNotNull(rectangle2D34);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Stroke stroke2 = piePlot3D1.getLabelOutlineStroke();
        piePlot3D1.setExplodePercent((java.lang.Comparable) 10.0f, (double) 'a');
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        float[] floatArray7 = null;
        float[] floatArray8 = color6.getColorComponents(floatArray7);
        int int9 = color6.getGreen();
        piePlot3D1.setNoDataMessagePaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str3 = intervalMarker2.getLabel();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP;
        intervalMarker2.setLabelAnchor(rectangleAnchor4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator6, xYURLGenerator7);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYStepRenderer8.getBaseToolTipGenerator();
        boolean boolean10 = rectangleAnchor4.equals((java.lang.Object) xYStepRenderer8);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator11, xYURLGenerator12);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = xYStepRenderer13.getBaseToolTipGenerator();
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font16);
        xYStepRenderer13.setBaseItemLabelFont(font16);
        boolean boolean20 = xYStepRenderer13.equals((java.lang.Object) (byte) 1);
        java.awt.Stroke stroke21 = xYStepRenderer13.getBaseStroke();
        xYStepRenderer8.setBaseOutlineStroke(stroke21, true);
        java.lang.Boolean boolean25 = xYStepRenderer8.getSeriesShapesVisible(3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator27 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer29 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator27, xYURLGenerator28);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator30 = xYStepRenderer29.getBaseToolTipGenerator();
        java.awt.Font font32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font32);
        xYStepRenderer29.setBaseItemLabelFont(font32);
        try {
            xYStepRenderer8.setLegendTextFont((int) (byte) -1, font32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNull(xYToolTipGenerator30);
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer70 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean71 = xYBarRenderer70.isDrawBarOutline();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator72 = null;
        xYBarRenderer70.setBaseItemLabelGenerator(xYItemLabelGenerator72, true);
        int int75 = combinedDomainXYPlot20.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer70);
        boolean boolean76 = xYBarRenderer70.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint1 = barRenderer0.getShadowPaint();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray7 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray8 = color2.getRGBColorComponents(floatArray7);
        barRenderer0.setShadowPaint((java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator(13, categoryToolTipGenerator2);
        java.awt.Paint paint4 = barRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation5 = null;
        boolean boolean6 = barRenderer0.removeAnnotation(categoryAnnotation5);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator7);
        barRenderer0.removeAnnotations();
        java.awt.Shape shape10 = barRenderer0.getBaseLegendShape();
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray16, numberArray20, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray25);
        org.jfree.data.Range range28 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset26, false);
        org.jfree.data.Range range29 = barRenderer0.findRangeBounds(categoryDataset26);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(range29);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3D0);
        org.jfree.data.general.PieDataset pieDataset5 = piePlot3D0.getDataset();
        boolean boolean6 = piePlot3D0.getSectionOutlinesVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        intervalMarker9.setStroke(stroke10);
        piePlot3D0.setBaseSectionOutlineStroke(stroke10);
        boolean boolean13 = piePlot3D0.getAutoPopulateSectionOutlineStroke();
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] { numberArray19, numberArray23, numberArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray28);
        java.lang.Number number30 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset29);
        org.jfree.data.general.PieDataset pieDataset32 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset29, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj34 = categoryAxis33.clone();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint38 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer36.setSeriesOutlinePaint((int) (short) 10, paint38);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot40 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection41 = null;
        combinedDomainXYPlot40.setFixedLegendItems(legendItemCollection41);
        java.awt.Paint paint43 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot40.setDomainGridlinePaint(paint43);
        boolean boolean45 = combinedDomainXYPlot40.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        combinedDomainXYPlot40.setDataset((int) (short) 0, xYDataset47);
        combinedDomainXYPlot40.setBackgroundImageAlignment((int) (byte) -1);
        int int51 = combinedDomainXYPlot40.getDatasetCount();
        xYBarRenderer36.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot40);
        java.awt.Font font54 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer36.setLegendTextFont((int) (short) 100, font54);
        categoryAxis33.setTickLabelFont((java.lang.Comparable) month35, font54);
        org.jfree.data.general.PieDataset pieDataset59 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset32, (java.lang.Comparable) month35, (double) 5, 12);
        piePlot3D0.setDataset(pieDataset59);
        org.jfree.chart.LegendItem legendItem62 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem62.setSeriesIndex((int) '4');
        java.lang.Number[] numberArray70 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray74 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray78 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray79 = new java.lang.Number[][] { numberArray70, numberArray74, numberArray78 };
        org.jfree.data.category.CategoryDataset categoryDataset80 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray79);
        java.lang.Number number81 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset80);
        legendItem62.setDataset((org.jfree.data.general.Dataset) categoryDataset80);
        java.awt.Stroke stroke83 = legendItem62.getOutlineStroke();
        piePlot3D0.setBaseSectionOutlineStroke(stroke83);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 1.0d + "'", number30.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset32);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(pieDataset59);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(numberArray74);
        org.junit.Assert.assertNotNull(numberArray78);
        org.junit.Assert.assertNotNull(numberArray79);
        org.junit.Assert.assertNotNull(categoryDataset80);
        org.junit.Assert.assertTrue("'" + number81 + "' != '" + 1.0d + "'", number81.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke83);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj1 = categoryPlot0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace2, true);
        categoryPlot0.setRangeMinorGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        timeSeriesCollection1.clearSelection();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setMinimumArcAngleToDraw((double) (byte) -1);
        piePlot3D3.setBackgroundImageAlignment(13);
        boolean boolean8 = timeSeriesCollection1.equals((java.lang.Object) piePlot3D3);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor9 = timeSeriesCollection1.getXPosition();
        timeSeriesCollection1.clearSelection();
        timeSeriesCollection1.clearSelection();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timePeriodAnchor9);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj4 = standardXYToolTipGenerator3.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator5);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer6.getLegendItem(12, 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer6.setBasePaint((java.awt.Paint) color10, true);
        standardChartTheme1.setShadowPaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter14 = standardChartTheme1.getXYBarPainter();
        java.lang.Object obj15 = standardChartTheme1.clone();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(xYBarPainter14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator7 = logFormat5.formatToCharacterIterator((java.lang.Object) 0);
        int int8 = logFormat5.getMinimumFractionDigits();
        org.jfree.chart.util.LogFormat logFormat13 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator15 = logFormat13.formatToCharacterIterator((java.lang.Object) 0);
        logFormat13.setGroupingUsed(false);
        int int18 = logFormat13.getMinimumIntegerDigits();
        logFormat5.setExponentFormat((java.text.NumberFormat) logFormat13);
        org.jfree.chart.util.LogFormat logFormat20 = new org.jfree.chart.util.LogFormat();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator21 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat13, (java.text.NumberFormat) logFormat20);
        org.junit.Assert.assertNotNull(attributedCharacterIterator7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(attributedCharacterIterator15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.CenterArrangement centerArrangement1 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement1.add((org.jfree.chart.block.Block) labelBlock3, (java.lang.Object) 100L);
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray11, numberArray15, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray20);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset21, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer25 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement1, (org.jfree.data.general.Dataset) categoryDataset21, (java.lang.Comparable) (short) 1);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset21);
        categoryPlot0.setDataset(categoryDataset21);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection29 = null;
        combinedDomainXYPlot28.setFixedLegendItems(legendItemCollection29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        combinedDomainXYPlot28.setRenderer(xYItemRenderer31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray38 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray39 = color33.getRGBColorComponents(floatArray38);
        int int40 = color33.getAlpha();
        combinedDomainXYPlot28.setRangeTickBandPaint((java.awt.Paint) color33);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color33);
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer43.setBaseCreateEntities(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = barRenderer43.getPositiveItemLabelPositionFallback();
        int int47 = barRenderer43.getRowCount();
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray57 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray61 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray62 = new java.lang.Number[][] { numberArray53, numberArray57, numberArray61 };
        org.jfree.data.category.CategoryDataset categoryDataset63 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray62);
        org.jfree.data.Range range64 = barRenderer43.findRangeBounds(categoryDataset63);
        categoryPlot0.setDataset(categoryDataset63);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 10.0d + "'", number26.equals(10.0d));
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 255 + "'", int40 == 255);
        org.junit.Assert.assertNull(itemLabelPosition46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(categoryDataset63);
        org.junit.Assert.assertNotNull(range64);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        boolean boolean2 = seriesRenderingOrder0.equals((java.lang.Object) "null");
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj4 = standardXYToolTipGenerator3.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator5);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer6.getLegendItem(12, 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer6.setBasePaint((java.awt.Paint) color10, true);
        standardChartTheme1.setShadowPaint((java.awt.Paint) color10);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace15 = color14.getColorSpace();
        standardChartTheme1.setDomainGridlinePaint((java.awt.Paint) color14);
        java.awt.Paint paint17 = standardChartTheme1.getPlotBackgroundPaint();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter18 = standardChartTheme1.getXYBarPainter();
        java.awt.Font font19 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        standardChartTheme1.setExtraLargeFont(font19);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(colorSpace15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(xYBarPainter18);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYStepRenderer2.getBaseToolTipGenerator();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font5);
        xYStepRenderer2.setBaseItemLabelFont(font5);
        boolean boolean9 = xYStepRenderer2.equals((java.lang.Object) (byte) 1);
        boolean boolean12 = xYStepRenderer2.getItemShapeVisible(6, 2019);
        xYStepRenderer2.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        java.awt.Paint paint6 = combinedDomainXYPlot0.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        combinedDomainXYPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis10.pan(0.0d);
        double double14 = logAxis10.calculateValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = logAxis10.getLabelInsets();
        org.jfree.data.Range range16 = combinedDomainXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis10);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100);
        timeSeries1.removeAgedItems(false);
        try {
            org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((-1), 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = xYStepRenderer2.getSeriesToolTipGenerator((int) '#');
        xYStepRenderer2.setItemLabelAnchorOffset((double) 10L);
        org.junit.Assert.assertNull(xYToolTipGenerator4);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        org.jfree.data.Range range70 = dateAxis36.getRange();
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month();
        int int72 = month71.getYearValue();
        java.util.Date date73 = month71.getEnd();
        dateAxis36.setMinimumDate(date73);
        java.awt.Stroke stroke75 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis36.setAxisLineStroke(stroke75);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2019 + "'", int72 == 2019);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(stroke75);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray6, numberArray10, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset16);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset16, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj21 = categoryAxis20.clone();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer23.setSeriesOutlinePaint((int) (short) 10, paint25);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        combinedDomainXYPlot27.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot27.setDomainGridlinePaint(paint30);
        boolean boolean32 = combinedDomainXYPlot27.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        combinedDomainXYPlot27.setDataset((int) (short) 0, xYDataset34);
        combinedDomainXYPlot27.setBackgroundImageAlignment((int) (byte) -1);
        int int38 = combinedDomainXYPlot27.getDatasetCount();
        xYBarRenderer23.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot27);
        java.awt.Font font41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer23.setLegendTextFont((int) (short) 100, font41);
        categoryAxis20.setTickLabelFont((java.lang.Comparable) month22, font41);
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset19, (java.lang.Comparable) month22, (double) 5, 12);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int48 = month47.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod49, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeriesDataItem51.getPeriod();
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("UnitType.ABSOLUTE", (org.jfree.data.time.RegularTimePeriod) month22, regularTimePeriod52);
        periodAxis53.setMinorTickMarkOutsideLength((float) 0);
        java.util.TimeZone timeZone56 = periodAxis53.getTimeZone();
        org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem58.setSeriesIndex((int) '4');
        java.lang.Number[] numberArray66 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray70 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray74 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray75 = new java.lang.Number[][] { numberArray66, numberArray70, numberArray74 };
        org.jfree.data.category.CategoryDataset categoryDataset76 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray75);
        java.lang.Number number77 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset76);
        legendItem58.setDataset((org.jfree.data.general.Dataset) categoryDataset76);
        org.jfree.data.Range range79 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset76);
        org.jfree.data.time.DateRange dateRange80 = new org.jfree.data.time.DateRange(range79);
        org.jfree.data.Range range83 = org.jfree.data.Range.expand(range79, (double) 0.0f, (double) (byte) 1);
        periodAxis53.setRange(range83, false, false);
        periodAxis53.setTickLabelsVisible(false);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(pieDataset46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(numberArray74);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(categoryDataset76);
        org.junit.Assert.assertTrue("'" + number77 + "' != '" + 1.0d + "'", number77.equals(1.0d));
        org.junit.Assert.assertNotNull(range79);
        org.junit.Assert.assertNotNull(range83);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        piePlot3D0.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean9 = piePlot3D8.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        java.awt.Shape shape12 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        polarPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot13);
        java.util.List list19 = jFreeChart18.getSubtitles();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity20 = new org.jfree.chart.entity.JFreeChartEntity(shape12, jFreeChart18);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot21 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = null;
        combinedDomainXYPlot21.setFixedLegendItems(legendItemCollection22);
        java.awt.Paint paint24 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot21.setDomainGridlinePaint(paint24);
        boolean boolean26 = combinedDomainXYPlot21.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        combinedDomainXYPlot21.setDataset((int) (short) 0, xYDataset28);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.RenderingSource renderingSource33 = null;
        combinedDomainXYPlot21.select((double) 1L, (double) ' ', rectangle2D32, renderingSource33);
        java.lang.String str35 = combinedDomainXYPlot21.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset37 = combinedDomainXYPlot21.getDataset((int) (short) 1);
        org.jfree.chart.axis.LogAxis logAxis39 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean40 = logAxis39.isInverted();
        logAxis39.resizeRange(0.0d);
        org.jfree.data.Range range43 = combinedDomainXYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis39);
        java.awt.Paint paint44 = logAxis39.getTickLabelPaint();
        org.jfree.chart.entity.AxisEntity axisEntity45 = new org.jfree.chart.entity.AxisEntity(shape12, (org.jfree.chart.axis.Axis) logAxis39);
        logAxis39.setVerticalTickLabels(true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Combined_Domain_XYPlot" + "'", str35.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYDataset37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str2 = spreadsheetDate1.toString();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        long long6 = day4.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12-January-1900" + "'", str2.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2208009600000L) + "'", long6 == (-2208009600000L));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj4 = standardXYToolTipGenerator3.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator5);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer6.getLegendItem(12, 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer6.setBasePaint((java.awt.Paint) color10, true);
        standardChartTheme1.setShadowPaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter14 = standardChartTheme1.getXYBarPainter();
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis16.pan(0.0d);
        double double20 = logAxis16.calculateValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = logAxis16.getLabelInsets();
        standardChartTheme1.setAxisOffset(rectangleInsets21);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(xYBarPainter14);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock2, (java.lang.Object) 100L);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray10, numberArray14, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset20, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) categoryDataset20, (java.lang.Comparable) (short) 1);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer28);
        boolean boolean31 = legendTitle30.visible;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = legendTitle30.getPosition();
        legendItemBlockContainer24.add((org.jfree.chart.block.Block) legendTitle30);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.TOP;
        legendTitle30.setLegendItemGraphicLocation(rectangleAnchor34);
        legendTitle30.setPadding((double) (-1), (double) ' ', 100.0d, (double) 10.0f);
        legendTitle30.setNotify(true);
        double double43 = legendTitle30.getContentXOffset();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot44 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection45 = null;
        combinedDomainXYPlot44.setFixedLegendItems(legendItemCollection45);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        combinedDomainXYPlot44.setRenderer(xYItemRenderer47);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray54 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray55 = color49.getRGBColorComponents(floatArray54);
        int int56 = color49.getAlpha();
        combinedDomainXYPlot44.setRangeTickBandPaint((java.awt.Paint) color49);
        legendTitle30.setItemPaint((java.awt.Paint) color49);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 32.0d + "'", double43 == 32.0d);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 255 + "'", int56 == 255);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = null;
        combinedDomainXYPlot5.setFixedLegendItems(legendItemCollection6);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot5.setDomainGridlinePaint(paint8);
        boolean boolean10 = combinedDomainXYPlot5.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        combinedDomainXYPlot5.setDataset((int) (short) 0, xYDataset12);
        combinedDomainXYPlot5.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = combinedDomainXYPlot5.getDatasetRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = combinedDomainXYPlot5.removeDomainMarker(12, (org.jfree.chart.plot.Marker) intervalMarker20, layer21);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot4.setRenderer(xYItemRenderer24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation(2019, axisLocation27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double31 = rectangleInsets29.calculateRightOutset((double) 900000L);
        double double33 = rectangleInsets29.calculateLeftOutset(0.05d);
        xYPlot4.setInsets(rectangleInsets29, false);
        double double37 = rectangleInsets29.extendHeight((double) '4');
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.0d + "'", double33 == 4.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 56.0d + "'", double37 == 56.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.lang.Object obj1 = null;
        boolean boolean2 = lineBorder0.equals(obj1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker10.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.text.TextAnchor textAnchor13 = intervalMarker10.getLabelTextAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor15 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor15, textAnchor16);
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor15, textAnchor18, textAnchor19, 10.0d);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D5, (float) 1559372400000L, (float) (-1L), textAnchor13, 1.0d, textAnchor19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor3, textAnchor13);
        boolean boolean24 = lineBorder0.equals((java.lang.Object) itemLabelAnchor3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(itemLabelAnchor15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer3);
        boolean boolean6 = legendTitle5.visible;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle5.getPosition();
        java.awt.Color color8 = java.awt.Color.BLACK;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8);
        legendTitle5.setBackgroundPaint((java.awt.Paint) color8);
        legendTitle5.visible = true;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle5.getItemLabelPadding();
        org.jfree.chart.block.CenterArrangement centerArrangement14 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement14.add((org.jfree.chart.block.Block) labelBlock16, (java.lang.Object) 100L);
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray24, numberArray28, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset34, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer38 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement14, (org.jfree.data.general.Dataset) categoryDataset34, (java.lang.Comparable) (short) 1);
        java.lang.Object obj39 = legendItemBlockContainer38.clone();
        java.lang.String str40 = legendItemBlockContainer38.getURLText();
        legendTitle5.setWrapper((org.jfree.chart.block.BlockContainer) legendItemBlockContainer38);
        double double42 = legendItemBlockContainer38.getContentYOffset();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-2208960000000L));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        java.awt.Font font3 = xYBarRenderer0.lookupLegendTextFont(3);
        xYBarRenderer0.setSeriesVisible((int) (byte) 0, (java.lang.Boolean) true, true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = null;
        xYBarRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator8, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(font3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.CenterArrangement centerArrangement1 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement1.add((org.jfree.chart.block.Block) labelBlock3, (java.lang.Object) 100L);
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray11, numberArray15, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray20);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset21, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer25 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement1, (org.jfree.data.general.Dataset) categoryDataset21, (java.lang.Comparable) (short) 1);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset21);
        categoryPlot0.setDataset(categoryDataset21);
        org.jfree.chart.block.CenterArrangement centerArrangement29 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock31 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement29.add((org.jfree.chart.block.Block) labelBlock31, (java.lang.Object) 100L);
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray48 = new java.lang.Number[][] { numberArray39, numberArray43, numberArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray48);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset49, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer53 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement29, (org.jfree.data.general.Dataset) categoryDataset49, (java.lang.Comparable) (short) 1);
        java.lang.Object obj54 = legendItemBlockContainer53.clone();
        java.lang.String str55 = legendItemBlockContainer53.getURLText();
        java.util.List list56 = legendItemBlockContainer53.getBlocks();
        try {
            categoryPlot0.mapDatasetToDomainAxes(2019, list56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 10.0d + "'", number26.equals(10.0d));
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(obj54);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNotNull(list56);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj1 = categoryPlot0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace2, true);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace5);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        org.jfree.data.Range range70 = dateAxis36.getRange();
        double double71 = dateAxis36.getUpperBound();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + (-2.20895999997E12d) + "'", double71 == (-2.20895999997E12d));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        timeSeriesCollection1.clearSelection();
        java.util.List list3 = timeSeriesCollection1.getSeries();
        double double5 = timeSeriesCollection1.getDomainUpperBound(true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.awt.Color color1 = java.awt.Color.yellow;
        java.lang.String str2 = color1.toString();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=255,b=0]", (java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=255,g=255,b=0]" + "'", str2.equals("java.awt.Color[r=255,g=255,b=0]"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        double double5 = logAxis1.calculateValue(0.0d);
        logAxis1.setPositiveArrowVisible(true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.valueToJava2D(3.0d, rectangle2D2, rectangleEdge3);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = null;
        combinedDomainXYPlot5.setFixedLegendItems(legendItemCollection6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.CrosshairState crosshairState12 = null;
        boolean boolean13 = combinedDomainXYPlot5.render(graphics2D8, rectangle2D9, (int) 'a', plotRenderingInfo11, crosshairState12);
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot5);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition15 = org.jfree.chart.axis.DateTickMarkPosition.END;
        dateAxis0.setTickMarkPosition(dateTickMarkPosition15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D21.setMinimumArcAngleToDraw((double) (byte) -1);
        double double24 = piePlot3D21.getInteriorGap();
        piePlot3D21.setDarkerSides(false);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D29 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D29.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D29.setLabelLinkStroke(stroke32);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = rectangleConstraint36.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent39 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart40 = chartChangeEvent39.getChart();
        boolean boolean41 = chartRenderingInfo35.equals((java.lang.Object) chartChangeEvent39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = chartRenderingInfo35.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState43 = piePlot3D21.initialise(graphics2D27, rectangle2D28, (org.jfree.chart.plot.PiePlot) piePlot3D29, (java.lang.Integer) 0, plotRenderingInfo42);
        java.awt.geom.Rectangle2D rectangle2D44 = plotRenderingInfo42.getDataArea();
        boolean boolean45 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 4, (double) (-398), rectangle2D44);
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot48 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection49 = null;
        combinedDomainXYPlot48.setFixedLegendItems(legendItemCollection49);
        java.awt.Paint paint51 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot48.setDomainGridlinePaint(paint51);
        boolean boolean53 = combinedDomainXYPlot48.canSelectByPoint();
        int int54 = combinedDomainXYPlot48.getSeriesCount();
        combinedDomainXYPlot48.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot58 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection59 = null;
        combinedDomainXYPlot58.setFixedLegendItems(legendItemCollection59);
        java.awt.Paint paint61 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot58.setDomainGridlinePaint(paint61);
        boolean boolean63 = combinedDomainXYPlot58.canSelectByPoint();
        int int64 = combinedDomainXYPlot58.getSeriesCount();
        boolean boolean65 = combinedDomainXYPlot58.canSelectByPoint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo68 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint69 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint71 = rectangleConstraint69.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent72 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart73 = chartChangeEvent72.getChart();
        boolean boolean74 = chartRenderingInfo68.equals((java.lang.Object) chartChangeEvent72);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = chartRenderingInfo68.getPlotInfo();
        combinedDomainXYPlot58.handleClick((-4767), 8, plotRenderingInfo75);
        org.jfree.chart.plot.PolarPlot polarPlot77 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        java.awt.geom.Rectangle2D rectangle2D81 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor82 = null;
        java.awt.geom.Point2D point2D83 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D81, rectangleAnchor82);
        polarPlot77.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo80, point2D83);
        combinedDomainXYPlot48.zoomDomainAxes((double) 1L, plotRenderingInfo75, point2D83);
        try {
            org.jfree.chart.axis.AxisState axisState86 = dateAxis0.draw(graphics2D17, 45.0d, rectangle2D44, rectangle2D46, rectangleEdge47, plotRenderingInfo75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition15);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.08d + "'", double24 == 0.08d);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertNotNull(rectangleConstraint38);
        org.junit.Assert.assertNull(jFreeChart40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo42);
        org.junit.Assert.assertNotNull(piePlotState43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint69);
        org.junit.Assert.assertNotNull(rectangleConstraint71);
        org.junit.Assert.assertNull(jFreeChart73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo75);
        org.junit.Assert.assertNotNull(point2D83);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str2 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        combinedDomainXYPlot7.setFixedLegendItems(legendItemCollection8);
        java.awt.Paint paint10 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot7.setDomainGridlinePaint(paint10);
        boolean boolean12 = combinedDomainXYPlot7.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        combinedDomainXYPlot7.setDataset((int) (short) 0, xYDataset14);
        combinedDomainXYPlot7.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.xy.XYSeries xYSeries18 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection19 = new org.jfree.data.xy.XYSeriesCollection(xYSeries18);
        double double21 = xYSeriesCollection19.getDomainLowerBound(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = combinedDomainXYPlot7.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection19);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot7.setDomainAxisLocation(axisLocation23);
        boolean boolean25 = spreadsheetDate1.equals((java.lang.Object) combinedDomainXYPlot7);
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        combinedDomainXYPlot7.setRangeGridlinePaint(paint26);
        java.util.List list28 = combinedDomainXYPlot7.getSubplots();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12-January-1900" + "'", str2.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12-January-1900" + "'", str5.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(list28);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = null;
        combinedDomainXYPlot5.setFixedLegendItems(legendItemCollection6);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot5.setDomainGridlinePaint(paint8);
        boolean boolean10 = combinedDomainXYPlot5.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        combinedDomainXYPlot5.setDataset((int) (short) 0, xYDataset12);
        combinedDomainXYPlot5.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = combinedDomainXYPlot5.getDatasetRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = combinedDomainXYPlot5.removeDomainMarker(12, (org.jfree.chart.plot.Marker) intervalMarker20, layer21);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker20);
        java.awt.Font font24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        intervalMarker20.setLabelFont(font24);
        java.lang.Object obj26 = intervalMarker20.clone();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = null;
        java.awt.geom.Point2D point2D6 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D4, rectangleAnchor5);
        polarPlot0.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo3, point2D6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        polarPlot0.datasetChanged(datasetChangeEvent8);
        polarPlot0.setAngleGridlinesVisible(true);
        polarPlot0.setAngleGridlinesVisible(false);
        org.junit.Assert.assertNotNull(point2D6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        piePlot3D0.setBackgroundImageAlignment(13);
        boolean boolean5 = piePlot3D0.getAutoPopulateSectionOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = null;
        try {
            piePlot3D0.setLabelDistributor(abstractPieLabelDistributor6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer7 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator5, xYURLGenerator6);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer7.setBaseItemLabelPaint(paint8, false);
        org.jfree.chart.LegendItem legendItem13 = xYStepRenderer7.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer7.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = null;
        combinedDomainXYPlot18.setFixedLegendItems(legendItemCollection19);
        java.awt.Paint paint21 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot18.setDomainGridlinePaint(paint21);
        boolean boolean23 = combinedDomainXYPlot18.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        combinedDomainXYPlot18.setDataset((int) (short) 0, xYDataset25);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.RenderingSource renderingSource30 = null;
        combinedDomainXYPlot18.select((double) 1L, (double) ' ', rectangle2D29, renderingSource30);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection32 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D33.setMinimumArcAngleToDraw((double) (byte) -1);
        double double36 = piePlot3D33.getInteriorGap();
        piePlot3D33.setDarkerSides(false);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D41 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D41.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D41.setLabelLinkStroke(stroke44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = rectangleConstraint48.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent51 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart52 = chartChangeEvent51.getChart();
        boolean boolean53 = chartRenderingInfo47.equals((java.lang.Object) chartChangeEvent51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = chartRenderingInfo47.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState55 = piePlot3D33.initialise(graphics2D39, rectangle2D40, (org.jfree.chart.plot.PiePlot) piePlot3D41, (java.lang.Integer) 0, plotRenderingInfo54);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState56 = xYStepRenderer7.initialise(graphics2D16, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot18, (org.jfree.data.xy.XYDataset) xYSeriesCollection32, plotRenderingInfo54);
        timeSeriesCollection1.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection32);
        org.jfree.data.Range range59 = xYSeriesCollection32.getDomainBounds(false);
        double double60 = xYSeriesCollection32.getIntervalPositionFactor();
        java.lang.Object obj61 = xYSeriesCollection32.clone();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.08d + "'", double36 == 0.08d);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
        org.junit.Assert.assertNotNull(rectangleConstraint50);
        org.junit.Assert.assertNull(jFreeChart52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo54);
        org.junit.Assert.assertNotNull(piePlotState55);
        org.junit.Assert.assertNotNull(xYItemRendererState56);
        org.junit.Assert.assertNull(range59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.5d + "'", double60 == 0.5d);
        org.junit.Assert.assertNotNull(obj61);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYStepRenderer2.getBaseToolTipGenerator();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font5);
        xYStepRenderer2.setBaseItemLabelFont(font5);
        xYStepRenderer2.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = null;
        combinedDomainXYPlot11.setFixedLegendItems(legendItemCollection12);
        java.awt.Paint paint14 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot11.setDomainGridlinePaint(paint14);
        boolean boolean16 = combinedDomainXYPlot11.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        combinedDomainXYPlot11.setDataset((int) (short) 0, xYDataset18);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        combinedDomainXYPlot11.select((double) 1L, (double) ' ', rectangle2D22, renderingSource23);
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean26 = piePlot3D25.getDarkerSides();
        combinedDomainXYPlot11.setParent((org.jfree.chart.plot.Plot) piePlot3D25);
        boolean boolean28 = xYStepRenderer2.hasListener((java.util.EventListener) piePlot3D25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str31 = spreadsheetDate30.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate30.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot36 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection37 = null;
        combinedDomainXYPlot36.setFixedLegendItems(legendItemCollection37);
        java.awt.Paint paint39 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot36.setDomainGridlinePaint(paint39);
        boolean boolean41 = combinedDomainXYPlot36.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        combinedDomainXYPlot36.setDataset((int) (short) 0, xYDataset43);
        combinedDomainXYPlot36.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.xy.XYSeries xYSeries47 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection48 = new org.jfree.data.xy.XYSeriesCollection(xYSeries47);
        double double50 = xYSeriesCollection48.getDomainLowerBound(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = combinedDomainXYPlot36.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection48);
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot36.setDomainAxisLocation(axisLocation52);
        boolean boolean54 = spreadsheetDate30.equals((java.lang.Object) combinedDomainXYPlot36);
        java.awt.Paint paint55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        combinedDomainXYPlot36.setRangeGridlinePaint(paint55);
        piePlot3D25.setLabelShadowPaint(paint55);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "12-January-1900" + "'", str31.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "12-January-1900" + "'", str34.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(paint55);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator7 = logFormat5.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat5, (int) (byte) -1);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.BLACK;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12);
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font11, (java.awt.Paint) color12);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = null;
        textBlock14.draw(graphics2D15, (float) (short) 10, (float) '#', textBlockAnchor18, (float) 'a', (float) (-4767), (double) 1.0f);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.util.Size2D size2D24 = textBlock14.calculateDimensions(graphics2D23);
        int int25 = numberTickUnit9.compareTo((java.lang.Object) size2D24);
        org.jfree.chart.plot.PiePlot3D piePlot3D26 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D26.setMinimumArcAngleToDraw((double) (byte) -1);
        piePlot3D26.setBackgroundImageAlignment(13);
        boolean boolean31 = piePlot3D26.getAutoPopulateSectionOutlinePaint();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        piePlot3D26.setLabelBackgroundPaint((java.awt.Paint) color32);
        int int34 = numberTickUnit9.compareTo((java.lang.Object) color32);
        org.junit.Assert.assertNotNull(attributedCharacterIterator7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100);
        timeSeries1.removeAgedItems(false);
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener5);
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator3);
        boolean boolean5 = xYAreaRenderer4.getPlotLines();
        java.awt.Stroke stroke6 = xYAreaRenderer4.getBaseOutlineStroke();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean9 = xYBarRenderer8.isDrawBarOutline();
        xYBarRenderer8.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = xYBarRenderer8.getDrawingSupplier();
        xYBarRenderer8.setShadowYOffset((double) 0L);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = null;
        xYBarRenderer8.setSeriesURLGenerator((int) 'a', xYURLGenerator16, false);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator21 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        xYBarRenderer8.setSeriesURLGenerator(8, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator21);
        try {
            xYAreaRenderer4.setSeriesURLGenerator((int) (short) -1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(drawingSupplier12);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font7);
        java.awt.Color color9 = java.awt.Color.green;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font7, (java.awt.Paint) color9);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, (double) '#', (-398.0d), (double) 6, 0.0d, font7);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textBlock10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod2, (double) (short) 100);
        timeSeriesDataItem4.setSelected(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer7 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator5, xYURLGenerator6);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer7.setBaseItemLabelPaint(paint8, false);
        org.jfree.chart.LegendItem legendItem13 = xYStepRenderer7.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer7.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = null;
        combinedDomainXYPlot18.setFixedLegendItems(legendItemCollection19);
        java.awt.Paint paint21 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot18.setDomainGridlinePaint(paint21);
        boolean boolean23 = combinedDomainXYPlot18.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        combinedDomainXYPlot18.setDataset((int) (short) 0, xYDataset25);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.RenderingSource renderingSource30 = null;
        combinedDomainXYPlot18.select((double) 1L, (double) ' ', rectangle2D29, renderingSource30);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection32 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D33.setMinimumArcAngleToDraw((double) (byte) -1);
        double double36 = piePlot3D33.getInteriorGap();
        piePlot3D33.setDarkerSides(false);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D41 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D41.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D41.setLabelLinkStroke(stroke44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = rectangleConstraint48.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent51 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart52 = chartChangeEvent51.getChart();
        boolean boolean53 = chartRenderingInfo47.equals((java.lang.Object) chartChangeEvent51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = chartRenderingInfo47.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState55 = piePlot3D33.initialise(graphics2D39, rectangle2D40, (org.jfree.chart.plot.PiePlot) piePlot3D41, (java.lang.Integer) 0, plotRenderingInfo54);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState56 = xYStepRenderer7.initialise(graphics2D16, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot18, (org.jfree.data.xy.XYDataset) xYSeriesCollection32, plotRenderingInfo54);
        boolean boolean57 = intervalMarker2.equals((java.lang.Object) graphics2D16);
        java.awt.Paint paint58 = intervalMarker2.getLabelPaint();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.08d + "'", double36 == 0.08d);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
        org.junit.Assert.assertNotNull(rectangleConstraint50);
        org.junit.Assert.assertNull(jFreeChart52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo54);
        org.junit.Assert.assertNotNull(piePlotState55);
        org.junit.Assert.assertNotNull(xYItemRendererState56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.BLACK;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2);
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textBlock4.setLineAlignment(horizontalAlignment5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment5, verticalAlignment7, 0.0d, (double) (-1.0f));
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.CenterArrangement centerArrangement12 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement12.add((org.jfree.chart.block.Block) labelBlock14, (java.lang.Object) 100L);
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] { numberArray22, numberArray26, numberArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray31);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset32, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer36 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement12, (org.jfree.data.general.Dataset) categoryDataset32, (java.lang.Comparable) (short) 1);
        java.lang.Number number37 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset32);
        categoryPlot11.setDataset(categoryDataset32);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot39 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection40 = null;
        combinedDomainXYPlot39.setFixedLegendItems(legendItemCollection40);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        combinedDomainXYPlot39.setRenderer(xYItemRenderer42);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray49 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray50 = color44.getRGBColorComponents(floatArray49);
        int int51 = color44.getAlpha();
        combinedDomainXYPlot39.setRangeTickBandPaint((java.awt.Paint) color44);
        categoryPlot11.setRangeGridlinePaint((java.awt.Paint) color44);
        org.jfree.chart.LegendItem legendItem56 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem56.setSeriesIndex((int) '4');
        java.lang.Number[] numberArray64 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray68 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray72 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray73 = new java.lang.Number[][] { numberArray64, numberArray68, numberArray72 };
        org.jfree.data.category.CategoryDataset categoryDataset74 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray73);
        java.lang.Number number75 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset74);
        legendItem56.setDataset((org.jfree.data.general.Dataset) categoryDataset74);
        org.jfree.data.Range range77 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset74);
        categoryPlot11.setDataset(0, categoryDataset74);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer80 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement10, (org.jfree.data.general.Dataset) categoryDataset74, (java.lang.Comparable) 4.0d);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 10.0d + "'", number37.equals(10.0d));
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 255 + "'", int51 == 255);
        org.junit.Assert.assertNotNull(numberArray64);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(numberArray73);
        org.junit.Assert.assertNotNull(categoryDataset74);
        org.junit.Assert.assertTrue("'" + number75 + "' != '" + 1.0d + "'", number75.equals(1.0d));
        org.junit.Assert.assertNotNull(range77);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        timeSeriesCollection1.clearSelection();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setMinimumArcAngleToDraw((double) (byte) -1);
        piePlot3D3.setBackgroundImageAlignment(13);
        boolean boolean8 = timeSeriesCollection1.equals((java.lang.Object) piePlot3D3);
        java.util.List list9 = timeSeriesCollection1.getSeries();
        try {
            double double12 = timeSeriesCollection1.getEndXValue(3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        piePlot3D0.setBackgroundImageAlignment(13);
        boolean boolean5 = piePlot3D0.getAutoPopulateSectionOutlinePaint();
        java.lang.String str6 = piePlot3D0.getPlotType();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        java.awt.Stroke stroke9 = piePlot3D8.getLabelOutlineStroke();
        boolean boolean10 = piePlot3D0.equals((java.lang.Object) stroke9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pie 3D Plot" + "'", str6.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.util.Date date0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.axis.Timeline timeline3 = dateAxis1.getTimeline();
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone4);
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date0, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(timeline3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator3);
        boolean boolean5 = xYAreaRenderer4.getPlotLines();
        java.awt.Stroke stroke6 = xYAreaRenderer4.getBaseOutlineStroke();
        xYAreaRenderer4.setUseFillPaint(false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.valueToJava2D(3.0d, rectangle2D2, rectangleEdge3);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = null;
        combinedDomainXYPlot5.setFixedLegendItems(legendItemCollection6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.CrosshairState crosshairState12 = null;
        boolean boolean13 = combinedDomainXYPlot5.render(graphics2D8, rectangle2D9, (int) 'a', plotRenderingInfo11, crosshairState12);
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot5);
        double double15 = combinedDomainXYPlot5.getRangeCrosshairValue();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        combinedDomainXYPlot5.setDomainMinorGridlineStroke(stroke16);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Stroke stroke2 = piePlot3D1.getLabelOutlineStroke();
        piePlot3D1.setExplodePercent((java.lang.Comparable) "Time", (double) 4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot3D1.getURLGenerator();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(pieURLGenerator6);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem1.setShapeVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = legendItem1.getFillPaintTransformer();
        legendItem1.setShapeVisible(false);
        java.awt.Stroke stroke7 = legendItem1.getLineStroke();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeSeries9);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        polarPlot8.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot8);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart13.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) stroke7, jFreeChart13, (int) (short) 0, 0);
        org.jfree.chart.JFreeChart jFreeChart19 = chartProgressEvent18.getChart();
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(jFreeChart19);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer3.setSeriesOutlinePaint((int) (short) 10, paint5);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        combinedDomainXYPlot7.setFixedLegendItems(legendItemCollection8);
        java.awt.Paint paint10 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot7.setDomainGridlinePaint(paint10);
        boolean boolean12 = combinedDomainXYPlot7.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        combinedDomainXYPlot7.setDataset((int) (short) 0, xYDataset14);
        combinedDomainXYPlot7.setBackgroundImageAlignment((int) (byte) -1);
        int int18 = combinedDomainXYPlot7.getDatasetCount();
        xYBarRenderer3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot7);
        java.awt.Font font21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer3.setLegendTextFont((int) (short) 100, font21);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) month2, font21);
        java.lang.String str25 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 0.08d);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.text.DateFormat dateFormat1 = null;
        org.jfree.chart.util.LogFormat logFormat9 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator11 = logFormat9.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat9, (int) (byte) -1);
        org.jfree.chart.util.LogFormat logFormat18 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        logFormat18.setMinimumIntegerDigits((int) (short) 100);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator21 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined_Domain_XYPlot", (java.text.NumberFormat) logFormat9, (java.text.NumberFormat) logFormat18);
        java.lang.String str23 = logFormat9.format(0.0d);
        org.jfree.chart.util.LogFormat logFormat28 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator30 = logFormat28.formatToCharacterIterator((java.lang.Object) 0);
        java.lang.String str32 = logFormat28.format((double) 10);
        logFormat9.setExponentFormat((java.text.NumberFormat) logFormat28);
        org.jfree.chart.util.LogFormat logFormat39 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator41 = logFormat39.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat39, (int) (byte) -1);
        logFormat39.setMinimumFractionDigits((int) (short) 100);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator46 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!�", (java.text.NumberFormat) logFormat9, (java.text.NumberFormat) logFormat39);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator47 = new org.jfree.chart.labels.StandardXYToolTipGenerator("12-January-1900", dateFormat1, (java.text.NumberFormat) logFormat39);
        org.junit.Assert.assertNotNull(attributedCharacterIterator11);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!�" + "'", str23.equals("hi!�"));
        org.junit.Assert.assertNotNull(attributedCharacterIterator30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!-0.0" + "'", str32.equals("hi!-0.0"));
        org.junit.Assert.assertNotNull(attributedCharacterIterator41);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
        timeSeries1.add(timeSeriesDataItem6, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        try {
            java.lang.Number number13 = timeSeriesCollection10.getEndY((int) (short) 100, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        timeSeriesCollection1.clearSelection();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setMinimumArcAngleToDraw((double) (byte) -1);
        piePlot3D3.setBackgroundImageAlignment(13);
        boolean boolean8 = timeSeriesCollection1.equals((java.lang.Object) piePlot3D3);
        java.util.List list9 = timeSeriesCollection1.getSeries();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = null;
        combinedDomainXYPlot10.setFixedLegendItems(legendItemCollection11);
        java.awt.Paint paint13 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot10.setDomainGridlinePaint(paint13);
        boolean boolean15 = combinedDomainXYPlot10.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        combinedDomainXYPlot10.setDataset((int) (short) 0, xYDataset17);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.RenderingSource renderingSource22 = null;
        combinedDomainXYPlot10.select((double) 1L, (double) ' ', rectangle2D21, renderingSource22);
        org.jfree.chart.plot.PiePlot3D piePlot3D24 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean25 = piePlot3D24.getDarkerSides();
        combinedDomainXYPlot10.setParent((org.jfree.chart.plot.Plot) piePlot3D24);
        boolean boolean27 = timeSeriesCollection1.equals((java.lang.Object) piePlot3D24);
        java.lang.Object obj28 = timeSeriesCollection1.clone();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        double double6 = xYStepRenderer2.getItemLabelAnchorOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator8 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj9 = standardXYToolTipGenerator8.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator8, xYURLGenerator10);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = null;
        xYAreaRenderer11.setBaseURLGenerator(xYURLGenerator12);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator14 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        xYAreaRenderer11.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator14);
        xYStepRenderer2.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator14);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        java.lang.Object obj3 = categoryAxis1.clone();
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis5.pan(0.0d);
        double double9 = logAxis5.calculateValue(0.0d);
        boolean boolean10 = logAxis5.isTickLabelsVisible();
        logAxis5.setAutoRangeMinimumSize((double) 5, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = barRenderer14.getSeriesItemLabelGenerator(5);
        int int17 = barRenderer14.getColumnCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) logAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D23.setMinimumArcAngleToDraw((double) (byte) -1);
        double double26 = piePlot3D23.getInteriorGap();
        piePlot3D23.setDarkerSides(false);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D31 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D31.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D31.setLabelLinkStroke(stroke34);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint38.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart42 = chartChangeEvent41.getChart();
        boolean boolean43 = chartRenderingInfo37.equals((java.lang.Object) chartChangeEvent41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = chartRenderingInfo37.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState45 = piePlot3D23.initialise(graphics2D29, rectangle2D30, (org.jfree.chart.plot.PiePlot) piePlot3D31, (java.lang.Integer) 0, plotRenderingInfo44);
        java.awt.geom.Rectangle2D rectangle2D46 = plotRenderingInfo44.getDataArea();
        boolean boolean47 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 4, (double) (-398), rectangle2D46);
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset48, valueAxis49, valueAxis50, xYItemRenderer51);
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer51);
        boolean boolean54 = legendTitle53.visible;
        legendTitle53.setHeight((double) 8);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = legendTitle53.getLegendItemGraphicEdge();
        try {
            double double58 = categoryAxis1.getCategoryMiddle((-16777216), (int) (short) 0, rectangle2D46, rectangleEdge57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -16777216");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.08d + "'", double26 == 0.08d);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(rectangleConstraint38);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
        org.junit.Assert.assertNull(jFreeChart42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo44);
        org.junit.Assert.assertNotNull(piePlotState45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, Double.NaN);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.canSelectByRegion();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint8.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart12 = chartChangeEvent11.getChart();
        boolean boolean13 = chartRenderingInfo7.equals((java.lang.Object) chartChangeEvent11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo7.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        xYPlot4.panDomainAxes((double) (short) 10, plotRenderingInfo14, point2D17);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange20);
        boolean boolean22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) xYPlot4, (java.lang.Object) rectangleConstraint21);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNull(jFreeChart12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str1 = datasetGroup0.getID();
        java.lang.Object obj2 = datasetGroup0.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOID" + "'", str1.equals("NOID"));
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str3 = intervalMarker2.getLabel();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP;
        intervalMarker2.setLabelAnchor(rectangleAnchor4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator6, xYURLGenerator7);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYStepRenderer8.getBaseToolTipGenerator();
        boolean boolean10 = rectangleAnchor4.equals((java.lang.Object) xYStepRenderer8);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator11, xYURLGenerator12);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = xYStepRenderer13.getBaseToolTipGenerator();
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font16);
        xYStepRenderer13.setBaseItemLabelFont(font16);
        boolean boolean20 = xYStepRenderer13.equals((java.lang.Object) (byte) 1);
        java.awt.Stroke stroke21 = xYStepRenderer13.getBaseStroke();
        xYStepRenderer8.setBaseOutlineStroke(stroke21, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator27 = xYStepRenderer8.getToolTipGenerator(6, (-16777216), true);
        boolean boolean28 = xYStepRenderer8.getDrawOutlines();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.text.TextAnchor textAnchor32 = itemLabelPosition31.getRotationAnchor();
        xYStepRenderer8.setBaseNegativeItemLabelPosition(itemLabelPosition31);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.data.Range range35 = xYStepRenderer8.findRangeBounds(xYDataset34);
        boolean boolean36 = xYStepRenderer8.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(xYToolTipGenerator27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("30-June-2019");
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange1);
        java.lang.String str3 = dateRange1.toString();
        java.lang.String str4 = dateRange1.toString();
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str3.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str4.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYStepRenderer2.getLegendItems();
        int int4 = xYStepRenderer2.getPassCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D5.setMinimumArcAngleToDraw((double) (byte) -1);
        double double8 = piePlot3D5.getInteriorGap();
        piePlot3D5.setDarkerSides(false);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        piePlot3D5.setDataset(pieDataset11);
        java.awt.Stroke stroke13 = piePlot3D5.getBaseSectionOutlineStroke();
        xYStepRenderer2.setBaseOutlineStroke(stroke13);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.08d + "'", double8 == 0.08d);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray10, numberArray14, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset20, (double) (-2208960000000L));
        double double23 = range22.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint(range22, 100.0d);
        boolean boolean28 = range22.intersects((double) (byte) 10, (double) 9999);
        dateAxis4.setRange(range22, true, false);
        boolean boolean33 = range22.contains((-2.20896E12d));
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis35.pan(0.0d);
        double double39 = logAxis35.calculateValue(0.0d);
        boolean boolean40 = logAxis35.isTickLabelsVisible();
        org.jfree.data.time.DateRange dateRange41 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        logAxis35.setRangeWithMargins((org.jfree.data.Range) dateRange41, true, false);
        boolean boolean45 = range22.intersects((org.jfree.data.Range) dateRange41);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType46 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot47 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot47.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.Layer layer51 = null;
        java.util.Collection collection52 = combinedDomainXYPlot47.getRangeMarkers((int) (short) 1, layer51);
        combinedDomainXYPlot47.clearDomainAxes();
        boolean boolean54 = lengthConstraintType46.equals((java.lang.Object) combinedDomainXYPlot47);
        org.jfree.chart.util.LogFormat logFormat60 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator62 = logFormat60.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit64 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat60, (int) (byte) -1);
        java.awt.Font font66 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color67 = java.awt.Color.BLACK;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent68 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color67);
        org.jfree.chart.text.TextBlock textBlock69 = org.jfree.chart.text.TextUtilities.createTextBlock("", font66, (java.awt.Paint) color67);
        java.awt.Graphics2D graphics2D70 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor73 = null;
        textBlock69.draw(graphics2D70, (float) (short) 10, (float) '#', textBlockAnchor73, (float) 'a', (float) (-4767), (double) 1.0f);
        java.awt.Graphics2D graphics2D78 = null;
        org.jfree.chart.util.Size2D size2D79 = textBlock69.calculateDimensions(graphics2D78);
        int int80 = numberTickUnit64.compareTo((java.lang.Object) size2D79);
        boolean boolean81 = lengthConstraintType46.equals((java.lang.Object) size2D79);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint82 = new org.jfree.chart.block.RectangleConstraint(90.0d, range1, lengthConstraintType2, (double) 2, (org.jfree.data.Range) dateRange41, lengthConstraintType46);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-2.20896E12d) + "'", double23 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dateRange41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType46);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(attributedCharacterIterator62);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(textBlock69);
        org.junit.Assert.assertNotNull(size2D79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.TickUnit tickUnit1 = polarPlot0.getAngleTickUnit();
        org.jfree.data.xy.XYDataset xYDataset2 = polarPlot0.getDataset();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = null;
        polarPlot0.axisChanged(axisChangeEvent3);
        org.jfree.chart.axis.TickUnit tickUnit5 = polarPlot0.getAngleTickUnit();
        org.junit.Assert.assertNotNull(tickUnit1);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(tickUnit5);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        org.jfree.chart.LegendItem legendItem8 = xYStepRenderer2.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        combinedDomainXYPlot13.setFixedLegendItems(legendItemCollection14);
        java.awt.Paint paint16 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot13.setDomainGridlinePaint(paint16);
        boolean boolean18 = combinedDomainXYPlot13.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        combinedDomainXYPlot13.setDataset((int) (short) 0, xYDataset20);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.RenderingSource renderingSource25 = null;
        combinedDomainXYPlot13.select((double) 1L, (double) ' ', rectangle2D24, renderingSource25);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection27 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D28.setMinimumArcAngleToDraw((double) (byte) -1);
        double double31 = piePlot3D28.getInteriorGap();
        piePlot3D28.setDarkerSides(false);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D36.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D36.setLabelLinkStroke(stroke39);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint43.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart47 = chartChangeEvent46.getChart();
        boolean boolean48 = chartRenderingInfo42.equals((java.lang.Object) chartChangeEvent46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = chartRenderingInfo42.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState50 = piePlot3D28.initialise(graphics2D34, rectangle2D35, (org.jfree.chart.plot.PiePlot) piePlot3D36, (java.lang.Integer) 0, plotRenderingInfo49);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState51 = xYStepRenderer2.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13, (org.jfree.data.xy.XYDataset) xYSeriesCollection27, plotRenderingInfo49);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState52 = xYItemRendererState51.getSelectionState();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.08d + "'", double31 == 0.08d);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNull(jFreeChart47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo49);
        org.junit.Assert.assertNotNull(piePlotState50);
        org.junit.Assert.assertNotNull(xYItemRendererState51);
        org.junit.Assert.assertNull(xYDatasetSelectionState52);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str7 = spreadsheetDate6.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays((int) 'a', (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str15 = spreadsheetDate14.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str18 = spreadsheetDate17.toString();
        boolean boolean19 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        combinedDomainXYPlot20.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.xy.XYSeries xYSeries31 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection32 = new org.jfree.data.xy.XYSeriesCollection(xYSeries31);
        double double34 = xYSeriesCollection32.getDomainLowerBound(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection32);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot20.setDomainAxisLocation(axisLocation36);
        boolean boolean38 = spreadsheetDate14.equals((java.lang.Object) combinedDomainXYPlot20);
        boolean boolean40 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate14, 2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(13);
        int int43 = spreadsheetDate42.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(13);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate46);
        int int48 = spreadsheetDate46.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(13);
        int int51 = spreadsheetDate50.getYYYY();
        boolean boolean52 = spreadsheetDate46.isOn((org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean54 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, (org.jfree.data.time.SerialDate) spreadsheetDate50, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12-January-1900" + "'", str7.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "12-January-1900" + "'", str10.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "12-January-1900" + "'", str15.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "12-January-1900" + "'", str18.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1900 + "'", int43 == 1900);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 13 + "'", int48 == 13);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1900 + "'", int51 == 1900);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator3);
        boolean boolean5 = xYAreaRenderer4.getPlotLines();
        org.jfree.chart.block.CenterArrangement centerArrangement6 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement6.add((org.jfree.chart.block.Block) labelBlock8, (java.lang.Object) 100L);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = labelBlock8.getMargin();
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean13 = piePlot3D12.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = piePlot3D12.getLegendLabelGenerator();
        boolean boolean15 = labelBlock8.equals((java.lang.Object) piePlot3D12);
        java.awt.Paint paint16 = piePlot3D12.getNoDataMessagePaint();
        boolean boolean17 = xYAreaRenderer4.equals((java.lang.Object) piePlot3D12);
        java.awt.Paint paint18 = xYAreaRenderer4.getBaseItemLabelPaint();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str2 = spreadsheetDate1.toString();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12-January-1900" + "'", str2.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.RenderingSource renderingSource12 = null;
        combinedDomainXYPlot0.select((double) 1L, (double) ' ', rectangle2D11, renderingSource12);
        java.lang.String str14 = combinedDomainXYPlot0.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedDomainXYPlot0.getRenderer();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        combinedDomainXYPlot0.setFixedRangeAxisSpace(axisSpace16);
        java.lang.Object obj18 = null;
        boolean boolean19 = combinedDomainXYPlot0.equals(obj18);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined_Domain_XYPlot" + "'", str14.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        boolean boolean70 = combinedDomainXYPlot20.isDomainMinorGridlinesVisible();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot71 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection72 = null;
        combinedDomainXYPlot71.setFixedLegendItems(legendItemCollection72);
        java.awt.Paint paint74 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot71.setDomainGridlinePaint(paint74);
        boolean boolean76 = combinedDomainXYPlot71.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset78 = null;
        combinedDomainXYPlot71.setDataset((int) (short) 0, xYDataset78);
        java.awt.geom.Rectangle2D rectangle2D82 = null;
        org.jfree.chart.RenderingSource renderingSource83 = null;
        combinedDomainXYPlot71.select((double) 1L, (double) ' ', rectangle2D82, renderingSource83);
        boolean boolean85 = combinedDomainXYPlot20.equals((java.lang.Object) combinedDomainXYPlot71);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseCreateEntities(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getPositiveItemLabelPositionFallback();
        int int4 = barRenderer0.getRowCount();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = barRenderer0.getLegendItems();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        barRenderer0.setSeriesItemLabelGenerator(1900, categoryItemLabelGenerator7, true);
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection5);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "");
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        try {
            double double7 = timeSeriesCollection2.getYValue(100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(5);
        barRenderer0.setIncludeBaseInRange(false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem(12.0d, (double) (short) 10);
        java.lang.Number number3 = xYDataItem2.getY();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 10.0d + "'", number3.equals(10.0d));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.pan((double) (byte) -1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer3);
        boolean boolean6 = legendTitle5.visible;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle5.getPosition();
        java.awt.Color color8 = java.awt.Color.BLACK;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8);
        legendTitle5.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Color color12 = org.jfree.chart.util.PaintUtilities.stringToColor("Pie 3D Plot");
        int int13 = color12.getBlue();
        legendTitle5.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double17 = rectangleInsets15.trimWidth((double) 900000L);
        legendTitle5.setPadding(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 899992.0d + "'", double17 == 899992.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseCreateEntities(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getPositiveItemLabelPositionFallback();
        int int4 = barRenderer0.getRowCount();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray10, numberArray14, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray19);
        org.jfree.data.Range range21 = barRenderer0.findRangeBounds(categoryDataset20);
        try {
            org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset20, (java.lang.Comparable) 9.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        java.awt.Paint paint4 = piePlot3D0.getLabelPaint();
        java.lang.String str5 = piePlot3D0.getPlotType();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot3D0.setURLGenerator(pieURLGenerator6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie 3D Plot" + "'", str5.equals("Pie 3D Plot"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat4 = numberAxis1.getNumberFormatOverride();
        boolean boolean5 = numberAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        boolean boolean5 = xYPlot4.canSelectByRegion();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint8.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart12 = chartChangeEvent11.getChart();
        boolean boolean13 = chartRenderingInfo7.equals((java.lang.Object) chartChangeEvent11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo7.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        xYPlot4.panDomainAxes((double) (short) 10, plotRenderingInfo14, point2D17);
        java.awt.Image image19 = xYPlot4.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNull(jFreeChart12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertNull(image19);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        boolean boolean70 = combinedDomainXYPlot20.isDomainMinorGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis72 = combinedDomainXYPlot20.getRangeAxis(3);
        org.jfree.chart.plot.PolarPlot polarPlot74 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries75 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection76 = new org.jfree.data.time.TimeSeriesCollection(timeSeries75);
        org.jfree.data.Range range77 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection76);
        polarPlot74.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection76);
        org.jfree.chart.JFreeChart jFreeChart79 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot74);
        java.util.List list80 = jFreeChart79.getSubtitles();
        try {
            combinedDomainXYPlot20.mapDatasetToRangeAxes((int) ' ', list80);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Indices must be Integer instances.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNull(valueAxis72);
        org.junit.Assert.assertNull(range77);
        org.junit.Assert.assertNotNull(list80);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator(13, categoryToolTipGenerator2);
        java.awt.Paint paint4 = barRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation5 = null;
        boolean boolean6 = barRenderer0.removeAnnotation(categoryAnnotation5);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = barRenderer0.getPlot();
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem11.setShapeVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer14 = legendItem11.getFillPaintTransformer();
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer14);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(gradientPaintTransformer14);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart5.setTitle("12-January-1900");
        java.lang.Object obj8 = jFreeChart5.clone();
        float float9 = jFreeChart5.getBackgroundImageAlpha();
        jFreeChart5.fireChartChanged();
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart5.getTitle();
        org.jfree.chart.StandardChartTheme standardChartTheme13 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj16 = standardXYToolTipGenerator15.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, xYURLGenerator17);
        org.jfree.chart.LegendItem legendItem21 = xYAreaRenderer18.getLegendItem(12, 1);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer18.setBasePaint((java.awt.Paint) color22, true);
        standardChartTheme13.setShadowPaint((java.awt.Paint) color22);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace27 = color26.getColorSpace();
        standardChartTheme13.setDomainGridlinePaint((java.awt.Paint) color26);
        java.awt.Paint paint29 = standardChartTheme13.getGridBandAlternatePaint();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        combinedDomainXYPlot30.setFixedLegendItems(legendItemCollection31);
        java.awt.Paint paint33 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot30.setDomainGridlinePaint(paint33);
        boolean boolean35 = combinedDomainXYPlot30.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        combinedDomainXYPlot30.setDataset((int) (short) 0, xYDataset37);
        combinedDomainXYPlot30.setBackgroundImageAlignment((int) (byte) -1);
        int int41 = combinedDomainXYPlot30.getDatasetCount();
        java.awt.Paint paint42 = combinedDomainXYPlot30.getBackgroundPaint();
        standardChartTheme13.setSubtitlePaint(paint42);
        textTitle11.setPaint(paint42);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNull(legendItem21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(colorSpace27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
        timeSeries1.add(timeSeriesDataItem6, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        int int15 = month14.getYearValue();
        java.util.Date date16 = month14.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        int int18 = day17.getMonth();
        java.lang.String str19 = day17.toString();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) day17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "30-June-2019" + "'", str19.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(timeSeries20);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod2, (double) (short) 100);
        timeSeriesDataItem4.setValue((java.lang.Number) (-8.0d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.DomainOrder domainOrder1 = xYSeriesCollection0.getDomainOrder();
        try {
            java.lang.Number number4 = xYSeriesCollection0.getEndX((int) (byte) -1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(domainOrder1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray6, numberArray10, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset16);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset16, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj21 = categoryAxis20.clone();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer23.setSeriesOutlinePaint((int) (short) 10, paint25);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        combinedDomainXYPlot27.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot27.setDomainGridlinePaint(paint30);
        boolean boolean32 = combinedDomainXYPlot27.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        combinedDomainXYPlot27.setDataset((int) (short) 0, xYDataset34);
        combinedDomainXYPlot27.setBackgroundImageAlignment((int) (byte) -1);
        int int38 = combinedDomainXYPlot27.getDatasetCount();
        xYBarRenderer23.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot27);
        java.awt.Font font41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer23.setLegendTextFont((int) (short) 100, font41);
        categoryAxis20.setTickLabelFont((java.lang.Comparable) month22, font41);
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset19, (java.lang.Comparable) month22, (double) 5, 12);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int48 = month47.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod49, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeriesDataItem51.getPeriod();
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("UnitType.ABSOLUTE", (org.jfree.data.time.RegularTimePeriod) month22, regularTimePeriod52);
        periodAxis53.setMinorTickMarkOutsideLength((float) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = periodAxis53.getFirst();
        org.jfree.data.xy.XYSeries xYSeries57 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) regularTimePeriod56);
        org.jfree.data.xy.XYDataItem xYDataItem60 = xYSeries57.addOrUpdate((double) (-4767), 0.0d);
        xYSeries57.add(0.0d, (java.lang.Number) 0, false);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(pieDataset46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(xYDataItem60);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) textAnchor1, true);
        boolean boolean4 = seriesRenderingOrder0.equals((java.lang.Object) rendererChangeEvent3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        combinedDomainXYPlot0.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.xy.XYSeries xYSeries11 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection12 = new org.jfree.data.xy.XYSeriesCollection(xYSeries11);
        double double14 = xYSeriesCollection12.getDomainLowerBound(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedDomainXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection12);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot0.setDomainAxisLocation(axisLocation16);
        combinedDomainXYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj4 = standardXYToolTipGenerator3.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator5);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer6.getLegendItem(12, 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer6.setBasePaint((java.awt.Paint) color10, true);
        standardChartTheme1.setShadowPaint((java.awt.Paint) color10);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        standardChartTheme1.setPlotOutlinePaint((java.awt.Paint) color14);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection17 = null;
        combinedDomainXYPlot16.setFixedLegendItems(legendItemCollection17);
        java.awt.Paint paint19 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot16.setDomainGridlinePaint(paint19);
        boolean boolean21 = combinedDomainXYPlot16.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        combinedDomainXYPlot16.setDataset((int) (short) 0, xYDataset23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.plot.CrosshairState crosshairState29 = null;
        boolean boolean30 = combinedDomainXYPlot16.render(graphics2D25, rectangle2D26, 10, plotRenderingInfo28, crosshairState29);
        org.jfree.chart.plot.IntervalMarker intervalMarker34 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.Layer layer35 = null;
        combinedDomainXYPlot16.addRangeMarker((-4767), (org.jfree.chart.plot.Marker) intervalMarker34, layer35, true);
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem39.setSeriesIndex((int) '4');
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray47, numberArray51, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray56);
        java.lang.Number number58 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset57);
        legendItem39.setDataset((org.jfree.data.general.Dataset) categoryDataset57);
        java.awt.Stroke stroke60 = legendItem39.getOutlineStroke();
        combinedDomainXYPlot16.setRangeZeroBaselineStroke(stroke60);
        java.awt.Paint paint62 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot16.setDomainCrosshairPaint(paint62);
        standardChartTheme1.setAxisLabelPaint(paint62);
        java.awt.Color color65 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        standardChartTheme1.setItemLabelPaint((java.awt.Paint) color65);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + 1.0d + "'", number58.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(color65);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieToolTipGenerator.DEFAULT_TOOLTIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.data.function.Function2D function2D0 = null;
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod6, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        try {
            org.jfree.data.xy.XYDataset xYDataset10 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (short) -1, 0.0d, (int) (byte) -1, (java.lang.Comparable) timeSeriesDataItem8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem1.setShapeVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = legendItem1.getFillPaintTransformer();
        legendItem1.setShapeVisible(false);
        java.text.AttributedString attributedString7 = legendItem1.getAttributedLabel();
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNull(attributedString7);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) '#', "", textAnchor3, textAnchor4, (double) 6);
        java.lang.String str7 = numberTick6.getText();
        org.jfree.chart.text.TextAnchor textAnchor8 = numberTick6.getRotationAnchor();
        java.lang.String str9 = numberTick6.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setBaseCreateEntities(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer1.getPositiveItemLabelPositionFallback();
        int int5 = barRenderer1.getRowCount();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = barRenderer1.getLegendItems();
        boolean boolean7 = categoryAxis0.equals((java.lang.Object) barRenderer1);
        float float8 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("null", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        org.jfree.chart.LegendItem legendItem8 = xYStepRenderer2.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        combinedDomainXYPlot13.setFixedLegendItems(legendItemCollection14);
        java.awt.Paint paint16 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot13.setDomainGridlinePaint(paint16);
        boolean boolean18 = combinedDomainXYPlot13.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        combinedDomainXYPlot13.setDataset((int) (short) 0, xYDataset20);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.RenderingSource renderingSource25 = null;
        combinedDomainXYPlot13.select((double) 1L, (double) ' ', rectangle2D24, renderingSource25);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection27 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D28.setMinimumArcAngleToDraw((double) (byte) -1);
        double double31 = piePlot3D28.getInteriorGap();
        piePlot3D28.setDarkerSides(false);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D36.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D36.setLabelLinkStroke(stroke39);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint43.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart47 = chartChangeEvent46.getChart();
        boolean boolean48 = chartRenderingInfo42.equals((java.lang.Object) chartChangeEvent46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = chartRenderingInfo42.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState50 = piePlot3D28.initialise(graphics2D34, rectangle2D35, (org.jfree.chart.plot.PiePlot) piePlot3D36, (java.lang.Integer) 0, plotRenderingInfo49);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState51 = xYStepRenderer2.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13, (org.jfree.data.xy.XYDataset) xYSeriesCollection27, plotRenderingInfo49);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state52 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo49);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.08d + "'", double31 == 0.08d);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNull(jFreeChart47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo49);
        org.junit.Assert.assertNotNull(piePlotState50);
        org.junit.Assert.assertNotNull(xYItemRendererState51);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        combinedDomainXYPlot20.setGap((double) 12);
        combinedDomainXYPlot20.setDomainZeroBaselineVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer75 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean76 = xYBarRenderer75.isDrawBarOutline();
        java.awt.Font font78 = xYBarRenderer75.lookupLegendTextFont(3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer79 = xYBarRenderer75.getGradientPaintTransformer();
        boolean boolean83 = xYBarRenderer75.getItemCreateEntity(2019, (int) (byte) 1, false);
        combinedDomainXYPlot20.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer75, false);
        boolean boolean86 = xYBarRenderer75.isDrawBarOutline();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(font78);
        org.junit.Assert.assertNotNull(gradientPaintTransformer79);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj4 = standardXYToolTipGenerator3.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator5);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer6.getLegendItem(12, 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer6.setBasePaint((java.awt.Paint) color10, true);
        standardChartTheme1.setShadowPaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter17 = new org.jfree.chart.renderer.category.GradientBarPainter(4.0d, (double) (byte) 10, 0.0d);
        standardChartTheme1.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter17);
        java.awt.Paint paint19 = standardChartTheme1.getTitlePaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator20 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator21 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer22 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator20, xYURLGenerator21);
        java.awt.Paint paint23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer22.setBaseFillPaint(paint23);
        standardChartTheme1.setPlotBackgroundPaint(paint23);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str7 = spreadsheetDate6.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays((int) 'a', (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str15 = spreadsheetDate14.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str18 = spreadsheetDate17.toString();
        boolean boolean19 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        combinedDomainXYPlot20.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.xy.XYSeries xYSeries31 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection32 = new org.jfree.data.xy.XYSeriesCollection(xYSeries31);
        double double34 = xYSeriesCollection32.getDomainLowerBound(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection32);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot20.setDomainAxisLocation(axisLocation36);
        boolean boolean38 = spreadsheetDate14.equals((java.lang.Object) combinedDomainXYPlot20);
        boolean boolean40 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate14, 2);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12-January-1900" + "'", str7.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "12-January-1900" + "'", str10.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "12-January-1900" + "'", str15.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "12-January-1900" + "'", str18.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D8.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D8.setLabelLinkStroke(stroke11);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint15.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart19 = chartChangeEvent18.getChart();
        boolean boolean20 = chartRenderingInfo14.equals((java.lang.Object) chartChangeEvent18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo14.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState22 = piePlot3D0.initialise(graphics2D6, rectangle2D7, (org.jfree.chart.plot.PiePlot) piePlot3D8, (java.lang.Integer) 0, plotRenderingInfo21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot3D0.setBaseSectionOutlinePaint((java.awt.Paint) color23);
        piePlot3D0.setCircular(false, false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNull(jFreeChart19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(piePlotState22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("Rotation.ANTICLOCKWISE", strArray1);
        java.awt.Paint paint3 = symbolAxis2.getGridBandAlternatePaint();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj4 = standardXYToolTipGenerator3.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator5);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer6.getLegendItem(12, 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer6.setBasePaint((java.awt.Paint) color10, true);
        standardChartTheme1.setShadowPaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter17 = new org.jfree.chart.renderer.category.GradientBarPainter(4.0d, (double) (byte) 10, 0.0d);
        standardChartTheme1.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter17);
        java.awt.Paint paint19 = standardChartTheme1.getThermometerPaint();
        java.awt.Font font20 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        standardChartTheme1.setExtraLargeFont(font20);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj1 = categoryPlot0.clone();
        java.lang.String str2 = categoryPlot0.getPlotType();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Category Plot" + "'", str2.equals("Category Plot"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) -1);
        java.lang.Object obj2 = xYStepAreaRenderer1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace3);
        categoryPlot0.setAnchorValue(56.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj1 = categoryPlot0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace2, true);
        categoryPlot0.setRangeMinorGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getDomainAxisLocation((int) 'a');
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        java.lang.String str3 = textAnchor1.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.HALF_ASCENT_LEFT" + "'", str3.equals("TextAnchor.HALF_ASCENT_LEFT"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        piePlot3D0.setStartAngle((double) (byte) -1);
        piePlot3D0.setShadowYOffset((double) (short) 100);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        piePlot3D0.setLegendLabelURLGenerator(pieURLGenerator7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D0);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D(pieDataset11);
        java.awt.Stroke stroke13 = piePlot3D12.getLabelOutlineStroke();
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) "hi!", stroke13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer16.getPositiveItemLabelPositionFallback();
        java.awt.Shape shape19 = barRenderer16.getSeriesShape(13);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = null;
        combinedDomainXYPlot22.setFixedLegendItems(legendItemCollection23);
        java.awt.Paint paint25 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot22.setDomainGridlinePaint(paint25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = combinedDomainXYPlot22.getRenderer();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = combinedDomainXYPlot22.getRangeAxisEdge();
        org.jfree.chart.axis.LogAxis logAxis30 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis30.pan(0.0d);
        double double34 = logAxis30.calculateValue(0.0d);
        combinedDomainXYPlot22.setRangeAxis((org.jfree.chart.axis.ValueAxis) logAxis30);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer39 = null;
        intervalMarker38.setGradientPaintTransformer(gradientPaintTransformer39);
        org.jfree.chart.text.TextAnchor textAnchor41 = intervalMarker38.getLabelTextAnchor();
        org.jfree.chart.plot.PiePlot3D piePlot3D44 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D44.setMinimumArcAngleToDraw((double) (byte) -1);
        double double47 = piePlot3D44.getInteriorGap();
        piePlot3D44.setDarkerSides(false);
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D52 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D52.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D52.setLabelLinkStroke(stroke55);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint61 = rectangleConstraint59.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent62 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart63 = chartChangeEvent62.getChart();
        boolean boolean64 = chartRenderingInfo58.equals((java.lang.Object) chartChangeEvent62);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = chartRenderingInfo58.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState66 = piePlot3D44.initialise(graphics2D50, rectangle2D51, (org.jfree.chart.plot.PiePlot) piePlot3D52, (java.lang.Integer) 0, plotRenderingInfo65);
        java.awt.geom.Rectangle2D rectangle2D67 = plotRenderingInfo65.getDataArea();
        boolean boolean68 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 4, (double) (-398), rectangle2D67);
        barRenderer16.drawRangeMarker(graphics2D20, categoryPlot21, (org.jfree.chart.axis.ValueAxis) logAxis30, (org.jfree.chart.plot.Marker) intervalMarker38, rectangle2D67);
        try {
            piePlot3D0.drawBackground(graphics2D15, rectangle2D67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(itemLabelPosition17);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.08d + "'", double47 == 0.08d);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(rectangleConstraint59);
        org.junit.Assert.assertNotNull(rectangleConstraint61);
        org.junit.Assert.assertNull(jFreeChart63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo65);
        org.junit.Assert.assertNotNull(piePlotState66);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setMinimumArcAngleToDraw((double) (byte) -1);
        double double7 = piePlot3D4.getInteriorGap();
        piePlot3D4.setDarkerSides(false);
        piePlot3D4.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean13 = piePlot3D12.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = piePlot3D12.getLegendLabelGenerator();
        piePlot3D4.setLegendLabelGenerator(pieSectionLabelGenerator14);
        java.awt.Shape shape16 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries18 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection(timeSeries18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection19);
        polarPlot17.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection19);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot17);
        java.util.List list23 = jFreeChart22.getSubtitles();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity24 = new org.jfree.chart.entity.JFreeChartEntity(shape16, jFreeChart22);
        java.awt.Paint paint25 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("Last", "HorizontalAlignment.CENTER", "Pie 3D Plot", "", shape16, paint25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("hi!�");
        java.awt.Paint paint29 = logAxis28.getTickLabelPaint();
        org.jfree.chart.entity.AxisEntity axisEntity31 = new org.jfree.chart.entity.AxisEntity(shape16, (org.jfree.chart.axis.Axis) logAxis28, "UnitType.ABSOLUTE");
        java.lang.Object obj32 = axisEntity31.clone();
        java.lang.String str33 = axisEntity31.getToolTipText();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "UnitType.ABSOLUTE" + "'", str33.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        piePlot3D0.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean9 = piePlot3D8.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        java.awt.Shape shape12 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.plot.Plot plot13 = piePlot3D0.getRootPlot();
        java.awt.Paint paint15 = piePlot3D0.getSectionOutlinePaint((java.lang.Comparable) "12-January-1900");
        java.awt.Stroke stroke16 = piePlot3D0.getLabelLinkStroke();
        boolean boolean17 = piePlot3D0.getAutoPopulateSectionPaint();
        piePlot3D0.clearSectionOutlinePaints(false);
        piePlot3D0.setShadowYOffset(0.14d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(plot13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat4 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator12 = logFormat10.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat10, (int) (byte) -1);
        numberAxis1.setTickUnit(numberTickUnit14);
        java.text.NumberFormat numberFormat16 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertNotNull(attributedCharacterIterator12);
        org.junit.Assert.assertNull(numberFormat16);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.valueToJava2D(3.0d, rectangle2D2, rectangleEdge3);
        dateAxis0.setRange((double) (byte) -1, 0.025d);
        dateAxis0.centerRange((double) (-1));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        org.jfree.chart.LegendItem legendItem8 = xYStepRenderer2.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        combinedDomainXYPlot13.setFixedLegendItems(legendItemCollection14);
        java.awt.Paint paint16 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot13.setDomainGridlinePaint(paint16);
        boolean boolean18 = combinedDomainXYPlot13.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        combinedDomainXYPlot13.setDataset((int) (short) 0, xYDataset20);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.RenderingSource renderingSource25 = null;
        combinedDomainXYPlot13.select((double) 1L, (double) ' ', rectangle2D24, renderingSource25);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection27 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D28.setMinimumArcAngleToDraw((double) (byte) -1);
        double double31 = piePlot3D28.getInteriorGap();
        piePlot3D28.setDarkerSides(false);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D36.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D36.setLabelLinkStroke(stroke39);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint43.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart47 = chartChangeEvent46.getChart();
        boolean boolean48 = chartRenderingInfo42.equals((java.lang.Object) chartChangeEvent46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = chartRenderingInfo42.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState50 = piePlot3D28.initialise(graphics2D34, rectangle2D35, (org.jfree.chart.plot.PiePlot) piePlot3D36, (java.lang.Integer) 0, plotRenderingInfo49);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState51 = xYStepRenderer2.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13, (org.jfree.data.xy.XYDataset) xYSeriesCollection27, plotRenderingInfo49);
        org.jfree.data.Range range53 = xYSeriesCollection27.getRangeBounds(false);
        java.util.List list54 = xYSeriesCollection27.getSeries();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.08d + "'", double31 == 0.08d);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNull(jFreeChart47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo49);
        org.junit.Assert.assertNotNull(piePlotState50);
        org.junit.Assert.assertNotNull(xYItemRendererState51);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(list54);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        float float5 = xYPlot4.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) '#', "", textAnchor3, textAnchor4, (double) 6);
        java.lang.String str7 = numberTick6.getText();
        org.jfree.chart.text.TextAnchor textAnchor8 = numberTick6.getRotationAnchor();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) numberTick6);
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator(13, categoryToolTipGenerator2);
        java.awt.Paint paint4 = barRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation5 = null;
        boolean boolean6 = barRenderer0.removeAnnotation(categoryAnnotation5);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator7);
        barRenderer0.removeAnnotations();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator10, false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        timeSeriesCollection1.clearSelection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor4 = timeSeriesCollection1.getXPosition();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(timePeriodAnchor4);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        int int6 = combinedDomainXYPlot0.getSeriesCount();
        combinedDomainXYPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.plot.Plot plot11 = combinedDomainXYPlot0.getParent();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(plot11);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("ERROR : Relative To String", 9999, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj1 = categoryPlot0.clone();
        boolean boolean2 = categoryPlot0.isDomainPannable();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = null;
        combinedDomainXYPlot3.setFixedLegendItems(legendItemCollection4);
        java.awt.Paint paint6 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot3.setDomainGridlinePaint(paint6);
        boolean boolean8 = combinedDomainXYPlot3.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        combinedDomainXYPlot3.setDataset((int) (short) 0, xYDataset10);
        combinedDomainXYPlot3.setBackgroundImageAlignment((int) (byte) -1);
        int int14 = combinedDomainXYPlot3.getDatasetCount();
        java.awt.Paint paint15 = combinedDomainXYPlot3.getBackgroundPaint();
        categoryPlot0.setDomainCrosshairPaint(paint15);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.valueToJava2D(3.0d, rectangle2D2, rectangleEdge3);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = null;
        combinedDomainXYPlot5.setFixedLegendItems(legendItemCollection6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.CrosshairState crosshairState12 = null;
        boolean boolean13 = combinedDomainXYPlot5.render(graphics2D8, rectangle2D9, (int) 'a', plotRenderingInfo11, crosshairState12);
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot5);
        org.jfree.chart.plot.PiePlot3D piePlot3D18 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D18.setMinimumArcAngleToDraw((double) (byte) -1);
        double double21 = piePlot3D18.getInteriorGap();
        piePlot3D18.setDarkerSides(false);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D26 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D26.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D26.setLabelLinkStroke(stroke29);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = rectangleConstraint33.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart37 = chartChangeEvent36.getChart();
        boolean boolean38 = chartRenderingInfo32.equals((java.lang.Object) chartChangeEvent36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = chartRenderingInfo32.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState40 = piePlot3D18.initialise(graphics2D24, rectangle2D25, (org.jfree.chart.plot.PiePlot) piePlot3D26, (java.lang.Integer) 0, plotRenderingInfo39);
        java.awt.geom.Rectangle2D rectangle2D41 = plotRenderingInfo39.getDataArea();
        boolean boolean42 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 4, (double) (-398), rectangle2D41);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double44 = dateAxis0.valueToJava2D((double) 1900, rectangle2D41, rectangleEdge43);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.08d + "'", double21 == 0.08d);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleConstraint33);
        org.junit.Assert.assertNotNull(rectangleConstraint35);
        org.junit.Assert.assertNull(jFreeChart37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo39);
        org.junit.Assert.assertNotNull(piePlotState40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter(899992.0d, (double) (-4767), (double) 100.0f);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean5 = xYBarRenderer4.isDrawBarOutline();
        java.awt.Font font7 = xYBarRenderer4.lookupLegendTextFont(3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = xYBarRenderer4.getGradientPaintTransformer();
        boolean boolean12 = xYBarRenderer4.getItemCreateEntity(2019, (int) (byte) 1, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean14 = xYBarRenderer13.isDrawBarOutline();
        xYBarRenderer13.setBaseCreateEntities(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYBarRenderer13.getNegativeItemLabelPosition(255, (-4767), false);
        xYBarRenderer4.setBasePositiveItemLabelPosition(itemLabelPosition20, false);
        boolean boolean23 = gradientBarPainter3.equals((java.lang.Object) itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertNotNull(gradientPaintTransformer8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray6, numberArray10, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset16);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset16, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj21 = categoryAxis20.clone();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer23.setSeriesOutlinePaint((int) (short) 10, paint25);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        combinedDomainXYPlot27.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot27.setDomainGridlinePaint(paint30);
        boolean boolean32 = combinedDomainXYPlot27.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        combinedDomainXYPlot27.setDataset((int) (short) 0, xYDataset34);
        combinedDomainXYPlot27.setBackgroundImageAlignment((int) (byte) -1);
        int int38 = combinedDomainXYPlot27.getDatasetCount();
        xYBarRenderer23.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot27);
        java.awt.Font font41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer23.setLegendTextFont((int) (short) 100, font41);
        categoryAxis20.setTickLabelFont((java.lang.Comparable) month22, font41);
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset19, (java.lang.Comparable) month22, (double) 5, 12);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int48 = month47.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod49, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeriesDataItem51.getPeriod();
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("UnitType.ABSOLUTE", (org.jfree.data.time.RegularTimePeriod) month22, regularTimePeriod52);
        java.lang.Number number54 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod52, number54);
        timeSeriesDataItem55.setValue((java.lang.Number) 1.0d);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(pieDataset46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.RenderingSource renderingSource12 = null;
        combinedDomainXYPlot0.select((double) 1L, (double) ' ', rectangle2D11, renderingSource12);
        java.lang.String str14 = combinedDomainXYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset16 = combinedDomainXYPlot0.getDataset((int) (short) 1);
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean19 = logAxis18.isInverted();
        logAxis18.resizeRange(0.0d);
        org.jfree.data.Range range22 = combinedDomainXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis18);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray30 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray31 = color25.getRGBColorComponents(floatArray30);
        int int32 = color25.getAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker33 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, (double) (-2208960000000L), (java.awt.Paint) color25);
        combinedDomainXYPlot0.setDomainMinorGridlinePaint((java.awt.Paint) color25);
        java.awt.Stroke stroke35 = combinedDomainXYPlot0.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined_Domain_XYPlot" + "'", str14.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 255 + "'", int32 == 255);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        boolean boolean70 = combinedDomainXYPlot20.isDomainMinorGridlinesVisible();
        java.awt.Stroke stroke71 = combinedDomainXYPlot20.getDomainGridlineStroke();
        java.awt.Stroke stroke72 = combinedDomainXYPlot20.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(stroke72);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        int int6 = combinedDomainXYPlot0.getSeriesCount();
        int int7 = combinedDomainXYPlot0.getBackgroundImageAlignment();
        combinedDomainXYPlot0.clearRangeAxes();
        combinedDomainXYPlot0.setOutlineVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        combinedDomainXYPlot0.setOrientation(plotOrientation11);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(plotOrientation11);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        java.lang.Object obj2 = categoryAxis0.clone();
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart5.setTitle("12-January-1900");
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart5.getLegend(2958465);
        org.jfree.chart.event.ChartProgressListener chartProgressListener10 = null;
        jFreeChart5.removeProgressListener(chartProgressListener10);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(legendTitle9);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer8);
        boolean boolean11 = legendTitle10.visible;
        legendTitle10.setHeight((double) 8);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle10.getLegendItemGraphicEdge();
        org.jfree.chart.axis.AxisState axisState15 = null;
        categoryAxis0.drawTickMarks(graphics2D2, (double) ' ', rectangle2D4, rectangleEdge14, axisState15);
        categoryAxis0.setAxisLineVisible(true);
        java.awt.Font font20 = categoryAxis0.getTickLabelFont((java.lang.Comparable) "hi!");
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer3);
        boolean boolean6 = legendTitle5.visible;
        java.awt.Font font7 = legendTitle5.getItemFont();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        legendTitle5.setBackgroundPaint((java.awt.Paint) color8);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray14);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset15, (double) (-2208960000000L));
        double double18 = range17.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(range17, 100.0d);
        org.jfree.data.Range range21 = rectangleConstraint20.getHeightRange();
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-2.20896E12d) + "'", double18 == (-2.20896E12d));
        org.junit.Assert.assertNull(range21);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        java.lang.String str1 = tickType0.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAJOR" + "'", str1.equals("MAJOR"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Object obj1 = defaultKeyedValues0.clone();
        java.lang.Object obj2 = defaultKeyedValues0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.valueToJava2D(3.0d, rectangle2D2, rectangleEdge3);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = null;
        combinedDomainXYPlot5.setFixedLegendItems(legendItemCollection6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.CrosshairState crosshairState12 = null;
        boolean boolean13 = combinedDomainXYPlot5.render(graphics2D8, rectangle2D9, (int) 'a', plotRenderingInfo11, crosshairState12);
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot5);
        double double15 = combinedDomainXYPlot5.getRangeCrosshairValue();
        combinedDomainXYPlot5.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer7 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator5, xYURLGenerator6);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer7.setBaseItemLabelPaint(paint8, false);
        org.jfree.chart.LegendItem legendItem13 = xYStepRenderer7.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer7.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = null;
        combinedDomainXYPlot18.setFixedLegendItems(legendItemCollection19);
        java.awt.Paint paint21 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot18.setDomainGridlinePaint(paint21);
        boolean boolean23 = combinedDomainXYPlot18.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        combinedDomainXYPlot18.setDataset((int) (short) 0, xYDataset25);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.RenderingSource renderingSource30 = null;
        combinedDomainXYPlot18.select((double) 1L, (double) ' ', rectangle2D29, renderingSource30);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection32 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D33.setMinimumArcAngleToDraw((double) (byte) -1);
        double double36 = piePlot3D33.getInteriorGap();
        piePlot3D33.setDarkerSides(false);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D41 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D41.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D41.setLabelLinkStroke(stroke44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = rectangleConstraint48.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent51 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart52 = chartChangeEvent51.getChart();
        boolean boolean53 = chartRenderingInfo47.equals((java.lang.Object) chartChangeEvent51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = chartRenderingInfo47.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState55 = piePlot3D33.initialise(graphics2D39, rectangle2D40, (org.jfree.chart.plot.PiePlot) piePlot3D41, (java.lang.Integer) 0, plotRenderingInfo54);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState56 = xYStepRenderer7.initialise(graphics2D16, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot18, (org.jfree.data.xy.XYDataset) xYSeriesCollection32, plotRenderingInfo54);
        timeSeriesCollection1.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection32);
        org.jfree.chart.axis.LogAxis logAxis59 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis59.pan(0.0d);
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.axis.AxisState axisState63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = null;
        java.util.List list66 = logAxis59.refreshTicks(graphics2D62, axisState63, rectangle2D64, rectangleEdge65);
        org.jfree.data.Range range68 = timeSeriesCollection1.getDomainBounds(list66, true);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState69 = timeSeriesCollection1.getSelectionState();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.08d + "'", double36 == 0.08d);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
        org.junit.Assert.assertNotNull(rectangleConstraint50);
        org.junit.Assert.assertNull(jFreeChart52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo54);
        org.junit.Assert.assertNotNull(piePlotState55);
        org.junit.Assert.assertNotNull(xYItemRendererState56);
        org.junit.Assert.assertNotNull(list66);
        org.junit.Assert.assertNull(range68);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState69);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        double double3 = rectangleInsets1.trimHeight((double) '#');
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 33.0d + "'", double3 == 33.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = null;
        combinedDomainXYPlot5.setFixedLegendItems(legendItemCollection6);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot5.setDomainGridlinePaint(paint8);
        boolean boolean10 = combinedDomainXYPlot5.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        combinedDomainXYPlot5.setDataset((int) (short) 0, xYDataset12);
        combinedDomainXYPlot5.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = combinedDomainXYPlot5.getDatasetRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = combinedDomainXYPlot5.removeDomainMarker(12, (org.jfree.chart.plot.Marker) intervalMarker20, layer21);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot4.setRenderer(xYItemRenderer24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot4.setRangeAxisLocation(2019, axisLocation27);
        org.jfree.chart.StandardChartTheme standardChartTheme30 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator32 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj33 = standardXYToolTipGenerator32.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator34 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer35 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator32, xYURLGenerator34);
        org.jfree.chart.LegendItem legendItem38 = xYAreaRenderer35.getLegendItem(12, 1);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer35.setBasePaint((java.awt.Paint) color39, true);
        standardChartTheme30.setShadowPaint((java.awt.Paint) color39);
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace44 = color43.getColorSpace();
        standardChartTheme30.setDomainGridlinePaint((java.awt.Paint) color43);
        java.awt.Paint paint46 = standardChartTheme30.getPlotBackgroundPaint();
        boolean boolean47 = xYPlot4.equals((java.lang.Object) paint46);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNull(legendItem38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(colorSpace44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYStepRenderer2.getLegendItems();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = xYStepRenderer2.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator4);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        piePlot3D0.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean9 = piePlot3D8.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        java.awt.Shape shape12 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        polarPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot13);
        java.util.List list19 = jFreeChart18.getSubtitles();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity20 = new org.jfree.chart.entity.JFreeChartEntity(shape12, jFreeChart18);
        boolean boolean22 = jFreeChartEntity20.equals((java.lang.Object) (-4767));
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean24 = xYBarRenderer23.isDrawBarOutline();
        java.awt.Font font26 = xYBarRenderer23.lookupLegendTextFont(3);
        boolean boolean27 = jFreeChartEntity20.equals((java.lang.Object) xYBarRenderer23);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            categoryPlot0.addDomainMarker(255, categoryMarker3, layer4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer6.setSeriesOutlinePaint((int) (short) 10, paint8);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = null;
        combinedDomainXYPlot10.setFixedLegendItems(legendItemCollection11);
        java.awt.Paint paint13 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot10.setDomainGridlinePaint(paint13);
        boolean boolean15 = combinedDomainXYPlot10.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        combinedDomainXYPlot10.setDataset((int) (short) 0, xYDataset17);
        combinedDomainXYPlot10.setBackgroundImageAlignment((int) (byte) -1);
        int int21 = combinedDomainXYPlot10.getDatasetCount();
        xYBarRenderer6.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot10);
        xYBarRenderer6.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = null;
        combinedDomainXYPlot26.setFixedLegendItems(legendItemCollection27);
        java.awt.Paint paint29 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot26.setDomainGridlinePaint(paint29);
        boolean boolean31 = combinedDomainXYPlot26.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        combinedDomainXYPlot26.setDataset((int) (short) 0, xYDataset33);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.RenderingSource renderingSource38 = null;
        combinedDomainXYPlot26.select((double) 1L, (double) ' ', rectangle2D37, renderingSource38);
        java.lang.String str40 = combinedDomainXYPlot26.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = combinedDomainXYPlot26.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray52 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray56 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray57 = new java.lang.Number[][] { numberArray48, numberArray52, numberArray56 };
        org.jfree.data.category.CategoryDataset categoryDataset58 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray57);
        org.jfree.data.Range range60 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset58, (double) (-2208960000000L));
        double double61 = range60.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint63 = new org.jfree.chart.block.RectangleConstraint(range60, 100.0d);
        boolean boolean66 = range60.intersects((double) (byte) 10, (double) 9999);
        dateAxis42.setRange(range60, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker72 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str73 = intervalMarker72.getLabel();
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        xYBarRenderer6.drawRangeMarker(graphics2D25, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot26, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.plot.Marker) intervalMarker72, rectangle2D74);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier76 = combinedDomainXYPlot26.getDrawingSupplier();
        combinedDomainXYPlot0.setDrawingSupplier(drawingSupplier76);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Combined_Domain_XYPlot" + "'", str40.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer41);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(categoryDataset58);
        org.junit.Assert.assertNotNull(range60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + (-2.20896E12d) + "'", double61 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertNotNull(drawingSupplier76);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        org.jfree.chart.LegendItem legendItem8 = xYStepRenderer2.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        combinedDomainXYPlot13.setFixedLegendItems(legendItemCollection14);
        java.awt.Paint paint16 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot13.setDomainGridlinePaint(paint16);
        boolean boolean18 = combinedDomainXYPlot13.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        combinedDomainXYPlot13.setDataset((int) (short) 0, xYDataset20);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.RenderingSource renderingSource25 = null;
        combinedDomainXYPlot13.select((double) 1L, (double) ' ', rectangle2D24, renderingSource25);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection27 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D28.setMinimumArcAngleToDraw((double) (byte) -1);
        double double31 = piePlot3D28.getInteriorGap();
        piePlot3D28.setDarkerSides(false);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D36.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D36.setLabelLinkStroke(stroke39);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint43.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart47 = chartChangeEvent46.getChart();
        boolean boolean48 = chartRenderingInfo42.equals((java.lang.Object) chartChangeEvent46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = chartRenderingInfo42.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState50 = piePlot3D28.initialise(graphics2D34, rectangle2D35, (org.jfree.chart.plot.PiePlot) piePlot3D36, (java.lang.Integer) 0, plotRenderingInfo49);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState51 = xYStepRenderer2.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13, (org.jfree.data.xy.XYDataset) xYSeriesCollection27, plotRenderingInfo49);
        boolean boolean52 = xYSeriesCollection27.isAutoWidth();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.08d + "'", double31 == 0.08d);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNull(jFreeChart47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo49);
        org.junit.Assert.assertNotNull(piePlotState50);
        org.junit.Assert.assertNotNull(xYItemRendererState51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray6, numberArray10, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset16);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset16, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj21 = categoryAxis20.clone();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer23.setSeriesOutlinePaint((int) (short) 10, paint25);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        combinedDomainXYPlot27.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot27.setDomainGridlinePaint(paint30);
        boolean boolean32 = combinedDomainXYPlot27.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        combinedDomainXYPlot27.setDataset((int) (short) 0, xYDataset34);
        combinedDomainXYPlot27.setBackgroundImageAlignment((int) (byte) -1);
        int int38 = combinedDomainXYPlot27.getDatasetCount();
        xYBarRenderer23.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot27);
        java.awt.Font font41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer23.setLegendTextFont((int) (short) 100, font41);
        categoryAxis20.setTickLabelFont((java.lang.Comparable) month22, font41);
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset19, (java.lang.Comparable) month22, (double) 5, 12);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int48 = month47.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod49, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeriesDataItem51.getPeriod();
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("UnitType.ABSOLUTE", (org.jfree.data.time.RegularTimePeriod) month22, regularTimePeriod52);
        periodAxis53.setMinorTickMarkOutsideLength((float) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = periodAxis53.getFirst();
        org.jfree.data.xy.XYSeries xYSeries57 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) regularTimePeriod56);
        org.jfree.data.xy.XYDataItem xYDataItem60 = xYSeries57.addOrUpdate((double) (-4767), 0.0d);
        java.lang.Number number62 = null;
        org.jfree.data.xy.XYDataItem xYDataItem63 = xYSeries57.addOrUpdate((java.lang.Number) 100, number62);
        xYSeries57.add(0.0d, (java.lang.Number) 0.5d);
        double double67 = xYSeries57.getMinY();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.0d + "'", number17.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(pieDataset46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(xYDataItem60);
        org.junit.Assert.assertNull(xYDataItem63);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        java.util.List list8 = logAxis1.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge7);
        double double9 = logAxis1.getAutoRangeMinimumSize();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        logAxis1.setLabelInsets(rectangleInsets10, false);
        int int13 = logAxis1.getMinorTickCount();
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-8d + "'", double9 == 1.0E-8d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        combinedDomainXYPlot4.setRenderer(xYItemRenderer7);
        java.awt.geom.GeneralPath generalPath9 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D10.setMinimumArcAngleToDraw((double) (byte) -1);
        double double13 = piePlot3D10.getInteriorGap();
        piePlot3D10.setDarkerSides(false);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D18 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D18.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D18.setLabelLinkStroke(stroke21);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint25.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart29 = chartChangeEvent28.getChart();
        boolean boolean30 = chartRenderingInfo24.equals((java.lang.Object) chartChangeEvent28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = chartRenderingInfo24.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState32 = piePlot3D10.initialise(graphics2D16, rectangle2D17, (org.jfree.chart.plot.PiePlot) piePlot3D18, (java.lang.Integer) 0, plotRenderingInfo31);
        java.awt.geom.Rectangle2D rectangle2D33 = plotRenderingInfo31.getDataArea();
        org.jfree.chart.RenderingSource renderingSource34 = null;
        combinedDomainXYPlot4.select(generalPath9, rectangle2D33, renderingSource34);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.StandardChartTheme standardChartTheme38 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator40 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj41 = standardXYToolTipGenerator40.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator42 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer43 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator40, xYURLGenerator42);
        org.jfree.chart.LegendItem legendItem46 = xYAreaRenderer43.getLegendItem(12, 1);
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer43.setBasePaint((java.awt.Paint) color47, true);
        standardChartTheme38.setShadowPaint((java.awt.Paint) color47);
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter54 = new org.jfree.chart.renderer.category.GradientBarPainter(4.0d, (double) (byte) 10, 0.0d);
        standardChartTheme38.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter54);
        java.awt.Paint paint56 = standardChartTheme38.getThermometerPaint();
        org.jfree.chart.plot.PiePlot3D piePlot3D57 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D57.setMinimumArcAngleToDraw((double) (byte) -1);
        double double60 = piePlot3D57.getInteriorGap();
        java.awt.Paint paint61 = piePlot3D57.getLabelPaint();
        standardChartTheme38.setPlotOutlinePaint(paint61);
        try {
            org.jfree.chart.LegendItem legendItem63 = new org.jfree.chart.LegendItem(attributedString0, "", "DomainOrder.ASCENDING", "June 2019", (java.awt.Shape) rectangle2D33, stroke36, paint61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.08d + "'", double13 == 0.08d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertNull(jFreeChart29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo31);
        org.junit.Assert.assertNotNull(piePlotState32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNull(legendItem46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.08d + "'", double60 == 0.08d);
        org.junit.Assert.assertNotNull(paint61);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer3.setSeriesOutlinePaint((int) (short) 10, paint5);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        combinedDomainXYPlot7.setFixedLegendItems(legendItemCollection8);
        java.awt.Paint paint10 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot7.setDomainGridlinePaint(paint10);
        boolean boolean12 = combinedDomainXYPlot7.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        combinedDomainXYPlot7.setDataset((int) (short) 0, xYDataset14);
        combinedDomainXYPlot7.setBackgroundImageAlignment((int) (byte) -1);
        int int18 = combinedDomainXYPlot7.getDatasetCount();
        xYBarRenderer3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot7);
        java.awt.Font font21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer3.setLegendTextFont((int) (short) 100, font21);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) month2, font21);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot24.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        combinedDomainXYPlot27.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot27.setDomainGridlinePaint(paint30);
        boolean boolean32 = combinedDomainXYPlot27.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        combinedDomainXYPlot27.setDataset((int) (short) 0, xYDataset34);
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.RenderingSource renderingSource39 = null;
        combinedDomainXYPlot27.select((double) 1L, (double) ' ', rectangle2D38, renderingSource39);
        java.lang.String str41 = combinedDomainXYPlot27.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset43 = combinedDomainXYPlot27.getDataset((int) (short) 1);
        org.jfree.chart.axis.LogAxis logAxis45 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean46 = logAxis45.isInverted();
        logAxis45.resizeRange(0.0d);
        org.jfree.data.Range range49 = combinedDomainXYPlot27.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis45);
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray57 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray58 = color52.getRGBColorComponents(floatArray57);
        int int59 = color52.getAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker60 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, (double) (-2208960000000L), (java.awt.Paint) color52);
        combinedDomainXYPlot27.setDomainMinorGridlinePaint((java.awt.Paint) color52);
        combinedDomainXYPlot24.setNoDataMessagePaint((java.awt.Paint) color52);
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color52);
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace65 = color64.getColorSpace();
        java.awt.Color color66 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray71 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray72 = color66.getRGBColorComponents(floatArray71);
        float[] floatArray73 = color52.getComponents(colorSpace65, floatArray72);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Combined_Domain_XYPlot" + "'", str41.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYDataset43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 255 + "'", int59 == 255);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(colorSpace65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(floatArray71);
        org.junit.Assert.assertNotNull(floatArray72);
        org.junit.Assert.assertNotNull(floatArray73);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray6, numberArray10, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset16, (double) (-2208960000000L));
        double double19 = range18.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range18, 100.0d);
        boolean boolean24 = range18.intersects((double) (byte) 10, (double) 9999);
        dateAxis0.setRange(range18, true, false);
        boolean boolean29 = range18.contains((-2.20896E12d));
        org.jfree.chart.axis.LogAxis logAxis31 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis31.pan(0.0d);
        double double35 = logAxis31.calculateValue(0.0d);
        boolean boolean36 = logAxis31.isTickLabelsVisible();
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        logAxis31.setRangeWithMargins((org.jfree.data.Range) dateRange37, true, false);
        boolean boolean41 = range18.intersects((org.jfree.data.Range) dateRange37);
        java.lang.String str42 = dateRange37.toString();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-2.20896E12d) + "'", double19 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateRange37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str42.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot0.getRenderer();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = combinedDomainXYPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.LogAxis logAxis8 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis8.pan(0.0d);
        double double12 = logAxis8.calculateValue(0.0d);
        combinedDomainXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) logAxis8);
        java.awt.Paint paint14 = combinedDomainXYPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getToolTipGenerator(6, 6, false);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        org.jfree.chart.LegendItem legendItem8 = xYStepRenderer2.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        combinedDomainXYPlot13.setFixedLegendItems(legendItemCollection14);
        java.awt.Paint paint16 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot13.setDomainGridlinePaint(paint16);
        boolean boolean18 = combinedDomainXYPlot13.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        combinedDomainXYPlot13.setDataset((int) (short) 0, xYDataset20);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.RenderingSource renderingSource25 = null;
        combinedDomainXYPlot13.select((double) 1L, (double) ' ', rectangle2D24, renderingSource25);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection27 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D28.setMinimumArcAngleToDraw((double) (byte) -1);
        double double31 = piePlot3D28.getInteriorGap();
        piePlot3D28.setDarkerSides(false);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D36.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D36.setLabelLinkStroke(stroke39);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint43.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart47 = chartChangeEvent46.getChart();
        boolean boolean48 = chartRenderingInfo42.equals((java.lang.Object) chartChangeEvent46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = chartRenderingInfo42.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState50 = piePlot3D28.initialise(graphics2D34, rectangle2D35, (org.jfree.chart.plot.PiePlot) piePlot3D36, (java.lang.Integer) 0, plotRenderingInfo49);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState51 = xYStepRenderer2.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13, (org.jfree.data.xy.XYDataset) xYSeriesCollection27, plotRenderingInfo49);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder52 = combinedDomainXYPlot13.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.08d + "'", double31 == 0.08d);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNull(jFreeChart47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo49);
        org.junit.Assert.assertNotNull(piePlotState50);
        org.junit.Assert.assertNotNull(xYItemRendererState51);
        org.junit.Assert.assertNotNull(seriesRenderingOrder52);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) unitType0);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYStepRenderer2.getBaseToolTipGenerator();
        boolean boolean4 = xYStepRenderer2.getUseFillPaint();
        boolean boolean5 = xYStepRenderer2.getBaseSeriesVisible();
        xYStepRenderer2.setUseOutlinePaint(false);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font2);
        java.awt.Color color4 = java.awt.Color.green;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color4);
        org.jfree.chart.util.LogFormat logFormat12 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator14 = logFormat12.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat12, (int) (byte) -1);
        org.jfree.chart.util.LogFormat logFormat21 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        logFormat21.setMinimumIntegerDigits((int) (short) 100);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator24 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined_Domain_XYPlot", (java.text.NumberFormat) logFormat12, (java.text.NumberFormat) logFormat21);
        boolean boolean25 = textBlock5.equals((java.lang.Object) "Combined_Domain_XYPlot");
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(textBlock5);
        org.junit.Assert.assertNotNull(attributedCharacterIterator14);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Shape shape3 = barRenderer0.getSeriesShape(13);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = null;
        combinedDomainXYPlot6.setFixedLegendItems(legendItemCollection7);
        java.awt.Paint paint9 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot6.setDomainGridlinePaint(paint9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = combinedDomainXYPlot6.getRenderer();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = combinedDomainXYPlot6.getRangeAxisEdge();
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis14.pan(0.0d);
        double double18 = logAxis14.calculateValue(0.0d);
        combinedDomainXYPlot6.setRangeAxis((org.jfree.chart.axis.ValueAxis) logAxis14);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer23 = null;
        intervalMarker22.setGradientPaintTransformer(gradientPaintTransformer23);
        org.jfree.chart.text.TextAnchor textAnchor25 = intervalMarker22.getLabelTextAnchor();
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D28.setMinimumArcAngleToDraw((double) (byte) -1);
        double double31 = piePlot3D28.getInteriorGap();
        piePlot3D28.setDarkerSides(false);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D36.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D36.setLabelLinkStroke(stroke39);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint43.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart47 = chartChangeEvent46.getChart();
        boolean boolean48 = chartRenderingInfo42.equals((java.lang.Object) chartChangeEvent46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = chartRenderingInfo42.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState50 = piePlot3D28.initialise(graphics2D34, rectangle2D35, (org.jfree.chart.plot.PiePlot) piePlot3D36, (java.lang.Integer) 0, plotRenderingInfo49);
        java.awt.geom.Rectangle2D rectangle2D51 = plotRenderingInfo49.getDataArea();
        boolean boolean52 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 4, (double) (-398), rectangle2D51);
        barRenderer0.drawRangeMarker(graphics2D4, categoryPlot5, (org.jfree.chart.axis.ValueAxis) logAxis14, (org.jfree.chart.plot.Marker) intervalMarker22, rectangle2D51);
        org.jfree.chart.plot.Plot plot54 = logAxis14.getPlot();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNull(shape3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.08d + "'", double31 == 0.08d);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNull(jFreeChart47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo49);
        org.junit.Assert.assertNotNull(piePlotState50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(plot54);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", graphics2D1, (float) (-1L), (float) 2019, (double) 0.0f, (float) 1900, 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        int int2 = barRenderer0.getRowCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj4 = categoryPlot3.clone();
        boolean boolean5 = categoryPlot3.isDomainPannable();
        barRenderer0.setPlot(categoryPlot3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer10 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator8, xYURLGenerator9);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = xYStepRenderer10.getBaseToolTipGenerator();
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font13);
        xYStepRenderer10.setBaseItemLabelFont(font13);
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("hi!�");
        java.awt.Paint paint18 = logAxis17.getTickLabelPaint();
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("HorizontalAlignment.CENTER", font13, paint18, 0.5f);
        categoryPlot3.setRangeCrosshairPaint(paint18);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, true);
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(axisSpace4);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        double double5 = logAxis1.calculateValue(0.0d);
        boolean boolean6 = logAxis1.isTickLabelsVisible();
        logAxis1.setAutoRangeMinimumSize((double) 5, false);
        double double10 = logAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }
}

