import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 1.0f);
        java.util.List list2 = axisState1.getTicks();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.mapDatasetToRangeAxis((int) 'a', (int) (byte) 0);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        combinedDomainXYPlot7.setFixedLegendItems(legendItemCollection8);
        java.awt.Paint paint10 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot7.setDomainGridlinePaint(paint10);
        boolean boolean12 = combinedDomainXYPlot7.canSelectByPoint();
        int int13 = combinedDomainXYPlot7.getSeriesCount();
        combinedDomainXYPlot7.clearAnnotations();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset15, valueAxis16, valueAxis17, xYItemRenderer18);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        combinedDomainXYPlot20.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = combinedDomainXYPlot20.getDatasetRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker35 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean37 = combinedDomainXYPlot20.removeDomainMarker(12, (org.jfree.chart.plot.Marker) intervalMarker35, layer36);
        xYPlot19.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        xYPlot19.setRenderer(xYItemRenderer39);
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot19.setRangeAxisLocation(2019, axisLocation42);
        combinedDomainXYPlot7.setRangeAxisLocation(axisLocation42);
        categoryPlot0.setRangeAxisLocation((int) '4', axisLocation42, true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(axisLocation42);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        int int6 = combinedDomainXYPlot0.getSeriesCount();
        combinedDomainXYPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent9);
        org.jfree.data.time.TimeSeries timeSeries11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeSeries11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection12, valueAxis13, polarItemRenderer14);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator16, xYURLGenerator17);
        java.awt.Paint paint19 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer18.setBaseItemLabelPaint(paint19, false);
        org.jfree.chart.LegendItem legendItem24 = xYStepRenderer18.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer18.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot29 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        combinedDomainXYPlot29.setFixedLegendItems(legendItemCollection30);
        java.awt.Paint paint32 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot29.setDomainGridlinePaint(paint32);
        boolean boolean34 = combinedDomainXYPlot29.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        combinedDomainXYPlot29.setDataset((int) (short) 0, xYDataset36);
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.RenderingSource renderingSource41 = null;
        combinedDomainXYPlot29.select((double) 1L, (double) ' ', rectangle2D40, renderingSource41);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection43 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D44 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D44.setMinimumArcAngleToDraw((double) (byte) -1);
        double double47 = piePlot3D44.getInteriorGap();
        piePlot3D44.setDarkerSides(false);
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D52 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D52.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D52.setLabelLinkStroke(stroke55);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint61 = rectangleConstraint59.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent62 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart63 = chartChangeEvent62.getChart();
        boolean boolean64 = chartRenderingInfo58.equals((java.lang.Object) chartChangeEvent62);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = chartRenderingInfo58.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState66 = piePlot3D44.initialise(graphics2D50, rectangle2D51, (org.jfree.chart.plot.PiePlot) piePlot3D52, (java.lang.Integer) 0, plotRenderingInfo65);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState67 = xYStepRenderer18.initialise(graphics2D27, rectangle2D28, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot29, (org.jfree.data.xy.XYDataset) xYSeriesCollection43, plotRenderingInfo65);
        timeSeriesCollection12.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection43);
        int int69 = combinedDomainXYPlot0.indexOf((org.jfree.data.xy.XYDataset) xYSeriesCollection43);
        boolean boolean70 = combinedDomainXYPlot0.isDomainMinorGridlinesVisible();
        org.jfree.chart.block.ColumnArrangement columnArrangement71 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement72 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock74 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement72.add((org.jfree.chart.block.Block) labelBlock74, (java.lang.Object) 100L);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor77 = labelBlock74.getContentAlignmentPoint();
        java.lang.Object obj78 = labelBlock74.clone();
        labelBlock74.setURLText("");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer81 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        columnArrangement71.add((org.jfree.chart.block.Block) labelBlock74, (java.lang.Object) xYAreaRenderer81);
        org.jfree.chart.block.ColumnArrangement columnArrangement83 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement83.clear();
        org.jfree.chart.title.LegendTitle legendTitle85 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedDomainXYPlot0, (org.jfree.chart.block.Arrangement) columnArrangement71, (org.jfree.chart.block.Arrangement) columnArrangement83);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.08d + "'", double47 == 0.08d);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(rectangleConstraint59);
        org.junit.Assert.assertNotNull(rectangleConstraint61);
        org.junit.Assert.assertNull(jFreeChart63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo65);
        org.junit.Assert.assertNotNull(piePlotState66);
        org.junit.Assert.assertNotNull(xYItemRendererState67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor77);
        org.junit.Assert.assertNotNull(obj78);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.TickUnit tickUnit1 = polarPlot0.getAngleTickUnit();
        org.jfree.data.xy.XYDataset xYDataset2 = polarPlot0.getDataset();
        java.awt.Paint paint3 = polarPlot0.getRadiusGridlinePaint();
        polarPlot0.setAngleLabelsVisible(false);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        boolean boolean13 = xYPlot12.canSelectByRegion();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint16.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart20 = chartChangeEvent19.getChart();
        boolean boolean21 = chartRenderingInfo15.equals((java.lang.Object) chartChangeEvent19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = chartRenderingInfo15.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = null;
        java.awt.geom.Point2D point2D25 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D23, rectangleAnchor24);
        xYPlot12.panDomainAxes((double) (short) 10, plotRenderingInfo22, point2D25);
        org.jfree.chart.plot.PlotState plotState27 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection29 = null;
        combinedDomainXYPlot28.setFixedLegendItems(legendItemCollection29);
        java.awt.Paint paint31 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot28.setDomainGridlinePaint(paint31);
        boolean boolean33 = combinedDomainXYPlot28.canSelectByPoint();
        int int34 = combinedDomainXYPlot28.getSeriesCount();
        combinedDomainXYPlot28.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot38 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        combinedDomainXYPlot38.setFixedLegendItems(legendItemCollection39);
        java.awt.Paint paint41 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot38.setDomainGridlinePaint(paint41);
        boolean boolean43 = combinedDomainXYPlot38.canSelectByPoint();
        int int44 = combinedDomainXYPlot38.getSeriesCount();
        boolean boolean45 = combinedDomainXYPlot38.canSelectByPoint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = rectangleConstraint49.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent52 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart53 = chartChangeEvent52.getChart();
        boolean boolean54 = chartRenderingInfo48.equals((java.lang.Object) chartChangeEvent52);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = chartRenderingInfo48.getPlotInfo();
        combinedDomainXYPlot38.handleClick((-4767), 8, plotRenderingInfo55);
        org.jfree.chart.plot.PolarPlot polarPlot57 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = null;
        java.awt.geom.Point2D point2D63 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D61, rectangleAnchor62);
        polarPlot57.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo60, point2D63);
        combinedDomainXYPlot28.zoomDomainAxes((double) 1L, plotRenderingInfo55, point2D63);
        try {
            polarPlot0.draw(graphics2D6, rectangle2D7, point2D25, plotState27, plotRenderingInfo55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnit1);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNull(jFreeChart20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo22);
        org.junit.Assert.assertNotNull(point2D25);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint49);
        org.junit.Assert.assertNotNull(rectangleConstraint51);
        org.junit.Assert.assertNull(jFreeChart53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo55);
        org.junit.Assert.assertNotNull(point2D63);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Object obj1 = categoryPlot0.clone();
        java.awt.Stroke stroke2 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = categoryPlot0.getDomainAxis((int) (byte) 10);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(categoryAxis4);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        java.awt.Color color2 = java.awt.Color.cyan;
        standardChartTheme1.setAxisLabelPaint((java.awt.Paint) color2);
        java.awt.Paint paint4 = standardChartTheme1.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        combinedDomainXYPlot1.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        combinedDomainXYPlot1.setRenderer(xYItemRenderer4);
        java.awt.geom.GeneralPath generalPath6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D7.setMinimumArcAngleToDraw((double) (byte) -1);
        double double10 = piePlot3D7.getInteriorGap();
        piePlot3D7.setDarkerSides(false);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D15.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D15.setLabelLinkStroke(stroke18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint22.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart26 = chartChangeEvent25.getChart();
        boolean boolean27 = chartRenderingInfo21.equals((java.lang.Object) chartChangeEvent25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = chartRenderingInfo21.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState29 = piePlot3D7.initialise(graphics2D13, rectangle2D14, (org.jfree.chart.plot.PiePlot) piePlot3D15, (java.lang.Integer) 0, plotRenderingInfo28);
        java.awt.geom.Rectangle2D rectangle2D30 = plotRenderingInfo28.getDataArea();
        org.jfree.chart.RenderingSource renderingSource31 = null;
        combinedDomainXYPlot1.select(generalPath6, rectangle2D30, renderingSource31);
        try {
            boolean boolean33 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.08d + "'", double10 == 0.08d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNull(jFreeChart26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo28);
        org.junit.Assert.assertNotNull(piePlotState29);
        org.junit.Assert.assertNotNull(rectangle2D30);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        combinedDomainXYPlot1.setFixedLegendItems(legendItemCollection2);
        java.awt.Paint paint4 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot1.setDomainGridlinePaint(paint4);
        boolean boolean6 = combinedDomainXYPlot1.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        combinedDomainXYPlot1.setDataset((int) (short) 0, xYDataset8);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedDomainXYPlot1.select((double) 1L, (double) ' ', rectangle2D12, renderingSource13);
        java.lang.String str15 = combinedDomainXYPlot1.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset17 = combinedDomainXYPlot1.getDataset((int) (short) 1);
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean20 = logAxis19.isInverted();
        logAxis19.resizeRange(0.0d);
        org.jfree.data.Range range23 = combinedDomainXYPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis19);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray31 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray32 = color26.getRGBColorComponents(floatArray31);
        int int33 = color26.getAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker34 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, (double) (-2208960000000L), (java.awt.Paint) color26);
        combinedDomainXYPlot1.setDomainMinorGridlinePaint((java.awt.Paint) color26);
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D36.setMinimumArcAngleToDraw((double) (byte) -1);
        double double39 = piePlot3D36.getInteriorGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent40 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3D36);
        org.jfree.data.general.PieDataset pieDataset41 = piePlot3D36.getDataset();
        boolean boolean42 = piePlot3D36.getSectionOutlinesVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker45 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        intervalMarker45.setStroke(stroke46);
        piePlot3D36.setBaseSectionOutlineStroke(stroke46);
        java.awt.Paint paint49 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = dateAxis50.valueToJava2D(3.0d, rectangle2D52, rectangleEdge53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis50.setTickMarkStroke(stroke55);
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker((double) 1900, (java.awt.Paint) color26, stroke46, paint49, stroke55, (float) (byte) 1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Combined_Domain_XYPlot" + "'", str15.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYDataset17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 255 + "'", int33 == 255);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.08d + "'", double39 == 0.08d);
        org.junit.Assert.assertNull(pieDataset41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        java.awt.Stroke stroke73 = xYBarRenderer0.getItemOutlineStroke(0, (-460), false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(stroke73);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        java.awt.Paint paint4 = piePlot3D0.getLabelPaint();
        java.lang.String str5 = piePlot3D0.getPlotType();
        double double6 = piePlot3D0.getDepthFactor();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie 3D Plot" + "'", str5.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.12d + "'", double6 == 0.12d);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 900000L, (double) (-398));
        double double3 = size2D2.getHeight();
        size2D2.width = 8;
        double double6 = size2D2.getWidth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-398.0d) + "'", double3 == (-398.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem1.setShapeVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = legendItem1.getFillPaintTransformer();
        legendItem1.setShapeVisible(false);
        java.lang.String str7 = legendItem1.getDescription();
        java.awt.Paint paint8 = legendItem1.getFillPaint();
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("ItemLabelAnchor.INSIDE10");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj4 = standardXYToolTipGenerator3.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator5);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer6.getLegendItem(12, 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYAreaRenderer6.setBasePaint((java.awt.Paint) color10, true);
        standardChartTheme1.setShadowPaint((java.awt.Paint) color10);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace15 = color14.getColorSpace();
        standardChartTheme1.setDomainGridlinePaint((java.awt.Paint) color14);
        java.awt.Paint paint17 = standardChartTheme1.getPlotBackgroundPaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer20 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator18, xYURLGenerator19);
        java.awt.Paint paint21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer20.setBaseFillPaint(paint21);
        standardChartTheme1.setChartBackgroundPaint(paint21);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(colorSpace15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint21);
    }
}

