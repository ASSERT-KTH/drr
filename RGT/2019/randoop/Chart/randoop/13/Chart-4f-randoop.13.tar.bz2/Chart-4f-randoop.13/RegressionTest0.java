import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("hi!", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        try {
            org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 10L, (double) '#', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) (byte) 100, (float) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4767) + "'", int3 == (-4767));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Stroke stroke0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        java.io.ObjectOutputStream objectOutputStream5 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint3, objectOutputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test019");
//        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 12);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        try {
            labelBlock1.setContentAlignmentPoint(textBlockAnchor2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Combined_Domain_XYPlot", graphics2D1, (float) (-4767), (float) 100, 1.0d, (float) (byte) 1, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Combined_Domain_XYPlot", graphics2D1, (float) '#', (float) 100, 100.0d, (float) '4', (float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Font font1 = null;
        try {
            polarPlot0.setNoDataMessageFont(font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 12, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.TickUnit tickUnit1 = polarPlot0.getAngleTickUnit();
        double double2 = tickUnit1.getSize();
        org.junit.Assert.assertNotNull(tickUnit1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 45.0d + "'", double2 == 45.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.TickUnit tickUnit1 = polarPlot0.getAngleTickUnit();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = null;
        java.awt.geom.Point2D point2D6 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D4, rectangleAnchor5);
        try {
            polarPlot0.zoomRangeAxes((double) 0, plotRenderingInfo3, point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnit1);
        org.junit.Assert.assertNotNull(point2D6);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        combinedDomainXYPlot0.setBackgroundImageAlignment((int) (byte) -1);
        int int11 = combinedDomainXYPlot0.getDatasetCount();
        org.jfree.chart.plot.Marker marker12 = null;
        try {
            combinedDomainXYPlot0.addRangeMarker(marker12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        boolean boolean6 = combinedDomainXYPlot0.isDomainPannable();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = labelBlock1.arrange(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        boolean boolean4 = xYBarRenderer0.getItemVisible(0, 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Combined_Domain_XYPlot");
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getWidthConstraintType();
        boolean boolean6 = standardPieToolTipGenerator1.equals((java.lang.Object) lengthConstraintType5);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Shape shape0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity3 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart1, "Combined_Domain_XYPlot");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 255, 45.0d, (-4767), (java.lang.Comparable) 45.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.clone(shape0);
        org.junit.Assert.assertNull(shape1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.RenderingSource renderingSource12 = null;
        combinedDomainXYPlot0.select((double) 1L, (double) ' ', rectangle2D11, renderingSource12);
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean15 = piePlot3D14.getDarkerSides();
        combinedDomainXYPlot0.setParent((org.jfree.chart.plot.Plot) piePlot3D14);
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        try {
            combinedDomainXYPlot0.addRangeMarker((int) '4', marker18, layer19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-1), 100, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 0.0f, "Combined_Domain_XYPlot", textAnchor3, textAnchor4, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator8 = logFormat6.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat6, (int) (byte) -1);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        logFormat15.setMinimumIntegerDigits((int) (short) 100);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator18 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined_Domain_XYPlot", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat15);
        java.util.Currency currency19 = null;
        try {
            logFormat15.setCurrency(currency19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(attributedCharacterIterator8);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth((double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.util.Size2D size2D4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = rectangleConstraint2.calculateConstrainedSize(size2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ', (int) (byte) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        logFormat4.setMinimumIntegerDigits((int) (short) 100);
        java.math.RoundingMode roundingMode7 = null;
        try {
            logFormat4.setRoundingMode(roundingMode7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        try {
            double double4 = timeSeriesCollection1.getEndYValue(1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYStepRenderer2.getBaseToolTipGenerator();
        boolean boolean6 = xYStepRenderer2.getItemShapeFilled((-1), (-4767));
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray14);
        java.lang.Number number16 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        try {
            org.jfree.data.general.PieDataset pieDataset18 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset15, (java.lang.Comparable) month17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1.0d + "'", number16.equals(1.0d));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.TickUnit tickUnit1 = polarPlot0.getAngleTickUnit();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = null;
        java.awt.geom.Point2D point2D10 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D8, rectangleAnchor9);
        polarPlot4.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo7, point2D10);
        try {
            polarPlot0.zoomRangeAxes((double) (byte) 0, plotRenderingInfo3, point2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnit1);
        org.junit.Assert.assertNotNull(point2D10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth((double) 0.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint2.getWidthConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("Combined_Domain_XYPlot", dateFormat1, dateFormat2);
        java.lang.Object obj4 = standardXYToolTipGenerator3.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer1.setSeriesOutlinePaint((int) (short) 10, paint3);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = null;
        combinedDomainXYPlot5.setFixedLegendItems(legendItemCollection6);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot5.setDomainGridlinePaint(paint8);
        boolean boolean10 = combinedDomainXYPlot5.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        combinedDomainXYPlot5.setDataset((int) (short) 0, xYDataset12);
        combinedDomainXYPlot5.setBackgroundImageAlignment((int) (byte) -1);
        int int16 = combinedDomainXYPlot5.getDatasetCount();
        xYBarRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot5);
        boolean boolean18 = datasetGroup0.equals((java.lang.Object) xYBarRenderer1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        combinedDomainXYPlot0.setRenderer(xYItemRenderer3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.Layer layer9 = null;
        try {
            combinedDomainXYPlot0.addDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 900000L);
        double double3 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 899992.0d + "'", double2 == 899992.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3, (int) (byte) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        centerArrangement0.clear();
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = null;
        java.awt.geom.Point2D point2D13 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D11, rectangleAnchor12);
        polarPlot7.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo10, point2D13);
        try {
            polarPlot4.zoomRangeAxes((double) 'a', plotRenderingInfo6, point2D13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D13);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        combinedDomainXYPlot0.setBackgroundImageAlignment((int) (byte) -1);
        int int11 = combinedDomainXYPlot0.getDatasetCount();
        java.awt.Paint paint12 = combinedDomainXYPlot0.getBackgroundPaint();
        java.awt.Paint paint13 = null;
        try {
            combinedDomainXYPlot0.setDomainMinorGridlinePaint(paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Shape shape0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity3 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((-4767), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!-0.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        xYBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = xYBarRenderer0.getDrawingSupplier();
        xYBarRenderer0.setShadowYOffset((double) 0L);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYBarRenderer0.setSeriesURLGenerator((int) 'a', xYURLGenerator8, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = xYBarRenderer0.getSeriesToolTipGenerator((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(drawingSupplier4);
        org.junit.Assert.assertNull(xYToolTipGenerator12);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity4 = new org.jfree.chart.entity.PlotEntity(shape0, plot1, "", "hi!-0.0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        java.util.List list5 = null;
        try {
            org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            waferMapPlot2.draw(graphics2D3, rectangle2D4, point2D7, plotState8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray14);
        java.lang.Number number16 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset15);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1.0d + "'", number16.equals(1.0d));
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = null;
        java.awt.geom.Point2D point2D10 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D8, rectangleAnchor9);
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            combinedDomainXYPlot0.draw(graphics2D6, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(point2D10);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("Combined_Domain_XYPlot", font1, paint2, (float) (-1), 255, textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D5.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D5.setLabelLinkStroke(stroke8);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace13 = logAxis1.reserveSpace(graphics2D4, (org.jfree.chart.plot.Plot) piePlot3D5, rectangle2D10, rectangleEdge11, axisSpace12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        int int6 = combinedDomainXYPlot0.getSeriesCount();
        boolean boolean7 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray8 = null;
        try {
            combinedDomainXYPlot0.setRenderers(xYItemRendererArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str3 = intervalMarker2.getLabel();
        intervalMarker2.setEndValue((-1.0d));
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.awt.Image image0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeImage(image0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            org.jfree.data.xy.XYSeries xYSeries2 = xYSeriesCollection0.getSeries((java.lang.Comparable) 6);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 6");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            java.lang.Number number3 = xYSeriesCollection0.getY(9999, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        try {
            java.lang.Number number4 = timeSeriesCollection1.getEndY((int) (byte) 1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            xYSeriesCollection0.setSelected((int) (byte) 10, 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.DESCENDING;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator7 = logFormat5.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat5, (int) (byte) -1);
        java.lang.String str10 = numberTickUnit9.toString();
        org.junit.Assert.assertNotNull(attributedCharacterIterator7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[size=hi!-0.0]" + "'", str10.equals("[size=hi!-0.0]"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        xYBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = xYBarRenderer0.getDrawingSupplier();
        xYBarRenderer0.setShadowYOffset((double) 0L);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYBarRenderer0.setSeriesURLGenerator((int) 'a', xYURLGenerator8, false);
        int int11 = xYBarRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(drawingSupplier4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray6, numberArray10, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset16, (double) (-2208960000000L));
        double double19 = range18.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range18, 100.0d);
        boolean boolean24 = range18.intersects((double) (byte) 10, (double) 9999);
        dateAxis0.setRange(range18, true, false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        try {
            java.util.Date date29 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-2.20896E12d) + "'", double19 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = null;
        java.awt.geom.Point2D point2D12 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D10, rectangleAnchor11);
        polarPlot6.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo9, point2D12);
        org.jfree.chart.plot.PlotState plotState14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint16.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart20 = chartChangeEvent19.getChart();
        boolean boolean21 = chartRenderingInfo15.equals((java.lang.Object) chartChangeEvent19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = chartRenderingInfo15.getPlotInfo();
        try {
            piePlot3D0.draw(graphics2D4, rectangle2D5, point2D12, plotState14, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNull(jFreeChart20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo22);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        combinedDomainXYPlot1.setFixedLegendItems(legendItemCollection2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        combinedDomainXYPlot1.setRenderer(xYItemRenderer4);
        try {
            org.jfree.chart.entity.PlotEntity plotEntity8 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedDomainXYPlot1, "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 0L, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("[size=hi!-0.0]");
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem1.setShapeVisible(true);
        java.lang.Comparable comparable4 = legendItem1.getSeriesKey();
        legendItem1.setLineVisible(true);
        org.junit.Assert.assertNull(comparable4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray9 = null;
        try {
            combinedDomainXYPlot0.setRenderers(xYItemRendererArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = null;
        java.awt.geom.Point2D point2D6 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D4, rectangleAnchor5);
        org.jfree.chart.plot.PlotState plotState7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart13 = chartChangeEvent12.getChart();
        boolean boolean14 = chartRenderingInfo8.equals((java.lang.Object) chartChangeEvent12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = chartRenderingInfo8.getPlotInfo();
        try {
            piePlot3D1.draw(graphics2D2, rectangle2D3, point2D6, plotState7, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNull(jFreeChart13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo15);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Color color2 = java.awt.Color.getColor("", (int) (short) 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!-0.0");
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!�", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator8 = logFormat6.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat6, (int) (byte) -1);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        logFormat15.setMinimumIntegerDigits((int) (short) 100);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator18 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined_Domain_XYPlot", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat15);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D(pieDataset19);
        boolean boolean21 = standardPieToolTipGenerator18.equals((java.lang.Object) pieDataset19);
        java.lang.Object obj22 = standardPieToolTipGenerator18.clone();
        org.junit.Assert.assertNotNull(attributedCharacterIterator8);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        boolean boolean6 = tickType0.equals((java.lang.Object) logFormat5);
        try {
            java.lang.Object obj8 = logFormat5.parseObject("");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) 900000L);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createInsetRectangle(rectangle2D3, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = xYPlot4.getAxisOffset();
        double double7 = rectangleInsets5.trimHeight(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-8.0d) + "'", double7 == (-8.0d));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYStepRenderer2.getBaseToolTipGenerator();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font5);
        xYStepRenderer2.setBaseItemLabelFont(font5);
        try {
            xYStepRenderer2.setStepPoint((double) 900000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires stepPoint in [0.0;1.0]");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = null;
        java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D2, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot0.getRenderer();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        try {
            combinedDomainXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot6, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Require weight >= 1.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(xYItemRenderer5);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 12, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.BLACK;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2);
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = null;
        textBlock4.draw(graphics2D5, (float) (short) 10, (float) '#', textBlockAnchor8, (float) 'a', (float) (-4767), (double) 1.0f);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = textBlock4.calculateDimensions(graphics2D13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.CenterArrangement centerArrangement18 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement18.add((org.jfree.chart.block.Block) labelBlock20, (java.lang.Object) 100L);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        labelBlock20.setContentAlignmentPoint(textBlockAnchor23);
        java.awt.Shape shape28 = textBlock4.calculateBounds(graphics2D15, (float) 255, (float) 12, textBlockAnchor23, 0.0f, 0.0f, (double) 1.0f);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertNotNull(shape28);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = null;
        java.awt.geom.Point2D point2D6 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D4, rectangleAnchor5);
        polarPlot0.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo3, point2D6);
        boolean boolean8 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis9 = polarPlot0.getAxis();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        polarPlot12.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo15, point2D18);
        org.jfree.chart.plot.PlotState plotState20 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot21 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = null;
        combinedDomainXYPlot21.setFixedLegendItems(legendItemCollection22);
        java.awt.Paint paint24 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot21.setDomainGridlinePaint(paint24);
        boolean boolean26 = combinedDomainXYPlot21.canSelectByPoint();
        int int27 = combinedDomainXYPlot21.getSeriesCount();
        boolean boolean28 = combinedDomainXYPlot21.canSelectByPoint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = rectangleConstraint32.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart36 = chartChangeEvent35.getChart();
        boolean boolean37 = chartRenderingInfo31.equals((java.lang.Object) chartChangeEvent35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = chartRenderingInfo31.getPlotInfo();
        combinedDomainXYPlot21.handleClick((-4767), 8, plotRenderingInfo38);
        try {
            polarPlot0.draw(graphics2D10, rectangle2D11, point2D18, plotState20, plotRenderingInfo38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint32);
        org.junit.Assert.assertNotNull(rectangleConstraint34);
        org.junit.Assert.assertNull(jFreeChart36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo38);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!-0.0", dateFormat1, dateFormat2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer2.setBaseFillPaint(paint3);
        xYStepRenderer2.setDrawOutlines(true);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Image image1 = org.jfree.chart.util.SerialUtilities.readImage(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock2, (java.lang.Object) 100L);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray10, numberArray14, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset20, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) categoryDataset20, (java.lang.Comparable) (short) 1);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        combinedDomainXYPlot27.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot27.setDomainGridlinePaint(paint30);
        boolean boolean32 = combinedDomainXYPlot27.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        combinedDomainXYPlot27.setDataset((int) (short) 0, xYDataset34);
        combinedDomainXYPlot27.setBackgroundImageAlignment((int) (byte) -1);
        int int38 = combinedDomainXYPlot27.getDatasetCount();
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis42.pan(0.0d);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.AxisState axisState46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        java.util.List list49 = logAxis42.refreshTicks(graphics2D45, axisState46, rectangle2D47, rectangleEdge48);
        combinedDomainXYPlot27.drawRangeTickBands(graphics2D39, rectangle2D40, list49);
        try {
            java.lang.Object obj51 = legendItemBlockContainer24.draw(graphics2D25, rectangle2D26, (java.lang.Object) rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(list49);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.DomainOrder domainOrder1 = xYSeriesCollection0.getDomainOrder();
        try {
            java.lang.Number number4 = xYSeriesCollection0.getStartY(10, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(domainOrder1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = combinedDomainXYPlot0.getRangeMarkers((int) 'a', layer4);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = null;
        combinedDomainXYPlot8.setFixedLegendItems(legendItemCollection9);
        java.awt.Paint paint11 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot8.setDomainGridlinePaint(paint11);
        boolean boolean13 = combinedDomainXYPlot8.canSelectByPoint();
        int int14 = combinedDomainXYPlot8.getSeriesCount();
        combinedDomainXYPlot8.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = null;
        combinedDomainXYPlot18.setFixedLegendItems(legendItemCollection19);
        java.awt.Paint paint21 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot18.setDomainGridlinePaint(paint21);
        boolean boolean23 = combinedDomainXYPlot18.canSelectByPoint();
        int int24 = combinedDomainXYPlot18.getSeriesCount();
        boolean boolean25 = combinedDomainXYPlot18.canSelectByPoint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = rectangleConstraint29.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart33 = chartChangeEvent32.getChart();
        boolean boolean34 = chartRenderingInfo28.equals((java.lang.Object) chartChangeEvent32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = chartRenderingInfo28.getPlotInfo();
        combinedDomainXYPlot18.handleClick((-4767), 8, plotRenderingInfo35);
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = null;
        java.awt.geom.Point2D point2D43 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D41, rectangleAnchor42);
        polarPlot37.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo40, point2D43);
        combinedDomainXYPlot8.zoomDomainAxes((double) 1L, plotRenderingInfo35, point2D43);
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = null;
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D46, rectangleAnchor47);
        combinedDomainXYPlot0.zoomRangeAxes((double) ' ', (double) 13, plotRenderingInfo35, point2D48);
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        plotRenderingInfo35.setPlotArea(rectangle2D50);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
        org.junit.Assert.assertNotNull(rectangleConstraint31);
        org.junit.Assert.assertNull(jFreeChart33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo35);
        org.junit.Assert.assertNotNull(point2D43);
        org.junit.Assert.assertNotNull(point2D48);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.RenderingSource renderingSource12 = null;
        combinedDomainXYPlot0.select((double) 1L, (double) ' ', rectangle2D11, renderingSource12);
        java.lang.String str14 = combinedDomainXYPlot0.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedDomainXYPlot0.getRenderer();
        boolean boolean16 = combinedDomainXYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined_Domain_XYPlot" + "'", str14.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            chartRenderingInfo0.setChartArea(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        combinedDomainXYPlot1.setFixedLegendItems(legendItemCollection2);
        java.awt.Paint paint4 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot1.setDomainGridlinePaint(paint4);
        boolean boolean6 = combinedDomainXYPlot1.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        combinedDomainXYPlot1.setDataset((int) (short) 0, xYDataset8);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedDomainXYPlot1.select((double) 1L, (double) ' ', rectangle2D12, renderingSource13);
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean16 = piePlot3D15.getDarkerSides();
        combinedDomainXYPlot1.setParent((org.jfree.chart.plot.Plot) piePlot3D15);
        double double18 = piePlot3D15.getShadowXOffset();
        java.lang.String str19 = piePlot3D15.getPlotType();
        boolean boolean20 = rectangleAnchor0.equals((java.lang.Object) str19);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Pie 3D Plot" + "'", str19.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot6 = jFreeChart5.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PolarPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator7 = logFormat5.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat5, (int) (byte) -1);
        try {
            java.util.Currency currency10 = logFormat5.getCurrency();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(attributedCharacterIterator7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem1.setSeriesIndex((int) '4');
        legendItem1.setDescription("");
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = null;
        combinedDomainXYPlot6.setFixedLegendItems(legendItemCollection7);
        java.awt.Paint paint9 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot6.setDomainGridlinePaint(paint9);
        boolean boolean11 = combinedDomainXYPlot6.canSelectByPoint();
        int int12 = combinedDomainXYPlot6.getSeriesCount();
        boolean boolean13 = combinedDomainXYPlot6.canSelectByPoint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint17.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart21 = chartChangeEvent20.getChart();
        boolean boolean22 = chartRenderingInfo16.equals((java.lang.Object) chartChangeEvent20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = chartRenderingInfo16.getPlotInfo();
        combinedDomainXYPlot6.handleClick((-4767), 8, plotRenderingInfo23);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        try {
            polarPlot4.zoomRangeAxes(0.0d, plotRenderingInfo23, point2D27, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
        org.junit.Assert.assertNull(jFreeChart21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo23);
        org.junit.Assert.assertNotNull(point2D27);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        xYBarRenderer0.setBaseCreateEntities(false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        try {
            xYBarRenderer0.addAnnotation(xYAnnotation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 6, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        boolean boolean70 = xYBarRenderer0.getShadowsVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        boolean boolean0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.RenderingSource renderingSource12 = null;
        combinedDomainXYPlot0.select((double) 1L, (double) ' ', rectangle2D11, renderingSource12);
        java.lang.String str14 = combinedDomainXYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset16 = combinedDomainXYPlot0.getDataset((int) (short) 1);
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean19 = logAxis18.isInverted();
        logAxis18.resizeRange(0.0d);
        org.jfree.data.Range range22 = combinedDomainXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis18);
        java.awt.Paint paint23 = logAxis18.getTickLabelPaint();
        logAxis18.pan(0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined_Domain_XYPlot" + "'", str14.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        combinedDomainXYPlot0.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.xy.XYSeries xYSeries11 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection12 = new org.jfree.data.xy.XYSeriesCollection(xYSeries11);
        double double14 = xYSeriesCollection12.getDomainLowerBound(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedDomainXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection12);
        org.jfree.data.xy.XYSeries xYSeries16 = null;
        try {
            xYSeriesCollection12.removeSeries(xYSeries16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) 0L, (double) 100.0f, (double) 1);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean6 = xYBarRenderer5.isDrawBarOutline();
        java.awt.Font font8 = xYBarRenderer5.lookupLegendTextFont(3);
        java.awt.Paint paint10 = null;
        xYBarRenderer5.setSeriesPaint((int) (short) 0, paint10, false);
        java.awt.geom.RectangularShape rectangularShape16 = null;
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer20);
        boolean boolean23 = legendTitle22.visible;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = legendTitle22.getPosition();
        try {
            gradientXYBarPainter3.paintBarShadow(graphics2D4, xYBarRenderer5, (-4767), 100, false, rectangularShape16, rectangleEdge24, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(font8);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.awt.Paint paint0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.text.NumberFormat numberFormat1 = standardXYToolTipGenerator0.getYFormat();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray7 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray8 = color2.getRGBColorComponents(floatArray7);
        org.jfree.chart.text.TextMeasurer textMeasurer10 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", font1, (java.awt.Paint) color2, (float) (byte) 10, textMeasurer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer3 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Paint paint4 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer3.setBaseItemLabelPaint(paint4, false);
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D7.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D7.setLabelLinkStroke(stroke10);
        xYStepRenderer3.setBaseOutlineStroke(stroke10, true);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (-4767), (java.lang.Object) true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray14);
        java.lang.Number number16 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.jfree.data.KeyToGroupMap keyToGroupMap17 = null;
        try {
            org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset15, keyToGroupMap17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1.0d + "'", number16.equals(1.0d));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot2.setDataset(waferMapDataset3);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection5 = waferMapPlot2.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock2, (java.lang.Object) 100L);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray10, numberArray14, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset20, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) categoryDataset20, (java.lang.Comparable) (short) 1);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer28);
        boolean boolean31 = legendTitle30.visible;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = legendTitle30.getPosition();
        legendItemBlockContainer24.add((org.jfree.chart.block.Block) legendTitle30);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = null;
        try {
            legendTitle30.setHorizontalAlignment(horizontalAlignment34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator7 = logFormat5.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat5, (int) (byte) -1);
        logFormat5.setMinimumFractionDigits((int) (short) 100);
        try {
            java.lang.Object obj13 = logFormat5.parseObject("[size=hi!-0.0]");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(attributedCharacterIterator7);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-4767));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str3 = intervalMarker2.getLabel();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP;
        intervalMarker2.setLabelAnchor(rectangleAnchor4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator6, xYURLGenerator7);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYStepRenderer8.getBaseToolTipGenerator();
        boolean boolean10 = rectangleAnchor4.equals((java.lang.Object) xYStepRenderer8);
        xYStepRenderer8.setSeriesLinesVisible((int) (short) 100, false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Color color1 = java.awt.Color.getColor("hi!");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        long long2 = month1.getFirstMillisecond();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.previous();
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Locale locale7 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("Pie 3D Plot", (org.jfree.data.time.RegularTimePeriod) month1, regularTimePeriod5, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray14);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset15, false);
        double double18 = range17.getLength();
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 9.0d + "'", double18 == 9.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int int0 = java.text.NumberFormat.FRACTION_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        org.jfree.chart.axis.AxisLocation axisLocation71 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot20.setRangeAxisLocation((int) (byte) 100, axisLocation71);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation73 = null;
        try {
            boolean boolean75 = combinedDomainXYPlot20.removeAnnotation(xYAnnotation73, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(axisLocation71);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener6 = null;
        try {
            xYStepRenderer2.removeChangeListener(rendererChangeListener6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        combinedDomainXYPlot0.setRenderer(xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray10 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray11 = color5.getRGBColorComponents(floatArray10);
        int int12 = color5.getAlpha();
        combinedDomainXYPlot0.setRangeTickBandPaint((java.awt.Paint) color5);
        float[] floatArray14 = new float[] {};
        try {
            float[] floatArray15 = color5.getRGBColorComponents(floatArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) textAnchor0, true);
        java.lang.Object obj3 = rendererChangeEvent2.getRenderer();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock2, (java.lang.Object) 100L);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray10, numberArray14, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset20, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) categoryDataset20, (java.lang.Comparable) (short) 1);
        java.lang.Object obj25 = legendItemBlockContainer24.clone();
        java.lang.String str26 = legendItemBlockContainer24.getID();
        boolean boolean27 = legendItemBlockContainer24.isEmpty();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        combinedDomainXYPlot30.setFixedLegendItems(legendItemCollection31);
        java.awt.Paint paint33 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot30.setDomainGridlinePaint(paint33);
        boolean boolean35 = combinedDomainXYPlot30.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        combinedDomainXYPlot30.setDataset((int) (short) 0, xYDataset37);
        combinedDomainXYPlot30.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.xy.XYSeries xYSeries41 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection42 = new org.jfree.data.xy.XYSeriesCollection(xYSeries41);
        double double44 = xYSeriesCollection42.getDomainLowerBound(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = combinedDomainXYPlot30.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection42);
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot30.setDomainAxisLocation(axisLocation46);
        try {
            java.lang.Object obj48 = legendItemBlockContainer24.draw(graphics2D28, rectangle2D29, (java.lang.Object) combinedDomainXYPlot30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNull(xYItemRenderer45);
        org.junit.Assert.assertNotNull(axisLocation46);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis4.pan(0.0d);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = logAxis4.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        projectInfo2.setContributors(list11);
        boolean boolean13 = month0.equals((java.lang.Object) projectInfo2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D8.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D8.setLabelLinkStroke(stroke11);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint15.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart19 = chartChangeEvent18.getChart();
        boolean boolean20 = chartRenderingInfo14.equals((java.lang.Object) chartChangeEvent18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo14.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState22 = piePlot3D0.initialise(graphics2D6, rectangle2D7, (org.jfree.chart.plot.PiePlot) piePlot3D8, (java.lang.Integer) 0, plotRenderingInfo21);
        java.awt.Paint paint24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        piePlot3D8.setSectionOutlinePaint((java.lang.Comparable) 100.0d, paint24);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor26 = piePlot3D8.getLabelDistributor();
        int int27 = abstractPieLabelDistributor26.getItemCount();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNull(jFreeChart19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(piePlotState22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(255);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-398) + "'", int1 == (-398));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock2, (java.lang.Object) 100L);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray10, numberArray14, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset20, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) categoryDataset20, (java.lang.Comparable) (short) 1);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer28);
        boolean boolean31 = legendTitle30.visible;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = legendTitle30.getPosition();
        legendItemBlockContainer24.add((org.jfree.chart.block.Block) legendTitle30);
        java.lang.Object obj34 = legendItemBlockContainer24.clone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer35 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean36 = xYBarRenderer35.isDrawBarOutline();
        java.awt.Font font38 = xYBarRenderer35.lookupLegendTextFont(3);
        java.awt.Paint paint40 = null;
        xYBarRenderer35.setSeriesPaint((int) (short) 0, paint40, false);
        boolean boolean43 = legendItemBlockContainer24.equals((java.lang.Object) (short) 0);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(font38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot2.setDataset(waferMapDataset3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot2.setDataset(waferMapDataset5);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(12);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("HorizontalAlignment.CENTER", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double7 = logAxis1.valueToJava2D((double) 2019, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        boolean boolean5 = xYStepRenderer2.getItemLineVisible((-1), (int) ' ');
        boolean boolean6 = xYStepRenderer2.getBaseShapesFilled();
        try {
            xYStepRenderer2.setSeriesLinesVisible((int) (short) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!�", "[size=hi!-0.0]", "hi!");
        java.lang.String str5 = basicProjectInfo4.getInfo();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        java.util.List list8 = logAxis1.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge7);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator17 = logFormat15.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat15, (int) (byte) -1);
        org.jfree.chart.util.LogFormat logFormat24 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        logFormat24.setMinimumIntegerDigits((int) (short) 100);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator27 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined_Domain_XYPlot", (java.text.NumberFormat) logFormat15, (java.text.NumberFormat) logFormat24);
        java.lang.String str29 = logFormat15.format(0.0d);
        org.jfree.chart.util.LogFormat logFormat34 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator36 = logFormat34.formatToCharacterIterator((java.lang.Object) 0);
        java.lang.String str38 = logFormat34.format((double) 10);
        logFormat15.setExponentFormat((java.text.NumberFormat) logFormat34);
        logAxis1.setNumberFormatOverride((java.text.NumberFormat) logFormat34);
        org.jfree.chart.util.LogFormat logFormat45 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        logFormat45.setMinimumIntegerDigits((int) (short) 100);
        logAxis1.setNumberFormatOverride((java.text.NumberFormat) logFormat45);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(attributedCharacterIterator17);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!�" + "'", str29.equals("hi!�"));
        org.junit.Assert.assertNotNull(attributedCharacterIterator36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!-0.0" + "'", str38.equals("hi!-0.0"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.BLACK;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2);
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = null;
        textBlock4.draw(graphics2D5, (float) (short) 10, (float) '#', textBlockAnchor8, (float) 'a', (float) (-4767), (double) 1.0f);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = textBlock4.calculateDimensions(graphics2D13);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = textBlock4.getLineAlignment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D8.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D8.setLabelLinkStroke(stroke11);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint15.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart19 = chartChangeEvent18.getChart();
        boolean boolean20 = chartRenderingInfo14.equals((java.lang.Object) chartChangeEvent18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo14.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState22 = piePlot3D0.initialise(graphics2D6, rectangle2D7, (org.jfree.chart.plot.PiePlot) piePlot3D8, (java.lang.Integer) 0, plotRenderingInfo21);
        java.awt.Paint paint24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        piePlot3D8.setSectionOutlinePaint((java.lang.Comparable) 100.0d, paint24);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor26 = piePlot3D8.getLabelDistributor();
        abstractPieLabelDistributor26.clear();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNull(jFreeChart19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(piePlotState22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor26);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        double double3 = xYSeriesCollection1.getDomainLowerBound(false);
        org.jfree.data.xy.XYSeries xYSeries4 = null;
        try {
            xYSeriesCollection1.addSeries(xYSeries4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        boolean boolean70 = combinedDomainXYPlot20.isDomainMinorGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = combinedDomainXYPlot20.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(rectangleEdge71);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE10" + "'", str1.equals("ItemLabelAnchor.INSIDE10"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setShadowXOffset(45.0d);
        boolean boolean19 = xYBarRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYStepRenderer2.getBaseToolTipGenerator();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font5);
        xYStepRenderer2.setBaseItemLabelFont(font5);
        xYStepRenderer2.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = null;
        combinedDomainXYPlot11.setFixedLegendItems(legendItemCollection12);
        java.awt.Paint paint14 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot11.setDomainGridlinePaint(paint14);
        boolean boolean16 = combinedDomainXYPlot11.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        combinedDomainXYPlot11.setDataset((int) (short) 0, xYDataset18);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        combinedDomainXYPlot11.select((double) 1L, (double) ' ', rectangle2D22, renderingSource23);
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean26 = piePlot3D25.getDarkerSides();
        combinedDomainXYPlot11.setParent((org.jfree.chart.plot.Plot) piePlot3D25);
        boolean boolean28 = xYStepRenderer2.hasListener((java.util.EventListener) piePlot3D25);
        boolean boolean29 = piePlot3D25.getAutoPopulateSectionPaint();
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        org.jfree.chart.LegendItem legendItem8 = xYStepRenderer2.getLegendItem((int) (byte) 10, (int) (byte) 0);
        java.awt.Shape shape9 = xYStepRenderer2.getBaseShape();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("HorizontalAlignment.CENTER", "", doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        piePlot3D0.setStartAngle((double) (byte) -1);
        piePlot3D0.setShadowYOffset((double) (short) 100);
        int int7 = piePlot3D0.getPieIndex();
        piePlot3D0.clearSectionOutlineStrokes(false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYStepRenderer2.getLegendItems();
        int int4 = xYStepRenderer2.getPassCount();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection6, valueAxis7, polarItemRenderer8);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator10, xYURLGenerator11);
        java.awt.Paint paint13 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer12.setBaseItemLabelPaint(paint13, false);
        org.jfree.chart.LegendItem legendItem18 = xYStepRenderer12.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer12.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = null;
        combinedDomainXYPlot23.setFixedLegendItems(legendItemCollection24);
        java.awt.Paint paint26 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot23.setDomainGridlinePaint(paint26);
        boolean boolean28 = combinedDomainXYPlot23.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        combinedDomainXYPlot23.setDataset((int) (short) 0, xYDataset30);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.RenderingSource renderingSource35 = null;
        combinedDomainXYPlot23.select((double) 1L, (double) ' ', rectangle2D34, renderingSource35);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection37 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D38 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D38.setMinimumArcAngleToDraw((double) (byte) -1);
        double double41 = piePlot3D38.getInteriorGap();
        piePlot3D38.setDarkerSides(false);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D46 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D46.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D46.setLabelLinkStroke(stroke49);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo52 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint53 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = rectangleConstraint53.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent56 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart57 = chartChangeEvent56.getChart();
        boolean boolean58 = chartRenderingInfo52.equals((java.lang.Object) chartChangeEvent56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = chartRenderingInfo52.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState60 = piePlot3D38.initialise(graphics2D44, rectangle2D45, (org.jfree.chart.plot.PiePlot) piePlot3D46, (java.lang.Integer) 0, plotRenderingInfo59);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState61 = xYStepRenderer12.initialise(graphics2D21, rectangle2D22, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot23, (org.jfree.data.xy.XYDataset) xYSeriesCollection37, plotRenderingInfo59);
        timeSeriesCollection6.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection37);
        boolean boolean63 = xYStepRenderer2.equals((java.lang.Object) xYSeriesCollection37);
        org.jfree.data.xy.XYSeries xYSeries64 = null;
        try {
            xYSeriesCollection37.removeSeries(xYSeries64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem18);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.08d + "'", double41 == 0.08d);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(rectangleConstraint53);
        org.junit.Assert.assertNotNull(rectangleConstraint55);
        org.junit.Assert.assertNull(jFreeChart57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo59);
        org.junit.Assert.assertNotNull(piePlotState60);
        org.junit.Assert.assertNotNull(xYItemRendererState61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        piePlot3D0.setBackgroundImageAlignment(13);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            piePlot3D0.drawBackground(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("hi!-0.0", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (double) (short) 100);
        java.util.TimeZone timeZone7 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Locale locale8 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!-0.0", (org.jfree.data.time.RegularTimePeriod) month1, regularTimePeriod4, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        boolean boolean2 = gradientPaintTransformType0.equals((java.lang.Object) timePeriodAnchor1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ItemLabelAnchor.INSIDE10", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        piePlot3D0.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean9 = piePlot3D8.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        java.awt.Shape shape12 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        polarPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot13);
        java.util.List list19 = jFreeChart18.getSubtitles();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity20 = new org.jfree.chart.entity.JFreeChartEntity(shape12, jFreeChart18);
        jFreeChart18.clearSubtitles();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 6, (double) 13);
        org.jfree.chart.block.CenterArrangement centerArrangement5 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement5.add((org.jfree.chart.block.Block) labelBlock7, (java.lang.Object) 100L);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray15, numberArray19, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray24);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset25, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer29 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement5, (org.jfree.data.general.Dataset) categoryDataset25, (java.lang.Comparable) (short) 1);
        java.lang.Object obj30 = legendItemBlockContainer29.clone();
        java.lang.String str31 = legendItemBlockContainer29.getID();
        boolean boolean32 = legendItemBlockContainer29.isEmpty();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = rectangleConstraint34.toFixedWidth((double) 0.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = rectangleConstraint36.toUnconstrainedHeight();
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray52 = new java.lang.Number[][] { numberArray43, numberArray47, numberArray51 };
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray52);
        org.jfree.data.Range range55 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset53, (double) (-2208960000000L));
        double double56 = range55.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = new org.jfree.chart.block.RectangleConstraint(range55, 100.0d);
        boolean boolean61 = range55.intersects((double) (byte) 10, (double) 9999);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint62 = rectangleConstraint36.toRangeWidth(range55);
        try {
            org.jfree.chart.util.Size2D size2D63 = columnArrangement4.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer29, graphics2D33, rectangleConstraint36);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint34);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertNotNull(rectangleConstraint37);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-2.20896E12d) + "'", double56 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint62);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        xYBarRenderer0.setBaseCreateEntities(false);
        java.awt.Paint paint4 = xYBarRenderer0.getBaseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) textAnchor0, true);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = rendererChangeEvent2.getType();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        combinedDomainXYPlot0.clearDomainAxes();
        combinedDomainXYPlot0.clearSelection();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.KeyedValues keyedValues0 = null;
        try {
            org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset(keyedValues0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'data' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot0.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = null;
        java.awt.geom.Point2D point2D13 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D11, rectangleAnchor12);
        polarPlot7.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo10, point2D13);
        try {
            org.jfree.chart.plot.XYPlot xYPlot15 = combinedDomainXYPlot0.findSubplot(plotRenderingInfo6, point2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(point2D13);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.TickUnit tickUnit1 = polarPlot0.getAngleTickUnit();
        org.jfree.data.xy.XYDataset xYDataset2 = polarPlot0.getDataset();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = polarPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(tickUnit1);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D2.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D2.setLabelLinkStroke(stroke5);
        strokeList0.setStroke(0, stroke5);
        int int8 = strokeList0.size();
        int int9 = strokeList0.size();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        java.awt.Paint paint6 = combinedDomainXYPlot0.getRangeTickBandPaint();
        combinedDomainXYPlot0.setDomainPannable(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        piePlot3D0.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean9 = piePlot3D8.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        java.awt.Shape shape12 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        polarPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot13);
        java.util.List list19 = jFreeChart18.getSubtitles();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity20 = new org.jfree.chart.entity.JFreeChartEntity(shape12, jFreeChart18);
        boolean boolean22 = jFreeChartEntity20.equals((java.lang.Object) (-4767));
        org.jfree.chart.JFreeChart jFreeChart23 = jFreeChartEntity20.getChart();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(jFreeChart23);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = null;
        combinedDomainXYPlot5.setFixedLegendItems(legendItemCollection6);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot5.setDomainGridlinePaint(paint8);
        boolean boolean10 = combinedDomainXYPlot5.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        combinedDomainXYPlot5.setDataset((int) (short) 0, xYDataset12);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.RenderingSource renderingSource17 = null;
        combinedDomainXYPlot5.select((double) 1L, (double) ' ', rectangle2D16, renderingSource17);
        java.lang.String str19 = combinedDomainXYPlot5.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset21 = combinedDomainXYPlot5.getDataset((int) (short) 1);
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean24 = logAxis23.isInverted();
        logAxis23.resizeRange(0.0d);
        org.jfree.data.Range range27 = combinedDomainXYPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis23);
        java.awt.Paint paint28 = logAxis23.getTickLabelPaint();
        java.awt.Shape shape29 = logAxis23.getDownArrow();
        java.awt.Paint paint31 = null;
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace34 = color33.getColorSpace();
        java.awt.Stroke stroke35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D37.setMinimumArcAngleToDraw((double) (byte) -1);
        double double40 = piePlot3D37.getInteriorGap();
        piePlot3D37.setDarkerSides(false);
        piePlot3D37.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D45 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean46 = piePlot3D45.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator47 = piePlot3D45.getLegendLabelGenerator();
        piePlot3D37.setLegendLabelGenerator(pieSectionLabelGenerator47);
        java.awt.Shape shape49 = piePlot3D37.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot50 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries51 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection52 = new org.jfree.data.time.TimeSeriesCollection(timeSeries51);
        org.jfree.data.Range range53 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection52);
        polarPlot50.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection52);
        org.jfree.chart.JFreeChart jFreeChart55 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot50);
        java.util.List list56 = jFreeChart55.getSubtitles();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity57 = new org.jfree.chart.entity.JFreeChartEntity(shape49, jFreeChart55);
        org.jfree.chart.plot.IntervalMarker intervalMarker60 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.awt.Stroke stroke61 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        intervalMarker60.setStroke(stroke61);
        java.awt.Color color63 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        try {
            org.jfree.chart.LegendItem legendItem64 = new org.jfree.chart.LegendItem(attributedString0, "ItemLabelAnchor.INSIDE10", "", "", false, shape29, true, paint31, true, (java.awt.Paint) color33, stroke35, false, shape49, stroke61, (java.awt.Paint) color63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Combined_Domain_XYPlot" + "'", str19.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYDataset21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(colorSpace34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.08d + "'", double40 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator47);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(list56);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(color63);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("");
        java.lang.Object obj2 = standardPieToolTipGenerator1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        combinedDomainXYPlot0.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.xy.XYSeries xYSeries11 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection12 = new org.jfree.data.xy.XYSeriesCollection(xYSeries11);
        double double14 = xYSeriesCollection12.getDomainLowerBound(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedDomainXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection12);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray23 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray24 = color18.getRGBColorComponents(floatArray23);
        int int25 = color18.getAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, (double) (-2208960000000L), (java.awt.Paint) color18);
        combinedDomainXYPlot0.setDomainGridlinePaint((java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        java.awt.Font font3 = xYBarRenderer0.lookupLegendTextFont(3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = xYBarRenderer0.getGradientPaintTransformer();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) '#', xYToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        polarPlot0.removeCornerTextItem("ItemLabelAnchor.INSIDE10");
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, 10.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.Object obj1 = standardXYToolTipGenerator0.clone();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        int int6 = combinedDomainXYPlot0.getSeriesCount();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot0.setDomainCrosshairStroke(stroke7);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(13, 3, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
        java.util.Locale locale2 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        org.jfree.chart.axis.AxisLocation axisLocation71 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot20.setRangeAxisLocation((int) (byte) 100, axisLocation71);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation73 = null;
        try {
            combinedDomainXYPlot20.addAnnotation(xYAnnotation73);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(axisLocation71);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.valueToJava2D(3.0d, rectangle2D2, rectangleEdge3);
        double double5 = dateAxis0.getLowerBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        org.jfree.chart.axis.AxisLocation axisLocation71 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        combinedDomainXYPlot20.setRangeAxisLocation((int) (byte) 100, axisLocation71);
        org.jfree.chart.plot.Plot plot73 = combinedDomainXYPlot20.getParent();
        int int74 = combinedDomainXYPlot20.getBackgroundImageAlignment();
        combinedDomainXYPlot20.setBackgroundImageAlpha(0.0f);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertNull(plot73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 15 + "'", int74 == 15);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator3);
        org.jfree.chart.LegendItem legendItem7 = xYAreaRenderer4.getLegendItem(12, 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYAreaRenderer4.getPositiveItemLabelPosition((int) (byte) 100, 0, true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = itemLabelPosition11.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(legendItem7);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.String str2 = spreadsheetDate1.toString();
        int int3 = spreadsheetDate1.getMonth();
        int int4 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12-January-1900" + "'", str2.equals("12-January-1900"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        try {
            org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getFollowingDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange1);
        try {
            org.jfree.data.Range range4 = org.jfree.data.Range.scale((org.jfree.data.Range) dateRange1, (-8.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'factor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("Combined_Domain_XYPlot", "");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Combined_Domain_XYPlot" + "'", str3.equals("Combined_Domain_XYPlot"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        piePlot3D0.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean9 = piePlot3D8.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        java.awt.Shape shape12 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        polarPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot13);
        java.util.List list19 = jFreeChart18.getSubtitles();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity20 = new org.jfree.chart.entity.JFreeChartEntity(shape12, jFreeChart18);
        org.jfree.chart.axis.LogAxis logAxis22 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis22.pan(0.0d);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.AxisState axisState26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        java.util.List list29 = logAxis22.refreshTicks(graphics2D25, axisState26, rectangle2D27, rectangleEdge28);
        org.jfree.chart.util.LogFormat logFormat36 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator38 = logFormat36.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit40 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat36, (int) (byte) -1);
        org.jfree.chart.util.LogFormat logFormat45 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        logFormat45.setMinimumIntegerDigits((int) (short) 100);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator48 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined_Domain_XYPlot", (java.text.NumberFormat) logFormat36, (java.text.NumberFormat) logFormat45);
        java.lang.String str50 = logFormat36.format(0.0d);
        org.jfree.chart.util.LogFormat logFormat55 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator57 = logFormat55.formatToCharacterIterator((java.lang.Object) 0);
        java.lang.String str59 = logFormat55.format((double) 10);
        logFormat36.setExponentFormat((java.text.NumberFormat) logFormat55);
        logAxis22.setNumberFormatOverride((java.text.NumberFormat) logFormat55);
        org.jfree.chart.entity.AxisEntity axisEntity64 = new org.jfree.chart.entity.AxisEntity(shape12, (org.jfree.chart.axis.Axis) logAxis22, "Pie 3D Plot", "Nearest");
        java.lang.String str65 = axisEntity64.getShapeCoords();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(attributedCharacterIterator38);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!�" + "'", str50.equals("hi!�"));
        org.junit.Assert.assertNotNull(attributedCharacterIterator57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!-0.0" + "'", str59.equals("hi!-0.0"));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str65.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYStepRenderer2.getLegendItems();
        int int4 = xYStepRenderer2.getPassCount();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection6, valueAxis7, polarItemRenderer8);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator10, xYURLGenerator11);
        java.awt.Paint paint13 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer12.setBaseItemLabelPaint(paint13, false);
        org.jfree.chart.LegendItem legendItem18 = xYStepRenderer12.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer12.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = null;
        combinedDomainXYPlot23.setFixedLegendItems(legendItemCollection24);
        java.awt.Paint paint26 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot23.setDomainGridlinePaint(paint26);
        boolean boolean28 = combinedDomainXYPlot23.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        combinedDomainXYPlot23.setDataset((int) (short) 0, xYDataset30);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.RenderingSource renderingSource35 = null;
        combinedDomainXYPlot23.select((double) 1L, (double) ' ', rectangle2D34, renderingSource35);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection37 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D38 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D38.setMinimumArcAngleToDraw((double) (byte) -1);
        double double41 = piePlot3D38.getInteriorGap();
        piePlot3D38.setDarkerSides(false);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D46 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D46.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D46.setLabelLinkStroke(stroke49);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo52 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint53 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = rectangleConstraint53.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent56 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart57 = chartChangeEvent56.getChart();
        boolean boolean58 = chartRenderingInfo52.equals((java.lang.Object) chartChangeEvent56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = chartRenderingInfo52.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState60 = piePlot3D38.initialise(graphics2D44, rectangle2D45, (org.jfree.chart.plot.PiePlot) piePlot3D46, (java.lang.Integer) 0, plotRenderingInfo59);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState61 = xYStepRenderer12.initialise(graphics2D21, rectangle2D22, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot23, (org.jfree.data.xy.XYDataset) xYSeriesCollection37, plotRenderingInfo59);
        timeSeriesCollection6.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection37);
        boolean boolean63 = xYStepRenderer2.equals((java.lang.Object) xYSeriesCollection37);
        try {
            org.jfree.data.xy.XYSeries xYSeries65 = xYSeriesCollection37.getSeries((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem18);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.08d + "'", double41 == 0.08d);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(rectangleConstraint53);
        org.junit.Assert.assertNotNull(rectangleConstraint55);
        org.junit.Assert.assertNull(jFreeChart57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo59);
        org.junit.Assert.assertNotNull(piePlotState60);
        org.junit.Assert.assertNotNull(xYItemRendererState61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = combinedDomainXYPlot0.getRangeMarkers((int) 'a', layer4);
        java.util.List list6 = combinedDomainXYPlot0.getSubplots();
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = null;
        java.awt.geom.Point2D point2D6 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D4, rectangleAnchor5);
        polarPlot0.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo3, point2D6);
        boolean boolean8 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis9 = polarPlot0.getAxis();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = null;
        combinedDomainXYPlot11.setFixedLegendItems(legendItemCollection12);
        java.awt.Paint paint14 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot11.setDomainGridlinePaint(paint14);
        boolean boolean16 = combinedDomainXYPlot11.canSelectByPoint();
        int int17 = combinedDomainXYPlot11.getSeriesCount();
        boolean boolean18 = combinedDomainXYPlot11.canSelectByPoint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint22.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart26 = chartChangeEvent25.getChart();
        boolean boolean27 = chartRenderingInfo21.equals((java.lang.Object) chartChangeEvent25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = chartRenderingInfo21.getPlotInfo();
        combinedDomainXYPlot11.handleClick((-4767), 8, plotRenderingInfo28);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        combinedDomainXYPlot30.setFixedLegendItems(legendItemCollection31);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = combinedDomainXYPlot30.getRangeMarkers((int) 'a', layer34);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot38 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        combinedDomainXYPlot38.setFixedLegendItems(legendItemCollection39);
        java.awt.Paint paint41 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot38.setDomainGridlinePaint(paint41);
        boolean boolean43 = combinedDomainXYPlot38.canSelectByPoint();
        int int44 = combinedDomainXYPlot38.getSeriesCount();
        combinedDomainXYPlot38.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot48 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection49 = null;
        combinedDomainXYPlot48.setFixedLegendItems(legendItemCollection49);
        java.awt.Paint paint51 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot48.setDomainGridlinePaint(paint51);
        boolean boolean53 = combinedDomainXYPlot48.canSelectByPoint();
        int int54 = combinedDomainXYPlot48.getSeriesCount();
        boolean boolean55 = combinedDomainXYPlot48.canSelectByPoint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint61 = rectangleConstraint59.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent62 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart63 = chartChangeEvent62.getChart();
        boolean boolean64 = chartRenderingInfo58.equals((java.lang.Object) chartChangeEvent62);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = chartRenderingInfo58.getPlotInfo();
        combinedDomainXYPlot48.handleClick((-4767), 8, plotRenderingInfo65);
        org.jfree.chart.plot.PolarPlot polarPlot67 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor72 = null;
        java.awt.geom.Point2D point2D73 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D71, rectangleAnchor72);
        polarPlot67.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo70, point2D73);
        combinedDomainXYPlot38.zoomDomainAxes((double) 1L, plotRenderingInfo65, point2D73);
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor77 = null;
        java.awt.geom.Point2D point2D78 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D76, rectangleAnchor77);
        combinedDomainXYPlot30.zoomRangeAxes((double) ' ', (double) 13, plotRenderingInfo65, point2D78);
        try {
            polarPlot0.zoomRangeAxes((double) 2019, plotRenderingInfo28, point2D78, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNull(jFreeChart26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo28);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint59);
        org.junit.Assert.assertNotNull(rectangleConstraint61);
        org.junit.Assert.assertNull(jFreeChart63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo65);
        org.junit.Assert.assertNotNull(point2D73);
        org.junit.Assert.assertNotNull(point2D78);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem1.setShapeVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = legendItem1.getFillPaintTransformer();
        legendItem1.setURLText("hi!�");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        combinedDomainXYPlot7.setFixedLegendItems(legendItemCollection8);
        java.awt.Paint paint10 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot7.setDomainGridlinePaint(paint10);
        boolean boolean12 = combinedDomainXYPlot7.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        combinedDomainXYPlot7.setDataset((int) (short) 0, xYDataset14);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.RenderingSource renderingSource19 = null;
        combinedDomainXYPlot7.select((double) 1L, (double) ' ', rectangle2D18, renderingSource19);
        java.lang.String str21 = combinedDomainXYPlot7.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset23 = combinedDomainXYPlot7.getDataset((int) (short) 1);
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean26 = logAxis25.isInverted();
        logAxis25.resizeRange(0.0d);
        org.jfree.data.Range range29 = combinedDomainXYPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis25);
        java.awt.Paint paint30 = logAxis25.getTickLabelPaint();
        java.awt.Shape shape31 = logAxis25.getDownArrow();
        legendItem1.setLine(shape31);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Combined_Domain_XYPlot" + "'", str21.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYDataset23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!�", "[size=hi!-0.0]", "hi!");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = null;
        combinedDomainXYPlot5.setFixedLegendItems(legendItemCollection6);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot5.setDomainGridlinePaint(paint8);
        boolean boolean10 = combinedDomainXYPlot5.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        combinedDomainXYPlot5.setDataset((int) (short) 0, xYDataset12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CrosshairState crosshairState18 = null;
        boolean boolean19 = combinedDomainXYPlot5.render(graphics2D14, rectangle2D15, 10, plotRenderingInfo17, crosshairState18);
        boolean boolean20 = basicProjectInfo4.equals((java.lang.Object) crosshairState18);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator8 = logFormat6.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat6, (int) (byte) -1);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        logFormat15.setMinimumIntegerDigits((int) (short) 100);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator18 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined_Domain_XYPlot", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat15);
        java.lang.String str20 = logFormat6.format(0.0d);
        org.jfree.chart.util.LogFormat logFormat25 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator27 = logFormat25.formatToCharacterIterator((java.lang.Object) 0);
        java.lang.String str29 = logFormat25.format((double) 10);
        logFormat6.setExponentFormat((java.text.NumberFormat) logFormat25);
        java.lang.String str32 = logFormat25.format(45.0d);
        org.junit.Assert.assertNotNull(attributedCharacterIterator8);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!�" + "'", str20.equals("hi!�"));
        org.junit.Assert.assertNotNull(attributedCharacterIterator27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!-0.0" + "'", str29.equals("hi!-0.0"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!-0.0" + "'", str32.equals("hi!-0.0"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        java.util.List list6 = jFreeChart5.getSubtitles();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, valueAxis9, xYItemRenderer10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer10);
        legendTitle12.setWidth(2.0d);
        jFreeChart5.removeSubtitle((org.jfree.chart.title.Title) legendTitle12);
        legendTitle12.setVisible(false);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            int int4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound(xYDataset0, 2019, Double.NaN, (double) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer7 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator5, xYURLGenerator6);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer7.setBaseItemLabelPaint(paint8, false);
        org.jfree.chart.LegendItem legendItem13 = xYStepRenderer7.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer7.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = null;
        combinedDomainXYPlot18.setFixedLegendItems(legendItemCollection19);
        java.awt.Paint paint21 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot18.setDomainGridlinePaint(paint21);
        boolean boolean23 = combinedDomainXYPlot18.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        combinedDomainXYPlot18.setDataset((int) (short) 0, xYDataset25);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.RenderingSource renderingSource30 = null;
        combinedDomainXYPlot18.select((double) 1L, (double) ' ', rectangle2D29, renderingSource30);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection32 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D33.setMinimumArcAngleToDraw((double) (byte) -1);
        double double36 = piePlot3D33.getInteriorGap();
        piePlot3D33.setDarkerSides(false);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D41 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D41.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D41.setLabelLinkStroke(stroke44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = rectangleConstraint48.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent51 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart52 = chartChangeEvent51.getChart();
        boolean boolean53 = chartRenderingInfo47.equals((java.lang.Object) chartChangeEvent51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = chartRenderingInfo47.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState55 = piePlot3D33.initialise(graphics2D39, rectangle2D40, (org.jfree.chart.plot.PiePlot) piePlot3D41, (java.lang.Integer) 0, plotRenderingInfo54);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState56 = xYStepRenderer7.initialise(graphics2D16, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot18, (org.jfree.data.xy.XYDataset) xYSeriesCollection32, plotRenderingInfo54);
        timeSeriesCollection1.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection32);
        org.jfree.data.Range range59 = xYSeriesCollection32.getDomainBounds(false);
        xYSeriesCollection32.removeAllSeries();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.08d + "'", double36 == 0.08d);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
        org.junit.Assert.assertNotNull(rectangleConstraint50);
        org.junit.Assert.assertNull(jFreeChart52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo54);
        org.junit.Assert.assertNotNull(piePlotState55);
        org.junit.Assert.assertNotNull(xYItemRendererState56);
        org.junit.Assert.assertNull(range59);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYStepRenderer2.getBaseToolTipGenerator();
        xYStepRenderer2.setBaseLinesVisible(true);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.RenderingSource renderingSource12 = null;
        combinedDomainXYPlot0.select((double) 1L, (double) ' ', rectangle2D11, renderingSource12);
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean15 = piePlot3D14.getDarkerSides();
        combinedDomainXYPlot0.setParent((org.jfree.chart.plot.Plot) piePlot3D14);
        double double17 = piePlot3D14.getShadowXOffset();
        piePlot3D14.setLabelGap((double) (short) 1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = barRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj5 = categoryAxis4.clone();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer7.setSeriesOutlinePaint((int) (short) 10, paint9);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = null;
        combinedDomainXYPlot11.setFixedLegendItems(legendItemCollection12);
        java.awt.Paint paint14 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot11.setDomainGridlinePaint(paint14);
        boolean boolean16 = combinedDomainXYPlot11.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        combinedDomainXYPlot11.setDataset((int) (short) 0, xYDataset18);
        combinedDomainXYPlot11.setBackgroundImageAlignment((int) (byte) -1);
        int int22 = combinedDomainXYPlot11.getDatasetCount();
        xYBarRenderer7.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot11);
        java.awt.Font font25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer7.setLegendTextFont((int) (short) 100, font25);
        categoryAxis4.setTickLabelFont((java.lang.Comparable) month6, font25);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot28.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot31 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = null;
        combinedDomainXYPlot31.setFixedLegendItems(legendItemCollection32);
        java.awt.Paint paint34 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot31.setDomainGridlinePaint(paint34);
        boolean boolean36 = combinedDomainXYPlot31.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        combinedDomainXYPlot31.setDataset((int) (short) 0, xYDataset38);
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.RenderingSource renderingSource43 = null;
        combinedDomainXYPlot31.select((double) 1L, (double) ' ', rectangle2D42, renderingSource43);
        java.lang.String str45 = combinedDomainXYPlot31.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset47 = combinedDomainXYPlot31.getDataset((int) (short) 1);
        org.jfree.chart.axis.LogAxis logAxis49 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean50 = logAxis49.isInverted();
        logAxis49.resizeRange(0.0d);
        org.jfree.data.Range range53 = combinedDomainXYPlot31.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis49);
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray61 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray62 = color56.getRGBColorComponents(floatArray61);
        int int63 = color56.getAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker64 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, (double) (-2208960000000L), (java.awt.Paint) color56);
        combinedDomainXYPlot31.setDomainMinorGridlinePaint((java.awt.Paint) color56);
        combinedDomainXYPlot28.setNoDataMessagePaint((java.awt.Paint) color56);
        categoryAxis4.setAxisLinePaint((java.awt.Paint) color56);
        org.jfree.chart.plot.CategoryMarker categoryMarker68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        try {
            barRenderer0.drawDomainMarker(graphics2D2, categoryPlot3, categoryAxis4, categoryMarker68, rectangle2D69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Combined_Domain_XYPlot" + "'", str45.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYDataset47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 255 + "'", int63 == 255);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem1.setSeriesIndex((int) '4');
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray9, numberArray13, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray18);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset19);
        legendItem1.setDataset((org.jfree.data.general.Dataset) categoryDataset19);
        org.jfree.data.KeyToGroupMap keyToGroupMap22 = null;
        try {
            org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset19, keyToGroupMap22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.0d + "'", number20.equals(1.0d));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("Nearest", timeZone1);
        java.util.Date date3 = null;
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getYearValue();
        java.util.Date date6 = month4.getEnd();
        try {
            dateAxis2.setRange(date3, date6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator6 = logFormat4.formatToCharacterIterator((java.lang.Object) 0);
        logFormat4.setGroupingUsed(false);
        java.lang.StringBuffer stringBuffer10 = null;
        java.text.FieldPosition fieldPosition11 = null;
        try {
            java.lang.StringBuffer stringBuffer12 = logFormat4.format((java.lang.Object) "Nearest", stringBuffer10, fieldPosition11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(attributedCharacterIterator6);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator3);
        org.jfree.chart.LegendItem legendItem7 = xYAreaRenderer4.getLegendItem(12, 1);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = xYAreaRenderer4.getLegendItemURLGenerator();
        xYAreaRenderer4.setUseFillPaint(true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(legendItem7);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator8);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.util.Locale locale0 = null;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = barRenderer0.getSeriesItemLabelGenerator(5);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = null;
        try {
            barRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        int int6 = combinedDomainXYPlot0.getSeriesCount();
        int int7 = combinedDomainXYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = combinedDomainXYPlot0.getLegendItems();
        java.lang.Object obj9 = legendItemCollection8.clone();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.util.Collection collection1 = xYBarRenderer0.getAnnotations();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = null;
        combinedDomainXYPlot3.setFixedLegendItems(legendItemCollection4);
        java.awt.Paint paint6 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot3.setDomainGridlinePaint(paint6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = combinedDomainXYPlot3.getRenderer();
        java.awt.Stroke stroke9 = combinedDomainXYPlot3.getDomainZeroBaselineStroke();
        xYBarRenderer0.setSeriesStroke(6, stroke9);
        org.junit.Assert.assertNotNull(collection1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(xYItemRenderer8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = combinedDomainXYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        int int9 = combinedDomainXYPlot0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setLicenceName("HorizontalAlignment.CENTER");
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("Pie 3D Plot");
        int int2 = color1.getRGB();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16777216) + "'", int2 == (-16777216));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator70 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        xYBarRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator70);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer7);
        boolean boolean10 = legendTitle9.visible;
        legendTitle9.setHeight((double) 8);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = legendTitle9.getLegendItemGraphicEdge();
        try {
            java.util.List list14 = dateAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D3, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        int int6 = combinedDomainXYPlot0.getSeriesCount();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        combinedDomainXYPlot9.setFixedLegendItems(legendItemCollection10);
        java.awt.Paint paint12 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot9.setDomainGridlinePaint(paint12);
        boolean boolean14 = combinedDomainXYPlot9.canSelectByPoint();
        int int15 = combinedDomainXYPlot9.getSeriesCount();
        combinedDomainXYPlot9.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = null;
        combinedDomainXYPlot19.setFixedLegendItems(legendItemCollection20);
        java.awt.Paint paint22 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot19.setDomainGridlinePaint(paint22);
        boolean boolean24 = combinedDomainXYPlot19.canSelectByPoint();
        int int25 = combinedDomainXYPlot19.getSeriesCount();
        boolean boolean26 = combinedDomainXYPlot19.canSelectByPoint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = rectangleConstraint30.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart34 = chartChangeEvent33.getChart();
        boolean boolean35 = chartRenderingInfo29.equals((java.lang.Object) chartChangeEvent33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = chartRenderingInfo29.getPlotInfo();
        combinedDomainXYPlot19.handleClick((-4767), 8, plotRenderingInfo36);
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = null;
        java.awt.geom.Point2D point2D44 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D42, rectangleAnchor43);
        polarPlot38.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo41, point2D44);
        combinedDomainXYPlot9.zoomDomainAxes((double) 1L, plotRenderingInfo36, point2D44);
        java.awt.geom.Point2D point2D47 = null;
        try {
            combinedDomainXYPlot0.zoomRangeAxes((double) (byte) -1, (double) 100L, plotRenderingInfo36, point2D47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(rectangleConstraint32);
        org.junit.Assert.assertNull(jFreeChart34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo36);
        org.junit.Assert.assertNotNull(point2D44);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = null;
        combinedDomainXYPlot3.setFixedLegendItems(legendItemCollection4);
        java.awt.Paint paint6 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot3.setDomainGridlinePaint(paint6);
        boolean boolean8 = combinedDomainXYPlot3.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        combinedDomainXYPlot3.setDataset((int) (short) 0, xYDataset10);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.RenderingSource renderingSource15 = null;
        combinedDomainXYPlot3.select((double) 1L, (double) ' ', rectangle2D14, renderingSource15);
        java.lang.String str17 = combinedDomainXYPlot3.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset19 = combinedDomainXYPlot3.getDataset((int) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = combinedDomainXYPlot3.getDomainAxisEdge();
        try {
            double double21 = dateAxis0.valueToJava2D((double) 2, rectangle2D2, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Combined_Domain_XYPlot" + "'", str17.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray7, numberArray11, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray16);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset17, (double) (-2208960000000L));
        double double20 = range19.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint(range19, 100.0d);
        boolean boolean25 = range19.intersects((double) (byte) 10, (double) 9999);
        dateAxis1.setRange(range19, true, false);
        boolean boolean30 = range19.contains((-2.20896E12d));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = rectangleConstraint31.toFixedWidth((double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType34 = rectangleConstraint33.getWidthConstraintType();
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem37.setSeriesIndex((int) '4');
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray45, numberArray49, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray54);
        java.lang.Number number56 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset55);
        legendItem37.setDataset((org.jfree.data.general.Dataset) categoryDataset55);
        org.jfree.data.Range range58 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset55);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType59 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot60 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot60.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.Layer layer64 = null;
        java.util.Collection collection65 = combinedDomainXYPlot60.getRangeMarkers((int) (short) 1, layer64);
        combinedDomainXYPlot60.clearDomainAxes();
        boolean boolean67 = lengthConstraintType59.equals((java.lang.Object) combinedDomainXYPlot60);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint68 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, range19, lengthConstraintType34, (double) 13, range58, lengthConstraintType59);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-2.20896E12d) + "'", double20 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint31);
        org.junit.Assert.assertNotNull(rectangleConstraint33);
        org.junit.Assert.assertNotNull(lengthConstraintType34);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 1.0d + "'", number56.equals(1.0d));
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(lengthConstraintType59);
        org.junit.Assert.assertNull(collection65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        xYBarRenderer0.setAutoPopulateSeriesStroke(false);
        java.awt.Paint paint5 = xYBarRenderer0.getSeriesPaint(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator3);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        xYAreaRenderer4.setBaseURLGenerator(xYURLGenerator5);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        xYAreaRenderer4.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator7);
        java.text.NumberFormat numberFormat9 = standardXYToolTipGenerator7.getXFormat();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(numberFormat9);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = combinedDomainXYPlot0.getRangeMarkers((int) (short) 1, layer4);
        combinedDomainXYPlot0.clearDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = combinedDomainXYPlot0.getRenderer(255);
        org.jfree.chart.axis.AxisLocation axisLocation10 = combinedDomainXYPlot0.getDomainAxisLocation(2958465);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(xYItemRenderer8);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator4, xYURLGenerator5);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = xYStepRenderer6.getBaseToolTipGenerator();
        java.awt.Font font9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font9);
        xYStepRenderer6.setBaseItemLabelFont(font9);
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D12.setMinimumArcAngleToDraw((double) (byte) -1);
        double double15 = piePlot3D12.getInteriorGap();
        piePlot3D12.setDarkerSides(false);
        piePlot3D12.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean21 = piePlot3D20.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator22 = piePlot3D20.getLegendLabelGenerator();
        piePlot3D12.setLegendLabelGenerator(pieSectionLabelGenerator22);
        java.awt.Shape shape24 = piePlot3D12.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries26 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection27 = new org.jfree.data.time.TimeSeriesCollection(timeSeries26);
        org.jfree.data.Range range28 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection27);
        polarPlot25.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot25);
        java.util.List list31 = jFreeChart30.getSubtitles();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity32 = new org.jfree.chart.entity.JFreeChartEntity(shape24, jFreeChart30);
        xYStepRenderer6.setLegendLine(shape24);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator34 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator35 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer36 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator34, xYURLGenerator35);
        java.awt.Paint paint37 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer36.setBaseItemLabelPaint(paint37, false);
        try {
            org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem(attributedString0, "[size=hi!-0.0]", "12-January-1900", "DateTickMarkPosition.MIDDLE", shape24, paint37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYToolTipGenerator7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        xYBarRenderer0.setBaseCreateEntities(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean5 = xYBarRenderer4.isDrawBarOutline();
        java.awt.Font font7 = xYBarRenderer4.lookupLegendTextFont(3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = xYBarRenderer4.getGradientPaintTransformer();
        xYBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer8);
        xYBarRenderer0.setMargin((-8.0d));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertNotNull(gradientPaintTransformer8);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        combinedDomainXYPlot0.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = combinedDomainXYPlot0.getDatasetRenderingOrder();
        java.lang.String str12 = datasetRenderingOrder11.toString();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str12.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        piePlot3D0.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean9 = piePlot3D8.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor12 = piePlot3D0.getLabelDistributor();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator13 = piePlot3D0.getToolTipGenerator();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor12);
        org.junit.Assert.assertNull(pieToolTipGenerator13);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        piePlot3D0.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean9 = piePlot3D8.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        java.awt.Shape shape12 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        polarPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot13);
        java.util.List list19 = jFreeChart18.getSubtitles();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity20 = new org.jfree.chart.entity.JFreeChartEntity(shape12, jFreeChart18);
        org.jfree.chart.axis.LogAxis logAxis22 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis22.pan(0.0d);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.AxisState axisState26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        java.util.List list29 = logAxis22.refreshTicks(graphics2D25, axisState26, rectangle2D27, rectangleEdge28);
        org.jfree.chart.util.LogFormat logFormat36 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator38 = logFormat36.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit40 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat36, (int) (byte) -1);
        org.jfree.chart.util.LogFormat logFormat45 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        logFormat45.setMinimumIntegerDigits((int) (short) 100);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator48 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined_Domain_XYPlot", (java.text.NumberFormat) logFormat36, (java.text.NumberFormat) logFormat45);
        java.lang.String str50 = logFormat36.format(0.0d);
        org.jfree.chart.util.LogFormat logFormat55 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator57 = logFormat55.formatToCharacterIterator((java.lang.Object) 0);
        java.lang.String str59 = logFormat55.format((double) 10);
        logFormat36.setExponentFormat((java.text.NumberFormat) logFormat55);
        logAxis22.setNumberFormatOverride((java.text.NumberFormat) logFormat55);
        org.jfree.chart.entity.AxisEntity axisEntity64 = new org.jfree.chart.entity.AxisEntity(shape12, (org.jfree.chart.axis.Axis) logAxis22, "Pie 3D Plot", "Nearest");
        java.lang.Number[] numberArray70 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray74 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray78 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray79 = new java.lang.Number[][] { numberArray70, numberArray74, numberArray78 };
        org.jfree.data.category.CategoryDataset categoryDataset80 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray79);
        org.jfree.data.Range range82 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset80, false);
        boolean boolean83 = axisEntity64.equals((java.lang.Object) categoryDataset80);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(attributedCharacterIterator38);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!�" + "'", str50.equals("hi!�"));
        org.junit.Assert.assertNotNull(attributedCharacterIterator57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!-0.0" + "'", str59.equals("hi!-0.0"));
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(numberArray74);
        org.junit.Assert.assertNotNull(numberArray78);
        org.junit.Assert.assertNotNull(numberArray79);
        org.junit.Assert.assertNotNull(categoryDataset80);
        org.junit.Assert.assertNotNull(range82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator(13, categoryToolTipGenerator2);
        java.awt.Paint paint4 = barRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        try {
            barRenderer0.setSeriesToolTipGenerator((int) (byte) -1, categoryToolTipGenerator6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator8 = logFormat6.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat6, (int) (byte) -1);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        logFormat15.setMinimumIntegerDigits((int) (short) 100);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator18 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined_Domain_XYPlot", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat15);
        java.lang.String str20 = logFormat6.format(0.0d);
        org.jfree.chart.util.LogFormat logFormat25 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator27 = logFormat25.formatToCharacterIterator((java.lang.Object) 0);
        java.lang.String str29 = logFormat25.format((double) 10);
        logFormat6.setExponentFormat((java.text.NumberFormat) logFormat25);
        logFormat25.setMinimumIntegerDigits(0);
        org.junit.Assert.assertNotNull(attributedCharacterIterator8);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!�" + "'", str20.equals("hi!�"));
        org.junit.Assert.assertNotNull(attributedCharacterIterator27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!-0.0" + "'", str29.equals("hi!-0.0"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        java.util.List list6 = jFreeChart5.getSubtitles();
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart5.getTitle();
        java.awt.Image image8 = jFreeChart5.getBackgroundImage();
        int int9 = jFreeChart5.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(textTitle7);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.height;
        double double2 = size2D0.height;
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYStepRenderer2.getLegendItems();
        int int4 = xYStepRenderer2.getPassCount();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = null;
        combinedDomainXYPlot6.setFixedLegendItems(legendItemCollection7);
        java.awt.Paint paint9 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot6.setDomainGridlinePaint(paint9);
        boolean boolean11 = combinedDomainXYPlot6.canSelectByPoint();
        int int12 = combinedDomainXYPlot6.getSeriesCount();
        boolean boolean13 = combinedDomainXYPlot6.canSelectByPoint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer15.setSeriesOutlinePaint((int) (short) 10, paint17);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = null;
        combinedDomainXYPlot19.setFixedLegendItems(legendItemCollection20);
        java.awt.Paint paint22 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot19.setDomainGridlinePaint(paint22);
        boolean boolean24 = combinedDomainXYPlot19.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        combinedDomainXYPlot19.setDataset((int) (short) 0, xYDataset26);
        combinedDomainXYPlot19.setBackgroundImageAlignment((int) (byte) -1);
        int int30 = combinedDomainXYPlot19.getDatasetCount();
        xYBarRenderer15.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot19);
        xYBarRenderer15.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot35 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection36 = null;
        combinedDomainXYPlot35.setFixedLegendItems(legendItemCollection36);
        java.awt.Paint paint38 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot35.setDomainGridlinePaint(paint38);
        boolean boolean40 = combinedDomainXYPlot35.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        combinedDomainXYPlot35.setDataset((int) (short) 0, xYDataset42);
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.RenderingSource renderingSource47 = null;
        combinedDomainXYPlot35.select((double) 1L, (double) ' ', rectangle2D46, renderingSource47);
        java.lang.String str49 = combinedDomainXYPlot35.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = combinedDomainXYPlot35.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray57 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray61 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray65 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray66 = new java.lang.Number[][] { numberArray57, numberArray61, numberArray65 };
        org.jfree.data.category.CategoryDataset categoryDataset67 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray66);
        org.jfree.data.Range range69 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset67, (double) (-2208960000000L));
        double double70 = range69.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint72 = new org.jfree.chart.block.RectangleConstraint(range69, 100.0d);
        boolean boolean75 = range69.intersects((double) (byte) 10, (double) 9999);
        dateAxis51.setRange(range69, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker81 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str82 = intervalMarker81.getLabel();
        java.awt.geom.Rectangle2D rectangle2D83 = null;
        xYBarRenderer15.drawRangeMarker(graphics2D34, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot35, (org.jfree.chart.axis.ValueAxis) dateAxis51, (org.jfree.chart.plot.Marker) intervalMarker81, rectangle2D83);
        combinedDomainXYPlot35.setGap((double) 12);
        org.jfree.chart.util.Layer layer87 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection88 = combinedDomainXYPlot35.getDomainMarkers(layer87);
        java.util.Collection collection89 = combinedDomainXYPlot6.getRangeMarkers((int) (byte) 0, layer87);
        try {
            xYStepRenderer2.addAnnotation(xYAnnotation5, layer87);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Combined_Domain_XYPlot" + "'", str49.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer50);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(categoryDataset67);
        org.junit.Assert.assertNotNull(range69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-2.20896E12d) + "'", double70 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNull(str82);
        org.junit.Assert.assertNotNull(layer87);
        org.junit.Assert.assertNull(collection88);
        org.junit.Assert.assertNull(collection89);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        java.util.Date date2 = month0.getEnd();
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        combinedDomainXYPlot1.setFixedLegendItems(legendItemCollection2);
        java.awt.Paint paint4 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot1.setDomainGridlinePaint(paint4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        combinedDomainXYPlot1.setRangeGridlinePaint(paint6);
        boolean boolean8 = rectangleAnchor0.equals((java.lang.Object) paint6);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        xYBarRenderer0.clearSeriesStrokes(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = null;
        combinedDomainXYPlot5.setFixedLegendItems(legendItemCollection6);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot5.setDomainGridlinePaint(paint8);
        boolean boolean10 = combinedDomainXYPlot5.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        combinedDomainXYPlot5.setDataset((int) (short) 0, xYDataset12);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.RenderingSource renderingSource17 = null;
        combinedDomainXYPlot5.select((double) 1L, (double) ' ', rectangle2D16, renderingSource17);
        java.lang.String str19 = combinedDomainXYPlot5.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset21 = combinedDomainXYPlot5.getDataset((int) (short) 1);
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean24 = logAxis23.isInverted();
        logAxis23.resizeRange(0.0d);
        org.jfree.data.Range range27 = combinedDomainXYPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis23);
        java.awt.Paint paint28 = logAxis23.getTickLabelPaint();
        xYBarRenderer0.setSeriesFillPaint(1, paint28, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Combined_Domain_XYPlot" + "'", str19.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYDataset21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis2.pan(0.0d);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = logAxis2.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        projectInfo0.setContributors(list9);
        java.util.Collection collection11 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list9);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(collection11);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer2.setBaseFillPaint(paint3);
        java.awt.Paint paint6 = xYStepRenderer2.getSeriesItemLabelPaint(15);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = null;
        xYStepRenderer2.setBaseItemLabelGenerator(xYItemLabelGenerator7);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        piePlot3D0.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean9 = piePlot3D8.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        java.awt.Shape shape12 = piePlot3D0.getLegendItemShape();
        piePlot3D0.setIgnoreZeroValues(false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = combinedDomainXYPlot0.getRangeMarkers((int) (short) 1, layer4);
        combinedDomainXYPlot0.clearDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis8 = combinedDomainXYPlot0.getDomainAxisForDataset(0);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        combinedDomainXYPlot0.setDataset(xYDataset9);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement0.add((org.jfree.chart.block.Block) labelBlock2, (java.lang.Object) 100L);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray10, numberArray14, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset20, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) categoryDataset20, (java.lang.Comparable) (short) 1);
        java.lang.Object obj25 = legendItemBlockContainer24.clone();
        java.lang.String str26 = legendItemBlockContainer24.getID();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator29 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator30 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer31 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator29, xYURLGenerator30);
        java.awt.Paint paint32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer31.setBaseFillPaint(paint32);
        try {
            java.lang.Object obj34 = legendItemBlockContainer24.draw(graphics2D27, rectangle2D28, (java.lang.Object) xYStepRenderer31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        long long3 = month0.getMiddleMillisecond();
        java.lang.String str4 = month0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem1.setShapeVisible(true);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendItem1.setLabelPaint((java.awt.Paint) color4);
        java.lang.String str6 = legendItem1.getToolTipText();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("Combined_Domain_XYPlot", dateFormat1, dateFormat2);
        java.lang.String str4 = standardXYToolTipGenerator3.getNullYString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "null" + "'", str4.equals("null"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3D0);
        org.jfree.chart.plot.Plot plot5 = plotChangeEvent4.getPlot();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(plot5);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYStepRenderer2.getBaseToolTipGenerator();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font5);
        xYStepRenderer2.setBaseItemLabelFont(font5);
        xYStepRenderer2.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = null;
        combinedDomainXYPlot11.setFixedLegendItems(legendItemCollection12);
        java.awt.Paint paint14 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot11.setDomainGridlinePaint(paint14);
        boolean boolean16 = combinedDomainXYPlot11.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        combinedDomainXYPlot11.setDataset((int) (short) 0, xYDataset18);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.RenderingSource renderingSource23 = null;
        combinedDomainXYPlot11.select((double) 1L, (double) ' ', rectangle2D22, renderingSource23);
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean26 = piePlot3D25.getDarkerSides();
        combinedDomainXYPlot11.setParent((org.jfree.chart.plot.Plot) piePlot3D25);
        boolean boolean28 = xYStepRenderer2.hasListener((java.util.EventListener) piePlot3D25);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = null;
        xYStepRenderer2.setBaseURLGenerator(xYURLGenerator29, false);
        xYStepRenderer2.setSeriesVisible((int) (byte) 0, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 0, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (-398));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        double double2 = crosshairState1.getAnchorY();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer7 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator5, xYURLGenerator6);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer7.setBaseItemLabelPaint(paint8, false);
        org.jfree.chart.LegendItem legendItem13 = xYStepRenderer7.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer7.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = null;
        combinedDomainXYPlot18.setFixedLegendItems(legendItemCollection19);
        java.awt.Paint paint21 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot18.setDomainGridlinePaint(paint21);
        boolean boolean23 = combinedDomainXYPlot18.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        combinedDomainXYPlot18.setDataset((int) (short) 0, xYDataset25);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.RenderingSource renderingSource30 = null;
        combinedDomainXYPlot18.select((double) 1L, (double) ' ', rectangle2D29, renderingSource30);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection32 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D33.setMinimumArcAngleToDraw((double) (byte) -1);
        double double36 = piePlot3D33.getInteriorGap();
        piePlot3D33.setDarkerSides(false);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D41 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D41.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D41.setLabelLinkStroke(stroke44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = rectangleConstraint48.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent51 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart52 = chartChangeEvent51.getChart();
        boolean boolean53 = chartRenderingInfo47.equals((java.lang.Object) chartChangeEvent51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = chartRenderingInfo47.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState55 = piePlot3D33.initialise(graphics2D39, rectangle2D40, (org.jfree.chart.plot.PiePlot) piePlot3D41, (java.lang.Integer) 0, plotRenderingInfo54);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState56 = xYStepRenderer7.initialise(graphics2D16, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot18, (org.jfree.data.xy.XYDataset) xYSeriesCollection32, plotRenderingInfo54);
        timeSeriesCollection1.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection32);
        org.jfree.data.Range range59 = xYSeriesCollection32.getDomainBounds(false);
        double double60 = xYSeriesCollection32.getIntervalPositionFactor();
        try {
            xYSeriesCollection32.setSelected((int) (short) 0, 3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.08d + "'", double36 == 0.08d);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
        org.junit.Assert.assertNotNull(rectangleConstraint50);
        org.junit.Assert.assertNull(jFreeChart52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo54);
        org.junit.Assert.assertNotNull(piePlotState55);
        org.junit.Assert.assertNotNull(xYItemRendererState56);
        org.junit.Assert.assertNull(range59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.5d + "'", double60 == 0.5d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.RenderingSource renderingSource12 = null;
        combinedDomainXYPlot0.select((double) 1L, (double) ' ', rectangle2D11, renderingSource12);
        java.lang.String str14 = combinedDomainXYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset16 = combinedDomainXYPlot0.getDataset((int) (short) 1);
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean19 = logAxis18.isInverted();
        logAxis18.resizeRange(0.0d);
        org.jfree.data.Range range22 = combinedDomainXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis18);
        float float23 = logAxis18.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined_Domain_XYPlot" + "'", str14.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource1 = chartRenderingInfo0.getRenderingSource();
        org.junit.Assert.assertNull(renderingSource1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj2 = categoryAxis1.clone();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer9);
        boolean boolean12 = legendTitle11.visible;
        legendTitle11.setHeight((double) 8);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle11.getLegendItemGraphicEdge();
        org.jfree.chart.axis.AxisState axisState16 = null;
        categoryAxis1.drawTickMarks(graphics2D3, (double) ' ', rectangle2D5, rectangleEdge15, axisState16);
        try {
            double double18 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYStepRenderer2.getBaseToolTipGenerator();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Combined_Domain_XYPlot", font5);
        xYStepRenderer2.setBaseItemLabelFont(font5);
        boolean boolean9 = xYStepRenderer2.equals((java.lang.Object) (byte) 1);
        boolean boolean12 = xYStepRenderer2.getItemShapeVisible(6, 2019);
        boolean boolean13 = xYStepRenderer2.getBaseLinesVisible();
        java.lang.Boolean boolean15 = xYStepRenderer2.getSeriesShapesVisible(1);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(boolean15);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        int int6 = combinedDomainXYPlot0.getSeriesCount();
        int int7 = combinedDomainXYPlot0.getBackgroundImageAlignment();
        int int8 = combinedDomainXYPlot0.getRendererCount();
        java.lang.String str9 = combinedDomainXYPlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        try {
            org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getFollowingDayOfWeek(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        double double5 = logAxis1.calculateValue(0.0d);
        boolean boolean6 = logAxis1.isTickLabelsVisible();
        java.awt.Font font7 = logAxis1.getLabelFont();
        java.awt.Paint paint8 = logAxis1.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        int int1 = dateTickUnitType0.getCalendarField();
        java.text.DateFormat dateFormat3 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 0, dateFormat3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter(4.0d, (double) (byte) 10, 0.0d);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer5.setBaseCreateEntities(false);
        java.awt.geom.RectangularShape rectangularShape11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer15);
        boolean boolean18 = legendTitle17.visible;
        legendTitle17.setHeight((double) 8);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = legendTitle17.getLegendItemGraphicEdge();
        try {
            gradientBarPainter3.paintBarShadow(graphics2D4, barRenderer5, (int) (short) 100, 9999, true, rectangularShape11, rectangleEdge21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray14);
        java.lang.Number number16 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        try {
            org.jfree.data.general.PieDataset pieDataset18 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset15, (-4767));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1.0d + "'", number16.equals(1.0d));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        xYBarRenderer0.setAutoPopulateSeriesStroke(false);
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = xYBarRenderer0.hasListener(eventListener4);
        java.awt.Paint paint9 = xYBarRenderer0.getItemPaint(9999, 5, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        org.jfree.chart.LegendItem legendItem8 = xYStepRenderer2.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        combinedDomainXYPlot13.setFixedLegendItems(legendItemCollection14);
        java.awt.Paint paint16 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot13.setDomainGridlinePaint(paint16);
        boolean boolean18 = combinedDomainXYPlot13.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        combinedDomainXYPlot13.setDataset((int) (short) 0, xYDataset20);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.RenderingSource renderingSource25 = null;
        combinedDomainXYPlot13.select((double) 1L, (double) ' ', rectangle2D24, renderingSource25);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection27 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D28.setMinimumArcAngleToDraw((double) (byte) -1);
        double double31 = piePlot3D28.getInteriorGap();
        piePlot3D28.setDarkerSides(false);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D36.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D36.setLabelLinkStroke(stroke39);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint43.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart47 = chartChangeEvent46.getChart();
        boolean boolean48 = chartRenderingInfo42.equals((java.lang.Object) chartChangeEvent46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = chartRenderingInfo42.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState50 = piePlot3D28.initialise(graphics2D34, rectangle2D35, (org.jfree.chart.plot.PiePlot) piePlot3D36, (java.lang.Integer) 0, plotRenderingInfo49);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState51 = xYStepRenderer2.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13, (org.jfree.data.xy.XYDataset) xYSeriesCollection27, plotRenderingInfo49);
        xYStepRenderer2.setSeriesShapesVisible(9999, true);
        java.awt.Shape shape55 = null;
        try {
            xYStepRenderer2.setLegendLine(shape55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'line' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.08d + "'", double31 == 0.08d);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNull(jFreeChart47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo49);
        org.junit.Assert.assertNotNull(piePlotState50);
        org.junit.Assert.assertNotNull(xYItemRendererState51);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        java.awt.Font font3 = waferMapPlot2.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str1.equals("java.awt.Color[r=128,g=128,b=255]"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        java.awt.Font font3 = xYBarRenderer0.lookupLegendTextFont(3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = xYBarRenderer0.getGradientPaintTransformer();
        xYBarRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        double double5 = logAxis1.calculateValue(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = logAxis1.getLabelInsets();
        java.lang.Object obj7 = null;
        boolean boolean8 = logAxis1.equals(obj7);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        piePlot3D0.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean9 = piePlot3D8.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        java.awt.Shape shape12 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.plot.Plot plot13 = piePlot3D0.getRootPlot();
        java.awt.Paint paint15 = piePlot3D0.getSectionOutlinePaint((java.lang.Comparable) "12-January-1900");
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint21.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart25 = chartChangeEvent24.getChart();
        boolean boolean26 = chartRenderingInfo20.equals((java.lang.Object) chartChangeEvent24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = chartRenderingInfo20.getPlotInfo();
        try {
            org.jfree.chart.plot.PiePlotState piePlotState28 = piePlot3D0.initialise(graphics2D16, rectangle2D17, piePlot18, (java.lang.Integer) 2958465, plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(plot13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNull(jFreeChart25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo27);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        java.lang.String str1 = horizontalAlignment0.toString();
        java.lang.String str2 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.CENTER" + "'", str1.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HorizontalAlignment.CENTER" + "'", str2.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        java.awt.Font font3 = xYBarRenderer0.lookupLegendTextFont(3);
        xYBarRenderer0.setSeriesVisible((int) (byte) 0, (java.lang.Boolean) true, true);
        java.awt.Stroke stroke9 = xYBarRenderer0.getSeriesOutlineStroke(13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNull(stroke9);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.valueToJava2D(3.0d, rectangle2D2, rectangleEdge3);
        boolean boolean5 = dateAxis0.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        try {
            java.lang.Number number4 = xYSeriesCollection1.getStartY((int) (short) 0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator7 = logFormat5.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat5, (int) (byte) -1);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.BLACK;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12);
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font11, (java.awt.Paint) color12);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = null;
        textBlock14.draw(graphics2D15, (float) (short) 10, (float) '#', textBlockAnchor18, (float) 'a', (float) (-4767), (double) 1.0f);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.util.Size2D size2D24 = textBlock14.calculateDimensions(graphics2D23);
        int int25 = numberTickUnit9.compareTo((java.lang.Object) size2D24);
        int int27 = numberTickUnit9.compareTo((java.lang.Object) 2.0d);
        org.junit.Assert.assertNotNull(attributedCharacterIterator7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator7 = logFormat5.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat5, (int) (byte) -1);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.BLACK;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12);
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font11, (java.awt.Paint) color12);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = null;
        textBlock14.draw(graphics2D15, (float) (short) 10, (float) '#', textBlockAnchor18, (float) 'a', (float) (-4767), (double) 1.0f);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.util.Size2D size2D24 = textBlock14.calculateDimensions(graphics2D23);
        int int25 = numberTickUnit9.compareTo((java.lang.Object) size2D24);
        size2D24.height = (-1);
        org.junit.Assert.assertNotNull(attributedCharacterIterator7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem2.setSeriesIndex((int) '4');
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray10, numberArray14, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset20);
        legendItem2.setDataset((org.jfree.data.general.Dataset) categoryDataset20);
        boolean boolean23 = textBlockAnchor0.equals((java.lang.Object) categoryDataset20);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.0d + "'", number21.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = null;
        java.awt.geom.Point2D point2D6 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D4, rectangleAnchor5);
        polarPlot0.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo3, point2D6);
        boolean boolean8 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean11 = logAxis10.isInverted();
        org.jfree.data.Range range12 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis10);
        logAxis10.setVerticalTickLabels(false);
        logAxis10.setFixedAutoRange((double) (-1L));
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer3.setSeriesOutlinePaint((int) (short) 10, paint5);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        combinedDomainXYPlot7.setFixedLegendItems(legendItemCollection8);
        java.awt.Paint paint10 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot7.setDomainGridlinePaint(paint10);
        boolean boolean12 = combinedDomainXYPlot7.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        combinedDomainXYPlot7.setDataset((int) (short) 0, xYDataset14);
        combinedDomainXYPlot7.setBackgroundImageAlignment((int) (byte) -1);
        int int18 = combinedDomainXYPlot7.getDatasetCount();
        xYBarRenderer3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot7);
        java.awt.Font font21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer3.setLegendTextFont((int) (short) 100, font21);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) month2, font21);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot24.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        combinedDomainXYPlot27.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot27.setDomainGridlinePaint(paint30);
        boolean boolean32 = combinedDomainXYPlot27.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        combinedDomainXYPlot27.setDataset((int) (short) 0, xYDataset34);
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.RenderingSource renderingSource39 = null;
        combinedDomainXYPlot27.select((double) 1L, (double) ' ', rectangle2D38, renderingSource39);
        java.lang.String str41 = combinedDomainXYPlot27.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset43 = combinedDomainXYPlot27.getDataset((int) (short) 1);
        org.jfree.chart.axis.LogAxis logAxis45 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean46 = logAxis45.isInverted();
        logAxis45.resizeRange(0.0d);
        org.jfree.data.Range range49 = combinedDomainXYPlot27.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis45);
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray57 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray58 = color52.getRGBColorComponents(floatArray57);
        int int59 = color52.getAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker60 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, (double) (-2208960000000L), (java.awt.Paint) color52);
        combinedDomainXYPlot27.setDomainMinorGridlinePaint((java.awt.Paint) color52);
        combinedDomainXYPlot24.setNoDataMessagePaint((java.awt.Paint) color52);
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color52);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions64 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Combined_Domain_XYPlot" + "'", str41.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYDataset43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 255 + "'", int59 == 255);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        piePlot3D0.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean9 = piePlot3D8.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        java.awt.Shape shape12 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.plot.Plot plot13 = piePlot3D0.getRootPlot();
        java.awt.Paint paint15 = piePlot3D0.getSectionOutlinePaint((java.lang.Comparable) "12-January-1900");
        java.awt.Stroke stroke16 = piePlot3D0.getLabelLinkStroke();
        boolean boolean17 = piePlot3D0.getAutoPopulateSectionPaint();
        org.jfree.chart.plot.Plot plot18 = piePlot3D0.getParent();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(plot13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(plot18);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMinimumArcAngleToDraw((double) (byte) -1);
        double double3 = piePlot3D0.getInteriorGap();
        piePlot3D0.setDarkerSides(false);
        piePlot3D0.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean9 = piePlot3D8.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator10);
        java.awt.Shape shape12 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeSeries14);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        polarPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot13);
        java.util.List list19 = jFreeChart18.getSubtitles();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity20 = new org.jfree.chart.entity.JFreeChartEntity(shape12, jFreeChart18);
        org.jfree.chart.axis.LogAxis logAxis22 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis22.pan(0.0d);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.AxisState axisState26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        java.util.List list29 = logAxis22.refreshTicks(graphics2D25, axisState26, rectangle2D27, rectangleEdge28);
        org.jfree.chart.util.LogFormat logFormat36 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator38 = logFormat36.formatToCharacterIterator((java.lang.Object) 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit40 = new org.jfree.chart.axis.NumberTickUnit((double) '4', (java.text.NumberFormat) logFormat36, (int) (byte) -1);
        org.jfree.chart.util.LogFormat logFormat45 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        logFormat45.setMinimumIntegerDigits((int) (short) 100);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator48 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined_Domain_XYPlot", (java.text.NumberFormat) logFormat36, (java.text.NumberFormat) logFormat45);
        java.lang.String str50 = logFormat36.format(0.0d);
        org.jfree.chart.util.LogFormat logFormat55 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator57 = logFormat55.formatToCharacterIterator((java.lang.Object) 0);
        java.lang.String str59 = logFormat55.format((double) 10);
        logFormat36.setExponentFormat((java.text.NumberFormat) logFormat55);
        logAxis22.setNumberFormatOverride((java.text.NumberFormat) logFormat55);
        org.jfree.chart.entity.AxisEntity axisEntity64 = new org.jfree.chart.entity.AxisEntity(shape12, (org.jfree.chart.axis.Axis) logAxis22, "Pie 3D Plot", "Nearest");
        logAxis22.setLabelToolTip("Pie 3D Plot");
        logAxis22.setBase(90.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(attributedCharacterIterator38);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!�" + "'", str50.equals("hi!�"));
        org.junit.Assert.assertNotNull(attributedCharacterIterator57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!-0.0" + "'", str59.equals("hi!-0.0"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod2, (double) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem4.getPeriod();
        boolean boolean6 = timeSeriesDataItem4.isSelected();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        java.text.AttributedCharacterIterator attributedCharacterIterator6 = logFormat4.formatToCharacterIterator((java.lang.Object) 0);
        java.lang.String str8 = logFormat4.format((double) 10);
        java.lang.String str10 = logFormat4.format((double) 1560668399999L);
        org.junit.Assert.assertNotNull(attributedCharacterIterator6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!-0.0" + "'", str8.equals("hi!-0.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!-0.0" + "'", str10.equals("hi!-0.0"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.block.CenterArrangement centerArrangement1 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement1.add((org.jfree.chart.block.Block) labelBlock3, (java.lang.Object) 100L);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        labelBlock3.setContentAlignmentPoint(textBlockAnchor6);
        java.awt.Font font8 = labelBlock3.getFont();
        java.awt.Color color9 = java.awt.Color.BLACK;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color9);
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("Pie 3D Plot", font8, (java.awt.Paint) color9, (float) 4);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 0L, "hi!", "", true);
        logFormat4.setMinimumIntegerDigits((int) (short) 100);
        logFormat4.setParseIntegerOnly(true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        double double5 = logAxis1.calculateValue(0.0d);
        boolean boolean6 = logAxis1.isTickLabelsVisible();
        java.awt.Font font7 = logAxis1.getLabelFont();
        logAxis1.zoomRange((double) (-16777216), (double) (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        int int6 = combinedDomainXYPlot0.getSeriesCount();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeSeries10);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        polarPlot9.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot9);
        java.util.List list15 = jFreeChart14.getSubtitles();
        combinedDomainXYPlot0.drawRangeTickBands(graphics2D7, rectangle2D8, list15);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        int int2 = crosshairState1.getRangeAxisIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = null;
        java.awt.geom.Point2D point2D6 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D4, rectangleAnchor5);
        polarPlot0.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo3, point2D6);
        boolean boolean8 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("hi!�");
        boolean boolean11 = logAxis10.isInverted();
        org.jfree.data.Range range12 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis10);
        java.lang.String str13 = logAxis10.getLabel();
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!�" + "'", str13.equals("hi!�"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth((double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedWidth((double) (-2208960000000L));
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.Class class3 = null;
        try {
            java.util.EventListener[] eventListenerArray4 = intervalMarker2.getListeners(class3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 0);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape1, "June 2019");
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis2.pan(0.0d);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = logAxis2.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        projectInfo0.setContributors(list9);
        java.lang.String str11 = projectInfo0.getName();
        java.lang.String str12 = projectInfo0.getName();
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer2.setBaseItemLabelPaint(paint3, false);
        double double6 = xYStepRenderer2.getItemLabelAnchorOffset();
        java.lang.Object obj7 = xYStepRenderer2.clone();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer3);
        boolean boolean6 = legendTitle5.visible;
        java.lang.String str7 = legendTitle5.getID();
        org.jfree.chart.block.CenterArrangement centerArrangement8 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("hi!");
        centerArrangement8.add((org.jfree.chart.block.Block) labelBlock10, (java.lang.Object) 100L);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray18, numberArray22, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28, (double) (-2208960000000L));
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer32 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement8, (org.jfree.data.general.Dataset) categoryDataset28, (java.lang.Comparable) (short) 1);
        java.lang.Object obj33 = legendItemBlockContainer32.clone();
        legendTitle5.setWrapper((org.jfree.chart.block.BlockContainer) legendItemBlockContainer32);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYStepRenderer2.getLegendItems();
        int int4 = xYStepRenderer2.getPassCount();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection6, valueAxis7, polarItemRenderer8);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator10, xYURLGenerator11);
        java.awt.Paint paint13 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer12.setBaseItemLabelPaint(paint13, false);
        org.jfree.chart.LegendItem legendItem18 = xYStepRenderer12.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer12.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = null;
        combinedDomainXYPlot23.setFixedLegendItems(legendItemCollection24);
        java.awt.Paint paint26 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot23.setDomainGridlinePaint(paint26);
        boolean boolean28 = combinedDomainXYPlot23.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        combinedDomainXYPlot23.setDataset((int) (short) 0, xYDataset30);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.RenderingSource renderingSource35 = null;
        combinedDomainXYPlot23.select((double) 1L, (double) ' ', rectangle2D34, renderingSource35);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection37 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D38 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D38.setMinimumArcAngleToDraw((double) (byte) -1);
        double double41 = piePlot3D38.getInteriorGap();
        piePlot3D38.setDarkerSides(false);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D46 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D46.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D46.setLabelLinkStroke(stroke49);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo52 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint53 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = rectangleConstraint53.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent56 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart57 = chartChangeEvent56.getChart();
        boolean boolean58 = chartRenderingInfo52.equals((java.lang.Object) chartChangeEvent56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = chartRenderingInfo52.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState60 = piePlot3D38.initialise(graphics2D44, rectangle2D45, (org.jfree.chart.plot.PiePlot) piePlot3D46, (java.lang.Integer) 0, plotRenderingInfo59);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState61 = xYStepRenderer12.initialise(graphics2D21, rectangle2D22, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot23, (org.jfree.data.xy.XYDataset) xYSeriesCollection37, plotRenderingInfo59);
        timeSeriesCollection6.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection37);
        boolean boolean63 = xYStepRenderer2.equals((java.lang.Object) xYSeriesCollection37);
        int int64 = xYSeriesCollection37.getSeriesCount();
        try {
            double double67 = xYSeriesCollection37.getEndYValue(10, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItem18);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.08d + "'", double41 == 0.08d);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(rectangleConstraint53);
        org.junit.Assert.assertNotNull(rectangleConstraint55);
        org.junit.Assert.assertNull(jFreeChart57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo59);
        org.junit.Assert.assertNotNull(piePlotState60);
        org.junit.Assert.assertNotNull(xYItemRendererState61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        int int6 = combinedDomainXYPlot0.getSeriesCount();
        boolean boolean7 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer9.setSeriesOutlinePaint((int) (short) 10, paint11);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        combinedDomainXYPlot13.setFixedLegendItems(legendItemCollection14);
        java.awt.Paint paint16 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot13.setDomainGridlinePaint(paint16);
        boolean boolean18 = combinedDomainXYPlot13.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        combinedDomainXYPlot13.setDataset((int) (short) 0, xYDataset20);
        combinedDomainXYPlot13.setBackgroundImageAlignment((int) (byte) -1);
        int int24 = combinedDomainXYPlot13.getDatasetCount();
        xYBarRenderer9.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot13);
        xYBarRenderer9.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot29 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        combinedDomainXYPlot29.setFixedLegendItems(legendItemCollection30);
        java.awt.Paint paint32 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot29.setDomainGridlinePaint(paint32);
        boolean boolean34 = combinedDomainXYPlot29.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        combinedDomainXYPlot29.setDataset((int) (short) 0, xYDataset36);
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.RenderingSource renderingSource41 = null;
        combinedDomainXYPlot29.select((double) 1L, (double) ' ', rectangle2D40, renderingSource41);
        java.lang.String str43 = combinedDomainXYPlot29.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = combinedDomainXYPlot29.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray59 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray60 = new java.lang.Number[][] { numberArray51, numberArray55, numberArray59 };
        org.jfree.data.category.CategoryDataset categoryDataset61 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray60);
        org.jfree.data.Range range63 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset61, (double) (-2208960000000L));
        double double64 = range63.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint66 = new org.jfree.chart.block.RectangleConstraint(range63, 100.0d);
        boolean boolean69 = range63.intersects((double) (byte) 10, (double) 9999);
        dateAxis45.setRange(range63, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker75 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str76 = intervalMarker75.getLabel();
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        xYBarRenderer9.drawRangeMarker(graphics2D28, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot29, (org.jfree.chart.axis.ValueAxis) dateAxis45, (org.jfree.chart.plot.Marker) intervalMarker75, rectangle2D77);
        combinedDomainXYPlot29.setGap((double) 12);
        org.jfree.chart.util.Layer layer81 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection82 = combinedDomainXYPlot29.getDomainMarkers(layer81);
        java.util.Collection collection83 = combinedDomainXYPlot0.getRangeMarkers((int) (byte) 0, layer81);
        org.jfree.chart.plot.IntervalMarker intervalMarker86 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.awt.Stroke stroke87 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        intervalMarker86.setStroke(stroke87);
        org.jfree.chart.util.Layer layer89 = org.jfree.chart.util.Layer.BACKGROUND;
        combinedDomainXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker86, layer89);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Combined_Domain_XYPlot" + "'", str43.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer44);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(categoryDataset61);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + (-2.20896E12d) + "'", double64 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNull(str76);
        org.junit.Assert.assertNotNull(layer81);
        org.junit.Assert.assertNull(collection82);
        org.junit.Assert.assertNull(collection83);
        org.junit.Assert.assertNotNull(stroke87);
        org.junit.Assert.assertNotNull(layer89);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        combinedDomainXYPlot20.setFixedLegendItems(legendItemCollection21);
        java.awt.Paint paint23 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot20.setDomainGridlinePaint(paint23);
        boolean boolean25 = combinedDomainXYPlot20.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        combinedDomainXYPlot20.setDataset((int) (short) 0, xYDataset27);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedDomainXYPlot20.select((double) 1L, (double) ' ', rectangle2D31, renderingSource32);
        java.lang.String str34 = combinedDomainXYPlot20.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray42, numberArray46, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset52, (double) (-2208960000000L));
        double double55 = range54.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range54, 100.0d);
        boolean boolean60 = range54.intersects((double) (byte) 10, (double) 9999);
        dateAxis36.setRange(range54, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str67 = intervalMarker66.getLabel();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        xYBarRenderer0.drawRangeMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.plot.Marker) intervalMarker66, rectangle2D68);
        org.jfree.data.Range range70 = dateAxis36.getRange();
        java.util.TimeZone timeZone72 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis73 = new org.jfree.chart.axis.DateAxis("Nearest", timeZone72);
        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month();
        int int75 = month74.getYearValue();
        java.util.Date date76 = month74.getEnd();
        dateAxis73.setMaximumDate(date76);
        java.awt.geom.Rectangle2D rectangle2D78 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot79 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot79.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.Layer layer83 = null;
        java.util.Collection collection84 = combinedDomainXYPlot79.getRangeMarkers((int) (short) 1, layer83);
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = combinedDomainXYPlot79.getRangeAxisEdge((int) (byte) -1);
        try {
            double double87 = dateAxis36.dateToJava2D(date76, rectangle2D78, rectangleEdge86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-2.20896E12d) + "'", double55 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2019 + "'", int75 == 2019);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNull(collection84);
        org.junit.Assert.assertNotNull(rectangleEdge86);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = xYBarRenderer0.getURLGenerator((-398), (int) (short) 10, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(xYURLGenerator7);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer7 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator5, xYURLGenerator6);
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYStepRenderer7.setBaseItemLabelPaint(paint8, false);
        org.jfree.chart.LegendItem legendItem13 = xYStepRenderer7.getLegendItem((int) (byte) 10, (int) (byte) 0);
        xYStepRenderer7.setDrawSeriesLineAsPath(false);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = null;
        combinedDomainXYPlot18.setFixedLegendItems(legendItemCollection19);
        java.awt.Paint paint21 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot18.setDomainGridlinePaint(paint21);
        boolean boolean23 = combinedDomainXYPlot18.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        combinedDomainXYPlot18.setDataset((int) (short) 0, xYDataset25);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.RenderingSource renderingSource30 = null;
        combinedDomainXYPlot18.select((double) 1L, (double) ' ', rectangle2D29, renderingSource30);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection32 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D33.setMinimumArcAngleToDraw((double) (byte) -1);
        double double36 = piePlot3D33.getInteriorGap();
        piePlot3D33.setDarkerSides(false);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D41 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D41.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D41.setLabelLinkStroke(stroke44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = rectangleConstraint48.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent51 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart52 = chartChangeEvent51.getChart();
        boolean boolean53 = chartRenderingInfo47.equals((java.lang.Object) chartChangeEvent51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = chartRenderingInfo47.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState55 = piePlot3D33.initialise(graphics2D39, rectangle2D40, (org.jfree.chart.plot.PiePlot) piePlot3D41, (java.lang.Integer) 0, plotRenderingInfo54);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState56 = xYStepRenderer7.initialise(graphics2D16, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot18, (org.jfree.data.xy.XYDataset) xYSeriesCollection32, plotRenderingInfo54);
        timeSeriesCollection1.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection32);
        org.jfree.data.Range range59 = xYSeriesCollection32.getDomainBounds(false);
        double double60 = xYSeriesCollection32.getIntervalPositionFactor();
        try {
            boolean boolean63 = xYSeriesCollection32.isSelected((int) 'a', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.08d + "'", double36 == 0.08d);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
        org.junit.Assert.assertNotNull(rectangleConstraint50);
        org.junit.Assert.assertNull(jFreeChart52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo54);
        org.junit.Assert.assertNotNull(piePlotState55);
        org.junit.Assert.assertNotNull(xYItemRendererState56);
        org.junit.Assert.assertNull(range59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.5d + "'", double60 == 0.5d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        java.lang.Object obj1 = null;
        boolean boolean2 = dateTickUnitType0.equals(obj1);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = null;
        java.awt.geom.Point2D point2D6 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D4, rectangleAnchor5);
        polarPlot0.zoomDomainAxes(0.0d, (double) (byte) 1, plotRenderingInfo3, point2D6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        polarPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D(pieDataset10);
        boolean boolean12 = polarPlot0.equals((java.lang.Object) piePlot3D11);
        boolean boolean13 = piePlot3D11.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint1.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart5 = chartChangeEvent4.getChart();
        boolean boolean6 = chartRenderingInfo0.equals((java.lang.Object) chartChangeEvent4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = chartRenderingInfo0.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection8 = null;
        chartRenderingInfo0.setEntityCollection(entityCollection8);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNull(jFreeChart5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo7);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
        double double3 = xYSeriesCollection1.getDomainLowerBound(false);
        xYSeriesCollection1.validateObject();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Stroke stroke2 = piePlot3D1.getLabelOutlineStroke();
        piePlot3D1.setNoDataMessage("Combined_Domain_XYPlot");
        org.jfree.data.general.PieDataset pieDataset5 = piePlot3D1.getDataset();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(pieDataset5);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        java.awt.Font font3 = xYBarRenderer0.lookupLegendTextFont(3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = xYBarRenderer0.getGradientPaintTransformer();
        boolean boolean8 = xYBarRenderer0.getItemCreateEntity(2019, (int) (byte) 1, false);
        xYBarRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean11 = xYBarRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        combinedDomainXYPlot0.setRenderer(xYItemRenderer3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray10 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray11 = color5.getRGBColorComponents(floatArray10);
        int int12 = color5.getAlpha();
        combinedDomainXYPlot0.setRangeTickBandPaint((java.awt.Paint) color5);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray22 = new float[] { (byte) 1, 100.0f, 1.0f, 1.0f };
        float[] floatArray23 = color17.getRGBColorComponents(floatArray22);
        int int24 = color17.getAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) 0.0f, (double) (-2208960000000L), (java.awt.Paint) color17);
        java.awt.Color color26 = java.awt.Color.getColor("Pie 3D Plot", color17);
        float[] floatArray27 = null;
        float[] floatArray28 = color17.getColorComponents(floatArray27);
        float[] floatArray29 = color5.getColorComponents(floatArray27);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem1.setSeriesIndex((int) '4');
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray9, numberArray13, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray18);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset19);
        legendItem1.setDataset((org.jfree.data.general.Dataset) categoryDataset19);
        boolean boolean22 = legendItem1.isShapeFilled();
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.0d + "'", number20.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        double double5 = logAxis1.calculateValue(0.0d);
        boolean boolean6 = logAxis1.isTickLabelsVisible();
        logAxis1.setAutoRangeMinimumSize((double) 5, false);
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D14.setMinimumArcAngleToDraw((double) (byte) -1);
        double double17 = piePlot3D14.getInteriorGap();
        piePlot3D14.setDarkerSides(false);
        piePlot3D14.setStartAngle(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D22 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean23 = piePlot3D22.getDarkerSides();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator24 = piePlot3D22.getLegendLabelGenerator();
        piePlot3D14.setLegendLabelGenerator(pieSectionLabelGenerator24);
        java.awt.Shape shape26 = piePlot3D14.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries28 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection29 = new org.jfree.data.time.TimeSeriesCollection(timeSeries28);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection29);
        polarPlot27.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection29);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot27);
        java.util.List list33 = jFreeChart32.getSubtitles();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity34 = new org.jfree.chart.entity.JFreeChartEntity(shape26, jFreeChart32);
        java.awt.Paint paint35 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("Last", "HorizontalAlignment.CENTER", "Pie 3D Plot", "", shape26, paint35);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity39 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis1, shape26, "hi!�", "hi!�");
        double double40 = logAxis1.getBase();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.08d + "'", double17 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 10.0d + "'", double40 == 10.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        logAxis1.setMinorTickCount((int) (byte) 100);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = null;
        combinedDomainXYPlot6.setFixedLegendItems(legendItemCollection7);
        java.awt.Paint paint9 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot6.setDomainGridlinePaint(paint9);
        boolean boolean11 = combinedDomainXYPlot6.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        combinedDomainXYPlot6.setDataset((int) (short) 0, xYDataset13);
        combinedDomainXYPlot6.setBackgroundImageAlignment((int) (byte) -1);
        int int17 = combinedDomainXYPlot6.getDatasetCount();
        java.awt.Paint paint18 = combinedDomainXYPlot6.getBackgroundPaint();
        logAxis1.setLabelPaint(paint18);
        boolean boolean20 = logAxis1.isInverted();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer3);
        boolean boolean6 = legendTitle5.visible;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle5.getPosition();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = null;
        combinedDomainXYPlot8.setFixedLegendItems(legendItemCollection9);
        java.awt.Paint paint11 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot8.setDomainGridlinePaint(paint11);
        boolean boolean13 = combinedDomainXYPlot8.canSelectByPoint();
        combinedDomainXYPlot8.clearDomainAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = combinedDomainXYPlot8.getAxisOffset();
        double double17 = rectangleInsets15.calculateRightOutset((double) 0);
        legendTitle5.setPadding(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = combinedDomainXYPlot0.getRangeMarkers((int) (short) 1, layer4);
        boolean boolean6 = combinedDomainXYPlot0.isDomainCrosshairVisible();
        java.awt.Stroke stroke7 = combinedDomainXYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis8.valueToJava2D(3.0d, rectangle2D10, rectangleEdge11);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = null;
        combinedDomainXYPlot13.setFixedLegendItems(legendItemCollection14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.plot.CrosshairState crosshairState20 = null;
        boolean boolean21 = combinedDomainXYPlot13.render(graphics2D16, rectangle2D17, (int) 'a', plotRenderingInfo19, crosshairState20);
        dateAxis8.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot13);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis23.getTickLabelInsets();
        org.jfree.chart.axis.Timeline timeline25 = dateAxis23.getTimeline();
        java.util.TimeZone timeZone26 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        dateAxis23.setTimeZone(timeZone26);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { dateAxis8, dateAxis23 };
        combinedDomainXYPlot0.setDomainAxes(valueAxisArray28);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(timeline25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(valueAxisArray28);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("June 2019");
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("Combined_Domain_XYPlot", dateFormat1, dateFormat2);
        org.jfree.data.xy.XYSeries xYSeries4 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection(xYSeries4);
        try {
            java.lang.String str8 = standardXYToolTipGenerator3.generateLabelString((org.jfree.data.xy.XYDataset) xYSeriesCollection5, 6, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod2, (double) (short) 100);
        java.lang.Number number5 = timeSeriesDataItem4.getValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0d + "'", number5.equals(100.0d));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        combinedDomainXYPlot0.setBackgroundImageAlignment((int) (byte) -1);
        int int11 = combinedDomainXYPlot0.getDatasetCount();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis15.pan(0.0d);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.AxisState axisState19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        java.util.List list22 = logAxis15.refreshTicks(graphics2D18, axisState19, rectangle2D20, rectangleEdge21);
        combinedDomainXYPlot0.drawRangeTickBands(graphics2D12, rectangle2D13, list22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = combinedDomainXYPlot0.getDomainAxisLocation(100);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray6, numberArray10, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset16, (double) (-2208960000000L));
        double double19 = range18.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range18, 100.0d);
        boolean boolean24 = range18.intersects((double) (byte) 10, (double) 9999);
        dateAxis0.setRange(range18, true, false);
        org.jfree.chart.axis.Timeline timeline28 = dateAxis0.getTimeline();
        java.lang.Object obj29 = dateAxis0.clone();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-2.20896E12d) + "'", double19 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeline28);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.valueToJava2D(3.0d, rectangle2D2, rectangleEdge3);
        dateAxis0.setRange((double) (byte) -1, 0.025d);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D10.setMinimumArcAngleToDraw((double) (byte) -1);
        double double13 = piePlot3D10.getInteriorGap();
        piePlot3D10.setDarkerSides(false);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D18 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D18.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D18.setLabelLinkStroke(stroke21);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint25.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart29 = chartChangeEvent28.getChart();
        boolean boolean30 = chartRenderingInfo24.equals((java.lang.Object) chartChangeEvent28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = chartRenderingInfo24.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState32 = piePlot3D10.initialise(graphics2D16, rectangle2D17, (org.jfree.chart.plot.PiePlot) piePlot3D18, (java.lang.Integer) 0, plotRenderingInfo31);
        java.awt.geom.Rectangle2D rectangle2D33 = plotRenderingInfo31.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            java.util.List list35 = dateAxis0.refreshTicks(graphics2D8, axisState9, rectangle2D33, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.08d + "'", double13 == 0.08d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertNull(jFreeChart29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo31);
        org.junit.Assert.assertNotNull(piePlotState32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 10, paint2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        combinedDomainXYPlot4.setFixedLegendItems(legendItemCollection5);
        java.awt.Paint paint7 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot4.setDomainGridlinePaint(paint7);
        boolean boolean9 = combinedDomainXYPlot4.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        combinedDomainXYPlot4.setDataset((int) (short) 0, xYDataset11);
        combinedDomainXYPlot4.setBackgroundImageAlignment((int) (byte) -1);
        int int15 = combinedDomainXYPlot4.getDatasetCount();
        xYBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot4);
        xYBarRenderer0.setShadowXOffset(45.0d);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem20.setShapeVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer23 = legendItem20.getFillPaintTransformer();
        xYBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer23);
        boolean boolean28 = xYBarRenderer0.isItemLabelVisible((int) '4', (-4767), true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        xYBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = xYBarRenderer0.getDrawingSupplier();
        xYBarRenderer0.setShadowYOffset((double) 0L);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYBarRenderer0.setSeriesURLGenerator((int) 'a', xYURLGenerator8, false);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator13 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        xYBarRenderer0.setSeriesURLGenerator(8, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator13);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor15 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor15, textAnchor16);
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor15, textAnchor18, textAnchor19, 10.0d);
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition21);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(itemLabelAnchor15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", dateFormat1, dateFormat2);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CrosshairState crosshairState13 = null;
        boolean boolean14 = combinedDomainXYPlot0.render(graphics2D9, rectangle2D10, 10, plotRenderingInfo12, crosshairState13);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        org.jfree.chart.util.Layer layer19 = null;
        combinedDomainXYPlot0.addRangeMarker((-4767), (org.jfree.chart.plot.Marker) intervalMarker18, layer19, true);
        boolean boolean22 = combinedDomainXYPlot0.isDomainMinorGridlinesVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.valueToJava2D(3.0d, rectangle2D2, rectangleEdge3);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = null;
        combinedDomainXYPlot5.setFixedLegendItems(legendItemCollection6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.CrosshairState crosshairState12 = null;
        boolean boolean13 = combinedDomainXYPlot5.render(graphics2D8, rectangle2D9, (int) 'a', plotRenderingInfo11, crosshairState12);
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot5);
        double double15 = combinedDomainXYPlot5.getRangeCrosshairValue();
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.data.time.TimeSeries timeSeries17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeSeries17);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        polarPlot16.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot16);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        jFreeChart21.setBackgroundPaint((java.awt.Paint) color22);
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart21.createBufferedImage(8, (int) (short) 1);
        combinedDomainXYPlot5.setBackgroundImage((java.awt.Image) bufferedImage26);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(bufferedImage26);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        crosshairState1.setDatasetIndex(15);
        double double4 = crosshairState1.getCrosshairDistance();
        crosshairState1.updateCrosshairX((double) 2019, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator(13, categoryToolTipGenerator2);
        java.awt.Paint paint4 = barRenderer0.getBaseLegendTextPaint();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D7.setMinimumArcAngleToDraw((double) (byte) -1);
        double double10 = piePlot3D7.getInteriorGap();
        piePlot3D7.setDarkerSides(false);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D15.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D15.setLabelLinkStroke(stroke18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint22.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart26 = chartChangeEvent25.getChart();
        boolean boolean27 = chartRenderingInfo21.equals((java.lang.Object) chartChangeEvent25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = chartRenderingInfo21.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState29 = piePlot3D7.initialise(graphics2D13, rectangle2D14, (org.jfree.chart.plot.PiePlot) piePlot3D15, (java.lang.Integer) 0, plotRenderingInfo28);
        java.awt.geom.Rectangle2D rectangle2D30 = plotRenderingInfo28.getDataArea();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYItemRenderer35);
        boolean boolean38 = legendTitle37.visible;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = legendTitle37.getPosition();
        java.awt.Color color40 = java.awt.Color.BLACK;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color40);
        legendTitle37.setBackgroundPaint((java.awt.Paint) color40);
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem44.setSeriesIndex((int) '4');
        java.lang.Number[] numberArray52 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray56 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray60 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray61 = new java.lang.Number[][] { numberArray52, numberArray56, numberArray60 };
        org.jfree.data.category.CategoryDataset categoryDataset62 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray61);
        java.lang.Number number63 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset62);
        legendItem44.setDataset((org.jfree.data.general.Dataset) categoryDataset62);
        java.awt.Stroke stroke65 = legendItem44.getOutlineStroke();
        try {
            barRenderer0.drawDomainLine(graphics2D5, categoryPlot6, rectangle2D30, (double) 12, (java.awt.Paint) color40, stroke65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.08d + "'", double10 == 0.08d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNull(jFreeChart26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo28);
        org.junit.Assert.assertNotNull(piePlotState29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(categoryDataset62);
        org.junit.Assert.assertTrue("'" + number63 + "' != '" + 1.0d + "'", number63.equals(1.0d));
        org.junit.Assert.assertNotNull(stroke65);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("June 2019", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.valueToJava2D(3.0d, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.Timeline timeline5 = dateAxis0.getTimeline();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(timeline5);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem1.setSeriesIndex((int) '4');
        boolean boolean5 = legendItem1.equals((java.lang.Object) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseCreateEntities(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint7 = barRenderer0.getItemOutlinePaint(2958465, 5, false);
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        xYBarRenderer0.setAutoPopulateSeriesStroke(false);
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = xYBarRenderer0.hasListener(eventListener4);
        java.awt.Stroke stroke7 = xYBarRenderer0.getSeriesStroke(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(stroke7);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = null;
        xYBarRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator2, true);
        java.awt.Paint paint5 = xYBarRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = xYBarRenderer0.getSeriesToolTipGenerator((-398));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(xYToolTipGenerator7);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = combinedDomainXYPlot0.getRangeMarkers((int) (short) 1, layer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = combinedDomainXYPlot0.getRangeAxisEdge((int) (byte) -1);
        java.awt.Paint paint8 = combinedDomainXYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        int int6 = combinedDomainXYPlot0.getSeriesCount();
        boolean boolean7 = combinedDomainXYPlot0.canSelectByPoint();
        combinedDomainXYPlot0.setBackgroundImageAlignment((int) (short) 0);
        combinedDomainXYPlot0.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LGPL" + "'", str1.equals("LGPL"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth((double) 0.0f);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYBarRenderer3.setSeriesOutlinePaint((int) (short) 10, paint5);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        combinedDomainXYPlot7.setFixedLegendItems(legendItemCollection8);
        java.awt.Paint paint10 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot7.setDomainGridlinePaint(paint10);
        boolean boolean12 = combinedDomainXYPlot7.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        combinedDomainXYPlot7.setDataset((int) (short) 0, xYDataset14);
        combinedDomainXYPlot7.setBackgroundImageAlignment((int) (byte) -1);
        int int18 = combinedDomainXYPlot7.getDatasetCount();
        xYBarRenderer3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot7);
        xYBarRenderer3.setMargin((double) 1L);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = null;
        combinedDomainXYPlot23.setFixedLegendItems(legendItemCollection24);
        java.awt.Paint paint26 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot23.setDomainGridlinePaint(paint26);
        boolean boolean28 = combinedDomainXYPlot23.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        combinedDomainXYPlot23.setDataset((int) (short) 0, xYDataset30);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.RenderingSource renderingSource35 = null;
        combinedDomainXYPlot23.select((double) 1L, (double) ' ', rectangle2D34, renderingSource35);
        java.lang.String str37 = combinedDomainXYPlot23.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = combinedDomainXYPlot23.getRenderer();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray45, numberArray49, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray54);
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset55, (double) (-2208960000000L));
        double double58 = range57.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint60 = new org.jfree.chart.block.RectangleConstraint(range57, 100.0d);
        boolean boolean63 = range57.intersects((double) (byte) 10, (double) 9999);
        dateAxis39.setRange(range57, true, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker69 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L);
        java.lang.String str70 = intervalMarker69.getLabel();
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        xYBarRenderer3.drawRangeMarker(graphics2D22, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot23, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.plot.Marker) intervalMarker69, rectangle2D71);
        org.jfree.data.Range range73 = dateAxis39.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint74 = rectangleConstraint0.toRangeWidth(range73);
        double double75 = range73.getUpperBound();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Combined_Domain_XYPlot" + "'", str37.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(xYItemRenderer38);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + (-2.20896E12d) + "'", double58 == (-2.20896E12d));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNotNull(rectangleConstraint74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + (-2.20895999997E12d) + "'", double75 == (-2.20895999997E12d));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation1 = null;
        try {
            boolean boolean2 = combinedDomainXYPlot0.removeAnnotation(xYAnnotation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("PieLabelLinkStyle.STANDARD");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getNumberFormat();
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (-8.0d), Double.NaN, (-1.0d), (double) (-1L));
        java.lang.String str6 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.RELATIVE" + "'", str6.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) ' ', (double) 0.5f);
        xYDataItem2.setY((java.lang.Number) 4);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj2 = standardXYToolTipGenerator1.clone();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator3);
        org.jfree.chart.LegendItem legendItem7 = xYAreaRenderer4.getLegendItem(12, 1);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = xYAreaRenderer4.getLegendItemURLGenerator();
        boolean boolean9 = xYAreaRenderer4.isOutline();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(legendItem7);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange1);
        java.lang.String str3 = dateRange1.toString();
        long long4 = dateRange1.getLowerMillis();
        java.lang.String str5 = dateRange1.toString();
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str3.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str5.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator(13, categoryToolTipGenerator2);
        java.awt.Paint paint4 = barRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation5 = null;
        boolean boolean6 = barRenderer0.removeAnnotation(categoryAnnotation5);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator7);
        barRenderer0.removeAnnotations();
        java.awt.Shape shape10 = barRenderer0.getBaseLegendShape();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 100, categoryToolTipGenerator12, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = barRenderer0.getSeriesItemLabelGenerator(8);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator16);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("Combined_Domain_XYPlot");
        legendItem1.setSeriesIndex((int) '4');
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 10, 1L, (short) 1 };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray9, numberArray13, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray18);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset19);
        legendItem1.setDataset((org.jfree.data.general.Dataset) categoryDataset19);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset19, false);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.0d + "'", number20.equals(1.0d));
        org.junit.Assert.assertNotNull(range23);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) '#', "", textAnchor3, textAnchor4, (double) 6);
        java.lang.String str7 = tickType0.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "MAJOR" + "'", str7.equals("MAJOR"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!�");
        logAxis1.pan(0.0d);
        double double5 = logAxis1.calculateValue(0.0d);
        logAxis1.pan((double) 10L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        boolean boolean5 = xYStepRenderer2.getItemLineVisible((-1), (int) ' ');
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        combinedDomainXYPlot7.setFixedLegendItems(legendItemCollection8);
        java.awt.Paint paint10 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot7.setDomainGridlinePaint(paint10);
        boolean boolean12 = combinedDomainXYPlot7.canSelectByPoint();
        int int13 = combinedDomainXYPlot7.getSeriesCount();
        combinedDomainXYPlot7.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.PiePlot3D piePlot3D19 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D19.setMinimumArcAngleToDraw((double) (byte) -1);
        double double22 = piePlot3D19.getInteriorGap();
        piePlot3D19.setDarkerSides(false);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D27.setMinimumArcAngleToDraw((double) (byte) -1);
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        piePlot3D27.setLabelLinkStroke(stroke30);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = rectangleConstraint34.toFixedWidth((double) 0.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart38 = chartChangeEvent37.getChart();
        boolean boolean39 = chartRenderingInfo33.equals((java.lang.Object) chartChangeEvent37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = chartRenderingInfo33.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState41 = piePlot3D19.initialise(graphics2D25, rectangle2D26, (org.jfree.chart.plot.PiePlot) piePlot3D27, (java.lang.Integer) 0, plotRenderingInfo40);
        java.awt.geom.Rectangle2D rectangle2D42 = plotRenderingInfo40.getDataArea();
        boolean boolean43 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 4, (double) (-398), rectangle2D42);
        try {
            xYStepRenderer2.drawDomainGridLine(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot7, (org.jfree.chart.axis.ValueAxis) dateAxis16, rectangle2D42, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.08d + "'", double22 == 0.08d);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleConstraint34);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertNull(jFreeChart38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo40);
        org.junit.Assert.assertNotNull(piePlotState41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean1 = xYBarRenderer0.isDrawBarOutline();
        xYBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = xYBarRenderer0.getDrawingSupplier();
        java.awt.Paint paint6 = xYBarRenderer0.getLegendTextPaint((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(drawingSupplier4);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = null;
        combinedDomainXYPlot0.setFixedLegendItems(legendItemCollection1);
        java.awt.Paint paint3 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        combinedDomainXYPlot0.setDomainGridlinePaint(paint3);
        boolean boolean5 = combinedDomainXYPlot0.canSelectByPoint();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        combinedDomainXYPlot0.setDataset((int) (short) 0, xYDataset7);
        combinedDomainXYPlot0.setBackgroundImageAlignment((int) (byte) -1);
        org.jfree.data.xy.XYSeries xYSeries11 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection12 = new org.jfree.data.xy.XYSeriesCollection(xYSeries11);
        double double14 = xYSeriesCollection12.getDomainLowerBound(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedDomainXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection12);
        double double16 = xYSeriesCollection12.getIntervalPositionFactor();
        try {
            double double19 = xYSeriesCollection12.getStartXValue((int) (byte) -1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.5d + "'", double16 == 0.5d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("12-January-1900");
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }
}

