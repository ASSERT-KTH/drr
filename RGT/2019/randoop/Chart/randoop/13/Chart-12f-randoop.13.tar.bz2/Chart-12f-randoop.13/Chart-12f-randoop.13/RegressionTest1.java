import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor5);
        java.awt.Color color7 = java.awt.Color.yellow;
        legendTitle1.setItemPaint((java.awt.Paint) color7);
        java.awt.Paint paint9 = legendTitle1.getBackgroundPaint();
        double double10 = legendTitle1.getContentYOffset();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle13.setHorizontalAlignment(horizontalAlignment14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendTitle13.getLegendItemGraphicAnchor();
        boolean boolean17 = color11.equals((java.lang.Object) rectangleAnchor16);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor16);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        java.awt.Color color17 = java.awt.Color.pink;
        legendTitle9.setItemPaint((java.awt.Paint) color17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendTitle9.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color19);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass24 = rectangleInsets23.getClass();
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = textTitle25.getTextAlignment();
        java.awt.Paint paint27 = textTitle25.getPaint();
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle25.getBounds();
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets23.createOutsetRectangle(rectangle2D28);
        try {
            blockBorder21.draw(graphics2D22, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Comparable comparable3 = null;
        try {
            defaultKeyedValues2D0.addValue((java.lang.Number) (short) 100, (java.lang.Comparable) "{0}", comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        multiplePiePlot1.markerChanged(markerChangeEvent4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = multiplePiePlot1.getInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int8 = color7.getGreen();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color7);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = multiplePiePlot1.getInsets();
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot1.getPieChart();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 128 + "'", int8 == 128);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(jFreeChart11);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeColumn((java.lang.Comparable) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: -1.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getSectionOutlinesVisible();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        piePlot1.setDataset(pieDataset3);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLabelGenerator();
        org.jfree.chart.util.Rotation rotation6 = piePlot1.getDirection();
        piePlot1.setIgnoreNullValues(true);
        piePlot1.setLabelLinksVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(rotation6);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle3);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle3.setItemPaint((java.awt.Paint) color8);
        double double10 = legendTitle3.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset12);
        java.awt.Paint paint14 = multiplePiePlot13.getNoDataMessagePaint();
        java.awt.Paint paint15 = multiplePiePlot13.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot13);
        jFreeChart16.setBackgroundImageAlignment((int) (short) 0);
        legendTitle3.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart16);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart16.setBorderPaint((java.awt.Paint) color20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textTitle22.getTextAlignment();
        java.awt.Paint paint24 = textTitle22.getPaint();
        java.awt.Stroke[] strokeArray25 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean26 = textTitle22.equals((java.lang.Object) strokeArray25);
        jFreeChart16.addSubtitle((org.jfree.chart.title.Title) textTitle22);
        jFreeChart16.setTextAntiAlias(true);
        org.jfree.chart.LegendItemSource legendItemSource30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle(legendItemSource30);
        double double32 = legendTitle31.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent33 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle31);
        org.jfree.chart.JFreeChart jFreeChart34 = null;
        titleChangeEvent33.setChart(jFreeChart34);
        jFreeChart16.titleChanged(titleChangeEvent33);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType37 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean39 = chartChangeEventType37.equals((java.lang.Object) 8.0d);
        java.lang.String str40 = chartChangeEventType37.toString();
        java.awt.Color color45 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color45);
        boolean boolean47 = chartChangeEventType37.equals((java.lang.Object) (short) 100);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockBorder1, jFreeChart16, chartChangeEventType37);
        org.jfree.chart.title.LegendTitle legendTitle49 = jFreeChart16.getLegend();
        org.jfree.chart.event.ChartProgressListener chartProgressListener50 = null;
        jFreeChart16.addProgressListener(chartProgressListener50);
        org.jfree.chart.plot.Plot plot52 = jFreeChart16.getPlot();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str40.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(legendTitle49);
        org.junit.Assert.assertNotNull(plot52);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        java.awt.Stroke stroke19 = jFreeChart14.getBorderStroke();
        int int20 = jFreeChart14.getSubtitleCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        try {
            java.awt.image.BufferedImage bufferedImage24 = jFreeChart14.createBufferedImage((int) (short) -1, 1, chartRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        textTitle0.setWidth((double) 100L);
        textTitle0.setText("");
        java.lang.String str6 = textTitle0.getText();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color11);
        textTitle0.setPaint((java.awt.Paint) color11);
        textTitle0.setURLText("PieSection: 255, -48897(10)");
        textTitle0.setText("VerticalAlignment.BOTTOM");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textTitle0.setTextAlignment(horizontalAlignment18);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) '4', 0.0f, (float) (byte) 0);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass3 = rectangleInsets2.getClass();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        double double6 = legendTitle5.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle5.getPadding();
        legendTitle5.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle5.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendTitle12.getPadding();
        java.awt.geom.Rectangle2D rectangle2D15 = legendTitle12.getBounds();
        rectangleInsets10.trim(rectangle2D15);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets2.createAdjustedRectangle(rectangle2D15, lengthAdjustmentType17, lengthAdjustmentType18);
        legendTitle1.setBounds(rectangle2D19);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent21 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = titleChangeEvent21.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = titleChangeEvent21.getType();
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        piePlot25.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean28 = piePlot25.getSimpleLabels();
        piePlot25.setLabelLinksVisible(true);
        boolean boolean31 = chartChangeEventType23.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(chartChangeEventType22);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets2);
        java.awt.Color color4 = java.awt.Color.cyan;
        int int5 = color4.getRed();
        legendTitle1.setItemPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleEdge.LEFT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "hi!");
        java.lang.Class<?> wildcardClass3 = contributor2.getClass();
        java.lang.String str4 = contributor2.getEmail();
        java.lang.String str5 = contributor2.getName();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setExplodePercent((java.lang.Comparable) (-254.0d), (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot1.getLabelPadding();
        boolean boolean6 = piePlot1.isCircular();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getSimpleLabelOffset();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        java.awt.Paint paint11 = multiplePiePlot10.getNoDataMessagePaint();
        java.awt.Paint paint12 = multiplePiePlot10.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot10);
        jFreeChart13.setBackgroundImageAlignment((int) (short) 0);
        java.awt.Stroke stroke16 = jFreeChart13.getBorderStroke();
        piePlot1.setLabelLinkStroke(stroke16);
        java.lang.String str18 = piePlot1.getNoDataMessage();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Multiple Pie Plot");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        java.text.NumberFormat numberFormat3 = standardPieSectionLabelGenerator1.getPercentFormat();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        double double5 = legendTitle1.getContentYOffset();
        legendTitle1.setHeight((double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        jFreeChart14.setTextAntiAlias(false);
        java.awt.Stroke stroke22 = jFreeChart14.getBorderStroke();
        java.lang.Object obj23 = jFreeChart14.getTextAntiAlias();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        jFreeChart5.setBackgroundImageAlignment((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass9 = rectangleInsets8.getClass();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getPadding();
        legendTitle11.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle11.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        double double19 = legendTitle18.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle18.getPadding();
        java.awt.geom.Rectangle2D rectangle2D21 = legendTitle18.getBounds();
        rectangleInsets16.trim(rectangle2D21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets8.createAdjustedRectangle(rectangle2D21, lengthAdjustmentType23, lengthAdjustmentType24);
        java.awt.Color color26 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder(rectangleInsets8, (java.awt.Paint) color26);
        double double29 = rectangleInsets8.calculateTopOutset((double) (-1));
        jFreeChart5.setPadding(rectangleInsets8);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset31);
        java.awt.Paint paint33 = multiplePiePlot32.getNoDataMessagePaint();
        java.lang.Comparable comparable34 = multiplePiePlot32.getAggregatedItemsKey();
        java.awt.Color color35 = java.awt.Color.black;
        java.awt.Color color36 = color35.darker();
        multiplePiePlot32.setAggregatedItemsPaint((java.awt.Paint) color36);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier38 = multiplePiePlot32.getDrawingSupplier();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = multiplePiePlot32.getLegendItems();
        java.awt.Paint paint40 = multiplePiePlot32.getBackgroundPaint();
        boolean boolean41 = rectangleInsets8.equals((java.lang.Object) multiplePiePlot32);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + "Other" + "'", comparable34.equals("Other"));
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(drawingSupplier38);
        org.junit.Assert.assertNotNull(legendItemCollection39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Comparable comparable3 = multiplePiePlot1.getAggregatedItemsKey();
        java.awt.Color color4 = java.awt.Color.black;
        java.awt.Color color5 = color4.darker();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = multiplePiePlot1.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset8 = multiplePiePlot1.getDataset();
        java.awt.Color color9 = java.awt.Color.gray;
        multiplePiePlot1.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot1.getPieChart();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        double double14 = legendTitle13.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle13);
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        titleChangeEvent15.setChart(jFreeChart16);
        java.lang.Object obj18 = titleChangeEvent15.getSource();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset20);
        java.awt.Paint paint22 = multiplePiePlot21.getNoDataMessagePaint();
        java.awt.Paint paint23 = multiplePiePlot21.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot21);
        titleChangeEvent15.setChart(jFreeChart24);
        multiplePiePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart24);
        jFreeChart24.setTitle("0,-1,1,1");
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(jFreeChart11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        java.awt.Paint paint2 = textTitle0.getPaint();
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean4 = textTitle0.equals((java.lang.Object) strokeArray3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment6, (double) '#', 0.0d);
        textTitle0.setHorizontalAlignment(horizontalAlignment5);
        java.lang.String str11 = textTitle0.getToolTipText();
        java.lang.String str12 = textTitle0.getURLText();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        boolean boolean2 = objectList0.equals((java.lang.Object) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.lang.Object obj3 = objectList0.clone();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color8);
        java.awt.Paint paint10 = blockBorder9.getPaint();
        boolean boolean11 = objectList0.equals((java.lang.Object) blockBorder9);
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        double double14 = legendTitle13.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle13.getPadding();
        legendTitle13.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle13.getPadding();
        int int19 = objectList0.indexOf((java.lang.Object) legendTitle13);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle13.getItemLabelPadding();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = null;
        try {
            jFreeChart14.plotChanged(plotChangeEvent19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("VerticalAlignment.CENTER", "{0}", "VerticalAlignment.CENTER", "{0}");
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle20.getTextAlignment();
        java.awt.Paint paint22 = textTitle20.getPaint();
        java.awt.Stroke[] strokeArray23 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean24 = textTitle20.equals((java.lang.Object) strokeArray23);
        jFreeChart14.addSubtitle((org.jfree.chart.title.Title) textTitle20);
        java.awt.Paint paint26 = jFreeChart14.getBorderPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (byte) -1, (java.awt.Paint) color5);
        float float7 = piePlot1.getForegroundAlpha();
        piePlot1.setLabelLinkMargin(1.0E-5d);
        boolean boolean10 = piePlot1.getSectionOutlinesVisible();
        boolean boolean11 = piePlot1.isCircular();
        float float12 = piePlot1.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("UnitType.ABSOLUTE", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        java.awt.Paint paint4 = legendTitle1.getItemPaint();
        java.lang.Object obj5 = legendTitle1.clone();
        java.lang.Object obj6 = legendTitle1.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("{0}");
        java.lang.Object obj2 = textTitle1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        java.awt.Stroke stroke4 = piePlot1.getOutlineStroke();
        java.awt.Stroke stroke5 = piePlot1.getBaseSectionOutlineStroke();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        textTitle0.setMargin(1.0d, 0.0d, (double) 128, (double) 1.0f);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = textTitle0.arrange(graphics2D7, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("ChartEntity: tooltip = ", "rect", "ChartChangeEventType.NEW_DATASET", "ChartChangeEventType.NEW_DATASET", "RectangleEdge.RIGHT");
        java.lang.String str6 = basicProjectInfo5.getCopyright();
        java.lang.String str7 = basicProjectInfo5.getCopyright();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str6.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str7.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        double double3 = rectangleInsets0.calculateBottomInset((double) (-452));
        double double5 = rectangleInsets0.calculateTopOutset((double) '#');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle1.getLegendItemGraphicEdge();
        boolean boolean7 = legendTitle1.getNotify();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot8.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Font font11 = multiplePiePlot8.getNoDataMessageFont();
        legendTitle1.setItemFont(font11);
        java.lang.Object obj13 = legendTitle1.clone();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setMaximumLabelWidth((double) (-1.0f));
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        double double23 = rectangleInsets21.calculateTopOutset((double) (short) 10);
        double double24 = rectangleInsets21.getLeft();
        piePlot15.setLabelPadding(rectangleInsets21);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double28 = rectangleInsets26.calculateRightInset((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass30 = rectangleInsets29.getClass();
        double double31 = rectangleInsets29.getLeft();
        double double33 = rectangleInsets29.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass35 = rectangleInsets34.getClass();
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle(legendItemSource36);
        double double38 = legendTitle37.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = legendTitle37.getPadding();
        legendTitle37.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = legendTitle37.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle(legendItemSource43);
        double double45 = legendTitle44.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendTitle44.getPadding();
        java.awt.geom.Rectangle2D rectangle2D47 = legendTitle44.getBounds();
        rectangleInsets42.trim(rectangle2D47);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets34.createAdjustedRectangle(rectangle2D47, lengthAdjustmentType49, lengthAdjustmentType50);
        org.jfree.chart.LegendItemSource legendItemSource52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle(legendItemSource52);
        double double54 = legendTitle53.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = legendTitle53.getPadding();
        java.awt.geom.Rectangle2D rectangle2D56 = legendTitle53.getBounds();
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets34.createInsetRectangle(rectangle2D56, false, true);
        org.jfree.chart.LegendItemSource legendItemSource60 = null;
        org.jfree.chart.title.LegendTitle legendTitle61 = new org.jfree.chart.title.LegendTitle(legendItemSource60);
        double double62 = legendTitle61.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = legendTitle61.getPadding();
        legendTitle61.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource66 = null;
        org.jfree.chart.title.LegendTitle legendTitle67 = new org.jfree.chart.title.LegendTitle(legendItemSource66);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment68 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle67.setHorizontalAlignment(horizontalAlignment68);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor70 = legendTitle67.getLegendItemGraphicAnchor();
        legendTitle61.setLegendItemGraphicAnchor(rectangleAnchor70);
        java.awt.geom.Point2D point2D72 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D56, rectangleAnchor70);
        java.awt.geom.Rectangle2D rectangle2D75 = rectangleInsets29.createOutsetRectangle(rectangle2D56, false, true);
        java.awt.geom.Rectangle2D rectangle2D76 = rectangleInsets26.createOutsetRectangle(rectangle2D56);
        rectangleInsets21.trim(rectangle2D56);
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(horizontalAlignment68);
        org.junit.Assert.assertNotNull(rectangleAnchor70);
        org.junit.Assert.assertNotNull(point2D72);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(rectangle2D76);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.plot.Plot plot6 = jFreeChart5.getPlot();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(plot6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image6 = projectInfo5.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo10 = new org.jfree.chart.ui.ProjectInfo("ChartChangeEventType.NEW_DATASET", "", "Other", image6, "", "Multiple Pie Plot", "Multiple Pie Plot");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo10);
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        double double14 = legendTitle13.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle13);
        org.jfree.chart.block.BlockContainer blockContainer16 = null;
        legendTitle13.setWrapper(blockContainer16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle13.setItemPaint((java.awt.Paint) color18);
        double double20 = legendTitle13.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot23 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset22);
        java.awt.Paint paint24 = multiplePiePlot23.getNoDataMessagePaint();
        java.awt.Paint paint25 = multiplePiePlot23.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot23);
        jFreeChart26.setBackgroundImageAlignment((int) (short) 0);
        legendTitle13.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart26);
        java.awt.Stroke stroke30 = jFreeChart26.getBorderStroke();
        java.awt.Stroke stroke31 = jFreeChart26.getBorderStroke();
        org.jfree.chart.ui.ProjectInfo projectInfo32 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image33 = projectInfo32.getLogo();
        jFreeChart26.setBackgroundImage(image33);
        projectInfo10.setLogo(image33);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertNotNull(image6);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(projectInfo32);
        org.junit.Assert.assertNotNull(image33);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.Color color2 = java.awt.Color.red;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getToolTipText();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        java.awt.Paint paint4 = multiplePiePlot3.getNoDataMessagePaint();
        java.awt.Paint paint5 = multiplePiePlot3.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        java.awt.Paint paint10 = multiplePiePlot9.getNoDataMessagePaint();
        java.awt.Paint paint11 = multiplePiePlot9.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot9);
        jFreeChart12.setBackgroundImageAlignment((int) (short) 0);
        multiplePiePlot3.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart12);
        java.lang.String str16 = multiplePiePlot3.getNoDataMessage();
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        multiplePiePlot3.setNoDataMessageFont(font17);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = textTitle19.getTextAlignment();
        textTitle19.setMargin(1.0d, 0.0d, (double) 128, (double) 1.0f);
        java.awt.Color color26 = java.awt.Color.yellow;
        textTitle19.setBackgroundPaint((java.awt.Paint) color26);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge28);
        java.lang.String str30 = rectangleEdge29.toString();
        org.jfree.chart.util.Rotation rotation31 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        double double34 = legendTitle33.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = legendTitle33.getPadding();
        java.awt.geom.Rectangle2D rectangle2D36 = legendTitle33.getBounds();
        boolean boolean37 = rotation31.equals((java.lang.Object) legendTitle33);
        org.jfree.chart.LegendItemSource legendItemSource38 = null;
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle(legendItemSource38);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle39.setHorizontalAlignment(horizontalAlignment40);
        legendTitle39.setPadding((double) (short) 0, (double) (-1L), 0.0d, (double) (short) -1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = legendTitle39.getHorizontalAlignment();
        legendTitle33.setHorizontalAlignment(horizontalAlignment47);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment49 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent50 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) horizontalAlignment49);
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment52 = textTitle51.getTextAlignment();
        java.awt.Paint paint53 = textTitle51.getBackgroundPaint();
        org.jfree.chart.block.BlockFrame blockFrame54 = textTitle51.getFrame();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment55 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment56 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement59 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment55, verticalAlignment56, (double) '#', 0.0d);
        textTitle51.setVerticalAlignment(verticalAlignment56);
        org.jfree.chart.block.FlowArrangement flowArrangement63 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment49, verticalAlignment56, 12.0d, (double) (short) 10);
        org.jfree.chart.LegendItemSource legendItemSource64 = null;
        org.jfree.chart.title.LegendTitle legendTitle65 = new org.jfree.chart.title.LegendTitle(legendItemSource64);
        double double66 = legendTitle65.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = legendTitle65.getPadding();
        legendTitle65.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = legendTitle65.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource71 = null;
        org.jfree.chart.title.LegendTitle legendTitle72 = new org.jfree.chart.title.LegendTitle(legendItemSource71);
        double double73 = legendTitle72.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = legendTitle72.getPadding();
        java.awt.geom.Rectangle2D rectangle2D75 = legendTitle72.getBounds();
        rectangleInsets70.trim(rectangle2D75);
        org.jfree.chart.title.TextTitle textTitle77 = new org.jfree.chart.title.TextTitle("hi!", font17, (java.awt.Paint) color26, rectangleEdge29, horizontalAlignment47, verticalAlignment56, rectangleInsets70);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "RectangleEdge.RIGHT" + "'", str30.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(rotation31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertNotNull(horizontalAlignment47);
        org.junit.Assert.assertNotNull(horizontalAlignment49);
        org.junit.Assert.assertNotNull(horizontalAlignment52);
        org.junit.Assert.assertNull(paint53);
        org.junit.Assert.assertNotNull(blockFrame54);
        org.junit.Assert.assertNotNull(horizontalAlignment55);
        org.junit.Assert.assertNotNull(verticalAlignment56);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(rectangle2D75);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        double double7 = piePlot1.getInteriorGap();
        java.awt.Paint paint8 = piePlot1.getLabelShadowPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass7 = rectangleInsets6.getClass();
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle9.getPadding();
        legendTitle9.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendTitle9.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        double double17 = legendTitle16.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getPadding();
        java.awt.geom.Rectangle2D rectangle2D19 = legendTitle16.getBounds();
        rectangleInsets14.trim(rectangle2D19);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets6.createAdjustedRectangle(rectangle2D19, lengthAdjustmentType21, lengthAdjustmentType22);
        legendTitle5.setBounds(rectangle2D23);
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets3.createOutsetRectangle(rectangle2D23);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D25);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass6 = rectangleInsets5.getClass();
        double double7 = rectangleInsets5.getLeft();
        boolean boolean8 = columnArrangement4.equals((java.lang.Object) double7);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        java.lang.Object obj11 = null;
        blockContainer9.add((org.jfree.chart.block.Block) blockContainer10, obj11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle14.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D15, "RectangleEdge.BOTTOM", "hi!");
        try {
            blockContainer9.draw(graphics2D13, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangle2D15);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        double double13 = rectangleInsets6.getTop();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        legendTitle1.setID("ChartEntity: tooltip = ");
        org.jfree.chart.util.ObjectList objectList7 = new org.jfree.chart.util.ObjectList((int) (short) 100);
        boolean boolean8 = legendTitle1.equals((java.lang.Object) objectList7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Comparable comparable4 = multiplePiePlot1.getAggregatedItemsKey();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "Other" + "'", comparable4.equals("Other"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset13, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        java.lang.String str20 = pieSectionEntity19.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass22 = rectangleInsets21.getClass();
        double double23 = rectangleInsets21.getLeft();
        double double25 = rectangleInsets21.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass27 = rectangleInsets26.getClass();
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle29.getPadding();
        legendTitle29.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle29.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        double double37 = legendTitle36.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle36.getPadding();
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle36.getBounds();
        rectangleInsets34.trim(rectangle2D39);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets26.createAdjustedRectangle(rectangle2D39, lengthAdjustmentType41, lengthAdjustmentType42);
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        double double46 = legendTitle45.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = legendTitle45.getPadding();
        java.awt.geom.Rectangle2D rectangle2D48 = legendTitle45.getBounds();
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets26.createInsetRectangle(rectangle2D48, false, true);
        org.jfree.chart.LegendItemSource legendItemSource52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle(legendItemSource52);
        double double54 = legendTitle53.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = legendTitle53.getPadding();
        legendTitle53.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource58 = null;
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle(legendItemSource58);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment60 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle59.setHorizontalAlignment(horizontalAlignment60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = legendTitle59.getLegendItemGraphicAnchor();
        legendTitle53.setLegendItemGraphicAnchor(rectangleAnchor62);
        java.awt.geom.Point2D point2D64 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D48, rectangleAnchor62);
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets21.createOutsetRectangle(rectangle2D48, false, true);
        pieSectionEntity19.setArea((java.awt.Shape) rectangle2D67);
        java.awt.Shape shape69 = pieSectionEntity19.getArea();
        pieSectionEntity19.setURLText("");
        java.lang.String str72 = pieSectionEntity19.getShapeCoords();
        org.jfree.chart.util.TableOrder tableOrder73 = org.jfree.chart.util.TableOrder.BY_ROW;
        boolean boolean74 = pieSectionEntity19.equals((java.lang.Object) tableOrder73);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PieSection: 255, -48897(10)" + "'", str20.equals("PieSection: 255, -48897(10)"));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(horizontalAlignment60);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(point2D64);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "0,-1,1,1" + "'", str72.equals("0,-1,1,1"));
        org.junit.Assert.assertNotNull(tableOrder73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle6.setHorizontalAlignment(horizontalAlignment7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle6.getLegendItemGraphicAnchor();
        boolean boolean10 = color4.equals((java.lang.Object) rectangleAnchor9);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) (-1.0f), 4.0d, (-1.0d), (double) '#', (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        java.awt.Paint paint11 = multiplePiePlot10.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        multiplePiePlot10.notifyListeners(plotChangeEvent12);
        java.awt.Paint paint14 = multiplePiePlot10.getNoDataMessagePaint();
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 192, 4.0d, (double) (byte) 10, 0.0d, paint14);
        piePlot1.setSectionPaint((java.lang.Comparable) 98.0d, paint14);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor17 = piePlot1.getLabelDistributor();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord18 = null;
        try {
            abstractPieLabelDistributor17.addPieLabelRecord(pieLabelRecord18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor17);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-3.0d), (java.lang.Comparable) (short) -1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.awt.Color color0 = java.awt.Color.cyan;
        int int1 = color0.getRed();
        java.awt.Color color2 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        double double7 = legendTitle6.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle6.getPadding();
        legendTitle6.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = legendTitle6.getLegendItemGraphicEdge();
        boolean boolean12 = legendTitle6.getNotify();
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = legendTitle6.getVerticalAlignment();
        boolean boolean14 = verticalAlignment1.equals((java.lang.Object) legendTitle6);
        java.awt.Color color15 = java.awt.Color.ORANGE;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color15);
        legendTitle6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder16);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass6 = rectangleInsets5.getClass();
        double double7 = rectangleInsets5.getLeft();
        boolean boolean8 = columnArrangement4.equals((java.lang.Object) double7);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.util.List list10 = blockContainer9.getBlocks();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        multiplePiePlot1.notifyListeners(plotChangeEvent3);
        org.jfree.chart.JFreeChart jFreeChart5 = multiplePiePlot1.getPieChart();
        jFreeChart5.fireChartChanged();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart5.removeProgressListener(chartProgressListener7);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart5);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("hi!");
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image1 = projectInfo0.getLogo();
//        java.lang.String str2 = projectInfo0.getInfo();
//        projectInfo0.setLicenceText("0,-1,1,1");
//        projectInfo0.setLicenceText("");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(image1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UnitType.ABSOLUTE" + "'", str2.equals("UnitType.ABSOLUTE"));
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setExplodePercent((java.lang.Comparable) (-254.0d), (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot1.getLabelPadding();
        boolean boolean6 = piePlot1.isCircular();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = piePlot1.getURLGenerator();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(pieURLGenerator7);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        double double6 = multiplePiePlot2.getLimit();
        float float7 = multiplePiePlot2.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        java.awt.Paint paint2 = textTitle0.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getTextAlignment();
        java.lang.String str4 = textTitle0.getURLText();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset13, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        java.lang.String str20 = pieSectionEntity19.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass22 = rectangleInsets21.getClass();
        double double23 = rectangleInsets21.getLeft();
        double double25 = rectangleInsets21.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass27 = rectangleInsets26.getClass();
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle29.getPadding();
        legendTitle29.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle29.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        double double37 = legendTitle36.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle36.getPadding();
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle36.getBounds();
        rectangleInsets34.trim(rectangle2D39);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets26.createAdjustedRectangle(rectangle2D39, lengthAdjustmentType41, lengthAdjustmentType42);
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        double double46 = legendTitle45.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = legendTitle45.getPadding();
        java.awt.geom.Rectangle2D rectangle2D48 = legendTitle45.getBounds();
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets26.createInsetRectangle(rectangle2D48, false, true);
        org.jfree.chart.LegendItemSource legendItemSource52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle(legendItemSource52);
        double double54 = legendTitle53.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = legendTitle53.getPadding();
        legendTitle53.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource58 = null;
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle(legendItemSource58);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment60 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle59.setHorizontalAlignment(horizontalAlignment60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = legendTitle59.getLegendItemGraphicAnchor();
        legendTitle53.setLegendItemGraphicAnchor(rectangleAnchor62);
        java.awt.geom.Point2D point2D64 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D48, rectangleAnchor62);
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets21.createOutsetRectangle(rectangle2D48, false, true);
        pieSectionEntity19.setArea((java.awt.Shape) rectangle2D67);
        pieSectionEntity19.setSectionIndex(192);
        java.lang.String str71 = pieSectionEntity19.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PieSection: 255, -48897(10)" + "'", str20.equals("PieSection: 255, -48897(10)"));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(horizontalAlignment60);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(point2D64);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "PieSection: 255, 192(10)" + "'", str71.equals("PieSection: 255, 192(10)"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        textTitle0.setWidth((double) 100L);
        textTitle0.setText("");
        textTitle0.setHeight((double) 0L);
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int11 = color10.getGreen();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge12);
        java.lang.String str14 = rectangleEdge13.toString();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        double double17 = legendTitle16.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getPadding();
        java.awt.geom.Rectangle2D rectangle2D19 = legendTitle16.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle16.setLegendItemGraphicAnchor(rectangleAnchor20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = legendTitle16.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource23);
        double double25 = legendTitle24.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle24.getPadding();
        java.lang.String str27 = rectangleInsets26.toString();
        boolean boolean28 = legendTitle16.equals((java.lang.Object) str27);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = legendTitle16.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("VerticalAlignment.CENTER", font9, (java.awt.Paint) color10, rectangleEdge13, horizontalAlignment29, verticalAlignment30, rectangleInsets31);
        textTitle0.setTextAlignment(horizontalAlignment29);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 128 + "'", int11 == 128);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleEdge.RIGHT" + "'", str14.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str27.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.08d, (double) 8);
        java.lang.String str5 = verticalAlignment1.toString();
        java.lang.String str6 = verticalAlignment1.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "VerticalAlignment.CENTER" + "'", str5.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "VerticalAlignment.CENTER" + "'", str6.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list1 = defaultKeyedValues2D0.getColumnKeys();
        java.lang.Object obj2 = defaultKeyedValues2D0.clone();
        int int3 = defaultKeyedValues2D0.getColumnCount();
        try {
            java.lang.Number number6 = defaultKeyedValues2D0.getValue((java.lang.Comparable) 98.0d, (java.lang.Comparable) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 10");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.distributeLabels((double) 2, (double) 1);
        pieLabelDistributor1.distributeLabels((double) 255, (double) '#');
        pieLabelDistributor1.distributeLabels((double) (byte) 0, 4.0d);
        pieLabelDistributor1.clear();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass6 = rectangleInsets5.getClass();
        double double7 = rectangleInsets5.getLeft();
        boolean boolean8 = columnArrangement4.equals((java.lang.Object) double7);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        java.lang.Object obj11 = null;
        blockContainer9.add((org.jfree.chart.block.Block) blockContainer10, obj11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setMaximumLabelWidth((double) (-1.0f));
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        double double23 = rectangleInsets21.calculateTopOutset((double) (short) 10);
        double double24 = rectangleInsets21.getLeft();
        piePlot15.setLabelPadding(rectangleInsets21);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double28 = rectangleInsets26.calculateRightInset((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass30 = rectangleInsets29.getClass();
        double double31 = rectangleInsets29.getLeft();
        double double33 = rectangleInsets29.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass35 = rectangleInsets34.getClass();
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle(legendItemSource36);
        double double38 = legendTitle37.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = legendTitle37.getPadding();
        legendTitle37.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = legendTitle37.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle(legendItemSource43);
        double double45 = legendTitle44.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendTitle44.getPadding();
        java.awt.geom.Rectangle2D rectangle2D47 = legendTitle44.getBounds();
        rectangleInsets42.trim(rectangle2D47);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets34.createAdjustedRectangle(rectangle2D47, lengthAdjustmentType49, lengthAdjustmentType50);
        org.jfree.chart.LegendItemSource legendItemSource52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle(legendItemSource52);
        double double54 = legendTitle53.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = legendTitle53.getPadding();
        java.awt.geom.Rectangle2D rectangle2D56 = legendTitle53.getBounds();
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets34.createInsetRectangle(rectangle2D56, false, true);
        org.jfree.chart.LegendItemSource legendItemSource60 = null;
        org.jfree.chart.title.LegendTitle legendTitle61 = new org.jfree.chart.title.LegendTitle(legendItemSource60);
        double double62 = legendTitle61.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = legendTitle61.getPadding();
        legendTitle61.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource66 = null;
        org.jfree.chart.title.LegendTitle legendTitle67 = new org.jfree.chart.title.LegendTitle(legendItemSource66);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment68 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle67.setHorizontalAlignment(horizontalAlignment68);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor70 = legendTitle67.getLegendItemGraphicAnchor();
        legendTitle61.setLegendItemGraphicAnchor(rectangleAnchor70);
        java.awt.geom.Point2D point2D72 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D56, rectangleAnchor70);
        java.awt.geom.Rectangle2D rectangle2D75 = rectangleInsets29.createOutsetRectangle(rectangle2D56, false, true);
        java.awt.geom.Rectangle2D rectangle2D76 = rectangleInsets26.createOutsetRectangle(rectangle2D56);
        rectangleInsets21.trim(rectangle2D56);
        try {
            blockContainer9.draw(graphics2D13, rectangle2D56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(horizontalAlignment68);
        org.junit.Assert.assertNotNull(rectangleAnchor70);
        org.junit.Assert.assertNotNull(point2D72);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(rectangle2D76);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        multiplePiePlot1.notifyListeners(plotChangeEvent3);
        java.awt.Paint paint5 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        multiplePiePlot1.axisChanged(axisChangeEvent6);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.awt.Color color0 = java.awt.Color.white;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        java.lang.Object obj5 = multiplePiePlot2.clone();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("Other", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.Stroke stroke7 = multiplePiePlot2.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("hi!", "", "PieSection: 255, 192(10)", "{0}");
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 0L, (double) (byte) 0, 0.4d, (double) (-48897));
        java.lang.String str6 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.ABSOLUTE" + "'", str6.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        org.jfree.data.general.DatasetGroup datasetGroup7 = new org.jfree.data.general.DatasetGroup("RectangleEdge.LEFT");
        java.lang.Object obj8 = datasetGroup7.clone();
        boolean boolean9 = rectangleAnchor4.equals((java.lang.Object) datasetGroup7);
        java.lang.String str10 = datasetGroup7.getID();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleEdge.LEFT" + "'", str10.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.distributeLabels((double) 2, (double) 1);
        pieLabelDistributor1.distributeLabels((double) 255, (double) '#');
        pieLabelDistributor1.distributeLabels((double) (byte) 0, 4.0d);
        java.lang.String str12 = pieLabelDistributor1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass12 = rectangleInsets11.getClass();
        double double13 = rectangleInsets11.getLeft();
        double double15 = rectangleInsets11.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass17 = rectangleInsets16.getClass();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        legendTitle19.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle19.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        rectangleInsets24.trim(rectangle2D29);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets16.createAdjustedRectangle(rectangle2D29, lengthAdjustmentType31, lengthAdjustmentType32);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle35.getPadding();
        java.awt.geom.Rectangle2D rectangle2D38 = legendTitle35.getBounds();
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets16.createInsetRectangle(rectangle2D38, false, true);
        org.jfree.chart.LegendItemSource legendItemSource42 = null;
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle(legendItemSource42);
        double double44 = legendTitle43.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = legendTitle43.getPadding();
        legendTitle43.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource48 = null;
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle(legendItemSource48);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment50 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle49.setHorizontalAlignment(horizontalAlignment50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = legendTitle49.getLegendItemGraphicAnchor();
        legendTitle43.setLegendItemGraphicAnchor(rectangleAnchor52);
        java.awt.geom.Point2D point2D54 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D38, rectangleAnchor52);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets11.createOutsetRectangle(rectangle2D38, false, true);
        legendTitle8.setPadding(rectangleInsets11);
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.image.ColorModel colorModel60 = null;
        java.awt.Rectangle rectangle61 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass63 = rectangleInsets62.getClass();
        org.jfree.chart.LegendItemSource legendItemSource64 = null;
        org.jfree.chart.title.LegendTitle legendTitle65 = new org.jfree.chart.title.LegendTitle(legendItemSource64);
        double double66 = legendTitle65.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = legendTitle65.getPadding();
        legendTitle65.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = legendTitle65.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource71 = null;
        org.jfree.chart.title.LegendTitle legendTitle72 = new org.jfree.chart.title.LegendTitle(legendItemSource71);
        double double73 = legendTitle72.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = legendTitle72.getPadding();
        java.awt.geom.Rectangle2D rectangle2D75 = legendTitle72.getBounds();
        rectangleInsets70.trim(rectangle2D75);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType77 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType78 = null;
        java.awt.geom.Rectangle2D rectangle2D79 = rectangleInsets62.createAdjustedRectangle(rectangle2D75, lengthAdjustmentType77, lengthAdjustmentType78);
        java.awt.geom.AffineTransform affineTransform80 = null;
        java.awt.RenderingHints renderingHints81 = null;
        java.awt.PaintContext paintContext82 = color59.createContext(colorModel60, rectangle61, rectangle2D79, affineTransform80, renderingHints81);
        java.awt.geom.Rectangle2D rectangle2D83 = rectangleInsets11.createOutsetRectangle(rectangle2D79);
        piePlot1.setLegendItemShape((java.awt.Shape) rectangle2D83);
        double double85 = piePlot1.getLabelGap();
        java.awt.Stroke stroke86 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator87 = piePlot1.getLegendLabelGenerator();
        piePlot1.setPieIndex((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(horizontalAlignment50);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(point2D54);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(paintContext82);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.025d + "'", double85 == 0.025d);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator87);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        double double7 = piePlot1.getInteriorGap();
        java.awt.Paint paint8 = piePlot1.getLabelShadowPaint();
        java.awt.Stroke stroke9 = piePlot1.getLabelOutlineStroke();
        boolean boolean10 = piePlot1.getIgnoreZeroValues();
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color12);
        piePlot1.setSectionPaint((java.lang.Comparable) "JFreeChart", (java.awt.Paint) color12);
        double double15 = piePlot1.getStartAngle();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 90.0d + "'", double15 == 90.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 192, (double) (byte) 0, (double) 192, (double) 64);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        double double7 = piePlot1.getInteriorGap();
        java.awt.Paint paint8 = piePlot1.getLabelShadowPaint();
        java.awt.Stroke stroke9 = piePlot1.getLabelOutlineStroke();
        boolean boolean10 = piePlot1.getIgnoreZeroValues();
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color12);
        piePlot1.setSectionPaint((java.lang.Comparable) "JFreeChart", (java.awt.Paint) color12);
        java.awt.Color color15 = java.awt.Color.black;
        java.awt.Color color16 = color15.darker();
        float[] floatArray22 = new float[] { '#', (short) 10, '#', 2, 255 };
        float[] floatArray23 = color16.getRGBComponents(floatArray22);
        float[] floatArray24 = color12.getRGBColorComponents(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        double double3 = legendTitle2.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle2.getPadding();
        java.awt.geom.Rectangle2D rectangle2D5 = legendTitle2.getBounds();
        boolean boolean6 = rotation0.equals((java.lang.Object) legendTitle2);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle7.getTextAlignment();
        java.awt.Paint paint9 = textTitle7.getBackgroundPaint();
        org.jfree.chart.block.BlockFrame blockFrame10 = textTitle7.getFrame();
        java.awt.Paint paint11 = textTitle7.getPaint();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset12);
        java.awt.Paint paint14 = multiplePiePlot13.getAggregatedItemsPaint();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        double double17 = legendTitle16.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getPadding();
        java.awt.geom.Rectangle2D rectangle2D19 = legendTitle16.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D19, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource23);
        double double25 = legendTitle24.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent26 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle24);
        org.jfree.chart.block.BlockContainer blockContainer27 = null;
        legendTitle24.setWrapper(blockContainer27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle24.setItemPaint((java.awt.Paint) color29);
        boolean boolean31 = chartEntity22.equals((java.lang.Object) legendTitle24);
        java.lang.String str32 = chartEntity22.getShapeType();
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        double double35 = legendTitle34.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle34.getPadding();
        legendTitle34.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = legendTitle34.getPadding();
        boolean boolean40 = chartEntity22.equals((java.lang.Object) rectangleInsets39);
        multiplePiePlot13.setInsets(rectangleInsets39, true);
        java.awt.Image image43 = multiplePiePlot13.getBackgroundImage();
        java.awt.Font font44 = multiplePiePlot13.getNoDataMessageFont();
        textTitle7.setFont(font44);
        legendTitle2.setItemFont(font44);
        org.jfree.chart.block.BlockBorder blockBorder47 = new org.jfree.chart.block.BlockBorder();
        legendTitle2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder47);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(blockFrame10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "rect" + "'", str32.equals("rect"));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(image43);
        org.junit.Assert.assertNotNull(font44);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        double double7 = piePlot1.getInteriorGap();
        java.awt.Paint paint8 = piePlot1.getLabelShadowPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color11.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        boolean boolean18 = standardPieSectionLabelGenerator10.equals((java.lang.Object) renderingHints16);
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator10);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator20 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator20);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getSectionOutlinesVisible();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        piePlot1.setDataset(pieDataset3);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLabelGenerator();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            piePlot1.setLabelPadding(rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image7 = projectInfo6.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo11 = new org.jfree.chart.ui.ProjectInfo("ChartChangeEventType.NEW_DATASET", "", "Other", image7, "", "Multiple Pie Plot", "Multiple Pie Plot");
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("UnitType.ABSOLUTE", "{0}", "PieSection: 255, -48897(10)", image7, "VerticalAlignment.CENTER", "PieSection: 255, -48897(10)", "0,0,1,1");
        projectInfo15.setName("RectangleEdge.LEFT");
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertNotNull(image7);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle1.setHorizontalAlignment(horizontalAlignment2);
        double double4 = legendTitle1.getHeight();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset6);
        java.awt.Paint paint8 = multiplePiePlot7.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        multiplePiePlot7.notifyListeners(plotChangeEvent9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        java.awt.Paint paint13 = multiplePiePlot12.getNoDataMessagePaint();
        java.lang.Comparable comparable14 = multiplePiePlot12.getAggregatedItemsKey();
        java.awt.Color color15 = java.awt.Color.black;
        java.awt.Color color16 = color15.darker();
        multiplePiePlot12.setAggregatedItemsPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = multiplePiePlot12.getDrawingSupplier();
        multiplePiePlot7.setDrawingSupplier(drawingSupplier18);
        java.awt.Font font20 = multiplePiePlot7.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.Color color23 = java.awt.Color.red;
        textTitle22.setPaint((java.awt.Paint) color23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean26 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge25);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) horizontalAlignment28);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = textTitle30.getTextAlignment();
        java.awt.Paint paint32 = textTitle30.getBackgroundPaint();
        org.jfree.chart.block.BlockFrame blockFrame33 = textTitle30.getFrame();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment35 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement38 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment34, verticalAlignment35, (double) '#', 0.0d);
        textTitle30.setVerticalAlignment(verticalAlignment35);
        org.jfree.chart.block.FlowArrangement flowArrangement42 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment28, verticalAlignment35, 12.0d, (double) (short) 10);
        org.jfree.chart.LegendItemSource legendItemSource43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle(legendItemSource43);
        double double45 = legendTitle44.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendTitle44.getPadding();
        legendTitle44.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = legendTitle44.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass51 = rectangleInsets50.getClass();
        org.jfree.chart.LegendItemSource legendItemSource52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle(legendItemSource52);
        double double54 = legendTitle53.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = legendTitle53.getPadding();
        legendTitle53.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = legendTitle53.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource59 = null;
        org.jfree.chart.title.LegendTitle legendTitle60 = new org.jfree.chart.title.LegendTitle(legendItemSource59);
        double double61 = legendTitle60.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = legendTitle60.getPadding();
        java.awt.geom.Rectangle2D rectangle2D63 = legendTitle60.getBounds();
        rectangleInsets58.trim(rectangle2D63);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType65 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets50.createAdjustedRectangle(rectangle2D63, lengthAdjustmentType65, lengthAdjustmentType66);
        legendTitle44.setPadding(rectangleInsets50);
        double double69 = rectangleInsets50.getTop();
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.NEW_DATASET", font20, (java.awt.Paint) color23, rectangleEdge25, horizontalAlignment27, verticalAlignment35, rectangleInsets50);
        legendTitle1.setHorizontalAlignment(horizontalAlignment27);
        org.jfree.chart.util.VerticalAlignment verticalAlignment72 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement75 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment27, verticalAlignment72, (double) 192, (double) (short) 100);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + "Other" + "'", comparable14.equals("Other"));
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(blockFrame33);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(verticalAlignment35);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("java.awt.Color[r=0,g=0,b=0]");
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "hi!", image3, "", "hi!", "");
        java.lang.String str8 = projectInfo7.getName();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        java.awt.Shape shape4 = piePlot1.getLegendItemShape();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot1.getURLGenerator();
        piePlot1.setLabelLinkMargin(90.0d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(pieURLGenerator5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("TableOrder.BY_COLUMN", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(0.0d, 12.0d, (double) (-48897), (double) (byte) 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        java.awt.Paint paint4 = multiplePiePlot3.getNoDataMessagePaint();
        java.awt.Paint paint5 = multiplePiePlot3.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        java.awt.Paint paint10 = multiplePiePlot9.getNoDataMessagePaint();
        java.awt.Paint paint11 = multiplePiePlot9.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot9);
        jFreeChart12.setBackgroundImageAlignment((int) (short) 0);
        multiplePiePlot3.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart12);
        java.lang.String str16 = multiplePiePlot3.getNoDataMessage();
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        multiplePiePlot3.setNoDataMessageFont(font17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset19);
        java.awt.Paint paint21 = multiplePiePlot20.getNoDataMessagePaint();
        java.lang.Comparable comparable22 = multiplePiePlot20.getAggregatedItemsKey();
        multiplePiePlot20.setBackgroundAlpha((float) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("HorizontalAlignment.RIGHT", font17, (org.jfree.chart.plot.Plot) multiplePiePlot20, false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + "Other" + "'", comparable22.equals("Other"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset20);
        java.awt.Paint paint22 = multiplePiePlot21.getNoDataMessagePaint();
        java.lang.Comparable comparable23 = multiplePiePlot21.getAggregatedItemsKey();
        java.awt.Color color24 = java.awt.Color.black;
        java.awt.Color color25 = color24.darker();
        multiplePiePlot21.setAggregatedItemsPaint((java.awt.Paint) color25);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = multiplePiePlot21.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset28 = multiplePiePlot21.getDataset();
        java.awt.Color color29 = java.awt.Color.gray;
        multiplePiePlot21.setBackgroundPaint((java.awt.Paint) color29);
        org.jfree.chart.JFreeChart jFreeChart31 = multiplePiePlot21.getPieChart();
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        double double34 = legendTitle33.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent35 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle33);
        org.jfree.chart.JFreeChart jFreeChart36 = null;
        titleChangeEvent35.setChart(jFreeChart36);
        java.lang.Object obj38 = titleChangeEvent35.getSource();
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot41 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset40);
        java.awt.Paint paint42 = multiplePiePlot41.getNoDataMessagePaint();
        java.awt.Paint paint43 = multiplePiePlot41.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot41);
        titleChangeEvent35.setChart(jFreeChart44);
        multiplePiePlot21.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        java.awt.Stroke stroke47 = jFreeChart44.getBorderStroke();
        int int48 = jFreeChart44.getSubtitleCount();
        try {
            jFreeChart14.setTextAntiAlias((java.lang.Object) jFreeChart44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.JFreeChart@66c3b915 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + "Other" + "'", comparable23.equals("Other"));
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(drawingSupplier27);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(jFreeChart31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        defaultKeyedValues2D1.addValue((java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 1.0f);
        int int9 = defaultKeyedValues2D1.getColumnCount();
        java.util.List list10 = defaultKeyedValues2D1.getRowKeys();
        try {
            java.lang.Comparable comparable12 = defaultKeyedValues2D1.getColumnKey((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.lang.String str4 = rectangleInsets3.toString();
        double double5 = rectangleInsets3.getLeft();
        double double7 = rectangleInsets3.trimHeight((double) (-452));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-454.0d) + "'", double7 == (-454.0d));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle3.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle10.getBounds();
        rectangleInsets8.trim(rectangle2D13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets0.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType15, lengthAdjustmentType16);
        java.awt.Color color18 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color18);
        double double21 = rectangleInsets0.calculateTopOutset((double) (-1));
        double double23 = rectangleInsets0.calculateTopOutset((double) ' ');
        double double25 = rectangleInsets0.trimWidth((double) 1);
        double double27 = rectangleInsets0.extendWidth((double) 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-1.0d) + "'", double25 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.0d + "'", double27 == 2.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        boolean boolean3 = multiplePiePlot1.isSubplot();
        org.jfree.chart.plot.Plot plot4 = multiplePiePlot1.getParent();
        java.awt.Color color5 = java.awt.Color.pink;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset6);
        java.awt.Paint paint8 = multiplePiePlot7.getNoDataMessagePaint();
        java.awt.Paint paint9 = multiplePiePlot7.getNoDataMessagePaint();
        java.awt.Stroke stroke10 = multiplePiePlot7.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double13 = rectangleInsets11.trimWidth((double) 2);
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke10, rectangleInsets11);
        multiplePiePlot1.setOutlinePaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle9.getPadding();
        java.lang.String str12 = rectangleInsets11.toString();
        boolean boolean13 = legendTitle1.equals((java.lang.Object) str12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = legendTitle1.getHorizontalAlignment();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        double double17 = legendTitle16.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getPadding();
        legendTitle16.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = legendTitle16.getLegendItemGraphicEdge();
        boolean boolean22 = legendTitle16.getNotify();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot23 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot23.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Font font26 = multiplePiePlot23.getNoDataMessageFont();
        legendTitle16.setItemFont(font26);
        java.lang.Object obj28 = legendTitle16.clone();
        org.jfree.chart.LegendItemSource legendItemSource29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource29);
        double double31 = legendTitle30.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame32 = legendTitle30.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray34 = new org.jfree.chart.LegendItemSource[] { legendItemSource33 };
        legendTitle30.setSources(legendItemSourceArray34);
        legendTitle16.setSources(legendItemSourceArray34);
        legendTitle1.setSources(legendItemSourceArray34);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray38 = legendTitle1.getSources();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str12.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame32);
        org.junit.Assert.assertNotNull(legendItemSourceArray34);
        org.junit.Assert.assertNotNull(legendItemSourceArray38);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("PieSection: 255, -48897(10)", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setExplodePercent((java.lang.Comparable) (-254.0d), (double) ' ');
        double double5 = piePlot1.getMaximumExplodePercent();
        java.awt.Paint paint6 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle1.setHorizontalAlignment(horizontalAlignment2);
        double double4 = legendTitle1.getHeight();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset6);
        java.awt.Paint paint8 = multiplePiePlot7.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        multiplePiePlot7.notifyListeners(plotChangeEvent9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        java.awt.Paint paint13 = multiplePiePlot12.getNoDataMessagePaint();
        java.lang.Comparable comparable14 = multiplePiePlot12.getAggregatedItemsKey();
        java.awt.Color color15 = java.awt.Color.black;
        java.awt.Color color16 = color15.darker();
        multiplePiePlot12.setAggregatedItemsPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = multiplePiePlot12.getDrawingSupplier();
        multiplePiePlot7.setDrawingSupplier(drawingSupplier18);
        java.awt.Font font20 = multiplePiePlot7.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.Color color23 = java.awt.Color.red;
        textTitle22.setPaint((java.awt.Paint) color23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean26 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge25);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) horizontalAlignment28);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = textTitle30.getTextAlignment();
        java.awt.Paint paint32 = textTitle30.getBackgroundPaint();
        org.jfree.chart.block.BlockFrame blockFrame33 = textTitle30.getFrame();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment35 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement38 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment34, verticalAlignment35, (double) '#', 0.0d);
        textTitle30.setVerticalAlignment(verticalAlignment35);
        org.jfree.chart.block.FlowArrangement flowArrangement42 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment28, verticalAlignment35, 12.0d, (double) (short) 10);
        org.jfree.chart.LegendItemSource legendItemSource43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle(legendItemSource43);
        double double45 = legendTitle44.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendTitle44.getPadding();
        legendTitle44.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = legendTitle44.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass51 = rectangleInsets50.getClass();
        org.jfree.chart.LegendItemSource legendItemSource52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle(legendItemSource52);
        double double54 = legendTitle53.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = legendTitle53.getPadding();
        legendTitle53.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = legendTitle53.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource59 = null;
        org.jfree.chart.title.LegendTitle legendTitle60 = new org.jfree.chart.title.LegendTitle(legendItemSource59);
        double double61 = legendTitle60.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = legendTitle60.getPadding();
        java.awt.geom.Rectangle2D rectangle2D63 = legendTitle60.getBounds();
        rectangleInsets58.trim(rectangle2D63);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType65 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets50.createAdjustedRectangle(rectangle2D63, lengthAdjustmentType65, lengthAdjustmentType66);
        legendTitle44.setPadding(rectangleInsets50);
        double double69 = rectangleInsets50.getTop();
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.NEW_DATASET", font20, (java.awt.Paint) color23, rectangleEdge25, horizontalAlignment27, verticalAlignment35, rectangleInsets50);
        legendTitle1.setHorizontalAlignment(horizontalAlignment27);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray72 = legendTitle1.getSources();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + "Other" + "'", comparable14.equals("Other"));
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(blockFrame33);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(verticalAlignment35);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
        org.junit.Assert.assertNotNull(legendItemSourceArray72);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getSectionOutlinesVisible();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        piePlot1.setDataset(pieDataset3);
        org.jfree.chart.util.Rotation rotation5 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        piePlot1.setDirection(rotation5);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rotation5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setExplodePercent((java.lang.Comparable) (-254.0d), (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot1.getLabelPadding();
        boolean boolean6 = piePlot1.isCircular();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getSimpleLabelOffset();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        java.awt.Paint paint11 = multiplePiePlot10.getNoDataMessagePaint();
        java.awt.Paint paint12 = multiplePiePlot10.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot10);
        jFreeChart13.setBackgroundImageAlignment((int) (short) 0);
        java.awt.Stroke stroke16 = jFreeChart13.getBorderStroke();
        piePlot1.setLabelLinkStroke(stroke16);
        java.awt.Paint paint18 = null;
        try {
            piePlot1.setBaseSectionPaint(paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        double double7 = piePlot1.getInteriorGap();
        java.awt.Paint paint8 = piePlot1.getLabelShadowPaint();
        java.awt.Stroke stroke9 = piePlot1.getLabelOutlineStroke();
        boolean boolean10 = piePlot1.getIgnoreZeroValues();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = piePlot1.getURLGenerator();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        piePlot14.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean17 = piePlot14.getSimpleLabels();
        double double18 = piePlot14.getInteriorGap();
        piePlot14.setExplodePercent((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (double) (short) 1);
        piePlot14.setMinimumArcAngleToDraw((double) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot25 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset24);
        java.awt.Paint paint26 = multiplePiePlot25.getNoDataMessagePaint();
        java.awt.Paint paint27 = multiplePiePlot25.getNoDataMessagePaint();
        java.awt.Stroke stroke28 = multiplePiePlot25.getOutlineStroke();
        piePlot14.setLabelLinkStroke(stroke28);
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) "JFreeChart", stroke28);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(pieURLGenerator11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.08d + "'", double18 == 0.08d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setExplodePercent((java.lang.Comparable) (-254.0d), (double) ' ');
        double double5 = piePlot1.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double8 = rectangleInsets6.calculateRightInset((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass10 = rectangleInsets9.getClass();
        double double11 = rectangleInsets9.getLeft();
        double double13 = rectangleInsets9.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass15 = rectangleInsets14.getClass();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        double double18 = legendTitle17.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle17.getPadding();
        legendTitle17.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle17.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource23);
        double double25 = legendTitle24.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle24.getPadding();
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle24.getBounds();
        rectangleInsets22.trim(rectangle2D27);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets14.createAdjustedRectangle(rectangle2D27, lengthAdjustmentType29, lengthAdjustmentType30);
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        double double34 = legendTitle33.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = legendTitle33.getPadding();
        java.awt.geom.Rectangle2D rectangle2D36 = legendTitle33.getBounds();
        java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets14.createInsetRectangle(rectangle2D36, false, true);
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        double double42 = legendTitle41.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = legendTitle41.getPadding();
        legendTitle41.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource46 = null;
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle(legendItemSource46);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle47.setHorizontalAlignment(horizontalAlignment48);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = legendTitle47.getLegendItemGraphicAnchor();
        legendTitle41.setLegendItemGraphicAnchor(rectangleAnchor50);
        java.awt.geom.Point2D point2D52 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D36, rectangleAnchor50);
        java.awt.geom.Rectangle2D rectangle2D55 = rectangleInsets9.createOutsetRectangle(rectangle2D36, false, true);
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets6.createOutsetRectangle(rectangle2D36);
        java.lang.String str57 = rectangleInsets6.toString();
        piePlot1.setInsets(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(horizontalAlignment48);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(point2D52);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str57.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle8.setLegendItemGraphicAnchor(rectangleAnchor12);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle15.getPadding();
        java.lang.String str18 = rectangleInsets17.toString();
        legendTitle8.setMargin(rectangleInsets17);
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor21);
        org.jfree.chart.block.BlockContainer blockContainer23 = legendTitle1.getItemContainer();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str18.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(blockContainer23);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (byte) -1, (java.awt.Paint) color5);
        float float7 = piePlot1.getForegroundAlpha();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color12);
        java.awt.Paint paint14 = blockBorder13.getPaint();
        piePlot1.setLabelOutlinePaint(paint14);
        java.awt.Paint paint16 = piePlot1.getBaseSectionPaint();
        boolean boolean17 = piePlot1.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle2.getTextAlignment();
        java.awt.Paint paint4 = textTitle2.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle2.getTextAlignment();
        boolean boolean6 = projectInfo0.equals((java.lang.Object) textTitle2);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass6 = rectangleInsets5.getClass();
        double double7 = rectangleInsets5.getLeft();
        boolean boolean8 = columnArrangement4.equals((java.lang.Object) double7);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame13 = legendTitle11.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray15 = new org.jfree.chart.LegendItemSource[] { legendItemSource14 };
        legendTitle11.setSources(legendItemSourceArray15);
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        double double19 = legendTitle18.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle18.getPadding();
        java.awt.geom.Rectangle2D rectangle2D21 = legendTitle18.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor22);
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        double double26 = legendTitle25.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle25.getPadding();
        java.lang.String str28 = rectangleInsets27.toString();
        legendTitle18.setMargin(rectangleInsets27);
        legendTitle11.setLegendItemGraphicPadding(rectangleInsets27);
        java.lang.Object obj31 = null;
        blockContainer9.add((org.jfree.chart.block.Block) legendTitle11, obj31);
        java.util.List list33 = blockContainer9.getBlocks();
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.Color color36 = java.awt.Color.red;
        textTitle35.setPaint((java.awt.Paint) color36);
        blockContainer9.add((org.jfree.chart.block.Block) textTitle35);
        java.lang.String str39 = textTitle35.getURLText();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame13);
        org.junit.Assert.assertNotNull(legendItemSourceArray15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str28.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(str39);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass8 = rectangleInsets7.getClass();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        legendTitle10.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle10.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        double double18 = legendTitle17.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle17.getPadding();
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle17.getBounds();
        rectangleInsets15.trim(rectangle2D20);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets7.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType22, lengthAdjustmentType23);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets7.createInsetRectangle(rectangle2D29, false, true);
        legendTitle1.setBounds(rectangle2D29);
        legendTitle1.setWidth((double) 100);
        org.jfree.chart.block.BlockContainer blockContainer36 = legendTitle1.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement37 = blockContainer36.getArrangement();
        blockContainer36.setID("TableOrder.BY_COLUMN");
        org.jfree.chart.block.Arrangement arrangement40 = blockContainer36.getArrangement();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(blockContainer36);
        org.junit.Assert.assertNotNull(arrangement37);
        org.junit.Assert.assertNotNull(arrangement40);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getURLText();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        textTitle0.setText("java.awt.Color[r=0,g=0,b=0]");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.distributeLabels((double) 2, (double) 1);
        java.lang.String str6 = pieLabelDistributor1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.lang.Object obj0 = null;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        double double3 = legendTitle2.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle2.getPadding();
        legendTitle2.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle2.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        double double16 = legendTitle9.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        java.awt.Paint paint20 = multiplePiePlot19.getNoDataMessagePaint();
        java.awt.Paint paint21 = multiplePiePlot19.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot19);
        jFreeChart22.setBackgroundImageAlignment((int) (short) 0);
        legendTitle9.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart22);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart22.setBorderPaint((java.awt.Paint) color26);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = textTitle28.getTextAlignment();
        java.awt.Paint paint30 = textTitle28.getPaint();
        java.awt.Stroke[] strokeArray31 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean32 = textTitle28.equals((java.lang.Object) strokeArray31);
        jFreeChart22.addSubtitle((org.jfree.chart.title.Title) textTitle28);
        boolean boolean34 = jFreeChart22.isBorderVisible();
        legendTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart22);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        jFreeChart14.setTextAntiAlias(false);
        java.awt.Stroke stroke22 = jFreeChart14.getBorderStroke();
        int int23 = jFreeChart14.getBackgroundImageAlignment();
        jFreeChart14.setBackgroundImageAlpha((float) ' ');
        java.awt.RenderingHints renderingHints26 = null;
        try {
            jFreeChart14.setRenderingHints(renderingHints26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.distributeLabels((double) 2, (double) 1);
        pieLabelDistributor1.distributeLabels((double) 255, (double) '#');
        pieLabelDistributor1.distributeLabels((double) 0.0f, (double) 0);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord13 = pieLabelDistributor1.getPieLabelRecord((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 0.0f, 4.0d, (double) 255, (double) 10L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        multiplePiePlot1.markerChanged(markerChangeEvent4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = multiplePiePlot1.getInsets();
        double double7 = multiplePiePlot1.getLimit();
        multiplePiePlot1.setOutlineVisible(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        java.awt.Stroke stroke19 = jFreeChart14.getBorderStroke();
        org.jfree.chart.ui.ProjectInfo projectInfo20 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image21 = projectInfo20.getLogo();
        jFreeChart14.setBackgroundImage(image21);
        jFreeChart14.setAntiAlias(true);
        boolean boolean25 = jFreeChart14.getAntiAlias();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(projectInfo20);
        org.junit.Assert.assertNotNull(image21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle3);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle3.setItemPaint((java.awt.Paint) color8);
        double double10 = legendTitle3.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset12);
        java.awt.Paint paint14 = multiplePiePlot13.getNoDataMessagePaint();
        java.awt.Paint paint15 = multiplePiePlot13.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot13);
        jFreeChart16.setBackgroundImageAlignment((int) (short) 0);
        legendTitle3.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart16);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart16.setBorderPaint((java.awt.Paint) color20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textTitle22.getTextAlignment();
        java.awt.Paint paint24 = textTitle22.getPaint();
        java.awt.Stroke[] strokeArray25 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean26 = textTitle22.equals((java.lang.Object) strokeArray25);
        jFreeChart16.addSubtitle((org.jfree.chart.title.Title) textTitle22);
        jFreeChart16.setTextAntiAlias(true);
        org.jfree.chart.LegendItemSource legendItemSource30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle(legendItemSource30);
        double double32 = legendTitle31.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent33 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle31);
        org.jfree.chart.JFreeChart jFreeChart34 = null;
        titleChangeEvent33.setChart(jFreeChart34);
        jFreeChart16.titleChanged(titleChangeEvent33);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType37 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean39 = chartChangeEventType37.equals((java.lang.Object) 8.0d);
        java.lang.String str40 = chartChangeEventType37.toString();
        java.awt.Color color45 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color45);
        boolean boolean47 = chartChangeEventType37.equals((java.lang.Object) (short) 100);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockBorder1, jFreeChart16, chartChangeEventType37);
        org.jfree.chart.title.LegendTitle legendTitle49 = jFreeChart16.getLegend();
        int int50 = jFreeChart16.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str40.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(legendTitle49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        double double2 = rectangleInsets0.getLeft();
        double double4 = rectangleInsets0.calculateTopInset((double) 100.0f);
        double double6 = rectangleInsets0.calculateLeftOutset(4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset13, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        java.lang.String str20 = pieSectionEntity19.toString();
        pieSectionEntity19.setSectionKey((java.lang.Comparable) "hi!");
        int int23 = pieSectionEntity19.getPieIndex();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PieSection: 255, -48897(10)" + "'", str20.equals("PieSection: 255, -48897(10)"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 255 + "'", int23 == 255);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot1.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Font font4 = multiplePiePlot1.getNoDataMessageFont();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        java.awt.Paint paint7 = multiplePiePlot6.getNoDataMessagePaint();
        java.awt.Paint paint8 = multiplePiePlot6.getNoDataMessagePaint();
        multiplePiePlot1.setParent((org.jfree.chart.plot.Plot) multiplePiePlot6);
        boolean boolean10 = objectList0.equals((java.lang.Object) multiplePiePlot6);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        titleChangeEvent14.setChart(jFreeChart15);
        java.lang.Object obj17 = titleChangeEvent14.getSource();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset19);
        java.awt.Paint paint21 = multiplePiePlot20.getNoDataMessagePaint();
        java.awt.Paint paint22 = multiplePiePlot20.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot20);
        titleChangeEvent14.setChart(jFreeChart23);
        multiplePiePlot6.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart23);
        multiplePiePlot6.setBackgroundImageAlpha((float) (short) 0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot0.getDataExtractOrder();
        java.lang.String str4 = tableOrder3.toString();
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TableOrder.BY_COLUMN" + "'", str4.equals("TableOrder.BY_COLUMN"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        org.jfree.data.general.DatasetGroup datasetGroup2 = defaultCategoryDataset0.getGroup();
        int int4 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) (byte) 0);
        int int5 = defaultCategoryDataset0.getRowCount();
        org.junit.Assert.assertNotNull(datasetGroup2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        double double5 = legendTitle4.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle4.getPadding();
        java.awt.geom.Rectangle2D rectangle2D7 = legendTitle4.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D7, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.block.BlockContainer blockContainer15 = null;
        legendTitle12.setWrapper(blockContainer15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle12.setItemPaint((java.awt.Paint) color17);
        boolean boolean19 = chartEntity10.equals((java.lang.Object) legendTitle12);
        java.lang.String str20 = chartEntity10.getShapeType();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        double double23 = legendTitle22.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle22.getPadding();
        legendTitle22.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle22.getPadding();
        boolean boolean28 = chartEntity10.equals((java.lang.Object) rectangleInsets27);
        multiplePiePlot1.setInsets(rectangleInsets27, true);
        boolean boolean31 = multiplePiePlot1.isSubplot();
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        double double34 = legendTitle33.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent35 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle33);
        org.jfree.chart.block.BlockContainer blockContainer36 = null;
        legendTitle33.setWrapper(blockContainer36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle33.setItemPaint((java.awt.Paint) color38);
        double double40 = legendTitle33.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot43 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset42);
        java.awt.Paint paint44 = multiplePiePlot43.getNoDataMessagePaint();
        java.awt.Paint paint45 = multiplePiePlot43.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart46 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot43);
        jFreeChart46.setBackgroundImageAlignment((int) (short) 0);
        legendTitle33.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart46);
        java.awt.Stroke stroke50 = jFreeChart46.getBorderStroke();
        java.awt.Stroke stroke51 = jFreeChart46.getBorderStroke();
        multiplePiePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart46);
        org.jfree.data.category.CategoryDataset categoryDataset53 = multiplePiePlot1.getDataset();
        double double54 = multiplePiePlot1.getLimit();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rect" + "'", str20.equals("rect"));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNull(categoryDataset53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        java.awt.Paint paint4 = multiplePiePlot3.getNoDataMessagePaint();
        java.awt.Paint paint5 = multiplePiePlot3.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot3);
        java.awt.Paint paint7 = jFreeChart6.getBorderPaint();
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle9.getPadding();
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle9.getBounds();
        java.awt.Paint paint13 = legendTitle9.getItemPaint();
        double double14 = legendTitle9.getContentXOffset();
        jFreeChart6.removeSubtitle((org.jfree.chart.title.Title) legendTitle9);
        java.awt.Paint paint16 = jFreeChart6.getBackgroundPaint();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        double double19 = legendTitle18.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent20 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle18);
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        titleChangeEvent20.setChart(jFreeChart21);
        java.lang.String str23 = titleChangeEvent20.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = titleChangeEvent20.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 'a', jFreeChart6, chartChangeEventType24);
        org.jfree.chart.JFreeChart jFreeChart26 = chartChangeEvent25.getChart();
        java.awt.Paint paint27 = jFreeChart26.getBorderPaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType24);
        org.junit.Assert.assertNotNull(jFreeChart26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        titleChangeEvent3.setChart(jFreeChart4);
        java.lang.String str6 = titleChangeEvent3.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = titleChangeEvent3.getType();
        java.lang.Object obj8 = titleChangeEvent3.getSource();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        defaultKeyedValues2D1.addValue((java.lang.Number) (short) -1, (java.lang.Comparable) 64, (java.lang.Comparable) 1.0f);
        java.lang.Comparable comparable10 = null;
        try {
            defaultKeyedValues2D1.setValue((java.lang.Number) (short) 10, comparable10, (java.lang.Comparable) "PieSection: 10, -48897(10)");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        double double1 = rotation0.getFactor();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image3 = projectInfo2.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image8 = projectInfo7.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo("ChartChangeEventType.NEW_DATASET", "", "Other", image8, "", "Multiple Pie Plot", "Multiple Pie Plot");
        projectInfo2.addLibrary((org.jfree.chart.ui.Library) projectInfo12);
        boolean boolean14 = rotation0.equals((java.lang.Object) projectInfo12);
        java.lang.String str15 = projectInfo12.getInfo();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertNotNull(image3);
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertNotNull(image8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Other" + "'", str15.equals("Other"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        double double17 = legendTitle9.getHeight();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset13, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        java.lang.String str20 = pieSectionEntity19.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass22 = rectangleInsets21.getClass();
        double double23 = rectangleInsets21.getLeft();
        double double25 = rectangleInsets21.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass27 = rectangleInsets26.getClass();
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle29.getPadding();
        legendTitle29.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle29.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        double double37 = legendTitle36.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle36.getPadding();
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle36.getBounds();
        rectangleInsets34.trim(rectangle2D39);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets26.createAdjustedRectangle(rectangle2D39, lengthAdjustmentType41, lengthAdjustmentType42);
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        double double46 = legendTitle45.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = legendTitle45.getPadding();
        java.awt.geom.Rectangle2D rectangle2D48 = legendTitle45.getBounds();
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets26.createInsetRectangle(rectangle2D48, false, true);
        org.jfree.chart.LegendItemSource legendItemSource52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle(legendItemSource52);
        double double54 = legendTitle53.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = legendTitle53.getPadding();
        legendTitle53.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource58 = null;
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle(legendItemSource58);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment60 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle59.setHorizontalAlignment(horizontalAlignment60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = legendTitle59.getLegendItemGraphicAnchor();
        legendTitle53.setLegendItemGraphicAnchor(rectangleAnchor62);
        java.awt.geom.Point2D point2D64 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D48, rectangleAnchor62);
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets21.createOutsetRectangle(rectangle2D48, false, true);
        pieSectionEntity19.setArea((java.awt.Shape) rectangle2D67);
        java.awt.Shape shape69 = pieSectionEntity19.getArea();
        java.awt.Image image73 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo77 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "hi!", image73, "", "hi!", "");
        java.util.List list78 = projectInfo77.getContributors();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo84 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets85 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass86 = rectangleInsets85.getClass();
        boolean boolean87 = basicProjectInfo84.equals((java.lang.Object) wildcardClass86);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo93 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets94 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass95 = rectangleInsets94.getClass();
        boolean boolean96 = basicProjectInfo93.equals((java.lang.Object) wildcardClass95);
        basicProjectInfo84.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo93);
        projectInfo77.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo93);
        boolean boolean99 = pieSectionEntity19.equals((java.lang.Object) projectInfo77);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PieSection: 255, -48897(10)" + "'", str20.equals("PieSection: 255, -48897(10)"));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(horizontalAlignment60);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(point2D64);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertNull(list78);
        org.junit.Assert.assertNotNull(rectangleInsets85);
        org.junit.Assert.assertNotNull(wildcardClass86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(rectangleInsets94);
        org.junit.Assert.assertNotNull(wildcardClass95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int int3 = java.awt.Color.HSBtoRGB(100.0f, (float) (byte) 0, (float) (-1L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-254) + "'", int3 == (-254));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset13, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        java.lang.String str20 = pieSectionEntity19.toString();
        pieSectionEntity19.setPieIndex((int) (short) 10);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        pieSectionEntity19.setDataset(pieDataset23);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = textTitle25.getTextAlignment();
        java.awt.Paint paint27 = textTitle25.getPaint();
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle25.getBounds();
        pieSectionEntity19.setArea((java.awt.Shape) rectangle2D28);
        java.lang.String str30 = pieSectionEntity19.getShapeCoords();
        java.lang.String str31 = pieSectionEntity19.toString();
        pieSectionEntity19.setSectionKey((java.lang.Comparable) 0.14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PieSection: 255, -48897(10)" + "'", str20.equals("PieSection: 255, -48897(10)"));
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0,0,1,1" + "'", str30.equals("0,0,1,1"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "PieSection: 10, -48897(10)" + "'", str31.equals("PieSection: 10, -48897(10)"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass4 = rectangleInsets3.getClass();
        double double5 = rectangleInsets3.getLeft();
        double double7 = rectangleInsets3.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass9 = rectangleInsets8.getClass();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getPadding();
        legendTitle11.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle11.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        double double19 = legendTitle18.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle18.getPadding();
        java.awt.geom.Rectangle2D rectangle2D21 = legendTitle18.getBounds();
        rectangleInsets16.trim(rectangle2D21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets8.createAdjustedRectangle(rectangle2D21, lengthAdjustmentType23, lengthAdjustmentType24);
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        double double28 = legendTitle27.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle27.getPadding();
        java.awt.geom.Rectangle2D rectangle2D30 = legendTitle27.getBounds();
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets8.createInsetRectangle(rectangle2D30, false, true);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle35.getPadding();
        legendTitle35.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment42 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle41.setHorizontalAlignment(horizontalAlignment42);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = legendTitle41.getLegendItemGraphicAnchor();
        legendTitle35.setLegendItemGraphicAnchor(rectangleAnchor44);
        java.awt.geom.Point2D point2D46 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D30, rectangleAnchor44);
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets3.createOutsetRectangle(rectangle2D30, false, true);
        java.awt.Paint[] paintArray50 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.lang.Object obj51 = textTitle1.draw(graphics2D2, rectangle2D49, (java.lang.Object) paintArray50);
        java.awt.Paint[] paintArray52 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray53 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray54 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray55 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier56 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray50, paintArray52, strokeArray53, strokeArray54, shapeArray55);
        java.awt.Paint[] paintArray57 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray58 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment60 = textTitle59.getTextAlignment();
        java.awt.Paint paint61 = textTitle59.getPaint();
        java.awt.Stroke[] strokeArray62 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean63 = textTitle59.equals((java.lang.Object) strokeArray62);
        java.awt.Shape[] shapeArray64 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier65 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray52, paintArray57, strokeArray58, strokeArray62, shapeArray64);
        java.awt.Stroke stroke66 = defaultDrawingSupplier65.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(horizontalAlignment42);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(point2D46);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(paintArray50);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(paintArray52);
        org.junit.Assert.assertNotNull(strokeArray53);
        org.junit.Assert.assertNotNull(strokeArray54);
        org.junit.Assert.assertNotNull(shapeArray55);
        org.junit.Assert.assertNotNull(paintArray57);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(horizontalAlignment60);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(strokeArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(shapeArray64);
        org.junit.Assert.assertNotNull(stroke66);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        double double5 = legendTitle4.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle4.getPadding();
        java.awt.geom.Rectangle2D rectangle2D7 = legendTitle4.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D7, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.block.BlockContainer blockContainer15 = null;
        legendTitle12.setWrapper(blockContainer15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle12.setItemPaint((java.awt.Paint) color17);
        boolean boolean19 = chartEntity10.equals((java.lang.Object) legendTitle12);
        java.lang.String str20 = chartEntity10.getShapeType();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        double double23 = legendTitle22.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle22.getPadding();
        legendTitle22.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle22.getPadding();
        boolean boolean28 = chartEntity10.equals((java.lang.Object) rectangleInsets27);
        multiplePiePlot1.setInsets(rectangleInsets27, true);
        boolean boolean31 = multiplePiePlot1.isSubplot();
        multiplePiePlot1.setLimit((double) 1L);
        int int34 = multiplePiePlot1.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        multiplePiePlot1.setDataset(categoryDataset35);
        java.awt.Paint paint37 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.plot.Plot plot38 = null;
        multiplePiePlot1.setParent(plot38);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rect" + "'", str20.equals("rect"));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color5 = java.awt.Color.black;
        java.awt.Color color6 = color5.darker();
        float[] floatArray12 = new float[] { '#', (short) 10, '#', 2, 255 };
        float[] floatArray13 = color6.getRGBComponents(floatArray12);
        float[] floatArray14 = java.awt.Color.RGBtoHSB((int) (byte) -1, (-452), (-452), floatArray13);
        float[] floatArray15 = color1.getRGBColorComponents(floatArray13);
        float[] floatArray16 = color0.getRGBColorComponents(floatArray13);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(1);
        java.lang.Object obj3 = null;
        int int4 = objectList0.indexOf(obj3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets5.getUnitType();
        int int7 = objectList0.indexOf((java.lang.Object) rectangleInsets5);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        java.awt.Paint paint4 = multiplePiePlot3.getNoDataMessagePaint();
        java.awt.Paint paint5 = multiplePiePlot3.getNoDataMessagePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = multiplePiePlot3.getDrawingSupplier();
        boolean boolean7 = unitType1.equals((java.lang.Object) multiplePiePlot3);
        java.lang.Object obj8 = null;
        boolean boolean9 = unitType1.equals(obj8);
        java.awt.Color color10 = java.awt.Color.WHITE;
        int int11 = color10.getBlue();
        boolean boolean12 = unitType1.equals((java.lang.Object) int11);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(unitType1, (double) (byte) 100, (double) 0.5f, (double) (-48897), 5.120000000000001d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle1.getLegendItemGraphicEdge();
        boolean boolean7 = legendTitle1.getNotify();
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = legendTitle1.getVerticalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.block.BlockFrame blockFrame10 = legendTitle1.getFrame();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(blockFrame10);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.awt.Color color2 = java.awt.Color.getColor("ChartEntity: tooltip = ", (int) (short) 0);
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass6 = rectangleInsets5.getClass();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        legendTitle8.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle8.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle15.getPadding();
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle15.getBounds();
        rectangleInsets13.trim(rectangle2D18);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets5.createAdjustedRectangle(rectangle2D18, lengthAdjustmentType20, lengthAdjustmentType21);
        java.awt.Color color23 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, (java.awt.Paint) color23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass26 = rectangleInsets25.getClass();
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        double double29 = legendTitle28.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = legendTitle28.getPadding();
        legendTitle28.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendTitle28.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle35.getPadding();
        java.awt.geom.Rectangle2D rectangle2D38 = legendTitle35.getBounds();
        rectangleInsets33.trim(rectangle2D38);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets25.createAdjustedRectangle(rectangle2D38, lengthAdjustmentType40, lengthAdjustmentType41);
        org.jfree.chart.LegendItemSource legendItemSource43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle(legendItemSource43);
        double double45 = legendTitle44.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendTitle44.getPadding();
        java.awt.geom.Rectangle2D rectangle2D47 = legendTitle44.getBounds();
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets25.createInsetRectangle(rectangle2D47, false, true);
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets5.createInsetRectangle(rectangle2D47, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity56 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D47, "rect", "ChartChangeEventType.NEW_DATASET");
        java.awt.geom.AffineTransform affineTransform57 = null;
        org.jfree.data.category.CategoryDataset categoryDataset59 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot60 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset59);
        java.awt.Paint paint61 = multiplePiePlot60.getNoDataMessagePaint();
        java.awt.Paint paint62 = multiplePiePlot60.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot60);
        java.awt.RenderingHints renderingHints64 = jFreeChart63.getRenderingHints();
        java.awt.PaintContext paintContext65 = color2.createContext(colorModel3, rectangle4, rectangle2D47, affineTransform57, renderingHints64);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(renderingHints64);
        org.junit.Assert.assertNotNull(paintContext65);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle3.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle10.getBounds();
        rectangleInsets8.trim(rectangle2D13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets0.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType15, lengthAdjustmentType16);
        java.awt.Color color18 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color18);
        double double21 = rectangleInsets0.calculateTopOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double24 = rectangleInsets22.trimWidth((double) 2);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass28 = rectangleInsets27.getClass();
        org.jfree.chart.LegendItemSource legendItemSource29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource29);
        double double31 = legendTitle30.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendTitle30.getPadding();
        legendTitle30.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = legendTitle30.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle(legendItemSource36);
        double double38 = legendTitle37.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = legendTitle37.getPadding();
        java.awt.geom.Rectangle2D rectangle2D40 = legendTitle37.getBounds();
        rectangleInsets35.trim(rectangle2D40);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets27.createAdjustedRectangle(rectangle2D40, lengthAdjustmentType42, lengthAdjustmentType43);
        legendTitle26.setBounds(rectangle2D44);
        rectangleInsets22.trim(rectangle2D44);
        rectangleInsets0.trim(rectangle2D44);
        double double48 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        java.awt.Paint paint2 = textTitle0.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getTextAlignment();
        java.awt.Graphics2D graphics2D4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textTitle0.arrange(graphics2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        java.lang.Object obj19 = jFreeChart14.clone();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D21 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D21.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        java.lang.Object obj25 = defaultKeyedValues2D21.clone();
        java.util.List list26 = defaultKeyedValues2D21.getRowKeys();
        jFreeChart14.setSubtitles(list26);
        org.jfree.chart.LegendItemSource legendItemSource29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource29);
        double double31 = legendTitle30.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendTitle30.getPadding();
        legendTitle30.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = legendTitle30.getLegendItemGraphicEdge();
        boolean boolean36 = legendTitle30.getNotify();
        org.jfree.chart.util.VerticalAlignment verticalAlignment37 = legendTitle30.getVerticalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = legendTitle30.getLegendItemGraphicAnchor();
        try {
            jFreeChart14.addSubtitle((int) (byte) 1, (org.jfree.chart.title.Title) legendTitle30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(verticalAlignment37);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", image3, "hi!", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        projectInfo7.setCopyright("RectangleEdge.LEFT");
        projectInfo7.setInfo("JFreeChart");
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset13, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        java.lang.String str20 = pieSectionEntity19.toString();
        pieSectionEntity19.setPieIndex((int) (short) 10);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        pieSectionEntity19.setDataset(pieDataset23);
        java.lang.String str25 = pieSectionEntity19.getURLText();
        java.lang.String str26 = pieSectionEntity19.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PieSection: 255, -48897(10)" + "'", str20.equals("PieSection: 255, -48897(10)"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "RectangleEdge.LEFT" + "'", str25.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PieSection: 10, -48897(10)" + "'", str26.equals("PieSection: 10, -48897(10)"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.awt.Color color0 = java.awt.Color.green;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("rect");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name rect, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle1.getMargin();
        double double6 = rectangleInsets4.trimWidth((double) (-254));
        java.lang.String str7 = rectangleInsets4.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-254.0d) + "'", double6 == (-254.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str7.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getTextAlignment();
        textTitle5.setWidth((double) 100L);
        textTitle5.setText("");
        java.lang.String str11 = textTitle5.getText();
        org.jfree.chart.util.ObjectList objectList12 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj14 = objectList12.get(1);
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle5, obj14);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle16.getTextAlignment();
        textTitle16.setWidth((double) 100L);
        textTitle16.setText("");
        java.lang.String str22 = textTitle16.getText();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color27);
        textTitle16.setPaint((java.awt.Paint) color27);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset30);
        java.awt.Paint paint32 = multiplePiePlot31.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        multiplePiePlot31.notifyListeners(plotChangeEvent33);
        org.jfree.chart.JFreeChart jFreeChart35 = multiplePiePlot31.getPieChart();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle16, (java.lang.Object) multiplePiePlot31);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) columnArrangement4);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(jFreeChart35);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.distributeLabels((double) 2, (double) 1);
        pieLabelDistributor1.clear();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor5);
        java.awt.Color color7 = java.awt.Color.yellow;
        legendTitle1.setItemPaint((java.awt.Paint) color7);
        java.awt.Paint paint9 = legendTitle1.getBackgroundPaint();
        double double10 = legendTitle1.getContentYOffset();
        org.jfree.chart.block.BlockFrame blockFrame11 = legendTitle1.getFrame();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame11);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass12 = rectangleInsets11.getClass();
        double double13 = rectangleInsets11.getLeft();
        double double15 = rectangleInsets11.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass17 = rectangleInsets16.getClass();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        legendTitle19.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle19.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        rectangleInsets24.trim(rectangle2D29);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets16.createAdjustedRectangle(rectangle2D29, lengthAdjustmentType31, lengthAdjustmentType32);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle35.getPadding();
        java.awt.geom.Rectangle2D rectangle2D38 = legendTitle35.getBounds();
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets16.createInsetRectangle(rectangle2D38, false, true);
        org.jfree.chart.LegendItemSource legendItemSource42 = null;
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle(legendItemSource42);
        double double44 = legendTitle43.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = legendTitle43.getPadding();
        legendTitle43.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource48 = null;
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle(legendItemSource48);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment50 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle49.setHorizontalAlignment(horizontalAlignment50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = legendTitle49.getLegendItemGraphicAnchor();
        legendTitle43.setLegendItemGraphicAnchor(rectangleAnchor52);
        java.awt.geom.Point2D point2D54 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D38, rectangleAnchor52);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets11.createOutsetRectangle(rectangle2D38, false, true);
        legendTitle8.setPadding(rectangleInsets11);
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.image.ColorModel colorModel60 = null;
        java.awt.Rectangle rectangle61 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass63 = rectangleInsets62.getClass();
        org.jfree.chart.LegendItemSource legendItemSource64 = null;
        org.jfree.chart.title.LegendTitle legendTitle65 = new org.jfree.chart.title.LegendTitle(legendItemSource64);
        double double66 = legendTitle65.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = legendTitle65.getPadding();
        legendTitle65.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = legendTitle65.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource71 = null;
        org.jfree.chart.title.LegendTitle legendTitle72 = new org.jfree.chart.title.LegendTitle(legendItemSource71);
        double double73 = legendTitle72.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = legendTitle72.getPadding();
        java.awt.geom.Rectangle2D rectangle2D75 = legendTitle72.getBounds();
        rectangleInsets70.trim(rectangle2D75);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType77 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType78 = null;
        java.awt.geom.Rectangle2D rectangle2D79 = rectangleInsets62.createAdjustedRectangle(rectangle2D75, lengthAdjustmentType77, lengthAdjustmentType78);
        java.awt.geom.AffineTransform affineTransform80 = null;
        java.awt.RenderingHints renderingHints81 = null;
        java.awt.PaintContext paintContext82 = color59.createContext(colorModel60, rectangle61, rectangle2D79, affineTransform80, renderingHints81);
        java.awt.geom.Rectangle2D rectangle2D83 = rectangleInsets11.createOutsetRectangle(rectangle2D79);
        piePlot1.setLegendItemShape((java.awt.Shape) rectangle2D83);
        double double85 = piePlot1.getLabelGap();
        java.awt.Stroke stroke86 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator87 = piePlot1.getLegendLabelGenerator();
        java.lang.Object obj88 = null;
        boolean boolean89 = piePlot1.equals(obj88);
        double double91 = piePlot1.getExplodePercent((java.lang.Comparable) "{0}");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(horizontalAlignment50);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(point2D54);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(paintContext82);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.025d + "'", double85 == 0.025d);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.Paint paint6 = jFreeChart5.getBorderPaint();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        java.awt.Paint paint12 = legendTitle8.getItemPaint();
        double double13 = legendTitle8.getContentXOffset();
        jFreeChart5.removeSubtitle((org.jfree.chart.title.Title) legendTitle8);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.String str16 = rectangleEdge15.toString();
        legendTitle8.setPosition(rectangleEdge15);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleEdge.BOTTOM" + "'", str16.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getTextAlignment();
        textTitle5.setWidth((double) 100L);
        textTitle5.setText("");
        java.lang.String str11 = textTitle5.getText();
        org.jfree.chart.util.ObjectList objectList12 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj14 = objectList12.get(1);
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle5, obj14);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle16.getTextAlignment();
        textTitle16.setWidth((double) 100L);
        textTitle16.setText("");
        java.lang.String str22 = textTitle16.getText();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color27);
        textTitle16.setPaint((java.awt.Paint) color27);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset30);
        java.awt.Paint paint32 = multiplePiePlot31.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        multiplePiePlot31.notifyListeners(plotChangeEvent33);
        org.jfree.chart.JFreeChart jFreeChart35 = multiplePiePlot31.getPieChart();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle16, (java.lang.Object) multiplePiePlot31);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent37 = null;
        multiplePiePlot31.axisChanged(axisChangeEvent37);
        multiplePiePlot31.setAggregatedItemsKey((java.lang.Comparable) "TableOrder.BY_COLUMN");
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(jFreeChart35);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image1 = projectInfo0.getLogo();
//        java.lang.String str2 = projectInfo0.getInfo();
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D3 = new org.jfree.data.DefaultKeyedValues2D();
//        java.util.List list4 = defaultKeyedValues2D3.getColumnKeys();
//        projectInfo0.setContributors(list4);
//        java.lang.String str6 = projectInfo0.getName();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(image1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UnitType.ABSOLUTE" + "'", str2.equals("UnitType.ABSOLUTE"));
//        org.junit.Assert.assertNotNull(list4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JFreeChart" + "'", str6.equals("JFreeChart"));
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        org.jfree.data.general.DatasetGroup datasetGroup2 = defaultCategoryDataset0.getGroup();
        try {
            java.lang.Comparable comparable4 = defaultCategoryDataset0.getColumnKey((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass7 = rectangleInsets6.getClass();
        boolean boolean8 = basicProjectInfo5.equals((java.lang.Object) wildcardClass7);
        org.jfree.chart.ui.Library[] libraryArray9 = basicProjectInfo5.getLibraries();
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(libraryArray9);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getOutlineStroke();
        java.lang.String str2 = piePlot0.getPlotType();
        try {
            piePlot0.setInteriorGap((double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (2.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "hi!", image4, "", "hi!", "");
        java.util.List list9 = projectInfo8.getContributors();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass17 = rectangleInsets16.getClass();
        boolean boolean18 = basicProjectInfo15.equals((java.lang.Object) wildcardClass17);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo24 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass26 = rectangleInsets25.getClass();
        boolean boolean27 = basicProjectInfo24.equals((java.lang.Object) wildcardClass26);
        basicProjectInfo15.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
        projectInfo8.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo8);
        basicProjectInfo0.setName("0,0,1,1");
        org.junit.Assert.assertNull(list9);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("PieSection: 255, -48897(10)", "Multiple Pie Plot", "0,-1,1,1", "RectangleEdge.RIGHT", "HorizontalAlignment.RIGHT");
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        piePlot1.setExplodePercent((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (double) (short) 1);
        piePlot1.setMinimumArcAngleToDraw((double) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        java.awt.Paint paint13 = multiplePiePlot12.getNoDataMessagePaint();
        java.awt.Paint paint14 = multiplePiePlot12.getNoDataMessagePaint();
        java.awt.Stroke stroke15 = multiplePiePlot12.getOutlineStroke();
        piePlot1.setLabelLinkStroke(stroke15);
        java.awt.Paint paint17 = piePlot1.getBaseSectionPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D2.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        defaultKeyedValues2D2.addValue((java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 1.0f);
        int int10 = defaultKeyedValues2D2.getColumnCount();
        java.util.List list11 = defaultKeyedValues2D2.getRowKeys();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        boolean boolean13 = defaultKeyedValues2D2.equals((java.lang.Object) color12);
        boolean boolean14 = unitType0.equals((java.lang.Object) color12);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getRight();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset2.validateObject();
        org.jfree.data.general.DatasetGroup datasetGroup4 = defaultCategoryDataset2.getGroup();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets0, (org.jfree.data.general.Dataset) defaultCategoryDataset2);
        java.lang.Comparable comparable6 = null;
        try {
            int int7 = defaultCategoryDataset2.getColumnIndex(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(datasetGroup4);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        java.awt.Color color2 = java.awt.Color.YELLOW;
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color2.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        boolean boolean9 = standardPieSectionLabelGenerator1.equals((java.lang.Object) renderingHints7);
        java.text.AttributedString attributedString11 = null;
        standardPieSectionLabelGenerator1.setAttributedLabel(2, attributedString11);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paintContext8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        piePlot1.setExplodePercent((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (double) (short) 1);
        piePlot1.setMinimumArcAngleToDraw((double) (byte) 0);
        java.awt.Paint paint11 = null;
        piePlot1.setLabelOutlinePaint(paint11);
        piePlot1.setLabelGap((double) (-48897));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        java.awt.Paint paint5 = legendTitle1.getItemPaint();
        org.jfree.chart.event.TitleChangeListener titleChangeListener6 = null;
        legendTitle1.addChangeListener(titleChangeListener6);
        org.jfree.chart.block.BlockContainer blockContainer8 = legendTitle1.getItemContainer();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(blockContainer8);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle20.getTextAlignment();
        java.awt.Paint paint22 = textTitle20.getPaint();
        java.awt.Stroke[] strokeArray23 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean24 = textTitle20.equals((java.lang.Object) strokeArray23);
        jFreeChart14.addSubtitle((org.jfree.chart.title.Title) textTitle20);
        java.lang.Object obj26 = textTitle20.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        jFreeChart14.setTextAntiAlias(false);
        java.awt.Paint paint22 = null;
        jFreeChart14.setBackgroundPaint(paint22);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        try {
            java.awt.image.BufferedImage bufferedImage28 = jFreeChart14.createBufferedImage(2, 10, (-48897), chartRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type -48897");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        java.awt.Shape shape4 = piePlot1.getLegendItemShape();
        java.awt.Paint paint5 = piePlot1.getLabelOutlinePaint();
        piePlot1.setPieIndex((int) (byte) 10);
        try {
            piePlot1.setBackgroundImageAlpha((float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, (-48897), 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        java.lang.String str1 = tableOrder0.toString();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        java.awt.Paint paint5 = multiplePiePlot4.getNoDataMessagePaint();
        java.awt.Paint paint6 = multiplePiePlot4.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot4);
        java.awt.RenderingHints renderingHints8 = jFreeChart7.getRenderingHints();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean11 = chartChangeEventType9.equals((java.lang.Object) 8.0d);
        java.lang.String str12 = chartChangeEventType9.toString();
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color17);
        boolean boolean19 = chartChangeEventType9.equals((java.lang.Object) (short) 100);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) str1, jFreeChart7, chartChangeEventType9);
        boolean boolean21 = jFreeChart7.getAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) jFreeChart7);
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TableOrder.BY_COLUMN" + "'", str1.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(renderingHints8);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str12.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (byte) -1, (java.awt.Paint) color5);
        float float7 = piePlot1.getForegroundAlpha();
        piePlot1.setLabelLinkMargin(1.0E-5d);
        boolean boolean10 = piePlot1.getSectionOutlinesVisible();
        java.awt.Stroke stroke11 = piePlot1.getLabelOutlineStroke();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        java.awt.geom.Rectangle2D rectangle2D7 = legendTitle1.getBounds();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        piePlot9.setExplodePercent((java.lang.Comparable) (-254.0d), (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot9.getLabelPadding();
        boolean boolean14 = piePlot9.isCircular();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = piePlot9.getSimpleLabelOffset();
        double double17 = rectangleInsets15.calculateBottomInset(2.0d);
        double double19 = rectangleInsets15.trimHeight((double) 8);
        legendTitle1.setMargin(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.36d + "'", double17 == 0.36d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 5.120000000000001d + "'", double19 == 5.120000000000001d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getURLText();
        textTitle0.setText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        defaultKeyedValues2D1.addValue((java.lang.Number) (short) -1, (java.lang.Comparable) 64, (java.lang.Comparable) 1.0f);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent12 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle10);
        org.jfree.chart.block.BlockContainer blockContainer13 = null;
        legendTitle10.setWrapper(blockContainer13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle10.setItemPaint((java.awt.Paint) color15);
        double double17 = legendTitle10.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset19);
        java.awt.Paint paint21 = multiplePiePlot20.getNoDataMessagePaint();
        java.awt.Paint paint22 = multiplePiePlot20.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot20);
        jFreeChart23.setBackgroundImageAlignment((int) (short) 0);
        legendTitle10.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = legendTitle10.getLegendItemGraphicLocation();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent28 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle10);
        boolean boolean29 = defaultKeyedValues2D1.equals((java.lang.Object) titleChangeEvent28);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getSectionOutlinesVisible();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        piePlot1.setDataset(pieDataset3);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLabelGenerator();
        org.jfree.chart.util.Rotation rotation6 = piePlot1.getDirection();
        piePlot1.setIgnoreNullValues(true);
        double double9 = piePlot1.getMinimumArcAngleToDraw();
        piePlot1.setShadowYOffset((double) (-452));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-5d + "'", double9 == 1.0E-5d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        multiplePiePlot1.notifyListeners(plotChangeEvent3);
        org.jfree.chart.JFreeChart jFreeChart5 = multiplePiePlot1.getPieChart();
        float float6 = multiplePiePlot1.getBackgroundAlpha();
        multiplePiePlot1.zoom(5.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        double double7 = piePlot1.getInteriorGap();
        java.awt.Paint paint8 = piePlot1.getLabelShadowPaint();
        java.awt.Stroke stroke9 = piePlot1.getLabelOutlineStroke();
        boolean boolean10 = piePlot1.getIgnoreZeroValues();
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color12);
        piePlot1.setSectionPaint((java.lang.Comparable) "JFreeChart", (java.awt.Paint) color12);
        piePlot1.setIgnoreZeroValues(false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        piePlot1.setLabelPaint((java.awt.Paint) color17);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        multiplePiePlot1.notifyListeners(plotChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        java.awt.Paint paint7 = multiplePiePlot6.getAggregatedItemsPaint();
        multiplePiePlot1.setParent((org.jfree.chart.plot.Plot) multiplePiePlot6);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot6);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = multiplePiePlot6.getLegendItems();
        int int11 = multiplePiePlot6.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str1.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle20.getTextAlignment();
        java.awt.Paint paint22 = textTitle20.getPaint();
        java.awt.Stroke[] strokeArray23 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean24 = textTitle20.equals((java.lang.Object) strokeArray23);
        jFreeChart14.addSubtitle((org.jfree.chart.title.Title) textTitle20);
        boolean boolean26 = textTitle20.getNotify();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle2.getTextAlignment();
        java.awt.Paint paint4 = textTitle2.getPaint();
        java.awt.geom.Rectangle2D rectangle2D5 = textTitle2.getBounds();
        java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createOutsetRectangle(rectangle2D5);
        double double8 = rectangleInsets0.trimHeight((double) 128);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        java.lang.String str10 = textTitle9.getURLText();
        textTitle9.setPadding((double) 0, (-1.0d), (double) (byte) 10, (double) 10L);
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle9.getBounds();
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets0.createInsetRectangle(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 126.0d + "'", double8 == 126.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        double double7 = piePlot1.getInteriorGap();
        java.awt.Paint paint8 = piePlot1.getLabelShadowPaint();
        java.awt.Stroke stroke9 = piePlot1.getLabelOutlineStroke();
        boolean boolean10 = piePlot1.getIgnoreZeroValues();
        java.awt.Shape shape11 = piePlot1.getLegendItemShape();
        piePlot1.setLabelLinkMargin((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        textTitle0.setWidth((double) 100L);
        textTitle0.setText("");
        java.lang.String str6 = textTitle0.getText();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color11);
        textTitle0.setPaint((java.awt.Paint) color11);
        int int14 = color11.getGreen();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        org.jfree.data.general.DatasetGroup datasetGroup2 = defaultCategoryDataset0.getGroup();
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 0, (float) '#', (float) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean5 = color3.equals((java.lang.Object) rectangleEdge4);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        java.lang.Class<?> wildcardClass7 = color3.getClass();
        java.lang.String str8 = color3.toString();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str8.equals("java.awt.Color[r=0,g=0,b=0]"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D1 = textTitle0.getBounds();
        textTitle0.setToolTipText("");
        org.junit.Assert.assertNotNull(rectangle2D1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle3);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle3.setItemPaint((java.awt.Paint) color8);
        double double10 = legendTitle3.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset12);
        java.awt.Paint paint14 = multiplePiePlot13.getNoDataMessagePaint();
        java.awt.Paint paint15 = multiplePiePlot13.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot13);
        jFreeChart16.setBackgroundImageAlignment((int) (short) 0);
        legendTitle3.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart16);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart16.setBorderPaint((java.awt.Paint) color20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textTitle22.getTextAlignment();
        java.awt.Paint paint24 = textTitle22.getPaint();
        java.awt.Stroke[] strokeArray25 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean26 = textTitle22.equals((java.lang.Object) strokeArray25);
        jFreeChart16.addSubtitle((org.jfree.chart.title.Title) textTitle22);
        jFreeChart16.setTextAntiAlias(true);
        org.jfree.chart.LegendItemSource legendItemSource30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle(legendItemSource30);
        double double32 = legendTitle31.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent33 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle31);
        org.jfree.chart.JFreeChart jFreeChart34 = null;
        titleChangeEvent33.setChart(jFreeChart34);
        jFreeChart16.titleChanged(titleChangeEvent33);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType37 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean39 = chartChangeEventType37.equals((java.lang.Object) 8.0d);
        java.lang.String str40 = chartChangeEventType37.toString();
        java.awt.Color color45 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color45);
        boolean boolean47 = chartChangeEventType37.equals((java.lang.Object) (short) 100);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockBorder1, jFreeChart16, chartChangeEventType37);
        jFreeChart16.setBackgroundImageAlignment((int) ' ');
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str40.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        defaultKeyedValues2D1.addValue((java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 1.0f);
        java.lang.Object obj9 = defaultKeyedValues2D1.clone();
        java.util.List list10 = defaultKeyedValues2D1.getRowKeys();
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            java.lang.Comparable comparable2 = defaultKeyedValues2D0.getRowKey(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        legendTitle1.setHeight((double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass11 = rectangleInsets10.getClass();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        double double14 = legendTitle13.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle13.getPadding();
        legendTitle13.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle13.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        double double21 = legendTitle20.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle20.getPadding();
        java.awt.geom.Rectangle2D rectangle2D23 = legendTitle20.getBounds();
        rectangleInsets18.trim(rectangle2D23);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets10.createAdjustedRectangle(rectangle2D23, lengthAdjustmentType25, lengthAdjustmentType26);
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle29.getPadding();
        java.awt.geom.Rectangle2D rectangle2D32 = legendTitle29.getBounds();
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets10.createInsetRectangle(rectangle2D32, false, true);
        rectangleInsets8.trim(rectangle2D32);
        legendTitle1.setPadding(rectangleInsets8);
        double double39 = rectangleInsets8.calculateTopOutset((double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list1 = defaultKeyedValues2D0.getColumnKeys();
        java.lang.Object obj2 = defaultKeyedValues2D0.clone();
        int int3 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.removeValue((java.lang.Comparable) 15, (java.lang.Comparable) "ChartEntity: tooltip = ");
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleEdge.LEFT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getSectionOutlinesVisible();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        piePlot1.setDataset(pieDataset3);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLabelGenerator();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator6);
        org.jfree.chart.util.Rotation rotation8 = piePlot1.getDirection();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean14 = piePlot11.getSimpleLabels();
        double double15 = piePlot11.getInteriorGap();
        boolean boolean16 = piePlot11.getLabelLinksVisible();
        double double17 = piePlot11.getInteriorGap();
        java.awt.Paint paint18 = piePlot11.getLabelShadowPaint();
        java.awt.Stroke stroke19 = piePlot11.getLabelOutlineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) (short) 10, stroke19);
        boolean boolean21 = piePlot1.isOutlineVisible();
        java.awt.Color color22 = java.awt.Color.BLUE;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color22);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(rotation8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.08d + "'", double17 == 0.08d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 1L, 0.0d, (double) (short) 100, (double) 15);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        java.awt.Paint paint11 = multiplePiePlot10.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        multiplePiePlot10.notifyListeners(plotChangeEvent12);
        java.awt.Paint paint14 = multiplePiePlot10.getNoDataMessagePaint();
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 192, 4.0d, (double) (byte) 10, 0.0d, paint14);
        piePlot1.setSectionPaint((java.lang.Comparable) 98.0d, paint14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        piePlot1.axisChanged(axisChangeEvent17);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        legendTitle20.setLegendItemGraphicPadding(rectangleInsets21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = legendTitle20.getItemLabelPadding();
        double double25 = rectangleInsets23.extendHeight((double) (byte) 1);
        piePlot1.setSimpleLabelOffset(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 5.0d + "'", double25 == 5.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle1.setHorizontalAlignment(horizontalAlignment2);
        legendTitle1.setPadding((double) (short) 0, (double) (-1L), 0.0d, (double) (short) -1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle1.getHorizontalAlignment();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int11 = color10.getRed();
        legendTitle1.setBackgroundPaint((java.awt.Paint) color10);
        java.awt.Color color13 = java.awt.Color.ORANGE;
        java.awt.Color color14 = java.awt.Color.black;
        java.awt.Color color15 = color14.darker();
        float[] floatArray21 = new float[] { '#', (short) 10, '#', 2, 255 };
        float[] floatArray22 = color15.getRGBComponents(floatArray21);
        float[] floatArray23 = color13.getRGBColorComponents(floatArray21);
        float[] floatArray24 = color10.getRGBComponents(floatArray23);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 192 + "'", int11 == 192);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        java.lang.Object obj19 = jFreeChart14.clone();
        jFreeChart14.setTextAntiAlias(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (byte) -1, (java.awt.Paint) color5);
        float float7 = piePlot1.getForegroundAlpha();
        piePlot1.setLabelLinkMargin(1.0E-5d);
        boolean boolean10 = piePlot1.getSectionOutlinesVisible();
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.block.BlockContainer blockContainer15 = null;
        legendTitle12.setWrapper(blockContainer15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle12.setItemPaint((java.awt.Paint) color17);
        double double19 = legendTitle12.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset21);
        java.awt.Paint paint23 = multiplePiePlot22.getNoDataMessagePaint();
        java.awt.Paint paint24 = multiplePiePlot22.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot22);
        jFreeChart25.setBackgroundImageAlignment((int) (short) 0);
        legendTitle12.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart25);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart25.setBorderPaint((java.awt.Paint) color29);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = textTitle31.getTextAlignment();
        java.awt.Paint paint33 = textTitle31.getPaint();
        java.awt.Stroke[] strokeArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean35 = textTitle31.equals((java.lang.Object) strokeArray34);
        jFreeChart25.addSubtitle((org.jfree.chart.title.Title) textTitle31);
        int int37 = jFreeChart25.getBackgroundImageAlignment();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart25);
        int int39 = piePlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(horizontalAlignment32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 15 + "'", int39 == 15);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        double double7 = piePlot1.getInteriorGap();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Object obj4 = multiplePiePlot1.clone();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        double double8 = legendTitle7.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle7.getPadding();
        java.lang.String str10 = rectangleInsets9.toString();
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass14 = rectangleInsets13.getClass();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        double double17 = legendTitle16.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getPadding();
        legendTitle16.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle16.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        double double24 = legendTitle23.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle23.getPadding();
        java.awt.geom.Rectangle2D rectangle2D26 = legendTitle23.getBounds();
        rectangleInsets21.trim(rectangle2D26);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType28 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets13.createAdjustedRectangle(rectangle2D26, lengthAdjustmentType28, lengthAdjustmentType29);
        legendTitle12.setBounds(rectangle2D30);
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets9.createOutsetRectangle(rectangle2D30, false, true);
        try {
            multiplePiePlot1.drawOutline(graphics2D5, rectangle2D34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str10.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D34);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass4 = rectangleInsets3.getClass();
        double double5 = rectangleInsets3.getLeft();
        double double7 = rectangleInsets3.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass9 = rectangleInsets8.getClass();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getPadding();
        legendTitle11.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle11.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        double double19 = legendTitle18.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle18.getPadding();
        java.awt.geom.Rectangle2D rectangle2D21 = legendTitle18.getBounds();
        rectangleInsets16.trim(rectangle2D21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets8.createAdjustedRectangle(rectangle2D21, lengthAdjustmentType23, lengthAdjustmentType24);
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        double double28 = legendTitle27.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle27.getPadding();
        java.awt.geom.Rectangle2D rectangle2D30 = legendTitle27.getBounds();
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets8.createInsetRectangle(rectangle2D30, false, true);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle35.getPadding();
        legendTitle35.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment42 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle41.setHorizontalAlignment(horizontalAlignment42);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = legendTitle41.getLegendItemGraphicAnchor();
        legendTitle35.setLegendItemGraphicAnchor(rectangleAnchor44);
        java.awt.geom.Point2D point2D46 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D30, rectangleAnchor44);
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets3.createOutsetRectangle(rectangle2D30, false, true);
        java.awt.Paint[] paintArray50 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.lang.Object obj51 = textTitle1.draw(graphics2D2, rectangle2D49, (java.lang.Object) paintArray50);
        org.jfree.chart.block.BlockFrame blockFrame52 = textTitle1.getFrame();
        boolean boolean53 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(horizontalAlignment42);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(point2D46);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(paintArray50);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(blockFrame52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray6 = null;
        try {
            legendTitle1.setSources(legendItemSourceArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'sources' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = blockContainer0.getArrangement();
        java.lang.String str2 = blockContainer0.getID();
        org.junit.Assert.assertNotNull(arrangement1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        jFreeChart14.setTextAntiAlias(false);
        java.awt.Stroke stroke22 = jFreeChart14.getBorderStroke();
        int int23 = jFreeChart14.getBackgroundImageAlignment();
        jFreeChart14.setBackgroundImageAlpha((float) ' ');
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle27.setHorizontalAlignment(horizontalAlignment28);
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement33 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment28, verticalAlignment30, (double) (short) 10, (double) 10.0f);
        java.awt.Image image37 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo41 = new org.jfree.chart.ui.ProjectInfo("", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", image37, "hi!", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D42 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list43 = defaultKeyedValues2D42.getColumnKeys();
        projectInfo41.setContributors(list43);
        boolean boolean45 = verticalAlignment30.equals((java.lang.Object) list43);
        jFreeChart14.setSubtitles(list43);
        org.jfree.chart.title.LegendTitle legendTitle47 = jFreeChart14.getLegend();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(legendTitle47);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        java.lang.Object obj19 = jFreeChart14.clone();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D21 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D21.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        java.lang.Object obj25 = defaultKeyedValues2D21.clone();
        java.util.List list26 = defaultKeyedValues2D21.getRowKeys();
        jFreeChart14.setSubtitles(list26);
        java.util.List list28 = jFreeChart14.getSubtitles();
        boolean boolean29 = jFreeChart14.getAntiAlias();
        java.awt.Paint paint30 = null;
        jFreeChart14.setBorderPaint(paint30);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.util.Rotation rotation1 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        java.awt.geom.Rectangle2D rectangle2D6 = legendTitle3.getBounds();
        boolean boolean7 = rotation1.equals((java.lang.Object) legendTitle3);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle8.getTextAlignment();
        java.awt.Paint paint10 = textTitle8.getBackgroundPaint();
        org.jfree.chart.block.BlockFrame blockFrame11 = textTitle8.getFrame();
        java.awt.Paint paint12 = textTitle8.getPaint();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.awt.Paint paint15 = multiplePiePlot14.getAggregatedItemsPaint();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        double double18 = legendTitle17.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle17.getPadding();
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle17.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D20, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        double double26 = legendTitle25.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent27 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle25);
        org.jfree.chart.block.BlockContainer blockContainer28 = null;
        legendTitle25.setWrapper(blockContainer28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle25.setItemPaint((java.awt.Paint) color30);
        boolean boolean32 = chartEntity23.equals((java.lang.Object) legendTitle25);
        java.lang.String str33 = chartEntity23.getShapeType();
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle35.getPadding();
        legendTitle35.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = legendTitle35.getPadding();
        boolean boolean41 = chartEntity23.equals((java.lang.Object) rectangleInsets40);
        multiplePiePlot14.setInsets(rectangleInsets40, true);
        java.awt.Image image44 = multiplePiePlot14.getBackgroundImage();
        java.awt.Font font45 = multiplePiePlot14.getNoDataMessageFont();
        textTitle8.setFont(font45);
        legendTitle3.setItemFont(font45);
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle("PieSection: 255, -48897(10)", font45);
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass51 = rectangleInsets50.getClass();
        org.jfree.chart.LegendItemSource legendItemSource52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle(legendItemSource52);
        double double54 = legendTitle53.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = legendTitle53.getPadding();
        legendTitle53.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = legendTitle53.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource59 = null;
        org.jfree.chart.title.LegendTitle legendTitle60 = new org.jfree.chart.title.LegendTitle(legendItemSource59);
        double double61 = legendTitle60.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = legendTitle60.getPadding();
        java.awt.geom.Rectangle2D rectangle2D63 = legendTitle60.getBounds();
        rectangleInsets58.trim(rectangle2D63);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType65 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets50.createAdjustedRectangle(rectangle2D63, lengthAdjustmentType65, lengthAdjustmentType66);
        textTitle48.draw(graphics2D49, rectangle2D67);
        org.junit.Assert.assertNotNull(rotation1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(blockFrame11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "rect" + "'", str33.equals("rect"));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(image44);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D67);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        double double5 = legendTitle4.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle4.getPadding();
        java.awt.geom.Rectangle2D rectangle2D7 = legendTitle4.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D7, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.block.BlockContainer blockContainer15 = null;
        legendTitle12.setWrapper(blockContainer15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle12.setItemPaint((java.awt.Paint) color17);
        boolean boolean19 = chartEntity10.equals((java.lang.Object) legendTitle12);
        java.lang.String str20 = chartEntity10.getShapeType();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        double double23 = legendTitle22.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle22.getPadding();
        legendTitle22.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle22.getPadding();
        boolean boolean28 = chartEntity10.equals((java.lang.Object) rectangleInsets27);
        multiplePiePlot1.setInsets(rectangleInsets27, true);
        java.awt.Image image31 = multiplePiePlot1.getBackgroundImage();
        java.awt.Font font32 = multiplePiePlot1.getNoDataMessageFont();
        org.jfree.chart.util.TableOrder tableOrder33 = multiplePiePlot1.getDataExtractOrder();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rect" + "'", str20.equals("rect"));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(image31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(tableOrder33);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        java.awt.Paint paint4 = multiplePiePlot3.getNoDataMessagePaint();
        java.awt.Paint paint5 = multiplePiePlot3.getNoDataMessagePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = multiplePiePlot3.getDrawingSupplier();
        boolean boolean7 = unitType1.equals((java.lang.Object) multiplePiePlot3);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(unitType1, (double) (short) 1, (double) 15, 100.0d, 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset7);
        java.awt.Paint paint9 = multiplePiePlot8.getNoDataMessagePaint();
        java.awt.Paint paint10 = multiplePiePlot8.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot8);
        jFreeChart11.setBackgroundImageAlignment((int) (short) 0);
        multiplePiePlot2.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart11);
        java.lang.String str15 = multiplePiePlot2.getNoDataMessage();
        java.awt.Font font16 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        multiplePiePlot2.setNoDataMessageFont(font16);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) font16);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        try {
            java.awt.Color color1 = java.awt.Color.decode("PieSection: 10, -48897(10)");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"PieSection: 10, -48897(10)\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setExplodePercent((java.lang.Comparable) (-254.0d), (double) ' ');
        piePlot1.setCircular(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot1.getSimpleLabelOffset();
        java.lang.Object obj9 = piePlot1.clone();
        piePlot1.setLabelLinksVisible(true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int2 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) (byte) 1);
        try {
            java.lang.Comparable comparable4 = defaultKeyedValues2D0.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        double double2 = rectangleInsets0.getLeft();
        double double4 = rectangleInsets0.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass6 = rectangleInsets5.getClass();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        legendTitle8.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle8.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle15.getPadding();
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle15.getBounds();
        rectangleInsets13.trim(rectangle2D18);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets5.createAdjustedRectangle(rectangle2D18, lengthAdjustmentType20, lengthAdjustmentType21);
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource23);
        double double25 = legendTitle24.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle24.getPadding();
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets5.createInsetRectangle(rectangle2D27, false, true);
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle(legendItemSource31);
        double double33 = legendTitle32.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle32.getPadding();
        legendTitle32.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource37 = null;
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle(legendItemSource37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle38.setHorizontalAlignment(horizontalAlignment39);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = legendTitle38.getLegendItemGraphicAnchor();
        legendTitle32.setLegendItemGraphicAnchor(rectangleAnchor41);
        java.awt.geom.Point2D point2D43 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D27, rectangleAnchor41);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets0.createOutsetRectangle(rectangle2D27, false, true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset47 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset47.validateObject();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent49 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) false, (org.jfree.data.general.Dataset) defaultCategoryDataset47);
        try {
            defaultCategoryDataset47.removeColumn((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(point2D43);
        org.junit.Assert.assertNotNull(rectangle2D46);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        piePlot1.setExplodePercent((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (double) (short) 1);
        piePlot1.setMinimumArcAngleToDraw((double) (byte) 0);
        java.awt.Paint paint12 = piePlot1.getSectionPaint((java.lang.Comparable) 5.120000000000001d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        java.lang.Object obj19 = jFreeChart14.clone();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D21 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D21.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        java.lang.Object obj25 = defaultKeyedValues2D21.clone();
        java.util.List list26 = defaultKeyedValues2D21.getRowKeys();
        jFreeChart14.setSubtitles(list26);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.ui.ProjectInfo projectInfo30 = new org.jfree.chart.ui.ProjectInfo();
        boolean boolean31 = color28.equals((java.lang.Object) projectInfo30);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Multiple Pie Plot");
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator7);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = textTitle9.getTextAlignment();
        java.awt.Paint paint11 = textTitle9.getPaint();
        java.awt.Stroke[] strokeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean13 = textTitle9.equals((java.lang.Object) strokeArray12);
        java.awt.Paint paint14 = textTitle9.getPaint();
        piePlot1.setLabelShadowPaint(paint14);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        java.awt.Stroke stroke19 = jFreeChart14.getBorderStroke();
        int int20 = jFreeChart14.getBackgroundImageAlignment();
        jFreeChart14.setTitle("RectangleEdge.BOTTOM");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        java.awt.Stroke stroke19 = jFreeChart14.getBorderStroke();
        org.jfree.chart.ui.ProjectInfo projectInfo20 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image21 = projectInfo20.getLogo();
        jFreeChart14.setBackgroundImage(image21);
        java.awt.Paint paint23 = jFreeChart14.getBorderPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(projectInfo20);
        org.junit.Assert.assertNotNull(image21);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        double double2 = rectangleInsets0.getLeft();
        double double4 = rectangleInsets0.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass6 = rectangleInsets5.getClass();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        legendTitle8.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle8.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle15.getPadding();
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle15.getBounds();
        rectangleInsets13.trim(rectangle2D18);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets5.createAdjustedRectangle(rectangle2D18, lengthAdjustmentType20, lengthAdjustmentType21);
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource23);
        double double25 = legendTitle24.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle24.getPadding();
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets5.createInsetRectangle(rectangle2D27, false, true);
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle(legendItemSource31);
        double double33 = legendTitle32.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle32.getPadding();
        legendTitle32.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource37 = null;
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle(legendItemSource37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle38.setHorizontalAlignment(horizontalAlignment39);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = legendTitle38.getLegendItemGraphicAnchor();
        legendTitle32.setLegendItemGraphicAnchor(rectangleAnchor41);
        java.awt.geom.Point2D point2D43 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D27, rectangleAnchor41);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets0.createOutsetRectangle(rectangle2D27, false, true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset47 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset47.validateObject();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent49 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) false, (org.jfree.data.general.Dataset) defaultCategoryDataset47);
        defaultCategoryDataset47.addValue((double) (short) 100, (java.lang.Comparable) "RectangleEdge.BOTTOM", (java.lang.Comparable) 1.0E-5d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(point2D43);
        org.junit.Assert.assertNotNull(rectangle2D46);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (java.lang.Comparable) 4.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Comparable comparable3 = multiplePiePlot1.getAggregatedItemsKey();
        java.awt.Paint paint4 = multiplePiePlot1.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass8 = rectangleInsets7.getClass();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        legendTitle10.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle10.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        double double18 = legendTitle17.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle17.getPadding();
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle17.getBounds();
        rectangleInsets15.trim(rectangle2D20);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets7.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType22, lengthAdjustmentType23);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets7.createInsetRectangle(rectangle2D29, false, true);
        legendTitle1.setBounds(rectangle2D29);
        legendTitle1.setWidth((double) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double38 = rectangleInsets36.calculateRightInset((double) '#');
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = legendTitle1.getLegendItemGraphicLocation();
        java.awt.Color color41 = java.awt.Color.ORANGE;
        org.jfree.chart.block.BlockBorder blockBorder42 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = blockBorder42.getInsets();
        double double45 = rectangleInsets43.extendWidth((double) (-48897));
        legendTitle1.setItemLabelPadding(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + (-48895.0d) + "'", double45 == (-48895.0d));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ChartEntity: tooltip = ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Object obj1 = paintMap0.clone();
        java.awt.Color color2 = java.awt.Color.ORANGE;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        double double6 = rectangleInsets4.extendWidth((double) (-48897));
        boolean boolean7 = paintMap0.equals((java.lang.Object) double6);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        double double16 = legendTitle9.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        java.awt.Paint paint20 = multiplePiePlot19.getNoDataMessagePaint();
        java.awt.Paint paint21 = multiplePiePlot19.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot19);
        jFreeChart22.setBackgroundImageAlignment((int) (short) 0);
        legendTitle9.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = legendTitle9.getLegendItemGraphicLocation();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot27.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        boolean boolean30 = legendTitle9.equals((java.lang.Object) multiplePiePlot27);
        boolean boolean31 = paintMap0.equals((java.lang.Object) boolean30);
        java.lang.Object obj32 = paintMap0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-48895.0d) + "'", double6 == (-48895.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "hi!", image4, "", "hi!", "");
        java.util.List list9 = projectInfo8.getContributors();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass17 = rectangleInsets16.getClass();
        boolean boolean18 = basicProjectInfo15.equals((java.lang.Object) wildcardClass17);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo24 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass26 = rectangleInsets25.getClass();
        boolean boolean27 = basicProjectInfo24.equals((java.lang.Object) wildcardClass26);
        basicProjectInfo15.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
        projectInfo8.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo8);
        java.awt.Image image31 = projectInfo8.getLogo();
        projectInfo8.setLicenceText("PieLabelLinkStyle.STANDARD");
        org.junit.Assert.assertNull(list9);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(image31);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        org.jfree.data.general.DatasetGroup datasetGroup7 = new org.jfree.data.general.DatasetGroup("RectangleEdge.LEFT");
        java.lang.Object obj8 = datasetGroup7.clone();
        boolean boolean9 = rectangleAnchor4.equals((java.lang.Object) datasetGroup7);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent13 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle11);
        org.jfree.chart.block.BlockContainer blockContainer14 = null;
        legendTitle11.setWrapper(blockContainer14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle11.setItemPaint((java.awt.Paint) color16);
        boolean boolean18 = datasetGroup7.equals((java.lang.Object) legendTitle11);
        java.lang.String str19 = datasetGroup7.getID();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleEdge.LEFT" + "'", str19.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        jFreeChart14.setTextAntiAlias(false);
        java.awt.Stroke stroke22 = jFreeChart14.getBorderStroke();
        boolean boolean23 = jFreeChart14.isBorderVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (byte) -1, (java.awt.Paint) color5);
        float float7 = piePlot1.getForegroundAlpha();
        piePlot1.setLabelLinkMargin(1.0E-5d);
        boolean boolean10 = piePlot1.getSectionOutlinesVisible();
        double double11 = piePlot1.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Comparable comparable3 = multiplePiePlot1.getAggregatedItemsKey();
        java.awt.Color color4 = java.awt.Color.black;
        java.awt.Color color5 = color4.darker();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = multiplePiePlot1.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset8 = multiplePiePlot1.getDataset();
        java.awt.Color color9 = java.awt.Color.gray;
        multiplePiePlot1.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot1.getPieChart();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        double double14 = legendTitle13.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle13);
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        titleChangeEvent15.setChart(jFreeChart16);
        java.lang.Object obj18 = titleChangeEvent15.getSource();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset20);
        java.awt.Paint paint22 = multiplePiePlot21.getNoDataMessagePaint();
        java.awt.Paint paint23 = multiplePiePlot21.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot21);
        titleChangeEvent15.setChart(jFreeChart24);
        multiplePiePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart24);
        java.awt.Stroke stroke27 = jFreeChart24.getBorderStroke();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator29 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}");
        java.text.NumberFormat numberFormat30 = standardPieSectionLabelGenerator29.getNumberFormat();
        java.lang.Object obj31 = standardPieSectionLabelGenerator29.clone();
        boolean boolean32 = jFreeChart24.equals((java.lang.Object) standardPieSectionLabelGenerator29);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(jFreeChart11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(numberFormat30);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setExplodePercent((java.lang.Comparable) (-254.0d), (double) ' ');
        piePlot1.setCircular(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot1.getSimpleLabelOffset();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor10 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        piePlot1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor10);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle3);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle3.setItemPaint((java.awt.Paint) color8);
        double double10 = legendTitle3.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset12);
        java.awt.Paint paint14 = multiplePiePlot13.getNoDataMessagePaint();
        java.awt.Paint paint15 = multiplePiePlot13.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot13);
        jFreeChart16.setBackgroundImageAlignment((int) (short) 0);
        legendTitle3.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart16);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart16.setBorderPaint((java.awt.Paint) color20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textTitle22.getTextAlignment();
        java.awt.Paint paint24 = textTitle22.getPaint();
        java.awt.Stroke[] strokeArray25 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean26 = textTitle22.equals((java.lang.Object) strokeArray25);
        jFreeChart16.addSubtitle((org.jfree.chart.title.Title) textTitle22);
        jFreeChart16.setTextAntiAlias(true);
        org.jfree.chart.LegendItemSource legendItemSource30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle(legendItemSource30);
        double double32 = legendTitle31.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent33 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle31);
        org.jfree.chart.JFreeChart jFreeChart34 = null;
        titleChangeEvent33.setChart(jFreeChart34);
        jFreeChart16.titleChanged(titleChangeEvent33);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType37 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean39 = chartChangeEventType37.equals((java.lang.Object) 8.0d);
        java.lang.String str40 = chartChangeEventType37.toString();
        java.awt.Color color45 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color45);
        boolean boolean47 = chartChangeEventType37.equals((java.lang.Object) (short) 100);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockBorder1, jFreeChart16, chartChangeEventType37);
        jFreeChart16.setBackgroundImageAlignment(255);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str40.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getSectionOutlinesVisible();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        piePlot1.setDataset(pieDataset3);
        java.awt.Stroke stroke6 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "VerticalAlignment.BOTTOM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(stroke6);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (byte) -1, (java.awt.Paint) color5);
        float float7 = piePlot1.getForegroundAlpha();
        piePlot1.setLabelLinkMargin(1.0E-5d);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_RED;
        piePlot1.setSectionPaint((java.lang.Comparable) 2.08d, (java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getLibraries();
        java.awt.Image image10 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo14 = new org.jfree.chart.ui.ProjectInfo("", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", image10, "hi!", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        projectInfo14.setCopyright("RectangleEdge.LEFT");
        basicProjectInfo5.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo14);
        java.util.List list18 = projectInfo14.getContributors();
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement21 = blockContainer20.getArrangement();
        flowArrangement19.add((org.jfree.chart.block.Block) blockContainer20, (java.lang.Object) 255);
        boolean boolean24 = blockContainer20.isEmpty();
        java.util.List list25 = blockContainer20.getBlocks();
        projectInfo14.setContributors(list25);
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertNotNull(arrangement21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        textTitle0.setWidth((double) 100L);
        textTitle0.setText("");
        textTitle0.setHeight((double) 0L);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        java.lang.String str13 = rectangleInsets12.toString();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass17 = rectangleInsets16.getClass();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        legendTitle19.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle19.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        rectangleInsets24.trim(rectangle2D29);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets16.createAdjustedRectangle(rectangle2D29, lengthAdjustmentType31, lengthAdjustmentType32);
        legendTitle15.setBounds(rectangle2D33);
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets12.createOutsetRectangle(rectangle2D33, false, true);
        textTitle0.draw(graphics2D8, rectangle2D33);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str13.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D37);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Shape shape3 = defaultDrawingSupplier0.getNextShape();
        java.awt.Paint paint4 = defaultDrawingSupplier0.getNextFillPaint();
        java.lang.Object obj5 = defaultDrawingSupplier0.clone();
        java.lang.Object obj6 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        java.awt.Paint paint2 = textTitle0.getPaint();
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean4 = textTitle0.equals((java.lang.Object) strokeArray3);
        textTitle0.setPadding((double) ' ', (double) 128, (double) (short) 100, 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getOutlineStroke();
        boolean boolean2 = piePlot0.getIgnoreNullValues();
        boolean boolean3 = piePlot0.getLabelLinksVisible();
        piePlot0.setSimpleLabels(false);
        piePlot0.setPieIndex(128);
        java.awt.Shape shape8 = piePlot0.getLegendItemShape();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        multiplePiePlot1.datasetChanged(datasetChangeEvent2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        java.awt.Paint paint2 = textTitle0.getPaint();
        textTitle0.setHeight(2.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getOutlineStroke();
        boolean boolean2 = piePlot0.getIgnoreNullValues();
        boolean boolean3 = piePlot0.getLabelLinksVisible();
        piePlot0.setSimpleLabels(false);
        piePlot0.setPieIndex(128);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot0.getURLGenerator();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieURLGenerator8);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getOutlineStroke();
        boolean boolean2 = piePlot0.getIgnoreNullValues();
        boolean boolean3 = piePlot0.getLabelLinksVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot0.getLegendItems();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot0.setURLGenerator(pieURLGenerator5);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot0.getDataExtractOrder();
        java.awt.Stroke stroke4 = multiplePiePlot0.getOutlineStroke();
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        java.awt.Paint paint2 = textTitle0.getPaint();
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean4 = textTitle0.equals((java.lang.Object) strokeArray3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment6, (double) '#', 0.0d);
        textTitle0.setHorizontalAlignment(horizontalAlignment5);
        java.lang.String str11 = textTitle0.getToolTipText();
        textTitle0.setExpandToFitSpace(false);
        java.awt.Color color14 = java.awt.Color.ORANGE;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color14);
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        double double18 = legendTitle17.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent19 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.block.BlockContainer blockContainer20 = null;
        legendTitle17.setWrapper(blockContainer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle17.setItemPaint((java.awt.Paint) color22);
        double double24 = legendTitle17.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset26);
        java.awt.Paint paint28 = multiplePiePlot27.getNoDataMessagePaint();
        java.awt.Paint paint29 = multiplePiePlot27.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot27);
        jFreeChart30.setBackgroundImageAlignment((int) (short) 0);
        legendTitle17.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart30);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart30.setBorderPaint((java.awt.Paint) color34);
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = textTitle36.getTextAlignment();
        java.awt.Paint paint38 = textTitle36.getPaint();
        java.awt.Stroke[] strokeArray39 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean40 = textTitle36.equals((java.lang.Object) strokeArray39);
        jFreeChart30.addSubtitle((org.jfree.chart.title.Title) textTitle36);
        jFreeChart30.setTextAntiAlias(true);
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        double double46 = legendTitle45.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent47 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle45);
        org.jfree.chart.JFreeChart jFreeChart48 = null;
        titleChangeEvent47.setChart(jFreeChart48);
        jFreeChart30.titleChanged(titleChangeEvent47);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType51 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean53 = chartChangeEventType51.equals((java.lang.Object) 8.0d);
        java.lang.String str54 = chartChangeEventType51.toString();
        java.awt.Color color59 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder60 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color59);
        boolean boolean61 = chartChangeEventType51.equals((java.lang.Object) (short) 100);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent62 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockBorder15, jFreeChart30, chartChangeEventType51);
        textTitle0.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart30);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(strokeArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str54.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        piePlot5.setExplodePercent((java.lang.Comparable) (-254.0d), (double) ' ');
        double double9 = piePlot5.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean14 = piePlot11.getSimpleLabels();
        double double15 = piePlot11.getInteriorGap();
        boolean boolean16 = piePlot11.getLabelLinksVisible();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        double double19 = legendTitle18.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent20 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle18);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass22 = rectangleInsets21.getClass();
        double double23 = rectangleInsets21.getLeft();
        double double25 = rectangleInsets21.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass27 = rectangleInsets26.getClass();
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle29.getPadding();
        legendTitle29.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle29.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        double double37 = legendTitle36.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle36.getPadding();
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle36.getBounds();
        rectangleInsets34.trim(rectangle2D39);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets26.createAdjustedRectangle(rectangle2D39, lengthAdjustmentType41, lengthAdjustmentType42);
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        double double46 = legendTitle45.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = legendTitle45.getPadding();
        java.awt.geom.Rectangle2D rectangle2D48 = legendTitle45.getBounds();
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets26.createInsetRectangle(rectangle2D48, false, true);
        org.jfree.chart.LegendItemSource legendItemSource52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle(legendItemSource52);
        double double54 = legendTitle53.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = legendTitle53.getPadding();
        legendTitle53.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource58 = null;
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle(legendItemSource58);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment60 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle59.setHorizontalAlignment(horizontalAlignment60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = legendTitle59.getLegendItemGraphicAnchor();
        legendTitle53.setLegendItemGraphicAnchor(rectangleAnchor62);
        java.awt.geom.Point2D point2D64 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D48, rectangleAnchor62);
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets21.createOutsetRectangle(rectangle2D48, false, true);
        legendTitle18.setPadding(rectangleInsets21);
        java.awt.Color color69 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.image.ColorModel colorModel70 = null;
        java.awt.Rectangle rectangle71 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass73 = rectangleInsets72.getClass();
        org.jfree.chart.LegendItemSource legendItemSource74 = null;
        org.jfree.chart.title.LegendTitle legendTitle75 = new org.jfree.chart.title.LegendTitle(legendItemSource74);
        double double76 = legendTitle75.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = legendTitle75.getPadding();
        legendTitle75.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = legendTitle75.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource81 = null;
        org.jfree.chart.title.LegendTitle legendTitle82 = new org.jfree.chart.title.LegendTitle(legendItemSource81);
        double double83 = legendTitle82.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets84 = legendTitle82.getPadding();
        java.awt.geom.Rectangle2D rectangle2D85 = legendTitle82.getBounds();
        rectangleInsets80.trim(rectangle2D85);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType87 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType88 = null;
        java.awt.geom.Rectangle2D rectangle2D89 = rectangleInsets72.createAdjustedRectangle(rectangle2D85, lengthAdjustmentType87, lengthAdjustmentType88);
        java.awt.geom.AffineTransform affineTransform90 = null;
        java.awt.RenderingHints renderingHints91 = null;
        java.awt.PaintContext paintContext92 = color69.createContext(colorModel70, rectangle71, rectangle2D89, affineTransform90, renderingHints91);
        java.awt.geom.Rectangle2D rectangle2D93 = rectangleInsets21.createOutsetRectangle(rectangle2D89);
        piePlot11.setLegendItemShape((java.awt.Shape) rectangle2D93);
        double double95 = piePlot11.getLabelGap();
        java.awt.Stroke stroke96 = piePlot11.getLabelLinkStroke();
        piePlot5.setLabelOutlineStroke(stroke96);
        strokeMap0.put((java.lang.Comparable) 100L, stroke96);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(horizontalAlignment60);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(point2D64);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets77);
        org.junit.Assert.assertNotNull(rectangleInsets80);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets84);
        org.junit.Assert.assertNotNull(rectangle2D85);
        org.junit.Assert.assertNotNull(rectangle2D89);
        org.junit.Assert.assertNotNull(paintContext92);
        org.junit.Assert.assertNotNull(rectangle2D93);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.025d + "'", double95 == 0.025d);
        org.junit.Assert.assertNotNull(stroke96);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass12 = rectangleInsets11.getClass();
        double double13 = rectangleInsets11.getLeft();
        double double15 = rectangleInsets11.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass17 = rectangleInsets16.getClass();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        legendTitle19.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle19.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        rectangleInsets24.trim(rectangle2D29);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets16.createAdjustedRectangle(rectangle2D29, lengthAdjustmentType31, lengthAdjustmentType32);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle35.getPadding();
        java.awt.geom.Rectangle2D rectangle2D38 = legendTitle35.getBounds();
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets16.createInsetRectangle(rectangle2D38, false, true);
        org.jfree.chart.LegendItemSource legendItemSource42 = null;
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle(legendItemSource42);
        double double44 = legendTitle43.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = legendTitle43.getPadding();
        legendTitle43.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource48 = null;
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle(legendItemSource48);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment50 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle49.setHorizontalAlignment(horizontalAlignment50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = legendTitle49.getLegendItemGraphicAnchor();
        legendTitle43.setLegendItemGraphicAnchor(rectangleAnchor52);
        java.awt.geom.Point2D point2D54 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D38, rectangleAnchor52);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets11.createOutsetRectangle(rectangle2D38, false, true);
        legendTitle8.setPadding(rectangleInsets11);
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.image.ColorModel colorModel60 = null;
        java.awt.Rectangle rectangle61 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass63 = rectangleInsets62.getClass();
        org.jfree.chart.LegendItemSource legendItemSource64 = null;
        org.jfree.chart.title.LegendTitle legendTitle65 = new org.jfree.chart.title.LegendTitle(legendItemSource64);
        double double66 = legendTitle65.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = legendTitle65.getPadding();
        legendTitle65.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = legendTitle65.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource71 = null;
        org.jfree.chart.title.LegendTitle legendTitle72 = new org.jfree.chart.title.LegendTitle(legendItemSource71);
        double double73 = legendTitle72.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = legendTitle72.getPadding();
        java.awt.geom.Rectangle2D rectangle2D75 = legendTitle72.getBounds();
        rectangleInsets70.trim(rectangle2D75);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType77 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType78 = null;
        java.awt.geom.Rectangle2D rectangle2D79 = rectangleInsets62.createAdjustedRectangle(rectangle2D75, lengthAdjustmentType77, lengthAdjustmentType78);
        java.awt.geom.AffineTransform affineTransform80 = null;
        java.awt.RenderingHints renderingHints81 = null;
        java.awt.PaintContext paintContext82 = color59.createContext(colorModel60, rectangle61, rectangle2D79, affineTransform80, renderingHints81);
        java.awt.geom.Rectangle2D rectangle2D83 = rectangleInsets11.createOutsetRectangle(rectangle2D79);
        piePlot1.setLegendItemShape((java.awt.Shape) rectangle2D83);
        double double85 = piePlot1.getLabelGap();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator86 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator86);
        piePlot1.setSimpleLabels(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(horizontalAlignment50);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(point2D54);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(paintContext82);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.025d + "'", double85 == 0.025d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset13, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        java.lang.String str20 = pieSectionEntity19.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass22 = rectangleInsets21.getClass();
        double double23 = rectangleInsets21.getLeft();
        double double25 = rectangleInsets21.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass27 = rectangleInsets26.getClass();
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle29.getPadding();
        legendTitle29.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle29.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        double double37 = legendTitle36.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle36.getPadding();
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle36.getBounds();
        rectangleInsets34.trim(rectangle2D39);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets26.createAdjustedRectangle(rectangle2D39, lengthAdjustmentType41, lengthAdjustmentType42);
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        double double46 = legendTitle45.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = legendTitle45.getPadding();
        java.awt.geom.Rectangle2D rectangle2D48 = legendTitle45.getBounds();
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets26.createInsetRectangle(rectangle2D48, false, true);
        org.jfree.chart.LegendItemSource legendItemSource52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle(legendItemSource52);
        double double54 = legendTitle53.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = legendTitle53.getPadding();
        legendTitle53.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource58 = null;
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle(legendItemSource58);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment60 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle59.setHorizontalAlignment(horizontalAlignment60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = legendTitle59.getLegendItemGraphicAnchor();
        legendTitle53.setLegendItemGraphicAnchor(rectangleAnchor62);
        java.awt.geom.Point2D point2D64 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D48, rectangleAnchor62);
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets21.createOutsetRectangle(rectangle2D48, false, true);
        pieSectionEntity19.setArea((java.awt.Shape) rectangle2D67);
        int int69 = pieSectionEntity19.getSectionIndex();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PieSection: 255, -48897(10)" + "'", str20.equals("PieSection: 255, -48897(10)"));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(horizontalAlignment60);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(point2D64);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-48897) + "'", int69 == (-48897));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.awt.Color color0 = java.awt.Color.green;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean3 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge2);
        java.lang.Class<?> wildcardClass4 = rectangleEdge2.getClass();
        boolean boolean5 = blockBorder1.equals((java.lang.Object) rectangleEdge2);
        java.awt.Paint paint6 = blockBorder1.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle20.getTextAlignment();
        java.awt.Paint paint22 = textTitle20.getPaint();
        java.awt.Stroke[] strokeArray23 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean24 = textTitle20.equals((java.lang.Object) strokeArray23);
        jFreeChart14.addSubtitle((org.jfree.chart.title.Title) textTitle20);
        jFreeChart14.setTextAntiAlias(true);
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent31 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle29);
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        titleChangeEvent31.setChart(jFreeChart32);
        jFreeChart14.titleChanged(titleChangeEvent31);
        org.jfree.chart.JFreeChart jFreeChart35 = titleChangeEvent31.getChart();
        boolean boolean36 = jFreeChart35.isNotify();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass5 = rectangleInsets4.getClass();
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        double double8 = legendTitle7.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle7.getPadding();
        legendTitle7.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle7.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        double double15 = legendTitle14.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle14.getPadding();
        java.awt.geom.Rectangle2D rectangle2D17 = legendTitle14.getBounds();
        rectangleInsets12.trim(rectangle2D17);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets4.createAdjustedRectangle(rectangle2D17, lengthAdjustmentType19, lengthAdjustmentType20);
        java.awt.Color color22 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, (java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass25 = rectangleInsets24.getClass();
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        double double28 = legendTitle27.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle27.getPadding();
        legendTitle27.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendTitle27.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        double double35 = legendTitle34.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle34.getPadding();
        java.awt.geom.Rectangle2D rectangle2D37 = legendTitle34.getBounds();
        rectangleInsets32.trim(rectangle2D37);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets24.createAdjustedRectangle(rectangle2D37, lengthAdjustmentType39, lengthAdjustmentType40);
        org.jfree.chart.LegendItemSource legendItemSource42 = null;
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle(legendItemSource42);
        double double44 = legendTitle43.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = legendTitle43.getPadding();
        java.awt.geom.Rectangle2D rectangle2D46 = legendTitle43.getBounds();
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets24.createInsetRectangle(rectangle2D46, false, true);
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets4.createInsetRectangle(rectangle2D46, false, true);
        try {
            blockBorder1.draw(graphics2D3, rectangle2D46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D52);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        double double1 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, (double) '#', 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass12 = rectangleInsets11.getClass();
        double double13 = rectangleInsets11.getLeft();
        boolean boolean14 = columnArrangement10.equals((java.lang.Object) double13);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement10);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockContainer15.getPadding();
        org.jfree.data.general.Dataset dataset17 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets16, dataset17);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        double double21 = legendTitle20.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame22 = legendTitle20.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray24 = new org.jfree.chart.LegendItemSource[] { legendItemSource23 };
        legendTitle20.setSources(legendItemSourceArray24);
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        double double28 = legendTitle27.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle27.getPadding();
        java.awt.geom.Rectangle2D rectangle2D30 = legendTitle27.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle27.setLegendItemGraphicAnchor(rectangleAnchor31);
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        double double35 = legendTitle34.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle34.getPadding();
        java.lang.String str37 = rectangleInsets36.toString();
        legendTitle27.setMargin(rectangleInsets36);
        legendTitle20.setLegendItemGraphicPadding(rectangleInsets36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle20.setLegendItemGraphicLocation(rectangleAnchor40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass43 = rectangleInsets42.getClass();
        double double44 = rectangleInsets42.getLeft();
        double double46 = rectangleInsets42.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass48 = rectangleInsets47.getClass();
        org.jfree.chart.LegendItemSource legendItemSource49 = null;
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle(legendItemSource49);
        double double51 = legendTitle50.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = legendTitle50.getPadding();
        legendTitle50.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = legendTitle50.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource56 = null;
        org.jfree.chart.title.LegendTitle legendTitle57 = new org.jfree.chart.title.LegendTitle(legendItemSource56);
        double double58 = legendTitle57.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = legendTitle57.getPadding();
        java.awt.geom.Rectangle2D rectangle2D60 = legendTitle57.getBounds();
        rectangleInsets55.trim(rectangle2D60);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType62 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets47.createAdjustedRectangle(rectangle2D60, lengthAdjustmentType62, lengthAdjustmentType63);
        org.jfree.chart.LegendItemSource legendItemSource65 = null;
        org.jfree.chart.title.LegendTitle legendTitle66 = new org.jfree.chart.title.LegendTitle(legendItemSource65);
        double double67 = legendTitle66.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = legendTitle66.getPadding();
        java.awt.geom.Rectangle2D rectangle2D69 = legendTitle66.getBounds();
        java.awt.geom.Rectangle2D rectangle2D72 = rectangleInsets47.createInsetRectangle(rectangle2D69, false, true);
        org.jfree.chart.LegendItemSource legendItemSource73 = null;
        org.jfree.chart.title.LegendTitle legendTitle74 = new org.jfree.chart.title.LegendTitle(legendItemSource73);
        double double75 = legendTitle74.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets76 = legendTitle74.getPadding();
        legendTitle74.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource79 = null;
        org.jfree.chart.title.LegendTitle legendTitle80 = new org.jfree.chart.title.LegendTitle(legendItemSource79);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment81 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle80.setHorizontalAlignment(horizontalAlignment81);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor83 = legendTitle80.getLegendItemGraphicAnchor();
        legendTitle74.setLegendItemGraphicAnchor(rectangleAnchor83);
        java.awt.geom.Point2D point2D85 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D69, rectangleAnchor83);
        java.awt.geom.Rectangle2D rectangle2D88 = rectangleInsets42.createOutsetRectangle(rectangle2D69, false, true);
        boolean boolean89 = rectangleAnchor40.equals((java.lang.Object) rectangle2D88);
        java.awt.geom.Rectangle2D rectangle2D92 = rectangleInsets16.createInsetRectangle(rectangle2D88, true, true);
        try {
            legendTitle1.draw(graphics2D5, rectangle2D92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame22);
        org.junit.Assert.assertNotNull(legendItemSourceArray24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str37.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets76);
        org.junit.Assert.assertNotNull(horizontalAlignment81);
        org.junit.Assert.assertNotNull(rectangleAnchor83);
        org.junit.Assert.assertNotNull(point2D85);
        org.junit.Assert.assertNotNull(rectangle2D88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(rectangle2D92);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        double double2 = rectangleInsets0.getTop();
        double double3 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.RenderingHints renderingHints6 = jFreeChart5.getRenderingHints();
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image8 = projectInfo7.getLogo();
        jFreeChart5.setBackgroundImage(image8);
        jFreeChart5.setTitle("RectangleEdge.BOTTOM");
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(renderingHints6);
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertNotNull(image8);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str1.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        double double7 = piePlot1.getInteriorGap();
        java.awt.Paint paint8 = piePlot1.getLabelShadowPaint();
        java.awt.Stroke stroke9 = piePlot1.getLabelOutlineStroke();
        boolean boolean10 = piePlot1.getIgnoreZeroValues();
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color12);
        piePlot1.setSectionPaint((java.lang.Comparable) "JFreeChart", (java.awt.Paint) color12);
        piePlot1.setIgnoreZeroValues(false);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle17.getTextAlignment();
        textTitle17.setMargin(1.0d, 0.0d, (double) 128, (double) 1.0f);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        legendTitle26.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle26.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        double double34 = legendTitle33.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = legendTitle33.getPadding();
        java.awt.geom.Rectangle2D rectangle2D36 = legendTitle33.getBounds();
        rectangleInsets31.trim(rectangle2D36);
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity44 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D36, pieDataset38, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        org.jfree.chart.LegendItemSource legendItemSource45 = null;
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle(legendItemSource45);
        double double47 = legendTitle46.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent48 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle46);
        org.jfree.chart.block.BlockContainer blockContainer49 = null;
        legendTitle46.setWrapper(blockContainer49);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle46.setItemPaint((java.awt.Paint) color51);
        double double53 = legendTitle46.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot56 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset55);
        java.awt.Paint paint57 = multiplePiePlot56.getNoDataMessagePaint();
        java.awt.Paint paint58 = multiplePiePlot56.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart59 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot56);
        jFreeChart59.setBackgroundImageAlignment((int) (short) 0);
        legendTitle46.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart59);
        java.awt.Color color63 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart59.setBorderPaint((java.awt.Paint) color63);
        java.lang.Object obj65 = textTitle17.draw(graphics2D24, rectangle2D36, (java.lang.Object) jFreeChart59);
        piePlot1.setLegendItemShape((java.awt.Shape) rectangle2D36);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNull(obj65);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        org.jfree.data.general.DatasetGroup datasetGroup2 = defaultCategoryDataset0.getGroup();
        int int4 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) (byte) 0);
        try {
            java.lang.Comparable comparable6 = defaultCategoryDataset0.getColumnKey((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        textTitle0.setWidth((double) 100L);
        textTitle0.setText("");
        java.lang.String str6 = textTitle0.getText();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass11 = rectangleInsets10.getClass();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        double double14 = legendTitle13.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle13.getPadding();
        legendTitle13.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle13.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        double double21 = legendTitle20.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle20.getPadding();
        java.awt.geom.Rectangle2D rectangle2D23 = legendTitle20.getBounds();
        rectangleInsets18.trim(rectangle2D23);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets10.createAdjustedRectangle(rectangle2D23, lengthAdjustmentType25, lengthAdjustmentType26);
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle29.getPadding();
        java.awt.geom.Rectangle2D rectangle2D32 = legendTitle29.getBounds();
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets10.createInsetRectangle(rectangle2D32, false, true);
        rectangleInsets8.trim(rectangle2D32);
        textTitle0.draw(graphics2D7, rectangle2D32);
        java.lang.Object obj38 = textTitle0.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = textTitle0.getTextAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color4);
        java.awt.Paint paint6 = blockBorder5.getPaint();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        boolean boolean8 = blockBorder5.equals((java.lang.Object) shape7);
        java.awt.Paint paint9 = blockBorder5.getPaint();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getPadding();
        java.awt.geom.Rectangle2D rectangle2D14 = legendTitle11.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = legendTitle11.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        java.lang.String str22 = rectangleInsets21.toString();
        boolean boolean23 = legendTitle11.equals((java.lang.Object) str22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace25 = color24.getColorSpace();
        legendTitle11.setItemPaint((java.awt.Paint) color24);
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle28.setHorizontalAlignment(horizontalAlignment29);
        legendTitle11.setHorizontalAlignment(horizontalAlignment29);
        boolean boolean32 = blockBorder5.equals((java.lang.Object) legendTitle11);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str22.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer1, (java.lang.Object) 255);
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        double double7 = legendTitle6.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle6.getPadding();
        java.awt.geom.Rectangle2D rectangle2D9 = legendTitle6.getBounds();
        double double10 = legendTitle6.getContentYOffset();
        org.jfree.chart.ui.Contributor contributor13 = new org.jfree.chart.ui.Contributor("", "");
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle6, (java.lang.Object) contributor13);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0);
        flowArrangement0.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement21 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment17, verticalAlignment18, (double) '#', 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass23 = rectangleInsets22.getClass();
        double double24 = rectangleInsets22.getLeft();
        boolean boolean25 = columnArrangement21.equals((java.lang.Object) double24);
        org.jfree.chart.block.BlockContainer blockContainer26 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement21);
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        double double29 = legendTitle28.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame30 = legendTitle28.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray32 = new org.jfree.chart.LegendItemSource[] { legendItemSource31 };
        legendTitle28.setSources(legendItemSourceArray32);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle35.getPadding();
        java.awt.geom.Rectangle2D rectangle2D38 = legendTitle35.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle35.setLegendItemGraphicAnchor(rectangleAnchor39);
        org.jfree.chart.LegendItemSource legendItemSource41 = null;
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle(legendItemSource41);
        double double43 = legendTitle42.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = legendTitle42.getPadding();
        java.lang.String str45 = rectangleInsets44.toString();
        legendTitle35.setMargin(rectangleInsets44);
        legendTitle28.setLegendItemGraphicPadding(rectangleInsets44);
        java.lang.Object obj48 = null;
        blockContainer26.add((org.jfree.chart.block.Block) legendTitle28, obj48);
        org.jfree.chart.ui.Contributor contributor52 = new org.jfree.chart.ui.Contributor("", "hi!");
        java.lang.Class<?> wildcardClass53 = contributor52.getClass();
        boolean boolean54 = blockContainer26.equals((java.lang.Object) wildcardClass53);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = null;
        try {
            org.jfree.chart.util.Size2D size2D57 = flowArrangement0.arrange(blockContainer26, graphics2D55, rectangleConstraint56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame30);
        org.junit.Assert.assertNotNull(legendItemSourceArray32);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str45.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.plot.Plot plot4 = piePlot1.getParent();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot4.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Font font7 = multiplePiePlot4.getNoDataMessageFont();
        multiplePiePlot0.setNoDataMessageFont(font7);
        java.awt.Paint paint9 = multiplePiePlot0.getBackgroundPaint();
        java.awt.Paint paint10 = multiplePiePlot0.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        double double7 = piePlot1.getInteriorGap();
        java.awt.Paint paint8 = piePlot1.getLabelShadowPaint();
        java.awt.Stroke stroke9 = piePlot1.getLabelOutlineStroke();
        boolean boolean10 = piePlot1.getIgnoreZeroValues();
        java.awt.Shape shape11 = piePlot1.getLegendItemShape();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        double double14 = legendTitle13.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle13.getPadding();
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle13.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        double double22 = legendTitle21.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent23 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle21);
        org.jfree.chart.block.BlockContainer blockContainer24 = null;
        legendTitle21.setWrapper(blockContainer24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle21.setItemPaint((java.awt.Paint) color26);
        boolean boolean28 = chartEntity19.equals((java.lang.Object) legendTitle21);
        java.awt.Color color29 = java.awt.Color.pink;
        legendTitle21.setItemPaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendTitle21.setBackgroundPaint((java.awt.Paint) color31);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color31);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color31);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        piePlot1.setExplodePercent((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (double) (short) 1);
        piePlot1.setMinimumArcAngleToDraw((double) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        java.awt.Paint paint13 = multiplePiePlot12.getNoDataMessagePaint();
        java.awt.Paint paint14 = multiplePiePlot12.getNoDataMessagePaint();
        java.awt.Stroke stroke15 = multiplePiePlot12.getOutlineStroke();
        piePlot1.setLabelLinkStroke(stroke15);
        java.awt.Color color17 = java.awt.Color.black;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color17);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = piePlot1.getLegendLabelURLGenerator();
        java.awt.Color color20 = java.awt.Color.black;
        java.awt.Color color21 = color20.darker();
        java.lang.String str22 = color21.toString();
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color21);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(pieURLGenerator19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str22.equals("java.awt.Color[r=0,g=0,b=0]"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        try {
            java.lang.Number number4 = defaultCategoryDataset0.getValue((java.lang.Comparable) 5.120000000000001d, (java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.08d, (double) 8);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.lang.Object obj6 = blockContainer5.clone();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle8.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D9, "RectangleEdge.BOTTOM", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass14 = rectangleInsets13.getClass();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        double double17 = legendTitle16.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getPadding();
        legendTitle16.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle16.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        double double24 = legendTitle23.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle23.getPadding();
        java.awt.geom.Rectangle2D rectangle2D26 = legendTitle23.getBounds();
        rectangleInsets21.trim(rectangle2D26);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType28 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets13.createAdjustedRectangle(rectangle2D26, lengthAdjustmentType28, lengthAdjustmentType29);
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle(legendItemSource31);
        double double33 = legendTitle32.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle32.getPadding();
        java.awt.geom.Rectangle2D rectangle2D35 = legendTitle32.getBounds();
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets13.createInsetRectangle(rectangle2D35, false, true);
        org.jfree.chart.LegendItemSource legendItemSource39 = null;
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle(legendItemSource39);
        double double41 = legendTitle40.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = legendTitle40.getPadding();
        legendTitle40.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource45 = null;
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle(legendItemSource45);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle46.setHorizontalAlignment(horizontalAlignment47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = legendTitle46.getLegendItemGraphicAnchor();
        legendTitle40.setLegendItemGraphicAnchor(rectangleAnchor49);
        java.awt.geom.Point2D point2D51 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D35, rectangleAnchor49);
        org.jfree.chart.entity.ChartEntity chartEntity52 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D35);
        try {
            java.lang.Object obj53 = blockContainer5.draw(graphics2D7, rectangle2D9, (java.lang.Object) chartEntity52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(horizontalAlignment47);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(point2D51);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int3 = color2.getGreen();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge4);
        java.lang.String str6 = rectangleEdge5.toString();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle8.setLegendItemGraphicAnchor(rectangleAnchor12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle8.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        double double17 = legendTitle16.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getPadding();
        java.lang.String str19 = rectangleInsets18.toString();
        boolean boolean20 = legendTitle8.equals((java.lang.Object) str19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = legendTitle8.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("VerticalAlignment.CENTER", font1, (java.awt.Paint) color2, rectangleEdge5, horizontalAlignment21, verticalAlignment22, rectangleInsets23);
        org.jfree.chart.util.ObjectList objectList26 = new org.jfree.chart.util.ObjectList((int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass28 = rectangleInsets27.getClass();
        org.jfree.chart.LegendItemSource legendItemSource29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource29);
        double double31 = legendTitle30.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendTitle30.getPadding();
        legendTitle30.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = legendTitle30.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle(legendItemSource36);
        double double38 = legendTitle37.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = legendTitle37.getPadding();
        java.awt.geom.Rectangle2D rectangle2D40 = legendTitle37.getBounds();
        rectangleInsets35.trim(rectangle2D40);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets27.createAdjustedRectangle(rectangle2D40, lengthAdjustmentType42, lengthAdjustmentType43);
        java.awt.Color color45 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder(rectangleInsets27, (java.awt.Paint) color45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass48 = rectangleInsets47.getClass();
        org.jfree.chart.LegendItemSource legendItemSource49 = null;
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle(legendItemSource49);
        double double51 = legendTitle50.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = legendTitle50.getPadding();
        legendTitle50.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = legendTitle50.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource56 = null;
        org.jfree.chart.title.LegendTitle legendTitle57 = new org.jfree.chart.title.LegendTitle(legendItemSource56);
        double double58 = legendTitle57.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = legendTitle57.getPadding();
        java.awt.geom.Rectangle2D rectangle2D60 = legendTitle57.getBounds();
        rectangleInsets55.trim(rectangle2D60);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType62 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets47.createAdjustedRectangle(rectangle2D60, lengthAdjustmentType62, lengthAdjustmentType63);
        org.jfree.chart.LegendItemSource legendItemSource65 = null;
        org.jfree.chart.title.LegendTitle legendTitle66 = new org.jfree.chart.title.LegendTitle(legendItemSource65);
        double double67 = legendTitle66.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = legendTitle66.getPadding();
        java.awt.geom.Rectangle2D rectangle2D69 = legendTitle66.getBounds();
        java.awt.geom.Rectangle2D rectangle2D72 = rectangleInsets47.createInsetRectangle(rectangle2D69, false, true);
        java.awt.geom.Rectangle2D rectangle2D75 = rectangleInsets27.createInsetRectangle(rectangle2D69, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity78 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D69, "rect", "ChartChangeEventType.NEW_DATASET");
        boolean boolean79 = objectList26.equals((java.lang.Object) rectangle2D69);
        org.jfree.chart.entity.ChartEntity chartEntity81 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D69, "JFreeChart");
        java.awt.geom.Rectangle2D rectangle2D82 = rectangleInsets23.createInsetRectangle(rectangle2D69);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 128 + "'", int3 == 128);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleEdge.RIGHT" + "'", str6.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str19.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(rectangle2D82);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        textTitle0.setMargin(1.0d, 0.0d, (double) 128, (double) 1.0f);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle9.getPadding();
        legendTitle9.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendTitle9.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        double double17 = legendTitle16.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getPadding();
        java.awt.geom.Rectangle2D rectangle2D19 = legendTitle16.getBounds();
        rectangleInsets14.trim(rectangle2D19);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity27 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D19, pieDataset21, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent31 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle29);
        org.jfree.chart.block.BlockContainer blockContainer32 = null;
        legendTitle29.setWrapper(blockContainer32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle29.setItemPaint((java.awt.Paint) color34);
        double double36 = legendTitle29.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot39 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset38);
        java.awt.Paint paint40 = multiplePiePlot39.getNoDataMessagePaint();
        java.awt.Paint paint41 = multiplePiePlot39.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart42 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot39);
        jFreeChart42.setBackgroundImageAlignment((int) (short) 0);
        legendTitle29.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart42);
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart42.setBorderPaint((java.awt.Paint) color46);
        java.lang.Object obj48 = textTitle0.draw(graphics2D7, rectangle2D19, (java.lang.Object) jFreeChart42);
        try {
            org.jfree.chart.title.Title title50 = jFreeChart42.getSubtitle(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNull(obj48);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = blockContainer0.getArrangement();
        boolean boolean2 = blockContainer0.isEmpty();
        org.junit.Assert.assertNotNull(arrangement1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getNumberFormat();
        java.text.NumberFormat numberFormat3 = standardPieSectionLabelGenerator1.getNumberFormat();
        java.text.AttributedString attributedString5 = null;
        standardPieSectionLabelGenerator1.setAttributedLabel(15, attributedString5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment7, verticalAlignment8, 0.08d, (double) 8);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement11);
        boolean boolean13 = standardPieSectionLabelGenerator1.equals((java.lang.Object) blockContainer12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean18 = piePlot15.getSimpleLabels();
        double double19 = piePlot15.getInteriorGap();
        piePlot15.setExplodePercent((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (double) (short) 1);
        piePlot15.setMinimumArcAngleToDraw((double) (byte) 0);
        java.awt.Paint paint25 = null;
        piePlot15.setLabelOutlinePaint(paint25);
        boolean boolean27 = standardPieSectionLabelGenerator1.equals((java.lang.Object) piePlot15);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberFormat3);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.08d + "'", double19 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getSectionOutlinesVisible();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        piePlot1.setDataset(pieDataset3);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLabelGenerator();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator6);
        org.jfree.chart.util.Rotation rotation8 = piePlot1.getDirection();
        java.awt.Paint paint9 = piePlot1.getShadowPaint();
        boolean boolean10 = piePlot1.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(rotation8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        java.lang.String str17 = chartEntity7.getShapeType();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        legendTitle19.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle19.getPadding();
        boolean boolean25 = chartEntity7.equals((java.lang.Object) rectangleInsets24);
        java.awt.Color color26 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color26);
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder(rectangleInsets24, (java.awt.Paint) color26);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "rect" + "'", str17.equals("rect"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        boolean boolean3 = blockBorder1.equals((java.lang.Object) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder1.getInsets();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        java.awt.Color color17 = java.awt.Color.pink;
        legendTitle9.setItemPaint((java.awt.Paint) color17);
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement21 = blockContainer20.getArrangement();
        flowArrangement19.add((org.jfree.chart.block.Block) blockContainer20, (java.lang.Object) 255);
        boolean boolean24 = blockContainer20.isEmpty();
        legendTitle9.setWrapper(blockContainer20);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = blockContainer20.getMargin();
        org.jfree.chart.block.LineBorder lineBorder27 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent31 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle29);
        java.lang.String str32 = titleChangeEvent31.toString();
        java.lang.Object obj33 = titleChangeEvent31.getSource();
        boolean boolean34 = lineBorder27.equals((java.lang.Object) titleChangeEvent31);
        blockContainer20.setFrame((org.jfree.chart.block.BlockFrame) lineBorder27);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(arrangement21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment4, verticalAlignment5, 0.08d, (double) 8);
        org.jfree.chart.block.Block block9 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass11 = rectangleInsets10.getClass();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        double double14 = legendTitle13.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle13.getPadding();
        legendTitle13.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle13.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        double double21 = legendTitle20.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle20.getPadding();
        java.awt.geom.Rectangle2D rectangle2D23 = legendTitle20.getBounds();
        rectangleInsets18.trim(rectangle2D23);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets10.createAdjustedRectangle(rectangle2D23, lengthAdjustmentType25, lengthAdjustmentType26);
        double double29 = rectangleInsets10.calculateLeftInset((double) (byte) 10);
        double double31 = rectangleInsets10.calculateTopInset((double) 8);
        columnArrangement8.add(block9, (java.lang.Object) rectangleInsets10);
        org.jfree.chart.block.FlowArrangement flowArrangement33 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer34 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement35 = blockContainer34.getArrangement();
        flowArrangement33.add((org.jfree.chart.block.Block) blockContainer34, (java.lang.Object) 255);
        java.lang.Object obj38 = null;
        boolean boolean39 = flowArrangement33.equals(obj38);
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot1, (org.jfree.chart.block.Arrangement) columnArrangement8, (org.jfree.chart.block.Arrangement) flowArrangement33);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(arrangement35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getOutlineStroke();
        boolean boolean2 = piePlot0.getIgnoreNullValues();
        boolean boolean3 = piePlot0.getLabelLinksVisible();
        piePlot0.setSimpleLabels(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot0.removeChangeListener(plotChangeListener6);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setExplodePercent((java.lang.Comparable) (-254.0d), (double) ' ');
        piePlot1.setCircular(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot1.getSimpleLabelOffset();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot1.getToolTipGenerator();
        piePlot1.setShadowYOffset((double) (short) -1);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        boolean boolean7 = piePlot1.isOutlineVisible();
        double double8 = piePlot1.getMaximumExplodePercent();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setExplodePercent((java.lang.Comparable) (-254.0d), (double) ' ');
        piePlot1.setCircular(true, false);
        double double8 = piePlot1.getMaximumLabelWidth();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass12 = rectangleInsets11.getClass();
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        double double15 = legendTitle14.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle14.getPadding();
        legendTitle14.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle14.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        double double22 = legendTitle21.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = legendTitle21.getPadding();
        java.awt.geom.Rectangle2D rectangle2D24 = legendTitle21.getBounds();
        rectangleInsets19.trim(rectangle2D24);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets11.createAdjustedRectangle(rectangle2D24, lengthAdjustmentType26, lengthAdjustmentType27);
        java.awt.Color color29 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder30 = new org.jfree.chart.block.BlockBorder(rectangleInsets11, (java.awt.Paint) color29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass32 = rectangleInsets31.getClass();
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        double double35 = legendTitle34.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle34.getPadding();
        legendTitle34.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = legendTitle34.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        double double42 = legendTitle41.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = legendTitle41.getPadding();
        java.awt.geom.Rectangle2D rectangle2D44 = legendTitle41.getBounds();
        rectangleInsets39.trim(rectangle2D44);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType46 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets31.createAdjustedRectangle(rectangle2D44, lengthAdjustmentType46, lengthAdjustmentType47);
        org.jfree.chart.LegendItemSource legendItemSource49 = null;
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle(legendItemSource49);
        double double51 = legendTitle50.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = legendTitle50.getPadding();
        java.awt.geom.Rectangle2D rectangle2D53 = legendTitle50.getBounds();
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets31.createInsetRectangle(rectangle2D53, false, true);
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets11.createInsetRectangle(rectangle2D53, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity62 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D53, "rect", "ChartChangeEventType.NEW_DATASET");
        org.jfree.chart.LegendItemSource legendItemSource63 = null;
        org.jfree.chart.title.LegendTitle legendTitle64 = new org.jfree.chart.title.LegendTitle(legendItemSource63);
        double double65 = legendTitle64.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = legendTitle64.getPadding();
        java.awt.geom.Rectangle2D rectangle2D67 = legendTitle64.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle64.setLegendItemGraphicAnchor(rectangleAnchor68);
        java.awt.geom.Point2D point2D70 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D53, rectangleAnchor68);
        org.jfree.chart.plot.PlotState plotState71 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = null;
        try {
            piePlot1.draw(graphics2D9, rectangle2D10, point2D70, plotState71, plotRenderingInfo72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.14d + "'", double8 == 0.14d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangleAnchor68);
        org.junit.Assert.assertNotNull(point2D70);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        try {
            java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset1, (java.lang.Comparable) 0.08d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("ChartEntity: tooltip = ", "rect", "ChartChangeEventType.NEW_DATASET", "ChartChangeEventType.NEW_DATASET", "RectangleEdge.RIGHT");
        java.lang.String str6 = basicProjectInfo5.getVersion();
        basicProjectInfo5.setLicenceName("VerticalAlignment.CENTER");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "rect" + "'", str6.equals("rect"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        jFreeChart5.setBackgroundImageAlignment((int) (short) 0);
        java.awt.Stroke stroke8 = jFreeChart5.getBorderStroke();
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart5.getTitle();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = null;
        try {
            org.jfree.chart.util.Size2D size2D12 = textTitle9.arrange(graphics2D10, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(textTitle9);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("ChartChangeEventType.NEW_DATASET", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.plot.Plot plot3 = multiplePiePlot1.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        multiplePiePlot1.setDataset(categoryDataset4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset6 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset6.validateObject();
        multiplePiePlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset6);
        try {
            defaultCategoryDataset6.removeColumn((java.lang.Comparable) "HorizontalAlignment.RIGHT");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: HorizontalAlignment.RIGHT");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass3 = rectangleInsets2.getClass();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        double double6 = legendTitle5.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle5.getPadding();
        legendTitle5.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle5.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendTitle12.getPadding();
        java.awt.geom.Rectangle2D rectangle2D15 = legendTitle12.getBounds();
        rectangleInsets10.trim(rectangle2D15);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets2.createAdjustedRectangle(rectangle2D15, lengthAdjustmentType17, lengthAdjustmentType18);
        legendTitle1.setBounds(rectangle2D19);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent21 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = titleChangeEvent21.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = titleChangeEvent21.getType();
        java.lang.String str24 = chartChangeEventType23.toString();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(chartChangeEventType22);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str24.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        java.lang.Object obj5 = multiplePiePlot2.clone();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("Other", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.util.TableOrder tableOrder7 = multiplePiePlot2.getDataExtractOrder();
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        double double16 = legendTitle9.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        java.awt.Paint paint20 = multiplePiePlot19.getNoDataMessagePaint();
        java.awt.Paint paint21 = multiplePiePlot19.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot19);
        jFreeChart22.setBackgroundImageAlignment((int) (short) 0);
        legendTitle9.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart22);
        java.awt.Stroke stroke26 = jFreeChart22.getBorderStroke();
        java.lang.Object obj27 = jFreeChart22.clone();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D29 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D29.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        java.lang.Object obj33 = defaultKeyedValues2D29.clone();
        java.util.List list34 = defaultKeyedValues2D29.getRowKeys();
        jFreeChart22.setSubtitles(list34);
        java.util.List list36 = jFreeChart22.getSubtitles();
        boolean boolean37 = jFreeChart22.getAntiAlias();
        java.awt.Paint paint38 = jFreeChart22.getBackgroundPaint();
        try {
            multiplePiePlot2.setPieChart(jFreeChart22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'pieChart' argument must be a chart based on a PiePlot.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(tableOrder7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("ChartEntity: tooltip = ");
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.Paint paint6 = jFreeChart5.getBorderPaint();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        java.awt.Paint paint12 = legendTitle8.getItemPaint();
        double double13 = legendTitle8.getContentXOffset();
        jFreeChart5.removeSubtitle((org.jfree.chart.title.Title) legendTitle8);
        java.awt.Paint paint15 = jFreeChart5.getBackgroundPaint();
        java.awt.RenderingHints renderingHints16 = jFreeChart5.getRenderingHints();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(renderingHints16);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot1.getLegendLabelURLGenerator();
        double double7 = piePlot1.getMaximumExplodePercent();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Enumeration<java.lang.String> strEnumeration2 = jFreeChartResources0.getKeys();
        java.lang.Object[][] objArray3 = jFreeChartResources0.getContents();
        try {
            java.lang.String str5 = jFreeChartResources0.getString("java.awt.Color[r=0,g=0,b=0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key java.awt.Color[r=0,g=0,b=0]");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(strEnumeration2);
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        java.awt.Paint paint2 = textTitle0.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getTextAlignment();
        double double4 = textTitle0.getHeight();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getRight();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset2.validateObject();
        org.jfree.data.general.DatasetGroup datasetGroup4 = defaultCategoryDataset2.getGroup();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets0, (org.jfree.data.general.Dataset) defaultCategoryDataset2);
        int int6 = defaultCategoryDataset2.getRowCount();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(datasetGroup4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Comparable comparable3 = multiplePiePlot1.getAggregatedItemsKey();
        java.awt.Color color4 = java.awt.Color.black;
        java.awt.Color color5 = color4.darker();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = multiplePiePlot1.getDrawingSupplier();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = multiplePiePlot1.getLegendItems();
        java.awt.Paint paint9 = multiplePiePlot1.getBackgroundPaint();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass12 = rectangleInsets11.getClass();
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        double double15 = legendTitle14.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle14.getPadding();
        legendTitle14.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle14.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        double double22 = legendTitle21.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = legendTitle21.getPadding();
        java.awt.geom.Rectangle2D rectangle2D24 = legendTitle21.getBounds();
        rectangleInsets19.trim(rectangle2D24);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets11.createAdjustedRectangle(rectangle2D24, lengthAdjustmentType26, lengthAdjustmentType27);
        java.awt.Color color29 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder30 = new org.jfree.chart.block.BlockBorder(rectangleInsets11, (java.awt.Paint) color29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass32 = rectangleInsets31.getClass();
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        double double35 = legendTitle34.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle34.getPadding();
        legendTitle34.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = legendTitle34.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        double double42 = legendTitle41.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = legendTitle41.getPadding();
        java.awt.geom.Rectangle2D rectangle2D44 = legendTitle41.getBounds();
        rectangleInsets39.trim(rectangle2D44);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType46 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets31.createAdjustedRectangle(rectangle2D44, lengthAdjustmentType46, lengthAdjustmentType47);
        org.jfree.chart.LegendItemSource legendItemSource49 = null;
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle(legendItemSource49);
        double double51 = legendTitle50.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = legendTitle50.getPadding();
        java.awt.geom.Rectangle2D rectangle2D53 = legendTitle50.getBounds();
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets31.createInsetRectangle(rectangle2D53, false, true);
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets11.createInsetRectangle(rectangle2D53, false, true);
        try {
            multiplePiePlot1.drawBackground(graphics2D10, rectangle2D53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D59);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        textTitle0.setWidth((double) 100L);
        textTitle0.setText("");
        java.lang.String str6 = textTitle0.getText();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass11 = rectangleInsets10.getClass();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        double double14 = legendTitle13.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle13.getPadding();
        legendTitle13.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle13.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        double double21 = legendTitle20.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle20.getPadding();
        java.awt.geom.Rectangle2D rectangle2D23 = legendTitle20.getBounds();
        rectangleInsets18.trim(rectangle2D23);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets10.createAdjustedRectangle(rectangle2D23, lengthAdjustmentType25, lengthAdjustmentType26);
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle29.getPadding();
        java.awt.geom.Rectangle2D rectangle2D32 = legendTitle29.getBounds();
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets10.createInsetRectangle(rectangle2D32, false, true);
        rectangleInsets8.trim(rectangle2D32);
        textTitle0.draw(graphics2D7, rectangle2D32);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass40 = rectangleInsets39.getClass();
        org.jfree.chart.LegendItemSource legendItemSource41 = null;
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle(legendItemSource41);
        double double43 = legendTitle42.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = legendTitle42.getPadding();
        legendTitle42.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = legendTitle42.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource48 = null;
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle(legendItemSource48);
        double double50 = legendTitle49.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = legendTitle49.getPadding();
        java.awt.geom.Rectangle2D rectangle2D52 = legendTitle49.getBounds();
        rectangleInsets47.trim(rectangle2D52);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType54 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets39.createAdjustedRectangle(rectangle2D52, lengthAdjustmentType54, lengthAdjustmentType55);
        textTitle0.draw(graphics2D38, rectangle2D56);
        java.lang.String str58 = textTitle0.getID();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNull(str58);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("HorizontalAlignment.RIGHT", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        jFreeChart5.setBackgroundImageAlignment((int) (short) 0);
        java.awt.Image image8 = jFreeChart5.getBackgroundImage();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        java.lang.String str10 = textTitle9.getURLText();
        textTitle9.setPadding((double) 0, (-1.0d), (double) (byte) 10, (double) 10L);
        jFreeChart5.setTitle(textTitle9);
        int int17 = jFreeChart5.getSubtitleCount();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        double double3 = legendTitle2.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle2.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle2.setLegendItemGraphicAnchor(rectangleAnchor5);
        boolean boolean7 = color0.equals((java.lang.Object) rectangleAnchor5);
        java.lang.String str8 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str8.equals("java.awt.Color[r=128,g=128,b=128]"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle20.getTextAlignment();
        java.awt.Paint paint22 = textTitle20.getPaint();
        java.awt.Stroke[] strokeArray23 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean24 = textTitle20.equals((java.lang.Object) strokeArray23);
        jFreeChart14.addSubtitle((org.jfree.chart.title.Title) textTitle20);
        int int26 = jFreeChart14.getBackgroundImageAlignment();
        org.jfree.chart.plot.Plot plot27 = jFreeChart14.getPlot();
        boolean boolean28 = plot27.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint1 = lineBorder0.getPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer1, (java.lang.Object) 255);
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        double double7 = legendTitle6.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle6.getPadding();
        java.awt.geom.Rectangle2D rectangle2D9 = legendTitle6.getBounds();
        double double10 = legendTitle6.getContentYOffset();
        org.jfree.chart.ui.Contributor contributor13 = new org.jfree.chart.ui.Contributor("", "");
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle6, (java.lang.Object) contributor13);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = null;
        try {
            org.jfree.chart.util.Size2D size2D18 = blockContainer15.arrange(graphics2D16, rectangleConstraint17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getTextAlignment();
        textTitle5.setWidth((double) 100L);
        textTitle5.setText("");
        java.lang.String str11 = textTitle5.getText();
        org.jfree.chart.util.ObjectList objectList12 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj14 = objectList12.get(1);
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle5, obj14);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle16.getTextAlignment();
        textTitle16.setWidth((double) 100L);
        textTitle16.setText("");
        java.lang.String str22 = textTitle16.getText();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color27);
        textTitle16.setPaint((java.awt.Paint) color27);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset30);
        java.awt.Paint paint32 = multiplePiePlot31.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        multiplePiePlot31.notifyListeners(plotChangeEvent33);
        org.jfree.chart.JFreeChart jFreeChart35 = multiplePiePlot31.getPieChart();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle16, (java.lang.Object) multiplePiePlot31);
        org.jfree.chart.block.BlockContainer blockContainer37 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.lang.Object obj38 = blockContainer37.clone();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        double double42 = legendTitle41.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame43 = legendTitle41.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray45 = new org.jfree.chart.LegendItemSource[] { legendItemSource44 };
        legendTitle41.setSources(legendItemSourceArray45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass48 = rectangleInsets47.getClass();
        org.jfree.chart.LegendItemSource legendItemSource49 = null;
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle(legendItemSource49);
        double double51 = legendTitle50.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = legendTitle50.getPadding();
        legendTitle50.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = legendTitle50.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource56 = null;
        org.jfree.chart.title.LegendTitle legendTitle57 = new org.jfree.chart.title.LegendTitle(legendItemSource56);
        double double58 = legendTitle57.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = legendTitle57.getPadding();
        java.awt.geom.Rectangle2D rectangle2D60 = legendTitle57.getBounds();
        rectangleInsets55.trim(rectangle2D60);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType62 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets47.createAdjustedRectangle(rectangle2D60, lengthAdjustmentType62, lengthAdjustmentType63);
        org.jfree.chart.LegendItemSource legendItemSource65 = null;
        org.jfree.chart.title.LegendTitle legendTitle66 = new org.jfree.chart.title.LegendTitle(legendItemSource65);
        double double67 = legendTitle66.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = legendTitle66.getPadding();
        java.awt.geom.Rectangle2D rectangle2D69 = legendTitle66.getBounds();
        java.awt.geom.Rectangle2D rectangle2D72 = rectangleInsets47.createInsetRectangle(rectangle2D69, false, true);
        legendTitle41.setBounds(rectangle2D69);
        java.lang.Object obj74 = null;
        try {
            java.lang.Object obj75 = blockContainer37.draw(graphics2D39, rectangle2D69, obj74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(jFreeChart35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame43);
        org.junit.Assert.assertNotNull(legendItemSourceArray45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(rectangle2D72);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint4 = defaultDrawingSupplier3.getNextFillPaint();
        java.lang.Object obj5 = defaultDrawingSupplier3.clone();
        java.awt.Paint paint6 = defaultDrawingSupplier3.getNextOutlinePaint();
        multiplePiePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier3);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        textTitle0.setWidth((double) 100L);
        textTitle0.setText("");
        textTitle0.setHeight((double) 0L);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment8, verticalAlignment9, 0.08d, (double) 8);
        java.lang.String str13 = verticalAlignment9.toString();
        textTitle0.setVerticalAlignment(verticalAlignment9);
        java.awt.Font font15 = textTitle0.getFont();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle17.setHorizontalAlignment(horizontalAlignment18);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement23 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment18, verticalAlignment20, (double) (short) 10, (double) 10.0f);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot26 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset25);
        java.awt.Paint paint27 = multiplePiePlot26.getNoDataMessagePaint();
        java.awt.Paint paint28 = multiplePiePlot26.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot26);
        jFreeChart29.setBackgroundImageAlignment((int) (short) 0);
        java.awt.Stroke stroke32 = jFreeChart29.getBorderStroke();
        org.jfree.chart.title.TextTitle textTitle33 = jFreeChart29.getTitle();
        boolean boolean34 = horizontalAlignment18.equals((java.lang.Object) jFreeChart29);
        java.awt.Paint paint35 = jFreeChart29.getBackgroundPaint();
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart29);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "VerticalAlignment.CENTER" + "'", str13.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(textTitle33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass8 = rectangleInsets7.getClass();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        legendTitle10.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle10.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        double double18 = legendTitle17.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle17.getPadding();
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle17.getBounds();
        rectangleInsets15.trim(rectangle2D20);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets7.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType22, lengthAdjustmentType23);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets7.createInsetRectangle(rectangle2D29, false, true);
        legendTitle1.setBounds(rectangle2D29);
        legendTitle1.setWidth((double) 100);
        org.jfree.chart.block.BlockContainer blockContainer36 = legendTitle1.getItemContainer();
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = null;
        try {
            org.jfree.chart.util.Size2D size2D39 = blockContainer36.arrange(graphics2D37, rectangleConstraint38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(blockContainer36);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("JFreeChart", "", "UnitType.ABSOLUTE", "VerticalAlignment.BOTTOM");
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass12 = rectangleInsets11.getClass();
        double double13 = rectangleInsets11.getLeft();
        double double15 = rectangleInsets11.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass17 = rectangleInsets16.getClass();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        legendTitle19.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle19.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        rectangleInsets24.trim(rectangle2D29);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets16.createAdjustedRectangle(rectangle2D29, lengthAdjustmentType31, lengthAdjustmentType32);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle35.getPadding();
        java.awt.geom.Rectangle2D rectangle2D38 = legendTitle35.getBounds();
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets16.createInsetRectangle(rectangle2D38, false, true);
        org.jfree.chart.LegendItemSource legendItemSource42 = null;
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle(legendItemSource42);
        double double44 = legendTitle43.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = legendTitle43.getPadding();
        legendTitle43.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource48 = null;
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle(legendItemSource48);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment50 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle49.setHorizontalAlignment(horizontalAlignment50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = legendTitle49.getLegendItemGraphicAnchor();
        legendTitle43.setLegendItemGraphicAnchor(rectangleAnchor52);
        java.awt.geom.Point2D point2D54 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D38, rectangleAnchor52);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets11.createOutsetRectangle(rectangle2D38, false, true);
        legendTitle8.setPadding(rectangleInsets11);
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.image.ColorModel colorModel60 = null;
        java.awt.Rectangle rectangle61 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass63 = rectangleInsets62.getClass();
        org.jfree.chart.LegendItemSource legendItemSource64 = null;
        org.jfree.chart.title.LegendTitle legendTitle65 = new org.jfree.chart.title.LegendTitle(legendItemSource64);
        double double66 = legendTitle65.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = legendTitle65.getPadding();
        legendTitle65.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = legendTitle65.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource71 = null;
        org.jfree.chart.title.LegendTitle legendTitle72 = new org.jfree.chart.title.LegendTitle(legendItemSource71);
        double double73 = legendTitle72.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = legendTitle72.getPadding();
        java.awt.geom.Rectangle2D rectangle2D75 = legendTitle72.getBounds();
        rectangleInsets70.trim(rectangle2D75);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType77 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType78 = null;
        java.awt.geom.Rectangle2D rectangle2D79 = rectangleInsets62.createAdjustedRectangle(rectangle2D75, lengthAdjustmentType77, lengthAdjustmentType78);
        java.awt.geom.AffineTransform affineTransform80 = null;
        java.awt.RenderingHints renderingHints81 = null;
        java.awt.PaintContext paintContext82 = color59.createContext(colorModel60, rectangle61, rectangle2D79, affineTransform80, renderingHints81);
        java.awt.geom.Rectangle2D rectangle2D83 = rectangleInsets11.createOutsetRectangle(rectangle2D79);
        piePlot1.setLegendItemShape((java.awt.Shape) rectangle2D83);
        double double85 = piePlot1.getLabelGap();
        java.awt.Stroke stroke86 = piePlot1.getLabelLinkStroke();
        piePlot1.setCircular(true, true);
        boolean boolean90 = piePlot1.getLabelLinksVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets91 = piePlot1.getLabelPadding();
        piePlot1.setLabelLinkMargin((double) 2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(horizontalAlignment50);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(point2D54);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(paintContext82);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.025d + "'", double85 == 0.025d);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(rectangleInsets91);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        multiplePiePlot1.markerChanged(markerChangeEvent4);
        org.jfree.chart.JFreeChart jFreeChart6 = multiplePiePlot1.getPieChart();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(jFreeChart6);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        java.awt.Stroke stroke19 = jFreeChart14.getBorderStroke();
        org.jfree.chart.ui.ProjectInfo projectInfo20 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image21 = projectInfo20.getLogo();
        jFreeChart14.setBackgroundImage(image21);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart14.getTitle();
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = textTitle24.getTextAlignment();
        java.awt.Paint paint26 = textTitle24.getBackgroundPaint();
        org.jfree.chart.block.BlockFrame blockFrame27 = textTitle24.getFrame();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement32 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment28, verticalAlignment29, (double) '#', 0.0d);
        textTitle24.setVerticalAlignment(verticalAlignment29);
        boolean boolean34 = textTitle23.equals((java.lang.Object) verticalAlignment29);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(projectInfo20);
        org.junit.Assert.assertNotNull(image21);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(blockFrame27);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        java.lang.Object obj19 = jFreeChart14.clone();
        java.awt.Color color20 = java.awt.Color.GREEN;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        int int5 = defaultKeyedValues2D1.getColumnCount();
        try {
            defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 10L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 10");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        double double7 = piePlot1.getInteriorGap();
        java.awt.Paint paint8 = piePlot1.getLabelShadowPaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 4.0d, (java.awt.Paint) color10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset13, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        java.lang.String str20 = pieSectionEntity19.toString();
        java.lang.String str21 = pieSectionEntity19.getToolTipText();
        org.jfree.data.general.PieDataset pieDataset22 = pieSectionEntity19.getDataset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PieSection: 255, -48897(10)" + "'", str20.equals("PieSection: 255, -48897(10)"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str21.equals("java.awt.Color[r=0,g=0,b=0]"));
        org.junit.Assert.assertNull(pieDataset22);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Comparable comparable3 = multiplePiePlot1.getAggregatedItemsKey();
        java.awt.Color color4 = java.awt.Color.black;
        java.awt.Color color5 = color4.darker();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = multiplePiePlot1.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset8 = multiplePiePlot1.getDataset();
        java.awt.Color color9 = java.awt.Color.gray;
        multiplePiePlot1.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot1.getPieChart();
        float float12 = jFreeChart11.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(jFreeChart11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        piePlot1.setExplodePercent((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (double) (short) 1);
        piePlot1.setMinimumArcAngleToDraw((double) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        java.awt.Paint paint13 = multiplePiePlot12.getNoDataMessagePaint();
        java.awt.Paint paint14 = multiplePiePlot12.getNoDataMessagePaint();
        java.awt.Stroke stroke15 = multiplePiePlot12.getOutlineStroke();
        piePlot1.setLabelLinkStroke(stroke15);
        java.awt.Color color17 = java.awt.Color.black;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color17);
        java.awt.Font font19 = piePlot1.getLabelFont();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.block.Block block5 = null;
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        double double8 = legendTitle7.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle7.getPadding();
        legendTitle7.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = legendTitle7.getLegendItemGraphicEdge();
        boolean boolean13 = legendTitle7.getNotify();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot14.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Font font17 = multiplePiePlot14.getNoDataMessageFont();
        legendTitle7.setItemFont(font17);
        java.lang.Object obj19 = legendTitle7.clone();
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        double double22 = legendTitle21.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame23 = legendTitle21.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray25 = new org.jfree.chart.LegendItemSource[] { legendItemSource24 };
        legendTitle21.setSources(legendItemSourceArray25);
        legendTitle7.setSources(legendItemSourceArray25);
        columnArrangement4.add(block5, (java.lang.Object) legendItemSourceArray25);
        columnArrangement4.clear();
        org.jfree.chart.block.Block block30 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass32 = rectangleInsets31.getClass();
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        double double35 = legendTitle34.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle34.getPadding();
        legendTitle34.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = legendTitle34.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        double double42 = legendTitle41.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = legendTitle41.getPadding();
        java.awt.geom.Rectangle2D rectangle2D44 = legendTitle41.getBounds();
        rectangleInsets39.trim(rectangle2D44);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType46 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets31.createAdjustedRectangle(rectangle2D44, lengthAdjustmentType46, lengthAdjustmentType47);
        java.awt.Color color49 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder50 = new org.jfree.chart.block.BlockBorder(rectangleInsets31, (java.awt.Paint) color49);
        double double52 = rectangleInsets31.calculateTopOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double55 = rectangleInsets53.trimWidth((double) 2);
        org.jfree.chart.LegendItemSource legendItemSource56 = null;
        org.jfree.chart.title.LegendTitle legendTitle57 = new org.jfree.chart.title.LegendTitle(legendItemSource56);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass59 = rectangleInsets58.getClass();
        org.jfree.chart.LegendItemSource legendItemSource60 = null;
        org.jfree.chart.title.LegendTitle legendTitle61 = new org.jfree.chart.title.LegendTitle(legendItemSource60);
        double double62 = legendTitle61.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = legendTitle61.getPadding();
        legendTitle61.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = legendTitle61.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource67 = null;
        org.jfree.chart.title.LegendTitle legendTitle68 = new org.jfree.chart.title.LegendTitle(legendItemSource67);
        double double69 = legendTitle68.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = legendTitle68.getPadding();
        java.awt.geom.Rectangle2D rectangle2D71 = legendTitle68.getBounds();
        rectangleInsets66.trim(rectangle2D71);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType73 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType74 = null;
        java.awt.geom.Rectangle2D rectangle2D75 = rectangleInsets58.createAdjustedRectangle(rectangle2D71, lengthAdjustmentType73, lengthAdjustmentType74);
        legendTitle57.setBounds(rectangle2D75);
        rectangleInsets53.trim(rectangle2D75);
        rectangleInsets31.trim(rectangle2D75);
        columnArrangement4.add(block30, (java.lang.Object) rectangle2D75);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame23);
        org.junit.Assert.assertNotNull(legendItemSourceArray25);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(rectangle2D75);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.lang.String str4 = rectangleInsets3.toString();
        double double6 = rectangleInsets3.extendHeight((double) 10);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset7);
        java.awt.Paint paint9 = multiplePiePlot8.getAggregatedItemsPaint();
        org.jfree.chart.plot.Plot plot10 = multiplePiePlot8.getParent();
        java.awt.Paint paint11 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        multiplePiePlot8.setAggregatedItemsPaint(paint11);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, paint11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.0d + "'", double6 == 12.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        java.awt.Shape shape4 = piePlot1.getLegendItemShape();
        double double6 = piePlot1.getExplodePercent((java.lang.Comparable) 1L);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke1 = piePlot0.getOutlineStroke();
        boolean boolean2 = piePlot0.getIgnoreNullValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup("RectangleEdge.LEFT");
        defaultCategoryDataset0.setGroup(datasetGroup2);
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.awt.Color color0 = java.awt.Color.pink;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Stroke stroke5 = multiplePiePlot2.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double8 = rectangleInsets6.trimWidth((double) 2);
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke5, rectangleInsets6);
        java.awt.Paint paint10 = lineBorder9.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        piePlot1.setExplodePercent((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (double) (short) 1);
        piePlot1.setMinimumArcAngleToDraw((double) (byte) 0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator11);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        java.awt.Paint paint11 = multiplePiePlot10.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        multiplePiePlot10.notifyListeners(plotChangeEvent12);
        java.awt.Paint paint14 = multiplePiePlot10.getNoDataMessagePaint();
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 192, 4.0d, (double) (byte) 10, 0.0d, paint14);
        piePlot1.setSectionPaint((java.lang.Comparable) 98.0d, paint14);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor17 = piePlot1.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord19 = abstractPieLabelDistributor17.getPieLabelRecord(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor17);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        titleChangeEvent3.setChart(jFreeChart4);
        java.lang.Object obj6 = titleChangeEvent3.getSource();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle8);
        org.jfree.chart.block.BlockContainer blockContainer11 = null;
        legendTitle8.setWrapper(blockContainer11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle8.setItemPaint((java.awt.Paint) color13);
        double double15 = legendTitle8.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        java.awt.Paint paint19 = multiplePiePlot18.getNoDataMessagePaint();
        java.awt.Paint paint20 = multiplePiePlot18.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot18);
        jFreeChart21.setBackgroundImageAlignment((int) (short) 0);
        legendTitle8.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart21);
        java.awt.Stroke stroke25 = jFreeChart21.getBorderStroke();
        java.awt.Stroke stroke26 = jFreeChart21.getBorderStroke();
        int int27 = jFreeChart21.getBackgroundImageAlignment();
        titleChangeEvent3.setChart(jFreeChart21);
        org.jfree.chart.LegendItemSource legendItemSource29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass32 = rectangleInsets31.getClass();
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        double double35 = legendTitle34.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle34.getPadding();
        legendTitle34.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = legendTitle34.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        double double42 = legendTitle41.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = legendTitle41.getPadding();
        java.awt.geom.Rectangle2D rectangle2D44 = legendTitle41.getBounds();
        rectangleInsets39.trim(rectangle2D44);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType46 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets31.createAdjustedRectangle(rectangle2D44, lengthAdjustmentType46, lengthAdjustmentType47);
        legendTitle30.setBounds(rectangle2D48);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent50 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle30);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType51 = titleChangeEvent50.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType52 = titleChangeEvent50.getType();
        titleChangeEvent3.setType(chartChangeEventType52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(chartChangeEventType51);
        org.junit.Assert.assertNotNull(chartChangeEventType52);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        double double2 = rectangleInsets0.getLeft();
        double double4 = rectangleInsets0.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass6 = rectangleInsets5.getClass();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        legendTitle8.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle8.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle15.getPadding();
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle15.getBounds();
        rectangleInsets13.trim(rectangle2D18);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets5.createAdjustedRectangle(rectangle2D18, lengthAdjustmentType20, lengthAdjustmentType21);
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource23);
        double double25 = legendTitle24.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle24.getPadding();
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets5.createInsetRectangle(rectangle2D27, false, true);
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle(legendItemSource31);
        double double33 = legendTitle32.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle32.getPadding();
        legendTitle32.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource37 = null;
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle(legendItemSource37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle38.setHorizontalAlignment(horizontalAlignment39);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = legendTitle38.getLegendItemGraphicAnchor();
        legendTitle32.setLegendItemGraphicAnchor(rectangleAnchor41);
        java.awt.geom.Point2D point2D43 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D27, rectangleAnchor41);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets0.createOutsetRectangle(rectangle2D27, false, true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset47 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset47.validateObject();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent49 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) false, (org.jfree.data.general.Dataset) defaultCategoryDataset47);
        int int50 = defaultCategoryDataset47.getRowCount();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(point2D43);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        multiplePiePlot2.notifyListeners(plotChangeEvent4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset6);
        java.awt.Paint paint8 = multiplePiePlot7.getNoDataMessagePaint();
        java.lang.Comparable comparable9 = multiplePiePlot7.getAggregatedItemsKey();
        java.awt.Color color10 = java.awt.Color.black;
        java.awt.Color color11 = color10.darker();
        multiplePiePlot7.setAggregatedItemsPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = multiplePiePlot7.getDrawingSupplier();
        multiplePiePlot2.setDrawingSupplier(drawingSupplier13);
        java.awt.Font font15 = multiplePiePlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.Color color18 = java.awt.Color.red;
        textTitle17.setPaint((java.awt.Paint) color18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean21 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) horizontalAlignment23);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = textTitle25.getTextAlignment();
        java.awt.Paint paint27 = textTitle25.getBackgroundPaint();
        org.jfree.chart.block.BlockFrame blockFrame28 = textTitle25.getFrame();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement33 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment29, verticalAlignment30, (double) '#', 0.0d);
        textTitle25.setVerticalAlignment(verticalAlignment30);
        org.jfree.chart.block.FlowArrangement flowArrangement37 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment23, verticalAlignment30, 12.0d, (double) (short) 10);
        org.jfree.chart.LegendItemSource legendItemSource38 = null;
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle(legendItemSource38);
        double double40 = legendTitle39.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = legendTitle39.getPadding();
        legendTitle39.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = legendTitle39.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass46 = rectangleInsets45.getClass();
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        double double49 = legendTitle48.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = legendTitle48.getPadding();
        legendTitle48.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = legendTitle48.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource54 = null;
        org.jfree.chart.title.LegendTitle legendTitle55 = new org.jfree.chart.title.LegendTitle(legendItemSource54);
        double double56 = legendTitle55.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = legendTitle55.getPadding();
        java.awt.geom.Rectangle2D rectangle2D58 = legendTitle55.getBounds();
        rectangleInsets53.trim(rectangle2D58);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType60 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType61 = null;
        java.awt.geom.Rectangle2D rectangle2D62 = rectangleInsets45.createAdjustedRectangle(rectangle2D58, lengthAdjustmentType60, lengthAdjustmentType61);
        legendTitle39.setPadding(rectangleInsets45);
        double double64 = rectangleInsets45.getTop();
        org.jfree.chart.title.TextTitle textTitle65 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.NEW_DATASET", font15, (java.awt.Paint) color18, rectangleEdge20, horizontalAlignment22, verticalAlignment30, rectangleInsets45);
        boolean boolean66 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge20);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "Other" + "'", comparable9.equals("Other"));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNotNull(blockFrame28);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle2.setHorizontalAlignment(horizontalAlignment3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment3, verticalAlignment5, (double) (short) 10, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame13 = legendTitle11.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray15 = new org.jfree.chart.LegendItemSource[] { legendItemSource14 };
        legendTitle11.setSources(legendItemSourceArray15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass18 = rectangleInsets17.getClass();
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        double double21 = legendTitle20.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle20.getPadding();
        legendTitle20.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle20.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        double double28 = legendTitle27.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle27.getPadding();
        java.awt.geom.Rectangle2D rectangle2D30 = legendTitle27.getBounds();
        rectangleInsets25.trim(rectangle2D30);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets17.createAdjustedRectangle(rectangle2D30, lengthAdjustmentType32, lengthAdjustmentType33);
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        double double37 = legendTitle36.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle36.getPadding();
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle36.getBounds();
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets17.createInsetRectangle(rectangle2D39, false, true);
        legendTitle11.setBounds(rectangle2D39);
        legendTitle11.setWidth((double) 100);
        org.jfree.chart.block.BlockContainer blockContainer46 = legendTitle11.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement47 = blockContainer46.getArrangement();
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement8, arrangement47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = legendTitle48.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame13);
        org.junit.Assert.assertNotNull(legendItemSourceArray15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(blockContainer46);
        org.junit.Assert.assertNotNull(arrangement47);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.util.List list2 = blockContainer0.getBlocks();
        java.util.List list3 = blockContainer0.getBlocks();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        piePlot1.setExplodePercent((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (double) (short) 1);
        piePlot1.setMinimumArcAngleToDraw((double) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        java.awt.Paint paint13 = multiplePiePlot12.getNoDataMessagePaint();
        java.awt.Paint paint14 = multiplePiePlot12.getNoDataMessagePaint();
        java.awt.Stroke stroke15 = multiplePiePlot12.getOutlineStroke();
        piePlot1.setLabelLinkStroke(stroke15);
        java.awt.Color color17 = java.awt.Color.black;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color17);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = piePlot1.getLegendLabelURLGenerator();
        piePlot1.setStartAngle(0.0d);
        boolean boolean22 = piePlot1.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(pieURLGenerator19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        textTitle0.setWidth((double) 100L);
        java.lang.String str4 = textTitle0.getToolTipText();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        java.lang.Object obj19 = jFreeChart14.clone();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D21 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D21.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        java.lang.Object obj25 = defaultKeyedValues2D21.clone();
        java.util.List list26 = defaultKeyedValues2D21.getRowKeys();
        jFreeChart14.setSubtitles(list26);
        jFreeChart14.setBackgroundImageAlignment((int) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(list26);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_ROW;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D2.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        int int6 = defaultKeyedValues2D2.getColumnCount();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        boolean boolean8 = defaultKeyedValues2D2.equals((java.lang.Object) pieLabelLinkStyle7);
        boolean boolean9 = tableOrder0.equals((java.lang.Object) pieLabelLinkStyle7);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame13 = legendTitle11.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray15 = new org.jfree.chart.LegendItemSource[] { legendItemSource14 };
        legendTitle11.setSources(legendItemSourceArray15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass18 = rectangleInsets17.getClass();
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        double double21 = legendTitle20.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle20.getPadding();
        legendTitle20.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle20.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        double double28 = legendTitle27.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle27.getPadding();
        java.awt.geom.Rectangle2D rectangle2D30 = legendTitle27.getBounds();
        rectangleInsets25.trim(rectangle2D30);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets17.createAdjustedRectangle(rectangle2D30, lengthAdjustmentType32, lengthAdjustmentType33);
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        double double37 = legendTitle36.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle36.getPadding();
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle36.getBounds();
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets17.createInsetRectangle(rectangle2D39, false, true);
        legendTitle11.setBounds(rectangle2D39);
        legendTitle11.setWidth((double) 100);
        org.jfree.chart.block.BlockContainer blockContainer46 = legendTitle11.getItemContainer();
        boolean boolean47 = pieLabelLinkStyle7.equals((java.lang.Object) blockContainer46);
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame13);
        org.junit.Assert.assertNotNull(legendItemSourceArray15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(blockContainer46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        java.awt.Shape shape4 = piePlot1.getLegendItemShape();
        piePlot1.setIgnoreNullValues(true);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset13, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        java.lang.String str20 = pieSectionEntity19.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass22 = rectangleInsets21.getClass();
        double double23 = rectangleInsets21.getLeft();
        double double25 = rectangleInsets21.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass27 = rectangleInsets26.getClass();
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle29.getPadding();
        legendTitle29.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle29.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        double double37 = legendTitle36.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle36.getPadding();
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle36.getBounds();
        rectangleInsets34.trim(rectangle2D39);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets26.createAdjustedRectangle(rectangle2D39, lengthAdjustmentType41, lengthAdjustmentType42);
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        double double46 = legendTitle45.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = legendTitle45.getPadding();
        java.awt.geom.Rectangle2D rectangle2D48 = legendTitle45.getBounds();
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets26.createInsetRectangle(rectangle2D48, false, true);
        org.jfree.chart.LegendItemSource legendItemSource52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle(legendItemSource52);
        double double54 = legendTitle53.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = legendTitle53.getPadding();
        legendTitle53.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource58 = null;
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle(legendItemSource58);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment60 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle59.setHorizontalAlignment(horizontalAlignment60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = legendTitle59.getLegendItemGraphicAnchor();
        legendTitle53.setLegendItemGraphicAnchor(rectangleAnchor62);
        java.awt.geom.Point2D point2D64 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D48, rectangleAnchor62);
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets21.createOutsetRectangle(rectangle2D48, false, true);
        pieSectionEntity19.setArea((java.awt.Shape) rectangle2D67);
        pieSectionEntity19.setToolTipText("rect");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PieSection: 255, -48897(10)" + "'", str20.equals("PieSection: 255, -48897(10)"));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(horizontalAlignment60);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(point2D64);
        org.junit.Assert.assertNotNull(rectangle2D67);
    }
}

