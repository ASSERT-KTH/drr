import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 100.0f, (double) 1.0f, (double) (-1L), 0.0d, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.Plot plot2 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", font1, plot2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = flowArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        java.awt.geom.Rectangle2D rectangle2D6 = legendTitle3.getBounds();
        try {
            java.lang.Object obj8 = blockContainer0.draw(graphics2D1, rectangle2D6, (java.lang.Object) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        java.awt.geom.Rectangle2D rectangle2D6 = legendTitle3.getBounds();
        java.lang.Object obj7 = null;
        try {
            java.lang.Object obj8 = blockContainer0.draw(graphics2D1, rectangle2D6, obj7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        try {
            java.lang.Object obj4 = blockContainer0.draw(graphics2D1, rectangle2D2, (java.lang.Object) color3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        java.awt.Font font3 = null;
        try {
            legendTitle1.setItemFont(font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        java.awt.geom.Rectangle2D rectangle2D6 = legendTitle3.getBounds();
        try {
            blockBorder0.draw(graphics2D1, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle2.setHorizontalAlignment(horizontalAlignment3);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        try {
            blockContainer0.add((org.jfree.chart.block.Block) legendTitle2, (java.lang.Object) font5);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.awt.Font cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = blockContainer0.arrange(graphics2D1, rectangleConstraint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle1.setHorizontalAlignment(horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment2, verticalAlignment4, (double) (short) 10, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = columnArrangement7.arrange(blockContainer8, graphics2D9, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle1.setHorizontalAlignment(horizontalAlignment2);
        boolean boolean5 = horizontalAlignment2.equals((java.lang.Object) (byte) -1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass7 = rectangleInsets6.getClass();
        boolean boolean8 = basicProjectInfo5.equals((java.lang.Object) wildcardClass7);
        basicProjectInfo5.setCopyright("hi!");
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            defaultKeyedValues2D1.removeColumn((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Object obj4 = multiplePiePlot1.clone();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        try {
            multiplePiePlot1.setPieChart(jFreeChart5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'pieChart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        legendTitle8.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle8.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle15.getPadding();
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle15.getBounds();
        rectangleInsets13.trim(rectangle2D18);
        try {
            blockBorder5.draw(graphics2D6, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D18);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        try {
            java.awt.Color color1 = java.awt.Color.decode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Comparable comparable2 = null;
        java.lang.Comparable comparable3 = null;
        try {
            java.lang.Number number4 = defaultKeyedValues2D1.getValue(comparable2, comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle10.getBounds();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle15.setHorizontalAlignment(horizontalAlignment16);
        try {
            java.lang.Object obj18 = legendTitle1.draw(graphics2D8, rectangle2D13, (java.lang.Object) legendTitle15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) 8.0d);
        java.awt.Color color3 = java.awt.Color.YELLOW;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        boolean boolean10 = chartChangeEventType0.equals((java.lang.Object) colorModel4);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            defaultKeyedValues2D1.removeRow((java.lang.Comparable) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        pieLabelDistributor1.distributeLabels((double) 2, (double) (short) 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        titleChangeEvent3.setChart(jFreeChart4);
        java.lang.Object obj6 = titleChangeEvent3.getSource();
        java.lang.String str7 = titleChangeEvent3.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        try {
            multiplePiePlot1.setPieChart(jFreeChart2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'pieChart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Color color0 = java.awt.Color.black;
        java.awt.Color color1 = color0.darker();
        java.awt.color.ColorSpace colorSpace2 = null;
        float[] floatArray5 = new float[] { (byte) 10, 0 };
        try {
            float[] floatArray6 = color0.getComponents(colorSpace2, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.NEW_DATASET", "Multiple Pie Plot");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass7 = rectangleInsets6.getClass();
        boolean boolean8 = basicProjectInfo5.equals((java.lang.Object) wildcardClass7);
        basicProjectInfo5.setName("");
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        multiplePiePlot1.markerChanged(markerChangeEvent4);
        java.lang.String str6 = multiplePiePlot1.getNoDataMessage();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        java.lang.Object obj5 = multiplePiePlot2.clone();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("Other", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        try {
            jFreeChart6.plotChanged(plotChangeEvent7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Multiple Pie Plot", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        java.lang.Object obj5 = multiplePiePlot2.clone();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("Other", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        try {
            java.awt.image.BufferedImage bufferedImage11 = jFreeChart6.createBufferedImage(8, 0, (int) (byte) 1, chartRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (8) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        java.lang.Object obj5 = multiplePiePlot2.clone();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("Other", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        try {
            org.jfree.chart.plot.XYPlot xYPlot7 = jFreeChart6.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.MultiplePiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.lang.String str4 = rectangleInsets3.toString();
        double double6 = rectangleInsets3.calculateLeftInset((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        double double3 = rectangleInsets0.extendWidth(0.08d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.08d + "'", double3 == 2.08d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(100.0d, 0.08d, 0.0d, (double) 2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle3.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle10.getBounds();
        rectangleInsets8.trim(rectangle2D13);
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle16.setHorizontalAlignment(horizontalAlignment17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = legendTitle16.getLegendItemGraphicAnchor();
        try {
            java.lang.Object obj20 = blockContainer0.draw(graphics2D1, rectangle2D13, (java.lang.Object) rectangleAnchor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        jFreeChart5.setBackgroundImageAlignment((int) (short) 0);
        org.jfree.chart.event.ChartChangeListener chartChangeListener8 = null;
        try {
            jFreeChart5.addChangeListener(chartChangeListener8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass8 = rectangleInsets7.getClass();
        double double9 = rectangleInsets7.getLeft();
        legendTitle1.setPadding(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        java.lang.Object obj5 = multiplePiePlot2.clone();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("Other", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        try {
            java.awt.image.BufferedImage bufferedImage12 = jFreeChart6.createBufferedImage(0, (int) (byte) 100, (double) 100.0f, (double) 100.0f, chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (100) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer1, (java.lang.Object) 255);
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        double double7 = legendTitle6.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent8 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle6);
        org.jfree.chart.block.BlockContainer blockContainer9 = null;
        legendTitle6.setWrapper(blockContainer9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle6.setItemPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor14 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        java.lang.String str15 = pieLabelDistributor14.toString();
        try {
            blockContainer1.add((org.jfree.chart.block.Block) legendTitle6, (java.lang.Object) str15);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass7 = rectangleInsets6.getClass();
        boolean boolean8 = basicProjectInfo5.equals((java.lang.Object) wildcardClass7);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo14 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass16 = rectangleInsets15.getClass();
        boolean boolean17 = basicProjectInfo14.equals((java.lang.Object) wildcardClass16);
        basicProjectInfo5.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo14);
        java.lang.String str19 = basicProjectInfo14.getInfo();
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle3.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle10.getBounds();
        rectangleInsets8.trim(rectangle2D13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets0.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType15, lengthAdjustmentType16);
        java.awt.Color color18 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color18);
        double double21 = rectangleInsets0.calculateTopOutset((double) (-1));
        double double22 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int3 = java.awt.Color.HSBtoRGB(10.0f, (float) (byte) 0, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-254) + "'", int3 == (-254));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        java.awt.Paint paint5 = legendTitle1.getItemPaint();
        java.awt.Graphics2D graphics2D6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = legendTitle1.arrange(graphics2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        multiplePiePlot1.notifyListeners(plotChangeEvent3);
        java.lang.Comparable comparable5 = null;
        try {
            multiplePiePlot1.setAggregatedItemsKey(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            java.lang.Number number3 = defaultKeyedValues2D0.getValue((-1), 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Color color2 = color1.darker();
        float[] floatArray8 = new float[] { '#', (short) 10, '#', 2, 255 };
        float[] floatArray9 = color2.getRGBComponents(floatArray8);
        float[] floatArray10 = color0.getRGBColorComponents(floatArray8);
        int int11 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass8 = rectangleInsets7.getClass();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        legendTitle10.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle10.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        double double18 = legendTitle17.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle17.getPadding();
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle17.getBounds();
        rectangleInsets15.trim(rectangle2D20);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets7.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType22, lengthAdjustmentType23);
        legendTitle1.setPadding(rectangleInsets7);
        double double27 = rectangleInsets7.calculateLeftInset((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        java.awt.Color color17 = java.awt.Color.pink;
        legendTitle9.setItemPaint((java.awt.Paint) color17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        legendTitle9.setBackgroundPaint((java.awt.Paint) color19);
        java.awt.Font font21 = legendTitle9.getItemFont();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle1.getLegendItemGraphicEdge();
        java.lang.String str7 = rectangleEdge6.toString();
        java.lang.String str8 = rectangleEdge6.toString();
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleEdge6, jFreeChart9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleEdge.LEFT" + "'", str7.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleEdge.LEFT" + "'", str8.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.RenderingHints renderingHints6 = jFreeChart5.getRenderingHints();
        java.awt.Paint paint7 = jFreeChart5.getBorderPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(renderingHints6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.RenderingHints renderingHints6 = jFreeChart5.getRenderingHints();
        try {
            org.jfree.chart.plot.XYPlot xYPlot7 = jFreeChart5.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.MultiplePiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(renderingHints6);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        java.lang.Object obj5 = multiplePiePlot2.clone();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("Other", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.title.Title title8 = null;
        try {
            jFreeChart6.addSubtitle(10, title8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle3.setHorizontalAlignment(horizontalAlignment4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendTitle3.getLegendItemGraphicAnchor();
        boolean boolean7 = color1.equals((java.lang.Object) rectangleAnchor6);
        try {
            java.awt.geom.Point2D point2D8 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(4.0d, (double) 100.0f, (double) (-1), 1.0d, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Other");
        double double2 = textTitle1.getContentYOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Comparable comparable3 = multiplePiePlot1.getAggregatedItemsKey();
        java.awt.Color color4 = java.awt.Color.black;
        java.awt.Color color5 = color4.darker();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = multiplePiePlot1.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset8 = multiplePiePlot1.getDataset();
        java.awt.Color color9 = java.awt.Color.gray;
        multiplePiePlot1.setBackgroundPaint((java.awt.Paint) color9);
        try {
            multiplePiePlot1.setBackgroundImageAlpha((float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass5 = rectangleInsets4.getClass();
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        double double8 = legendTitle7.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle7.getPadding();
        legendTitle7.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle7.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        double double15 = legendTitle14.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle14.getPadding();
        java.awt.geom.Rectangle2D rectangle2D17 = legendTitle14.getBounds();
        rectangleInsets12.trim(rectangle2D17);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets4.createAdjustedRectangle(rectangle2D17, lengthAdjustmentType19, lengthAdjustmentType20);
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        double double24 = legendTitle23.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle23.getPadding();
        java.awt.geom.Rectangle2D rectangle2D26 = legendTitle23.getBounds();
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets4.createInsetRectangle(rectangle2D26, false, true);
        try {
            multiplePiePlot1.drawOutline(graphics2D3, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        multiplePiePlot1.markerChanged(markerChangeEvent4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = multiplePiePlot1.getInsets();
        multiplePiePlot1.setForegroundAlpha((float) (-254));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass8 = rectangleInsets7.getClass();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        legendTitle10.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle10.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        double double18 = legendTitle17.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle17.getPadding();
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle17.getBounds();
        rectangleInsets15.trim(rectangle2D20);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets7.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType22, lengthAdjustmentType23);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets7.createInsetRectangle(rectangle2D29, false, true);
        legendTitle1.setBounds(rectangle2D29);
        java.awt.Paint paint34 = null;
        try {
            legendTitle1.setItemPaint(paint34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Object obj4 = multiplePiePlot1.clone();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        multiplePiePlot1.setDataset(categoryDataset5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass10 = rectangleInsets9.getClass();
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendTitle12.getPadding();
        legendTitle12.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle12.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle19.getBounds();
        rectangleInsets17.trim(rectangle2D22);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets9.createAdjustedRectangle(rectangle2D22, lengthAdjustmentType24, lengthAdjustmentType25);
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        double double29 = legendTitle28.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = legendTitle28.getPadding();
        java.awt.geom.Rectangle2D rectangle2D31 = legendTitle28.getBounds();
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets9.createInsetRectangle(rectangle2D31, false, true);
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        double double37 = legendTitle36.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle36.getPadding();
        legendTitle36.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource41 = null;
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle(legendItemSource41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle42.setHorizontalAlignment(horizontalAlignment43);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = legendTitle42.getLegendItemGraphicAnchor();
        legendTitle36.setLegendItemGraphicAnchor(rectangleAnchor45);
        java.awt.geom.Point2D point2D47 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D31, rectangleAnchor45);
        org.jfree.chart.plot.PlotState plotState48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        try {
            multiplePiePlot1.draw(graphics2D7, rectangle2D8, point2D47, plotState48, plotRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(point2D47);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("TableOrder.BY_COLUMN", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Comparable comparable3 = multiplePiePlot1.getAggregatedItemsKey();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset4);
        multiplePiePlot1.setParent((org.jfree.chart.plot.Plot) multiplePiePlot5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        multiplePiePlot1.removeChangeListener(plotChangeListener7);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        double double14 = rectangleInsets6.extendHeight((double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getTextAlignment();
        textTitle5.setWidth((double) 100L);
        textTitle5.setText("");
        java.lang.String str11 = textTitle5.getText();
        org.jfree.chart.util.ObjectList objectList12 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj14 = objectList12.get(1);
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle5, obj14);
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement17 = blockContainer16.getArrangement();
        org.jfree.chart.block.BlockFrame blockFrame18 = blockContainer16.getFrame();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        try {
            org.jfree.chart.util.Size2D size2D21 = columnArrangement4.arrange(blockContainer16, graphics2D19, rectangleConstraint20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(arrangement17);
        org.junit.Assert.assertNotNull(blockFrame18);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        multiplePiePlot1.notifyListeners(plotChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        java.awt.Paint paint7 = multiplePiePlot6.getAggregatedItemsPaint();
        multiplePiePlot1.setParent((org.jfree.chart.plot.Plot) multiplePiePlot6);
        java.awt.Image image9 = multiplePiePlot1.getBackgroundImage();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(image9);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset(0.0d);
        double double4 = rectangleInsets0.calculateLeftOutset((double) (short) 10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int2 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) (byte) 1);
        try {
            java.lang.Number number5 = defaultKeyedValues2D0.getValue((java.lang.Comparable) "RectangleEdge.LEFT", (java.lang.Comparable) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        multiplePiePlot0.setBackgroundAlpha((float) (byte) 10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        try {
            java.awt.image.BufferedImage bufferedImage10 = jFreeChart5.createBufferedImage((int) (short) 100, 10, 0, chartRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("Multiple Pie Plot", "hi!", "Multiple Pie Plot", "Other");
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        titleChangeEvent3.setChart(jFreeChart4);
        java.lang.Object obj6 = titleChangeEvent3.getSource();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        java.awt.Paint paint10 = multiplePiePlot9.getNoDataMessagePaint();
        java.awt.Paint paint11 = multiplePiePlot9.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot9);
        titleChangeEvent3.setChart(jFreeChart12);
        java.lang.String str14 = titleChangeEvent3.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getColumnKey(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle2.setHorizontalAlignment(horizontalAlignment3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle2.getLegendItemGraphicAnchor();
        boolean boolean6 = color0.equals((java.lang.Object) rectangleAnchor5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle8);
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        titleChangeEvent10.setChart(jFreeChart11);
        boolean boolean13 = rectangleAnchor5.equals((java.lang.Object) jFreeChart11);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image4 = projectInfo3.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("ChartChangeEventType.NEW_DATASET", "", "Other", image4, "", "Multiple Pie Plot", "Multiple Pie Plot");
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo8.getOptionalLibraries();
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(image4);
        org.junit.Assert.assertNotNull(libraryArray9);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("RectangleEdge.LEFT");
        java.lang.Object obj2 = datasetGroup1.clone();
        java.lang.Object obj3 = null;
        boolean boolean4 = datasetGroup1.equals(obj3);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        java.lang.String str17 = chartEntity7.getShapeType();
        java.lang.Object obj18 = chartEntity7.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "rect" + "'", str17.equals("rect"));
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.lang.String str4 = rectangleInsets3.toString();
        double double5 = rectangleInsets3.getLeft();
        double double7 = rectangleInsets3.calculateRightOutset((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        java.lang.String str17 = chartEntity7.getShapeType();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        legendTitle19.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle19.getPadding();
        boolean boolean25 = chartEntity7.equals((java.lang.Object) rectangleInsets24);
        java.lang.String str26 = chartEntity7.getToolTipText();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "rect" + "'", str17.equals("rect"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.lang.String str11 = rectangleInsets10.toString();
        legendTitle1.setMargin(rectangleInsets10);
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        double double15 = legendTitle14.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle14.getPadding();
        legendTitle14.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = legendTitle14.getLegendItemGraphicEdge();
        boolean boolean20 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge19);
        legendTitle1.setPosition(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str11.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            multiplePiePlot1.setInsets(rectangleInsets4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        defaultKeyedValues2D1.addValue((java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 1.0f);
        try {
            java.lang.Comparable comparable10 = defaultKeyedValues2D1.getColumnKey((-254));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        java.awt.Color color1 = java.awt.Color.BLACK;
        boolean boolean2 = tableOrder0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setInfo("");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleEdge.LEFT");
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle7.setHorizontalAlignment(horizontalAlignment8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendTitle7.getLegendItemGraphicAnchor();
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = null;
        try {
            legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' point.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle9.getPadding();
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle9.getBounds();
        java.awt.Paint paint13 = legendTitle9.getItemPaint();
        double double14 = legendTitle9.getContentXOffset();
        boolean boolean15 = rectangleEdge7.equals((java.lang.Object) legendTitle9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass22 = rectangleInsets21.getClass();
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource23);
        double double25 = legendTitle24.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle24.getPadding();
        legendTitle24.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle24.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle(legendItemSource30);
        double double32 = legendTitle31.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendTitle31.getPadding();
        java.awt.geom.Rectangle2D rectangle2D34 = legendTitle31.getBounds();
        rectangleInsets29.trim(rectangle2D34);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets21.createAdjustedRectangle(rectangle2D34, lengthAdjustmentType36, lengthAdjustmentType37);
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color18.createContext(colorModel19, rectangle20, rectangle2D38, affineTransform39, renderingHints40);
        try {
            jFreeChart14.setTextAntiAlias((java.lang.Object) paintContext41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.awt.ColorPaintContext@386b3d9a incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(paintContext41);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.distributeLabels((double) 2, (double) 1);
        pieLabelDistributor1.distributeLabels((double) 255, (double) '#');
        pieLabelDistributor1.distributeLabels((double) (byte) 0, 4.0d);
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord12 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        double double8 = rectangleInsets6.calculateTopInset((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("java.awt.Color[r=0,g=0,b=0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        titleChangeEvent3.setType(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Comparable comparable3 = multiplePiePlot1.getAggregatedItemsKey();
        java.awt.Color color4 = java.awt.Color.black;
        java.awt.Color color5 = color4.darker();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = multiplePiePlot1.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset8 = multiplePiePlot1.getDataset();
        org.jfree.chart.plot.Plot plot9 = multiplePiePlot1.getParent();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNull(plot9);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getTextAlignment();
        textTitle5.setWidth((double) 100L);
        textTitle5.setText("");
        java.lang.String str11 = textTitle5.getText();
        org.jfree.chart.util.ObjectList objectList12 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj14 = objectList12.get(1);
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle5, obj14);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle16.getTextAlignment();
        textTitle16.setWidth((double) 100L);
        textTitle16.setText("");
        java.lang.String str22 = textTitle16.getText();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color27);
        textTitle16.setPaint((java.awt.Paint) color27);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset30);
        java.awt.Paint paint32 = multiplePiePlot31.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        multiplePiePlot31.notifyListeners(plotChangeEvent33);
        org.jfree.chart.JFreeChart jFreeChart35 = multiplePiePlot31.getPieChart();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle16, (java.lang.Object) multiplePiePlot31);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = multiplePiePlot31.getDrawingSupplier();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(jFreeChart35);
        org.junit.Assert.assertNotNull(drawingSupplier37);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Comparable comparable3 = null;
        try {
            defaultKeyedValues2D0.setValue((java.lang.Number) (short) 1, (java.lang.Comparable) 0.08d, comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle1.setHorizontalAlignment(horizontalAlignment2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle1.addChangeListener(titleChangeListener5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass9 = rectangleInsets8.getClass();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getPadding();
        legendTitle11.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle11.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        double double19 = legendTitle18.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle18.getPadding();
        java.awt.geom.Rectangle2D rectangle2D21 = legendTitle18.getBounds();
        rectangleInsets16.trim(rectangle2D21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets8.createAdjustedRectangle(rectangle2D21, lengthAdjustmentType23, lengthAdjustmentType24);
        java.awt.Color color26 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder(rectangleInsets8, (java.awt.Paint) color26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass29 = rectangleInsets28.getClass();
        org.jfree.chart.LegendItemSource legendItemSource30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle(legendItemSource30);
        double double32 = legendTitle31.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendTitle31.getPadding();
        legendTitle31.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle31.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource37 = null;
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle(legendItemSource37);
        double double39 = legendTitle38.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = legendTitle38.getPadding();
        java.awt.geom.Rectangle2D rectangle2D41 = legendTitle38.getBounds();
        rectangleInsets36.trim(rectangle2D41);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType43 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets28.createAdjustedRectangle(rectangle2D41, lengthAdjustmentType43, lengthAdjustmentType44);
        org.jfree.chart.LegendItemSource legendItemSource46 = null;
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle(legendItemSource46);
        double double48 = legendTitle47.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = legendTitle47.getPadding();
        java.awt.geom.Rectangle2D rectangle2D50 = legendTitle47.getBounds();
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets28.createInsetRectangle(rectangle2D50, false, true);
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets8.createInsetRectangle(rectangle2D50, false, true);
        try {
            legendTitle1.draw(graphics2D7, rectangle2D50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangle2D56);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        boolean boolean2 = objectList0.equals((java.lang.Object) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.lang.Object obj3 = objectList0.clone();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color8);
        java.awt.Paint paint10 = blockBorder9.getPaint();
        boolean boolean11 = objectList0.equals((java.lang.Object) blockBorder9);
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        legendTitle13.setLegendItemGraphicPadding(rectangleInsets14);
        boolean boolean16 = blockBorder9.equals((java.lang.Object) legendTitle13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        defaultKeyedValues2D1.addValue((java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 1.0f);
        java.lang.Object obj9 = defaultKeyedValues2D1.clone();
        try {
            java.lang.Number number12 = defaultKeyedValues2D1.getValue(15, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        java.awt.Color color17 = java.awt.Color.pink;
        legendTitle9.setItemPaint((java.awt.Paint) color17);
        org.jfree.chart.block.BlockContainer blockContainer19 = legendTitle9.getItemContainer();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(blockContainer19);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        double double5 = legendTitle4.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle4.getPadding();
        java.awt.geom.Rectangle2D rectangle2D7 = legendTitle4.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D7, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.block.BlockContainer blockContainer15 = null;
        legendTitle12.setWrapper(blockContainer15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle12.setItemPaint((java.awt.Paint) color17);
        boolean boolean19 = chartEntity10.equals((java.lang.Object) legendTitle12);
        java.lang.String str20 = chartEntity10.getShapeType();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        double double23 = legendTitle22.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle22.getPadding();
        legendTitle22.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle22.getPadding();
        boolean boolean28 = chartEntity10.equals((java.lang.Object) rectangleInsets27);
        multiplePiePlot1.setInsets(rectangleInsets27, true);
        java.awt.Image image31 = multiplePiePlot1.getBackgroundImage();
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = textTitle32.getTextAlignment();
        textTitle32.setWidth((double) 100L);
        textTitle32.setText("");
        java.lang.String str38 = textTitle32.getText();
        java.awt.Color color43 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder44 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color43);
        textTitle32.setPaint((java.awt.Paint) color43);
        multiplePiePlot1.setOutlinePaint((java.awt.Paint) color43);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rect" + "'", str20.equals("rect"));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(image31);
        org.junit.Assert.assertNotNull(horizontalAlignment33);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle17 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        boolean boolean18 = chartEntity7.equals((java.lang.Object) pieLabelLinkStyle17);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        textTitle0.setWidth((double) 100L);
        java.lang.Object obj4 = textTitle0.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        textTitle0.setFont(font2);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(255, 8, 255);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        java.awt.Color color17 = java.awt.Color.pink;
        legendTitle9.setItemPaint((java.awt.Paint) color17);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color23);
        java.awt.Paint paint25 = blockBorder24.getPaint();
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        boolean boolean27 = blockBorder24.equals((java.lang.Object) shape26);
        java.awt.Paint paint28 = blockBorder24.getPaint();
        legendTitle9.setFrame((org.jfree.chart.block.BlockFrame) blockBorder24);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass8 = rectangleInsets7.getClass();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        legendTitle10.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle10.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        double double18 = legendTitle17.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle17.getPadding();
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle17.getBounds();
        rectangleInsets15.trim(rectangle2D20);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets7.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType22, lengthAdjustmentType23);
        legendTitle1.setPadding(rectangleInsets7);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass27 = rectangleInsets26.getClass();
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = textTitle28.getTextAlignment();
        java.awt.Paint paint30 = textTitle28.getPaint();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle28.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets26.createOutsetRectangle(rectangle2D31);
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets7.createOutsetRectangle(rectangle2D31);
        double double35 = rectangleInsets7.calculateTopOutset(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        java.awt.Paint paint2 = textTitle0.getPaint();
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean4 = textTitle0.equals((java.lang.Object) strokeArray3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment6, (double) '#', 0.0d);
        textTitle0.setHorizontalAlignment(horizontalAlignment5);
        textTitle0.setExpandToFitSpace(true);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        java.lang.String str17 = chartEntity7.getShapeType();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        legendTitle19.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle19.getPadding();
        boolean boolean25 = chartEntity7.equals((java.lang.Object) rectangleInsets24);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle26.getBounds();
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets24.createInsetRectangle(rectangle2D27);
        double double29 = rectangleInsets24.getRight();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "rect" + "'", str17.equals("rect"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "hi!");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        int int1 = color0.getTransparency();
        int int2 = color0.getRGB();
        org.jfree.chart.ui.Contributor contributor5 = new org.jfree.chart.ui.Contributor("hi!", "hi!");
        boolean boolean6 = color0.equals((java.lang.Object) contributor5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-48897) + "'", int2 == (-48897));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("Other", "RectangleEdge.LEFT", "TableOrder.BY_COLUMN", "");
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int3 = java.awt.Color.HSBtoRGB((-1.0f), (float) (short) 10, (float) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-452) + "'", int3 == (-452));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle3.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle10.getBounds();
        rectangleInsets8.trim(rectangle2D13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets0.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType15, lengthAdjustmentType16);
        java.awt.Color color18 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color18);
        java.awt.Color color20 = color18.brighter();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        int int5 = defaultKeyedValues2D1.getColumnCount();
        try {
            defaultKeyedValues2D1.removeRow((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle8.setLegendItemGraphicAnchor(rectangleAnchor12);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle15.getPadding();
        java.lang.String str18 = rectangleInsets17.toString();
        legendTitle8.setMargin(rectangleInsets17);
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass24 = rectangleInsets23.getClass();
        double double25 = rectangleInsets23.getLeft();
        double double27 = rectangleInsets23.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass29 = rectangleInsets28.getClass();
        org.jfree.chart.LegendItemSource legendItemSource30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle(legendItemSource30);
        double double32 = legendTitle31.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendTitle31.getPadding();
        legendTitle31.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle31.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource37 = null;
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle(legendItemSource37);
        double double39 = legendTitle38.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = legendTitle38.getPadding();
        java.awt.geom.Rectangle2D rectangle2D41 = legendTitle38.getBounds();
        rectangleInsets36.trim(rectangle2D41);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType43 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets28.createAdjustedRectangle(rectangle2D41, lengthAdjustmentType43, lengthAdjustmentType44);
        org.jfree.chart.LegendItemSource legendItemSource46 = null;
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle(legendItemSource46);
        double double48 = legendTitle47.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = legendTitle47.getPadding();
        java.awt.geom.Rectangle2D rectangle2D50 = legendTitle47.getBounds();
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets28.createInsetRectangle(rectangle2D50, false, true);
        org.jfree.chart.LegendItemSource legendItemSource54 = null;
        org.jfree.chart.title.LegendTitle legendTitle55 = new org.jfree.chart.title.LegendTitle(legendItemSource54);
        double double56 = legendTitle55.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = legendTitle55.getPadding();
        legendTitle55.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource60 = null;
        org.jfree.chart.title.LegendTitle legendTitle61 = new org.jfree.chart.title.LegendTitle(legendItemSource60);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment62 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle61.setHorizontalAlignment(horizontalAlignment62);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor64 = legendTitle61.getLegendItemGraphicAnchor();
        legendTitle55.setLegendItemGraphicAnchor(rectangleAnchor64);
        java.awt.geom.Point2D point2D66 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D50, rectangleAnchor64);
        java.awt.geom.Rectangle2D rectangle2D69 = rectangleInsets23.createOutsetRectangle(rectangle2D50, false, true);
        boolean boolean70 = rectangleAnchor21.equals((java.lang.Object) rectangle2D69);
        org.jfree.data.category.CategoryDataset categoryDataset72 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot73 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset72);
        java.awt.Paint paint74 = multiplePiePlot73.getNoDataMessagePaint();
        java.awt.Paint paint75 = multiplePiePlot73.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart76 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot73);
        double double77 = multiplePiePlot73.getLimit();
        boolean boolean78 = rectangleAnchor21.equals((java.lang.Object) double77);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str18.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(horizontalAlignment62);
        org.junit.Assert.assertNotNull(rectangleAnchor64);
        org.junit.Assert.assertNotNull(point2D66);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getInfo();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        java.lang.Object obj2 = null;
        boolean boolean3 = projectInfo0.equals(obj2);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("java.awt.Color[r=0,g=0,b=0]", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle1.setHorizontalAlignment(horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment2, verticalAlignment4, (double) (short) 10, (double) 10.0f);
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", image11, "hi!", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D16 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list17 = defaultKeyedValues2D16.getColumnKeys();
        projectInfo15.setContributors(list17);
        boolean boolean19 = verticalAlignment4.equals((java.lang.Object) list17);
        java.lang.String str20 = verticalAlignment4.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str20.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        java.awt.Paint paint4 = multiplePiePlot3.getNoDataMessagePaint();
        java.awt.Paint paint5 = multiplePiePlot3.getNoDataMessagePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = multiplePiePlot3.getDrawingSupplier();
        boolean boolean7 = unitType1.equals((java.lang.Object) multiplePiePlot3);
        java.lang.Object obj8 = multiplePiePlot3.clone();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Other", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass8 = rectangleInsets7.getClass();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        legendTitle10.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle10.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        double double18 = legendTitle17.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle17.getPadding();
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle17.getBounds();
        rectangleInsets15.trim(rectangle2D20);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets7.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType22, lengthAdjustmentType23);
        legendTitle1.setPadding(rectangleInsets7);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass27 = rectangleInsets26.getClass();
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = textTitle28.getTextAlignment();
        java.awt.Paint paint30 = textTitle28.getPaint();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle28.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets26.createOutsetRectangle(rectangle2D31);
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets7.createOutsetRectangle(rectangle2D31);
        double double35 = rectangleInsets7.calculateRightOutset((double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        multiplePiePlot1.markerChanged(markerChangeEvent4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = multiplePiePlot1.getInsets();
        java.awt.Stroke stroke7 = multiplePiePlot1.getOutlineStroke();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) 0, (float) '#', (float) 0);
        multiplePiePlot1.setBackgroundPaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        jFreeChart5.setBackgroundImageAlignment((int) (short) 0);
        try {
            org.jfree.chart.title.Title title9 = jFreeChart5.getSubtitle(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        java.lang.String str2 = pieLabelDistributor1.toString();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        java.awt.Paint paint5 = legendTitle1.getItemPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle1.getPosition();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendTitle1.getLegendItemGraphicAnchor();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        titleChangeEvent11.setChart(jFreeChart12);
        java.lang.String str14 = titleChangeEvent11.toString();
        boolean boolean15 = chartEntity7.equals((java.lang.Object) titleChangeEvent11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.Paint paint6 = jFreeChart5.getBorderPaint();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        java.awt.Paint paint12 = legendTitle8.getItemPaint();
        double double13 = legendTitle8.getContentXOffset();
        jFreeChart5.removeSubtitle((org.jfree.chart.title.Title) legendTitle8);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle16.getTextAlignment();
        java.awt.Paint paint18 = textTitle16.getBackgroundPaint();
        org.jfree.chart.block.BlockFrame blockFrame19 = textTitle16.getFrame();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement24 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment20, verticalAlignment21, (double) '#', 0.0d);
        textTitle16.setVerticalAlignment(verticalAlignment21);
        jFreeChart5.addSubtitle((int) (byte) 1, (org.jfree.chart.title.Title) textTitle16);
        textTitle16.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(blockFrame19);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(verticalAlignment21);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle8.setLegendItemGraphicAnchor(rectangleAnchor12);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle15.getPadding();
        java.lang.String str18 = rectangleInsets17.toString();
        legendTitle8.setMargin(rectangleInsets17);
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass24 = rectangleInsets23.getClass();
        double double25 = rectangleInsets23.getLeft();
        double double27 = rectangleInsets23.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass29 = rectangleInsets28.getClass();
        org.jfree.chart.LegendItemSource legendItemSource30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle(legendItemSource30);
        double double32 = legendTitle31.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendTitle31.getPadding();
        legendTitle31.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle31.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource37 = null;
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle(legendItemSource37);
        double double39 = legendTitle38.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = legendTitle38.getPadding();
        java.awt.geom.Rectangle2D rectangle2D41 = legendTitle38.getBounds();
        rectangleInsets36.trim(rectangle2D41);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType43 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets28.createAdjustedRectangle(rectangle2D41, lengthAdjustmentType43, lengthAdjustmentType44);
        org.jfree.chart.LegendItemSource legendItemSource46 = null;
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle(legendItemSource46);
        double double48 = legendTitle47.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = legendTitle47.getPadding();
        java.awt.geom.Rectangle2D rectangle2D50 = legendTitle47.getBounds();
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets28.createInsetRectangle(rectangle2D50, false, true);
        org.jfree.chart.LegendItemSource legendItemSource54 = null;
        org.jfree.chart.title.LegendTitle legendTitle55 = new org.jfree.chart.title.LegendTitle(legendItemSource54);
        double double56 = legendTitle55.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = legendTitle55.getPadding();
        legendTitle55.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource60 = null;
        org.jfree.chart.title.LegendTitle legendTitle61 = new org.jfree.chart.title.LegendTitle(legendItemSource60);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment62 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle61.setHorizontalAlignment(horizontalAlignment62);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor64 = legendTitle61.getLegendItemGraphicAnchor();
        legendTitle55.setLegendItemGraphicAnchor(rectangleAnchor64);
        java.awt.geom.Point2D point2D66 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D50, rectangleAnchor64);
        java.awt.geom.Rectangle2D rectangle2D69 = rectangleInsets23.createOutsetRectangle(rectangle2D50, false, true);
        boolean boolean70 = rectangleAnchor21.equals((java.lang.Object) rectangle2D69);
        java.lang.String str71 = rectangleAnchor21.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str18.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(horizontalAlignment62);
        org.junit.Assert.assertNotNull(rectangleAnchor64);
        org.junit.Assert.assertNotNull(point2D66);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str71.equals("RectangleAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        java.lang.Object obj19 = jFreeChart14.clone();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        try {
            java.awt.image.BufferedImage bufferedImage24 = jFreeChart14.createBufferedImage(8, (int) (short) 1, (int) '4', chartRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (byte) -1, 2.08d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.lang.Object obj18 = legendTitle1.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle20.getTextAlignment();
        java.awt.Paint paint22 = textTitle20.getPaint();
        java.awt.Stroke[] strokeArray23 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean24 = textTitle20.equals((java.lang.Object) strokeArray23);
        jFreeChart14.addSubtitle((org.jfree.chart.title.Title) textTitle20);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        try {
            jFreeChart14.draw(graphics2D26, rectangle2D27, chartRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str1.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Multiple Pie Plot");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        try {
            java.text.AttributedString attributedString4 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset2, (java.lang.Comparable) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass6 = rectangleInsets5.getClass();
        double double7 = rectangleInsets5.getLeft();
        boolean boolean8 = columnArrangement4.equals((java.lang.Object) double7);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockContainer9.getPadding();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        try {
            org.jfree.chart.util.Size2D size2D13 = blockContainer9.arrange(graphics2D11, rectangleConstraint12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator8 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator9 = null;
        try {
            java.lang.String str10 = chartEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator8, uRLTagFragmentGenerator9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockContainer0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset13, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        pieSectionEntity19.setURLText("ChartEntity: tooltip = ");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer1, (java.lang.Object) 255);
        boolean boolean5 = blockContainer1.isEmpty();
        org.jfree.chart.block.Arrangement arrangement6 = blockContainer1.getArrangement();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color11);
        blockContainer1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder12);
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(arrangement6);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        java.awt.Paint paint2 = textTitle0.getBackgroundPaint();
        org.jfree.chart.block.BlockFrame blockFrame3 = textTitle0.getFrame();
        java.awt.Graphics2D graphics2D4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textTitle0.arrange(graphics2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(blockFrame3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        double double2 = rectangleInsets0.getLeft();
        double double4 = rectangleInsets0.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass6 = rectangleInsets5.getClass();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        legendTitle8.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle8.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle15.getPadding();
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle15.getBounds();
        rectangleInsets13.trim(rectangle2D18);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets5.createAdjustedRectangle(rectangle2D18, lengthAdjustmentType20, lengthAdjustmentType21);
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource23);
        double double25 = legendTitle24.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle24.getPadding();
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets5.createInsetRectangle(rectangle2D27, false, true);
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle(legendItemSource31);
        double double33 = legendTitle32.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle32.getPadding();
        legendTitle32.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource37 = null;
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle(legendItemSource37);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle38.setHorizontalAlignment(horizontalAlignment39);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = legendTitle38.getLegendItemGraphicAnchor();
        legendTitle32.setLegendItemGraphicAnchor(rectangleAnchor41);
        java.awt.geom.Point2D point2D43 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D27, rectangleAnchor41);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets0.createOutsetRectangle(rectangle2D27, false, true);
        double double48 = rectangleInsets0.calculateLeftOutset(10.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass50 = rectangleInsets49.getClass();
        org.jfree.chart.LegendItemSource legendItemSource51 = null;
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle(legendItemSource51);
        double double53 = legendTitle52.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = legendTitle52.getPadding();
        legendTitle52.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = legendTitle52.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource58 = null;
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle(legendItemSource58);
        double double60 = legendTitle59.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = legendTitle59.getPadding();
        java.awt.geom.Rectangle2D rectangle2D62 = legendTitle59.getBounds();
        rectangleInsets57.trim(rectangle2D62);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType64 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = rectangleInsets49.createAdjustedRectangle(rectangle2D62, lengthAdjustmentType64, lengthAdjustmentType65);
        java.awt.Color color67 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder68 = new org.jfree.chart.block.BlockBorder(rectangleInsets49, (java.awt.Paint) color67);
        double double70 = rectangleInsets49.calculateTopOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double73 = rectangleInsets71.trimWidth((double) 2);
        org.jfree.chart.LegendItemSource legendItemSource74 = null;
        org.jfree.chart.title.LegendTitle legendTitle75 = new org.jfree.chart.title.LegendTitle(legendItemSource74);
        org.jfree.chart.util.RectangleInsets rectangleInsets76 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass77 = rectangleInsets76.getClass();
        org.jfree.chart.LegendItemSource legendItemSource78 = null;
        org.jfree.chart.title.LegendTitle legendTitle79 = new org.jfree.chart.title.LegendTitle(legendItemSource78);
        double double80 = legendTitle79.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets81 = legendTitle79.getPadding();
        legendTitle79.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets84 = legendTitle79.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource85 = null;
        org.jfree.chart.title.LegendTitle legendTitle86 = new org.jfree.chart.title.LegendTitle(legendItemSource85);
        double double87 = legendTitle86.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets88 = legendTitle86.getPadding();
        java.awt.geom.Rectangle2D rectangle2D89 = legendTitle86.getBounds();
        rectangleInsets84.trim(rectangle2D89);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType91 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType92 = null;
        java.awt.geom.Rectangle2D rectangle2D93 = rectangleInsets76.createAdjustedRectangle(rectangle2D89, lengthAdjustmentType91, lengthAdjustmentType92);
        legendTitle75.setBounds(rectangle2D93);
        rectangleInsets71.trim(rectangle2D93);
        rectangleInsets49.trim(rectangle2D93);
        java.awt.geom.Rectangle2D rectangle2D99 = rectangleInsets0.createOutsetRectangle(rectangle2D93, false, false);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(point2D43);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.0d + "'", double70 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets76);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets81);
        org.junit.Assert.assertNotNull(rectangleInsets84);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets88);
        org.junit.Assert.assertNotNull(rectangle2D89);
        org.junit.Assert.assertNotNull(rectangle2D93);
        org.junit.Assert.assertNotNull(rectangle2D99);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Comparable comparable3 = multiplePiePlot1.getAggregatedItemsKey();
        java.awt.Color color4 = java.awt.Color.black;
        java.awt.Color color5 = color4.darker();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = multiplePiePlot1.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset8 = multiplePiePlot1.getDataset();
        java.awt.Color color9 = java.awt.Color.gray;
        multiplePiePlot1.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot1.getPieChart();
        org.jfree.chart.event.ChartChangeListener chartChangeListener12 = null;
        try {
            jFreeChart11.removeChangeListener(chartChangeListener12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(jFreeChart11);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key hi!");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        legendTitle1.setHeight((double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass11 = rectangleInsets10.getClass();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        double double14 = legendTitle13.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle13.getPadding();
        legendTitle13.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle13.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        double double21 = legendTitle20.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle20.getPadding();
        java.awt.geom.Rectangle2D rectangle2D23 = legendTitle20.getBounds();
        rectangleInsets18.trim(rectangle2D23);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets10.createAdjustedRectangle(rectangle2D23, lengthAdjustmentType25, lengthAdjustmentType26);
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle29.getPadding();
        java.awt.geom.Rectangle2D rectangle2D32 = legendTitle29.getBounds();
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets10.createInsetRectangle(rectangle2D32, false, true);
        rectangleInsets8.trim(rectangle2D32);
        legendTitle1.setPadding(rectangleInsets8);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = legendTitle1.getPosition();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = null;
        try {
            org.jfree.chart.util.Size2D size2D41 = legendTitle1.arrange(graphics2D39, rectangleConstraint40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        double double5 = legendTitle4.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle4);
        org.jfree.chart.block.BlockContainer blockContainer7 = null;
        legendTitle4.setWrapper(blockContainer7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle4.setItemPaint((java.awt.Paint) color9);
        double double11 = legendTitle4.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.awt.Paint paint15 = multiplePiePlot14.getNoDataMessagePaint();
        java.awt.Paint paint16 = multiplePiePlot14.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot14);
        jFreeChart17.setBackgroundImageAlignment((int) (short) 0);
        legendTitle4.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        java.awt.Stroke stroke21 = jFreeChart17.getBorderStroke();
        strokeMap0.put((java.lang.Comparable) '#', stroke21);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = legendTitle1.arrange(graphics2D6, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset6);
        java.awt.Paint paint8 = multiplePiePlot7.getNoDataMessagePaint();
        java.lang.Comparable comparable9 = multiplePiePlot7.getAggregatedItemsKey();
        java.awt.Color color10 = java.awt.Color.black;
        java.awt.Color color11 = color10.darker();
        multiplePiePlot7.setAggregatedItemsPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = multiplePiePlot7.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset14 = multiplePiePlot7.getDataset();
        java.awt.Color color15 = java.awt.Color.gray;
        multiplePiePlot7.setBackgroundPaint((java.awt.Paint) color15);
        org.jfree.chart.JFreeChart jFreeChart17 = multiplePiePlot7.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        java.awt.Paint paint20 = multiplePiePlot19.getAggregatedItemsPaint();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        double double23 = legendTitle22.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle22.getPadding();
        java.awt.geom.Rectangle2D rectangle2D25 = legendTitle22.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D25, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource29);
        double double31 = legendTitle30.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent32 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle30);
        org.jfree.chart.block.BlockContainer blockContainer33 = null;
        legendTitle30.setWrapper(blockContainer33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle30.setItemPaint((java.awt.Paint) color35);
        boolean boolean37 = chartEntity28.equals((java.lang.Object) legendTitle30);
        java.lang.String str38 = chartEntity28.getShapeType();
        org.jfree.chart.LegendItemSource legendItemSource39 = null;
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle(legendItemSource39);
        double double41 = legendTitle40.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = legendTitle40.getPadding();
        legendTitle40.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = legendTitle40.getPadding();
        boolean boolean46 = chartEntity28.equals((java.lang.Object) rectangleInsets45);
        multiplePiePlot19.setInsets(rectangleInsets45, true);
        java.awt.Image image49 = multiplePiePlot19.getBackgroundImage();
        java.awt.Font font50 = multiplePiePlot19.getNoDataMessageFont();
        multiplePiePlot7.setNoDataMessageFont(font50);
        legendTitle1.setItemFont(font50);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "Other" + "'", comparable9.equals("Other"));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(jFreeChart17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "rect" + "'", str38.equals("rect"));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(image49);
        org.junit.Assert.assertNotNull(font50);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset7);
        java.awt.Paint paint9 = multiplePiePlot8.getNoDataMessagePaint();
        java.awt.Paint paint10 = multiplePiePlot8.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot8);
        jFreeChart11.setBackgroundImageAlignment((int) (short) 0);
        multiplePiePlot2.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart11);
        java.lang.String str15 = multiplePiePlot2.getNoDataMessage();
        multiplePiePlot2.setLimit((double) 10L);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        java.lang.Class<?> wildcardClass2 = rectangleEdge0.getClass();
        boolean boolean3 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        double double1 = rotation0.getFactor();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image3 = projectInfo2.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image8 = projectInfo7.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo("ChartChangeEventType.NEW_DATASET", "", "Other", image8, "", "Multiple Pie Plot", "Multiple Pie Plot");
        projectInfo2.addLibrary((org.jfree.chart.ui.Library) projectInfo12);
        boolean boolean14 = rotation0.equals((java.lang.Object) projectInfo12);
        double double15 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertNotNull(image3);
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertNotNull(image8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = jFreeChart14.getPadding();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Comparable comparable3 = multiplePiePlot1.getAggregatedItemsKey();
        java.awt.Color color4 = java.awt.Color.black;
        java.awt.Color color5 = color4.darker();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = multiplePiePlot1.getDrawingSupplier();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = multiplePiePlot1.getLegendItems();
        java.awt.Paint paint9 = multiplePiePlot1.getBackgroundPaint();
        multiplePiePlot1.setForegroundAlpha((float) (short) 100);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment12, verticalAlignment13, (double) '#', 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass18 = rectangleInsets17.getClass();
        double double19 = rectangleInsets17.getLeft();
        boolean boolean20 = columnArrangement16.equals((java.lang.Object) double19);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement16);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockContainer21.getPadding();
        org.jfree.data.general.Dataset dataset23 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets22, dataset23);
        multiplePiePlot1.datasetChanged(datasetChangeEvent24);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Comparable comparable3 = multiplePiePlot1.getAggregatedItemsKey();
        java.awt.Color color4 = java.awt.Color.black;
        java.awt.Color color5 = color4.darker();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = multiplePiePlot1.getDrawingSupplier();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = multiplePiePlot1.getLegendItems();
        java.awt.Paint paint9 = null;
        multiplePiePlot1.setBackgroundPaint(paint9);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset13, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        pieSectionEntity19.setToolTipText("ChartEntity: tooltip = ");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot4.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Font font7 = multiplePiePlot4.getNoDataMessageFont();
        multiplePiePlot0.setNoDataMessageFont(font7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = multiplePiePlot0.getLegendItems();
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Comparable comparable1 = null;
        java.awt.Stroke stroke2 = null;
        try {
            strokeMap0.put(comparable1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getNumberFormat();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        java.awt.Paint paint5 = multiplePiePlot4.getNoDataMessagePaint();
        java.awt.Paint paint6 = multiplePiePlot4.getNoDataMessagePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        multiplePiePlot4.markerChanged(markerChangeEvent7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = multiplePiePlot4.getInsets();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int11 = color10.getGreen();
        multiplePiePlot4.setAggregatedItemsPaint((java.awt.Paint) color10);
        boolean boolean13 = standardPieSectionLabelGenerator1.equals((java.lang.Object) color10);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        try {
            java.text.AttributedString attributedString16 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset14, (java.lang.Comparable) "TableOrder.BY_COLUMN");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 128 + "'", int11 == 128);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        java.lang.String str2 = datasetGroup1.getID();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset13, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        java.lang.String str20 = pieSectionEntity19.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass22 = rectangleInsets21.getClass();
        double double23 = rectangleInsets21.getLeft();
        double double25 = rectangleInsets21.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass27 = rectangleInsets26.getClass();
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle29.getPadding();
        legendTitle29.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle29.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        double double37 = legendTitle36.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle36.getPadding();
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle36.getBounds();
        rectangleInsets34.trim(rectangle2D39);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets26.createAdjustedRectangle(rectangle2D39, lengthAdjustmentType41, lengthAdjustmentType42);
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        double double46 = legendTitle45.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = legendTitle45.getPadding();
        java.awt.geom.Rectangle2D rectangle2D48 = legendTitle45.getBounds();
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets26.createInsetRectangle(rectangle2D48, false, true);
        org.jfree.chart.LegendItemSource legendItemSource52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle(legendItemSource52);
        double double54 = legendTitle53.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = legendTitle53.getPadding();
        legendTitle53.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource58 = null;
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle(legendItemSource58);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment60 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle59.setHorizontalAlignment(horizontalAlignment60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = legendTitle59.getLegendItemGraphicAnchor();
        legendTitle53.setLegendItemGraphicAnchor(rectangleAnchor62);
        java.awt.geom.Point2D point2D64 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D48, rectangleAnchor62);
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets21.createOutsetRectangle(rectangle2D48, false, true);
        pieSectionEntity19.setArea((java.awt.Shape) rectangle2D67);
        java.awt.Shape shape69 = pieSectionEntity19.getArea();
        pieSectionEntity19.setURLText("");
        java.lang.String str72 = pieSectionEntity19.getShapeType();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PieSection: 255, -48897(10)" + "'", str20.equals("PieSection: 255, -48897(10)"));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(horizontalAlignment60);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(point2D64);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "rect" + "'", str72.equals("rect"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle1.setHorizontalAlignment(horizontalAlignment2);
        legendTitle1.setPadding((double) (short) 0, (double) (-1L), 0.0d, (double) (short) -1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = legendTitle1.getHorizontalAlignment();
        java.awt.Color color10 = java.awt.Color.YELLOW;
        legendTitle1.setItemPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        multiplePiePlot0.setOutlineVisible(false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        try {
            defaultKeyedValues2D1.removeColumn((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        java.awt.Paint paint4 = legendTitle1.getItemPaint();
        java.lang.Object obj5 = legendTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getMargin();
        double double8 = rectangleInsets6.trimHeight((double) 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list1 = defaultKeyedValues2D0.getColumnKeys();
        java.lang.Object obj2 = defaultKeyedValues2D0.clone();
        try {
            java.lang.Comparable comparable4 = defaultKeyedValues2D0.getRowKey((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getTextAlignment();
        textTitle5.setWidth((double) 100L);
        textTitle5.setText("");
        java.lang.String str11 = textTitle5.getText();
        org.jfree.chart.util.ObjectList objectList12 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj14 = objectList12.get(1);
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle5, obj14);
        java.awt.Paint paint16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        textTitle5.setBackgroundPaint(paint16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = null;
        try {
            org.jfree.chart.util.Size2D size2D20 = textTitle5.arrange(graphics2D18, rectangleConstraint19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        titleChangeEvent3.setChart(jFreeChart4);
        java.lang.Object obj6 = titleChangeEvent3.getSource();
        org.jfree.chart.JFreeChart jFreeChart7 = titleChangeEvent3.getChart();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(jFreeChart7);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        jFreeChart5.setBackgroundImageAlignment((int) (short) 0);
        java.awt.Stroke stroke8 = jFreeChart5.getBorderStroke();
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart5.getTitle();
        try {
            org.jfree.chart.plot.XYPlot xYPlot10 = jFreeChart5.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.MultiplePiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(textTitle9);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass9 = rectangleInsets8.getClass();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getPadding();
        legendTitle11.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle11.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        double double19 = legendTitle18.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle18.getPadding();
        java.awt.geom.Rectangle2D rectangle2D21 = legendTitle18.getBounds();
        rectangleInsets16.trim(rectangle2D21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets8.createAdjustedRectangle(rectangle2D21, lengthAdjustmentType23, lengthAdjustmentType24);
        org.jfree.chart.util.ObjectList objectList27 = new org.jfree.chart.util.ObjectList((int) (short) 100);
        try {
            java.lang.Object obj28 = legendTitle1.draw(graphics2D7, rectangle2D25, (java.lang.Object) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D25);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        java.awt.Paint paint2 = textTitle0.getPaint();
        java.awt.geom.Rectangle2D rectangle2D3 = textTitle0.getBounds();
        java.awt.Paint paint4 = textTitle0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleEdge.BOTTOM", "", "TableOrder.BY_COLUMN", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "java.awt.Color[r=0,g=0,b=0]");
        basicProjectInfo5.setLicenceName("ChartChangeEventType.NEW_DATASET");
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass6 = rectangleInsets5.getClass();
        double double7 = rectangleInsets5.getLeft();
        boolean boolean8 = columnArrangement4.equals((java.lang.Object) double7);
        columnArrangement4.clear();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame13 = legendTitle11.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray15 = new org.jfree.chart.LegendItemSource[] { legendItemSource14 };
        legendTitle11.setSources(legendItemSourceArray15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass18 = rectangleInsets17.getClass();
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        double double21 = legendTitle20.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle20.getPadding();
        legendTitle20.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle20.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        double double28 = legendTitle27.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle27.getPadding();
        java.awt.geom.Rectangle2D rectangle2D30 = legendTitle27.getBounds();
        rectangleInsets25.trim(rectangle2D30);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets17.createAdjustedRectangle(rectangle2D30, lengthAdjustmentType32, lengthAdjustmentType33);
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        double double37 = legendTitle36.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle36.getPadding();
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle36.getBounds();
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets17.createInsetRectangle(rectangle2D39, false, true);
        legendTitle11.setBounds(rectangle2D39);
        legendTitle11.setWidth((double) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double48 = rectangleInsets46.calculateRightInset((double) '#');
        legendTitle11.setLegendItemGraphicPadding(rectangleInsets46);
        org.jfree.chart.LegendItemSource legendItemSource50 = null;
        org.jfree.chart.title.LegendTitle legendTitle51 = new org.jfree.chart.title.LegendTitle(legendItemSource50);
        double double52 = legendTitle51.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = legendTitle51.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle51.setLegendItemGraphicAnchor(rectangleAnchor54);
        org.jfree.data.general.DatasetGroup datasetGroup57 = new org.jfree.data.general.DatasetGroup("RectangleEdge.LEFT");
        java.lang.Object obj58 = datasetGroup57.clone();
        boolean boolean59 = rectangleAnchor54.equals((java.lang.Object) datasetGroup57);
        org.jfree.chart.LegendItemSource legendItemSource60 = null;
        org.jfree.chart.title.LegendTitle legendTitle61 = new org.jfree.chart.title.LegendTitle(legendItemSource60);
        double double62 = legendTitle61.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent63 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle61);
        org.jfree.chart.block.BlockContainer blockContainer64 = null;
        legendTitle61.setWrapper(blockContainer64);
        java.awt.Color color66 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle61.setItemPaint((java.awt.Paint) color66);
        boolean boolean68 = datasetGroup57.equals((java.lang.Object) legendTitle61);
        columnArrangement4.add((org.jfree.chart.block.Block) legendTitle11, (java.lang.Object) datasetGroup57);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame13);
        org.junit.Assert.assertNotNull(legendItemSourceArray15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "hi!", image4, "", "hi!", "");
        java.util.List list9 = projectInfo8.getContributors();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass17 = rectangleInsets16.getClass();
        boolean boolean18 = basicProjectInfo15.equals((java.lang.Object) wildcardClass17);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo24 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass26 = rectangleInsets25.getClass();
        boolean boolean27 = basicProjectInfo24.equals((java.lang.Object) wildcardClass26);
        basicProjectInfo15.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
        projectInfo8.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo8);
        projectInfo8.setCopyright("{0}");
        org.junit.Assert.assertNull(list9);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        java.awt.Paint paint7 = multiplePiePlot6.getNoDataMessagePaint();
        java.lang.Comparable comparable8 = multiplePiePlot6.getAggregatedItemsKey();
        java.awt.Color color9 = java.awt.Color.black;
        java.awt.Color color10 = color9.darker();
        multiplePiePlot6.setAggregatedItemsPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = multiplePiePlot6.getDrawingSupplier();
        boolean boolean13 = columnArrangement4.equals((java.lang.Object) drawingSupplier12);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + "Other" + "'", comparable8.equals("Other"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass19 = rectangleInsets18.getClass();
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        double double22 = legendTitle21.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = legendTitle21.getPadding();
        legendTitle21.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle21.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        double double29 = legendTitle28.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = legendTitle28.getPadding();
        java.awt.geom.Rectangle2D rectangle2D31 = legendTitle28.getBounds();
        rectangleInsets26.trim(rectangle2D31);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets18.createAdjustedRectangle(rectangle2D31, lengthAdjustmentType33, lengthAdjustmentType34);
        java.awt.Color color36 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder37 = new org.jfree.chart.block.BlockBorder(rectangleInsets18, (java.awt.Paint) color36);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass39 = rectangleInsets38.getClass();
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        double double42 = legendTitle41.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = legendTitle41.getPadding();
        legendTitle41.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendTitle41.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        double double49 = legendTitle48.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = legendTitle48.getPadding();
        java.awt.geom.Rectangle2D rectangle2D51 = legendTitle48.getBounds();
        rectangleInsets46.trim(rectangle2D51);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType53 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = rectangleInsets38.createAdjustedRectangle(rectangle2D51, lengthAdjustmentType53, lengthAdjustmentType54);
        org.jfree.chart.LegendItemSource legendItemSource56 = null;
        org.jfree.chart.title.LegendTitle legendTitle57 = new org.jfree.chart.title.LegendTitle(legendItemSource56);
        double double58 = legendTitle57.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = legendTitle57.getPadding();
        java.awt.geom.Rectangle2D rectangle2D60 = legendTitle57.getBounds();
        java.awt.geom.Rectangle2D rectangle2D63 = rectangleInsets38.createInsetRectangle(rectangle2D60, false, true);
        java.awt.geom.Rectangle2D rectangle2D66 = rectangleInsets18.createInsetRectangle(rectangle2D60, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity69 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D60, "rect", "ChartChangeEventType.NEW_DATASET");
        try {
            legendTitle9.draw(graphics2D17, rectangle2D60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D66);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.distributeLabels((double) 2, (double) 1);
        pieLabelDistributor1.distributeLabels((double) 255, (double) '#');
        pieLabelDistributor1.distributeLabels((double) 0, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle3.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle10.getBounds();
        rectangleInsets8.trim(rectangle2D13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets0.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType15, lengthAdjustmentType16);
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle19.getBounds();
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets0.createInsetRectangle(rectangle2D22, false, true);
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        double double28 = legendTitle27.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle27.getPadding();
        legendTitle27.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle33.setHorizontalAlignment(horizontalAlignment34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = legendTitle33.getLegendItemGraphicAnchor();
        legendTitle27.setLegendItemGraphicAnchor(rectangleAnchor36);
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D22, rectangleAnchor36);
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D22);
        java.lang.String str40 = chartEntity39.getShapeCoords();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0,0,1,1" + "'", str40.equals("0,0,1,1"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "hi!", image4, "", "hi!", "");
        java.util.List list9 = projectInfo8.getContributors();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass17 = rectangleInsets16.getClass();
        boolean boolean18 = basicProjectInfo15.equals((java.lang.Object) wildcardClass17);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo24 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass26 = rectangleInsets25.getClass();
        boolean boolean27 = basicProjectInfo24.equals((java.lang.Object) wildcardClass26);
        basicProjectInfo15.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
        projectInfo8.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo8);
        java.lang.String str31 = projectInfo8.getCopyright();
        org.junit.Assert.assertNull(list9);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.Paint paint6 = jFreeChart5.getBorderPaint();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        java.awt.Paint paint12 = legendTitle8.getItemPaint();
        double double13 = legendTitle8.getContentXOffset();
        jFreeChart5.removeSubtitle((org.jfree.chart.title.Title) legendTitle8);
        java.awt.Paint paint15 = jFreeChart5.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot17 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset16);
        java.awt.Paint paint18 = multiplePiePlot17.getNoDataMessagePaint();
        java.awt.Paint paint19 = multiplePiePlot17.getNoDataMessagePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        multiplePiePlot17.markerChanged(markerChangeEvent20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = multiplePiePlot17.getInsets();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int24 = color23.getGreen();
        multiplePiePlot17.setAggregatedItemsPaint((java.awt.Paint) color23);
        jFreeChart5.setBackgroundPaint((java.awt.Paint) color23);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 128 + "'", int24 == 128);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendTitle1.getLegendItemGraphicAnchor();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        java.lang.Object obj5 = defaultKeyedValues2D1.clone();
        java.util.List list6 = defaultKeyedValues2D1.getRowKeys();
        try {
            java.lang.Comparable comparable8 = defaultKeyedValues2D1.getRowKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer1, (java.lang.Object) 255);
        java.lang.Object obj5 = null;
        boolean boolean6 = flowArrangement0.equals(obj5);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        blockContainer7.clear();
        java.util.List list9 = blockContainer7.getBlocks();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = null;
        try {
            org.jfree.chart.util.Size2D size2D12 = flowArrangement0.arrange(blockContainer7, graphics2D10, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        java.awt.Paint paint4 = legendTitle1.getItemPaint();
        java.lang.Object obj5 = legendTitle1.clone();
        double double6 = legendTitle1.getHeight();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image4 = projectInfo3.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("ChartChangeEventType.NEW_DATASET", "", "Other", image4, "", "Multiple Pie Plot", "Multiple Pie Plot");
        java.lang.String str9 = projectInfo8.getCopyright();
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(image4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle20.getTextAlignment();
        java.awt.Paint paint22 = textTitle20.getPaint();
        java.awt.Stroke[] strokeArray23 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean24 = textTitle20.equals((java.lang.Object) strokeArray23);
        jFreeChart14.addSubtitle((org.jfree.chart.title.Title) textTitle20);
        try {
            org.jfree.chart.plot.XYPlot xYPlot26 = jFreeChart14.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.MultiplePiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64 + "'", int2 == 64);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle3.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle10.getBounds();
        rectangleInsets8.trim(rectangle2D13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets0.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType15, lengthAdjustmentType16);
        double double19 = rectangleInsets0.calculateLeftInset((double) (byte) 10);
        double double21 = rectangleInsets0.calculateTopInset((double) 8);
        double double23 = rectangleInsets0.calculateLeftOutset(1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        multiplePiePlot1.axisChanged(axisChangeEvent2);
        java.lang.String str4 = multiplePiePlot1.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = multiplePiePlot1.getInsets();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Multiple Pie Plot" + "'", str4.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        defaultKeyedValues2D1.addValue((java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 1.0f);
        java.util.List list9 = defaultKeyedValues2D1.getColumnKeys();
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str1.equals("HorizontalAlignment.RIGHT"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle1.getLegendItemGraphicLocation();
        boolean boolean6 = rectangleAnchor4.equals((java.lang.Object) "HorizontalAlignment.RIGHT");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Color color0 = java.awt.Color.lightGray;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        float[] floatArray4 = new float[] { (short) 10, 15, 10 };
        try {
            float[] floatArray5 = color0.getComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        boolean boolean3 = multiplePiePlot1.isSubplot();
        boolean boolean4 = multiplePiePlot1.isSubplot();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle3.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle10.getBounds();
        rectangleInsets8.trim(rectangle2D13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets0.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType15, lengthAdjustmentType16);
        java.awt.Color color18 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color18);
        double double21 = rectangleInsets0.calculateRightInset((double) (-452));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color5);
        boolean boolean7 = projectInfo0.equals((java.lang.Object) 0.0d);
        projectInfo0.setLicenceName("VerticalAlignment.CENTER");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        multiplePiePlot1.markerChanged(markerChangeEvent4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = multiplePiePlot1.getInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int8 = color7.getGreen();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color7);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = multiplePiePlot1.getInsets();
        float float11 = multiplePiePlot1.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 128 + "'", int8 == 128);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        chartEntity7.setURLText("");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        textTitle0.setWidth((double) 100L);
        textTitle0.setText("");
        java.lang.String str6 = textTitle0.getText();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent7 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "hi!", image4, "", "hi!", "");
        java.util.List list9 = projectInfo8.getContributors();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass17 = rectangleInsets16.getClass();
        boolean boolean18 = basicProjectInfo15.equals((java.lang.Object) wildcardClass17);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo24 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass26 = rectangleInsets25.getClass();
        boolean boolean27 = basicProjectInfo24.equals((java.lang.Object) wildcardClass26);
        basicProjectInfo15.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
        projectInfo8.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo8);
        java.util.List list31 = projectInfo8.getContributors();
        org.junit.Assert.assertNull(list9);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(list31);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        double double5 = legendTitle4.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle4.getPadding();
        java.awt.geom.Rectangle2D rectangle2D7 = legendTitle4.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D7, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.block.BlockContainer blockContainer15 = null;
        legendTitle12.setWrapper(blockContainer15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle12.setItemPaint((java.awt.Paint) color17);
        boolean boolean19 = chartEntity10.equals((java.lang.Object) legendTitle12);
        java.lang.String str20 = chartEntity10.getShapeType();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        double double23 = legendTitle22.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle22.getPadding();
        legendTitle22.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle22.getPadding();
        boolean boolean28 = chartEntity10.equals((java.lang.Object) rectangleInsets27);
        multiplePiePlot1.setInsets(rectangleInsets27, true);
        multiplePiePlot1.setLimit((double) 10.0f);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rect" + "'", str20.equals("rect"));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.08d, (double) 8);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset6);
        java.awt.Paint paint8 = multiplePiePlot7.getAggregatedItemsPaint();
        boolean boolean9 = multiplePiePlot7.isSubplot();
        boolean boolean10 = columnArrangement4.equals((java.lang.Object) boolean9);
        columnArrangement4.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass6 = rectangleInsets5.getClass();
        double double7 = rectangleInsets5.getLeft();
        boolean boolean8 = columnArrangement4.equals((java.lang.Object) double7);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame13 = legendTitle11.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray15 = new org.jfree.chart.LegendItemSource[] { legendItemSource14 };
        legendTitle11.setSources(legendItemSourceArray15);
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        double double19 = legendTitle18.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle18.getPadding();
        java.awt.geom.Rectangle2D rectangle2D21 = legendTitle18.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor22);
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        double double26 = legendTitle25.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle25.getPadding();
        java.lang.String str28 = rectangleInsets27.toString();
        legendTitle18.setMargin(rectangleInsets27);
        legendTitle11.setLegendItemGraphicPadding(rectangleInsets27);
        java.lang.Object obj31 = null;
        blockContainer9.add((org.jfree.chart.block.Block) legendTitle11, obj31);
        org.jfree.chart.ui.Contributor contributor35 = new org.jfree.chart.ui.Contributor("", "hi!");
        java.lang.Class<?> wildcardClass36 = contributor35.getClass();
        boolean boolean37 = blockContainer9.equals((java.lang.Object) wildcardClass36);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = null;
        try {
            org.jfree.chart.util.Size2D size2D40 = blockContainer9.arrange(graphics2D38, rectangleConstraint39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame13);
        org.junit.Assert.assertNotNull(legendItemSourceArray15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str28.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        defaultKeyedValues2D1.addValue((java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 1.0f);
        java.lang.Object obj9 = defaultKeyedValues2D1.clone();
        int int10 = defaultKeyedValues2D1.getColumnCount();
        try {
            java.lang.Number number13 = defaultKeyedValues2D1.getValue((java.lang.Comparable) "rect", (java.lang.Comparable) "0,0,1,1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 0,0,1,1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        try {
            java.awt.Color color1 = java.awt.Color.decode("HorizontalAlignment.RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HorizontalAlignment.RIGHT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.lang.String str4 = legendTitle1.getID();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle6.getTextAlignment();
        java.awt.Paint paint8 = textTitle6.getPaint();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle6.getBounds();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment10, verticalAlignment11, (double) '#', 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass16 = rectangleInsets15.getClass();
        double double17 = rectangleInsets15.getLeft();
        boolean boolean18 = columnArrangement14.equals((java.lang.Object) double17);
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement14);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = blockContainer19.getPadding();
        blockContainer19.clear();
        try {
            java.lang.Object obj22 = legendTitle1.draw(graphics2D5, rectangle2D9, (java.lang.Object) blockContainer19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", image3, "hi!", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        projectInfo7.setCopyright("RectangleEdge.LEFT");
        java.lang.String str10 = projectInfo7.getCopyright();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleEdge.LEFT" + "'", str10.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        java.lang.String str17 = chartEntity7.getShapeType();
        java.lang.String str18 = chartEntity7.getToolTipText();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "rect" + "'", str17.equals("rect"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        multiplePiePlot1.markerChanged(markerChangeEvent4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = multiplePiePlot1.getInsets();
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets6.getUnitType();
        java.lang.String str8 = unitType7.toString();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UnitType.ABSOLUTE" + "'", str8.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.trimWidth((double) 2);
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass6 = rectangleInsets5.getClass();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        legendTitle8.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle8.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle15.getPadding();
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle15.getBounds();
        rectangleInsets13.trim(rectangle2D18);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets5.createAdjustedRectangle(rectangle2D18, lengthAdjustmentType20, lengthAdjustmentType21);
        legendTitle4.setBounds(rectangle2D22);
        rectangleInsets0.trim(rectangle2D22);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        legendTitle26.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = legendTitle26.getLegendItemGraphicEdge();
        double double32 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D22, rectangleEdge31);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 2.0d + "'", double32 == 2.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getNumberFormat();
        java.lang.Object obj3 = standardPieSectionLabelGenerator1.clone();
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        multiplePiePlot1.markerChanged(markerChangeEvent4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = multiplePiePlot1.getInsets();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int8 = color7.getGreen();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color7);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = multiplePiePlot1.getInsets();
        java.awt.Color color11 = java.awt.Color.GREEN;
        multiplePiePlot1.setBackgroundPaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 128 + "'", int8 == 128);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        projectInfo0.setInfo("UnitType.ABSOLUTE");
        java.lang.String str4 = projectInfo0.getName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart" + "'", str4.equals("JFreeChart"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        java.awt.Paint paint5 = legendTitle1.getItemPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle1.getPosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle1.getLegendItemGraphicEdge();
        java.awt.Graphics2D graphics2D8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = legendTitle1.arrange(graphics2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        java.awt.Paint paint4 = multiplePiePlot3.getNoDataMessagePaint();
        java.awt.Paint paint5 = multiplePiePlot3.getNoDataMessagePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = multiplePiePlot3.getDrawingSupplier();
        boolean boolean7 = unitType1.equals((java.lang.Object) multiplePiePlot3);
        multiplePiePlot3.setOutlineVisible(false);
        java.lang.Object obj10 = multiplePiePlot3.clone();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        java.lang.Class<?> wildcardClass3 = legendTitle1.getClass();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = legendTitle1.arrange(graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        float float3 = multiplePiePlot1.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.lang.String str4 = legendTitle1.getID();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            legendTitle1.setBounds(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getURLText();
        textTitle0.setText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.lang.String str4 = textTitle0.getText();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.08d, (double) 8);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.lang.String str6 = blockContainer5.getID();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        double double5 = legendTitle4.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle4.getPadding();
        java.awt.geom.Rectangle2D rectangle2D7 = legendTitle4.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D7, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.block.BlockContainer blockContainer15 = null;
        legendTitle12.setWrapper(blockContainer15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle12.setItemPaint((java.awt.Paint) color17);
        boolean boolean19 = chartEntity10.equals((java.lang.Object) legendTitle12);
        java.lang.String str20 = chartEntity10.getShapeType();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        double double23 = legendTitle22.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle22.getPadding();
        legendTitle22.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle22.getPadding();
        boolean boolean28 = chartEntity10.equals((java.lang.Object) rectangleInsets27);
        multiplePiePlot1.setInsets(rectangleInsets27, true);
        boolean boolean31 = multiplePiePlot1.isSubplot();
        java.awt.Paint paint32 = multiplePiePlot1.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rect" + "'", str20.equals("rect"));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        java.awt.Paint paint4 = multiplePiePlot3.getNoDataMessagePaint();
        java.awt.Paint paint5 = multiplePiePlot3.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        java.awt.Paint paint10 = multiplePiePlot9.getNoDataMessagePaint();
        java.awt.Paint paint11 = multiplePiePlot9.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot9);
        jFreeChart12.setBackgroundImageAlignment((int) (short) 0);
        multiplePiePlot3.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart12);
        java.lang.String str16 = multiplePiePlot3.getNoDataMessage();
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        multiplePiePlot3.setNoDataMessageFont(font17);
        java.awt.Color color19 = java.awt.Color.CYAN;
        java.awt.Color color20 = java.awt.Color.green;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean23 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge22);
        java.lang.Class<?> wildcardClass24 = rectangleEdge22.getClass();
        boolean boolean25 = blockBorder21.equals((java.lang.Object) rectangleEdge22);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double30 = rectangleInsets28.calculateRightInset((double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass32 = rectangleInsets31.getClass();
        double double33 = rectangleInsets31.getLeft();
        double double35 = rectangleInsets31.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass37 = rectangleInsets36.getClass();
        org.jfree.chart.LegendItemSource legendItemSource38 = null;
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle(legendItemSource38);
        double double40 = legendTitle39.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = legendTitle39.getPadding();
        legendTitle39.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = legendTitle39.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource45 = null;
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle(legendItemSource45);
        double double47 = legendTitle46.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = legendTitle46.getPadding();
        java.awt.geom.Rectangle2D rectangle2D49 = legendTitle46.getBounds();
        rectangleInsets44.trim(rectangle2D49);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType51 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets36.createAdjustedRectangle(rectangle2D49, lengthAdjustmentType51, lengthAdjustmentType52);
        org.jfree.chart.LegendItemSource legendItemSource54 = null;
        org.jfree.chart.title.LegendTitle legendTitle55 = new org.jfree.chart.title.LegendTitle(legendItemSource54);
        double double56 = legendTitle55.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = legendTitle55.getPadding();
        java.awt.geom.Rectangle2D rectangle2D58 = legendTitle55.getBounds();
        java.awt.geom.Rectangle2D rectangle2D61 = rectangleInsets36.createInsetRectangle(rectangle2D58, false, true);
        org.jfree.chart.LegendItemSource legendItemSource62 = null;
        org.jfree.chart.title.LegendTitle legendTitle63 = new org.jfree.chart.title.LegendTitle(legendItemSource62);
        double double64 = legendTitle63.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = legendTitle63.getPadding();
        legendTitle63.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource68 = null;
        org.jfree.chart.title.LegendTitle legendTitle69 = new org.jfree.chart.title.LegendTitle(legendItemSource68);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment70 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle69.setHorizontalAlignment(horizontalAlignment70);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor72 = legendTitle69.getLegendItemGraphicAnchor();
        legendTitle63.setLegendItemGraphicAnchor(rectangleAnchor72);
        java.awt.geom.Point2D point2D74 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D58, rectangleAnchor72);
        java.awt.geom.Rectangle2D rectangle2D77 = rectangleInsets31.createOutsetRectangle(rectangle2D58, false, true);
        java.awt.geom.Rectangle2D rectangle2D78 = rectangleInsets28.createOutsetRectangle(rectangle2D58);
        try {
            org.jfree.chart.title.TextTitle textTitle79 = new org.jfree.chart.title.TextTitle("Multiple Pie Plot", font17, (java.awt.Paint) color19, rectangleEdge22, horizontalAlignment26, verticalAlignment27, rectangleInsets28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(horizontalAlignment70);
        org.junit.Assert.assertNotNull(rectangleAnchor72);
        org.junit.Assert.assertNotNull(point2D74);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertNotNull(rectangle2D78);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        multiplePiePlot1.axisChanged(axisChangeEvent2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        multiplePiePlot1.handleClick(100, (int) 'a', plotRenderingInfo6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("PieSection: 255, -48897(10)", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle1.getLegendItemGraphicEdge();
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge6);
        java.lang.String str8 = rectangleEdge6.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleEdge.LEFT" + "'", str8.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle20.getTextAlignment();
        java.awt.Paint paint22 = textTitle20.getPaint();
        java.awt.Stroke[] strokeArray23 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean24 = textTitle20.equals((java.lang.Object) strokeArray23);
        jFreeChart14.addSubtitle((org.jfree.chart.title.Title) textTitle20);
        org.jfree.chart.block.BlockContainer blockContainer26 = new org.jfree.chart.block.BlockContainer();
        blockContainer26.clear();
        java.util.List list28 = blockContainer26.getBlocks();
        jFreeChart14.setSubtitles(list28);
        jFreeChart14.setTextAntiAlias(true);
        java.awt.Paint paint32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        jFreeChart14.setBackgroundPaint(paint32);
        float float34 = jFreeChart14.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.5f + "'", float34 == 0.5f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.08d, (double) 8);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        blockContainer6.clear();
        java.util.List list8 = blockContainer6.getBlocks();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = columnArrangement4.arrange(blockContainer6, graphics2D9, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getTextAlignment();
        textTitle5.setWidth((double) 100L);
        textTitle5.setText("");
        java.lang.String str11 = textTitle5.getText();
        org.jfree.chart.util.ObjectList objectList12 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj14 = objectList12.get(1);
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle5, obj14);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle16.getTextAlignment();
        textTitle16.setWidth((double) 100L);
        textTitle16.setText("");
        java.lang.String str22 = textTitle16.getText();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color27);
        textTitle16.setPaint((java.awt.Paint) color27);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset30);
        java.awt.Paint paint32 = multiplePiePlot31.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        multiplePiePlot31.notifyListeners(plotChangeEvent33);
        org.jfree.chart.JFreeChart jFreeChart35 = multiplePiePlot31.getPieChart();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle16, (java.lang.Object) multiplePiePlot31);
        org.jfree.chart.block.BlockContainer blockContainer37 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.lang.Object obj38 = blockContainer37.clone();
        java.util.List list39 = blockContainer37.getBlocks();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(jFreeChart35);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(list39);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        chartEntity7.setToolTipText("");
        chartEntity7.setURLText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = columnArrangement4.arrange(blockContainer5, graphics2D6, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("VerticalAlignment.CENTER", "RectangleEdge.RIGHT", "RectangleEdge.LEFT", "rect", "RectangleAnchor.BOTTOM_RIGHT");
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleEdge.BOTTOM", "rect", "RectangleEdge.LEFT", "RectangleEdge.LEFT", "TableOrder.BY_COLUMN");
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        java.awt.Paint paint4 = legendTitle1.getItemPaint();
        java.lang.Object obj5 = legendTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getMargin();
        double double8 = rectangleInsets6.calculateTopOutset((double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "hi!", image3, "", "hi!", "");
        java.util.List list8 = projectInfo7.getContributors();
        java.util.List list9 = projectInfo7.getContributors();
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNull(list9);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.lang.String str4 = legendTitle1.getID();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        double double8 = legendTitle7.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle7.getPadding();
        java.awt.geom.Rectangle2D rectangle2D10 = legendTitle7.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D10, "", "hi!");
        try {
            legendTitle1.draw(graphics2D5, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangle2D10);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot0.getDataExtractOrder();
        multiplePiePlot0.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(tableOrder3);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getNumberFormat();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color7);
        java.awt.Paint paint9 = blockBorder8.getPaint();
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        boolean boolean11 = blockBorder8.equals((java.lang.Object) shape10);
        java.awt.Paint paint12 = blockBorder8.getPaint();
        boolean boolean13 = standardPieSectionLabelGenerator1.equals((java.lang.Object) paint12);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.awt.Color color7 = java.awt.Color.getHSBColor((float) 0, (float) '#', (float) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean9 = color7.equals((java.lang.Object) rectangleEdge8);
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color7);
        java.lang.Class<?> wildcardClass11 = color7.getClass();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 15, 10.0d, 100.0d, (java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        java.awt.Color color17 = java.awt.Color.pink;
        legendTitle9.setItemPaint((java.awt.Paint) color17);
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement21 = blockContainer20.getArrangement();
        flowArrangement19.add((org.jfree.chart.block.Block) blockContainer20, (java.lang.Object) 255);
        boolean boolean24 = blockContainer20.isEmpty();
        legendTitle9.setWrapper(blockContainer20);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = null;
        try {
            org.jfree.chart.util.Size2D size2D28 = blockContainer20.arrange(graphics2D26, rectangleConstraint27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(arrangement21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) (byte) -1, (int) '#', (java.lang.Comparable) 12.0d, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleEdge.LEFT");
        java.lang.String str8 = pieSectionEntity7.getURLText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleEdge.LEFT" + "'", str8.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.distributeLabels((double) 2, (double) 1);
        pieLabelDistributor1.sort();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass12 = rectangleInsets11.getClass();
        double double13 = rectangleInsets11.getLeft();
        double double15 = rectangleInsets11.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass17 = rectangleInsets16.getClass();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        legendTitle19.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle19.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        rectangleInsets24.trim(rectangle2D29);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets16.createAdjustedRectangle(rectangle2D29, lengthAdjustmentType31, lengthAdjustmentType32);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle35.getPadding();
        java.awt.geom.Rectangle2D rectangle2D38 = legendTitle35.getBounds();
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets16.createInsetRectangle(rectangle2D38, false, true);
        org.jfree.chart.LegendItemSource legendItemSource42 = null;
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle(legendItemSource42);
        double double44 = legendTitle43.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = legendTitle43.getPadding();
        legendTitle43.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource48 = null;
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle(legendItemSource48);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment50 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle49.setHorizontalAlignment(horizontalAlignment50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = legendTitle49.getLegendItemGraphicAnchor();
        legendTitle43.setLegendItemGraphicAnchor(rectangleAnchor52);
        java.awt.geom.Point2D point2D54 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D38, rectangleAnchor52);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets11.createOutsetRectangle(rectangle2D38, false, true);
        legendTitle8.setPadding(rectangleInsets11);
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.image.ColorModel colorModel60 = null;
        java.awt.Rectangle rectangle61 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass63 = rectangleInsets62.getClass();
        org.jfree.chart.LegendItemSource legendItemSource64 = null;
        org.jfree.chart.title.LegendTitle legendTitle65 = new org.jfree.chart.title.LegendTitle(legendItemSource64);
        double double66 = legendTitle65.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = legendTitle65.getPadding();
        legendTitle65.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = legendTitle65.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource71 = null;
        org.jfree.chart.title.LegendTitle legendTitle72 = new org.jfree.chart.title.LegendTitle(legendItemSource71);
        double double73 = legendTitle72.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = legendTitle72.getPadding();
        java.awt.geom.Rectangle2D rectangle2D75 = legendTitle72.getBounds();
        rectangleInsets70.trim(rectangle2D75);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType77 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType78 = null;
        java.awt.geom.Rectangle2D rectangle2D79 = rectangleInsets62.createAdjustedRectangle(rectangle2D75, lengthAdjustmentType77, lengthAdjustmentType78);
        java.awt.geom.AffineTransform affineTransform80 = null;
        java.awt.RenderingHints renderingHints81 = null;
        java.awt.PaintContext paintContext82 = color59.createContext(colorModel60, rectangle61, rectangle2D79, affineTransform80, renderingHints81);
        java.awt.geom.Rectangle2D rectangle2D83 = rectangleInsets11.createOutsetRectangle(rectangle2D79);
        piePlot1.setLegendItemShape((java.awt.Shape) rectangle2D83);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator85 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator85);
        boolean boolean87 = piePlot1.getIgnoreZeroValues();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(horizontalAlignment50);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(point2D54);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(paintContext82);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        double double3 = legendTitle2.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle2.getPadding();
        java.awt.geom.Rectangle2D rectangle2D5 = legendTitle2.getBounds();
        boolean boolean6 = rotation0.equals((java.lang.Object) legendTitle2);
        org.jfree.chart.block.BlockFrame blockFrame7 = legendTitle2.getFrame();
        java.lang.String str8 = legendTitle2.getID();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(blockFrame7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle3.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle10.getBounds();
        rectangleInsets8.trim(rectangle2D13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets0.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType15, lengthAdjustmentType16);
        java.awt.Color color18 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color18);
        double double21 = rectangleInsets0.calculateTopOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double24 = rectangleInsets22.trimWidth((double) 2);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass28 = rectangleInsets27.getClass();
        org.jfree.chart.LegendItemSource legendItemSource29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource29);
        double double31 = legendTitle30.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendTitle30.getPadding();
        legendTitle30.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = legendTitle30.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle(legendItemSource36);
        double double38 = legendTitle37.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = legendTitle37.getPadding();
        java.awt.geom.Rectangle2D rectangle2D40 = legendTitle37.getBounds();
        rectangleInsets35.trim(rectangle2D40);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets27.createAdjustedRectangle(rectangle2D40, lengthAdjustmentType42, lengthAdjustmentType43);
        legendTitle26.setBounds(rectangle2D44);
        rectangleInsets22.trim(rectangle2D44);
        rectangleInsets0.trim(rectangle2D44);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double49 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D44, rectangleEdge48);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + (-3.0d) + "'", double49 == (-3.0d));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle7.setHorizontalAlignment(horizontalAlignment8);
        legendTitle7.setPadding((double) (short) 0, (double) (-1L), 0.0d, (double) (short) -1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = legendTitle7.getHorizontalAlignment();
        legendTitle1.setHorizontalAlignment(horizontalAlignment15);
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        double double19 = legendTitle18.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle18.getPadding();
        legendTitle18.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle18.getLegendItemGraphicEdge();
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = legendTitle1.getLegendItemGraphicLocation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str1 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.LEFT" + "'", str1.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        jFreeChart5.setBackgroundImageAlignment((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass9 = rectangleInsets8.getClass();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getPadding();
        legendTitle11.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle11.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        double double19 = legendTitle18.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle18.getPadding();
        java.awt.geom.Rectangle2D rectangle2D21 = legendTitle18.getBounds();
        rectangleInsets16.trim(rectangle2D21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets8.createAdjustedRectangle(rectangle2D21, lengthAdjustmentType23, lengthAdjustmentType24);
        java.awt.Color color26 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder(rectangleInsets8, (java.awt.Paint) color26);
        double double29 = rectangleInsets8.calculateTopOutset((double) (-1));
        jFreeChart5.setPadding(rectangleInsets8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent31 = null;
        try {
            jFreeChart5.plotChanged(plotChangeEvent31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getPercentFormat();
        java.text.NumberFormat numberFormat3 = standardPieSectionLabelGenerator1.getNumberFormat();
        java.text.AttributedString attributedString5 = null;
        standardPieSectionLabelGenerator1.setAttributedLabel(100, attributedString5);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getSectionOutlinesVisible();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        piePlot1.setDataset(pieDataset3);
        try {
            piePlot1.setInteriorGap(8.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (8.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getURLText();
        textTitle0.setText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        textTitle0.setExpandToFitSpace(false);
        textTitle0.setToolTipText("rect");
        boolean boolean8 = textTitle0.getNotify();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        java.awt.Paint paint5 = legendTitle1.getItemPaint();
        java.lang.Object obj6 = legendTitle1.clone();
        legendTitle1.setID("0,-1,1,1");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        java.awt.Stroke stroke19 = jFreeChart14.getBorderStroke();
        org.jfree.chart.ui.ProjectInfo projectInfo20 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image21 = projectInfo20.getLogo();
        jFreeChart14.setBackgroundImage(image21);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart14.getTitle();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent24 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle23);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(projectInfo20);
        org.junit.Assert.assertNotNull(image21);
        org.junit.Assert.assertNotNull(textTitle23);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle8.setLegendItemGraphicAnchor(rectangleAnchor12);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle15.getPadding();
        java.lang.String str18 = rectangleInsets17.toString();
        legendTitle8.setMargin(rectangleInsets17);
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.lang.Class<?> wildcardClass24 = rectangleAnchor23.getClass();
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str18.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer1, (java.lang.Object) 255);
        boolean boolean5 = blockContainer1.isEmpty();
        java.util.List list6 = blockContainer1.getBlocks();
        double double7 = blockContainer1.getContentYOffset();
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Set<java.lang.String> strSet2 = jFreeChartResources0.keySet();
        java.util.Enumeration<java.lang.String> strEnumeration3 = jFreeChartResources0.getKeys();
        java.lang.Object obj5 = jFreeChartResources0.handleGetObject("Other");
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNotNull(strEnumeration3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor4);
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        double double8 = legendTitle7.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle7.getPadding();
        legendTitle7.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = legendTitle7.getLegendItemGraphicEdge();
        java.lang.String str13 = rectangleEdge12.toString();
        legendTitle1.setPosition(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleEdge.LEFT" + "'", str13.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        java.awt.Shape shape4 = piePlot1.getLegendItemShape();
        java.awt.Paint paint5 = piePlot1.getLabelOutlinePaint();
        float float6 = piePlot1.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.5f + "'", float6 == 0.5f);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset13, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        java.lang.String str20 = pieSectionEntity19.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass22 = rectangleInsets21.getClass();
        double double23 = rectangleInsets21.getLeft();
        double double25 = rectangleInsets21.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass27 = rectangleInsets26.getClass();
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle29.getPadding();
        legendTitle29.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle29.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        double double37 = legendTitle36.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle36.getPadding();
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle36.getBounds();
        rectangleInsets34.trim(rectangle2D39);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets26.createAdjustedRectangle(rectangle2D39, lengthAdjustmentType41, lengthAdjustmentType42);
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        double double46 = legendTitle45.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = legendTitle45.getPadding();
        java.awt.geom.Rectangle2D rectangle2D48 = legendTitle45.getBounds();
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets26.createInsetRectangle(rectangle2D48, false, true);
        org.jfree.chart.LegendItemSource legendItemSource52 = null;
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle(legendItemSource52);
        double double54 = legendTitle53.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = legendTitle53.getPadding();
        legendTitle53.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource58 = null;
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle(legendItemSource58);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment60 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle59.setHorizontalAlignment(horizontalAlignment60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = legendTitle59.getLegendItemGraphicAnchor();
        legendTitle53.setLegendItemGraphicAnchor(rectangleAnchor62);
        java.awt.geom.Point2D point2D64 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D48, rectangleAnchor62);
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets21.createOutsetRectangle(rectangle2D48, false, true);
        pieSectionEntity19.setArea((java.awt.Shape) rectangle2D67);
        java.awt.Shape shape69 = pieSectionEntity19.getArea();
        pieSectionEntity19.setURLText("");
        java.lang.String str72 = pieSectionEntity19.getShapeCoords();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator73 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator74 = null;
        try {
            java.lang.String str75 = pieSectionEntity19.getImageMapAreaTag(toolTipTagFragmentGenerator73, uRLTagFragmentGenerator74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PieSection: 255, -48897(10)" + "'", str20.equals("PieSection: 255, -48897(10)"));
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(horizontalAlignment60);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(point2D64);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "0,-1,1,1" + "'", str72.equals("0,-1,1,1"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle20.getTextAlignment();
        java.awt.Paint paint22 = textTitle20.getPaint();
        java.awt.Stroke[] strokeArray23 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean24 = textTitle20.equals((java.lang.Object) strokeArray23);
        jFreeChart14.addSubtitle((org.jfree.chart.title.Title) textTitle20);
        org.jfree.chart.block.FlowArrangement flowArrangement26 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement28 = blockContainer27.getArrangement();
        flowArrangement26.add((org.jfree.chart.block.Block) blockContainer27, (java.lang.Object) 255);
        boolean boolean31 = blockContainer27.isEmpty();
        java.util.List list32 = blockContainer27.getBlocks();
        try {
            jFreeChart14.setTextAntiAlias((java.lang.Object) list32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: [] incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(arrangement28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(list32);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        projectInfo0.setLicenceText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.lang.String str4 = projectInfo0.getCopyright();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str4.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("TableOrder.BY_COLUMN", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Shape shape3 = defaultDrawingSupplier0.getNextShape();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        double double6 = legendTitle5.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent7 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle5);
        org.jfree.chart.block.BlockContainer blockContainer8 = null;
        legendTitle5.setWrapper(blockContainer8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle5.setItemPaint((java.awt.Paint) color10);
        double double12 = legendTitle5.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset14);
        java.awt.Paint paint16 = multiplePiePlot15.getNoDataMessagePaint();
        java.awt.Paint paint17 = multiplePiePlot15.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot15);
        jFreeChart18.setBackgroundImageAlignment((int) (short) 0);
        legendTitle5.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart18);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart18.setBorderPaint((java.awt.Paint) color22);
        boolean boolean24 = defaultDrawingSupplier0.equals((java.lang.Object) color22);
        java.awt.Shape shape25 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        defaultKeyedValues2D1.addValue((java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 1.0f);
        int int9 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 15, (java.lang.Comparable) (short) 10);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 10.0f, (java.lang.Comparable) (-1.0d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset(0.0d);
        double double4 = rectangleInsets0.calculateTopInset((double) 1L);
        double double6 = rectangleInsets0.calculateLeftInset((double) 192);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle1.getLegendItemGraphicEdge();
        boolean boolean7 = legendTitle1.getNotify();
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = legendTitle1.getVerticalAlignment();
        java.awt.Color color9 = java.awt.Color.ORANGE;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.block.BlockContainer blockContainer15 = null;
        legendTitle12.setWrapper(blockContainer15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle12.setItemPaint((java.awt.Paint) color17);
        double double19 = legendTitle12.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset21);
        java.awt.Paint paint23 = multiplePiePlot22.getNoDataMessagePaint();
        java.awt.Paint paint24 = multiplePiePlot22.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot22);
        jFreeChart25.setBackgroundImageAlignment((int) (short) 0);
        legendTitle12.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart25);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart25.setBorderPaint((java.awt.Paint) color29);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = textTitle31.getTextAlignment();
        java.awt.Paint paint33 = textTitle31.getPaint();
        java.awt.Stroke[] strokeArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean35 = textTitle31.equals((java.lang.Object) strokeArray34);
        jFreeChart25.addSubtitle((org.jfree.chart.title.Title) textTitle31);
        jFreeChart25.setTextAntiAlias(true);
        org.jfree.chart.LegendItemSource legendItemSource39 = null;
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle(legendItemSource39);
        double double41 = legendTitle40.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent42 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle40);
        org.jfree.chart.JFreeChart jFreeChart43 = null;
        titleChangeEvent42.setChart(jFreeChart43);
        jFreeChart25.titleChanged(titleChangeEvent42);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType46 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean48 = chartChangeEventType46.equals((java.lang.Object) 8.0d);
        java.lang.String str49 = chartChangeEventType46.toString();
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder55 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color54);
        boolean boolean56 = chartChangeEventType46.equals((java.lang.Object) (short) 100);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent57 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockBorder10, jFreeChart25, chartChangeEventType46);
        org.jfree.chart.title.LegendTitle legendTitle58 = jFreeChart25.getLegend();
        legendTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart25);
        java.awt.Paint paint60 = jFreeChart25.getBorderPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(horizontalAlignment32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str49.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(legendTitle58);
        org.junit.Assert.assertNotNull(paint60);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) ' ');
        java.lang.Object obj3 = objectList1.get((int) ' ');
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "hi!", image3, "", "hi!", "");
        java.util.List list8 = projectInfo7.getContributors();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo14 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass16 = rectangleInsets15.getClass();
        boolean boolean17 = basicProjectInfo14.equals((java.lang.Object) wildcardClass16);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo23 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass25 = rectangleInsets24.getClass();
        boolean boolean26 = basicProjectInfo23.equals((java.lang.Object) wildcardClass25);
        basicProjectInfo14.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo23);
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo23);
        java.lang.String str29 = projectInfo7.getVersion();
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        java.awt.Color color2 = java.awt.Color.RED;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass6 = rectangleInsets5.getClass();
        double double7 = rectangleInsets5.getLeft();
        double double9 = rectangleInsets5.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass11 = rectangleInsets10.getClass();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        double double14 = legendTitle13.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle13.getPadding();
        legendTitle13.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle13.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        double double21 = legendTitle20.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle20.getPadding();
        java.awt.geom.Rectangle2D rectangle2D23 = legendTitle20.getBounds();
        rectangleInsets18.trim(rectangle2D23);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets10.createAdjustedRectangle(rectangle2D23, lengthAdjustmentType25, lengthAdjustmentType26);
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle29.getPadding();
        java.awt.geom.Rectangle2D rectangle2D32 = legendTitle29.getBounds();
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets10.createInsetRectangle(rectangle2D32, false, true);
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle(legendItemSource36);
        double double38 = legendTitle37.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = legendTitle37.getPadding();
        legendTitle37.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource42 = null;
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle(legendItemSource42);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle43.setHorizontalAlignment(horizontalAlignment44);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = legendTitle43.getLegendItemGraphicAnchor();
        legendTitle37.setLegendItemGraphicAnchor(rectangleAnchor46);
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D32, rectangleAnchor46);
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets5.createOutsetRectangle(rectangle2D32, false, true);
        try {
            blockBorder3.draw(graphics2D4, rectangle2D51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        java.awt.Paint paint4 = multiplePiePlot3.getNoDataMessagePaint();
        java.awt.Paint paint5 = multiplePiePlot3.getNoDataMessagePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = multiplePiePlot3.getDrawingSupplier();
        boolean boolean7 = unitType1.equals((java.lang.Object) multiplePiePlot3);
        java.lang.Object obj8 = null;
        boolean boolean9 = unitType1.equals(obj8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getPadding();
        legendTitle11.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle11.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        double double19 = legendTitle18.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle18.getPadding();
        java.awt.geom.Rectangle2D rectangle2D21 = legendTitle18.getBounds();
        rectangleInsets16.trim(rectangle2D21);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity29 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D21, pieDataset23, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        boolean boolean30 = unitType1.equals((java.lang.Object) 10L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        java.awt.Paint paint5 = legendTitle1.getItemPaint();
        org.jfree.chart.event.TitleChangeListener titleChangeListener6 = null;
        legendTitle1.addChangeListener(titleChangeListener6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle1.getLegendItemGraphicEdge();
        boolean boolean9 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getNumberFormat();
        java.text.NumberFormat numberFormat3 = standardPieSectionLabelGenerator1.getNumberFormat();
        java.text.NumberFormat numberFormat4 = standardPieSectionLabelGenerator1.getNumberFormat();
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberFormat3);
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot1);
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        double double6 = legendTitle5.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent7 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle5);
        org.jfree.chart.block.BlockContainer blockContainer8 = null;
        legendTitle5.setWrapper(blockContainer8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle11.setHorizontalAlignment(horizontalAlignment12);
        legendTitle11.setPadding((double) (short) 0, (double) (-1L), 0.0d, (double) (short) -1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = legendTitle11.getHorizontalAlignment();
        legendTitle5.setHorizontalAlignment(horizontalAlignment19);
        boolean boolean21 = legendTitle3.equals((java.lang.Object) horizontalAlignment19);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer1.getArrangement();
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer1, (java.lang.Object) 255);
        boolean boolean5 = blockContainer1.isEmpty();
        org.jfree.chart.block.Arrangement arrangement6 = blockContainer1.getArrangement();
        blockContainer1.clear();
        java.lang.String str8 = blockContainer1.getID();
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(arrangement6);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        piePlot1.setExplodePercent((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (double) (short) 1);
        piePlot1.setMinimumArcAngleToDraw((double) (byte) 0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot1.setURLGenerator(pieURLGenerator11);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        double double18 = legendTitle17.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle17.getPadding();
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle17.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D20, "", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass25 = rectangleInsets24.getClass();
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        double double28 = legendTitle27.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle27.getPadding();
        legendTitle27.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendTitle27.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        double double35 = legendTitle34.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle34.getPadding();
        java.awt.geom.Rectangle2D rectangle2D37 = legendTitle34.getBounds();
        rectangleInsets32.trim(rectangle2D37);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets24.createAdjustedRectangle(rectangle2D37, lengthAdjustmentType39, lengthAdjustmentType40);
        org.jfree.chart.LegendItemSource legendItemSource42 = null;
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle(legendItemSource42);
        double double44 = legendTitle43.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = legendTitle43.getPadding();
        java.awt.geom.Rectangle2D rectangle2D46 = legendTitle43.getBounds();
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets24.createInsetRectangle(rectangle2D46, false, true);
        org.jfree.chart.LegendItemSource legendItemSource50 = null;
        org.jfree.chart.title.LegendTitle legendTitle51 = new org.jfree.chart.title.LegendTitle(legendItemSource50);
        double double52 = legendTitle51.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = legendTitle51.getPadding();
        legendTitle51.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource56 = null;
        org.jfree.chart.title.LegendTitle legendTitle57 = new org.jfree.chart.title.LegendTitle(legendItemSource56);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment58 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle57.setHorizontalAlignment(horizontalAlignment58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = legendTitle57.getLegendItemGraphicAnchor();
        legendTitle51.setLegendItemGraphicAnchor(rectangleAnchor60);
        java.awt.geom.Point2D point2D62 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D46, rectangleAnchor60);
        org.jfree.chart.plot.PlotState plotState63 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        try {
            piePlot1.draw(graphics2D15, rectangle2D20, point2D62, plotState63, plotRenderingInfo64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(horizontalAlignment58);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(point2D62);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        multiplePiePlot1.axisChanged(axisChangeEvent2);
        java.lang.String str4 = multiplePiePlot1.getPlotType();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass7 = rectangleInsets6.getClass();
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle9.getPadding();
        legendTitle9.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendTitle9.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        double double17 = legendTitle16.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getPadding();
        java.awt.geom.Rectangle2D rectangle2D19 = legendTitle16.getBounds();
        rectangleInsets14.trim(rectangle2D19);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets6.createAdjustedRectangle(rectangle2D19, lengthAdjustmentType21, lengthAdjustmentType22);
        java.awt.Color color24 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(rectangleInsets6, (java.awt.Paint) color24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass27 = rectangleInsets26.getClass();
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle29.getPadding();
        legendTitle29.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle29.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        double double37 = legendTitle36.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle36.getPadding();
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle36.getBounds();
        rectangleInsets34.trim(rectangle2D39);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets26.createAdjustedRectangle(rectangle2D39, lengthAdjustmentType41, lengthAdjustmentType42);
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        double double46 = legendTitle45.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = legendTitle45.getPadding();
        java.awt.geom.Rectangle2D rectangle2D48 = legendTitle45.getBounds();
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets26.createInsetRectangle(rectangle2D48, false, true);
        java.awt.geom.Rectangle2D rectangle2D54 = rectangleInsets6.createInsetRectangle(rectangle2D48, false, true);
        try {
            multiplePiePlot1.drawBackground(graphics2D5, rectangle2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Multiple Pie Plot" + "'", str4.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D54);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        double double6 = multiplePiePlot2.getLimit();
        multiplePiePlot2.setAggregatedItemsKey((java.lang.Comparable) (-1));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.trimWidth((double) (byte) 100);
        double double3 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 98.0d + "'", double2 == 98.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.awt.Color color2 = java.awt.Color.getColor("0,0,1,1", (int) (byte) 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset4);
        java.awt.Paint paint6 = multiplePiePlot5.getAggregatedItemsPaint();
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((double) 100L, (double) (byte) 10, (double) 15, 0.0d, paint6);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "hi!", image3, "", "hi!", "");
        java.util.List list8 = projectInfo7.getContributors();
        java.lang.String str9 = projectInfo7.getLicenceText();
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("TableOrder.BY_COLUMN", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", "Multiple Pie Plot", "java.awt.Color[r=0,g=0,b=0]");
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Color color2 = color1.darker();
        float[] floatArray8 = new float[] { '#', (short) 10, '#', 2, 255 };
        float[] floatArray9 = color2.getRGBComponents(floatArray8);
        float[] floatArray10 = color0.getComponents(floatArray8);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass2 = rectangleInsets1.getClass();
        java.awt.Color color3 = java.awt.Color.RED;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color3);
        java.awt.Color color5 = color3.brighter();
        boolean boolean6 = objectList0.equals((java.lang.Object) color3);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Color color2 = color1.darker();
        float[] floatArray8 = new float[] { '#', (short) 10, '#', 2, 255 };
        float[] floatArray9 = color2.getRGBComponents(floatArray8);
        float[] floatArray10 = color0.getComponents(floatArray9);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.util.List list2 = blockContainer0.getBlocks();
        double double3 = blockContainer0.getContentYOffset();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = blockContainer0.arrange(graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getNumberFormat();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        java.awt.Paint paint5 = multiplePiePlot4.getNoDataMessagePaint();
        java.awt.Paint paint6 = multiplePiePlot4.getNoDataMessagePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        multiplePiePlot4.markerChanged(markerChangeEvent7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = multiplePiePlot4.getInsets();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int11 = color10.getGreen();
        multiplePiePlot4.setAggregatedItemsPaint((java.awt.Paint) color10);
        boolean boolean13 = standardPieSectionLabelGenerator1.equals((java.lang.Object) color10);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        java.lang.String str16 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset14, (java.lang.Comparable) (-1.0f));
        java.lang.Object obj17 = standardPieSectionLabelGenerator1.clone();
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 128 + "'", int11 == 128);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ChartEntity: tooltip = ", "RectangleEdge.RIGHT");
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        multiplePiePlot1.setLimit((double) 100L);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getNumberFormat();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        try {
            java.text.AttributedString attributedString5 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset3, (java.lang.Comparable) "RectangleEdge.BOTTOM");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        java.lang.String str17 = chartEntity7.getShapeType();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        legendTitle19.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle19.getPadding();
        boolean boolean25 = chartEntity7.equals((java.lang.Object) rectangleInsets24);
        java.awt.Shape shape26 = chartEntity7.getArea();
        chartEntity7.setToolTipText("ChartChangeEventType.NEW_DATASET");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "rect" + "'", str17.equals("rect"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        java.awt.Paint paint2 = textTitle0.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getTextAlignment();
        java.lang.Object obj4 = textTitle0.clone();
        textTitle0.setURLText("Other");
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 128, (double) 1.0f, (double) 0L, (double) ' ');
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-1), (int) (short) 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset7);
        java.awt.Paint paint9 = multiplePiePlot8.getNoDataMessagePaint();
        java.awt.Paint paint10 = multiplePiePlot8.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot8);
        jFreeChart11.setBackgroundImageAlignment((int) (short) 0);
        multiplePiePlot2.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart11);
        java.lang.String str15 = multiplePiePlot2.getNoDataMessage();
        java.awt.Font font16 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        multiplePiePlot2.setNoDataMessageFont(font16);
        java.lang.Object obj18 = multiplePiePlot2.clone();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle1.getLegendItemGraphicEdge();
        boolean boolean7 = legendTitle1.getNotify();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot8.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Font font11 = multiplePiePlot8.getNoDataMessageFont();
        legendTitle1.setItemFont(font11);
        java.lang.Object obj13 = legendTitle1.clone();
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame17 = legendTitle15.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray19 = new org.jfree.chart.LegendItemSource[] { legendItemSource18 };
        legendTitle15.setSources(legendItemSourceArray19);
        legendTitle1.setSources(legendItemSourceArray19);
        double double22 = legendTitle1.getContentXOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame17);
        org.junit.Assert.assertNotNull(legendItemSourceArray19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("RectangleEdge.LEFT");
        java.lang.String str2 = datasetGroup1.getID();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleEdge.LEFT" + "'", str2.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image6 = projectInfo5.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo10 = new org.jfree.chart.ui.ProjectInfo("ChartChangeEventType.NEW_DATASET", "", "Other", image6, "", "Multiple Pie Plot", "Multiple Pie Plot");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo10);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo17 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass19 = rectangleInsets18.getClass();
        boolean boolean20 = basicProjectInfo17.equals((java.lang.Object) wildcardClass19);
        basicProjectInfo17.addOptionalLibrary("Other");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo17);
        java.util.List list24 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertNotNull(image6);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(list24);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        java.lang.String str17 = chartEntity7.getShapeType();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        legendTitle19.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle19.getPadding();
        boolean boolean25 = chartEntity7.equals((java.lang.Object) rectangleInsets24);
        java.lang.String str26 = chartEntity7.toString();
        boolean boolean28 = chartEntity7.equals((java.lang.Object) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "rect" + "'", str17.equals("rect"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ChartEntity: tooltip = " + "'", str26.equals("ChartEntity: tooltip = "));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        jFreeChart5.setBackgroundImageAlignment((int) (short) 0);
        java.awt.Stroke stroke8 = jFreeChart5.getBorderStroke();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass11 = rectangleInsets10.getClass();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        double double14 = legendTitle13.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle13.getPadding();
        legendTitle13.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle13.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        double double21 = legendTitle20.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle20.getPadding();
        java.awt.geom.Rectangle2D rectangle2D23 = legendTitle20.getBounds();
        rectangleInsets18.trim(rectangle2D23);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets10.createAdjustedRectangle(rectangle2D23, lengthAdjustmentType25, lengthAdjustmentType26);
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle29.getPadding();
        java.awt.geom.Rectangle2D rectangle2D32 = legendTitle29.getBounds();
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets10.createInsetRectangle(rectangle2D32, false, true);
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle(legendItemSource36);
        double double38 = legendTitle37.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = legendTitle37.getPadding();
        legendTitle37.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource42 = null;
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle(legendItemSource42);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle43.setHorizontalAlignment(horizontalAlignment44);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = legendTitle43.getLegendItemGraphicAnchor();
        legendTitle37.setLegendItemGraphicAnchor(rectangleAnchor46);
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D32, rectangleAnchor46);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo49 = null;
        try {
            jFreeChart5.draw(graphics2D9, rectangle2D32, chartRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(point2D48);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        multiplePiePlot1.markerChanged(markerChangeEvent4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = multiplePiePlot1.getInsets();
        java.awt.Image image7 = multiplePiePlot1.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset8 = multiplePiePlot1.getDataset();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNull(categoryDataset8);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list1 = defaultKeyedValues2D0.getColumnKeys();
        java.lang.Object obj2 = defaultKeyedValues2D0.clone();
        int int3 = defaultKeyedValues2D0.getColumnCount();
        try {
            defaultKeyedValues2D0.removeRow((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.plot.Plot plot2 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("ChartChangeEventType.NEW_DATASET", font1, plot2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        legendTitle1.setWidth(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) (byte) -1, (int) '#', (java.lang.Comparable) 12.0d, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleEdge.LEFT");
        java.lang.Comparable comparable8 = null;
        pieSectionEntity7.setSectionKey(comparable8);
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        java.awt.Shape shape4 = piePlot1.getLegendItemShape();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle7.setHorizontalAlignment(horizontalAlignment8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendTitle7.getLegendItemGraphicAnchor();
        java.awt.Paint paint11 = legendTitle7.getBackgroundPaint();
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle7.getBounds();
        try {
            piePlot1.drawOutline(graphics2D5, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Color color0 = java.awt.Color.blue;
        int int1 = color0.getGreen();
        float[] floatArray2 = null;
        float[] floatArray3 = color0.getRGBColorComponents(floatArray2);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot1);
        multiplePiePlot1.zoom((double) (-1L));
        multiplePiePlot1.setLimit(0.0d);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = multiplePiePlot1.getDrawingSupplier();
        org.jfree.chart.plot.Plot plot9 = multiplePiePlot1.getRootPlot();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(plot9);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        textTitle0.setWidth((double) 100L);
        textTitle0.setText("");
        textTitle0.setHeight((double) 0L);
        java.lang.String str8 = textTitle0.getID();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = textTitle0.arrange(graphics2D9, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image6 = projectInfo5.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo10 = new org.jfree.chart.ui.ProjectInfo("ChartChangeEventType.NEW_DATASET", "", "Other", image6, "", "Multiple Pie Plot", "Multiple Pie Plot");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo10);
        java.awt.Image image12 = null;
        projectInfo0.setLogo(image12);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertNotNull(image6);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        multiplePiePlot2.notifyListeners(plotChangeEvent4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset6);
        java.awt.Paint paint8 = multiplePiePlot7.getNoDataMessagePaint();
        java.lang.Comparable comparable9 = multiplePiePlot7.getAggregatedItemsKey();
        java.awt.Color color10 = java.awt.Color.black;
        java.awt.Color color11 = color10.darker();
        multiplePiePlot7.setAggregatedItemsPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = multiplePiePlot7.getDrawingSupplier();
        multiplePiePlot2.setDrawingSupplier(drawingSupplier13);
        java.awt.Font font15 = multiplePiePlot2.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.Color color18 = java.awt.Color.red;
        textTitle17.setPaint((java.awt.Paint) color18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean21 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) horizontalAlignment23);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = textTitle25.getTextAlignment();
        java.awt.Paint paint27 = textTitle25.getBackgroundPaint();
        org.jfree.chart.block.BlockFrame blockFrame28 = textTitle25.getFrame();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement33 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment29, verticalAlignment30, (double) '#', 0.0d);
        textTitle25.setVerticalAlignment(verticalAlignment30);
        org.jfree.chart.block.FlowArrangement flowArrangement37 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment23, verticalAlignment30, 12.0d, (double) (short) 10);
        org.jfree.chart.LegendItemSource legendItemSource38 = null;
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle(legendItemSource38);
        double double40 = legendTitle39.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = legendTitle39.getPadding();
        legendTitle39.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = legendTitle39.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass46 = rectangleInsets45.getClass();
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        double double49 = legendTitle48.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = legendTitle48.getPadding();
        legendTitle48.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = legendTitle48.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource54 = null;
        org.jfree.chart.title.LegendTitle legendTitle55 = new org.jfree.chart.title.LegendTitle(legendItemSource54);
        double double56 = legendTitle55.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = legendTitle55.getPadding();
        java.awt.geom.Rectangle2D rectangle2D58 = legendTitle55.getBounds();
        rectangleInsets53.trim(rectangle2D58);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType60 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType61 = null;
        java.awt.geom.Rectangle2D rectangle2D62 = rectangleInsets45.createAdjustedRectangle(rectangle2D58, lengthAdjustmentType60, lengthAdjustmentType61);
        legendTitle39.setPadding(rectangleInsets45);
        double double64 = rectangleInsets45.getTop();
        org.jfree.chart.title.TextTitle textTitle65 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.NEW_DATASET", font15, (java.awt.Paint) color18, rectangleEdge20, horizontalAlignment22, verticalAlignment30, rectangleInsets45);
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = textTitle65.getPadding();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "Other" + "'", comparable9.equals("Other"));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNotNull(blockFrame28);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets66);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset13, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        java.lang.Comparable comparable20 = pieSectionEntity19.getSectionKey();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 10L + "'", comparable20.equals(10L));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) (short) 0);
        int int5 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) "0,0,1,1");
        try {
            defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 8.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 8.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "hi!", image4, "", "hi!", "");
        java.util.List list9 = projectInfo8.getContributors();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass17 = rectangleInsets16.getClass();
        boolean boolean18 = basicProjectInfo15.equals((java.lang.Object) wildcardClass17);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo24 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass26 = rectangleInsets25.getClass();
        boolean boolean27 = basicProjectInfo24.equals((java.lang.Object) wildcardClass26);
        basicProjectInfo15.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
        projectInfo8.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo8);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset31);
        java.awt.Paint paint33 = multiplePiePlot32.getNoDataMessagePaint();
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot32);
        org.jfree.chart.JFreeChart jFreeChart35 = multiplePiePlot32.getPieChart();
        boolean boolean36 = basicProjectInfo0.equals((java.lang.Object) multiplePiePlot32);
        org.junit.Assert.assertNull(list9);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(jFreeChart35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.plot.Plot plot3 = multiplePiePlot1.getParent();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        multiplePiePlot1.setDataset(categoryDataset4);
        java.awt.Paint paint6 = multiplePiePlot1.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle1.getLegendItemGraphicLocation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleAnchor.BOTTOM_RIGHT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Enumeration<java.lang.String> strEnumeration2 = jFreeChartResources0.getKeys();
        try {
            java.lang.String[] strArray4 = jFreeChartResources0.getStringArray("ChartEntity: tooltip = ");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ChartEntity: tooltip = ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(strEnumeration2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str1.equals("RectangleAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        multiplePiePlot1.notifyListeners(plotChangeEvent3);
        java.awt.Image image5 = null;
        multiplePiePlot1.setBackgroundImage(image5);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getTextAlignment();
        textTitle5.setWidth((double) 100L);
        textTitle5.setText("");
        java.lang.String str11 = textTitle5.getText();
        org.jfree.chart.util.ObjectList objectList12 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj14 = objectList12.get(1);
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle5, obj14);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle16.getTextAlignment();
        textTitle16.setWidth((double) 100L);
        textTitle16.setText("");
        java.lang.String str22 = textTitle16.getText();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color27);
        textTitle16.setPaint((java.awt.Paint) color27);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset30);
        java.awt.Paint paint32 = multiplePiePlot31.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        multiplePiePlot31.notifyListeners(plotChangeEvent33);
        org.jfree.chart.JFreeChart jFreeChart35 = multiplePiePlot31.getPieChart();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle16, (java.lang.Object) multiplePiePlot31);
        java.awt.Graphics2D graphics2D37 = null;
        try {
            org.jfree.chart.util.Size2D size2D38 = textTitle16.arrange(graphics2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(jFreeChart35);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image6 = projectInfo5.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo10 = new org.jfree.chart.ui.ProjectInfo("ChartChangeEventType.NEW_DATASET", "", "Other", image6, "", "Multiple Pie Plot", "Multiple Pie Plot");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo10);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo17 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass19 = rectangleInsets18.getClass();
        boolean boolean20 = basicProjectInfo17.equals((java.lang.Object) wildcardClass19);
        basicProjectInfo17.addOptionalLibrary("Other");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo17);
        basicProjectInfo17.setLicenceName("java.awt.Color[r=0,g=0,b=0]");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertNotNull(image6);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        piePlot1.setExplodePercent((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (double) (short) 1);
        java.lang.Comparable comparable9 = null;
        java.awt.Color color10 = java.awt.Color.ORANGE;
        try {
            piePlot1.setSectionPaint(comparable9, (java.awt.Paint) color10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("0,-1,1,1", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "hi!", image4, "", "hi!", "");
        java.util.List list9 = projectInfo8.getContributors();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass17 = rectangleInsets16.getClass();
        boolean boolean18 = basicProjectInfo15.equals((java.lang.Object) wildcardClass17);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo24 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass26 = rectangleInsets25.getClass();
        boolean boolean27 = basicProjectInfo24.equals((java.lang.Object) wildcardClass26);
        basicProjectInfo15.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
        projectInfo8.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo8);
        projectInfo8.setCopyright("");
        java.lang.String str33 = projectInfo8.getLicenceText();
        org.junit.Assert.assertNull(list9);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        double double13 = rectangleInsets6.getLeft();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        multiplePiePlot0.setBackgroundAlpha((float) (byte) 1);
        java.lang.String str5 = multiplePiePlot0.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str5.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("Other", "RectangleEdge.LEFT");
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle20.getTextAlignment();
        java.awt.Paint paint22 = textTitle20.getPaint();
        java.awt.Stroke[] strokeArray23 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean24 = textTitle20.equals((java.lang.Object) strokeArray23);
        jFreeChart14.addSubtitle((org.jfree.chart.title.Title) textTitle20);
        jFreeChart14.setTextAntiAlias(true);
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        double double30 = legendTitle29.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent31 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle29);
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        titleChangeEvent31.setChart(jFreeChart32);
        jFreeChart14.titleChanged(titleChangeEvent31);
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle(legendItemSource36);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment38 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle37.setHorizontalAlignment(horizontalAlignment38);
        legendTitle37.setPadding((double) (short) 0, (double) (-1L), 0.0d, (double) (short) -1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment45 = legendTitle37.getHorizontalAlignment();
        try {
            jFreeChart14.addSubtitle((-452), (org.jfree.chart.title.Title) legendTitle37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment38);
        org.junit.Assert.assertNotNull(horizontalAlignment45);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        jFreeChart14.setTextAntiAlias(false);
        java.awt.Stroke stroke22 = jFreeChart14.getBorderStroke();
        int int23 = jFreeChart14.getBackgroundImageAlignment();
        java.awt.Image image24 = jFreeChart14.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNull(image24);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle8.setLegendItemGraphicAnchor(rectangleAnchor12);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle15.getPadding();
        java.lang.String str18 = rectangleInsets17.toString();
        legendTitle8.setMargin(rectangleInsets17);
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets17);
        double double22 = rectangleInsets17.calculateRightInset(2.08d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str18.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        java.lang.String str1 = tableOrder0.toString();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        java.awt.Paint paint5 = multiplePiePlot4.getNoDataMessagePaint();
        java.awt.Paint paint6 = multiplePiePlot4.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot4);
        java.awt.RenderingHints renderingHints8 = jFreeChart7.getRenderingHints();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean11 = chartChangeEventType9.equals((java.lang.Object) 8.0d);
        java.lang.String str12 = chartChangeEventType9.toString();
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color17);
        boolean boolean19 = chartChangeEventType9.equals((java.lang.Object) (short) 100);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) str1, jFreeChart7, chartChangeEventType9);
        jFreeChart7.setNotify(false);
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TableOrder.BY_COLUMN" + "'", str1.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(renderingHints8);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str12.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass8 = rectangleInsets7.getClass();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        legendTitle10.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle10.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        double double18 = legendTitle17.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle17.getPadding();
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle17.getBounds();
        rectangleInsets15.trim(rectangle2D20);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets7.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType22, lengthAdjustmentType23);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets7.createInsetRectangle(rectangle2D29, false, true);
        legendTitle1.setBounds(rectangle2D29);
        legendTitle1.setWidth((double) 100);
        org.jfree.chart.block.BlockContainer blockContainer36 = legendTitle1.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement37 = blockContainer36.getArrangement();
        blockContainer36.setID("TableOrder.BY_COLUMN");
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = null;
        try {
            org.jfree.chart.util.Size2D size2D42 = blockContainer36.arrange(graphics2D40, rectangleConstraint41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(blockContainer36);
        org.junit.Assert.assertNotNull(arrangement37);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle1.setHorizontalAlignment(horizontalAlignment2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment2, verticalAlignment4, (double) (short) 10, (double) 10.0f);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        java.awt.Paint paint11 = multiplePiePlot10.getNoDataMessagePaint();
        java.awt.Paint paint12 = multiplePiePlot10.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot10);
        jFreeChart13.setBackgroundImageAlignment((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass17 = rectangleInsets16.getClass();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        legendTitle19.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle19.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        rectangleInsets24.trim(rectangle2D29);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets16.createAdjustedRectangle(rectangle2D29, lengthAdjustmentType31, lengthAdjustmentType32);
        java.awt.Color color34 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder35 = new org.jfree.chart.block.BlockBorder(rectangleInsets16, (java.awt.Paint) color34);
        double double37 = rectangleInsets16.calculateTopOutset((double) (-1));
        jFreeChart13.setPadding(rectangleInsets16);
        boolean boolean39 = horizontalAlignment2.equals((java.lang.Object) rectangleInsets16);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Multiple Pie Plot");
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator7);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint10 = defaultDrawingSupplier9.getNextFillPaint();
        java.awt.Paint paint11 = defaultDrawingSupplier9.getNextOutlinePaint();
        java.awt.Shape shape12 = defaultDrawingSupplier9.getNextShape();
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        double double15 = legendTitle14.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent16 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle14);
        org.jfree.chart.block.BlockContainer blockContainer17 = null;
        legendTitle14.setWrapper(blockContainer17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle14.setItemPaint((java.awt.Paint) color19);
        double double21 = legendTitle14.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset23);
        java.awt.Paint paint25 = multiplePiePlot24.getNoDataMessagePaint();
        java.awt.Paint paint26 = multiplePiePlot24.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot24);
        jFreeChart27.setBackgroundImageAlignment((int) (short) 0);
        legendTitle14.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart27);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart27.setBorderPaint((java.awt.Paint) color31);
        boolean boolean33 = defaultDrawingSupplier9.equals((java.lang.Object) color31);
        piePlot1.setShadowPaint((java.awt.Paint) color31);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass12 = rectangleInsets11.getClass();
        double double13 = rectangleInsets11.getLeft();
        double double15 = rectangleInsets11.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass17 = rectangleInsets16.getClass();
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        legendTitle19.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle19.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        rectangleInsets24.trim(rectangle2D29);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets16.createAdjustedRectangle(rectangle2D29, lengthAdjustmentType31, lengthAdjustmentType32);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle35.getPadding();
        java.awt.geom.Rectangle2D rectangle2D38 = legendTitle35.getBounds();
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets16.createInsetRectangle(rectangle2D38, false, true);
        org.jfree.chart.LegendItemSource legendItemSource42 = null;
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle(legendItemSource42);
        double double44 = legendTitle43.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = legendTitle43.getPadding();
        legendTitle43.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource48 = null;
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle(legendItemSource48);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment50 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle49.setHorizontalAlignment(horizontalAlignment50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = legendTitle49.getLegendItemGraphicAnchor();
        legendTitle43.setLegendItemGraphicAnchor(rectangleAnchor52);
        java.awt.geom.Point2D point2D54 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D38, rectangleAnchor52);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets11.createOutsetRectangle(rectangle2D38, false, true);
        legendTitle8.setPadding(rectangleInsets11);
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.image.ColorModel colorModel60 = null;
        java.awt.Rectangle rectangle61 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass63 = rectangleInsets62.getClass();
        org.jfree.chart.LegendItemSource legendItemSource64 = null;
        org.jfree.chart.title.LegendTitle legendTitle65 = new org.jfree.chart.title.LegendTitle(legendItemSource64);
        double double66 = legendTitle65.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = legendTitle65.getPadding();
        legendTitle65.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = legendTitle65.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource71 = null;
        org.jfree.chart.title.LegendTitle legendTitle72 = new org.jfree.chart.title.LegendTitle(legendItemSource71);
        double double73 = legendTitle72.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = legendTitle72.getPadding();
        java.awt.geom.Rectangle2D rectangle2D75 = legendTitle72.getBounds();
        rectangleInsets70.trim(rectangle2D75);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType77 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType78 = null;
        java.awt.geom.Rectangle2D rectangle2D79 = rectangleInsets62.createAdjustedRectangle(rectangle2D75, lengthAdjustmentType77, lengthAdjustmentType78);
        java.awt.geom.AffineTransform affineTransform80 = null;
        java.awt.RenderingHints renderingHints81 = null;
        java.awt.PaintContext paintContext82 = color59.createContext(colorModel60, rectangle61, rectangle2D79, affineTransform80, renderingHints81);
        java.awt.geom.Rectangle2D rectangle2D83 = rectangleInsets11.createOutsetRectangle(rectangle2D79);
        piePlot1.setLegendItemShape((java.awt.Shape) rectangle2D83);
        double double85 = piePlot1.getLabelGap();
        java.awt.Stroke stroke86 = piePlot1.getLabelLinkStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator87 = piePlot1.getLegendLabelGenerator();
        java.lang.Object obj88 = null;
        boolean boolean89 = piePlot1.equals(obj88);
        org.jfree.chart.ui.ProjectInfo projectInfo93 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image94 = projectInfo93.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo98 = new org.jfree.chart.ui.ProjectInfo("ChartChangeEventType.NEW_DATASET", "", "Other", image94, "", "Multiple Pie Plot", "Multiple Pie Plot");
        piePlot1.setBackgroundImage(image94);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(horizontalAlignment50);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(point2D54);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(paintContext82);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.025d + "'", double85 == 0.025d);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(projectInfo93);
        org.junit.Assert.assertNotNull(image94);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleAnchor.BOTTOM_RIGHT", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        piePlot1.setSectionOutlinesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (byte) -1, (java.awt.Paint) color5);
        float float7 = piePlot1.getForegroundAlpha();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color12);
        java.awt.Paint paint14 = blockBorder13.getPaint();
        piePlot1.setLabelOutlinePaint(paint14);
        java.awt.Stroke stroke16 = piePlot1.getLabelOutlineStroke();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.lang.String str4 = rectangleInsets3.toString();
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass8 = rectangleInsets7.getClass();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        legendTitle10.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle10.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        double double18 = legendTitle17.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle17.getPadding();
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle17.getBounds();
        rectangleInsets15.trim(rectangle2D20);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets7.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType22, lengthAdjustmentType23);
        legendTitle6.setBounds(rectangle2D24);
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets3.createOutsetRectangle(rectangle2D24, false, true);
        double double30 = rectangleInsets3.calculateRightOutset(0.0d);
        double double32 = rectangleInsets3.calculateLeftOutset(2.08d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        java.awt.Shape shape4 = piePlot1.getLegendItemShape();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot1.getURLGenerator();
        java.lang.Object obj6 = piePlot1.clone();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getSectionOutlinesVisible();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        piePlot1.setDataset(pieDataset3);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLabelGenerator();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator6);
        org.jfree.chart.util.Rotation rotation8 = piePlot1.getDirection();
        java.awt.Paint paint9 = piePlot1.getBaseSectionOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(rotation8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        java.awt.Paint paint4 = multiplePiePlot3.getNoDataMessagePaint();
        java.awt.Paint paint5 = multiplePiePlot3.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot3);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        java.awt.Paint paint10 = multiplePiePlot9.getNoDataMessagePaint();
        java.awt.Paint paint11 = multiplePiePlot9.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot9);
        jFreeChart12.setBackgroundImageAlignment((int) (short) 0);
        multiplePiePlot3.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart12);
        java.lang.String str16 = multiplePiePlot3.getNoDataMessage();
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        multiplePiePlot3.setNoDataMessageFont(font17);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("", font17);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass8 = rectangleInsets7.getClass();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        legendTitle10.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle10.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        double double18 = legendTitle17.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle17.getPadding();
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle17.getBounds();
        rectangleInsets15.trim(rectangle2D20);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets7.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType22, lengthAdjustmentType23);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets7.createInsetRectangle(rectangle2D29, false, true);
        legendTitle1.setBounds(rectangle2D29);
        legendTitle1.setWidth((double) 100);
        org.jfree.chart.block.BlockContainer blockContainer36 = legendTitle1.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement37 = blockContainer36.getArrangement();
        java.lang.Object obj38 = blockContainer36.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(blockContainer36);
        org.junit.Assert.assertNotNull(arrangement37);
        org.junit.Assert.assertNotNull(obj38);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot1.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Font font4 = multiplePiePlot1.getNoDataMessageFont();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        java.awt.Paint paint7 = multiplePiePlot6.getNoDataMessagePaint();
        java.awt.Paint paint8 = multiplePiePlot6.getNoDataMessagePaint();
        multiplePiePlot1.setParent((org.jfree.chart.plot.Plot) multiplePiePlot6);
        boolean boolean10 = strokeMap0.equals((java.lang.Object) multiplePiePlot6);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Comparable comparable3 = multiplePiePlot1.getAggregatedItemsKey();
        java.awt.Color color4 = java.awt.Color.black;
        java.awt.Color color5 = color4.darker();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color5);
        java.lang.Object obj7 = multiplePiePlot1.clone();
        java.lang.String str8 = multiplePiePlot1.getNoDataMessage();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 100);
        java.lang.Object obj3 = objectList1.get((int) (short) 1);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        java.awt.Paint paint5 = legendTitle1.getItemPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle1.getLegendItemGraphicEdge();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        java.lang.Class<?> wildcardClass3 = legendTitle1.getClass();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle1.getLegendItemGraphicLocation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) 8.0d);
        java.lang.Object obj3 = null;
        boolean boolean4 = chartChangeEventType0.equals(obj3);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Stroke stroke18 = jFreeChart14.getBorderStroke();
        java.awt.Stroke stroke19 = jFreeChart14.getBorderStroke();
        org.jfree.chart.ui.ProjectInfo projectInfo20 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image21 = projectInfo20.getLogo();
        jFreeChart14.setBackgroundImage(image21);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart14.getTitle();
        jFreeChart14.setBackgroundImageAlpha((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(projectInfo20);
        org.junit.Assert.assertNotNull(image21);
        org.junit.Assert.assertNotNull(textTitle23);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        java.awt.Color color6 = java.awt.Color.green;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "hi!");
        java.lang.Class<?> wildcardClass3 = contributor2.getClass();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        double double5 = legendTitle4.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle4.getPadding();
        java.awt.geom.Rectangle2D rectangle2D7 = legendTitle4.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D7, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle12);
        org.jfree.chart.block.BlockContainer blockContainer15 = null;
        legendTitle12.setWrapper(blockContainer15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle12.setItemPaint((java.awt.Paint) color17);
        boolean boolean19 = chartEntity10.equals((java.lang.Object) legendTitle12);
        java.lang.String str20 = chartEntity10.getShapeType();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        double double23 = legendTitle22.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle22.getPadding();
        legendTitle22.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle22.getPadding();
        boolean boolean28 = chartEntity10.equals((java.lang.Object) rectangleInsets27);
        multiplePiePlot1.setInsets(rectangleInsets27, true);
        boolean boolean31 = multiplePiePlot1.isSubplot();
        multiplePiePlot1.setLimit((double) 1L);
        java.awt.Paint paint34 = multiplePiePlot1.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rect" + "'", str20.equals("rect"));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Comparable comparable3 = multiplePiePlot1.getAggregatedItemsKey();
        java.awt.Color color4 = java.awt.Color.black;
        java.awt.Color color5 = color4.darker();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = multiplePiePlot1.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset8 = multiplePiePlot1.getDataset();
        java.awt.Color color9 = java.awt.Color.gray;
        multiplePiePlot1.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot1.getPieChart();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        try {
            jFreeChart11.handleClick(10, (int) (short) 10, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(jFreeChart11);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass2 = rectangleInsets1.getClass();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        double double5 = legendTitle4.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle4.getPadding();
        legendTitle4.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle4.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getPadding();
        java.awt.geom.Rectangle2D rectangle2D14 = legendTitle11.getBounds();
        rectangleInsets9.trim(rectangle2D14);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets1.createAdjustedRectangle(rectangle2D14, lengthAdjustmentType16, lengthAdjustmentType17);
        java.awt.Color color19 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color19);
        textTitle0.setPadding(rectangleInsets1);
        double double23 = rectangleInsets1.calculateLeftInset(2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        try {
            java.lang.String str4 = jFreeChartResources0.getString("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        double double7 = piePlot1.getInteriorGap();
        java.awt.Paint paint8 = piePlot1.getLabelShadowPaint();
        java.awt.Stroke stroke9 = piePlot1.getLabelOutlineStroke();
        boolean boolean10 = piePlot1.getIgnoreZeroValues();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = piePlot1.getURLGenerator();
        java.awt.Stroke stroke12 = piePlot1.getBaseSectionOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(pieURLGenerator11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        java.awt.Shape shape4 = piePlot1.getLegendItemShape();
        java.lang.Comparable comparable5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset6);
        java.awt.Paint paint8 = multiplePiePlot7.getNoDataMessagePaint();
        java.lang.Comparable comparable9 = multiplePiePlot7.getAggregatedItemsKey();
        java.awt.Color color10 = java.awt.Color.black;
        java.awt.Color color11 = color10.darker();
        multiplePiePlot7.setAggregatedItemsPaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.blue;
        int int14 = color13.getGreen();
        multiplePiePlot7.setNoDataMessagePaint((java.awt.Paint) color13);
        java.awt.Stroke stroke16 = multiplePiePlot7.getOutlineStroke();
        try {
            piePlot1.setSectionOutlineStroke(comparable5, stroke16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "Other" + "'", comparable9.equals("Other"));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getTextAlignment();
        textTitle5.setWidth((double) 100L);
        textTitle5.setText("");
        java.lang.String str11 = textTitle5.getText();
        org.jfree.chart.util.ObjectList objectList12 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj14 = objectList12.get(1);
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle5, obj14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass21 = rectangleInsets20.getClass();
        double double22 = rectangleInsets20.getLeft();
        double double24 = rectangleInsets20.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass26 = rectangleInsets25.getClass();
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        double double29 = legendTitle28.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = legendTitle28.getPadding();
        legendTitle28.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendTitle28.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle35.getPadding();
        java.awt.geom.Rectangle2D rectangle2D38 = legendTitle35.getBounds();
        rectangleInsets33.trim(rectangle2D38);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets25.createAdjustedRectangle(rectangle2D38, lengthAdjustmentType40, lengthAdjustmentType41);
        org.jfree.chart.LegendItemSource legendItemSource43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle(legendItemSource43);
        double double45 = legendTitle44.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendTitle44.getPadding();
        java.awt.geom.Rectangle2D rectangle2D47 = legendTitle44.getBounds();
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets25.createInsetRectangle(rectangle2D47, false, true);
        org.jfree.chart.LegendItemSource legendItemSource51 = null;
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle(legendItemSource51);
        double double53 = legendTitle52.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = legendTitle52.getPadding();
        legendTitle52.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource57 = null;
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle(legendItemSource57);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment59 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle58.setHorizontalAlignment(horizontalAlignment59);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = legendTitle58.getLegendItemGraphicAnchor();
        legendTitle52.setLegendItemGraphicAnchor(rectangleAnchor61);
        java.awt.geom.Point2D point2D63 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D47, rectangleAnchor61);
        java.awt.geom.Rectangle2D rectangle2D66 = rectangleInsets20.createOutsetRectangle(rectangle2D47, false, true);
        java.awt.Paint[] paintArray67 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.lang.Object obj68 = textTitle18.draw(graphics2D19, rectangle2D66, (java.lang.Object) paintArray67);
        org.jfree.chart.LegendItemSource legendItemSource69 = null;
        org.jfree.chart.title.LegendTitle legendTitle70 = new org.jfree.chart.title.LegendTitle(legendItemSource69);
        double double71 = legendTitle70.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = legendTitle70.getPadding();
        legendTitle70.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = legendTitle70.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource76 = null;
        org.jfree.chart.title.LegendTitle legendTitle77 = new org.jfree.chart.title.LegendTitle(legendItemSource76);
        double double78 = legendTitle77.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets79 = legendTitle77.getPadding();
        java.awt.geom.Rectangle2D rectangle2D80 = legendTitle77.getBounds();
        rectangleInsets75.trim(rectangle2D80);
        java.lang.Object obj82 = textTitle5.draw(graphics2D16, rectangle2D66, (java.lang.Object) rectangleInsets75);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(horizontalAlignment59);
        org.junit.Assert.assertNotNull(rectangleAnchor61);
        org.junit.Assert.assertNotNull(point2D63);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(paintArray67);
        org.junit.Assert.assertNull(obj68);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets79);
        org.junit.Assert.assertNotNull(rectangle2D80);
        org.junit.Assert.assertNull(obj82);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        java.lang.String str8 = chartEntity7.getShapeType();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "rect" + "'", str8.equals("rect"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getTextAlignment();
        textTitle5.setWidth((double) 100L);
        textTitle5.setText("");
        java.lang.String str11 = textTitle5.getText();
        org.jfree.chart.util.ObjectList objectList12 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj14 = objectList12.get(1);
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle5, obj14);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle16.getTextAlignment();
        textTitle16.setWidth((double) 100L);
        textTitle16.setText("");
        java.lang.String str22 = textTitle16.getText();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color27);
        textTitle16.setPaint((java.awt.Paint) color27);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset30);
        java.awt.Paint paint32 = multiplePiePlot31.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        multiplePiePlot31.notifyListeners(plotChangeEvent33);
        org.jfree.chart.JFreeChart jFreeChart35 = multiplePiePlot31.getPieChart();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle16, (java.lang.Object) multiplePiePlot31);
        org.jfree.chart.block.BlockContainer blockContainer37 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment38 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment39 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement42 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment38, verticalAlignment39, (double) '#', 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass44 = rectangleInsets43.getClass();
        double double45 = rectangleInsets43.getLeft();
        boolean boolean46 = columnArrangement42.equals((java.lang.Object) double45);
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement42);
        double double48 = blockContainer47.getContentXOffset();
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = null;
        try {
            org.jfree.chart.util.Size2D size2D51 = columnArrangement4.arrange(blockContainer47, graphics2D49, rectangleConstraint50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(jFreeChart35);
        org.junit.Assert.assertNotNull(horizontalAlignment38);
        org.junit.Assert.assertNotNull(verticalAlignment39);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        java.awt.Stroke stroke3 = strokeMap0.getStroke((java.lang.Comparable) "java.awt.Color[r=0,g=0,b=0]");
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(stroke3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Set<java.lang.String> strSet2 = jFreeChartResources0.keySet();
        boolean boolean4 = jFreeChartResources0.containsKey("rect");
        java.lang.Object[][] objArray5 = jFreeChartResources0.getContents();
        java.util.Set<java.lang.String> strSet6 = jFreeChartResources0.keySet();
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.Paint paint6 = jFreeChart5.getBorderPaint();
        jFreeChart5.fireChartChanged();
        jFreeChart5.setBackgroundImageAlpha(0.0f);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        double double6 = legendTitle1.getContentXOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass8 = rectangleInsets7.getClass();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        legendTitle10.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle10.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        double double18 = legendTitle17.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle17.getPadding();
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle17.getBounds();
        rectangleInsets15.trim(rectangle2D20);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets7.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType22, lengthAdjustmentType23);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets7.createInsetRectangle(rectangle2D29, false, true);
        legendTitle1.setBounds(rectangle2D29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        double double37 = legendTitle36.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle36.getPadding();
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle36.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle36.setLegendItemGraphicAnchor(rectangleAnchor40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = legendTitle36.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource legendItemSource43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle(legendItemSource43);
        double double45 = legendTitle44.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendTitle44.getPadding();
        java.lang.String str47 = rectangleInsets46.toString();
        boolean boolean48 = legendTitle36.equals((java.lang.Object) str47);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment49 = legendTitle36.getHorizontalAlignment();
        org.jfree.chart.LegendItemSource legendItemSource50 = null;
        org.jfree.chart.title.LegendTitle legendTitle51 = new org.jfree.chart.title.LegendTitle(legendItemSource50);
        double double52 = legendTitle51.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = legendTitle51.getPadding();
        legendTitle51.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = legendTitle51.getLegendItemGraphicEdge();
        boolean boolean57 = legendTitle51.getNotify();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot58 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot58.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Font font61 = multiplePiePlot58.getNoDataMessageFont();
        legendTitle51.setItemFont(font61);
        java.lang.Object obj63 = legendTitle51.clone();
        org.jfree.chart.LegendItemSource legendItemSource64 = null;
        org.jfree.chart.title.LegendTitle legendTitle65 = new org.jfree.chart.title.LegendTitle(legendItemSource64);
        double double66 = legendTitle65.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame67 = legendTitle65.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource68 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray69 = new org.jfree.chart.LegendItemSource[] { legendItemSource68 };
        legendTitle65.setSources(legendItemSourceArray69);
        legendTitle51.setSources(legendItemSourceArray69);
        legendTitle36.setSources(legendItemSourceArray69);
        legendTitle1.setSources(legendItemSourceArray69);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str47.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment49);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(font61);
        org.junit.Assert.assertNotNull(obj63);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame67);
        org.junit.Assert.assertNotNull(legendItemSourceArray69);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.lang.Object[][] objArray2 = jFreeChartResources0.getContents();
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        java.awt.Paint paint6 = jFreeChart5.getBorderPaint();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        java.awt.Paint paint12 = legendTitle8.getItemPaint();
        double double13 = legendTitle8.getContentXOffset();
        jFreeChart5.removeSubtitle((org.jfree.chart.title.Title) legendTitle8);
        java.awt.Paint paint15 = jFreeChart5.getBackgroundPaint();
        int int16 = jFreeChart5.getSubtitleCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        try {
            java.awt.image.BufferedImage bufferedImage21 = jFreeChart5.createBufferedImage((int) ' ', (int) (byte) 100, 15, chartRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 15");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle3.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle10.getBounds();
        rectangleInsets8.trim(rectangle2D13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets0.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType15, lengthAdjustmentType16);
        double double19 = rectangleInsets0.calculateRightOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle3.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle10.getBounds();
        rectangleInsets8.trim(rectangle2D13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets0.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType15, lengthAdjustmentType16);
        java.awt.Color color18 = java.awt.Color.cyan;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass21 = rectangleInsets20.getClass();
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        double double24 = legendTitle23.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle23.getPadding();
        legendTitle23.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle23.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource29);
        double double31 = legendTitle30.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendTitle30.getPadding();
        java.awt.geom.Rectangle2D rectangle2D33 = legendTitle30.getBounds();
        rectangleInsets28.trim(rectangle2D33);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType35 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets20.createAdjustedRectangle(rectangle2D33, lengthAdjustmentType35, lengthAdjustmentType36);
        org.jfree.chart.LegendItemSource legendItemSource38 = null;
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle(legendItemSource38);
        double double40 = legendTitle39.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = legendTitle39.getPadding();
        java.awt.geom.Rectangle2D rectangle2D42 = legendTitle39.getBounds();
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets20.createInsetRectangle(rectangle2D42, false, true);
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets0.createInsetRectangle(rectangle2D42, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity51 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D42, "rect", "ChartChangeEventType.NEW_DATASET");
        java.lang.Object obj52 = chartEntity51.clone();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(obj52);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        java.lang.String str2 = unitType1.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UnitType.ABSOLUTE" + "'", str2.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass4 = rectangleInsets3.getClass();
        double double5 = rectangleInsets3.getLeft();
        double double7 = rectangleInsets3.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass9 = rectangleInsets8.getClass();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getPadding();
        legendTitle11.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle11.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        double double19 = legendTitle18.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle18.getPadding();
        java.awt.geom.Rectangle2D rectangle2D21 = legendTitle18.getBounds();
        rectangleInsets16.trim(rectangle2D21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets8.createAdjustedRectangle(rectangle2D21, lengthAdjustmentType23, lengthAdjustmentType24);
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        double double28 = legendTitle27.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle27.getPadding();
        java.awt.geom.Rectangle2D rectangle2D30 = legendTitle27.getBounds();
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets8.createInsetRectangle(rectangle2D30, false, true);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle35.getPadding();
        legendTitle35.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment42 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle41.setHorizontalAlignment(horizontalAlignment42);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = legendTitle41.getLegendItemGraphicAnchor();
        legendTitle35.setLegendItemGraphicAnchor(rectangleAnchor44);
        java.awt.geom.Point2D point2D46 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D30, rectangleAnchor44);
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets3.createOutsetRectangle(rectangle2D30, false, true);
        java.awt.Paint[] paintArray50 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.lang.Object obj51 = textTitle1.draw(graphics2D2, rectangle2D49, (java.lang.Object) paintArray50);
        boolean boolean52 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(horizontalAlignment42);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(point2D46);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(paintArray50);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", image3, "hi!", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D8 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list9 = defaultKeyedValues2D8.getColumnKeys();
        projectInfo7.setContributors(list9);
        java.lang.String str11 = projectInfo7.getLicenceName();
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass1 = rectangleInsets0.getClass();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle3.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle10.getBounds();
        rectangleInsets8.trim(rectangle2D13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets0.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType15, lengthAdjustmentType16);
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        double double20 = legendTitle19.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle19.getPadding();
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle19.getBounds();
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets0.createInsetRectangle(rectangle2D22, false, true);
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        double double28 = legendTitle27.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle27.getPadding();
        legendTitle27.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle33.setHorizontalAlignment(horizontalAlignment34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = legendTitle33.getLegendItemGraphicAnchor();
        legendTitle27.setLegendItemGraphicAnchor(rectangleAnchor36);
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D22, rectangleAnchor36);
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D22);
        java.lang.Object obj40 = chartEntity39.clone();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertNotNull(obj40);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendTitle1.getLegendItemGraphicLocation();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        float[] floatArray29 = new float[] { '4', 1, (-452), 2, 2, 1L };
        float[] floatArray30 = java.awt.Color.RGBtoHSB((int) '#', (-48897), 192, floatArray29);
        float[] floatArray31 = color19.getRGBColorComponents(floatArray30);
        legendTitle1.setItemPaint((java.awt.Paint) color19);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_ROW;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D2.removeValue((java.lang.Comparable) 0.08d, (java.lang.Comparable) "RectangleEdge.LEFT");
        int int6 = defaultKeyedValues2D2.getColumnCount();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        boolean boolean8 = defaultKeyedValues2D2.equals((java.lang.Object) pieLabelLinkStyle7);
        boolean boolean9 = tableOrder0.equals((java.lang.Object) pieLabelLinkStyle7);
        java.lang.String str10 = pieLabelLinkStyle7.toString();
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str10.equals("PieLabelLinkStyle.QUAD_CURVE"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.08d, (double) 8);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        columnArrangement4.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Paint paint3 = multiplePiePlot2.getNoDataMessagePaint();
        java.awt.Paint paint4 = multiplePiePlot2.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset7);
        java.awt.Paint paint9 = multiplePiePlot8.getNoDataMessagePaint();
        java.awt.Paint paint10 = multiplePiePlot8.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot8);
        jFreeChart11.setBackgroundImageAlignment((int) (short) 0);
        multiplePiePlot2.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart11);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType16 = rectangleInsets15.getUnitType();
        try {
            jFreeChart11.setTextAntiAlias((java.lang.Object) unitType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: UnitType.ABSOLUTE incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(unitType16);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle8.setLegendItemGraphicAnchor(rectangleAnchor12);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        double double16 = legendTitle15.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle15.getPadding();
        java.lang.String str18 = rectangleInsets17.toString();
        legendTitle8.setMargin(rectangleInsets17);
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor21);
        double double23 = legendTitle1.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle1.getItemLabelPadding();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str18.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.LegendItemCollection legendItemCollection2 = piePlot1.getLegendItems();
        java.awt.Color color4 = java.awt.Color.GRAY;
        java.awt.Color color5 = java.awt.Color.getColor("{0}", color4);
        piePlot1.setBaseSectionPaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.lang.String str4 = titleChangeEvent3.toString();
        java.lang.Object obj5 = titleChangeEvent3.getSource();
        java.awt.Color color6 = java.awt.Color.ORANGE;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        double double16 = legendTitle9.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        java.awt.Paint paint20 = multiplePiePlot19.getNoDataMessagePaint();
        java.awt.Paint paint21 = multiplePiePlot19.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot19);
        jFreeChart22.setBackgroundImageAlignment((int) (short) 0);
        legendTitle9.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart22);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart22.setBorderPaint((java.awt.Paint) color26);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = textTitle28.getTextAlignment();
        java.awt.Paint paint30 = textTitle28.getPaint();
        java.awt.Stroke[] strokeArray31 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean32 = textTitle28.equals((java.lang.Object) strokeArray31);
        jFreeChart22.addSubtitle((org.jfree.chart.title.Title) textTitle28);
        jFreeChart22.setTextAntiAlias(true);
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle(legendItemSource36);
        double double38 = legendTitle37.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent39 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle37);
        org.jfree.chart.JFreeChart jFreeChart40 = null;
        titleChangeEvent39.setChart(jFreeChart40);
        jFreeChart22.titleChanged(titleChangeEvent39);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType43 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean45 = chartChangeEventType43.equals((java.lang.Object) 8.0d);
        java.lang.String str46 = chartChangeEventType43.toString();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color51);
        boolean boolean53 = chartChangeEventType43.equals((java.lang.Object) (short) 100);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent54 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockBorder7, jFreeChart22, chartChangeEventType43);
        titleChangeEvent3.setChart(jFreeChart22);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo59 = null;
        try {
            java.awt.image.BufferedImage bufferedImage60 = jFreeChart22.createBufferedImage(0, (int) (short) 100, 192, chartRenderingInfo59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 192");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str46.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        projectInfo0.setInfo("PieSection: 255, -48897(10)");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        piePlot1.setExplodePercent((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (double) (short) 1);
        piePlot1.setMinimumArcAngleToDraw((double) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        java.awt.Paint paint13 = multiplePiePlot12.getNoDataMessagePaint();
        java.awt.Paint paint14 = multiplePiePlot12.getNoDataMessagePaint();
        java.awt.Stroke stroke15 = multiplePiePlot12.getOutlineStroke();
        piePlot1.setLabelLinkStroke(stroke15);
        java.awt.Color color17 = java.awt.Color.black;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color17);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = piePlot1.getLegendLabelURLGenerator();
        java.awt.Color color20 = java.awt.Color.BLACK;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color20);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(pieURLGenerator19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.lang.Comparable comparable3 = multiplePiePlot1.getAggregatedItemsKey();
        java.awt.Color color4 = java.awt.Color.black;
        java.awt.Color color5 = color4.darker();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color5);
        multiplePiePlot1.setBackgroundAlpha((float) (-452));
        multiplePiePlot1.setLimit((double) (short) 100);
        java.lang.String str11 = multiplePiePlot1.getPlotType();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Multiple Pie Plot" + "'", str11.equals("Multiple Pie Plot"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "hi!", image3, "", "hi!", "");
        java.util.List list8 = projectInfo7.getContributors();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo14 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass16 = rectangleInsets15.getClass();
        boolean boolean17 = basicProjectInfo14.equals((java.lang.Object) wildcardClass16);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo23 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass25 = rectangleInsets24.getClass();
        boolean boolean26 = basicProjectInfo23.equals((java.lang.Object) wildcardClass25);
        basicProjectInfo14.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo23);
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo23);
        basicProjectInfo23.setVersion("ChartEntity: tooltip = ");
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '#', 0.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle5.getTextAlignment();
        textTitle5.setWidth((double) 100L);
        textTitle5.setText("");
        java.lang.String str11 = textTitle5.getText();
        org.jfree.chart.util.ObjectList objectList12 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj14 = objectList12.get(1);
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle5, obj14);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle16.getTextAlignment();
        textTitle16.setWidth((double) 100L);
        textTitle16.setText("");
        java.lang.String str22 = textTitle16.getText();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color27);
        textTitle16.setPaint((java.awt.Paint) color27);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset30);
        java.awt.Paint paint32 = multiplePiePlot31.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        multiplePiePlot31.notifyListeners(plotChangeEvent33);
        org.jfree.chart.JFreeChart jFreeChart35 = multiplePiePlot31.getPieChart();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle16, (java.lang.Object) multiplePiePlot31);
        org.jfree.chart.block.BlockContainer blockContainer37 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = null;
        try {
            org.jfree.chart.util.Size2D size2D40 = blockContainer37.arrange(graphics2D38, rectangleConstraint39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(jFreeChart35);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass4 = rectangleInsets3.getClass();
        double double5 = rectangleInsets3.getLeft();
        double double7 = rectangleInsets3.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass9 = rectangleInsets8.getClass();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getPadding();
        legendTitle11.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle11.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        double double19 = legendTitle18.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle18.getPadding();
        java.awt.geom.Rectangle2D rectangle2D21 = legendTitle18.getBounds();
        rectangleInsets16.trim(rectangle2D21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets8.createAdjustedRectangle(rectangle2D21, lengthAdjustmentType23, lengthAdjustmentType24);
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        double double28 = legendTitle27.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle27.getPadding();
        java.awt.geom.Rectangle2D rectangle2D30 = legendTitle27.getBounds();
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets8.createInsetRectangle(rectangle2D30, false, true);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        double double36 = legendTitle35.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle35.getPadding();
        legendTitle35.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment42 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle41.setHorizontalAlignment(horizontalAlignment42);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = legendTitle41.getLegendItemGraphicAnchor();
        legendTitle35.setLegendItemGraphicAnchor(rectangleAnchor44);
        java.awt.geom.Point2D point2D46 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D30, rectangleAnchor44);
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets3.createOutsetRectangle(rectangle2D30, false, true);
        java.awt.Paint[] paintArray50 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.lang.Object obj51 = textTitle1.draw(graphics2D2, rectangle2D49, (java.lang.Object) paintArray50);
        textTitle1.setText("VerticalAlignment.BOTTOM");
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(horizontalAlignment42);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(point2D46);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(paintArray50);
        org.junit.Assert.assertNull(obj51);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        double double6 = legendTitle5.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle5.getPadding();
        double double9 = rectangleInsets7.calculateTopOutset((double) (short) 10);
        double double10 = rectangleInsets7.getLeft();
        piePlot1.setLabelPadding(rectangleInsets7);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        double double15 = legendTitle14.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle14.getPadding();
        legendTitle14.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle14.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        double double22 = legendTitle21.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = legendTitle21.getPadding();
        java.awt.geom.Rectangle2D rectangle2D24 = legendTitle21.getBounds();
        rectangleInsets19.trim(rectangle2D24);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity32 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D24, pieDataset26, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        try {
            piePlot1.drawOutline(graphics2D12, rectangle2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangle2D24);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle1.getLegendItemGraphicLocation();
        boolean boolean5 = legendTitle1.getNotify();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        java.lang.String str2 = projectInfo0.getInfo();
        projectInfo0.setLicenceText("0,-1,1,1");
        projectInfo0.setInfo("TableOrder.BY_COLUMN");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PieSection: 255, -48897(10)" + "'", str2.equals("PieSection: 255, -48897(10)"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = java.awt.Color.black;
        java.awt.Color color4 = color3.darker();
        float[] floatArray10 = new float[] { '#', (short) 10, '#', 2, 255 };
        float[] floatArray11 = color4.getRGBComponents(floatArray10);
        float[] floatArray12 = color0.getColorComponents(colorSpace2, floatArray10);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        java.lang.String str1 = tableOrder0.toString();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        java.awt.Paint paint5 = multiplePiePlot4.getNoDataMessagePaint();
        java.awt.Paint paint6 = multiplePiePlot4.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot4);
        java.awt.RenderingHints renderingHints8 = jFreeChart7.getRenderingHints();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean11 = chartChangeEventType9.equals((java.lang.Object) 8.0d);
        java.lang.String str12 = chartChangeEventType9.toString();
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color17);
        boolean boolean19 = chartChangeEventType9.equals((java.lang.Object) (short) 100);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) str1, jFreeChart7, chartChangeEventType9);
        boolean boolean21 = jFreeChart7.getAntiAlias();
        jFreeChart7.setTextAntiAlias(true);
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TableOrder.BY_COLUMN" + "'", str1.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(renderingHints8);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str12.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle1.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle8.getBounds();
        rectangleInsets6.trim(rectangle2D11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D11, pieDataset13, 255, (-48897), (java.lang.Comparable) 10L, "java.awt.Color[r=0,g=0,b=0]", "RectangleEdge.LEFT");
        java.lang.String str20 = pieSectionEntity19.toString();
        pieSectionEntity19.setPieIndex((int) (short) 10);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        pieSectionEntity19.setDataset(pieDataset23);
        java.lang.String str25 = pieSectionEntity19.getURLText();
        java.lang.Comparable comparable26 = pieSectionEntity19.getSectionKey();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PieSection: 255, -48897(10)" + "'", str20.equals("PieSection: 255, -48897(10)"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "RectangleEdge.LEFT" + "'", str25.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + 10L + "'", comparable26.equals(10L));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}");
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getPadding();
        java.lang.String str6 = legendTitle3.getID();
        boolean boolean7 = standardPieSectionLabelGenerator1.equals((java.lang.Object) legendTitle3);
        java.lang.Object obj8 = standardPieSectionLabelGenerator1.clone();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        java.lang.String str11 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset9, (java.lang.Comparable) 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.distributeLabels((double) 2, (double) 1);
        int int6 = pieLabelDistributor1.getItemCount();
        pieLabelDistributor1.clear();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "hi!", image4, "", "hi!", "");
        java.util.List list9 = projectInfo8.getContributors();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass17 = rectangleInsets16.getClass();
        boolean boolean18 = basicProjectInfo15.equals((java.lang.Object) wildcardClass17);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo24 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass26 = rectangleInsets25.getClass();
        boolean boolean27 = basicProjectInfo24.equals((java.lang.Object) wildcardClass26);
        basicProjectInfo15.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
        projectInfo8.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo24);
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo8);
        java.awt.Image image31 = projectInfo8.getLogo();
        java.lang.String str32 = projectInfo8.getLicenceText();
        org.junit.Assert.assertNull(list9);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(image31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.awt.Paint paint0 = null;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        double double3 = legendTitle2.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        legendTitle2.setWrapper(blockContainer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle2.setItemPaint((java.awt.Paint) color7);
        double double9 = legendTitle2.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        java.awt.Paint paint13 = multiplePiePlot12.getNoDataMessagePaint();
        java.awt.Paint paint14 = multiplePiePlot12.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot12);
        jFreeChart15.setBackgroundImageAlignment((int) (short) 0);
        legendTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart15);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart15.setBorderPaint((java.awt.Paint) color19);
        jFreeChart15.setTextAntiAlias(false);
        java.awt.Stroke stroke23 = jFreeChart15.getBorderStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass25 = rectangleInsets24.getClass();
        double double26 = rectangleInsets24.getLeft();
        double double28 = rectangleInsets24.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass30 = rectangleInsets29.getClass();
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle(legendItemSource31);
        double double33 = legendTitle32.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle32.getPadding();
        legendTitle32.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle32.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource38 = null;
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle(legendItemSource38);
        double double40 = legendTitle39.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = legendTitle39.getPadding();
        java.awt.geom.Rectangle2D rectangle2D42 = legendTitle39.getBounds();
        rectangleInsets37.trim(rectangle2D42);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets29.createAdjustedRectangle(rectangle2D42, lengthAdjustmentType44, lengthAdjustmentType45);
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        double double49 = legendTitle48.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = legendTitle48.getPadding();
        java.awt.geom.Rectangle2D rectangle2D51 = legendTitle48.getBounds();
        java.awt.geom.Rectangle2D rectangle2D54 = rectangleInsets29.createInsetRectangle(rectangle2D51, false, true);
        org.jfree.chart.LegendItemSource legendItemSource55 = null;
        org.jfree.chart.title.LegendTitle legendTitle56 = new org.jfree.chart.title.LegendTitle(legendItemSource55);
        double double57 = legendTitle56.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = legendTitle56.getPadding();
        legendTitle56.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource61 = null;
        org.jfree.chart.title.LegendTitle legendTitle62 = new org.jfree.chart.title.LegendTitle(legendItemSource61);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment63 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle62.setHorizontalAlignment(horizontalAlignment63);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor65 = legendTitle62.getLegendItemGraphicAnchor();
        legendTitle56.setLegendItemGraphicAnchor(rectangleAnchor65);
        java.awt.geom.Point2D point2D67 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D51, rectangleAnchor65);
        java.awt.geom.Rectangle2D rectangle2D70 = rectangleInsets24.createOutsetRectangle(rectangle2D51, false, true);
        double double72 = rectangleInsets24.calculateLeftOutset(10.0d);
        try {
            org.jfree.chart.block.LineBorder lineBorder73 = new org.jfree.chart.block.LineBorder(paint0, stroke23, rectangleInsets24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(horizontalAlignment63);
        org.junit.Assert.assertNotNull(rectangleAnchor65);
        org.junit.Assert.assertNotNull(point2D67);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0d + "'", double72 == 1.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        double double5 = legendTitle4.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame6 = legendTitle4.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray8 = new org.jfree.chart.LegendItemSource[] { legendItemSource7 };
        legendTitle4.setSources(legendItemSourceArray8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle11.getPadding();
        java.awt.geom.Rectangle2D rectangle2D14 = legendTitle11.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor15);
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        double double19 = legendTitle18.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle18.getPadding();
        java.lang.String str21 = rectangleInsets20.toString();
        legendTitle11.setMargin(rectangleInsets20);
        legendTitle4.setLegendItemGraphicPadding(rectangleInsets20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle4.setLegendItemGraphicLocation(rectangleAnchor24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass27 = rectangleInsets26.getClass();
        double double28 = rectangleInsets26.getLeft();
        double double30 = rectangleInsets26.calculateBottomOutset((double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass32 = rectangleInsets31.getClass();
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        double double35 = legendTitle34.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle34.getPadding();
        legendTitle34.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = legendTitle34.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        double double42 = legendTitle41.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = legendTitle41.getPadding();
        java.awt.geom.Rectangle2D rectangle2D44 = legendTitle41.getBounds();
        rectangleInsets39.trim(rectangle2D44);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType46 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets31.createAdjustedRectangle(rectangle2D44, lengthAdjustmentType46, lengthAdjustmentType47);
        org.jfree.chart.LegendItemSource legendItemSource49 = null;
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle(legendItemSource49);
        double double51 = legendTitle50.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = legendTitle50.getPadding();
        java.awt.geom.Rectangle2D rectangle2D53 = legendTitle50.getBounds();
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets31.createInsetRectangle(rectangle2D53, false, true);
        org.jfree.chart.LegendItemSource legendItemSource57 = null;
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle(legendItemSource57);
        double double59 = legendTitle58.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = legendTitle58.getPadding();
        legendTitle58.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource63 = null;
        org.jfree.chart.title.LegendTitle legendTitle64 = new org.jfree.chart.title.LegendTitle(legendItemSource63);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment65 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle64.setHorizontalAlignment(horizontalAlignment65);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = legendTitle64.getLegendItemGraphicAnchor();
        legendTitle58.setLegendItemGraphicAnchor(rectangleAnchor67);
        java.awt.geom.Point2D point2D69 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D53, rectangleAnchor67);
        java.awt.geom.Rectangle2D rectangle2D72 = rectangleInsets26.createOutsetRectangle(rectangle2D53, false, true);
        boolean boolean73 = rectangleAnchor24.equals((java.lang.Object) rectangle2D72);
        try {
            java.awt.geom.Rectangle2D rectangle2D74 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 'a', 1.0d, rectangleAnchor24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(legendItemSourceArray8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str21.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(horizontalAlignment65);
        org.junit.Assert.assertNotNull(rectangleAnchor67);
        org.junit.Assert.assertNotNull(point2D69);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        piePlot1.setExplodePercent((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (double) (short) 1);
        piePlot1.setMinimumArcAngleToDraw((double) (byte) 0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot1.setURLGenerator(pieURLGenerator11);
        java.awt.Paint paint13 = piePlot1.getLabelLinkPaint();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        double double17 = legendTitle16.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle16.getPadding();
        java.lang.String str19 = rectangleInsets18.toString();
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass23 = rectangleInsets22.getClass();
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        double double26 = legendTitle25.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle25.getPadding();
        legendTitle25.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = legendTitle25.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle(legendItemSource31);
        double double33 = legendTitle32.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle32.getPadding();
        java.awt.geom.Rectangle2D rectangle2D35 = legendTitle32.getBounds();
        rectangleInsets30.trim(rectangle2D35);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType37 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets22.createAdjustedRectangle(rectangle2D35, lengthAdjustmentType37, lengthAdjustmentType38);
        legendTitle21.setBounds(rectangle2D39);
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets18.createOutsetRectangle(rectangle2D39, false, true);
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity50 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D39, pieDataset44, (int) (short) 10, 1, (java.lang.Comparable) 0.0f, "Multiple Pie Plot", "0,-1,1,1");
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass52 = rectangleInsets51.getClass();
        org.jfree.chart.LegendItemSource legendItemSource53 = null;
        org.jfree.chart.title.LegendTitle legendTitle54 = new org.jfree.chart.title.LegendTitle(legendItemSource53);
        double double55 = legendTitle54.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = legendTitle54.getPadding();
        legendTitle54.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = legendTitle54.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource60 = null;
        org.jfree.chart.title.LegendTitle legendTitle61 = new org.jfree.chart.title.LegendTitle(legendItemSource60);
        double double62 = legendTitle61.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = legendTitle61.getPadding();
        java.awt.geom.Rectangle2D rectangle2D64 = legendTitle61.getBounds();
        rectangleInsets59.trim(rectangle2D64);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType66 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType67 = null;
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets51.createAdjustedRectangle(rectangle2D64, lengthAdjustmentType66, lengthAdjustmentType67);
        org.jfree.chart.LegendItemSource legendItemSource69 = null;
        org.jfree.chart.title.LegendTitle legendTitle70 = new org.jfree.chart.title.LegendTitle(legendItemSource69);
        double double71 = legendTitle70.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = legendTitle70.getPadding();
        java.awt.geom.Rectangle2D rectangle2D73 = legendTitle70.getBounds();
        java.awt.geom.Rectangle2D rectangle2D76 = rectangleInsets51.createInsetRectangle(rectangle2D73, false, true);
        org.jfree.chart.LegendItemSource legendItemSource77 = null;
        org.jfree.chart.title.LegendTitle legendTitle78 = new org.jfree.chart.title.LegendTitle(legendItemSource77);
        double double79 = legendTitle78.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = legendTitle78.getPadding();
        legendTitle78.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource83 = null;
        org.jfree.chart.title.LegendTitle legendTitle84 = new org.jfree.chart.title.LegendTitle(legendItemSource83);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment85 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle84.setHorizontalAlignment(horizontalAlignment85);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor87 = legendTitle84.getLegendItemGraphicAnchor();
        legendTitle78.setLegendItemGraphicAnchor(rectangleAnchor87);
        java.awt.geom.Point2D point2D89 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D73, rectangleAnchor87);
        org.jfree.chart.plot.PlotState plotState90 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo91 = null;
        try {
            piePlot1.draw(graphics2D14, rectangle2D39, point2D89, plotState90, plotRenderingInfo91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str19.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(rectangle2D76);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets80);
        org.junit.Assert.assertNotNull(horizontalAlignment85);
        org.junit.Assert.assertNotNull(rectangleAnchor87);
        org.junit.Assert.assertNotNull(point2D89);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle1.setItemPaint((java.awt.Paint) color6);
        double double8 = legendTitle1.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        java.awt.Paint paint12 = multiplePiePlot11.getNoDataMessagePaint();
        java.awt.Paint paint13 = multiplePiePlot11.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot11);
        jFreeChart14.setBackgroundImageAlignment((int) (short) 0);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart14.setBorderPaint((java.awt.Paint) color18);
        jFreeChart14.setTextAntiAlias(false);
        java.awt.Paint paint22 = null;
        jFreeChart14.setBackgroundPaint(paint22);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot24 = jFreeChart14.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.MultiplePiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.lang.String str4 = titleChangeEvent3.toString();
        java.lang.Object obj5 = titleChangeEvent3.getSource();
        java.awt.Color color6 = java.awt.Color.ORANGE;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        double double16 = legendTitle9.getContentYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        java.awt.Paint paint20 = multiplePiePlot19.getNoDataMessagePaint();
        java.awt.Paint paint21 = multiplePiePlot19.getNoDataMessagePaint();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("{0}", (org.jfree.chart.plot.Plot) multiplePiePlot19);
        jFreeChart22.setBackgroundImageAlignment((int) (short) 0);
        legendTitle9.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart22);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        jFreeChart22.setBorderPaint((java.awt.Paint) color26);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = textTitle28.getTextAlignment();
        java.awt.Paint paint30 = textTitle28.getPaint();
        java.awt.Stroke[] strokeArray31 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        boolean boolean32 = textTitle28.equals((java.lang.Object) strokeArray31);
        jFreeChart22.addSubtitle((org.jfree.chart.title.Title) textTitle28);
        jFreeChart22.setTextAntiAlias(true);
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle(legendItemSource36);
        double double38 = legendTitle37.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent39 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle37);
        org.jfree.chart.JFreeChart jFreeChart40 = null;
        titleChangeEvent39.setChart(jFreeChart40);
        jFreeChart22.titleChanged(titleChangeEvent39);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType43 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean45 = chartChangeEventType43.equals((java.lang.Object) 8.0d);
        java.lang.String str46 = chartChangeEventType43.toString();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color51);
        boolean boolean53 = chartChangeEventType43.equals((java.lang.Object) (short) 100);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent54 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockBorder7, jFreeChart22, chartChangeEventType43);
        titleChangeEvent3.setChart(jFreeChart22);
        jFreeChart22.setNotify(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str46.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        legendTitle1.setID("ChartEntity: tooltip = ");
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle1.getPosition();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        double double9 = legendTitle8.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle8.getPadding();
        legendTitle8.setWidth((double) 0L);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = legendTitle8.getLegendItemGraphicEdge();
        boolean boolean14 = legendTitle8.getNotify();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot15.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Font font18 = multiplePiePlot15.getNoDataMessageFont();
        legendTitle8.setItemFont(font18);
        java.lang.Object obj20 = legendTitle8.clone();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        double double23 = legendTitle22.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame24 = legendTitle22.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray26 = new org.jfree.chart.LegendItemSource[] { legendItemSource25 };
        legendTitle22.setSources(legendItemSourceArray26);
        legendTitle8.setSources(legendItemSourceArray26);
        legendTitle1.setSources(legendItemSourceArray26);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame24);
        org.junit.Assert.assertNotNull(legendItemSourceArray26);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        boolean boolean2 = objectList0.equals((java.lang.Object) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.lang.Object obj3 = objectList0.clone();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color8);
        java.awt.Paint paint10 = blockBorder9.getPaint();
        boolean boolean11 = objectList0.equals((java.lang.Object) blockBorder9);
        java.lang.Object obj12 = objectList0.clone();
        java.lang.Object obj13 = objectList0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int2 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) (byte) 1);
        int int4 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) 255);
        try {
            java.lang.Comparable comparable6 = defaultKeyedValues2D0.getRowKey(192);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 192, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setNoDataMessage("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Font font3 = multiplePiePlot0.getNoDataMessageFont();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color4);
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        multiplePiePlot1.notifyListeners(plotChangeEvent3);
        org.jfree.chart.JFreeChart jFreeChart5 = multiplePiePlot1.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset6);
        java.awt.Paint paint8 = multiplePiePlot7.getNoDataMessagePaint();
        java.lang.Comparable comparable9 = multiplePiePlot7.getAggregatedItemsKey();
        java.awt.Color color10 = java.awt.Color.black;
        java.awt.Color color11 = color10.darker();
        multiplePiePlot7.setAggregatedItemsPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = multiplePiePlot7.getDrawingSupplier();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = multiplePiePlot7.getLegendItems();
        java.awt.Paint paint15 = multiplePiePlot7.getBackgroundPaint();
        jFreeChart5.setBackgroundPaint(paint15);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(jFreeChart5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "Other" + "'", comparable9.equals("Other"));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        java.awt.Paint paint2 = textTitle0.getPaint();
        java.awt.Paint paint3 = textTitle0.getPaint();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Set<java.lang.String> strSet2 = jFreeChartResources0.keySet();
        boolean boolean4 = jFreeChartResources0.containsKey("rect");
        boolean boolean6 = jFreeChartResources0.containsKey("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint3 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        multiplePiePlot1.markerChanged(markerChangeEvent4);
        java.lang.Object obj6 = multiplePiePlot1.clone();
        org.jfree.data.category.CategoryDataset categoryDataset7 = multiplePiePlot1.getDataset();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(categoryDataset7);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setMaximumLabelWidth((double) (-1.0f));
        boolean boolean4 = piePlot1.getSimpleLabels();
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.getLabelLinksVisible();
        double double7 = piePlot1.getInteriorGap();
        java.awt.Paint paint8 = piePlot1.getLabelShadowPaint();
        java.awt.Stroke stroke9 = piePlot1.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = new org.jfree.chart.LegendItemSource[] { legendItemSource4 };
        legendTitle1.setSources(legendItemSourceArray5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.Class<?> wildcardClass8 = rectangleInsets7.getClass();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle10.getPadding();
        legendTitle10.setWidth((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle10.getPadding();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        double double18 = legendTitle17.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle17.getPadding();
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle17.getBounds();
        rectangleInsets15.trim(rectangle2D20);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets7.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType22, lengthAdjustmentType23);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        double double27 = legendTitle26.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendTitle26.getPadding();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle26.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets7.createInsetRectangle(rectangle2D29, false, true);
        legendTitle1.setBounds(rectangle2D29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = null;
        try {
            legendTitle1.setItemLabelPadding(rectangleInsets35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.lang.String str4 = titleChangeEvent3.toString();
        java.lang.Object obj5 = titleChangeEvent3.getSource();
        java.lang.Object obj6 = titleChangeEvent3.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = titleChangeEvent3.getType();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getPadding();
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "", "hi!");
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        double double10 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle9.setItemPaint((java.awt.Paint) color14);
        boolean boolean16 = chartEntity7.equals((java.lang.Object) legendTitle9);
        java.awt.Color color17 = java.awt.Color.pink;
        legendTitle9.setItemPaint((java.awt.Paint) color17);
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement21 = blockContainer20.getArrangement();
        flowArrangement19.add((org.jfree.chart.block.Block) blockContainer20, (java.lang.Object) 255);
        boolean boolean24 = blockContainer20.isEmpty();
        legendTitle9.setWrapper(blockContainer20);
        double double26 = legendTitle9.getContentXOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(arrangement21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        textTitle0.setWidth((double) 100L);
        textTitle0.setText("");
        java.lang.String str6 = textTitle0.getText();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) (short) 100, (double) (-1), 0.0d, (java.awt.Paint) color11);
        textTitle0.setPaint((java.awt.Paint) color11);
        textTitle0.setURLText("PieSection: 255, -48897(10)");
        textTitle0.setText("VerticalAlignment.BOTTOM");
        java.awt.Paint paint18 = null;
        textTitle0.setBackgroundPaint(paint18);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(color11);
    }
}

